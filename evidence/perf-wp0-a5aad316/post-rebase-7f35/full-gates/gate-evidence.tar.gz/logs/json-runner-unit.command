command=bash -c cd\ \"\$1\"\ \&\&\ python3\ -m\ unittest\ benchmarks/sim-hotspots/test_run_json.py bash /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-full-1174ea06-7f35-20261014-r1/source-off 
