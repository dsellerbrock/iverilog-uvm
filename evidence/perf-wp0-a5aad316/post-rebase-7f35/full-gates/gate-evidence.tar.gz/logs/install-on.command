command=make -C /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-full-1174ea06-7f35-20261014-r1/source-on install 
