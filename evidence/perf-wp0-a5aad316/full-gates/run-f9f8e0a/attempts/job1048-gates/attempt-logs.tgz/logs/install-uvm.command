command=make -C /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-full-a5aad316-f9f8-20261014-r2/source-off installuvm 
