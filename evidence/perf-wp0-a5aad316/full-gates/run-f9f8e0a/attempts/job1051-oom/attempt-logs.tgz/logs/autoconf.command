command=bash -c cd\ \"\$1\"\ \&\&\ sh\ ./autoconf.sh bash /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-uvm-a5aad316-f9f8-20261014-r1/source 
