#ifndef IVL_netclass_H
#define IVL_netclass_H
/*
 * Copyright (c) 2012-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "LineInfo.h"
# include  "ivl_target.h"
# include  "nettypes.h"
# include  "property_qual.h"
# include  <cstdint>
# include  <iostream>
# include  <map>
# include  <set>
# include  <string>
# include  <vector>

class Design;
class netenum_t;
class NetExpr;
class NetNet;
class NetProcTop;
class NetScope;
class Module;
class PClass;
class PExpr;
class PEventStatement;
class Statement;

class netclass_t : public ivl_type_s {
    public:
      netclass_t(perm_string class_name, const netclass_t*super);
      ~netclass_t() override;

	// Set the property of the class during elaboration. Set the
	// name and type, and return true. If the name is already
	// present, then return false.
      bool set_property(perm_string pname, property_qualifier_t qual,
			ivl_type_t ptype,
			perm_string interface_modport = perm_string(),
			bool has_decl_initializer = false);

	// Set the scope for the class. The scope has no parents and
	// is used for the elaboration of methods
	// (tasks/functions). In other words, this is the class itself.
      void set_class_scope(NetScope*cscope);
      const netclass_t* find_ancestor_by_pform(const PClass*pclass) const;

      inline const NetScope* class_scope(void) const { return class_scope_; }

	// Set the scope for the class definition. This is the scope
	// where the class definition was encountered, and may be used
	// to locate symbols that the class definition may inherit
	// from its context. This can be nil, or a package or module
	// where a class is defined.
      void set_definition_scope(NetScope*dscope);

      NetScope*definition_scope(void);

	// As an ivl_type_s object, the netclass is always an
	// ivl_VT_CLASS object.
      ivl_variable_type_t base_type() const override;

	// This is the name of the class type
      inline perm_string get_name() const { return name_; }

	// If this is derived from another class, then this method
	// returns a pointer to the super-class.
      inline const netclass_t* get_super() const { return super_; }
      inline const std::vector<const netclass_t*>& derived_types() const { return derived_types_; }
      void set_super(const netclass_t*super);

	// Resolve the class's pure-constraint obligations after its superclass
	// is known. Concrete classes must implement every inherited prototype.
      void configure_constraint_declarations(Design*des, const PClass*pclass);

	// Interface-class inheritance is orthogonal to the single concrete
	// superclass chain. These relationships contribute type compatibility
	// and inherited prototypes/typedef visibility, but never properties or
	// object layout (IEEE 1800-2017 8.26).
      void add_interface(const netclass_t*interface_type);
      inline const std::vector<const netclass_t*>& interface_types() const
	    { return interface_types_; }
      bool implements_interface(const netclass_t*interface_type) const;

	// Get the number of properties in this class. Include
	// properties in the parent class.
      size_t get_properties(void) const;
	// Get information about each property.
      const char*get_prop_name(size_t idx) const;
      property_qualifier_t get_prop_qual(size_t idx) const;
      ivl_type_t get_prop_type(size_t idx) const;
      bool get_prop_has_decl_initializer(size_t idx) const;
      const netclass_t*get_prop_declaring_class(size_t idx) const;
      perm_string get_prop_interface_modport(size_t idx) const;

	// Return the declaring class-scope signal for a static property.
	// IDX is the absolute property index, so inherited properties are
	// resolved through the superclass before any local name lookup. This
	// is important when a derived class hides a base property with the
	// same name.
      NetNet*get_prop_static_signal(size_t idx) const;

	// The DLL target installs the ivl_signal_t corresponding to each
	// declaring NetNet after that signal has been converted. Targets can
	// then recover the exact signal from the absolute property index.
      bool bind_static_property_target(const NetNet*net,
				       ivl_signal_t target) const;
      ivl_signal_t get_prop_static_target(size_t idx) const;

	// These methods are used by the elaborator to note the
	// initializer for constant properties. Properties start out
	// as not initialized, and when elaboration detects an
	// assignment to the property, it is marked initialized.
      bool get_prop_initialized(size_t idx) const;
      void set_prop_initialized(size_t idx) const;

      bool test_for_missing_initializers(void) const;

	// Map the name of a property to its index. Return <0 if the
	// name is not a property in the class.
      int property_idx_from_name(perm_string pname) const;

	// The task method scopes from the method name.
      NetScope*method_from_name(perm_string mname) const;

	// Resolve an object method call. This normally returns the method
	// found on the static class type, but if that resolves to an
	// abstract/bodyless prototype then this may redirect to a unique
	// concrete override found in a descendant class.
      NetScope*resolve_method_call_scope(const Design*des, perm_string mname) const;

	// Returns the constructor task method of the class. Might be nullptr if
	// there is nothing to do in the constructor.
      NetScope* get_constructor() const;

	// Find the elaborated signal (NetNet) for a static
	// property. Search by name. The signal is created by the
	// elaborate_sig pass.
      NetNet*find_static_property(perm_string name) const;

	// Test if this scope is a method within the class. This is
	// used to check scope for handling data protection keywords
	// "local" and "protected".
      bool test_scope_is_method(const NetScope*scope) const;

      void elaborate_sig(Design*des, PClass*pclass);
      void elaborate(Design*des, PClass*pclass);
      void elaborate_constraints(Design*des, PClass*pclass);

      void emit_scope(struct target_t*tgt) const;
      bool emit_defs(struct target_t*tgt) const;
      int ensure_property_decl(Design*des, perm_string pname);

      // Ensure ALL properties in this class and its entire super chain are
      // declared. This makes get_properties() return a stable final count so
      // that property_idx_from_name() computes correct absolute indices even
      // when called early during incremental elaboration.
      void ensure_all_properties_declared(Design*des);

      // Overwrite the stored type for an already-declared property.
      // Used by elaborate_sig to repair types that were stored as
      // integer fallbacks due to circular elaboration order.
      void repair_property_type(perm_string pname, ivl_type_t new_type);

      // Revisit bare parameterized-class properties after all class scopes
      // are visible. Forward declarations may initially leave a generic
      // class placeholder even though the declaration denotes C#().
      void repair_bare_class_property_types(Design*des);

      std::ostream& debug_dump(std::ostream&fd) const override;
      void dump_scope(std::ostream&fd) const;

      const NetExpr* get_parameter(Design *des, perm_string name,
				   ivl_type_t &par_type) const;

      void set_virtual(bool virtual_class) { virtual_class_ = virtual_class; }
      bool is_virtual() const { return virtual_class_; }
      void set_final_class(bool final_class) { final_class_ = final_class; }
      bool is_final_class() const { return final_class_; }
      void set_interface_class(bool flag) { interface_class_type_ = flag; }
      bool is_interface_class() const { return interface_class_type_; }
      void set_interface(bool interface_type) { interface_type_ = interface_type; }
      bool is_interface() const { return interface_type_; }
      void set_interface_identity(const Module*definition,
                                  const std::string&parameter_key,
                                  const std::string&layout_parameter_key,
                                  perm_string modport);
      const Module* interface_definition() const
            { return interface_definition_; }
      std::uintptr_t interface_definition_id() const
            { return interface_definition_id_; }
      void retire_interface_definition() { interface_definition_ = nullptr; }
      const std::string& interface_parameter_key() const
            { return interface_parameter_key_; }
      const std::string& interface_layout_parameter_key() const
            { return interface_layout_parameter_key_; }
      perm_string interface_modport() const { return interface_modport_; }
      bool same_interface_layout(const netclass_t*that) const;
      bool same_interface_type(const netclass_t*that) const;
      bool interface_assignment_compatible_from(const netclass_t*source) const;
      void set_unresolved_interface(bool flag)
	    { unresolved_interface_type_ = flag; }
      bool is_unresolved_interface() const
		    { return unresolved_interface_type_; }

	/* A typed mailbox is a built-in parameterized class. Keep the
	 * elaborated message type on the carrier instead of borrowing its
	 * short-lived parse-form #(...) expression. The semantic key is owned by
	 * this object and lets specialization/cache serializers distinguish
	 * mailbox#(T) even though built-ins have no PClass parameter scope. */
      void set_mailbox_message_type(ivl_type_t type,
                                    const std::string&matching_key);
      bool is_typed_mailbox() const { return mailbox_message_type_ != 0; }
      ivl_type_t mailbox_message_type() const { return mailbox_message_type_; }
      const std::string& mailbox_message_type_key() const
            { return mailbox_message_type_key_; }
      bool mailbox_message_type_equivalent(ivl_type_t actual) const;
      void set_sig_elaborated(bool flag) { sig_elaborated_ = flag; }
      bool sig_elaborated() const { return sig_elaborated_; }
      void set_sig_elaborating(bool flag) { sig_elaborating_ = flag; }
      bool sig_elaborating() const { return sig_elaborating_; }

	// Constraint IR: simple token-stream representation of constraint blocks.
	// Format: each item is "name\tir_string" where ir_string is an
	// S-expression like "(lt p:1:8 c:255)".
      struct constraint_dependency_t {
		  enum kind_t { PROP = 0, MEMBER = 1, ELEM = 2, SIZE = 3 };
		  unsigned kind;
		  unsigned property;
		  unsigned leaf;
		  bool operator<(const constraint_dependency_t&that) const
		  {
			if (kind != that.kind) return kind < that.kind;
			if (property != that.property) return property < that.property;
			return leaf < that.leaf;
		  }
	};
      struct constraint_state_call_t {
	    perm_string method;
	    NetScope*method_scope;
	    std::string method_scope_name;
	    bool is_virtual;
	    std::vector<constraint_dependency_t> argument_dependencies;
	    size_t constraint_index;
	    unsigned width;
	    bool is_signed;
      };
      void add_constraint_ir(const std::string&name, const std::string&ir,
		const std::vector<constraint_state_call_t>&calls = {});
      size_t constraint_ir_count() const
	    { merge_inherited_constraint_irs_(); return constraint_irs_.size(); }
      const std::string& constraint_ir_name(size_t idx) const;
      const std::string& constraint_ir_str(size_t idx)  const;
      size_t constraint_state_call_count() const;
      const constraint_state_call_t&constraint_state_call(size_t idx) const;
      void set_body_elaborated(bool flag) { body_elaborated_ = flag; }
      bool body_elaborated() const { return body_elaborated_; }
      bool constraints_elaborated() const { return constraints_elaborated_; }
      void set_body_elaborating(bool flag) { body_elaborating_ = flag; }
      bool body_elaborating() const { return body_elaborating_; }
      void set_scope_ready(bool flag) { scope_ready_ = flag; }
      bool scope_ready() const { return scope_ready_; }
      void set_specialized_instance(bool flag) { specialized_instance_ = flag; }
      bool specialized_instance() const { return specialized_instance_; }

	/* True when this specialization was materialised WHILE ELABORATING a
	   template seed, from that seed's own default type parameters -- e.g.
	   `class C #(type T = int) extends B #(uvm_class_pair #(T,T))' makes
	   uvm_class_pair#(int,int) while C's own generic body is elaborated.
	   Nothing in the design instantiates such a class, so IEEE 8.25's
	   "a generic class is not a type" reasoning extends to it: it is part
	   of the seed, and diagnostics from its body are false positives.
	   It is still a specialized_instance() for every other purpose. */
	// Requested only by generic master bodies so far: not a runtime type
	// (IEEE 1800 8.25), so its static initializers must not run.
      // Clearing the mark also clears it on every class this one marked
      // while it was generic-body-only: they are now reachable from a
      // concrete type too.
      void set_generic_body_only(bool flag);
      bool generic_body_only() const { return generic_body_only_; }
      void add_generic_dependent(netclass_t*dep) { generic_dependents_.push_back(dep); }
      // The static-initializer process held back while generic-body-only;
      // released once elaboration knows whether the class is concrete.
      void set_deferred_static_init(NetProcTop*top) { deferred_static_init_ = top; }
      NetProcTop* take_deferred_static_init()
      { NetProcTop*top = deferred_static_init_; deferred_static_init_ = 0; return top; }
      void set_seed_derived(bool flag) { seed_derived_ = flag; }
      bool seed_derived() const { return seed_derived_; }

      struct clocking_block_t {
	    perm_string name;
	    const PEventStatement* event;
	    std::vector<perm_string> signals;
	      /* Per-signal direction, copied from Module::PClocking as
		 int(NetNet::PortType) — this header cannot see NetNet.
		 Signals missing from the map behave as inout. */
	    std::map<perm_string,int> directions;
	      /* Simple signal-path clocking_decl_assign aliases. This is
		 sufficient for virtual-interface rewrites; complex paths retain
		 the defining-scope resolver. */
	    std::map<perm_string,perm_string> aliases;
      };
      bool add_clocking_block(perm_string name, const PEventStatement*event,
			      const std::vector<perm_string>&signals,
			      const std::map<perm_string,int>&directions,
			      const std::map<perm_string,perm_string>&aliases);
      const clocking_block_t* find_clocking_block(perm_string name) const;

    protected:
      bool test_compatibility(ivl_type_t that) const override;
      bool test_equivalence(ivl_type_t that) const override;

    private:
      void add_derived_type_(const netclass_t*derived);

      perm_string name_;
	// If this is derived from another base class, point to it
	// here.
      const netclass_t*super_;
      std::vector<const netclass_t*> derived_types_;
      std::vector<const netclass_t*> interface_types_;
	// Map property names to property table index.
      std::map<perm_string,size_t> properties_;
	// Separate synthesized types for embedded covergroup extensions.
      std::map<perm_string,netclass_t*> covgrp_extensions_;
	// Vector of properties.
      struct prop_t {
	    perm_string name;
	    property_qualifier_t qual;
	    ivl_type_t type;
	    perm_string interface_modport;
	    bool has_decl_initializer;
	    mutable bool initialized_flag;
	    mutable ivl_signal_t static_target;
      };
      std::vector<prop_t> property_table_;

	// This holds task/function definitions for methods.
      NetScope*class_scope_;

	// This holds the context for the class type definition.
      NetScope*definition_scope_;

      bool virtual_class_;
      bool final_class_;
      bool interface_class_type_;
      bool interface_type_;
      const Module*interface_definition_;
      std::uintptr_t interface_definition_id_;
      std::string interface_parameter_key_;
      std::string interface_layout_parameter_key_;
      perm_string interface_modport_;
      bool unresolved_interface_type_;
      ivl_type_t mailbox_message_type_;
      std::string mailbox_message_type_key_;
      bool sig_elaborated_;
      bool sig_elaborating_;
      bool props_declaring_;  // guard for ensure_all_properties_declared re-entry
      bool body_elaborated_;
      bool body_elaborating_;
      bool constraints_elaborated_ = false;
      bool constraints_elaborating_ = false;
      bool scope_ready_;
      bool specialized_instance_;
      bool seed_derived_ = false;
      bool generic_body_only_ = false;
      std::vector<netclass_t*> generic_dependents_;
      NetProcTop*deferred_static_init_ = 0;
      std::map<perm_string,size_t> clocking_blocks_;
      std::vector<clocking_block_t> clocking_table_;

      struct constraint_ir_t {
	    std::string name;
	    std::string ir;
	    std::string flat_ir;
	    std::vector<constraint_state_call_t> state_calls;
      };
      mutable std::vector<constraint_ir_t> constraint_irs_;
	mutable std::vector<constraint_state_call_t> constraint_state_calls_;
	// Unimplemented pure constraints inherited by this exact class type.
	// The source location is the original pure declaration, used by the
	// concrete-class diagnostic.
      std::map<perm_string,LineInfo> unimplemented_pure_constraints_;
      bool constraint_declarations_configured_ = false;
	// Constraint inheritance (IEEE 1800-2017 18.5.2): derived classes
	// inherit base-class constraints unless overridden by a local
	// constraint of the same name. The merge runs lazily on the first
	// count query, which happens at code-emission time after all
	// classes have elaborated their own constraint blocks. Property
	// indexes are stable across the inheritance chain (base properties
	// keep their slots in derived classes), so base IR strings apply
	// verbatim.
      void merge_inherited_constraint_irs_() const;
      mutable bool constraint_irs_merged_ = false;

    public:
	// Covergroup bin metadata (for synthesized covergroup class types).
	// Each entry represents one bin: the cp_idx selects which
	// coverpoint value to sample (matches the order they are pushed
	// on the vec4 stack at the sample() call site), prop_idx is the
	// property index in THIS class that holds the bin hit count,
	// and lo/hi define the inclusive range.
	// M11: each entry is one predicate RECORD of a coverage bin.
	// Records sharing (prop_idx, tuple) are ANDed (cross product
	// tuples); different tuples of the same prop are ORed (multi-
	// range bins).  item_idx groups props into coverage items
	// (coverpoints 0..ncp-1, then crosses) for per-item coverage.
      struct covgrp_bin_t {
	    unsigned cp_idx;
	    unsigned prop_idx;   // 0xFFFFFFFF: no counter (ignore bins)
	    uint64_t lo;         // wildcard: match value
	    uint64_t hi;         // wildcard: care mask
	    // kind & 7: 0 = normal counted bin
	    //           1 = ignore_bin (carves values out of the item)
	    //           2 = illegal_bin (runtime error on match)
	    //           3 = default bin (counts only when no normal
	    //               bin of the item matched; excluded from %)
	    //           4 = transition step (M11-2; tuple encodes
	    //               (seq_id << 8) | step_pos, lo/hi the step)
	    //           5 = illegal_bins default (complement of normal bins)
	    //           6 = ignore_bins default (complement of normal bins)
	    // kind & 8: wildcard match ((v ^ lo) & hi == 0)
	    // kind & 128: exact 4-state value; lo packs 2-bit states, hi gives width/chunk.
	    unsigned kind = 0;
	    unsigned tuple = 0;
	    unsigned item_idx = 0;
	      // Transition-program metadata. Defaults preserve old/simple
	      // records. trans_family==COVGRP_NO_FAMILY means the transition
	      // increments prop_idx; otherwise it increments a sparse logical
	      // bin in that compact arrayed family.
	    unsigned trans_repeat = 0;
	    uint64_t trans_min = 1;
	    uint64_t trans_max = 1;
	    unsigned trans_alt = 0;
	    unsigned trans_alt_count = 1;
	    unsigned trans_family = 0xFFFFFFFFu;
	    uint64_t trans_base = 0;
	    unsigned guard_idx = 0xFFFFFFFFu;
      };

	// A bin whose endpoints depend on constructor formals. Records with
	// the same family identify the ranges of one source-language bin
	// declaration. array_size==0 means an unsized [] family (one logical
	// bin per value), UINT64_MAX means a non-arrayed bin, and any other
	// value partitions the union into that many logical bins.
      struct covgrp_dyn_bin_t {
	    unsigned cp_idx = 0;
	    unsigned item_idx = 0;
	    unsigned kind = 0;
	    unsigned family = 0;
	    uint64_t array_size = 0;
	    std::string name;
	    std::string lo_ir;
	    std::string hi_ir;
	    unsigned value_width = 64;
	    bool value_signed = false;
	    unsigned guard_idx = 0xFFFFFFFFu;
	    unsigned trans_seq = 0;
	    unsigned trans_term = 0;
	    unsigned trans_repeat = 0;
	    uint64_t trans_min = 1;
	    uint64_t trans_max = 1;
      };

	// Compact per-instance cross metadata. A header identifies one cross
	// plan, terms describe its dimensions in stable source order, and named
	// bin records retain the selection IR used to route sampled tuples.
      struct covgrp_cross_t {
	    unsigned family = 0;
	    unsigned item_idx = 0;
	    unsigned n_dims = 0;
	    bool retain_auto = false;
      };
      struct covgrp_cross_term_t {
	    unsigned family = 0;
	    unsigned dim = 0;
	    unsigned term_idx = 0;
	    unsigned kind = 0;
	    unsigned source_id = 0;
	    unsigned source_aux = 0;
      };
      struct covgrp_cross_bin_t {
	    unsigned family = 0;
	    unsigned kind = 0;
	    unsigned target = 0;
	    std::string name;
	    std::string select_ir;
      };

	// M11: per-item (coverpoint or cross) coverage options.
      struct covgrp_item_t {
	    unsigned at_least = 1;
	    unsigned weight = 1;
            unsigned type_weight = 1;
	    std::string weight_ir; // per-instance constructor expression
	    int at_least_prop = -1; // mutable per-instance option slot
	    int weight_prop = -1;   // mutable per-instance option slot
	    bool is_cross = false;
	    perm_string name;   // M12-7: coverpoint/cross label
	    PExpr* iff_expr = nullptr; // cross-level iff, evaluated per sample
	    int iff_src = -1;          // parent property for sample/all
      };

      static const unsigned COVGRP_NO_PROP = 0xFFFFFFFF;
      static const unsigned COVGRP_NO_FAMILY = 0xFFFFFFFF;
      static const unsigned COVGRP_NO_GUARD = 0xFFFFFFFF;
	static const unsigned COVGRP_REAL_BIN = 0x100;

      void add_covgrp_bin(unsigned cp, unsigned prop, uint64_t lo, uint64_t hi,
			  unsigned kind = 0, unsigned tuple = 0,
			  unsigned item_idx = 0, unsigned trans_repeat = 0,
			  uint64_t trans_min = 1, uint64_t trans_max = 1,
			  unsigned trans_alt = 0,
			  unsigned trans_alt_count = 1,
			  unsigned trans_family = COVGRP_NO_FAMILY,
			  uint64_t trans_base = 0,
			  unsigned guard_idx = COVGRP_NO_GUARD);
      size_t covgrp_bin_count() const { return covgrp_bins_.size(); }
      const covgrp_bin_t& covgrp_bin(size_t idx) const { return covgrp_bins_[idx]; }
	void set_last_covgrp_bin_guard(unsigned guard)
	{ if (!covgrp_bins_.empty()) covgrp_bins_.back().guard_idx = guard; }
      void add_covgrp_dyn_bin(unsigned cp, unsigned item, unsigned kind,
			      unsigned family, uint64_t array_size,
			      const std::string&name,
			      const std::string&lo_ir,
			      const std::string&hi_ir,
			      unsigned value_width = 64,
			      bool value_signed = false,
			      unsigned guard_idx = COVGRP_NO_GUARD,
			      unsigned trans_seq = 0,
			      unsigned trans_term = 0,
			      unsigned trans_repeat = 0,
			      uint64_t trans_min = 1,
			      uint64_t trans_max = 1)
      { covgrp_dyn_bin_t b;
	b.cp_idx = cp; b.item_idx = item; b.kind = kind; b.family = family;
	b.array_size = array_size; b.name = name; b.lo_ir = lo_ir; b.hi_ir = hi_ir;
	b.value_width = value_width; b.value_signed = value_signed;
	b.guard_idx = guard_idx;
	b.trans_seq = trans_seq; b.trans_term = trans_term;
	b.trans_repeat = trans_repeat; b.trans_min = trans_min;
	b.trans_max = trans_max;
	covgrp_dyn_bins_.push_back(b); }
      size_t covgrp_dyn_bin_count() const { return covgrp_dyn_bins_.size(); }
      const covgrp_dyn_bin_t& covgrp_dyn_bin(size_t idx) const
      { return covgrp_dyn_bins_[idx]; }
      void add_covgrp_cross(unsigned family, unsigned item, unsigned n_dims,
			    bool retain_auto)
      { covgrp_cross_t cross;
	cross.family = family; cross.item_idx = item; cross.n_dims = n_dims;
	cross.retain_auto = retain_auto;
	covgrp_crosses_.push_back(cross); }
      size_t covgrp_cross_count() const { return covgrp_crosses_.size(); }
      const covgrp_cross_t& covgrp_cross(size_t idx) const
      { return covgrp_crosses_[idx]; }
      void add_covgrp_cross_term(unsigned family, unsigned dim,
				 unsigned term_idx, unsigned kind,
				 unsigned source_id, unsigned source_aux)
      { covgrp_cross_term_t term;
	term.family = family; term.dim = dim; term.term_idx = term_idx;
	term.kind = kind; term.source_id = source_id;
	term.source_aux = source_aux;
	covgrp_cross_terms_.push_back(term); }
      size_t covgrp_cross_term_count() const
      { return covgrp_cross_terms_.size(); }
      const covgrp_cross_term_t& covgrp_cross_term(size_t idx) const
      { return covgrp_cross_terms_[idx]; }
      void add_covgrp_cross_bin(unsigned family, unsigned kind,
				unsigned target, const std::string&name,
				const std::string&select_ir)
      { covgrp_cross_bin_t bin;
	bin.family = family; bin.kind = kind; bin.target = target;
	bin.name = name; bin.select_ir = select_ir;
	covgrp_cross_bins_.push_back(bin); }
      size_t covgrp_cross_bin_count() const
      { return covgrp_cross_bins_.size(); }
      const covgrp_cross_bin_t& covgrp_cross_bin(size_t idx) const
      { return covgrp_cross_bins_[idx]; }
      void add_covgrp_item(unsigned at_least, unsigned weight,
                           unsigned type_weight, bool is_cross,
			   perm_string name = perm_string(),
			   const std::string&weight_ir = std::string(),
			   PExpr*iff_expr = nullptr, int iff_src = -1,
			   int at_least_prop = -1, int weight_prop = -1)
      { covgrp_item_t it;
	it.at_least = at_least;
	it.weight = weight;
        it.type_weight = type_weight;
	it.weight_ir = weight_ir;
	it.at_least_prop = at_least_prop;
	it.weight_prop = weight_prop;
	it.is_cross = is_cross;
	it.name = name;
	it.iff_expr = iff_expr;
	it.iff_src = iff_src;
	covgrp_items_.push_back(it); }
      struct covgrp_options_t {
            bool merge_instances = false;
            bool per_instance = false;
            unsigned type_weight = 1;
            unsigned weight = 1, get_inst_coverage = 0;
            PExpr* weight_expr = nullptr;
            PExpr* per_instance_expr = nullptr;
            PExpr* get_inst_coverage_expr = nullptr;
            NetScope* declaration_scope = nullptr;
            int weight_prop = -1, per_instance_prop = -1;
            int get_inst_coverage_prop = -1;
      };
      covgrp_options_t& covgrp_options() { return covgrp_options_; }
      const covgrp_options_t& covgrp_options() const { return covgrp_options_; }
      int covgrp_option_prop(perm_string name) const {
            if (name == perm_string::literal("weight"))
                  return covgrp_options_.weight_prop;
            if (name == perm_string::literal("per_instance"))
                  return covgrp_options_.per_instance_prop;
            if (name == perm_string::literal("get_inst_coverage"))
                  return covgrp_options_.get_inst_coverage_prop;
            return -1;
      }
      size_t covgrp_item_count() const { return covgrp_items_.size(); }
      const covgrp_item_t& covgrp_item(size_t idx) const { return covgrp_items_[idx]; }
	// Resolve the IEEE hierarchical pseudo-members
	//   <coverpoint-or-cross>.option.{at_least,weight}
	// to the synthesized scalar property that carries the mutable value on
	// each covergroup object. The item labels themselves are metadata rather
	// than class properties, so expression/l-value elaboration uses this hook
	// before ordinary class-member lookup.
      int covgrp_item_option_prop(perm_string item_name,
				   perm_string option_name) const {
	    for (const covgrp_item_t&item : covgrp_items_) {
		  if (item.name != item_name) continue;
		  if (option_name == perm_string::literal("at_least"))
			return item.at_least_prop;
		  if (option_name == perm_string::literal("weight"))
			return item.weight_prop;
		  return -1;
	    }
	    return -1;
      }
      bool has_covgrp_item(perm_string item_name) const {
	    for (const covgrp_item_t&item : covgrp_items_)
		  if (item.name == item_name)
			return true;
	    return false;
      }
      PExpr* covgrp_item_guard(size_t idx) const {
	    return idx < covgrp_items_.size() ? covgrp_items_[idx].iff_expr : nullptr;
      }
      int covgrp_item_guardsrc(size_t idx) const {
	    return idx < covgrp_items_.size() ? covgrp_items_[idx].iff_src : -1;
      }
      bool is_covergroup() const { return is_covergroup_; }
      void set_is_covergroup(bool f) { is_covergroup_ = f; }
	// Covergroup constructor formals are stored as leading properties
	// on the synthesized covergroup object. `new(args)` initializes
	// these slots once, and dynamic coverage metadata reads them from
	// the particular instance being sampled.
      void add_covgrp_ctor_formal(perm_string name, unsigned prop,
				   ivl_type_t type, PExpr*defe, bool is_ref)
      { covgrp_ctor_names_.push_back(name);
	covgrp_ctor_props_.push_back(prop);
	covgrp_ctor_types_.push_back(type);
	covgrp_ctor_defaults_.push_back(defe);
	covgrp_ctor_is_ref_.push_back(is_ref); }
      size_t covgrp_ctor_formal_count() const { return covgrp_ctor_names_.size(); }
      perm_string covgrp_ctor_formal_name(size_t i) const { return covgrp_ctor_names_[i]; }
      unsigned covgrp_ctor_formal_prop(size_t i) const { return covgrp_ctor_props_[i]; }
      ivl_type_t covgrp_ctor_formal_type(size_t i) const { return covgrp_ctor_types_[i]; }
      PExpr* covgrp_ctor_formal_default(size_t i) const { return covgrp_ctor_defaults_[i]; }
      bool covgrp_ctor_formal_is_ref(size_t i) const
      { return i < covgrp_ctor_is_ref_.size() && covgrp_ctor_is_ref_[i]; }

      struct covgrp_ctor_method_endpoint_t {
            covgrp_ctor_method_endpoint_t(const PExpr*source, unsigned property,
		unsigned bits, bool sign)
		: expr(source), prop(property), width(bits), is_signed(sign) { }
            const PExpr*expr;
            unsigned prop;
            unsigned width;
            bool is_signed;
      };
      void add_covgrp_ctor_method_endpoint(const PExpr*expr, unsigned prop,
		unsigned width, bool is_signed)
      { covgrp_ctor_method_endpoints_.push_back(
	    covgrp_ctor_method_endpoint_t(expr, prop, width, is_signed)); }
      std::vector<covgrp_ctor_method_endpoint_t>& covgrp_ctor_method_endpoints()
      { return covgrp_ctor_method_endpoints_; }
      const std::vector<covgrp_ctor_method_endpoint_t>& covgrp_ctor_method_endpoints() const
      { return covgrp_ctor_method_endpoints_; }

	// Semantic binding for direct identifiers used in covergroup range
	// expressions. A found-but-illegal symbol is retained here so later
	// constant evaluation cannot accidentally fall through to a parameter or
	// enum with the same spelling.
      enum covgrp_range_ref_kind_t {
	    COVGRP_RANGE_CTOR_VALUE,
	    COVGRP_RANGE_CTOR_REF,
	    COVGRP_RANGE_PARENT_GLOBAL_CONST,
	    COVGRP_RANGE_PARENT_INSTANCE_CONST,
	    COVGRP_RANGE_PARENT_MUTABLE,
	    COVGRP_RANGE_PARENT_LOCAL,
	    COVGRP_RANGE_PARENT_BAD_CONST
      };
      struct covgrp_range_ref_t {
	    covgrp_range_ref_kind_t kind;
	    int parent_prop;
	    unsigned ctor_formal;
      };
      struct covgrp_parent_const_dep_t {
	    unsigned parent_prop;
	    const PExpr*ref_site;
      };
      void bind_covgrp_range_ref(const PExpr*expr, covgrp_range_ref_kind_t kind,
				 int parent_prop = -1,
				 unsigned ctor_formal = 0);
      const covgrp_range_ref_t*covgrp_range_ref(const PExpr*expr) const;
      void add_covgrp_parent_const_dependency(unsigned parent_prop,
					       const PExpr*ref_site);
      const std::vector<covgrp_parent_const_dep_t>&
      covgrp_parent_const_dependencies() const
      { return covgrp_parent_const_dependencies_; }
      void set_covgrp_range_bindings_complete(bool value)
      { covgrp_range_bindings_complete_ = value; }
      bool covgrp_range_bindings_complete() const
      { return covgrp_range_bindings_complete_; }

	// Definite initialization summary for IEEE 1800 8.19 instance
	// constants at every reachable exit from this class's constructor. The
	// superclass is signature-elaborated first, so a derived-class covergroup
	// can use this proof for an inherited protected/public dependency.
      void set_constructor_definitely_initialized(
	    const std::set<size_t>&properties)
      { constructor_definitely_initialized_ = properties;
	constructor_initialization_audited_ = true; }
      const std::set<size_t>&constructor_definitely_initialized() const
      { return constructor_definitely_initialized_; }
      bool constructor_initialization_audited() const
      { return constructor_initialization_audited_; }

	// The unlowered constructor control-flow audit is authoritative for
	// procedural writes to IEEE 1800 8.19 instance constants. Parse-form
	// statements may be shared by parameterized specializations, so retain
	// the decision on this elaborated class type rather than on Statement.
      enum constructor_initializer_site_status_t {
	    CONSTRUCTOR_INITIALIZER_NOT_APPLICABLE,
	    CONSTRUCTOR_INITIALIZER_AUTHORIZED,
	    CONSTRUCTOR_INITIALIZER_REJECTED
      };
      void set_constructor_initializer_sites(
	    const std::set<const Statement*>&authorized,
	    const std::set<const Statement*>&rejected,
	    const std::map<const Statement*,size_t>&properties);
      constructor_initializer_site_status_t
      constructor_initializer_site_status(const Statement*statement) const;
      int constructor_initializer_property(const Statement*statement) const;
      bool has_embedded_covergroups() const { return has_embedded_cgs_; }
      void set_has_embedded_covergroups(bool f) { has_embedded_cgs_ = f; }
      netclass_t* covgrp_extension_class(perm_string name) const
	    { auto found = covgrp_extensions_.find(name);
	      return found == covgrp_extensions_.end() ? nullptr : found->second; }
      void set_covgrp_extension_class(perm_string name, netclass_t*type)
	    { covgrp_extensions_[name] = type; }
      unsigned covgrp_ncoverpoints() const { return covgrp_ncoverpoints_; }
      void set_covgrp_ncoverpoints(unsigned n) { covgrp_ncoverpoints_ = n; }

	// Property index in the PARENT class for each coverpoint
	// (in coverpoint order). Used at sample() call sites.
      void add_covgrp_cp_parent_prop(int pidx) { covgrp_cp_parent_props_.push_back(pidx); }
      int covgrp_cp_parent_prop(unsigned cp_idx) const {
	    if (cp_idx < covgrp_cp_parent_props_.size()) return covgrp_cp_parent_props_[cp_idx];
	    return -1;
      }

	// M11: per-coverpoint iff guard expressions (pform, evaluated
	// at each sample() call site; null = unguarded).
      void add_covgrp_cp_guard(PExpr*g) { covgrp_cp_guards_.push_back(g); }
	// Per-bin iff expressions, evaluated in declaration order at every
	// explicit/standalone sample site. Bin records reference this table.
      unsigned add_covgrp_bin_guard(PExpr*g)
      { covgrp_bin_guards_.push_back(g);
	return static_cast<unsigned>(covgrp_bin_guards_.size() - 1); }
      size_t covgrp_bin_guard_count() const { return covgrp_bin_guards_.size(); }
      PExpr* covgrp_bin_guard(size_t idx) const
      { return idx < covgrp_bin_guards_.size() ? covgrp_bin_guards_[idx] : nullptr; }
	// Coverpoint SOURCE expressions (pform), for sample() sites
	// where the source is not a parent-class property — standalone
	// (module/package-scope) covergroups sample scope signals, and
	// the expression elaborates in the CALLER's scope.
      void add_covgrp_cp_expr(PExpr*e) { covgrp_cp_exprs_.push_back(e); }
	// M11-4: `with function sample(...)` formals, in declaration
	// order. Keep the declared type as well as the name: an actual
	// expression is assignment-compatible with the formal and need not
	// have the same type itself (for example a packed vector passed to a
	// packed-struct formal). Coverpoint member lookup must use the
	// formal's declared type after that conversion.
	void add_covgrp_sample_formal(perm_string n, ivl_type_t t, PExpr*d)
	{ covgrp_sample_formals_.push_back(n);
	  covgrp_sample_formal_types_.push_back(t);
	  covgrp_sample_formal_defaults_.push_back(d); }
	size_t covgrp_sample_formal_count() const { return covgrp_sample_formals_.size(); }
	perm_string covgrp_sample_formal(size_t i) const { return covgrp_sample_formals_[i]; }
	ivl_type_t covgrp_sample_formal_type(size_t i) const {
	    if (i < covgrp_sample_formal_types_.size())
		  return covgrp_sample_formal_types_[i];
	    return nullptr;
	}
	PExpr* covgrp_sample_formal_default(size_t i) const {
	    if (i < covgrp_sample_formal_defaults_.size())
		  return covgrp_sample_formal_defaults_[i];
	    return nullptr;
	}
      PExpr* covgrp_cp_expr(unsigned cp_idx) const {
	    if (cp_idx < covgrp_cp_exprs_.size()) return covgrp_cp_exprs_[cp_idx];
	    return 0;
      }
      PExpr* covgrp_cp_guard(unsigned cp_idx) const {
	    if (cp_idx < covgrp_cp_guards_.size()) return covgrp_cp_guards_[cp_idx];
	    return nullptr;
      }

	// M11-3: event-driven sampling of class-embedded covergroups.
	// The runtime samples every live instance on the declaration
	// event: per coverpoint it reads the PARENT object's property
	// (srcprop; -1 = not property-backed, samples constant 0) and
	// guard property (guardsrc; -1 = unguarded), reaching the
	// parent through the hidden __covgrp_parent handle property.
      void add_covgrp_cp_srcprop(int p) { covgrp_cp_srcprops_.push_back(p); }
      int covgrp_cp_srcprop(unsigned cp_idx) const {
	    if (cp_idx < covgrp_cp_srcprops_.size()) return covgrp_cp_srcprops_[cp_idx];
	    return -1;
      }
      void add_covgrp_cp_guardsrc(int p) { covgrp_cp_guardsrcs_.push_back(p); }
      int covgrp_cp_guardsrc(unsigned cp_idx) const {
	    if (cp_idx < covgrp_cp_guardsrcs_.size()) return covgrp_cp_guardsrcs_[cp_idx];
	    return -1;
      }
      void add_covgrp_cp_sample_ir(const std::string&ir)
      { covgrp_cp_sample_irs_.push_back(ir); }
      const std::string& covgrp_cp_sample_ir(unsigned cp_idx) const {
	    static const std::string empty;
	    return cp_idx < covgrp_cp_sample_irs_.size()
		  ? covgrp_cp_sample_irs_[cp_idx] : empty;
      }
      void set_covgrp_parent_prop(int p) { covgrp_parent_prop_ = p; }
      int covgrp_parent_prop() const { return covgrp_parent_prop_; }
      void set_covgrp_owner_prop(int p) { covgrp_owner_prop_ = p; }
      int covgrp_owner_prop() const { return covgrp_owner_prop_; }

    private:
      std::vector<PExpr*> covgrp_cp_exprs_;
      std::vector<perm_string> covgrp_sample_formals_;
      std::vector<ivl_type_t> covgrp_sample_formal_types_;
      std::vector<PExpr*> covgrp_sample_formal_defaults_;
	std::vector<perm_string> covgrp_ctor_names_;
	std::vector<unsigned> covgrp_ctor_props_;
	std::vector<ivl_type_t> covgrp_ctor_types_;
	std::vector<PExpr*> covgrp_ctor_defaults_;
	std::vector<bool> covgrp_ctor_is_ref_;
      std::vector<covgrp_ctor_method_endpoint_t> covgrp_ctor_method_endpoints_;
	std::map<const PExpr*,covgrp_range_ref_t> covgrp_range_refs_;
	std::vector<covgrp_parent_const_dep_t> covgrp_parent_const_dependencies_;
	bool covgrp_range_bindings_complete_ = false;
	std::set<size_t> constructor_definitely_initialized_;
	bool constructor_initialization_audited_ = false;
	std::set<const Statement*>constructor_initializer_sites_;
	std::set<const Statement*>rejected_constructor_initializer_sites_;
	std::map<const Statement*,size_t>constructor_initializer_properties_;
      std::vector<covgrp_bin_t> covgrp_bins_;
      std::vector<covgrp_dyn_bin_t> covgrp_dyn_bins_;
      std::vector<covgrp_cross_t> covgrp_crosses_;
      std::vector<covgrp_cross_term_t> covgrp_cross_terms_;
      std::vector<covgrp_cross_bin_t> covgrp_cross_bins_;
      std::vector<covgrp_item_t> covgrp_items_;
      covgrp_options_t covgrp_options_;
      std::vector<int> covgrp_cp_parent_props_;
      std::vector<PExpr*> covgrp_cp_guards_;
      std::vector<PExpr*> covgrp_bin_guards_;
      std::vector<int> covgrp_cp_srcprops_;
      std::vector<int> covgrp_cp_guardsrcs_;
      std::vector<std::string> covgrp_cp_sample_irs_;
      int covgrp_parent_prop_ = -1;
      int covgrp_owner_prop_ = -1;
      bool is_covergroup_ = false;
      bool has_embedded_cgs_ = false;
      unsigned covgrp_ncoverpoints_ = 0;
};

inline NetScope*netclass_t::definition_scope(void)
{
      return definition_scope_;
}

extern netclass_t* builtin_class_type(perm_string name);
extern netenum_t* builtin_process_state_type(Design*des = nullptr);

#endif /* IVL_netclass_H */
