/*
 * Copyright (c) 2012-2024 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  <cstdarg>
# include  <algorithm>
# include  <cstring>
# include  <iostream>
# include  <list>
# include  <set>
# include  <vector>
# include  "pform.h"
# include  "PClass.h"
# include  "PExpr.h"
# include  "compiler.h"
# include  "PPackage.h"
# include  "parse_misc.h"
# include  "ivl_assert.h"
# include  "sv_edition.h"

using namespace std;

/*
 * The functions here help the parser put together class type declarations.
 */
static PClass*pform_cur_class = 0;
static perm_string pending_covergroup_extends_;
/* A class declaration is itself a legal class item (IEEE 1800-2017
 * 8.3). Keep the enclosing class while a nested declaration is parsed so
 * items following the nested class are attached to the right owner. */
static vector<PClass*> pform_enclosing_classes_;
/* Out-of-block method/constraint bodies temporarily re-enter a previously
 * declared class. Remember the exact lexical caller so leaving the class can
 * verify that the parser returned to the declaration site, rather than merely
 * to some ancestor that happened to contain the class name. */
static LexicalScope* pform_class_reentry_caller_ = 0;
static PTaskFunc* pform_recent_class_method_ = 0;

static PClass* pform_class_base_scope_(PClass*class_scope)
{
      if (!class_scope || !class_scope->type || !class_scope->type->base_type)
	    return nullptr;

      const typeref_t*base_ref = dynamic_cast<const typeref_t*>(
	    class_scope->type->base_type.get());
      if (!base_ref || !base_ref->typedef_ref())
	    return nullptr;

	// A package-qualified base names that package's class directly.
      if (PPackage*pkg = dynamic_cast<PPackage*>(base_ref->scope_ref())) {
	    map<perm_string,PClass*>::const_iterator found =
		  pkg->classes.find(base_ref->typedef_ref()->name);
	    if (found != pkg->classes.end())
		  return found->second;
      }

      return pform_find_visible_class_scope(
	    class_scope, base_ref->typedef_ref()->name);
}

void pform_class_covergroup_set_extends(const char*name)
{
      pending_covergroup_extends_ = name ? lex_strings.make(name) : perm_string();
}

static void pform_covergroup_remap_select_(
      class_type_t::pform_cross_t::select_t*select,
      const map<perm_string,perm_string>&labels)
{
      if (!select) return;
      if (select->op == class_type_t::pform_cross_t::select_t::SEL_BINSOF) {
	    auto found = labels.find(select->cp_name);
	    if (found != labels.end()) select->cp_name = found->second;
      }
      pform_covergroup_remap_select_(select->a, labels);
      pform_covergroup_remap_select_(select->b, labels);
}

static class_type_t::pform_cross_t::select_t*
pform_covergroup_clone_select_(
      const class_type_t::pform_cross_t::select_t*select)
{
      if (!select) return nullptr;
      auto*copy = new class_type_t::pform_cross_t::select_t(*select);
      copy->a = pform_covergroup_clone_select_(select->a);
      copy->b = pform_covergroup_clone_select_(select->b);
      return copy;
}

static PFunction* pform_class_constructor_(PClass*class_scope)
{
      if (!class_scope)
	    return nullptr;

      map<perm_string,PFunction*>::iterator found =
	    class_scope->funcs.find(perm_string::literal("new"));
      if (found == class_scope->funcs.end())
	    found = class_scope->funcs.find(perm_string::literal("new@"));
      return found == class_scope->funcs.end() ? nullptr : found->second;
}

static bool pform_class_default_uses_local_member_(PClass*class_scope,
							  const PExpr*expr)
{
      set<PClass*>seen;
      for (PClass*cur = class_scope ; cur && seen.insert(cur).second ;
	   cur = pform_class_base_scope_(cur)) {
	    if (!cur->type) continue;
	    for (const auto&property : cur->type->properties)
		  if (property.second.qual.test_local()
		      && expr->refs_name(property.first))
			return true;
      }

      return false;
}

std::vector<pform_tf_port_t>* pform_class_constructor_default_ports(
					const struct vlltype&loc, PFunction*constructor)
{
      vector<pform_tf_port_t>*ports = new vector<pform_tf_port_t>;
      if (!constructor || !pform_cur_class
	  || pform_cur_class->type->interface_class
	  || (constructor->pscope_name() != perm_string::literal("new")
	      && constructor->pscope_name() != perm_string::literal("new@"))) {
	    cerr << loc << ": error: The default constructor argument is only valid "
		 << "in a class constructor." << endl;
	    error_count += 1;
	    return ports;
      }

      if (constructor->has_constructor_default()) {
	    cerr << loc << ": error: The default constructor argument may appear "
		 << "only once." << endl;
	    error_count += 1;
	    return ports;
      }
      constructor->set_constructor_default(true);
      constructor->set_constructor_default_lexical_pos(loc.lexical_pos);

	  if (!pform_cur_class->type->base_default
	      && !sv_require_feature(constructor, SVF_CLASS_CONSTRUCTOR_DEFAULT))
	    error_count += 1;

      PClass*base_class = pform_class_base_scope_(pform_cur_class);
      if (!base_class) {
	    cerr << loc << ": error: The default constructor argument requires a "
		 << "base class." << endl;
	    error_count += 1;
	    return ports;
      }

      PFunction*base_constructor = pform_class_constructor_(base_class);
      const vector<pform_tf_port_t>*base_ports = base_constructor
	    ? base_constructor->peek_ports() : nullptr;
      if (!base_ports)
	    return ports;

      for (const pform_tf_port_t&base_port : *base_ports) {
	    PWire*wire = base_port.port;
	    if (!wire || wire->basename() == perm_string::literal(THIS_TOKEN))
		  continue;
	    if (base_port.defe && pform_class_default_uses_local_member_(
		      base_class, base_port.defe)) {
		  cerr << base_port.defe->get_fileline() << ": error: Default value of "
		       << "superclass constructor argument '" << wire->basename()
		       << "' refers to a local member." << endl;
		  error_count += 1;
	    }

	    perm_string name = wire->basename();
	    if (constructor->wires.count(name)
		|| constructor->local_symbols.count(name)) {
		  cerr << loc << ": error: Constructor default argument duplicates "
		       << "formal '" << name << "'." << endl;
		  error_count += 1;
		  continue;
	    }

	    // PWire descriptors are borrowed by scopes. Reusing the base formal
	    // preserves its direction, type, unpacked dimensions, and default.
	    constructor->wires[name] = wire;
	    constructor->local_symbols[name] = wire;
	    ports->push_back(base_port);
	    constructor->add_constructor_default_port(name);
      }

      return ports;
}

vector<named_pexpr_t> pform_class_constructor_default_args(
					PFunction*constructor)
{
      vector<named_pexpr_t> args;
      if (!constructor || !constructor->has_constructor_default()) {
	    if (constructor)
		  cerr << constructor->get_fileline();
	    cerr << ": error: super.new(default) requires the default "
		 << "argument in this constructor's formal list." << endl;
	    error_count += 1;
	    return args;
      }

      for (perm_string name : constructor->constructor_default_ports()) {
	  named_pexpr_t arg;
	  arg.name = name;
	  arg.parm = new PEIdent(name, constructor->constructor_default_lexical_pos());
	  arg.parm->reloc_lexical_pos_bind();
	  arg.parm->set_line(*constructor);
	    args.push_back(arg);
      }
      return args;
}

void pform_blend_class_constructors(PClass*pclass)
{
      perm_string new1 = perm_string::literal("new");
      perm_string new2 = perm_string::literal("new@");

      map<perm_string,PFunction*>::iterator iter_new = pclass->funcs.find(new1);
      PFunction*use_new = (iter_new == pclass->funcs.end()) ? 0 : iter_new->second;

      map<perm_string,PFunction*>::iterator iter_new2 = pclass->funcs.find(new2);
      PFunction*use_new2 = (iter_new2 == pclass->funcs.end()) ? 0 : iter_new2->second;

      if (pclass->type->base_default && use_new
	  && !use_new->has_constructor_default()) {
	    cerr << use_new->get_fileline()
		 << ": error: A constructor for an extends-default class must "
		 << "include the default argument."
		 << endl;
	    error_count += 1;
      }

      const bool explicit_body_ready = use_new && use_new->get_statement();

      if (use_new == 0 && use_new2 == 0)
            return;

      if (use_new && use_new2 && !explicit_body_ready)
            return;

      PChainConstructor*chain_new = 0;
      if (explicit_body_ready)
            chain_new = use_new->extract_chain_constructor();
      else if (use_new2 && use_new == 0)
            chain_new = use_new2->extract_chain_constructor();

      if (pclass->type->base_default && chain_new
          && !chain_new->is_synthesized()) {
	    cerr << pclass->get_fileline()
		 << ": error: A class with arguments in its extends specifier "
		 << "cannot call super.new()."
		 << endl;
	    error_count += 1;
	    delete chain_new;
	    chain_new = nullptr;
      }

      if (chain_new == 0 && pclass->type->base_type) {
	    PFunction*constructor = use_new ? use_new : use_new2;
	    if (constructor && constructor->has_constructor_default()) {
		  vector<named_pexpr_t> args =
				pform_class_constructor_default_args(constructor);
		  chain_new = new PChainConstructor(args);
	    } else {
		  chain_new = new PChainConstructor(pclass->type->base_args);
	    }
	    chain_new->set_synthesized();
	    chain_new->set_line(*pclass);
      }

      if (use_new && use_new2) {
            if (!use_new->method_of() && use_new2->method_of()) {
                  use_new->set_method_type_only(use_new2->method_of());
                  use_new->set_return(use_new2->method_of());
            }

            if (use_new->method_of() != use_new2->method_of()) {
                  cerr << use_new->get_fileline()
                       << ": warning: constructor merge saw mismatched method class metadata."
                       << endl;
            }

            Statement*def_new = use_new->get_statement();
            Statement*def_new2 = use_new2->get_statement();

            if (def_new == 0) {
                  def_new = new PBlock(PBlock::BL_SEQ);
                  use_new->set_statement(def_new);
            }

            if (def_new2)
                  use_new->push_statement_front(def_new2);

            pclass->funcs.erase(iter_new2);
            if (pform_recent_class_method_ == use_new2)
                  pform_recent_class_method_ = 0;
            delete use_new2;
            use_new2 = 0;
      }

      if (chain_new) {
            if (use_new2)
                  use_new2->push_statement_front(chain_new);
            else if (use_new)
                  use_new->push_statement_front(chain_new);
      }
}

/*
 * The base_type is set to the base class if this declaration is
 * starting a derived class. For example, for the syntax:
 *
 *    class foo extends bar (exprs) ...
 *
 * the base_type is the type of the class "bar", and the base_args,
 * if present, are passed to a chained constructor. The default form
 * inherits its superclass constructor ports.
 */
void pform_start_class_declaration(const struct vlltype&loc,
				   class_type_t*type,
				   data_type_t*base_type,
				   list<named_pexpr_t> *base_args,
				   bool virtual_class,
				   bool interface_class,
				   list<data_type_t*>*interface_types,
				   bool base_default)
{
      PClass*class_scope = pform_push_class_scope(loc, type->name);
      class_scope->type = type;
      pform_enclosing_classes_.push_back(pform_cur_class);
      pform_cur_class = class_scope;

      ivl_assert(loc, type->base_type == 0);
      type->base_type.reset(base_type);
      type->base_default = base_default;
      if (base_default
	  && !sv_require_feature(type, SVF_CLASS_CONSTRUCTOR_DEFAULT))
	    error_count += 1;
      type->virtual_class = virtual_class;
      type->interface_class = interface_class;

      if (interface_types) {
	    for (data_type_t*relation : *interface_types)
		  type->interface_types.emplace_back(relation);
	    delete interface_types;
      }


      ivl_assert(loc, type->base_args.empty());
      if (base_args) {
	    type->base_args.insert(type->base_args.begin(), base_args->begin(),
			           base_args->end());
	    delete base_args;
      }
}

void pform_class_property(const struct vlltype&loc,
			  property_qualifier_t property_qual,
			  data_type_t*data_type,
			  list<decl_assignment_t*>*decls)
{
      ivl_assert(loc, pform_cur_class);

	// Add the non-static properties to the class type
	// object. Unwind the list of names to make a map of name to
	// type.
      for (list<decl_assignment_t*>::iterator cur = decls->begin()
		 ; cur != decls->end() ; ++cur) {

	    decl_assignment_t*curp = *cur;
	    data_type_t*use_type = data_type;

	    if (! curp->index.empty()) {
		  list<pform_range_t>*pd = new list<pform_range_t> (curp->index);
		  use_type = new uarray_type_t(use_type, pd);
		  FILE_NAME(use_type, loc);
	    }

	    const bool has_decl_initializer = curp->expr.get() != nullptr;
	    pform_cur_class->type->properties[curp->name.first]
	      = class_type_t::prop_info_t(property_qual, use_type,
					 has_decl_initializer);
	    FILE_NAME(&pform_cur_class->type->properties[curp->name.first], loc);
            pform_cur_class->type->property_order.push_back(curp->name.first);

	    vector<Statement*>&initializers = property_qual.test_static()
		  ? pform_cur_class->type->initialize_static
		  : pform_cur_class->type->initialize;
	    if (!pform_validate_struct_member_defaults(loc, use_type, curp)) {
		  // The validation emitted the mandatory diagnostic.
	    } else if (property_qual.test_const() &&
		pform_has_implicit_struct_member_defaults(use_type, curp)) {
		  cerr << loc.get_fileline()
		       << ": sorry: unpacked-struct default member initializers "
			  "are not yet supported for const class property "
			  "declaration `" << curp->name.first
		       << "'; provide an explicit whole-variable initializer."
		       << endl;
		  error_count += 1;
	    } else {
		  pform_make_struct_member_defaults(loc, use_type, curp,
					      initializers);
	    }

	    if (PExpr*rval = curp->expr.release()) {
		  PExpr*lval = new PEIdent(curp->name.first, curp->name.second);
		  FILE_NAME(lval, loc);
		    // A class-property declaration assignment is a variable
		    // initializer, just like the declaration assignments built by
		    // pform_make_var_init().  Preserve that context through l-value
		    // elaboration.  In particular, a static const property may be
		    // written by this declaration initializer and nowhere else.
		  PAssign*tmp = new PAssign(lval, rval, false, true);
		  FILE_NAME(tmp, loc);

		  initializers.push_back(tmp);
	    }
      }
}

void pform_set_this_class(const struct vlltype&loc, PTaskFunc*net)
{
      unsigned specifiers = net->method_override_specifiers();
      if (specifiers) {
	    if (!sv_require_feature(net, SVF_METHOD_OVERRIDE_SPECIFIERS))
		  error_count += 1;
	    if (pform_cur_class == 0) {
		  cerr << loc << ": error: Method override specifiers are only "
		       << "legal on class methods "
		       << "(IEEE 1800-2023 8.20)." << endl;
		  error_count += 1;
	    }
	    if ((specifiers & METHOD_OVERRIDE_FINAL) && net->is_pure_method()) {
		  cerr << loc << ": error: The final specifier is illegal on a pure "
		       << "virtual method (IEEE 1800-2023 8.20)." << endl;
		  error_count += 1;
	    }
	    if (specifiers & METHOD_OVERRIDE_EXTENDS)
		  net->set_virtual_method(true);
      }

      if (pform_cur_class == 0)
	    return;

      if (net->is_pure_method() && !pform_cur_class->type->virtual_class) {
	    cerr << loc << ": error: A pure virtual method may only be declared "
		 << "in a virtual class." << endl;
	    error_count += 1;
      }

      list<pform_port_t>*this_name = new list<pform_port_t>;
      this_name->push_back(pform_port_t({ perm_string::literal(THIS_TOKEN), 0 }, 0, 0));
      vector<pform_tf_port_t>*this_port = pform_make_task_ports(loc,
						       NetNet::PINPUT,
						       pform_cur_class->type,
						       this_name);
	// The pform_make_task_ports() function deletes the this_name
	// object.

      ivl_assert(loc, this_port->at(0).defe == 0);
      PWire*this_wire = this_port->at(0).port;
      delete this_port;

      net->set_this(pform_cur_class->type, this_wire);
      pform_recent_class_method_ = net;
}

void pform_set_recent_class_method_qualifiers(property_qualifier_t qual)
{
      if (pform_recent_class_method_)
	    pform_recent_class_method_->set_method_qualifiers(qual);
}

void pform_mark_recent_class_method_virtual(void)
{
      if (pform_recent_class_method_)
	    pform_recent_class_method_->set_virtual_method(true);
      pform_recent_class_method_ = 0;
}

void pform_set_constructor_return(PFunction*net)
{
      ivl_assert(*net, pform_cur_class);
      net->set_return(pform_cur_class->type);
}

bool pform_reenter_class_scope(const struct vlltype&loc, const char*name)
{
      ivl_assert(loc, pform_cur_class == 0);
      ivl_assert(loc, pform_class_reentry_caller_ == 0);

      /* IEEE 1800-2017 8.24 requires an out-of-block method body to be
       * declared in the same scope as its class. Looking through parent
       * scopes is not only an illegal extension: pform_leave_class_scope()
       * would then restore the class's parent instead of the declaration's
       * caller (for example a module or generate scope), corrupting parser
       * state. */
      PScopeExtra*scopex = dynamic_cast<PScopeExtra*>(pform_peek_scope());
      if (scopex == 0)
	    return false;

      for (auto it = scopex->classes.begin(); it != scopex->classes.end(); ++it) {
	    if (std::strcmp(it->first, name) != 0)
		  continue;

	    pform_class_reentry_caller_ = pform_peek_scope();
	    pform_cur_class = it->second;
	    pform_push_existing_scope(it->second);
	    return true;
      }

      return false;
}

void pform_leave_class_scope(const struct vlltype&loc)
{
      /* Failed lookup never entered a class, so there is nothing to undo. */
      if (pform_class_reentry_caller_ == 0) {
	    ivl_assert(loc, pform_cur_class == 0);
	    return;
      }

      pform_cur_class = 0;
      pform_pop_scope();
      ivl_assert(loc, pform_peek_scope() == pform_class_reentry_caller_);
      pform_class_reentry_caller_ = 0;
}

/*
 * A constructor is basically a function with special implications.
 */
PFunction*pform_push_constructor_scope(const struct vlltype&loc)
{
      ivl_assert(loc, pform_cur_class);
      PFunction*func = pform_push_function_scope(loc, "new", LexicalScope::AUTOMATIC);
      return func;
}

void pform_end_class_declaration(const struct vlltype&loc)
{
      ivl_assert(loc, pform_cur_class);

	// If there were initializer statements, then collect them
	// into an implicit constructor function. Also make sure that an
	// explicit constructor exists if base class constructor arguments are
	// specified, so that the base class constructor will be called.
      if (!pform_cur_class->type->initialize.empty() ||
	  !pform_cur_class->type->base_args.empty() ||
	  pform_cur_class->type->base_default) {
	    PFunction*func = pform_push_function_scope(loc, "new@", LexicalScope::AUTOMATIC);
	    if (pform_cur_class->type->base_default) {
		  func->set_ports(pform_class_constructor_default_ports(loc, func));
	    } else {
		  func->set_ports(0);
	    }
	    pform_set_constructor_return(func);
	    pform_set_this_class(loc, func);

	    class_type_t*use_class = pform_cur_class->type;
	    if (use_class->initialize.size() == 1) {
		  func->set_statement(use_class->initialize.front());
	    } else {
		  PBlock*tmp = new PBlock(PBlock::BL_SEQ);
		  tmp->set_statement(use_class->initialize);
		  func->set_statement(tmp);
	    }
	    pform_pop_scope();
      }

      pform_blend_class_constructors(pform_cur_class);
      pform_recent_class_method_ = 0;

      pform_pop_scope();
      ivl_assert(loc, !pform_enclosing_classes_.empty());
      pform_cur_class = pform_enclosing_classes_.back();
      pform_enclosing_classes_.pop_back();
}

bool pform_in_class()
{
      return pform_cur_class != 0;
}

/*
 * Bind an out-of-class function body to its extern prototype declared
 * inside the class. When an extern method is parsed out-of-class
 * (e.g. "function void MyClass::foo(...)"), the body-bearing PFunction
 * is created but not linked to the class's funcs map. This function
 * replaces the bodyless prototype with the real implementation.
 */
void pform_bind_extern_func(PFunction*func)
{
      if (pform_cur_class == 0)
	    return;

      perm_string name = func->pscope_name();
      map<perm_string,PFunction*>::iterator it = pform_cur_class->funcs.find(name);
      if (it != pform_cur_class->funcs.end()) {
	    PFunction*proto = it->second;
	    if (!func->method_of() && proto->method_of())
		  func->set_method_type_only(proto->method_of());
	    if (!func->is_virtual_method() && proto->is_virtual_method())
		  func->set_virtual_method(true);
	    func->set_method_override_specifiers(
		  proto->method_override_specifiers());
	    func->set_method_qualifiers(proto->method_qualifiers());
	    it->second = func;
      } else {
	    pform_cur_class->funcs[name] = func;
      }

      if (name == perm_string::literal("new"))
            pform_blend_class_constructors(pform_cur_class);
}

/*
 * Same as above, for tasks.
 */
void pform_bind_extern_task(PTask*task)
{
      if (pform_cur_class == 0)
	    return;

      perm_string name = task->pscope_name();
      map<perm_string,PTask*>::iterator it = pform_cur_class->tasks.find(name);
      if (it != pform_cur_class->tasks.end()) {
	    PTask*proto = it->second;
	    if (!task->method_of() && proto->method_of())
		  task->set_method_type_only(proto->method_of());
	    if (!task->is_virtual_method() && proto->is_virtual_method())
		  task->set_virtual_method(true);
	    task->set_method_override_specifiers(
		  proto->method_override_specifiers());
	    task->set_method_qualifiers(proto->method_qualifiers());
	    it->second = task;
      } else {
	    pform_cur_class->tasks[name] = task;
      }
}

static void pform_check_constraint_override_specifiers_(
	      const LineInfo*loc, bool is_static, bool is_pure, unsigned specifiers)
{
      if (!specifiers)
	    return;
      if (!sv_require_feature(loc, SVF_CONSTRAINT_OVERRIDE_SPECIFIERS))
	    error_count += 1;
      if (is_static) {
	    cerr << loc->get_fileline()
		 << ": error: Constraint override specifiers are illegal on static "
		    "constraints (IEEE 1800-2023 18.5.10)." << endl;
	    error_count += 1;
      }
      if (is_pure
	  && (specifiers & class_type_t::CONSTRAINT_OVERRIDE_FINAL)) {
	    cerr << loc->get_fileline()
		 << ": error: The final specifier is illegal on a pure constraint "
		    "(IEEE 1800-2023 18.5.2)." << endl;
	    error_count += 1;
      }
}

void pform_class_constraint(const struct vlltype&loc,
			     bool is_static, unsigned override_specifiers,
			     const char*name, std::list<PExpr*>*items)
{
      if (!pform_cur_class || !name)
	    return;

      perm_string pname = lex_strings.make(name);
	  class_type_t*type = pform_cur_class->type;
	  bool had_decl = type->constraint_declarations.count(pname) != 0;
      class_type_t::constraint_decl_info_t&decl =
	    type->constraint_declarations[pname];
      FILE_NAME(&decl, loc);
	  pform_check_constraint_override_specifiers_(&decl, is_static, false,
					      override_specifiers);
	  if (had_decl && decl.is_prototype) {
	    if (decl.is_static != is_static) {
		  cerr << loc << ": error: Out-of-body definition of constraint `"
		       << pname << "' does not match the prototype's static "
			  "qualifier." << endl;
		  error_count += 1;
	    }
	    if (decl.override_specifiers != override_specifiers) {
		  cerr << loc << ": error: Out-of-body definition of constraint `"
		       << pname << "' does not match the prototype's override "
			  "specifiers (IEEE 1800-2023 18.5.2)." << endl;
		  error_count += 1;
	    }
	    decl.is_prototype = false;
	  }
      decl.is_static = is_static;
	  decl.override_specifiers = override_specifiers;
      auto pure = type->pure_constraints.find(pname);
      if (pure != type->pure_constraints.end()) {
	    cerr << loc << ": error: Constraint `" << pname
		 << "' is already declared pure in this class." << endl;
	    error_count += 1;
      }
	  auto proto = type->extern_constraints.find(pname);
	  if (proto == type->extern_constraints.end()
	      && type->constraints.count(pname) == 0)
	    type->constraint_order.push_back(pname);
	  if (proto != type->extern_constraints.end()) {
	    if (proto->second.is_static != is_static) {
		  cerr << loc << ": error: Out-of-body definition of constraint `"
		       << pname << "' does not match the prototype's static "
			  "qualifier." << endl;
		  error_count += 1;
	    }
	    if (proto->second.override_specifiers != override_specifiers) {
		  cerr << loc << ": error: Out-of-body definition of constraint `"
		       << pname << "' does not match the prototype's override "
			  "specifiers (IEEE 1800-2023 18.5.2)." << endl;
		  error_count += 1;
	    }
	    type->extern_constraints.erase(proto);
      }
	  vector<PExpr*>& slot = type->constraints[pname];
      if (items) {
	    slot.assign(items->begin(), items->end());
	    delete items;
      }
}

void pform_class_constraint_prototype(const struct vlltype&loc,
				      bool is_static,
				      unsigned override_specifiers,
				      const char*name, bool is_extern)
{
      if (!pform_cur_class || !name)
	    return;

      perm_string pname = lex_strings.make(name);
      class_type_t*type = pform_cur_class->type;
      if (type->constraints.find(pname) != type->constraints.end()
	  || type->pure_constraints.find(pname) != type->pure_constraints.end()
	  || type->extern_constraints.find(pname)
	       != type->extern_constraints.end()) {
	    cerr << loc << ": error: Constraint `" << pname
		 << "' is already declared in this class." << endl;
	    error_count += 1;
	    return;
      }
      type->constraint_order.push_back(pname);
      if (!is_extern) {
            // An implicit prototype may remain empty (IEEE 1800-2017/2023
            // 18.5.1). It is a declaration, never a definition that consumes
            // an existing extern prototype or changes its required-body check.
            type->constraints[pname];
            class_type_t::constraint_decl_info_t&decl = type->constraint_declarations[pname];
            FILE_NAME(&decl, loc);
		  pform_check_constraint_override_specifiers_(&decl, is_static,
						      false, override_specifiers);
            decl.is_static = is_static;
		  decl.is_prototype = true;
		  decl.override_specifiers = override_specifiers;
            return;
      }
      class_type_t::extern_constraint_info_t&info =
	type->extern_constraints[pname];
      FILE_NAME(&info, loc);
	  pform_check_constraint_override_specifiers_(&info, is_static, false,
					      override_specifiers);
      info.is_static = is_static;
	  info.override_specifiers = override_specifiers;
      info.reported = false;
}

void pform_class_pure_constraint(const struct vlltype&loc,
				  unsigned override_specifiers, const char*name)
{
      if (!pform_cur_class || !name)
	    return;

      perm_string pname = lex_strings.make(name);
      class_type_t*type = pform_cur_class->type;
      if (!type->virtual_class) {
	    cerr << loc << ": error: A pure constraint may only be declared "
		 << "in a virtual class." << endl;
	    error_count += 1;
      }
      if (type->constraints.find(pname) != type->constraints.end()
	  || type->pure_constraints.find(pname) != type->pure_constraints.end()
	  || type->extern_constraints.find(pname)
	       != type->extern_constraints.end()) {
	    cerr << loc << ": error: Constraint `" << pname
		 << "' is already declared in this class." << endl;
	    error_count += 1;
	    return;
      }

      class_type_t::pure_constraint_info_t&info =
	type->pure_constraints[pname];
      FILE_NAME(&info, loc);
	  pform_check_constraint_override_specifiers_(&info, false, true,
					      override_specifiers);
	  info.override_specifiers = override_specifiers;
}

// I1 (Phase 62g): forward-declared accumulator from parse.y.
extern std::vector<class_type_t::pform_cross_t> pending_crosses_;
extern std::map<perm_string, PExpr*> pending_cg_options_;

/* IEEE 1800-2017 19.6. A cross item may name either an explicitly declared
 * coverpoint or an integral variable. In the latter case the language creates
 * an implicit coverpoint equivalent to `coverpoint variable'. Do this after
 * the complete covergroup body has been parsed so a cross can precede the
 * explicit coverpoint that it names. */
static void pform_covergroup_implicit_cross_coverpoints_(
      const struct vlltype&loc, class_type_t::pform_covergroup_t*cg)
{
      if (!cg) return;

      for (auto&cross : cg->crosses) {
	    for (size_t item_idx = 0; item_idx < cross.cp_labels.size();
		 item_idx += 1) {
		  perm_string item = cross.cp_labels[item_idx];
		  bool declared = false;
		  for (const auto&cp : cg->coverpoints) {
			if (cp.label == item) {
			      declared = true;
			      break;
			}
		  }
		  if (declared) continue;

		  class_type_t::pform_coverpoint_t cp;
		  cp.label = item;
		  cp.decl_class = cross.decl_class;
		  cp.declared_by_extension = cross.declared_by_extension;
		  if (item_idx < cross.cp_exprs.size()
		      && cross.cp_exprs[item_idx]) {
			cp.expr = cross.cp_exprs[item_idx];
			cross.cp_exprs[item_idx] = nullptr;
		  } else {
			cp.expr = new PEIdent(item, loc.lexical_pos);
			FILE_NAME(cp.expr, loc);
		  }
		  cg->coverpoints.push_back(std::move(cp));
	    }
      }
}

void pform_class_covergroup(const struct vlltype&loc,
			     const char*name,
			     std::list<class_type_t::pform_coverpoint_t*>*coverpoints,
			     std::vector<perm_string>*sample_formals,
			     std::vector<PWire*>*sample_formal_types,
			     std::vector<PEEvent*>*sample_events,
			     std::vector<perm_string>*ctor_formals,
			     std::vector<data_type_t*>*ctor_formal_types,
			     std::vector<bool>*ctor_formal_is_ref,
			     std::vector<PExpr*>*ctor_defaults,
			     std::vector<PExpr*>*sample_formal_defaults)
{
	  perm_string extends_name = pending_covergroup_extends_;
	  pending_covergroup_extends_ = perm_string();
      if (!pform_cur_class || !name) {
	    pending_crosses_.clear();  // discard if we can't attach
	    pending_cg_options_.clear();
	    if (sample_formals) delete sample_formals;
	    if (sample_formal_types) delete sample_formal_types;
	    if (sample_formal_defaults) delete sample_formal_defaults;
	    if (sample_events) delete sample_events;
	    if (ctor_formals) delete ctor_formals;
	    if (ctor_formal_types) delete ctor_formal_types;
	    if (ctor_formal_is_ref) delete ctor_formal_is_ref;
	    if (ctor_defaults) delete ctor_defaults;
	    return;
      }

      class_type_t::pform_covergroup_t* cg = new class_type_t::pform_covergroup_t();
      cg->name = lex_strings.make(name);
	// Constructor formals retain their declaration types/defaults so
	// the synthesized covergroup class can store per-instance values.
      if (ctor_formals) {
	    cg->ctor_formals = *ctor_formals;
	    delete ctor_formals;
      }
      if (ctor_formal_types) {
	    cg->ctor_formal_types = *ctor_formal_types;
	    delete ctor_formal_types;
      }
      if (ctor_formal_is_ref) {
	    cg->ctor_formal_is_ref = *ctor_formal_is_ref;
	    delete ctor_formal_is_ref;
      }
      if (ctor_defaults) {
	    cg->ctor_defaults = *ctor_defaults;
	    delete ctor_defaults;
      }
      if (coverpoints) {
	    for (auto* cp : *coverpoints)
		  cg->coverpoints.push_back(std::move(*cp));
	    delete coverpoints;
      }
      // I1: move accumulated cross declarations onto the covergroup.
      cg->crosses = std::move(pending_crosses_);
      pending_crosses_.clear();
      // M11: move accumulated covergroup-level options.
      cg->options = std::move(pending_cg_options_);
      pending_cg_options_.clear();
      // M11-4: `with function sample(<formals>)` names.
      if (sample_formals) {
	    cg->sample_formals = *sample_formals;
	    delete sample_formals;
      }
      if (sample_formal_types) {
	    cg->sample_formal_types = *sample_formal_types;
	    delete sample_formal_types;
      }
      if (sample_formal_defaults) {
	    cg->sample_formal_defaults = *sample_formal_defaults;
	    delete sample_formal_defaults;
      }
	// M11-3: declaration sampling event on a class-embedded
	// covergroup.
      if (sample_events) {
	    cg->sample_events = *sample_events;
	    delete sample_events;
      }

	// Preserve the lexical class scope as covergroup components are copied
	// into further derived covergroups.
      for (auto&item : cg->coverpoints) {
	    item.decl_class = pform_cur_class;
	    for (auto&bin : item.bins)
		  bin.decl_class = pform_cur_class;
      }
      for (auto&item : cg->crosses)
	    item.decl_class = pform_cur_class;

	// IEEE 1800-2023 19.4.1: an embedded extension replaces the
	// same-named base property, retaining its sampling interface and
	// merging coverage components by their declared names.
      if (!extends_name.nil()) {
	    class_type_t::pform_covergroup_t* base_cg = nullptr;
	    for (PClass*base = pform_class_base_scope_(pform_cur_class);
		 base && !base_cg; base = pform_class_base_scope_(base)) {
		  if (!base->type) continue;
		  for (auto*item : base->type->covergroups)
			if (item && item->name == extends_name) {
			      base_cg = item;
			      break;
			}
	    }
	    if (!base_cg) {
		  string message = "error: covergroup '" + string(extends_name.str())
			+ "' is not declared in a base class (IEEE 1800-2023 19.4.1).";
		  VLerror(loc, "%s", message.c_str());
		  delete cg;
		  return;
	    }
	    if (!cg->sample_events.empty() || !cg->sample_formals.empty()) {
		  VLerror(loc, "error: an embedded covergroup extension inherits its base sampling event and sample arguments (IEEE 1800-2023 19.4.1).");
		  delete cg;
		  return;
	    }

	    vector<class_type_t::pform_coverpoint_t> added_coverpoints =
		  std::move(cg->coverpoints);
	    vector<class_type_t::pform_cross_t> added_crosses =
		  std::move(cg->crosses);
	    map<perm_string,PExpr*> added_options = std::move(cg->options);
	    *cg = *base_cg;
	    cg->is_extension = true;
	    for (auto&item : cg->coverpoints) {
		  item.declared_by_extension = false;
		  for (auto&bin : item.bins) bin.declared_by_extension = false;
	    }
	    for (auto&item : cg->crosses)
		  item.declared_by_extension = false;
	    map<perm_string,perm_string> inherited_cross_labels;
	    for (auto&item : added_coverpoints) {
		  item.declared_by_extension = true;
		  for (auto&bin : item.bins) bin.declared_by_extension = true;
		  auto found = find_if(cg->coverpoints.begin(), cg->coverpoints.end(),
				       [&](const class_type_t::pform_coverpoint_t&base) {
					     return !item.label.nil()
						&& base.label == item.label;
				       });
		  if (found == cg->coverpoints.end())
			cg->coverpoints.push_back(std::move(item));
		  else {
			class_type_t::pform_coverpoint_t base_only = *found;
			string alias = "$ivl_inherited_"
			      + string(extends_name.str()) + "_"
			      + std::to_string(found - cg->coverpoints.begin());
			base_only.label = lex_strings.make(alias.c_str());
			base_only.inherited_cross_only = true;
			inherited_cross_labels[item.label] = base_only.label;
			*found = std::move(base_only);
			cg->coverpoints.push_back(std::move(item));
		  }
	    }
	    for (auto&cross : cg->crosses) {
		  for (auto&label : cross.cp_labels) {
			    auto found = inherited_cross_labels.find(label);
			    if (found != inherited_cross_labels.end())
				  label = found->second;
		  }
		  if (!inherited_cross_labels.empty())
			for (auto&bin : cross.bins) {
			      // Extension label remapping must not mutate the base definition.
			      bin.select = pform_covergroup_clone_select_(bin.select);
			      pform_covergroup_remap_select_(bin.select,
						inherited_cross_labels);
			}
	    }
	    for (auto&item : added_crosses) {
		  item.declared_by_extension = true;
		  auto found = find_if(cg->crosses.begin(), cg->crosses.end(),
				       [&](const class_type_t::pform_cross_t&base) {
					     return !item.label.nil()
						&& base.label == item.label;
				       });
		  if (found == cg->crosses.end())
			cg->crosses.push_back(std::move(item));
		  else
			*found = std::move(item);
	    }
	    for (const auto&item : added_options)
		  cg->options[item.first] = item.second;
      }
      // Resolve implicit cross items after inheritance is merged so names
      // from a base covergroup remain references to its components.
      pform_covergroup_implicit_cross_coverpoints_(loc, cg);
      for (auto&cross : cg->crosses) {
	    if (!cross.value_type || !cross.value_type->members) continue;
	    auto member = cross.value_type->members->begin();
	    for (perm_string label : cross.cp_labels) {
		  auto cp = std::find_if(cg->coverpoints.begin(),
					 cg->coverpoints.end(),
					 [&](const class_type_t::pform_coverpoint_t&item) {
					       return item.label == label;
					 });
		  if (member == cross.value_type->members->end()) break;
		  if (cp != cg->coverpoints.end())
			if (PEIdent*id = dynamic_cast<PEIdent*>(cp->expr)) {
			      (*member)->type.reset(new type_reference_t(
				    id->clone_for_reference()));
			      FILE_NAME((*member)->type.get(), loc);
			}
		  ++member;
	    }
      }
      pform_cur_class->type->covergroups.push_back(cg);
}

void pform_standalone_covergroup(const struct vlltype&loc,
			     const char*name,
			     std::list<class_type_t::pform_coverpoint_t*>*coverpoints,
			     std::vector<PEEvent*>*sample_events,
			     std::vector<perm_string>*sample_formals,
			     std::vector<PWire*>*sample_formal_types,
			     std::vector<perm_string>*ctor_formals,
			     std::vector<data_type_t*>*ctor_formal_types,
			     std::vector<bool>*ctor_formal_is_ref,
			     std::vector<PExpr*>*ctor_defaults,
			     std::vector<PExpr*>*sample_formal_defaults)
{
      if (!name) {
	    pending_crosses_.clear();
	    pending_cg_options_.clear();
	    if (sample_formals) delete sample_formals;
	    if (sample_formal_types) delete sample_formal_types;
	    if (sample_formal_defaults) delete sample_formal_defaults;
	    if (ctor_formals) delete ctor_formals;
	    if (ctor_formal_types) delete ctor_formal_types;
	    if (ctor_formal_is_ref) delete ctor_formal_is_ref;
	    if (ctor_defaults) delete ctor_defaults;
	    return;
      }
      perm_string cg_name = lex_strings.make(name);
      PClass*cls = pform_push_class_scope(loc, cg_name);
      class_type_t*ct = new class_type_t(cg_name);
      FILE_NAME(ct, loc);
      ct->is_covergroup_standalone = true;
      cls->type = ct;
      pform_set_typedef(loc, cg_name, ct, nullptr);
	// The regular class-covergroup registration attaches the
	// covergroup (and any pending crosses/options) via
	// pform_cur_class, which only class_declaration normally
	// manages — point it at the wrapper for the call.
      PClass*save_cur = pform_cur_class;
      pform_cur_class = cls;
      pform_class_covergroup(loc, name, coverpoints, nullptr, nullptr,
			     nullptr, ctor_formals, ctor_formal_types,
			     ctor_formal_is_ref,
			     ctor_defaults, nullptr);
      pform_cur_class = save_cur;
      if (sample_events && !ct->covergroups.empty()) {
	    ct->covergroups.back()->sample_events = *sample_events;
	    delete sample_events;
      } else if (sample_events) {
	    delete sample_events;
      }
      if (sample_formals && !ct->covergroups.empty()) {
	    ct->covergroups.back()->sample_formals = *sample_formals;
	    delete sample_formals;
      } else if (sample_formals) {
	    delete sample_formals;
      }
      if (sample_formal_types && !ct->covergroups.empty()) {
	    ct->covergroups.back()->sample_formal_types = *sample_formal_types;
	    delete sample_formal_types;
      } else if (sample_formal_types) {
	    delete sample_formal_types;
      }
      if (sample_formal_defaults && !ct->covergroups.empty()) {
	    ct->covergroups.back()->sample_formal_defaults =
		  *sample_formal_defaults;
	    delete sample_formal_defaults;
      } else if (sample_formal_defaults) {
	    delete sample_formal_defaults;
      }
      pform_pop_scope();
}
