/*
 * Copyright (c) 2000-2026 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include "config.h"

# include  <iostream>
# include  <set>
# include  <cstdlib>
# include  <cstring>
# include  <string>
# include  <functional>
# include  <memory>

/*
 * This source file contains all the implementations of the Design
 * class declared in netlist.h.
 */

# include  "netlist.h"
# include  "netscalar.h"
# include  "netclass.h"
# include  "netenum.h"
# include  "netstruct.h"
# include  "netvector.h"
# include  "util.h"
# include  "compiler.h"
# include  "netmisc.h"
# include  "netparray.h"
# include  "netqueue.h"
# include  "PExpr.h"
# include  "PClass.h"
# include  "PPackage.h"
# include  "PTask.h"
# include  "PWire.h"
# include  "parse_misc.h"
# include  "pform_types.h"
# include  <sstream>
# include  "ivl_assert.h"

using namespace std;

static void trace_const_function_materialization_(const LineInfo&loc, NetScope*caller,
					       NetScope*callee, const char*reason)
{
      const char*trace = getenv("IVL_CONST_TRACE");
      if (!trace || !*trace || !callee)
	    return;

      ostringstream callee_buf;
      callee_buf << scope_path(callee);
      string callee_path = callee_buf.str();
      string caller_path = "<none>";
      if (caller) {
	    ostringstream caller_buf;
	    caller_buf << scope_path(caller);
	    caller_path = caller_buf.str();
      }
      if (strcmp(trace, "1") != 0 && strcmp(trace, "all") != 0) {
	    if (callee_path.find(trace) == string::npos &&
		caller_path.find(trace) == string::npos)
		  return;
      }

      cerr << loc.get_fileline() << ": const-trace: " << reason
	   << " caller=" << caller_path
	   << " callee=" << callee_path << endl;
}

static const netclass_t* resolve_current_class_typedef_alias_(NetScope*scope,
					      const typedef_t*td)
{
      if (!scope || !td)
	    return 0;

      const NetScope*class_scope = scope->get_class_scope();
      const netclass_t*current_class = class_scope ? class_scope->class_def() : 0;
      if (!current_class)
	    return 0;

      const data_type_t*alias_type = td->get_data_type();
      if (!alias_type)
	    return 0;

      if (const class_type_t*class_ref =
		  dynamic_cast<const class_type_t*>(alias_type)) {
	    if (class_ref->name == current_class->get_name())
		  return current_class;
      }

      if (const typeref_t*type_ref =
		  dynamic_cast<const typeref_t*>(alias_type)) {
	    if (typedef_t*base_td = type_ref->typedef_ref()) {
		  if (base_td->name == current_class->get_name())
			return current_class;
	    }
      }

      return 0;
}

static NetFuncDef* elaborate_missing_package_function_scope_(Design*des,
						       NetScope*scope,
						       const pform_name_t&name)
{
      if (!scope || name.size() != 1)
	    return 0;

      perm_string fname = peek_tail_name(name);
      for (NetScope*cur = scope ; cur ; cur = cur->parent()) {
	    if (cur->type() != NetScope::PACKAGE)
		  continue;

	    if (NetScope*existing = cur->child(hname_t(fname))) {
			if (existing->type() == NetScope::FUNC) {
				if (existing->elab_stage() < 2) {
				      if (scope->need_const_func())
					    if (const PFunction*pfunc = existing->func_pform())
						  trace_const_function_materialization_(*pfunc, scope, existing,
										      "reusing lazy package function in const context");
				      if (scope->need_const_func())
					    existing->need_const_func(true);
				      if (const PFunction*pfunc = existing->func_pform())
					    pfunc->elaborate_sig(des, existing);
				}
			return existing->func_def();
		  }
		  continue;
	    }

	    PPackage*pkg = pform_test_package_identifier(cur->basename());
	    if (!pkg)
		  continue;

	    map<perm_string,PFunction*>::const_iterator it = pkg->funcs.find(fname);
	    if (it == pkg->funcs.end())
		  continue;

	    NetScope*func_scope = new NetScope(cur, hname_t(fname), NetScope::FUNC);
		      /* Carry the declared lifetime onto the materialized
		         scope (as the task variant below does). Without
		         this, an automatic package function materialized
		         on demand elaborates as static: its nested-block
		         variable initializers are emitted as a vacuous
		         one-shot $init process against a frame that never
		         exists, instead of inline per-call statements. */
		    func_scope->is_auto(it->second->is_auto());
		    func_scope->set_line(it->second);
		    func_scope->add_imports(&it->second->explicit_imports);
		    it->second->elaborate_scope(des, func_scope);
		    if (scope->need_const_func())
			  trace_const_function_materialization_(*it->second, scope, func_scope,
							      "materializing package function in const context"),
			  func_scope->need_const_func(true);
		    it->second->elaborate_sig(des, func_scope);
		    return func_scope->func_def();
	      }

      return 0;
}

static NetScope* elaborate_missing_package_task_scope_(Design*des,
						      NetScope*scope,
						      const pform_name_t&name)
{
      if (!scope || name.size() != 1)
	    return 0;

      perm_string tname = peek_tail_name(name);
      for (NetScope*cur = scope ; cur ; cur = cur->parent()) {
	    if (cur->type() != NetScope::PACKAGE)
		  continue;

	    if (NetScope*existing = cur->child(hname_t(tname))) {
		  if (existing->type() == NetScope::TASK) {
			if (existing->task_def() == 0) {
			      if (const PTask*ptask = existing->task_pform())
				    ptask->elaborate_sig(des, existing);
			}
			return existing;
		  }
		  continue;
	    }

	    PPackage*pkg = pform_test_package_identifier(cur->basename());
	    if (!pkg)
		  continue;

	    map<perm_string,PTask*>::const_iterator it = pkg->tasks.find(tname);
	    if (it == pkg->tasks.end())
		  continue;

	    NetScope*task_scope = new NetScope(cur, hname_t(tname), NetScope::TASK);
	    task_scope->is_auto(it->second->is_auto());
	    task_scope->set_line(it->second);
	    task_scope->add_imports(&it->second->explicit_imports);
	    it->second->elaborate_scope(des, task_scope);
	    it->second->elaborate_sig(des, task_scope);
	    return task_scope;
      }

      return 0;
}

Design:: Design()
    : errors(0), nodes_(0), procs_(0), aprocs_(0)
{
      branches_ = 0;
      procs_idx_ = 0;
      des_precision_ = 0;
      nodes_functor_cur_ = 0;
      nodes_functor_nxt_ = 0;
      des_delay_sel_ = Design::TYP;
      package_subroutine_bodies_ready_ = false;
}

Design::~Design()
{
}

bool Design::package_subroutine_bodies_ready() const
{
      return package_subroutine_bodies_ready_;
}

void Design::set_package_subroutine_bodies_ready(bool ready)
{
      package_subroutine_bodies_ready_ = ready;
}

void Design::release_elaboration_caches()
{
      for (map<perm_string,NetScope*>::iterator cur = packages_.begin()
		 ; cur != packages_.end() ; ++cur)
	    cur->second->release_elaboration_caches();

      for (list<NetScope*>::iterator cur = root_scopes_.begin()
		 ; cur != root_scopes_.end() ; ++cur)
	    (*cur)->release_elaboration_caches();

      nettype_scopes_.clear();
      interconnect_nets_.clear();
      struct_member_default_validations_.clear();
      constraint_randc_diagnostic_sites_.clear();
      randc_cycle_cap_warning_sites_.clear();
      constraint_order_diagnostic_sites_.clear();
}

void Design::register_nettype_scope(const nettype_t*type, NetScope*scope)
{
      if (!type || !scope)
            return;
      /* NetScope::add_nettypes registers a descriptor only when inserting its
       * local record, so duplicates cannot arrive here.  Append directly:
       * scanning all prior instances would make a heavily instantiated
       * parameterized module quadratic merely to build this provenance
       * index. */
      nettype_scopes_[type].push_back(scope);
}

NetScope* Design::find_nettype_scope(const nettype_t*type,
                                     const NetScope*context) const
{
      /* Module/class declarations are instantiated, so the same pform
       * descriptor legitimately belongs to several NetScopes. Prefer the
       * exact current instance chain; only use the global index when the
       * descriptor has a unique elaborated owner (packages and compilation
       * units are the usual cross-scope alias targets). */
      for (const NetScope*cur = context; cur; cur = cur->parent())
            if (cur->find_local_nettype(type))
                  return const_cast<NetScope*>(cur);

      map<const nettype_t*,vector<NetScope*> >::const_iterator cur =
            nettype_scopes_.find(type);
      if (cur == nettype_scopes_.end() || cur->second.size() != 1)
            return 0;
      return cur->second.front();
}

void Design::register_interconnect(NetNet*net)
{
      if (!net)
            return;
      interconnect_nets_.push_back(net);
}

void Design::finalize_interconnects()
{
      struct component_use_t {
            NetNet*representative = 0;
            NetNet*referenced = 0;
            bool reference_diagnosed = false;
      };
      map<const NetInterconnectType*,component_use_t>components;

      for (vector<NetNet*>::const_iterator cur = interconnect_nets_.begin();
           cur != interconnect_nets_.end(); ++cur) {
            NetNet*net = *cur;
            if (!net || !net->is_interconnect())
                  continue;
            const NetInterconnectType*key = net->interconnect_component();
            component_use_t&use = components[key];
            if (!use.representative)
                  use.representative = net;
            if (!use.referenced && net->interconnect_value_referenced())
                  use.referenced = net;
            use.reference_diagnosed = use.reference_diagnosed
                  || net->interconnect_reference_diagnosed();
      }

      for (map<const NetInterconnectType*,component_use_t>::const_iterator cur =
                 components.begin(); cur != components.end(); ++cur) {
            const NetInterconnectType*component = cur->first;
            const component_use_t&use = cur->second;
            if (use.referenced && !use.reference_diagnosed) {
                  cerr << use.referenced->get_fileline() << ": error: "
                       << "Interconnect net `" << use.referenced->name() << "'"
                       << " may only be referenced in a net port connection."
                       << endl;
                  errors += 1;
            }
            /* A concrete illegal value reference already explains why this
             * component cannot be lowered. Do not add a secondary unresolved
             * type diagnostic for the same component. */
            if (!use.referenced && !use.reference_diagnosed
                && !component->resolved()
                && !component->invalid()) {
                  cerr << use.representative->get_fileline() << ": error: "
                       << "interconnect net '" << use.representative->name()
                       << "' has no concrete net type after port propagation."
                       << endl;
                  errors += 1;
            }
      }
}

void Design::record_struct_member_default_validation(const PExpr*expr,
						      const NetScope*scope,
						      bool valid)
{
      if (!expr || !scope)
	    return;

      struct_member_default_validations_[make_pair(expr, scope)] = valid;
}

bool Design::get_struct_member_default_validation(const PExpr*expr,
						   const NetScope*scope,
						   bool&valid) const
{
      map<pair<const PExpr*,const NetScope*>,bool>::const_iterator cur =
	    struct_member_default_validations_.find(make_pair(expr, scope));
      if (cur == struct_member_default_validations_.end())
	    return false;

      valid = cur->second;
      return true;
}

bool Design::mark_constraint_randc_diagnostic(const PExpr*expr)
{
      return expr && constraint_randc_diagnostic_sites_.insert(expr).second;
}

bool Design::mark_randc_cycle_cap_warning(
      const class_type_t::prop_info_t*prop, long width)
{
      return prop && randc_cycle_cap_warning_sites_[prop].insert(width).second;
}

bool Design::mark_constraint_order_diagnostic(const PExpr*expr)
{
      return expr && constraint_order_diagnostic_sites_.insert(expr).second;
}

bool Design::mark_constraint_dist_diagnostic(const PExpr*expr)
{
      return expr
	    && constraint_dist_diagnostic_sites_.insert(expr).second;
}

void Design::set_precision(int val)
{
      if (val < des_precision_)
	    des_precision_ = val;
}

int Design::get_precision() const
{
      return des_precision_;
}

void Design::set_delay_sel(delay_sel_t sel)
{
      des_delay_sel_ = sel;
}

const char* Design::get_delay_sel() const
{
      switch (des_delay_sel_) {
	case Design::MIN:
	    return "MINIMUM";
	    break;
	case Design::TYP:
	    return "TYPICAL";
	    break;
	case Design::MAX:
	    return "MAXIMUM";
	    break;
	default:
	    assert(0);
	    return "TYPICAL";
      }
}


uint64_t Design::scale_to_precision(uint64_t val,
				    const NetScope*scope) const
{
      int units = scope->time_unit();
      assert( units >= des_precision_ );

      while (units > des_precision_) {
	    units -= 1;
	    val *= 10;
      }

      return val;
}

NetScope* Design::make_root_scope(perm_string root, NetScope*unit_scope,
				  bool program_block, bool is_interface)
{
      NetScope *root_scope_;
      root_scope_ = new NetScope(0, hname_t(root), NetScope::MODULE, unit_scope,
				 false, program_block, is_interface);
	/* This relies on the fact that the basename return value is
	   permallocated. */
      root_scope_->set_module_name(root_scope_->basename());
      root_scopes_.push_back(root_scope_);
      return root_scope_;
}

NetScope* Design::find_root_scope()
{
      assert(root_scopes_.front());
      return root_scopes_.front();
}

list<NetScope*>&Design::find_root_scopes() const
{
      return const_cast<list<NetScope*>&>(root_scopes_);
}

NetScope* Design::make_package_scope(perm_string name, NetScope*unit_scope,
				     bool is_unit)
{
      NetScope*scope;

      scope = new NetScope(0, hname_t(name), NetScope::PACKAGE, unit_scope,
			   false, false, false, is_unit);
      scope->set_module_name(scope->basename());
      packages_[name] = scope;
      return scope;
}

NetScope* Design::find_package(perm_string name) const
{
      map<perm_string,NetScope*>::const_iterator cur = packages_.find(name);
      if (cur == packages_.end())
	    return 0;

      return cur->second;
}

list<NetScope*> Design::find_package_scopes() const
{
      list<NetScope*>res;
      for (map<perm_string,NetScope*>::const_iterator cur = packages_.begin()
		 ; cur != packages_.end() ; ++cur) {
	    res.push_back (cur->second);
      }

      return res;
}

/*
 * This method locates a scope in the design, given its rooted
 * hierarchical name. Each component of the key is used to scan one
 * more step down the tree until the name runs out or the search
 * fails.
 */
NetScope* Design::find_scope(const std::list<hname_t>&path) const
{
      if (path.empty())
	    return 0;

      for (list<NetScope*>::const_iterator scope = root_scopes_.begin()
		 ; scope != root_scopes_.end(); ++ scope ) {

	    NetScope*cur = *scope;
	    if (path.front() != cur->fullname())
		  continue;

	    std::list<hname_t> tmp = path;
	    tmp.pop_front();

	    while (cur) {
		  if (tmp.empty()) return cur;

		  cur = cur->child( tmp.front() );

		  tmp.pop_front();
	    }
      }

      return 0;
}

/*
 * This method locates a scope in the design, given its rooted
 * hierarchical name. Each component of the key is used to scan one
 * more step down the tree until the name runs out or the search
 * fails.
 */
NetScope* Design::find_scope(const hname_t&path) const
{
      for (list<NetScope*>::const_iterator scope = root_scopes_.begin()
		 ; scope != root_scopes_.end(); ++ scope ) {

	    NetScope*cur = *scope;
	    if (path.peek_name() == cur->basename())
		  return cur;

      }

      return 0;
}

static bool is_design_unit(const NetScope*scope)
{
      return (scope->type() == NetScope::MODULE && !scope->nested_module())
	  || (scope->type() == NetScope::PACKAGE);
}

static bool is_subroutine(NetScope::TYPE type)
{
      return type == NetScope::TASK || type == NetScope::FUNC;
}

/*
 * This method locates a scope within another scope, given its relative
 * hierarchical name. Each component of the key is used to scan one
 * more step down the tree until the name runs out or the search
 * fails.
 */
NetScope* Design::find_scope_(NetScope*scope, const std::list<hname_t>&path,
                              NetScope::TYPE type) const
{
      std::list<hname_t> tmp = path;

      do {
	    hname_t key = tmp.front();
	      /* If we are looking for a module or we are not
	       * looking at the last path component check for
	       * a name match (second line). */
	    if (scope->type() == NetScope::MODULE
		&& (type == NetScope::MODULE || tmp.size() > 1)
		&& scope->module_name()==key.peek_name()) {

		    /* Up references may match module name */

	    } else {
		  NetScope*found_scope = scope->child(key);
		  if (found_scope == 0) {
			found_scope = scope->find_import(this, key.peek_name());
			if (found_scope)
			      found_scope = found_scope->child(key);
		  }
		  scope = found_scope;
		  if (scope == 0) break;
	    }
	    tmp.pop_front();
      } while (! tmp.empty());

      return scope;
}

/*
 * This is a relative lookup of a scope by name. The starting point is
 * the scope parameter within which I start looking for the scope. If
 * I do not find the scope within the passed scope, start looking in
 * parent scopes until I find it, or I run out of parent scopes.
 */
NetScope* Design::find_scope(NetScope*scope, const std::list<hname_t>&path,
                             NetScope::TYPE type) const
{
      assert(scope);
      if (path.empty())
	    return scope;

	// Record the compilation unit scope for use later.
      NetScope*unit_scope = scope->unit();

	// First search upwards through the hierarchy.
      while (scope) {
	    NetScope*found_scope = find_scope_(scope, path, type);
	    if (found_scope)
		  return found_scope;

	      // Avoid searching the unit scope twice.
	    if (scope == unit_scope)
		  unit_scope = 0;

	      // Special case - see IEEE 1800-2012 section 23.8.1.
	    if (unit_scope && is_design_unit(scope) && is_subroutine(type)) {
		  found_scope = find_scope_(unit_scope, path, type);
		  if (found_scope)
			  return found_scope;

		  unit_scope = 0;
	    }

	    scope = scope->parent();
      }

	// If we haven't already done so, search the compilation unit scope.
      if (unit_scope) {
	    NetScope*found_scope = find_scope_(unit_scope, path, type);
	    if (found_scope)
		  return found_scope;
      }

	// Last chance. Look for the name starting at the root.
      return find_scope(path);
}

/*
 * This method locates a scope within another scope, given its relative
 * hierarchical name. Each component of the key is used to scan one
 * more step down the tree until the name runs out or the search
 * fails.
 */
NetScope* Design::find_scope_(NetScope*scope, const hname_t&path,
                              NetScope::TYPE type) const
{
	/* If we are looking for a module or we are not
	 * looking at the last path component check for
	 * a name match (second line). */
      if ((scope->type() == NetScope::MODULE) && (type == NetScope::MODULE)
	  && (scope->module_name() == path.peek_name())) {
	      /* Up references may match module name */
	    return scope;
      }
      NetScope*found_scope = scope->child(path);
      if (found_scope == 0) {
	    found_scope = scope->find_import(this, path.peek_name());
	    if (found_scope)
		  found_scope = found_scope->child(path);
      }
      return found_scope;
}

/*
 * This is a relative lookup of a scope by name. The starting point is
 * the scope parameter within which I start looking for the scope. If
 * I do not find the scope within the passed scope, start looking in
 * parent scopes until I find it, or I run out of parent scopes.
 */
NetScope* Design::find_scope(NetScope*scope, const hname_t&path,
                             NetScope::TYPE type) const
{
      assert(scope);

	// Record the compilation unit scope for use later.
      NetScope*unit_scope = scope->unit();

	// First search upwards through the hierarchy.
      while (scope) {
	    NetScope*found_scope = find_scope_(scope, path, type);
	    if (found_scope)
		  return found_scope;

	      // Avoid searching the unit scope twice.
	    if (scope == unit_scope)
		  unit_scope = 0;

	      // Special case - see IEEE 1800-2012 section 23.8.1.
	    if (unit_scope && is_design_unit(scope) && is_subroutine(type)) {
		  found_scope = find_scope_(unit_scope, path, type);
		  if (found_scope)
			  return found_scope;

		  unit_scope = 0;
	    }

	    scope = scope->parent();
      }

	// If we haven't already done so, search the compilation unit scope.
      if (unit_scope) {
	    NetScope*found_scope = find_scope_(unit_scope, path, type);
	    if (found_scope)
		  return found_scope;
      }

	// Last chance. Look for the name starting at the root.
      list<hname_t>path_list;
      path_list.push_back(path);
      return find_scope(path_list);
}

/*
 * This method runs through the scope, noticing the defparam
 * statements that were collected during the elaborate_scope pass and
 * applying them to the target parameters. The implementation actually
 * works by using a specialized method from the NetScope class that
 * does all the work for me.
 */
void Design::run_defparams()
{
      for (list<NetScope*>::const_iterator scope = root_scopes_.begin();
	   scope != root_scopes_.end(); ++ scope )
	    (*scope)->run_defparams(this);
}

void NetScope::run_defparams(Design*des)
{
      for (map<hname_t,NetScope*>::const_iterator cur = children_.begin()
		 ; cur != children_.end() ; ++ cur )
	    cur->second->run_defparams(des);

      while (! defparams.empty()) {
	    pair<pform_name_t,PExpr*> pp = defparams.front();
	    defparams.pop_front();

	    pform_name_t path = pp.first;
	    PExpr*val = pp.second;

	    perm_string perm_name = peek_tail_name(path);
	    path.pop_back();

	    list<hname_t> eval_path = eval_scope_path(des, this, path);

	      /* If there is no path on the name, then the targ_scope
		 is the current scope. */
	    NetScope*targ_scope = des->find_scope(this, eval_path);
	    if (targ_scope == 0) {

		    // Push the defparam onto a list for retry
		    // later. It is possible for the scope lookup to
		    // fail if the scope being defparam'd into is
		    // generated by an index array for generate.
		  eval_path.push_back(hname_t(perm_name));
		  defparams_later.push_back(make_pair(eval_path,val));
		  continue;
	    }

	    targ_scope->replace_parameter(des, perm_name, val, this, true);
      }

	// If some of the defparams didn't find a scope in the name,
	// then try again later. It may be that the target scope is
	// created later by generate scheme or instance array.
      if (! defparams_later.empty())
	    des->defparams_later.insert(this);
}

void NetScope::run_defparams_later(Design*des)
{
      set<NetScope*> target_scopes;
      list<pair<list<hname_t>,PExpr*> > defparams_even_later;

      while (! defparams_later.empty()) {
	    pair<list<hname_t>,PExpr*> cur = defparams_later.front();
	    defparams_later.pop_front();

	    list<hname_t>eval_path = cur.first;
	    perm_string name = eval_path.back().peek_name();
	    eval_path.pop_back();

	    PExpr*val = cur.second;

	    NetScope*targ_scope = des->find_scope(this, eval_path);
	    if (targ_scope == 0) {
		    // If a scope in the target path is not found,
		    // then push this defparam for handling even
		    // later. Maybe a later generate scheme or
		    // instance array will create the scope.
		  defparams_even_later.push_back(cur);
		  continue;
	    }

	    targ_scope->replace_parameter(des, name, val, this, true);

	      // We'll need to re-evaluate parameters in this scope
	    target_scopes.insert(targ_scope);
      }

	// The scopes that this defparam set touched will be
	// re-evaluated later it a top_defparams work item. So do not
	// do the evaluation now.

	// If there are some scopes that still have missing scopes,
	// then save them back into the defparams_later list for a
	// later pass.
      defparams_later = defparams_even_later;
      if (! defparams_later.empty())
	    des->defparams_later.insert(this);
}

void Design::evaluate_parameters()
{
      for (map<perm_string,NetScope*>::const_iterator cur = packages_.begin()
		 ; cur != packages_.end() ; ++ cur) {
	    cur->second->evaluate_parameters(this);
      }

      for (list<NetScope*>::const_iterator scope = root_scopes_.begin()
		 ; scope != root_scopes_.end() ; ++ scope ) {
	    (*scope)->evaluate_parameters(this);
      }
}

/* Expand an unpacked array parameter into individual scalar parameters.
 * For  `parameter logic [3:0] UART_PERMIT [13] = '{4'b0011, ...}`
 * this creates parameters named "UART_PERMIT[0]", "UART_PERMIT[1]", etc.
 * For N unpacked dimensions the element name carries ONE bracket per
 * dimension, outermost first -- "PiRotate[2][3]" -- and every index is
 * the REAL declared index, so descending ([3:0]) and non-zero-based
 * ([1:4]) declarations name their elements the way the source does.
 * The read side (PEIdent::elaborate_expr_param_array_) rebuilds exactly
 * this name; the two MUST agree.
 * The original parameter gets a sentinel val so get_parameter() won't
 * try to re-evaluate it, and is_array_param remains true for indexed access.
 */

/* The element-name suffix for a position vector, one bracket per
 * unpacked dimension. `pos' is the 0-based position within each
 * dimension counted from that dimension's FIRST-LISTED bound, which is
 * how an assignment pattern is written; dims[k].get_msb() is that bound.
 * Shared by the write side here and mirrored on the read side. */
static string array_param_elem_suffix(const netranges_t&dims,
				      const std::vector<long>&pos)
{
      string s;
      for (size_t k = 0 ; k < pos.size() ; k += 1) {
	    long idx;
	    if (k < dims.size()) {
		  long l = dims[k].get_msb();
		  long r = dims[k].get_lsb();
		  idx = (l <= r) ? l + pos[k] : l - pos[k];
	    } else {
		  idx = pos[k];
	    }
	    char buf[64];
	    snprintf(buf, sizeof(buf), "[%ld]", idx);
	    s += buf;
      }
      return s;
}

void NetScope::evaluate_parameter_array_(Design*des, param_ref_t cur)
{
	if (cur->second.is_assoc_param) {
	      if (!cur->second.array_type && cur->second.udims)
		    cur->second.array_type = elaborate_array_type(
			  des, this, cur->second, cur->second.ivl_type,
			  *cur->second.udims);

	      if (!cur->second.array_type || !cur->second.val_expr) {
		    cerr << cur->second.get_fileline() << ": error: "
			 << "Unable to elaborate associative-array parameter `"
			 << cur->first << "`." << endl;
		    des->errors += 1;
		    cur->second.val = new NetEConst(verinum(verinum::Vx, 1));
		    cur->second.val_expr = nullptr;
		    return;
	      }

	      NetExpr*value = elab_and_eval(des, cur->second.val_scope,
					    cur->second.val_expr,
					    cur->second.array_type, true);
	      if (!value) {
		    cur->second.val = new NetEConst(verinum(verinum::Vx, 1));
		    cur->second.val_expr = nullptr;
		    return;
	      }
	      cur->second.val = value;
	      cur->second.val_expr = nullptr;
	      cur->second.array_dims.clear();
	      cur->second.array_bounds_known = false;
	      return;
	}

	/* The element parameters created below each infer their own type
	   from their own expression, but the ARRAY parameter itself keeps
	   whatever type the declaration gave it, and nothing fills that in
	   later. Without a declared element type it stays null and t-dll
	   asserts on it (`No type for parameter A in scope top?', then
	   `Assertion cur_pit->second.ivl_type failed'). Refuse instead of
	   aborting. */
      if (cur->second.ivl_type == nullptr && cur->second.val_type == nullptr) {
	    cerr << cur->second.get_fileline() << ": sorry: "
		 << "Unpacked array parameter '" << cur->first
		 << "' has no declared element type; an explicit type is "
		 << "required." << endl;
	    des->errors += 1;
	    cur->second.val = new NetEConst(verinum(verinum::Vx, 1));
	    cur->second.val_expr = nullptr;
	    return;
      }

	// Evaluate the declared unpacked bounds first: '{e0, e1, ...}
	// assigns e0 to [left], and elements are stored under their REAL
	// indices so that a select by index finds the right element for
	// descending ([3:0]) and non-zero-based ([1:4]) declarations
	// alike. Every unpacked dimension is evaluated, outermost first.
      netranges_t dims = cur->second.array_dims;
      bool bounds_known = cur->second.array_bounds_known;
      if (cur->second.udims && !cur->second.udims->empty()) {
	      dims.clear();
	      bounds_known = false;
	      // evaluate_range handles the [size] form ([4] == [0:3]) and
	      // reports unsized/queue/non-constant dimensions itself.
	      /* The DECLARED dimensions belong to the scope that declares
	         the parameter -- `this' -- not to val_scope. IEEE
	         1800-2017 23.10: an override supplies a VALUE, it does not
	         restate the declaration, so names in the declared range
	         still resolve where the parameter was written (6.20.2).
	         val_scope becomes the INSTANTIATING scope once the
	         parameter is overridden, so `parameter int A[N]' in a
	         child, overridden from a parent that has no `N', looked
	         `N' up in the parent and failed with "Unable to bind
	         parameter `N'". Overriding nothing, or overriding only
	         `N', both worked -- which is why this hid for so long. */
	    bool ok = true;
	      /* IEEE 1800-2017 6.20.2 / A.2.4: a parameter may leave a single
	         unpacked dimension UNSIZED and take its size from the
	         initializer -- OpenTitan's rstmgr_env_pkg writes

	             parameter string LIST_OF_LEAFS[] = { "u_daon_lc", ... };

	         evaluate_range() rejects an unsized dimension outright (its own
	         comment says such a dimension must be resolved before it is
	         called), so this only needs the count, which the initializer
	         already carries. Restricted to a lone dimension: inferring one
	         size from a flat element count says nothing about how a
	         multi-dimensional array should be split, so those stay a loud
	         error rather than a guess. */
	    size_t inferred = 0;
	    bool infer_first = false;
	    if (cur->second.udims->size() == 1
		&& cur->second.udims->front().first == 0) {
		  if (PEAssignPattern*ipat =
			  dynamic_cast<PEAssignPattern*>(cur->second.val_expr)) {
			std::vector<PExpr*> ielems;
			if (ipat->expand_replication_(des, cur->second.val_scope,
						      ielems)) {
			      inferred = ielems.size();
			      infer_first = true;
			}
		  } else if (PEConcat*icat =
			  dynamic_cast<PEConcat*>(cur->second.val_expr)) {
			if (!icat->has_repeat()) {
			      inferred = icat->stream_parms().size();
			      infer_first = true;
			}
		  }
		  if (infer_first && inferred == 0)
			infer_first = false;
	    }
	    if (infer_first) {
		  dims.push_back(netrange_t(0, (long)inferred - 1));
	    } else
	    for (std::list<pform_range_t>::const_iterator dcur
		       = cur->second.udims->begin()
		       ; dcur != cur->second.udims->end() ; ++dcur) {
		  long dl = 0, dr = 0;
		  if (! evaluate_range(des, this, &cur->second, *dcur, dl, dr)) {
			ok = false;
			break;
		  }
		  dims.push_back(netrange_t(dl, dr));
	    }
	    if (! ok) {
		  cur->second.val = new NetEConst(verinum(verinum::Vx, 1));
		  cur->second.val_expr = nullptr;
		  return;
	    }
	    bounds_known = true;
      }
      cur->second.array_dims = dims;
      cur->second.array_bounds_known = bounds_known;

      const size_t ndims = dims.size();

	// Total element count across all unpacked dimensions.
      size_t total = 1;
      for (size_t k = 0 ; k < ndims ; k += 1)
	    total *= (size_t)dims[k].width();

	// Set the sentinel and give up on this array.
      auto give_up = [&]() {
	    cur->second.val = new NetEConst(verinum(verinum::Vx, 1));
	    cur->second.val_expr = nullptr;
      };

	// Create one scalar element parameter. `expr' is the (unelaborated)
	// source expression, or `val' an already-evaluated constant. An
	// assignment pattern at a leaf is context-determined by the array's
	// declared element type (IEEE 1800-2017 10.9.1). Preserve that type on
	// the expanded element; otherwise a declaration such as
	//
	//   localparam pair_t P[2] = '{'{a:1, b:2}, '{a:3, b:4}};
	//
	// is split into P[0]/P[1] and each nested pattern is later elaborated
	// without any type context.
      auto make_elem = [&](const string&suffix, PExpr*expr,
			   NetExpr*val, NetScope*vscope,
			   ivl_type_t vtype = nullptr) {
	    string elem_str = string(cur->first.str()) + suffix;
	    perm_string elem_name = lex_strings.make(elem_str.c_str());
	    param_expr_t& ref = parameters[elem_name];
	    ref.is_annotatable = false;
	    ref.val_expr = expr;
	    ref.source_expr = expr;
	    ref.val_type = nullptr;
	    ref.val_scope = vscope;
	    ref.source_scope = vscope;
	    ref.local_flag = cur->second.local_flag;
	    ref.overridable = false;
	      ref.type_flag = false;
	      ref.is_array_param = false;
	      ref.is_assoc_param = false;
	      ref.array_type = nullptr;
	    // A copied element carries its source type. An unevaluated element
	    // carries the declared array element type so typed expressions,
	    // especially nested assignment patterns, can be elaborated exactly.
	    ref.ivl_type = vtype ? vtype : (expr ? cur->second.ivl_type : nullptr);
	    ref.val = val;
	    ref.solving = false;
	    ref.range = nullptr;
	    ref.set_line(cur->second);
      };

      PEAssignPattern* ap = dynamic_cast<PEAssignPattern*>(cur->second.val_expr);
      PEConcat* ac = dynamic_cast<PEConcat*>(cur->second.val_expr);
      if (!ap && !ac) {
	    /* If val_expr is an identifier reference (e.g. a parent's array
	     * parameter passed through a port), copy the elements over from
	     * the source array, index tuple by index tuple. */
	    PEIdent* id = dynamic_cast<PEIdent*>(cur->second.val_expr);
	    if (id && cur->second.val_scope) {
		  // Resolve the identifier as a symbol instead of assuming it is
		  // a parameter declared directly in val_scope. The latter is true
		  // for a simple parent-to-child override, but not for a qualified
		  // package constant such as pkg::PmpCfgRst, nor for an unqualified
		  // reference found in an ancestor scope. IEEE 1800-2017 23.10
		  // passes the array value; qualification only chooses its source.
		  symbol_search_results src_res;
		  bool src_found = symbol_search(id, des, cur->second.val_scope,
			id->path(), id->lexical_pos(), &src_res);
		  perm_string src_name = src_res.path_head.empty()
			? peek_tail_name(id->path().name)
			: peek_tail_name(src_res.path_head);
		  NetScope* src_scope = src_found ? src_res.scope : nullptr;
		  if (!src_found || !src_scope || !src_res.par_val
		      || !src_res.path_tail.empty()) {
			cerr << cur->second.get_fileline() << ": sorry: "
			     << "Array parameter '" << cur->first
			     << "' is initialized from `" << id->path()
			     << "', which does not resolve to an array parameter."
			     << endl;
			des->errors += 1;
			give_up();
			return;
		  }
		  param_ref_t src_it = src_scope->parameters.find(src_name);
		  if (src_it == src_scope->parameters.end()) {
			/* Not a parameter of val_scope at all -- a
			   package-qualified or hierarchical reference, say.
			   Refuse loudly rather than leaving the array with
			   no elements, which reads back as a silent x. */
			cerr << cur->second.get_fileline() << ": sorry: "
			     << "Array parameter '" << cur->first
			     << "' is initialized from `" << id->path()
			     << "', which is not an array parameter of "
			     << scope_path(src_scope) << "." << endl;
			des->errors += 1;
			give_up();
			return;
		  }
		    /* The source may not have been expanded yet: child
		       scopes are evaluated BEFORE their parent (see
		       NetScope::evaluate_parameters), so a parameter
		       overridden with a parent's array arrives here with
		       the parent's array still unexpanded. Force it. */
		  if (! src_it->second.array_bounds_known
		      && src_it->second.is_array_param)
			src_scope->evaluate_parameter_(des, src_it);

		  if (! src_it->second.array_bounds_known) {
			cerr << cur->second.get_fileline() << ": sorry: "
			     << "Array parameter '" << cur->first
			     << "' is initialized from `" << src_name
			     << "', whose bounds are not known." << endl;
			des->errors += 1;
			give_up();
			return;
		  }
		  const netranges_t&sdims = src_it->second.array_dims;
		  if (bounds_known && sdims.size() != ndims) {
			cerr << cur->second.get_fileline() << ": error: "
			     << "Array parameter '" << cur->first << "' has "
			     << ndims << " unpacked dimension(s) but is "
			     << "initialized from `" << src_name << "', which "
			     << "has " << sdims.size() << "." << endl;
			des->errors += 1;
			give_up();
			return;
		  }
		  for (size_t k = 0 ; bounds_known && k < ndims ; k += 1) {
			if (dims[k].width() != sdims[k].width()) {
			      cerr << cur->second.get_fileline() << ": error: "
				   << "Array parameter '" << cur->first
				   << "' dimension " << k << " has "
				   << dims[k].width() << " element(s) but `"
				   << src_name << "' has " << sdims[k].width()
				   << "." << endl;
			      des->errors += 1;
			      give_up();
			      return;
			}
			if (dims[k] == sdims[k])
			      continue;
			/* Same size, different bounds. Which source element
			   corresponds to which destination element is then
			   NOT settled: copying by position from each side's
			   first-listed bound and copying by distance from
			   each side's LOW index disagree, and this compiler
			   already picks the second for a whole-array
			   assignment (`P = Q'). Refuse rather than pick one
			   silently -- a wrong element here is invisible. */
			cerr << cur->second.get_fileline() << ": sorry: "
			     << "Array parameter '" << cur->first
			     << "' dimension " << k << " is declared ["
			     << dims[k].get_msb() << ":" << dims[k].get_lsb()
			     << "] but is initialized from `" << src_name
			     << "', whose dimension " << k << " is ["
			     << sdims[k].get_msb() << ":"
			     << sdims[k].get_lsb() << "]; only identical "
			     << "bounds are supported." << endl;
			des->errors += 1;
			give_up();
			return;
		  }
		    // Walk the position space in row-major order and copy
		    // element by element. Both sides use their OWN declared
		    // indices for the name, so direction and origin can
		    // differ between source and destination.
		  std::vector<long> pos (ndims, 0);
		  for (size_t n = 0 ; n < total ; n += 1) {
			ivl_type_t src_type = 0;
			string sname = string(src_name.str())
			      + array_param_elem_suffix(sdims, pos);
			perm_string s_perm = lex_strings.make(sname.c_str());
			const NetExpr* src_val =
			      src_scope->get_parameter(des, s_perm, src_type);
			if (! src_val) {
			      cerr << cur->second.get_fileline() << ": error: "
				   << "Array parameter '" << cur->first
				   << "' is initialized from `" << src_name
				   << "', which has no element " << sname
				   << "." << endl;
			      des->errors += 1;
			      give_up();
			      return;
			}
			make_elem(array_param_elem_suffix(dims, pos), nullptr,
				  src_val->dup_expr(), src_scope,
				  src_type ? src_type
					   : cur->second.ivl_type);
			  // Odometer step, last dimension fastest.
			for (size_t k = ndims ; k-- > 0 ; ) {
			      pos[k] += 1;
			      if (pos[k] < (long)dims[k].width())
				    break;
			      pos[k] = 0;
			}
		  }
		  give_up();
		  return;
	    }
	    /* Fall back: warn and use X for all elements (index unknown
	     * without udims info). */
	    cerr << cur->second.get_fileline() << ": warning: "
		 << "Array parameter '" << cur->first
		 << "' has non-pattern initializer; elements set to X." << endl;
	    give_up();
	    return;
      }

	/* Walk the nested assignment pattern, one level per unpacked
	   dimension, creating one scalar parameter per leaf. Replication
	   ('{N{...}}) is expanded at every level. */
      bool failed = false;
      std::vector<long> pos;
      std::function<void(PExpr*)> walk = [&](PExpr*e) {
	    if (failed) return;
	    size_t depth = pos.size();
	    if (bounds_known && depth == ndims) {
		  make_elem(array_param_elem_suffix(dims, pos), e,
			    nullptr, cur->second.val_scope);
		  return;
	    }
	    PEAssignPattern* pat = dynamic_cast<PEAssignPattern*>(e);
	    PEConcat* cat = dynamic_cast<PEConcat*>(e);
	    if (!pat && !cat) {
		  cerr << e->get_fileline() << ": error: "
		       << "Array parameter '" << cur->first << "' dimension "
		       << depth << " needs an assignment pattern here, not a "
		       << "scalar expression." << endl;
		  des->errors += 1;
		  failed = true;
		  return;
	    }

	    /* A lone default names every element in the current and all
	       remaining unpacked dimensions. It is not a one-element
	       positional pattern. Elaborate a separately owned scalar value
	       for every leaf so parameter cleanup never shares a PExpr. */
	    if (bounds_known && pat) {
		  if (PExpr*dflt = pat->lone_default_()) {
			for (unsigned i = 0 ; i < dims[depth].width() ; i += 1) {
			      pos.push_back((long)i);
			      if (depth + 1 < ndims) {
				    walk(e);
			      } else {
				    NetExpr*val = elab_and_eval(
					  des, cur->second.val_scope, dflt,
					  cur->second.ivl_type, true);
				    if (!val) {
					  failed = true;
				    } else {
					  make_elem(array_param_elem_suffix(dims, pos),
						    nullptr, val, this,
						    cur->second.ivl_type);
				    }
			      }
			      pos.pop_back();
			      if (failed) return;
			}
			return;
		  }
	    }

	    std::vector<PExpr*> elems;
	    if (pat) {
		  ivl_type_t element_type = cur->second.ivl_type;
		  std::unique_ptr<netuarray_t> nested_array_type;
		  if (depth + 1 < ndims) {
			netranges_t remaining(dims.begin() + depth + 1,
					      dims.end());
			nested_array_type.reset(new netuarray_t(
			      remaining, cur->second.ivl_type));
			element_type = nested_array_type.get();
		  }
		  if (!pat->resolve_keyed_dimension_(des, cur->second.val_scope,
				dims[depth], element_type, elems)) {
			failed = true;
			return;
		  }
	    } else {
		    // IEEE 1800-2017 10.10: an unpacked array concatenation
		    // supplies elements in the same left-to-right positional
		    // order as an assignment pattern. OpenTitan uses this legal
		    // form for string array parameters:
		    //   parameter string P[2] = {"a", "b"};
		  const std::vector<PExpr*>&base = cat->stream_parms();
		  unsigned repeat = 1;
		  if (cat->has_repeat()) {
			NetExpr*re = elab_and_eval(des, cur->second.val_scope,
					    cat->repeat_expr(), -1, true);
			NetEConst*rc = dynamic_cast<NetEConst*>(re);
			if (!rc || !rc->value().is_defined()) {
			      cerr << cat->get_fileline() << ": error: Array "
				      "concatenation repetition must be a constant."
				   << endl;
			      des->errors += 1;
			      delete re;
			      failed = true;
			      return;
			}
			repeat = (unsigned)rc->value().as_ulong64();
			delete re;
		  }
		  elems.reserve((size_t)repeat * base.size());
		  for (unsigned rep = 0 ; rep < repeat ; rep += 1)
			for (PExpr*elem : base) elems.push_back(elem);
	    }
	      // IEEE 1800-2017 10.9.1/7.6: the pattern must supply exactly
	      // one expression per element. A mismatch is an error, not a
	      // silently truncated or padded array.
	    if (bounds_known && elems.size() != (size_t)dims[depth].width()) {
		  cerr << cur->second.get_fileline() << ": error: "
		       << "Assignment pattern for array parameter '"
		       << cur->first << "'";
		  if (depth > 0)
			cerr << " dimension " << depth;
		  cerr << " has " << elems.size()
		       << " element(s), but the array has "
		       << dims[depth].width() << "." << endl;
		  des->errors += 1;
		  failed = true;
		  return;
	    }
	    for (size_t i = 0 ; i < elems.size() ; i += 1) {
		  pos.push_back((long)i);
		  walk(elems[i]);
		  pos.pop_back();
		  if (failed) return;
	    }
      };

      if (! bounds_known) {
	      // No udims at all: keep the historical flat behaviour, one
	      // bracket, positions as indices.
	    std::vector<PExpr*> elems;
	    if (! ap->expand_replication_(des, cur->second.val_scope, elems)) {
		  give_up();
		  return;
	    }
	    for (size_t i = 0 ; i < elems.size() ; i += 1) {
		  char buf[64];
		  snprintf(buf, sizeof(buf), "[%zu]", i);
		  make_elem(buf, elems[i], nullptr, cur->second.val_scope);
	    }
	    give_up();
	    return;
      }

      walk(cur->second.val_expr);

      // Set sentinel so get_parameter() returns non-null (is_array_param stays true)
      give_up();
}

void NetScope::evaluate_parameter_logic_(Design*des, param_ref_t cur)
{
	/* Evaluate the parameter expression. */
      PExpr*val_expr = (*cur).second.val_expr;
      NetScope*val_scope = (*cur).second.val_scope;

      // The param_type may be nil if the parameter has no declared type. In
      // this case, we'll try to take our type from the r-value.
      ivl_type_t param_type = cur->second.ivl_type;

      // Most parameter declarations are packed vectors, of the form:
      //   parameter [H:L] foo == bar;
      // so get the netvector_t. Note that this may also be the special
      // case of a netvector_t with no dimensions, that exists only to carry
      // signed-ness, e.g.:
      //  parameter signed foo = bar;
      // These will be marked as scalar, but also have the implict flag set.
      const netvector_t* param_vect = dynamic_cast<const netvector_t*> (param_type);

      if (debug_elaborate) {
	    cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		 << "parameter=" << cur->first << endl;
	    if (param_type)
		  cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		       << "param_type=" << *param_type << endl;
	    else
		  cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		       << "param_type=(nil)" << endl;
	    cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		 << "val_expr=" << *val_expr << endl;
      }

      ivl_variable_type_t use_type;
      int lv_width = -2;
      if (param_type) {
	    use_type = param_type->base_type();
	    // Is this an implicit netvector_t with no dimenions?
	    if (param_vect && param_vect->get_implicit() &&
	        param_vect->get_scalar())
		  lv_width = -2;
	    else if (param_type->packed())
		  lv_width = param_type->packed_width();
      } else {
	    use_type = val_expr->expr_type();
      }

      if (debug_elaborate) {
	    cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		 << "use_type = " << use_type << endl;
      }

      NetExpr *expr;

      // Handle assignment patterns as a special case as they need the type to
      // be evaluated correctly.
      if (param_type && (dynamic_cast<PEAssignPattern*>(val_expr)
			 || concat_of_assign_patterns_is_unsafe_typed(val_expr))) {
	    expr = elab_and_eval(des, val_scope, val_expr, param_type, true);
      } else {
	    unsigned extra_flags = PExpr::NO_FLAGS;
	      /* A direct `$' or direct parameter alias is the only value-
	       * parameter expression that may carry the unbounded marker.
	       * Do not propagate this permission through arithmetic/casts: an
	       * unbounded parameter is not a numeric value (6.20.2.1). */
	    if (dynamic_cast<PEUnbounded*>(val_expr)
		|| dynamic_cast<PEIdent*>(val_expr))
		  extra_flags |= PExpr::ALLOW_UNBOUNDED;
	    expr = elab_and_eval(des, val_scope, val_expr, lv_width, true,
			 cur->second.is_annotatable, use_type, false,
			 extra_flags);
      }
      if (! expr)
            return;

      if (!param_type && use_type == IVL_VT_NO_TYPE) {
	    use_type = val_expr->expr_type();
	    if (use_type == IVL_VT_NO_TYPE)
		  use_type = expr->expr_type();
      }

      if (NetEConst*unbounded = dynamic_cast<NetEConst*>(expr)) {
	    if (unbounded->is_unbounded()) {
		    /* Enum assignment still requires an enum member/cast, and
		       unpacked arrays are not integer types. */
		  if (dynamic_cast<const netenum_t*>(param_type)
		      || cur->second.is_array_param
		      || cur->second.range) {
			cerr << val_expr->get_fileline() << ": error: unbounded "
			     << "literal '$' cannot be assigned to parameter `"
			     << cur->first << "' with this type or value range."
			     << endl;
			des->errors += 1;
			delete expr;
			return;
		  }

		  if (param_type == 0) {
			param_type = netvector_t::integer_type();
			cur->second.ivl_type = param_type;
		  }
		  unbounded->cast_signed(param_type->get_signed());
		  cur->second.val = unbounded;
		  return;
	    }
      }

      // Make sure to carry the signed-ness from a vector type.
      if (param_vect)
	    expr->cast_signed(param_vect->get_signed());

      if (debug_elaborate) {
	    cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		 << "expr = " << *expr << endl;
	    cerr << val_expr->get_fileline() << ": " << __func__ << ": "
		 << "expr type = " << expr->expr_type() << endl;
      }

      switch (expr->expr_type()) {
	  case IVL_VT_REAL:
	    if (! dynamic_cast<const NetECReal*>(expr)) {
		  cerr << expr->get_fileline()
		       << ": error: Unable to evaluate real parameter "
		       << (*cur).first << " value: " << *expr << endl;
		  des->errors += 1;
		  return;
	    }

	    // If the parameter has no type, then infer its type from the
	    // r-value expression.
	    if (param_type==0) {
		  param_type = &netreal_t::type_real;
		  cur->second.ivl_type = param_type;
	    }
	    break;

	  case IVL_VT_STRING:
	      /* An UNTYPED parameter takes its type from the value it is
		 finally assigned (IEEE 1800-2017/2023 6.20.2), and that value
		 may be a string: prim_lfsr's `parameter LfsrType = "GAL_XOR"'
		 is overridden from a `localparam string'. A string LITERAL
		 override arrives as a vector and lands in the IVL_VT_LOGIC arm
		 below, so only an override that keeps its string type reaches
		 here -- which is why this case was missing. */
	    if (! dynamic_cast<const NetECString*>(expr)) {
		  cerr << expr->get_fileline()
		       << ": error: Unable to evaluate string parameter "
		       << (*cur).first << " value: " << *expr << endl;
		  des->errors += 1;
		  return;
	    }

	    if (param_type==0) {
		  param_type = &netstring_t::type_string;
		  cur->second.ivl_type = param_type;
	    }
	    break;

	  case IVL_VT_LOGIC:
	  case IVL_VT_BOOL:
	    if (! dynamic_cast<const NetEConst*>(expr)) {
		  cerr << expr->get_fileline()
		       << ": error: Unable to evaluate parameter "
		       << (*cur).first << " value: " << *expr << endl;
		  des->errors += 1;
		  return;
	    }

	    // If the parameter has no type, then infer its type from the
	    // r-value expression.
	    if (param_type==0) {
		  param_type = new netvector_t(use_type, expr->expr_width()-1,
					       0, expr->has_sign());
		  cur->second.ivl_type = param_type;
	    }

	    if (param_type->base_type() != IVL_VT_NO_TYPE)
		  expr->cast_signed(param_type->get_signed());

	    if (!expr->has_width()) {
		  expr = pad_to_width(expr, integer_width, *expr);
	    }
	    break;

	  case IVL_VT_NO_TYPE:
	      /* An unpacked struct has no scalar ivl_variable_type. Its
		 assignment-pattern value is nevertheless a fully elaborated,
		 constant aggregate whose member types are carried by netstruct_t.
		 Keep that NetEArrayPattern as the parameter value; member reads
		 select and duplicate its constant items later. */
	    if (param_type
		&& dynamic_cast<const netstruct_t*>(param_type)
		&& !param_type->packed()
		&& dynamic_cast<const NetEArrayPattern*>(expr))
		  break;
	      /* fall through */

	  default:
	    cerr << expr->get_fileline()
		 << ": internal error: "
		 << "Unhandled expression type "
		 << expr->expr_type() << "?" << endl;
	    cerr << expr->get_fileline()
		 << ":               : "
		 << "param_type: ";
	      /* param_type is null for an untyped parameter -- the arms above
		 all test for that and infer a type. Dereferencing it here
		 crashed the compiler while it was printing this very message. */
	    if (param_type) cerr << *param_type;
	    else cerr << "<none: the parameter is untyped>";
	    cerr << endl;
	    des->errors += 1;
	    return;
      }

      // By the time we're done with the above, we should certainly know the
      // type of the parameter.
      ivl_assert(*expr, cur->second.ivl_type);

      cur->second.val = expr;

	// If there are no value ranges to test the value against,
	// then we are done.
      if ((*cur).second.range == 0)
	    return;

      const NetEConst*val = dynamic_cast<NetEConst*>((*cur).second.val);
      ivl_assert(*expr, val);

      verinum value = val->value();

      bool from_flag = (*cur).second.range == 0? true : false;
      for (range_t*value_range = (*cur).second.range
		 ; value_range ; value_range = value_range->next) {

	      // If we already know that the value is
	      // within a "from" range, then do not test
	      // any more of the from ranges.
	    if (from_flag && value_range->exclude_flag==false)
		  continue;

	    if (value_range->low_expr) {
		  const NetEConst*tmp = dynamic_cast<NetEConst*>(value_range->low_expr);
		  ivl_assert(*value_range->low_expr, tmp);
		  if (value_range->low_open_flag && value <= tmp->value())
			continue;
		  else if (value < tmp->value())
			continue;
	    }

	    if (value_range->high_expr) {
		  const NetEConst*tmp = dynamic_cast<NetEConst*>(value_range->high_expr);
		  ivl_assert(*value_range->high_expr, tmp);
		  if (value_range->high_open_flag && value >= tmp->value())
			continue;
		  else if (value > tmp->value())
			continue;
	    }

	      // Within the range. If this is a "from"
	      // range, then set the from_flag and continue.
	    if (value_range->exclude_flag == false) {
		  from_flag = true;
		  continue;
	    }

	      // OH NO! In an excluded range. signal an error.
	    from_flag = false;
	    break;
      }

	// If we found no from range that contains the
	// value, then report an error.
      if (! from_flag) {
	    cerr << val->get_fileline() << ": error: "
		 << "Parameter value " << value
		 << " is out of range for parameter " << (*cur).first
		 << "." << endl;
	    des->errors += 1;
      }
}

void NetScope::evaluate_parameter_real_(Design*des, param_ref_t cur)
{
      PExpr*val_expr = (*cur).second.val_expr;
      NetScope*val_scope = (*cur).second.val_scope;
      ivl_type_t param_type = cur->second.ivl_type;

      ivl_assert(*val_expr, param_type);
      NetExpr*expr = elab_and_eval(des, val_scope, val_expr, -1, true,
                                   cur->second.is_annotatable,
                                   param_type->base_type());
      if (! expr)
            return;

      NetECReal*res = 0;

      switch (expr->expr_type()) {
	  case IVL_VT_REAL:
	    if (NetECReal*tmp = dynamic_cast<NetECReal*>(expr)) {
		  res = tmp;
	    } else {
		  cerr << expr->get_fileline()
		       << ": error: "
		       << "Unable to evaluate real parameter "
		       << (*cur).first << " value: " << *expr << endl;
		  des->errors += 1;
		  return;
	    }
	    break;

	  default:
	    cerr << expr->get_fileline()
		 << ": internal error: "
		 << "Failed to cast expression?" << endl;
	    des->errors += 1;
	    return;
	    break;
      }

      (*cur).second.val = res;
      double value = res->value().as_double();

      bool from_flag = (*cur).second.range == 0? true : false;
      for (range_t*value_range = (*cur).second.range
		 ; value_range ; value_range = value_range->next) {

	    if (from_flag && value_range->exclude_flag==false)
		  continue;

	    if (value_range->low_expr) {
		  double tmp;
		  bool flag = eval_as_double(tmp, value_range->low_expr);
		  ivl_assert(*value_range->low_expr, flag);
		  if (value_range->low_open_flag && value <= tmp)
			continue;
		  else if (value < tmp)
			continue;
	    }

	    if (value_range->high_expr) {
		  double tmp;
		  bool flag = eval_as_double(tmp, value_range->high_expr);
		  ivl_assert(*value_range->high_expr, flag);
		  if (value_range->high_open_flag && value >= tmp)
			continue;
		  else if (value > tmp)
			continue;
	    }

	    if (value_range->exclude_flag == false) {
		  from_flag = true;
		  continue;
	    }

	      // All the above tests failed, so we must have tripped
	      // an exclude rule.
	    from_flag = false;
	    break;
      }

      if (! from_flag) {
	    cerr << res->get_fileline() << ": error: "
		 << "Parameter value " << value
		 << " is out of range for real parameter " << (*cur).first
		 << "." << endl;
	    des->errors += 1;
      }
}

/*
 * Evaluate a parameter that is forced to type string. This comes to pass when
 * the input is something like this:
 *
 *     parameter string foo = <expr>;
 *
 * The param_type should be netstring_t, the val_expr is the pform of the
 * input <expr>, and we try to elaborate/evaluate down to a IVL_VT_STRING
 * expression.
 */
void NetScope::evaluate_parameter_string_(Design*des, param_ref_t cur)
{
      PExpr*val_expr = (*cur).second.val_expr;
      NetScope*val_scope = (*cur).second.val_scope;
      ivl_type_t param_type = cur->second.ivl_type;

      ivl_assert(cur->second, val_expr);
      ivl_assert(cur->second, param_type);

      NetExpr*expr = elab_and_eval(des, val_scope, val_expr, param_type, true);
      if (! expr)
	    return;

      if (!dynamic_cast<const NetECString*>(expr)) {
	    cerr << expr->get_fileline()
		 << ": error: Unable to evaluate string parameter "
		 << cur->first << " value: " << *expr << endl;
	    des->errors += 1;
	    delete expr;
	    return;
      }

      cur->second.val = expr;

      if (debug_elaborate) {
	    cerr << cur->second.get_fileline() << ": " << __func__ << ": "
		 << "Parameter type: " << *param_type << endl;
	    cerr << cur->second.get_fileline() << ": " << __func__ << ": "
		 << "Parameter value: " << *val_expr << endl;
	    cerr << cur->second.get_fileline() << ": " << __func__ << ": "
		 << "Elaborated value: " << *expr << endl;
      }
}

void NetScope::evaluate_type_parameter_(Design *des, param_ref_t cur)
{
      const PETypename *type_expr = dynamic_cast<const PETypename*>(cur->second.val_expr);
      if (!type_expr) {
	    const PEIdent*ident_expr = dynamic_cast<const PEIdent*>(cur->second.val_expr);
	    if (ident_expr) {
		  NetScope*actual_scope = cur->second.val_scope ? cur->second.val_scope : this;
		  if (ivl_type_t type = ident_expr->resolve_scoped_type_actual(des, actual_scope)) {
			cur->second.ivl_type = type;
			return;
		  }
		  const pform_scoped_name_t&ident_path = ident_expr->path();
		  if (ident_path.package == 0 && ident_path.name.size() == 1
		      && ident_path.name.front().index.empty()) {
			perm_string name = ident_path.name.front().name;
			NetScope*start_scope = cur->second.val_scope ? cur->second.val_scope : this;

			  // First, allow aliases to earlier visible type parameters
			  // (e.g. type RSP = REQ).
			for (NetScope*sc = start_scope ; sc ; sc = sc->parent()) {
			      auto param_it = sc->parameters.find(name);
			      if (param_it != sc->parameters.end() && param_it->second.type_flag) {
				    if (&param_it->second != &cur->second)
					  sc->evaluate_parameter_(des, param_it);
				    cur->second.ivl_type = param_it->second.ivl_type;
				    if (cur->second.ivl_type)
					  return;
			      }

			      auto td_it = sc->typedefs_.find(name);
			      if (td_it != sc->typedefs_.end()) {
				    if (const netclass_t*self_class =
						resolve_current_class_typedef_alias_(start_scope,
										 td_it->second)) {
					  cur->second.ivl_type = const_cast<netclass_t*>(self_class);
					  return;
				    }
				    cur->second.ivl_type = td_it->second->elaborate_type(des, sc);
				    if (cur->second.ivl_type)
					  return;
			      }

			      NetScope*import_scope = sc->find_import(des, name);
			      if (import_scope) {
				    auto imp_param_it = import_scope->parameters.find(name);
				    if (imp_param_it != import_scope->parameters.end()
				        && imp_param_it->second.type_flag) {
					  import_scope->evaluate_parameter_(des, imp_param_it);
					  cur->second.ivl_type = imp_param_it->second.ivl_type;
					  if (cur->second.ivl_type)
					        return;
				    }

				    auto imp_td_it = import_scope->typedefs_.find(name);
				    if (imp_td_it != import_scope->typedefs_.end()) {
					  if (const netclass_t*self_class =
						      resolve_current_class_typedef_alias_(start_scope,
											   imp_td_it->second)) {
						cur->second.ivl_type = const_cast<netclass_t*>(self_class);
						return;
					  }
					  cur->second.ivl_type = imp_td_it->second->elaborate_type(des, import_scope);
					  if (cur->second.ivl_type)
					        return;
				    }
			      }

			      if (sc->type() == NetScope::MODULE)
				    break;
			}

			  // Also accept visible classes as type defaults.
			if (netclass_t*cls = ensure_visible_class_type(des, start_scope, name)) {
			      cur->second.ivl_type = cls;
			      return;
			}
		  }
	    }
      }

      if (!type_expr) {
	    cerr << this->get_fileline() << ": error: "
		 << "Type parameter `" << cur->first << "` value `"
	         << *cur->second.val_expr << "` is not a type."
		 << endl;
	    des->errors++;

	    // Recover
	    cur->second.ivl_type = netvector_t::integer_type();
	    return;
      }

      data_type_t *ptype = type_expr->get_type();
      NetScope *type_scope = cur->second.val_scope ? cur->second.val_scope : this;

      /* A type-parameter alias (type U = T) must copy T's resolved type
	 without elaborating T as a concrete declaration use. This distinction
	 matters for a lazy unresolved virtual-interface default: forwarding the
	 default remains legal until a signal/property actually selects it. */
      if (const type_parameter_t*type_param =
		dynamic_cast<const type_parameter_t*>(ptype)) {
	    ivl_type_t resolved_type = 0;
	    type_scope->get_parameter(des, type_param->name, resolved_type);
	    if (resolved_type) {
		  cur->second.ivl_type = resolved_type;
		  return;
	    }
      }

      /* Resolve class-bearing type actuals before consulting the generic
       * per-scope type cache. A forward class used through a parameterized
       * typedef can otherwise cache an early integral recovery
       * specialization; because that stale result is still a netclass_t,
       * the late non-class recovery below cannot recognize or repair it. */
      cur->second.ivl_type = resolve_class_type_reference(des, type_scope, ptype);
      if (!cur->second.ivl_type)
	    cur->second.ivl_type = ptype->elaborate_type(des, type_scope);
	/* A bare class used as a type actual of a concrete specialization is a
	 * concrete default specialization. The circular-handle resolver above
	 * seeds its type only; request the ordinary class use so its method body
	 * is emitted as well. Keep generic masters and forwarded actuals lazy. */
	if (type_ == CLASS && class_def_ && class_def_->specialized_instance()
	    && !class_def_->generic_body_only()
	    && !class_type_parameter_is_deferred(des, this, cur->first)) {
	    const typeref_t*ref = dynamic_cast<const typeref_t*>(ptype);
	    const netclass_t*actual =
		  dynamic_cast<const netclass_t*>(cur->second.ivl_type);
	    if (ref && !ref->parameter_values() && actual
		&& actual->specialized_instance())
		  (void) ptype->elaborate_type(des, type_scope);
	}
      if (!dynamic_cast<const netclass_t*>(cur->second.ivl_type)) {
	    if (const class_type_t*class_type = dynamic_cast<const class_type_t*>(ptype)) {
		  if (netclass_t*cls = ensure_visible_class_type(des, type_scope,
								 class_type->name)) {
			cur->second.ivl_type = cls;
			return;
		  }
	    }

	    if (const type_parameter_t*type_param = dynamic_cast<const type_parameter_t*>(ptype)) {
		  ivl_type_t resolved_type = 0;
		  type_scope->get_parameter(des, type_param->name, resolved_type);
		  if (dynamic_cast<const netclass_t*>(resolved_type)) {
			cur->second.ivl_type = resolved_type;
			return;
		  }
	    }

	    if (const typeref_t*type_ref = dynamic_cast<const typeref_t*>(ptype)) {
		  if (typedef_t*td = type_ref->typedef_ref()) {
			if (td->get_basic_type() == typedef_t::CLASS) {
			      if (const netclass_t*self_class =
					      resolve_current_class_typedef_alias_(type_scope, td)) {
				    cur->second.ivl_type = const_cast<netclass_t*>(self_class);
				    return;
			      }

			      NetScope*ref_scope = type_ref->find_scope(des, type_scope);
			      if (!ref_scope)
				    ref_scope = type_scope;
			      if (netclass_t*cls = ensure_visible_class_type(des, ref_scope,
								     td->name)) {
				    if (const parmvalue_t*overrides = type_ref->parameter_values())
					  cls = const_cast<netclass_t*>(
						elaborate_specialized_class_type(des, ref_scope,
										 cls, overrides));
				    cur->second.ivl_type = cls;
				    return;
			      }
			}
		  }
	    }
      }
}

void NetScope::evaluate_parameter_(Design*des, param_ref_t cur)
{

      // A value parameter is evaluated when it has a value, not merely when
      // its declared type has been elaborated. Expanded array elements carry
      // ivl_type before their expression is evaluated so nested assignment
      // patterns retain their context. Type parameters have no NetExpr value,
      // so their resolved ivl_type remains their completion marker.
      if (cur->second.val || (cur->second.type_flag && cur->second.ivl_type))
            return;

      if (cur->second.val_expr == 0) {
	      /* A parameterized class declaration is a template. Its generic
	       * master legitimately retains formals without defaults; only a
	       * concrete bare use or an incomplete specialization owes a missing-
	       * actual diagnostic. The latter paths create a specialized class
	       * scope, so give only the unspecialized master a type/value seed that
	       * lets its signatures be collected without rejecting the declaration
	       * itself (IEEE 1800-2017 8.25). */
	    const netclass_t*class_type = type_ == CLASS ? class_def_ : 0;
	    const NetScope*class_scope = class_type
		  ? class_type->class_scope() : 0;
	    const PClass*class_pform = class_scope
		  ? class_scope->class_pform() : 0;
	    if (class_type && !class_type->specialized_instance()
		&& class_pform && class_pform->has_parameter_port_list) {
		  if (cur->second.type_flag)
			cur->second.ivl_type = netvector_t::integer_type();
		  else {
			cur->second.ivl_type = netvector_t::integer_type();
			cur->second.val = new NetEConst(verinum(verinum::Vx));
		  }
		  return;
	    }

	    cerr << this->get_fileline() << ": error: "
	         << "Missing value for parameter `"
	         << cur->first << "`." << endl;
	    des->errors += 1;

	    cur->second.val = new NetEConst(verinum(verinum::Vx));
	    return;
      }

      if (cur->second.type_flag) {
	    /* Type-parameter aliases can be mutually recursive just like value
	     * parameters (type A=B, type B=A). Guard the type path before it
	     * follows another parameter; the old ordering entered
	     * evaluate_type_parameter_ ahead of the ordinary solving check and
	     * recursed until stack exhaustion. */
	    if (cur->second.solving) {
		  cerr << cur->second.get_fileline() << ": error: "
		       << "Recursive parameter reference found involving "
		       << cur->first << "." << endl;
		  des->errors += 1;
		  cur->second.ivl_type = netvector_t::integer_type();
		  return;
	    }
	    cur->second.solving = true;
	    evaluate_type_parameter_(des, cur);
	    cur->second.solving = false;
	    return;
      }

      ivl_type_t param_type = cur->second.ivl_type;

      // If the parameter type is present, then elaborate it now. Elaborate
      // the type in the current scope, and not the scope of the expression.
      if (cur->second.val_type) {
	    param_type = cur->second.val_type->elaborate_type(des, this);
	    cur->second.ivl_type = param_type;
	    cur->second.val_type = 0;
      }

	/* A typedef may carry the unpacked dimensions in its data type, rather
	   than in the parameter declarator's udims. Route it through the same
	   element-parameter representation as `parameter T P[N]`: indexed reads
	   depend on is_array_param, declared bounds, and the element type. */
      if (!cur->second.is_array_param && param_type) {
	    const netuarray_t*array_type =
		  dynamic_cast<const netuarray_t*>(param_type);
	    if (array_type && !array_type->static_dimensions().empty()) {
		  cur->second.is_array_param = true;
		  cur->second.array_dims = array_type->static_dimensions();
		  cur->second.array_bounds_known = true;
		  cur->second.ivl_type = array_type->element_type();
		  param_type = cur->second.ivl_type;
	    }
	    const netqueue_t*assoc_type =
		  dynamic_cast<const netqueue_t*>(param_type);
	    if (assoc_type && assoc_type->assoc_compat()) {
		  cur->second.is_array_param = true;
		  cur->second.is_assoc_param = true;
		  cur->second.array_type = const_cast<netqueue_t*>(assoc_type);
		  cur->second.ivl_type = assoc_type->element_type();
		  param_type = cur->second.ivl_type;
	    }
      }

      if (cur->second.is_array_param) {
	    evaluate_parameter_array_(des, cur);
	    return;
      }

      // Guess the varaiable type of the parameter. If the parameter has no
      // given type, then guess the type from the expression and use that to
      // evaluate (this is currently handled in evaluate_parameter_logic_()).
      ivl_variable_type_t use_type;
      if (param_type)
	    use_type = param_type->base_type();
      else
	    use_type = IVL_VT_NO_TYPE;

      if (cur->second.solving) {
            cerr << cur->second.get_fileline() << ": error: "
	         << "Recursive parameter reference found involving "
                 << cur->first << "." << endl;
	    des->errors += 1;

      } else {
            cur->second.solving = true;
            switch (use_type) {
                case IVL_VT_NO_TYPE:
                case IVL_VT_BOOL:
                case IVL_VT_LOGIC:
                  evaluate_parameter_logic_(des, cur);
                  break;

                case IVL_VT_REAL:
                  evaluate_parameter_real_(des, cur);
                  break;

		case IVL_VT_STRING:
		  evaluate_parameter_string_(des, cur);
		  break;

                default:
                  cerr << cur->second.get_fileline() << ": internal error: "
                       << "Unexpected parameter type " << use_type
                       << "." << endl;
                  cerr << cur->second.get_fileline() << ":               : "
                       << "Parameter name: " << cur->first << endl;
		  if (param_type)
			cerr << cur->second.get_fileline() << ":               : "
			     << "Parameter ivl_type: " << *param_type << endl;
                  cerr << cur->second.get_fileline() << ":               : "
                       << "Expression is: " << *cur->second.val_expr << endl;
                  ivl_assert(cur->second, 0);
                  break;
            }
            cur->second.solving = false;
      }

        // If we have failed to evaluate the expression, create a dummy
        // value. This prevents spurious error messages being output.
      if (cur->second.val == 0) {
            verinum val(verinum::Vx);
            cur->second.val = new NetEConst(val);
      }

        // Flag that the expression has been evaluated.
      cur->second.val_expr = 0;
}

void NetScope::evaluate_parameters(Design*des)
{
      for (map<hname_t,NetScope*>::const_iterator cur = children_.begin()
		 ; cur != children_.end() ; ++ cur )
	    cur->second->evaluate_parameters(des);

      if (debug_scopes)
	    cerr << "debug: "
		 << "Evaluating parameters in " << scope_path(this) << endl;

      for (param_ref_t cur = parameters.begin()
		 ; cur != parameters.end() ;  ++ cur) {

            evaluate_parameter_(des, cur);
      }
}

void Design::residual_defparams()
{
      for (list<NetScope*>::const_iterator scope = root_scopes_.begin();
	   scope != root_scopes_.end(); ++ scope )
	    (*scope)->residual_defparams(this);
}

void NetScope::residual_defparams(Design*des)
{
	// Clean out the list of defparams that never managed to match
	// a scope. Print a warning for each.
      while (! defparams_later.empty()) {
	    pair<list<hname_t>,PExpr*> cur = defparams_later.front();
	    defparams_later.pop_front();

	    cerr << cur.second->get_fileline() << ": warning: "
		 << "Scope of " << cur.first << " not found." << endl;
      }

      for (map<hname_t,NetScope*>::const_iterator cur = children_.begin()
		 ; cur != children_.end() ; ++ cur )
	    cur->second->residual_defparams(des);
}

const char* Design::get_flag(const string&key) const
{
      map<string,const char*>::const_iterator tmp = flags_.find(key);
      if (tmp == flags_.end())
	    return "";
      else
	    return (*tmp).second;
}

/*
 * This method looks for a signal (reg, wire, whatever) starting at
 * the specified scope. If the name is hierarchical, it is split into
 * scope and name and the scope used to find the proper starting point
 * for the real search.
 *
 * It is the job of this function to properly implement Verilog scope
 * rules as signals are concerned.
 */
NetNet* Design::find_signal(NetScope*scope, pform_name_t path)
{
      assert(scope);

      perm_string key = peek_tail_name(path);
      path.pop_back();
      if (! path.empty()) {
	      // This function's own contract for every other kind of miss
	      // is "return 0, say nothing" (see the fall-through at the
	      // end below) -- callers use it to PROBE whether a
	      // hierarchical name is a signal at all, most commonly a
	      // foreach loop target that falls back to ordinary expression
	      // elaboration when the answer is no (PForeach::elaborate()).
	      // A prefix that merely doesn't evaluate to a constant scope
	      // index (e.g. h[k].v where h is an ordinary array-of-struct
	      // variable and k is a foreach loop variable, not a
	      // module/generate-block instance selector) is exactly such a
	      // "no" and must not report a compile error out from under a
	      // caller that is only asking, not asserting.
	    list<hname_t> eval_path = eval_scope_path(this, scope, path, true);
	    scope = find_scope(scope, eval_path);
      }

      while (scope) {
	    if (NetNet*net = scope->find_signal(key))
		  return net;

	    if (PWire*wire = scope->find_signal_placeholder(key)) {
		  if (NetNet*net = wire->elaborate_sig(this, scope))
			return net;
	    }

	    if (NetScope*import_scope = scope->find_import(this, key)) {
		  scope = import_scope;
		  continue;
	    }

	    if (scope->type() == NetScope::MODULE)
		  break;

	    scope = scope->parent();
      }

      return 0;
}

NetFuncDef* Design::find_function(NetScope*scope, const pform_name_t&name,
				  bool search_up)
{
      assert(scope);

      std::list<hname_t> eval_path = eval_scope_path(this, scope, name);
      NetScope*func = search_up
	    ? find_scope(scope, eval_path, NetScope::FUNC)
	    : find_scope_(scope, eval_path, NetScope::FUNC);
      if (!func)
	    return elaborate_missing_package_function_scope_(this, scope, name);
	      if (func && (func->type() == NetScope::FUNC)) {
	              // If a function is used in a parameter definition or in
	              // a signal declaration, it is possible to get here before
	              // the function's signals have been elaborated. If this is
	              // the case, elaborate them now.
	            if (func->elab_stage() < 2) {
			  if (scope->need_const_func())
				func->need_const_func(true);
	                  const PFunction*pfunc = func->func_pform();
	                  assert(pfunc);
	                  pfunc->elaborate_sig(this, func);
            }
	    return func->func_def();
      }
      return 0;
}

NetScope* Design::find_task(NetScope*scope, const pform_name_t&name,
			    bool search_up)
{
      std::list<hname_t> eval_path = eval_scope_path(this, scope, name);
      NetScope*task = search_up
	    ? find_scope(scope, eval_path, NetScope::TASK)
	    : find_scope_(scope, eval_path, NetScope::TASK);
      if (task && (task->type() == NetScope::TASK))
	    return task;

      if (name.size() == 1)
	    return elaborate_missing_package_task_scope_(this, scope, name);

      return 0;
}

void Design::add_node(NetNode*net)
{
      assert(net->design_ == 0);
      if (nodes_ == 0) {
	    net->node_next_ = net;
	    net->node_prev_ = net;
      } else {
	    net->node_next_ = nodes_->node_next_;
	    net->node_prev_ = nodes_;
	    net->node_next_->node_prev_ = net;
	    net->node_prev_->node_next_ = net;
      }
      nodes_ = net;
      net->design_ = this;
}

void Design::del_node(NetNode*net)
{
      assert(net != 0);
      assert(net->design_ == this);

	/* Interact with the Design::functor method by manipulating the
	   cur and nxt pointers that it is using. */
      if (net == nodes_functor_nxt_)
	    nodes_functor_nxt_ = nodes_functor_nxt_->node_next_;
      if (net == nodes_functor_nxt_)
	    nodes_functor_nxt_ = 0;

      if (net == nodes_functor_cur_)
	    nodes_functor_cur_ = 0;

	/* Now perform the actual delete. */
      if (nodes_ == net)
	    nodes_ = net->node_prev_;

      if (nodes_ == net) {
	    nodes_ = 0;
      } else {
	    net->node_next_->node_prev_ = net->node_prev_;
	    net->node_prev_->node_next_ = net->node_next_;
      }

      net->design_ = 0;
}

void Design::add_branch(NetBranch*bra)
{
      bra->next_ = branches_;
      branches_ = bra;
}

void Design::add_process(NetProcTop*pro)
{
      ivl_unsafe_note_spawned_process();
      pro->next_ = procs_;
      procs_ = pro;
}

// I5 (Phase 62m): append at TAIL.  procs_ is a singly-linked list that
// add_process prepends to; for the small N typical of a design, walking
// to the tail to insert is cheap relative to elaboration.
void Design::add_process_at_tail(NetProcTop*pro)
{
      ivl_unsafe_note_spawned_process();
      pro->next_ = 0;
      if (!procs_) {
	    procs_ = pro;
      } else {
	    NetProcTop*cur = procs_;
	    while (cur->next_) cur = cur->next_;
	    cur->next_ = pro;
      }
}

void Design::add_process(NetAnalogTop*pro)
{
      ivl_unsafe_note_spawned_process();
      pro->next_ = aprocs_;
      aprocs_ = pro;
}
void Design::delete_process(NetProcTop*top)
{
      assert(top);
      if (procs_ == top) {
	    procs_ = top->next_;

      } else {
	    NetProcTop*cur = procs_;
	    while (cur->next_ != top) {
		  assert(cur->next_);
		  cur = cur->next_;
	    }

	    cur->next_ = top->next_;
      }

      if (procs_idx_ == top)
	    procs_idx_ = top->next_;

      delete top;
}

void Design::join_islands(void)
{
      if (nodes_ == 0)
	    return;

      NetNode*cur = nodes_->node_next_;
      do {
	    join_island(cur);
	    cur = cur->node_next_;
      } while (cur != nodes_->node_next_);
}
