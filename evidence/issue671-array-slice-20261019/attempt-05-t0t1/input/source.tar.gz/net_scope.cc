/*
 * Copyright (c) 2000-2025 Stephen Williams (steve@icarus.com)
 * Copyright (c) 2016 CERN Michele Castellana (michele.castellana@cern.ch)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include "config.h"
# include "compiler.h"

# include  "netlist.h"
# include  "netclass.h"
# include  "netenum.h"
# include  "netmisc.h"
# include  "netparray.h"
# include  "netqueue.h"
# include  "netvector.h"
# include  "PExpr.h"
# include  "PPackage.h"
# include  "PWire.h"
# include  <cstring>
# include  <cstdlib>
# include  <sstream>
# include  "ivl_assert.h"

using namespace std;

class PExpr;

Definitions::Definitions()
{
}

Definitions::~Definitions()
{
}

void Definitions::add_enumeration_set(const enum_type_t*key, netenum_t*enum_set)
{
      netenum_t*&tmp = enum_sets_[key];
      assert(tmp == 0);
      tmp = enum_set;
}

bool Definitions::add_enumeration_name(const netenum_t*enum_set, perm_string name)
{
      netenum_t::iterator enum_val = enum_set->find_name(name);
      assert(enum_val != enum_set->end_name());

      NetEConstEnum*val = new NetEConstEnum(name, enum_set, enum_val->second);

      pair<map<perm_string,NetEConstEnum*>::iterator, bool> cur;
      cur = enum_names_.insert(make_pair(name,val));

	// Return TRUE if the name is added (i.e. is NOT a duplicate.)
      return cur.second;
}

netenum_t* Definitions::enumeration_for_key(const enum_type_t*key) const
{
      map<const enum_type_t*,netenum_t*>::const_iterator cur;

      cur = enum_sets_.find(key);
      if (cur != enum_sets_.end())
	    return cur->second;
      else
	    return 0;
}

/*
 * This locates the VALUE for the given enumeration literal.
 */
const NetExpr* Definitions::enumeration_expr(perm_string key)
{
      map<perm_string,NetEConstEnum*>::const_iterator eidx;

      eidx = enum_names_.find(key);
      if (eidx != enum_names_.end()) {
	    return eidx->second;
      } else {
	    return 0;
      }
}

void Definitions::add_class(netclass_t*net_class)
{
      classes_[net_class->get_name()] = net_class;
      class_definitions_changed_();
}

void Definitions::class_definitions_changed_()
{
}

/*
 * The NetScope class keeps a scope tree organized. Each node of the
 * scope tree points to its parent, its right sibling and its leftmost
 * child. The root node has no parent or siblings. The node stores the
 * name of the scope. The complete hierarchical name of the scope is
 * formed by appending the path of scopes from the root to the scope
 * in question.
 */

NetScope::NetScope(NetScope*up, const hname_t&n, NetScope::TYPE t, NetScope*in_unit,
		   bool nest, bool program, bool interface, bool compilation_unit)
: type_(t), name_(n), nested_module_(nest), program_block_(program),
  is_interface_(interface), is_unit_(compilation_unit),
  module_definition_(0), generate_definition_(0), is_bind_instance_(false),
  unit_(in_unit), up_(up), target_scope_(0)
{
      imports_ = 0;
      events_ = 0;
      lcounter_ = 0;
      is_auto_ = false;
      is_disable_target_ = false;
      auto_frame_ = true;
      is_cell_ = false;
      calls_stask_ = false;
      in_final_ = false;

      if (compilation_unit)
	    unit_ = this;

      if (up) {
            need_const_func_ = up->need_const_func_;
            is_const_func_ = up->is_const_func_;
            time_unit_ = up->time_unit();
            time_prec_ = up->time_precision();
            time_from_timescale_ = up->time_from_timescale();
              // Need to check for duplicate names?
            up_->children_[name_] = this;
            if (unit_ == 0)
                  unit_ = up_->unit_;
      } else {
	    need_const_func_ = false;
	    is_const_func_ = false;
            time_unit_ = 0;
            time_prec_ = 0;
            time_from_timescale_ = false;
      }

        // A caller's constant-evaluation state is meaningful for nested
        // procedural blocks, not for newly declared symbols. Package/class
        // scopes and task/function scopes may be materialized on demand while
        // some unrelated caller is in a constant context; inheriting that
        // transient state causes ordinary runtime methods to elaborate as
        // constant functions.
      switch (t) {
          case NetScope::MODULE:
          case NetScope::PACKAGE:
          case NetScope::CLASS:
          case NetScope::TASK:
          case NetScope::FUNC:
            need_const_func_ = false;
            is_const_func_ = false;
            break;
          default:
            break;
      }

      var_init_ = 0;
      switch (t) {
	  case NetScope::TASK:
	    task_ = 0;
	    break;
	  case NetScope::FUNC:
	    func_ = 0;
	    break;
	  case NetScope::MODULE:
	  case NetScope::PACKAGE:
	    module_name_ = perm_string();
	    break;
	  case NetScope::CLASS:
	    class_def_ = 0;
	    break;
	  default:  /* BEGIN_END and FORK_JOIN, do nothing */
	    break;
      }
      func_pform_ = 0;
      task_pform_ = 0;
      class_pform_ = 0;
      elab_stage_ = 1;
      lineno_ = 0;
      def_lineno_ = 0;
      genvar_tmp_val = 0;
      loop_index_net_tmp = 0;
      tie_hi_ = 0;
      tie_lo_ = 0;
}

const PGModule* NetScope::reserve_bind_instance_name(
      perm_string name, const PGModule*gate)
{
      pair<map<perm_string,const PGModule*>::iterator,bool> result
            = bind_instance_names_.insert(make_pair(name, gate));
      return result.first->second;
}

NetScope::~NetScope()
{
      lcounter_ = 0;

	/* name_ and module_name_ are perm-allocated. */
}

void NetScope::set_line(const LineInfo*info)
{
      file_ = info->get_file();
      def_file_ = file_;
      lineno_ = info->get_lineno();
      def_lineno_ = lineno_;
}

void NetScope::set_line(perm_string file, unsigned lineno)
{
      file_ = file;
      def_file_ = file;
      lineno_ = lineno;
      def_lineno_ = lineno;
}

string NetScope::get_fileline() const
{
      ostringstream buf;
      buf << (file_? file_ : "") << ":" << lineno_;
      string res = buf.str();
      return res;
}

string NetScope::get_def_fileline() const
{
      ostringstream buf;
      buf << (def_file_? def_file_ : "") << ":" << def_lineno_;
      string res = buf.str();
      return res;
}

void NetScope::set_line(perm_string file, perm_string def_file,
                        unsigned lineno, unsigned def_lineno)
{
      file_ = file;
      def_file_ = def_file;
      lineno_ = lineno;
      def_lineno_ = def_lineno;
}

void NetScope::add_imports(const map<perm_string,PPackage*>*imports)
{
      if (!imports->empty())
	    imports_ = imports;
      clear_lookup_caches_(true, true);
}

NetScope*NetScope::find_import(const Design*des, perm_string name)
{
      if (imports_ == 0)
	    return 0;

      map<perm_string,PPackage*>::const_iterator cur = imports_->find(name);
      if (cur != imports_->end()) {
            return des->find_package(cur->second->pscope_name());
      } else
            return 0;
}

void NetScope::add_typedefs(const map<perm_string,typedef_t*>*typedefs)
{
      if (!typedefs->empty())
	    typedefs_ = *typedefs;
      clear_lookup_caches_(true, false);
}

void NetScope::class_definitions_changed_()
{
      clear_lookup_caches_(false, true);
}

void NetScope::clear_lookup_caches_(bool clear_typedefs, bool clear_classes)
{
      if (clear_typedefs)
	    typedef_search_cache_.clear();
      if (clear_classes)
	    class_search_cache_.clear();

      for (map<hname_t,NetScope*>::iterator cur = children_.begin()
		 ; cur != children_.end() ; ++cur) {
	    if (cur->second)
		  cur->second->clear_lookup_caches_(clear_typedefs, clear_classes);
      }
}

void NetScope::release_elaboration_caches()
{
      typedef_search_cache_.clear();
      class_search_cache_.clear();

	/* These maps only index borrowed parse-form declarations. Every signal,
	 * let expansion, post-elaboration functor and netlist dump is complete at
	 * this terminal boundary; target callbacks consume elaborated Net* objects
	 * and never consult these source-name indexes. */
      signal_placeholders_.clear();
      lets_.clear();

      if (type_ == FUNC && func_)
	    func_->release_port_defaults();
      if (type_ == TASK && task_)
	    task_->release_port_defaults();

      for (map<hname_t,NetScope*>::iterator cur = children_.begin()
		 ; cur != children_.end() ; ++cur) {
	    if (cur->second)
		  cur->second->release_elaboration_caches();
      }
}

size_t NetScope::release_signal_connectivity()
{
      size_t released = 0;
      for (signals_map_iter_t cur = signals_map_.begin()
                 ; cur != signals_map_.end() ; ++cur) {
            if (cur->second)
                  released += cur->second->release_terminal_connectivity();
      }

      for (map<hname_t,NetScope*>::iterator cur = children_.begin()
                 ; cur != children_.end() ; ++cur) {
            if (cur->second)
                  released += cur->second->release_signal_connectivity();
      }
      return released;
}

NetScope*NetScope::find_typedef_scope(const Design*des, const typedef_t*type)
{
      ivl_assert(*this, type);

      auto find_in_super_chain = [type](NetScope*scope) -> NetScope* {
	    if (!scope || scope->type() != NetScope::CLASS)
		  return 0;
	    const netclass_t*cls = scope->class_def();
	    if (!cls)
		  return 0;
	    for (const netclass_t*sup = cls->get_super(); sup; sup = sup->get_super()) {
		  const NetScope*sup_scope_const = sup->class_scope();
		  NetScope*sup_scope = const_cast<NetScope*>(sup_scope_const);
		  if (!sup_scope)
			continue;
		  auto it = sup_scope->typedefs_.find(type->name);
		  if (it != sup_scope->typedefs_.end() && it->second == type)
			return sup_scope;
	    }
	    return 0;
      };

      auto find_in_interface_graph = [type](NetScope*scope) -> NetScope* {
	    if (!scope || scope->type() != NetScope::CLASS)
		  return 0;
	    const netclass_t*cls = scope->class_def();
	    if (!cls || !cls->is_interface_class())
		  return 0;

	    std::vector<const netclass_t*>pending(cls->interface_types());
	    std::set<const netclass_t*>seen;
	    while (!pending.empty()) {
		  const netclass_t*parent = pending.back();
		  pending.pop_back();
		  if (!parent || !seen.insert(parent).second)
			continue;
		  NetScope*parent_scope =
			const_cast<NetScope*>(parent->class_scope());
		  if (parent_scope) {
			auto it = parent_scope->typedefs_.find(type->name);
			if (it != parent_scope->typedefs_.end()
			    && it->second == type)
			      return parent_scope;
		  }
		  pending.insert(pending.end(), parent->interface_types().begin(),
				 parent->interface_types().end());
	    }
	    return 0;
      };

      NetScope *cur_scope = this;
      while (cur_scope) {
	    auto it = cur_scope->typedefs_.find(type->name);
	    if (it != cur_scope->typedefs_.end() && it->second == type)
		  return cur_scope;
	    if (NetScope*sup_scope = find_in_super_chain(cur_scope))
		  return sup_scope;
	    if (NetScope*interface_scope = find_in_interface_graph(cur_scope))
		  return interface_scope;
	    NetScope*import_scope = cur_scope->find_import(des, type->name);
	    if (import_scope)
		  cur_scope = import_scope;
	    else if (cur_scope == unit_)
		  break;
	    else
		  cur_scope = cur_scope->parent();

	    if (cur_scope == 0)
		  cur_scope = unit_;
      }

      /* A package-qualified type does not need to be imported into the
	 consuming scope. The caller nevertheless has the exact typedef_t that
	 owns a borrowed declaration expression (for example an unpacked-struct
	 member default), so locate that definition directly in a package. Keep
	 this pointer-identity search ahead of, and separate from, the visible
	 name-only recovery below: an unrelated package typedef with the same
	 name must never change ordinary lookup or shadowing semantics. */
      for (NetScope*package_scope : des->find_package_scopes()) {
	    auto it = package_scope->typedefs_.find(type->name);
	    if (it != package_scope->typedefs_.end() && it->second == type)
		  return package_scope;
      }

      // Some SV paths synthesize equivalent typedef_t wrappers (not pointer
      // identical to the scope entry). Fall back to the nearest visible name.
      cur_scope = this;
      while (cur_scope) {
	    auto it = cur_scope->typedefs_.find(type->name);
	    if (it != cur_scope->typedefs_.end())
		  return cur_scope;
	    if (cur_scope->type() == NetScope::CLASS) {
		  const netclass_t*cls = cur_scope->class_def();
		  for (const netclass_t*sup = cls ? cls->get_super() : 0;
		       sup; sup = sup->get_super()) {
			const NetScope*sup_scope_const = sup->class_scope();
			NetScope*sup_scope = const_cast<NetScope*>(sup_scope_const);
			if (!sup_scope)
			      continue;
			auto sup_it = sup_scope->typedefs_.find(type->name);
			if (sup_it != sup_scope->typedefs_.end())
			      return sup_scope;
		  }
		  if (cls && cls->is_interface_class()) {
			std::vector<const netclass_t*>pending(cls->interface_types());
			std::set<const netclass_t*>seen;
			while (!pending.empty()) {
			      const netclass_t*parent = pending.back();
			      pending.pop_back();
			      if (!parent || !seen.insert(parent).second)
				    continue;
			      NetScope*parent_scope = const_cast<NetScope*>(
				    parent->class_scope());
			      if (parent_scope) {
				    auto parent_it = parent_scope->typedefs_.find(type->name);
				    if (parent_it != parent_scope->typedefs_.end())
					  return parent_scope;
			      }
			      pending.insert(pending.end(),
				    parent->interface_types().begin(),
				    parent->interface_types().end());
			}
		  }
	    }
	    NetScope*import_scope = cur_scope->find_import(des, type->name);
	    if (import_scope)
		  cur_scope = import_scope;
	    else if (cur_scope == unit_)
		  return 0;
	    else
		  cur_scope = cur_scope->parent();

	    if (cur_scope == 0)
		  cur_scope = unit_;
      }

      return 0;
}

/*
 * Attach to the a parameter name in the scope a value and a type. The value
 * (val_expr) is the PExpr form that is not yet elaborated. Later, when
 * elaboration happens, val_expr is elaborated and written to val, then
 * cleared. source_expr retains the borrowed parse form for provenance-only
 * uses such as parameterized-class specialization identity.
 */
void NetScope::set_parameter(perm_string key, bool is_annotatable,
			     const LexicalScope::param_expr_t &param,
			     NetScope::range_t *range_list)
{
      param_expr_t&ref = parameters[key];
      ref.is_annotatable = is_annotatable;
      ref.val_expr = param.expr;
      ref.source_expr = param.expr;
      ref.val_type = param.data_type;
      ref.val_scope = this;
      ref.source_scope = this;
      ref.local_flag = param.local_flag;
      ref.overridable = param.overridable;
      ref.type_flag = param.type_flag;
      ref.lexical_pos = param.lexical_pos;
      ref.is_array_param = (param.udims != nullptr && !param.udims->empty());
      ref.is_assoc_param = false;
	if (param.udims) {
	      for (std::list<pform_range_t>::const_iterator cur = param.udims->begin()
			 ; cur != param.udims->end() ; ++cur) {
		    if (dynamic_cast<const PEAssocType*>(cur->first)) {
			  ref.is_assoc_param = true;
			  break;
		    }
	      }
	}
	ref.array_type = nullptr;
      ref.udims = param.udims;
      ivl_assert(param, !ref.range);
      ref.range = range_list;
      ref.val = 0;
      ref.ivl_type = 0;
      ref.set_line(param);
}

/*
 * This is a simplified version of set_parameter, for use when the
 * parameter value is already known. It is currently only used to
 * add a genvar to the parameter list.
 */
void NetScope::set_parameter(perm_string key, NetExpr*val,
			     const LineInfo&file_line)
{
      param_expr_t&ref = parameters[key];
      ref.is_annotatable = false;
      ref.val_expr = 0;
      ref.source_expr = 0;
      ref.val_type = 0;
      ref.val_scope = this;
      ref.source_scope = this;
      ref.ivl_type = netvector_t::integer_type();
      ivl_assert(file_line, ref.ivl_type);
      ref.val = val;
      ref.set_line(file_line);
}

void NetScope::release_parameters()
{
      for (map<perm_string,param_expr_t>::iterator cur = parameters.begin()
		 ; cur != parameters.end() ; ++cur) {
	    param_expr_t&param = cur->second;
	    delete param.val;

	    range_t*range = param.range;
	    while (range) {
		  range_t*next = range->next;
		  if (range->high_expr != range->low_expr)
			delete range->high_expr;
		  delete range->low_expr;
		  delete range;
		  range = next;
	    }
	}

	/* Clearing the records releases their map nodes and array-dimension
	 * vectors. val_expr, source_expr, val_type, udims and ivl_type are
	 * deliberately not deleted: they are borrowed pform or shared
	 * elaborated-type pointers. */
      parameters.clear();
}

bool NetScope::auto_name(const char*prefix, char pad, const char* suffix)
{
	// Find the current reference to myself in the parent scope.
      map<hname_t,NetScope*>::iterator self = up_->children_.find(name_);
      ivl_assert(*this, self != up_->children_.end());
      ivl_assert(*this, self->second == this);

	// This is to keep the pad attempts from being stuck in some
	// sort of infinite loop. This should not be a practical
	// limit, but an extreme one.
      const size_t max_pad_attempts = 32 + strlen(prefix);

      string use_prefix = prefix;

	// Try a variety of potential new names. Make sure the new
	// name is not in the parent scope. Keep looking until we are
	// sure we have a unique name, or we run out of names to try.
      while (use_prefix.size() <= max_pad_attempts) {
	      // Try this name...
	    string tmp = use_prefix + suffix;
	    perm_string base_name = lex_strings.make(tmp.c_str());
	    hname_t new_name(base_name, name_.peek_numbers());
	    if (!up_->child(new_name) && !up_->symbol_exists(base_name)) {
		    // Ah, this name is unique. Rename myself, and
		    // change my name in the parent scope.
		  name_ = new_name;
		  up_->children_.erase(self);
		  up_->children_[name_] = this;
		  return true;
	    }

	      // Name collides, so try a different name.
	    use_prefix = use_prefix + pad;
      }
      return false;
}

/*
 * Return false if the parameter does not already exist.
 * A parameter is not automatically created.
 */
void NetScope::replace_parameter(Design *des, perm_string key, PExpr*val,
			         NetScope*scope, bool defparam)
{
      if (parameters.find(key) == parameters.end()) {
	    cerr << val->get_fileline() << ": error: parameter `"
	         << key << "` not found in `"
	         << scope_path(this) << "`." << endl;
	    des->errors++;
	    return;
      }

      param_expr_t&ref = parameters[key];
      if (ref.local_flag) {
	    cerr << val->get_fileline() << ": error: "
	         << "Cannot override localparam `" << key << "` in `"
	         << scope_path(this) << "`." << endl;
	    des->errors++;
	    return;
      }
      if (!ref.overridable) {
	    cerr << val->get_fileline() << ": error: "
		 << "Cannot override parameter `" << key << "` in `"
		 << scope_path(this) << "`. Parameter cannot be overridden "
		 << "in the scope it has been declared in."
		 << endl;
	    des->errors++;
	    return;
      }

      if (ref.type_flag && defparam) {
	    cerr << val->get_fileline() << ": error: "
		 << "Cannot override type parameter `" << key << "` in `"
		 << scope_path(this) << "`. It is not allowed to override type"
		 << " parameters using a defparam statement."
		 << endl;
	    des->errors++;
	    return;
      }

      ref.val_expr = val;
      ref.val_scope = scope;
      ref.source_expr = val;
      ref.source_scope = scope;
      if (defparam)
	    ref.defparam_source_scopes.insert(scope);
}

bool NetScope::make_parameter_unannotatable(perm_string key)
{
      bool flag = false;

      if (parameters.find(key) != parameters.end()) {
	    param_expr_t&ref = parameters[key];
	    flag = ref.is_annotatable;
	    ref.is_annotatable = false;
      }

      return flag;
}

bool NetScope::parameter_is_specparam(perm_string key) const
{
      map<perm_string,param_expr_t>::const_iterator cur = parameters.find(key);
      return cur != parameters.end() && cur->second.is_annotatable;
}

/*
 * NOTE: This method takes a const char* as a key to lookup a
 * parameter, because we don't save that pointer. However, due to the
 * way the map<> template works, we need to *cheat* and use the
 * perm_string::literal method to fake the compiler into doing the
 * compare without actually creating a perm_string.
 */
const NetExpr* NetScope::get_parameter(Design*des, const char* key,
				       ivl_type_t&ivl_type)
{
      return get_parameter(des, perm_string::literal(key), ivl_type);
}

const NetExpr* NetScope::get_parameter(Design*des, perm_string key,
				       ivl_type_t&ivl_type)
{
      map<perm_string,param_expr_t>::iterator idx;

      idx = parameters.find(key);
      if (idx != parameters.end()) {
            if (idx->second.val_expr)
                  evaluate_parameter_(des, idx);

	    ivl_type = idx->second.ivl_type;
	    return idx->second.val;
      }

      ivl_type = 0;
      const NetExpr*tmp = enumeration_expr(key);
      return tmp;
}

LineInfo NetScope::get_parameter_line_info(perm_string key) const
{
      map<perm_string,param_expr_t>::const_iterator idx;

      idx = parameters.find(key);
      if (idx != parameters.end()) return idx->second;

	// To get here the parameter must already exist, so we should
	// never get here.
      assert(0);
	// But return something to avoid a compiler warning.
      return LineInfo();
}

bool NetScope::is_array_parameter(perm_string key) const
{
      map<perm_string,param_expr_t>::const_iterator idx = parameters.find(key);
      if (idx == parameters.end()) return false;
      return idx->second.is_array_param;
}

unsigned NetScope::get_parameter_lexical_pos(perm_string key) const
{
      map<perm_string,param_expr_t>::const_iterator idx;

      idx = parameters.find(key);
      if (idx != parameters.end()) return idx->second.lexical_pos;

	// If we get here, assume an enumeration value.
      return 0;
}

void NetScope::print_type(ostream&stream) const
{
      switch (type_) {
	case BEGIN_END:
	    stream << "sequential block";
	    break;
	case FORK_JOIN:
	    stream << "parallel block";
	    break;
	case FUNC:
	    stream << "function";
	    break;
	case MODULE:
	    stream << "module <" << module_name_ << "> instance";
	    break;
	case TASK:
	    stream << "task";
	    break;
	case GENBLOCK:
	    stream << "generate block";
	    break;
	case PACKAGE:
	    stream << "package " << module_name_;
	    break;
	case CLASS:
	    stream << "class";
	    break;
      }
}

void NetScope::set_task_def(NetTaskDef*def)
{
      ivl_assert(*this, type_ == TASK);
      ivl_assert(*this, task_ == nullptr);
      task_ = def;
}

NetTaskDef* NetScope::task_def()
{
      ivl_assert(*this, type_ == TASK);
      return task_;
}

const NetTaskDef* NetScope::task_def() const
{
      ivl_assert(*this, type_ == TASK);
      return task_;
}

void NetScope::set_func_def(NetFuncDef*def)
{
      ivl_assert(*this, type_ == FUNC);
      ivl_assert(*this, func_ == nullptr);
      func_ = def;
}

NetFuncDef* NetScope::func_def()
{
      ivl_assert(*this, type_ == FUNC);
      return func_;
}

bool NetScope::in_func() const
{
      return (type_ == FUNC) ? true : false;
}

const NetFuncDef* NetScope::func_def() const
{
      ivl_assert(*this, type_ == FUNC);
      return func_;
}

void NetScope::set_class_def(netclass_t*def)
{
      ivl_assert(*this, type_ == CLASS);
      ivl_assert(*this, class_def_ == nullptr);
      class_def_ = def;
}

const netclass_t* NetScope::class_def(void) const
{
      if (type_==CLASS)
	    return class_def_;
      else
	    return 0;
}

void NetScope::set_module_name(perm_string n)
{
      ivl_assert(*this, type_==MODULE || type_==PACKAGE);
      module_name_ = n;
}

perm_string NetScope::module_name() const
{
      ivl_assert(*this, type_==MODULE || type_==PACKAGE);
      return module_name_;
}

void NetScope::set_num_ports(unsigned int num_ports)
{
    ivl_assert(*this, type_ == MODULE);
    ivl_assert(*this, ports_.empty());
    ports_.resize( num_ports );
}

void NetScope::add_module_port_net(NetNet*subport)
{
      ivl_assert(*this, type_ == MODULE);
      port_nets.push_back(subport);
}


void NetScope::add_module_port_info( unsigned idx, perm_string name, PortType::Enum ptype,
                                unsigned long width )
{
      ivl_assert(*this, type_ == MODULE);
      ivl_assert(*this, ports_.size() > idx);
      PortInfo &info = ports_[idx];
      info.name = name;
      info.type = ptype;
      info.width = width;
      info.buffer = nullptr;
}

PortInfo* NetScope::get_module_port_info( unsigned idx )
{
      ivl_assert(*this, type_ == MODULE);
      ivl_assert(*this, ports_.size() > idx);
      return &ports_[idx];
}

unsigned NetScope::module_port_nets() const
{
      ivl_assert(*this, type_ == MODULE);
      return port_nets.size();
}


const std::vector<PortInfo> & NetScope::module_port_info() const
{
      ivl_assert(*this, type_ == MODULE);
      return ports_;
}



NetNet* NetScope::module_port_net(unsigned idx) const
{
      ivl_assert(*this, type_ == MODULE);
      ivl_assert(*this, idx < port_nets.size());
      return port_nets[idx];
}

void NetScope::time_unit(int val)
{
      time_unit_ = val;
}

void NetScope::time_precision(int val)
{
      time_prec_ = val;
}

void NetScope::time_from_timescale(bool val)
{
      time_from_timescale_ = val;
}

int NetScope::time_unit() const
{
      return time_unit_;
}

int NetScope::time_precision() const
{
      return time_prec_;
}

bool NetScope::time_from_timescale() const
{
      return time_from_timescale_;
}

perm_string NetScope::basename() const
{
      return name_.peek_name();
}

void NetScope::add_event(NetEvent*ev)
{
      ivl_assert(*this, ev->scope_ == nullptr);
      ev->scope_ = this;
      ev->snext_ = events_;
      events_ = ev;
}

void NetScope::rem_event(NetEvent*ev)
{
      ivl_assert(*this, ev->scope_ == this);
      ev->scope_ = 0;
      if (events_ == ev) {
	    events_ = ev->snext_;

      } else {
	    NetEvent*cur = events_;
	    while (cur->snext_ != ev) {
		  ivl_assert(*this, cur->snext_);
		  cur = cur->snext_;
	    }
	    cur->snext_ = ev->snext_;
      }

      ev->snext_ = 0;
}


NetEvent* NetScope::find_event(perm_string name)
{
      for (NetEvent*cur = events_;  cur ;  cur = cur->snext_)
	    if (cur->name() == name)
		  return cur;

      return 0;
}

void NetScope::add_genvar(perm_string name, LineInfo *li)
{
      ivl_assert(*li, (type_ == MODULE) || (type_ == GENBLOCK));
      genvars_[name] = li;
}

LineInfo* NetScope::find_genvar(perm_string name)
{
      map<perm_string,LineInfo*>::iterator it = genvars_.find(name);
      return it != genvars_.end()? it->second : 0;
}

void NetScope::add_signal_placeholder(PWire*wire)
{
      signal_placeholders_[wire->basename()] = wire;
}

void NetScope::rem_signal_placeholder(const PWire*wire)
{
      signal_placeholders_.erase(wire->basename());
}

// I2 (Phase 62m): post-elab signal type repair.  Walk all NetNets in
// this scope; for any NetNet whose net_type is not a class but whose
// originating PWire's data_type was a typeref to a CLASS-typedef, try
// to resolve the class type now (after all classes are visible) and
// patch the NetNet via set_net_type.  Without this, package-global
// class handles like `uvm_default_table_printer` end up with a logic
// vector type and assignments to them silently no-op at runtime.
void NetScope::repair_typed_class_signals(Design*des)
{
      if (!des) return;

      if (const netclass_t*class_type = class_def())
	    const_cast<netclass_t*>(class_type)
		  ->repair_bare_class_property_types(des);

      for (auto&kv : signals_map_) {
	    NetNet*sig = kv.second;
	    if (!sig) continue;

	    // A forward class declaration can already have produced a class
	    // placeholder, so the old logic-vector-only repair below will not
	    // see it. Reapply bare C => C#() normalization now that every class
	    // scope is registered. NetNet stores fixed unpacked dimensions
	    // separately, so this repairs scalar and fixed-array element types.
	    if (PWire*pw = find_signal_placeholder(kv.first)) {
		  /* Probe with a null stored type so an already-specialized but
		   * provisional forward element cannot short-circuit the bare-type
		   * detector.  Once confirmed, re-elaborate the complete declaration
		   * instead of rebuilding one container layer by hand; this preserves
		   * arbitrarily nested fixed/dynamic/queue/associative wrappers. */
		  ivl_type_t bare_default = specialize_bare_class_at_concrete_use(
			des, this, pw->data_type(), 0, false);
		  if (bare_default) {
			ivl_type_t repaired_type = pw->elaborate_sig_type(des, this);
			/* NetNet stores every fixed unpacked dimension separately and
			 * keeps only the first non-fixed container (or scalar) here. */
			while (const netuarray_t*fixed =
			       dynamic_cast<const netuarray_t*>(repaired_type))
			      repaired_type = fixed->element_type();
			if (repaired_type)
			      sig->set_net_type(repaired_type);
		  }
	    }

	    // Only patch logic-vector signals.  Class types, queues,
	    // strings, reals, etc. all have non-LOGIC base — the
	    // fallback netvector_t that this fix targets is specifically
	    // IVL_VT_LOGIC.
	    if (!sig->net_type()) continue;
	    if (ivl_type_base(sig->net_type()) != IVL_VT_LOGIC) continue;
	    if (sig->unpacked_dimensions() > 0) continue;

	    // Find the originating PWire to inspect its declared type.
	    PWire*pw = find_signal_placeholder(kv.first);
	    if (!pw) continue;

	    const data_type_t*dt = pw->data_type();
	    if (!dt) continue;

	    // Only repair typeref-to-class.  Other forms (atom_type_t,
	    // string_type_t, vector_type_t, etc.) are not class-handle
	    // signals and should keep their resolved type.
	    const typeref_t*tr = dynamic_cast<const typeref_t*>(dt);
	    if (!tr) continue;

	    typedef_t*td = tr->typedef_ref();
	    if (!td) continue;
	    if (td->get_basic_type() != typedef_t::CLASS) continue;

	    // Re-elaborate the exact declared type, including explicit class
	    // parameter overrides. A name-only lookup here would turn a late
	    // C#(4) handle into generic C and silently lose its specialization.
	    ivl_type_t repaired_type = pw->elaborate_sig_type(des, this);
	    while (const netuarray_t*fixed =
		   dynamic_cast<const netuarray_t*>(repaired_type))
		  repaired_type = fixed->element_type();
	    if (repaired_type)
		  sig->set_net_type(repaired_type);
      }

      // Recurse into children.  Class scopes contain their own static
      // properties; module scopes contain instance signals.
      for (auto&ch : children_) {
	    if (ch.second)
		  ch.second->repair_typed_class_signals(des);
      }
}

PWire* NetScope::find_signal_placeholder(perm_string name)
{
      map<perm_string,PWire*>::iterator it = signal_placeholders_.find(name);
      return it != signal_placeholders_.end()? it->second : 0;
}

void NetScope::add_signal(NetNet*net)
{
      signals_map_[net->name()]=net;
}

void NetScope::rem_signal(NetNet*net)
{
      ivl_assert(*this, net->scope() == this);
      signals_map_.erase(net->name());
}

/*
 * This method looks for a signal within the current scope. The name
 * is assumed to be the base name of the signal, so no sub-scopes are
 * searched.
 */
NetNet* NetScope::find_signal(perm_string key)
{
      map<perm_string,NetNet*>::iterator it = signals_map_.find(key);
      return it != signals_map_.end()? it->second : 0;
}

NetNet* NetScope::set_signal_alias(perm_string name, NetNet*net)
{
      NetNet*prev = find_signal(name);
      signals_map_[name] = net;
	// The symbol_search() cache assumes ordinary declarations, which
	// are stable once found; this alias is deliberately transient
	// (see the comment at the declaration), so any cached resolution
	// of this name is now stale.
      symbol_search_cache_clear();
      return prev;
}

void NetScope::restore_signal_alias(perm_string name, NetNet*prev)
{
      if (prev)
	    signals_map_[name] = prev;
      else
	    signals_map_.erase(name);
	// Undoes the alias installed above; the cache may again hold
	// resolutions computed while it was in effect.
      symbol_search_cache_clear();
}

typedef_t* NetScope::find_typedef(const Design*des, perm_string name)
{
      map<perm_string,typedef_t*>::const_iterator cache_td = typedef_search_cache_.find(name);
      if (cache_td != typedef_search_cache_.end())
	    return cache_td->second;

      struct typedef_search_guard_t {
	    explicit typedef_search_guard_t(std::set<perm_string>&active, perm_string key)
	    : active_(active), key_(key), owner_(active_.insert(key_).second) { }
	    ~typedef_search_guard_t()
	    {
		  if (owner_)
			active_.erase(key_);
	    }
	    bool owner() const { return owner_; }
	  private:
	    std::set<perm_string>&active_;
	    perm_string key_;
	    bool owner_;
      } search_guard(typedef_search_active_, name);

      if (!search_guard.owner())
	    return 0;

      map<perm_string,typedef_t*>::const_iterator td = typedefs_.find(name);
      if (td != typedefs_.end()) {
	    typedef_search_cache_[name] = td->second;
	    return td->second;
      }

      typedef_t*res = 0;

      if (type_ == CLASS && class_def_ && class_def_->get_super()) {
	    const NetScope*sup_scope = class_def_->get_super()->class_scope();
	    ivl_assert(*this, sup_scope);
	    typedef_t*sup_td = const_cast<NetScope*>(sup_scope)->find_typedef(des, name);
	    if (sup_td)
		  res = sup_td;
      }

      if (!res && type_ == CLASS && class_def_
	  && class_def_->is_interface_class()) {
	    std::vector<const netclass_t*>pending(class_def_->interface_types());
	    std::set<const netclass_t*>seen;
	    while (!pending.empty() && !res) {
		  const netclass_t*parent = pending.back();
		  pending.pop_back();
		  if (!parent || !seen.insert(parent).second)
			continue;
		  NetScope*parent_scope = const_cast<NetScope*>(
			parent->class_scope());
		  if (parent_scope) {
			auto local = parent_scope->typedefs_.find(name);
			if (local != parent_scope->typedefs_.end())
			      res = local->second;
		  }
		  pending.insert(pending.end(), parent->interface_types().begin(),
				 parent->interface_types().end());
	    }
      }

      if (!res) {
	      // Try the imports.
	    NetScope*import_scope = find_import(des, name);
	    if (import_scope)
		  res = import_scope->find_typedef(des, name);
      }

      if (!res && up_==0 && type_==CLASS) {
	    ivl_assert(*this, class_def_);

	    NetScope*def_parent = class_def_->definition_scope();
	    res = def_parent->find_typedef(des, name);
      }

	// Try looking up for the typedef.
      if (!res && up_!=0 && type_!=MODULE) {
	    res = up_->find_typedef(des, name);
      }

	// Try the compilation unit.
      if (!res && unit_ != 0 && this != unit_) {
	    res = unit_->find_typedef(des, name);
      }

      typedef_search_cache_[name] = res;
      return res;
}

netclass_t*NetScope::find_class(const Design*des, perm_string name)
{
      map<perm_string,netclass_t*>::const_iterator cache_it = class_search_cache_.find(name);
      if (cache_it != class_search_cache_.end())
	    return cache_it->second;

      struct class_search_guard_t {
	    explicit class_search_guard_t(std::set<perm_string>&active, perm_string key)
	    : active_(active), key_(key), owner_(active_.insert(key_).second) { }
	    ~class_search_guard_t()
	    {
		  if (owner_)
			active_.erase(key_);
	    }
	    bool owner() const { return owner_; }
	  private:
	    std::set<perm_string>&active_;
	    perm_string key_;
	    bool owner_;
      } search_guard(class_search_active_, name);

      if (!search_guard.owner())
	    return 0;

	// Special case: The scope itself is the class that we are
	// looking for. This may happen for example when elaborating
	// methods within the class.
      if (type_==CLASS && class_def_) {
	    if (name_==hname_t(name) || class_def_->get_name() == name) {
		  class_search_cache_[name] = class_def_;
		  return class_def_;
	    }
      }

	// Look for the class directly within this scope.
      map<perm_string,netclass_t*>::const_iterator cur = classes_.find(name);
      if (cur != classes_.end()) {
	    class_search_cache_[name] = cur->second;
	    return cur->second;
      }

	// A class-typed parameter/type-parameter can also be used as a class name.
      ivl_type_t param_type = 0;
      (void) get_parameter(const_cast<Design*>(des), name, param_type);
      if (const netclass_t*param_class = dynamic_cast<const netclass_t*>(param_type)) {
	    class_search_cache_[name] = const_cast<netclass_t*>(param_class);
	    return const_cast<netclass_t*>(param_class);
      }

        // Try the imports.
      NetScope*import_scope = find_import(des, name);
      if (import_scope) {
            netclass_t*res = import_scope->find_class(des, name);
            class_search_cache_[name] = res;
            return res;
      }

      if (up_==0 && type_==CLASS) {
	    ivl_assert(*this, class_def_);

	    NetScope*def_parent = class_def_->definition_scope();
	    netclass_t*res = def_parent->find_class(des, name);
	    class_search_cache_[name] = res;
	    return res;
      }

	// Try looking up for the class.
      if (up_!=0 && type_!=MODULE) {
	    netclass_t*res = up_->find_class(des, name);
	    class_search_cache_[name] = res;
	    return res;
      }

	// Try the compilation unit.
      if (unit_ != 0 && this != unit_) {
	    netclass_t*res = unit_->find_class(des, name);
	    class_search_cache_[name] = res;
	    return res;
      }

	// Nowhere left to try...
      class_search_cache_[name] = 0;
      return 0;
}

/*
 * This method locates a child scope by name. The name is the simple
 * name of the child, no hierarchy is searched.
 */
NetScope* NetScope::child(const hname_t&name)
{
      map<hname_t,NetScope*>::iterator cur = children_.find(name);
      if (cur == children_.end())
	    return 0;
      else
	    return cur->second;
}

const NetScope* NetScope::child(const hname_t&name) const
{
      map<hname_t,NetScope*>::const_iterator cur = children_.find(name);
      if (cur == children_.end())
	    return 0;
      else
	    return cur->second;
}

/* Helper function to see if the given scope is defined in a class and if
 * so return the class scope. */
const NetScope* NetScope::get_class_scope() const
{
      const NetScope*scope = this;
      while (scope) {
	    switch(scope->type()) {
		case NetScope::CLASS:
		  return scope;
		case NetScope::TASK:
		case NetScope::FUNC:
		case NetScope::BEGIN_END:
		case NetScope::FORK_JOIN:
		  break;
		case NetScope::MODULE:
		case NetScope::GENBLOCK:
		case NetScope::PACKAGE:
		  return 0;
		default:
		  ivl_assert(*this, 0);
	    }
	    scope = scope->parent();
      }
      return scope;
}

const NetScope* NetScope::child_byname(perm_string name) const
{
      hname_t hname (name);
      map<hname_t,NetScope*>::const_iterator cur = children_.lower_bound(hname);

      if (cur == children_.end())
	    return 0;

      if (cur->first.peek_name() == name)
	    return cur->second;

      return 0;
}


bool NetScope::symbol_exists(perm_string sym)
{
      if (signals_map_.find(sym) != signals_map_.end())
            return true;
      if (parameters.find(sym) != parameters.end())
            return true;
      if (genvars_.find(sym) != genvars_.end())
            return true;
      if (classes_.find(sym) != classes_.end())
          return true;
      if (typedefs_.find(sym) != typedefs_.end())
          return true;
      if (find_event(sym))
          return true;

      return false;
}

perm_string NetScope::local_symbol()
{
      perm_string sym;
      do {
	    ostringstream res;
	    res << "_ivl_" << (lcounter_++);
	    perm_string sym_tmp = lex_strings.make(res.str());

	      // If the name already exists, try again.
	    if (symbol_exists(sym_tmp))
		  continue;

	      // No collisions, this is the one.
	    sym = sym_tmp;
      } while (sym.nil());
      return sym;
}

void NetScope::add_tie_hi(Design*des)
{
      if (tie_hi_ == 0) {
	    NetNet*sig = new NetNet(this, lex_strings.make("_LOGIC1"),
				    NetNet::WIRE, &netvector_t::scalar_logic);
	    sig->local_flag(true);

	    tie_hi_ = new NetLogic(this, local_symbol(),
				   1, NetLogic::PULLUP, 1);
	    des->add_node(tie_hi_);

	    connect(sig->pin(0), tie_hi_->pin(0));
      }
}

void NetScope::add_tie_lo(Design*des)
{
      if (tie_lo_ == 0) {
	    NetNet*sig = new NetNet(this, lex_strings.make("_LOGIC0"),
				    NetNet::WIRE, &netvector_t::scalar_logic);
	    sig->local_flag(true);

	    tie_lo_ = new NetLogic(this, local_symbol(),
				   1, NetLogic::PULLDOWN, 1);
	    des->add_node(tie_lo_);

	    connect(sig->pin(0), tie_lo_->pin(0));
      }
}

/* M13: let lookup — search this scope then walk up lexical parents,
   stopping at (and including) the enclosing module scope so lets do
   not leak across module instance boundaries. */
PLet* NetScope::find_let(perm_string name) const
{
      const NetScope*cur = this;
      for (;;) {
	    std::map<perm_string,PLet*>::const_iterator it
		  = cur->lets_.find(name);
	    if (it != cur->lets_.end()) return it->second;
	    if (cur->type() == MODULE) return 0;
	    cur = cur->parent();
	    if (cur == 0) return 0;
      }
}
