/*
 * Copyright (c) 2000-2025 Stephen Williams (steve@icarus.com)
 * Copyright CERN 2012-2013 / Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include "config.h"
# include  <algorithm>
# include  <cstdlib>
# include  <sstream>

# include  "PExpr.h"
# include  "PPackage.h"
# include  "PClass.h"
# include  "PTask.h"
# include  "netlist.h"
# include  "netmisc.h"
# include  "netstruct.h"
# include  "netclass.h"
# include  "Module.h"
# include  "PModport.h"
# include  "parse_api.h"
# include  "netdarray.h"
# include  "netparray.h"
# include  "netqueue.h"
# include  "netvector.h"
# include  "netenum.h"
# include  "compiler.h"
# include  <cstdlib>
# include  <iostream>
# include  <climits>
# include  "ivl_assert.h"

/* A bit or part select of a packed property. An enum or packed struct is
 * written as the flat vector of its bits, like a `logic [N-1:0]' property. */
static const netvector_t*packed_select_view_(ivl_type_t type)
{
      if (const netvector_t*vec = dynamic_cast<const netvector_t*>(type))
	    return vec;
      if (type && (dynamic_cast<const netenum_t*>(type)
		   || (type->packed() && dynamic_cast<const netstruct_t*>(type)))
	  && type->packed_width() > 0)
	    return new netvector_t(type->base_type(), type->packed_width() - 1, 0,
				   type->get_signed());
      return 0;
}

using namespace std;

/* Reuse the live last-index expression used by queue reads. Ordinary indices
 * still use assignment-context elaboration for associative-array keys. */
static NetExpr* elab_lval_container_index_(Design*des, NetScope*scope,
      const LineInfo&loc, const index_component_t&index, NetNet*sig)
{
      if (index.sel == index_component_t::SEL_BIT_LAST) {
            const netqueue_t*queue = sig->queue_type();
            if (!queue || queue->assoc_compat()) {
                  cerr << loc.get_fileline()
                       << ": error: `$' requires a positional queue l-value." << endl;
                  des->errors += 1;
                  return nullptr;
            }
            NetELast*last = new NetELast(sig);
            last->set_line(loc);
            return last;
      }
      return elab_assoc_index(des, scope, index.msb, sig->queue_type());
}

static string stream_int128_text_(__int128 value)
{
      if (value == 0) return "0";
      bool negative = value < 0;
      unsigned __int128 magnitude = negative
	    ? (unsigned __int128)(-(value + 1)) + 1
	    : (unsigned __int128)value;
      string result;
      while (magnitude) {
	    result.push_back(char('0' + magnitude % 10));
	    magnitude /= 10;
      }
      if (negative) result.push_back('-');
      reverse(result.begin(), result.end());
      return result;
}

NetAssign_* PEStreamWith::elaborate_lval(Design*des, NetScope*scope,
                                          bool is_cassign, bool is_force,
                                          bool is_init, bool read_only_ref) const
{
      if (read_only_ref) {
	cerr << get_fileline() << ": error: A const ref actual must be a variable."
	     << endl;
	des->errors += 1;
	return nullptr;
      }
      NetAssign_*res = base_->elaborate_lval(des, scope, is_cassign,
                                             is_force, is_init);
      if (!res)
	    return nullptr;

      if (res->more) {
	    cerr << get_fileline() << ": error: the operand before streaming "
	         << "`with' must be one one-dimensional unpacked array or queue."
	         << endl;
	    des->errors += 1;
	    delete res;
	    return nullptr;
      }

      ivl_type_t type = res->lval_type();
      const netdarray_t*dar = dynamic_cast<const netdarray_t*>(type);
      const netqueue_t*queue = dynamic_cast<const netqueue_t*>(type);
      const netuarray_t*fixed = dynamic_cast<const netuarray_t*>(type);
      bool valid_fixed = fixed && fixed->static_dimensions().size() == 1;
      if ((!dar && !valid_fixed) || (queue && queue->assoc_compat())) {
	    cerr << get_fileline() << ": error: the operand before streaming "
	         << "`with' must be a one-dimensional unpacked array or queue "
	            "(IEEE 1800-2023 11.4.14.4)." << endl;
	    des->errors += 1;
	    delete res;
	    return nullptr;
      }

      ivl_type_t elem = dar ? dar->element_type() : fixed->element_type();
      if (!elem || !elem->packed() || elem->packed_width() <= 0) {
	    cerr << get_fileline() << ": error: a streaming `with' array must "
	         << "have fixed-width bit-stream elements." << endl;
	    des->errors += 1;
	    delete res;
	    return nullptr;
      }

      width_mode_t mode = SIZED;
      first_->test_width(des, scope, mode);
      if (first_->expr_type() != IVL_VT_BOOL
	  && first_->expr_type() != IVL_VT_LOGIC) {
	    cerr << first_->get_fileline() << ": error: streaming `with' range "
	         << "expressions must be integral." << endl;
	    des->errors += 1;
	    delete res;
	    return nullptr;
      }
      NetExpr*first = elab_and_eval(des, scope, first_, -1);
      if (!first) {
	    delete res;
	    return nullptr;
      }

      NetExpr*second = nullptr;
      if (second_) {
	    mode = SIZED;
	    second_->test_width(des, scope, mode);
	    if (second_->expr_type() != IVL_VT_BOOL
		&& second_->expr_type() != IVL_VT_LOGIC) {
		  cerr << second_->get_fileline()
		       << ": error: streaming `with' range expressions must be "
		          "integral." << endl;
		  des->errors += 1;
		  delete first;
		  delete res;
		  return nullptr;
	    }
	    second = elab_and_eval(des, scope, second_, -1);
	    if (!second) {
		  delete first;
		  delete res;
		  return nullptr;
	    }
      }

      /* Dynamically sized arrays and queues only admit positive indexes;
	 catch constant violations here and leave variable values for the bounded
	 runtime check at their single evaluation point. */
      if (dar) {
	    const NetEConst*fc = dynamic_cast<const NetEConst*>(first);
	    const NetEConst*sc = dynamic_cast<const NetEConst*>(second);
	    bool bad = fc && fc->value().is_defined()
		  && fc->value().as_long() < 0;
	    if (kind_ == IVL_STREAM_RANGE_RANGE && sc
		&& sc->value().is_defined() && sc->value().as_long() < 0)
		  bad = true;
	    if ((kind_ == IVL_STREAM_RANGE_UP
		 || kind_ == IVL_STREAM_RANGE_DOWN) && sc
		&& sc->value().is_defined() && sc->value().as_long() <= 0)
		  bad = true;
	    if (bad) {
		  cerr << get_fileline() << ": error: a dynamic-array or queue "
		       << "streaming `with' range requires nonnegative indexes "
		          "and a positive indexed width." << endl;
		  des->errors += 1;
		  delete second;
		  delete first;
		  delete res;
		  return nullptr;
	    }
      } else if (fixed) {
	    const netranges_t&dims = fixed->static_dimensions();
	    __int128 bound_lo = std::min(dims[0].get_msb(), dims[0].get_lsb());
	    __int128 bound_hi = std::max(dims[0].get_msb(), dims[0].get_lsb());
	    const NetEConst*fc = dynamic_cast<const NetEConst*>(first);
	    const NetEConst*sc = dynamic_cast<const NetEConst*>(second);
	    if (fc && fc->value().is_defined()
		&& (!second || (sc && sc->value().is_defined()))) {
		  __int128 a = fc->value().as_long();
		  __int128 lo = a, hi = a;
		  if (kind_ == IVL_STREAM_RANGE_RANGE) {
			__int128 b = sc->value().as_long();
			lo = std::min(a, b); hi = std::max(a, b);
		  } else if (kind_ == IVL_STREAM_RANGE_UP
			     || kind_ == IVL_STREAM_RANGE_DOWN) {
			__int128 width = sc->value().as_long();
			if (width <= 0) {
			      lo = bound_lo-1;
			} else if (kind_ == IVL_STREAM_RANGE_UP) {
			      hi = a + width - 1;
			} else {
			      lo = a - width + 1;
			}
		  }
		  if (lo < bound_lo || hi > bound_hi) {
			cerr << get_fileline() << ": error: streaming `with' "
			     << "unpack range [" << stream_int128_text_(lo)
			     << ":" << stream_int128_text_(hi)
			     << "] is outside fixed array bounds ["
			     << dims[0].get_msb() << ":" << dims[0].get_lsb()
			     << "]; only in-range elements would be modified "
			        "(IEEE 1800-2023 11.4.14.4)." << endl;
			des->errors += 1;
			delete second;
			delete first;
			delete res;
			return nullptr;
		  }
	    }
      }

      res->set_stream_range(kind_, first, second);
      return res;
}

/* Clocking-block member path rewrites are shared with expression
   elaboration — see rewrite_*_clocking_member_path* in netmisc.cc. */

/*
 * These methods generate a NetAssign_ object for the l-value of the
 * assignment. This is common code for the = and <= statements.
 *
 * What gets generated depends on the structure of the l-value. If the
 * l-value is a simple name (i.e., foo <= <value>) then the NetAssign_
 * is created the width of the foo reg and connected to all the
 * bits.
 *
 * If there is a part select (i.e., foo[3:1] <= <value>) the NetAssign_
 * is made only as wide as it needs to be (3 bits in this example) and
 * connected to the correct bits of foo. A constant bit select is a
 * special case of the part select.
 *
 * If the bit-select is non-constant (i.e., foo[<expr>] = <value>) the
 * NetAssign_ is made wide enough to connect to all the bits of foo,
 * then the mux expression is elaborated and attached to the
 * NetAssign_ node as a b_mux value. The target must interpret the
 * presence of a bmux value as taking a single bit and assigning it to
 * the bit selected by the bmux expression.
 *
 * If the l-value expression is non-trivial, but can be fully
 * evaluated at compile time (meaning any bit selects are constant)
 * then elaboration will make a single NetAssign_ that connects to a
 * synthetic reg that in turn connects to all the proper pins of the
 * l-value.
 *
 * This last case can turn up in statements like: {a, b[1]} = c;
 * rather than create a NetAssign_ for each item in the concatenation,
 * elaboration makes a single NetAssign_ and connects it up properly.
 */

void PEIdent::report_mixed_assignment_conflict_(const char*category) const
{
      cerr << get_fileline() << ": error: Cannot perform procedural "
              "assignment to " << category << " '" << path_
           << "' because it is also continuously assigned." << endl;
}

/*
 * The default interpretation of an l-value to a procedural assignment
 * is to try to make a net elaboration, and see if the result is
 * suitable for assignment.
 */
NetAssign_* PExpr::elaborate_lval(Design*des, NetScope*, bool, bool, bool,
				 bool read_only_ref) const
{
      if (read_only_ref) {
	cerr << get_fileline() << ": error: A const ref actual must be a variable."
	     << endl;
	des->errors += 1;
      } else {
	cerr << get_fileline() << ": Assignment l-value too complex." << endl;
      }
      return 0;
}

/*
 * Concatenation expressions can appear as l-values. Handle them here.
 *
 * If adjacent l-values in the concatenation are not bit selects, then
 * merge them into a single NetAssign_ object. This can happen is code
 * like ``{ ...a, b, ...}''. As long as "a" and "b" do not have bit
 * selects (or the bit selects are constant) we can merge the
 * NetAssign_ objects.
 *
 * Be careful to get the bit order right. In the expression ``{a, b}''
 * a is the MSB and b the LSB. Connect the LSB to the low pins of the
 * NetAssign_ object.
 */

/* IEEE 1800-2017 14.3: a clocking signal is not a legal operand of a
   concatenation or assignment-pattern l-value. Detect the clocking pseudo-
   hierarchy before elaborating any operand, otherwise the ordinary member
   rewrite aliases it to the raw signal and a partial NetAssign_ tree can be
   built with immediate (non-clocking) semantics. */
static bool report_concat_clocking_lvalue_(const PExpr*expr, Design*des,
					    NetScope*scope)
{
      if (const PEIdent*ident = dynamic_cast<const PEIdent*>(expr)) {
	    symbol_search_results sr;
	    symbol_search(ident, des, scope, ident->path(),
			  ident->lexical_pos(), &sr);
	    pform_name_t rewritten;
	    bool is_clocking =
		  (sr.net && rewrite_class_clocking_member_path(
			ident, sr, rewritten, false))
		  || rewrite_clocking_member_path_via_scope(
			ident, sr, rewritten, false)
		  || (!sr.net && rewrite_enclosing_scope_clocking_member_path(
			ident, scope, rewritten, false));
	    if (!is_clocking)
		  return false;

	    cerr << ident->get_fileline() << ": error: clocking signal `"
		 << *ident << "' cannot be part of a concatenation or "
		 << "assignment-pattern l-value (IEEE 1800-2017 14.3)." << endl;
	    des->errors += 1;
	    return true;
      }

      const PEConcat*concat = dynamic_cast<const PEConcat*>(expr);
      if (!concat)
	    return false;

      bool found = false;
      for (const PExpr*operand : concat->stream_parms())
	    if (operand)
		  found = report_concat_clocking_lvalue_(operand, des, scope)
			|| found;
      return found;
}

NetAssign_* PEConcat::elaborate_lval(Design*des,
                                     NetScope*scope,
                                     bool is_cassign,
                                     bool is_force,
                                     bool is_init,
                                     bool read_only_ref) const
{
      if (read_only_ref) {
	cerr << get_fileline() << ": error: A const ref actual must be a variable."
	     << endl;
	des->errors += 1;
	return nullptr;
      }
      if (repeat_) {
	    cerr << get_fileline() << ": error: Repeat concatenations make "
		  "no sense in l-value expressions. I refuse." << endl;
	    des->errors += 1;
	    return 0;
      }

      if (report_concat_clocking_lvalue_(this, des, scope))
	    return 0;

      NetAssign_*res = 0;

      for (unsigned idx = 0 ;  idx < parms_.size() ;  idx += 1) {

	    if (parms_[idx] == 0) {
		  cerr << get_fileline() << ": error: Empty expressions "
		       << "not allowed in concatenations." << endl;
		  des->errors += 1;
		  continue;
	    }

	    NetAssign_*tmp = parms_[idx]->elaborate_lval(des, scope,
							 is_cassign, is_force, is_init);

	      /* If the l-value doesn't elaborate, the error was
		 already detected and printed. We just skip it and let
		 the compiler catch more errors. */
	    if (tmp == 0) continue;

	    if (tmp->expr_type() == IVL_VT_REAL) {
		  cerr << parms_[idx]->get_fileline() << ": error: "
		       << "concatenation operand can not be real: "
		       << *parms_[idx] << endl;
		  des->errors += 1;
		  continue;
	    }

	      /* A concatenation is always unsigned. */
	    tmp->set_signed(false);

	      /* Link the new l-value to the previous one. */
	    NetAssign_*last = tmp;
	    while (last->more)
		  last = last->more;

	    last->more = res;
	    res = tmp;
      }

      return res;
}

enum scoped_lvalue_class_name_kind_t {
      SCOPED_LVALUE_CLASS_NONE,
      SCOPED_LVALUE_CLASS_DIRECT,
      SCOPED_LVALUE_CLASS_TYPE_PARAMETER,
      SCOPED_LVALUE_CLASS_NONCLASS_TYPE_PARAMETER,
      SCOPED_LVALUE_CLASS_TYPEDEF,
      SCOPED_LVALUE_CLASS_NONCLASS_TYPEDEF
};

struct scoped_lvalue_class_name_result_t {
      const netclass_t*class_type = nullptr;
      scoped_lvalue_class_name_kind_t kind = SCOPED_LVALUE_CLASS_NONE;
};

struct scoped_lvalue_type_parameter_result_t {
      const netclass_t*class_type = nullptr;
      bool concrete_nonclass = false;
};

/* Resolve a type parameter without losing that it was a type parameter.  A
   bound T and a direct class declaration both elaborate to netclass_t, but
   only the latter is an illegal external bare-generic prefix.  Conversely,
   the generic class seed may temporarily elaborate a non-class default for T;
   that seed must remain deferred, while the same result in a concrete
   specialization is a hard invalid receiver. */
static scoped_lvalue_type_parameter_result_t
resolve_scoped_lvalue_type_parameter_(
		Design*des, NetScope*scope, perm_string name)
{
      scoped_lvalue_type_parameter_result_t result;
      if (!scope)
	    return result;

      for (NetScope*cur = scope ; cur ; cur = cur->parent()) {
	    std::map<perm_string,NetScope::param_expr_t>::const_iterator param =
		  cur->parameters.find(name);
	    if (param == cur->parameters.end() || !param->second.type_flag)
		  continue;

	    ivl_type_t param_type = nullptr;
	    (void) cur->get_parameter(des, name, param_type);
	    if (dynamic_cast<const netclass_t*>(param_type)) {
		  if (param->second.val_expr) {
			if (const PETypename*actual =
			      dynamic_cast<const PETypename*>(param->second.val_expr))
			      param_type = specialize_bare_class_at_concrete_use(
				    des, scope, actual->get_type(), param_type, true);
		  }
		  result.class_type = dynamic_cast<const netclass_t*>(param_type);
		  return result;
	    }

	    result.concrete_nonclass = param_type
		  && !class_type_parameter_is_deferred(des, scope, name);
	    return result;
      }

      if (NetScope*unit = scope->unit()) {
	    std::map<perm_string,NetScope::param_expr_t>::const_iterator param =
		  unit->parameters.find(name);
	    if (param == unit->parameters.end() || !param->second.type_flag)
		  return result;

	    ivl_type_t param_type = nullptr;
	    (void) unit->get_parameter(des, name, param_type);
	    if (dynamic_cast<const netclass_t*>(param_type)) {
		  if (param->second.val_expr) {
			if (const PETypename*actual =
			      dynamic_cast<const PETypename*>(param->second.val_expr))
			      param_type = specialize_bare_class_at_concrete_use(
				    des, scope, actual->get_type(), param_type, true);
		  }
		  result.class_type = dynamic_cast<const netclass_t*>(param_type);
		  return result;
	    }

	    result.concrete_nonclass = param_type
		  && !class_type_parameter_is_deferred(des, scope, name);
      }

	  return result;
}

static scoped_lvalue_class_name_result_t resolve_scoped_lvalue_class_name_(
		Design*des, NetScope*scope, perm_string name)
{
      scoped_lvalue_class_name_result_t result;
      if (!scope)
	    return result;

      if (typedef_t*td = scope->find_typedef(des, name)) {
	    const data_type_t*declared_type = td->get_data_type();
	    if (dynamic_cast<const type_parameter_t*>(declared_type)) {
		  scoped_lvalue_type_parameter_result_t parameter =
			resolve_scoped_lvalue_type_parameter_(des, scope, name);
		  result.class_type = parameter.class_type;
		  result.kind = parameter.concrete_nonclass
			? SCOPED_LVALUE_CLASS_NONCLASS_TYPE_PARAMETER
			: SCOPED_LVALUE_CLASS_TYPE_PARAMETER;
		  return result;
	    }

	    /* The same-name class_type_t is the synthetic typedef for the
	       declaration itself.  A user alias has different parse-form
	       provenance and denotes its concrete default specialization. */
	    if (const class_type_t*class_pf =
		  dynamic_cast<const class_type_t*>(declared_type)) {
		  if (class_pf->name == name) {
			result.class_type = scope->find_class(des, name);
			if (!result.class_type)
			      result.class_type = ensure_visible_class_type(
				    des, scope, name);
			result.kind = SCOPED_LVALUE_CLASS_DIRECT;
			return result;
		  }
	    }

	    ivl_type_t alias_type = td->elaborate_type(des, scope);
	    if (dynamic_cast<const netclass_t*>(alias_type)) {
		  alias_type = specialize_bare_class_at_concrete_use(
			des, scope, declared_type, alias_type, true);
		  result.class_type =
			dynamic_cast<const netclass_t*>(alias_type);
		  result.kind = SCOPED_LVALUE_CLASS_TYPEDEF;
		  return result;
	    }

	    /* A visible, successfully elaborated typedef is terminal even when
	       it is not a class.  Falling through to find_class(name) would
	       incorrectly recover an outer class hidden by the typedef.  Keep
	       the null-type fallthrough for early class-forward placeholders. */
	    if (alias_type) {
		  result.kind = SCOPED_LVALUE_CLASS_NONCLASS_TYPEDEF;
		  return result;
	    }
      }

      result.class_type = scope->find_class(des, name);
      if (!result.class_type)
	    result.class_type = ensure_visible_class_type(des, scope, name);
      if (result.class_type)
	    result.kind = SCOPED_LVALUE_CLASS_DIRECT;
      return result;
}

static bool scoped_lvalue_class_is_unspecialized_parameterized_(
		const netclass_t*class_type)
{
      if (!class_type || class_type->specialized_instance())
	    return false;

      const NetScope*class_scope = class_type->class_scope();
      const PClass*pclass = class_scope ? class_scope->class_pform() : nullptr;
      return pclass && pclass->has_parameter_port_list;
}

static const netclass_t* scoped_lvalue_current_specialization_(
		NetScope*use_scope, const netclass_t*class_type)
{
      if (!use_scope || !class_type)
	    return nullptr;

      const NetScope*current_scope = use_scope->get_class_scope();
      const NetScope*resolved_scope = class_type->class_scope();
      if (!current_scope || !resolved_scope
	  || current_scope->class_pform() != resolved_scope->class_pform())
	    return nullptr;

      return current_scope->class_def();
}

enum scoped_lvalue_retarget_status_t {
      SCOPED_LVALUE_RETARGET_NOT_APPLICABLE,
      SCOPED_LVALUE_RETARGETED,
      SCOPED_LVALUE_RETARGET_DEFERRED,
      SCOPED_LVALUE_RETARGET_ERROR_BARE_GENERIC,
      SCOPED_LVALUE_RETARGET_ERROR_NONCLASS_TYPE_PARAMETER,
      SCOPED_LVALUE_RETARGET_ERROR_NONCLASS_TYPEDEF,
      SCOPED_LVALUE_RETARGET_ERROR_MISSING_PROPERTY,
      SCOPED_LVALUE_RETARGET_ERROR_NONSTATIC_PROPERTY,
      SCOPED_LVALUE_RETARGET_ERROR_STATIC_STORAGE
};

struct scoped_lvalue_retarget_result_t {
      scoped_lvalue_retarget_status_t status =
	    SCOPED_LVALUE_RETARGET_NOT_APPLICABLE;
      const netclass_t*class_type = nullptr;
      perm_string prefix;
      perm_string property;
};

/* Retarget Class#(...)::property and typedef-qualified assignments to the
   selected class specialization before ordinary l-value lowering.  Keeping
   the result status distinct from the symbol-search result prevents a known
   class-scoped target from falling through to the generic missing-variable
   warning path. */
static scoped_lvalue_retarget_result_t retarget_scoped_static_lvalue_(
		Design*des, NetScope*scope, const pform_scoped_name_t&path,
		const parmvalue_t*leading_type_args, symbol_search_results&sr)
{
	  scoped_lvalue_retarget_result_t result;
      if (!gn_system_verilog() || path.name.size() < 2)
	    return result;

      const name_component_t&prefix = path.name.front();
      if (!prefix.index.empty())
	    return result;
	  result.prefix = prefix.name;

      NetScope*search_scope = scope;
      if (path.package) {
	    search_scope = des->find_package(path.package->pscope_name());
	    if (!search_scope)
		  return result;
      }

      scoped_lvalue_class_name_result_t resolved =
	    resolve_scoped_lvalue_class_name_(des, search_scope, prefix.name);
	  if (resolved.kind == SCOPED_LVALUE_CLASS_NONCLASS_TYPE_PARAMETER) {
	    result.status = SCOPED_LVALUE_RETARGET_ERROR_NONCLASS_TYPE_PARAMETER;
	    return result;
	  }
	  if (resolved.kind == SCOPED_LVALUE_CLASS_NONCLASS_TYPEDEF) {
	    result.status = SCOPED_LVALUE_RETARGET_ERROR_NONCLASS_TYPEDEF;
	    return result;
	  }
      const netclass_t*class_type = resolved.class_type;
	  if (!class_type) {
	    if (resolved.kind == SCOPED_LVALUE_CLASS_TYPE_PARAMETER)
		  result.status = SCOPED_LVALUE_RETARGET_DEFERRED;
	    return result;
	  }

      if (leading_type_args) {
	    class_type = elaborate_specialized_class_type(
		  des, search_scope, class_type, leading_type_args, true);
      } else if (resolved.kind == SCOPED_LVALUE_CLASS_DIRECT) {
	    if (const netclass_t*current_class =
		  scoped_lvalue_current_specialization_(scope, class_type)) {
		  class_type = current_class;
	    } else if (scoped_lvalue_class_is_unspecialized_parameterized_(
			     class_type)) {
		  result.class_type = class_type;
		  result.status = SCOPED_LVALUE_RETARGET_ERROR_BARE_GENERIC;
		  return result;
	    }
      }

	  if (!class_type) {
	    result.status = SCOPED_LVALUE_RETARGET_DEFERRED;
	    return result;
	  }
	  result.class_type = class_type;

      /* This grammar shape has one class-scope prefix; the next component is
	 the static property and any later components are instance members of
	 that property. */
      pform_name_t::const_iterator prop_it = path.name.begin();
      ++prop_it;
	  result.property = prop_it->name;
	  int pidx = const_cast<netclass_t*>(class_type)->ensure_property_decl(
		des, prop_it->name);
	  if (pidx < 0) {
	    result.status = SCOPED_LVALUE_RETARGET_ERROR_MISSING_PROPERTY;
	    return result;
	  }
	  if (!class_type->get_prop_qual(pidx).test_static()) {
	    result.status = SCOPED_LVALUE_RETARGET_ERROR_NONSTATIC_PROPERTY;
	    return result;
	  }

      NetNet*target = class_type->get_prop_static_signal((size_t)pidx);
	  if (!target) {
	    result.status = SCOPED_LVALUE_RETARGET_ERROR_STATIC_STORAGE;
	    return result;
	  }

      sr.net = target;
      sr.scope = target->scope();
      sr.type = target->net_type();
	  sr.par_val = nullptr;
	  sr.eve = nullptr;
	  sr.decl_after_use = nullptr;
	  sr.path_head.clear();
	  sr.path_head.push_back(prefix);
	  sr.path_head.push_back(*prop_it);
	  sr.path_tail.clear();
	  for (++prop_it ; prop_it != path.name.end() ; ++prop_it)
	    sr.path_tail.push_back(*prop_it);
	  result.status = SCOPED_LVALUE_RETARGETED;
	  return result;
}


/*
 * Handle the ident as an l-value. This includes bit and part selects
 * of that ident.
 */
NetAssign_* PEIdent::elaborate_lval(Design*des,
				    NetScope*scope,
				    bool is_cassign,
				    bool is_force,
				    bool is_init,
				    bool read_only_ref) const
{

      for (const name_component_t&component : path_.name) {
	    for (const index_component_t&index : component.index) {
		  if (index.sel != index_component_t::SEL_PART_LEFT_LAST)
			continue;
		  cerr << get_fileline() << ": sorry: assignment to queue slice"
		       << " [$:hi] is not yet supported." << endl;
		  des->errors += 1;
		  return nullptr;
	    }
      }

      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval: "
		 << "Elaborate l-value ident expression: " << *this << endl;
      }

      symbol_search_results sr;
      symbol_search(this, des, scope, path_, lexical_pos_, &sr);

	  scoped_lvalue_retarget_result_t scoped_result;
	  if (has_scoped_type_prefix())
	    scoped_result = retarget_scoped_static_lvalue_(
		  des, scope, path_, leading_type_args(), sr);

	  bool scoped_error = false;
	  switch (scoped_result.status) {
	      case SCOPED_LVALUE_RETARGET_ERROR_BARE_GENERIC:
		    if (!bare_generic_scope_error_reported_) {
			  cerr << get_fileline()
			       << ": error: Parameterized class `"
			       << scoped_result.prefix
			       << "' requires an explicit #(...) specialization before ::."
			       << endl;
			  des->errors += 1;
			  bare_generic_scope_error_reported_ = true;
		    }
		    return nullptr;
	      case SCOPED_LVALUE_RETARGET_ERROR_NONCLASS_TYPE_PARAMETER:
		    scoped_error = true;
		    if (!scoped_lvalue_error_reported_) {
			  cerr << get_fileline()
			       << ": error: Class-scoped l-value prefix `"
			       << scoped_result.prefix
			       << "' resolves to a non-class type parameter." << endl;
			  des->errors += 1;
			  scoped_lvalue_error_reported_ = true;
		    }
		    break;
	      case SCOPED_LVALUE_RETARGET_ERROR_NONCLASS_TYPEDEF:
		    scoped_error = true;
		    if (!scoped_lvalue_error_reported_) {
			  cerr << get_fileline()
			       << ": error: Class-scoped l-value prefix `"
			       << scoped_result.prefix
			       << "' resolves to a non-class typedef." << endl;
			  des->errors += 1;
			  scoped_lvalue_error_reported_ = true;
		    }
		    break;
	      case SCOPED_LVALUE_RETARGET_ERROR_MISSING_PROPERTY:
		    scoped_error = true;
		    if (!scoped_lvalue_error_reported_) {
			  cerr << get_fileline() << ": error: Class `"
			       << scoped_result.class_type->get_name()
			       << "' does not have a property `"
			       << scoped_result.property << "'." << endl;
			  des->errors += 1;
			  scoped_lvalue_error_reported_ = true;
		    }
		    break;
	      case SCOPED_LVALUE_RETARGET_ERROR_NONSTATIC_PROPERTY:
		    scoped_error = true;
		    if (!scoped_lvalue_error_reported_) {
			  cerr << get_fileline()
			       << ": error: Class-scoped l-value `"
			       << scoped_result.prefix << "::"
			       << scoped_result.property
			       << "' requires static property `"
			       << scoped_result.property << "'." << endl;
			  des->errors += 1;
			  scoped_lvalue_error_reported_ = true;
		    }
		    break;
	      case SCOPED_LVALUE_RETARGET_ERROR_STATIC_STORAGE:
		    scoped_error = true;
		    if (!scoped_lvalue_error_reported_) {
			  cerr << get_fileline()
			       << ": error: Failed to resolve static property `"
			       << scoped_result.property << "' in class `"
			       << scoped_result.class_type->get_name() << "'." << endl;
			  des->errors += 1;
			  scoped_lvalue_error_reported_ = true;
		    }
		    break;
	      case SCOPED_LVALUE_RETARGET_DEFERRED:
		    return nullptr;
	      default:
		    break;
	  }
	  if (scoped_error)
	    return nullptr;

      NetNet *reg = sr.net;
      const pform_name_t &member_path = sr.path_tail;

      pform_name_t rewritten_path;
      bool clk_input_write = false;
      perm_string mapped_access = clocking_access();
      if ((reg && rewrite_class_clocking_member_path(this, sr, rewritten_path,
						     true, &clk_input_write,
						     &mapped_access))
	  || rewrite_clocking_member_path_via_scope(this, sr, rewritten_path,
						    true, &clk_input_write,
						    &mapped_access)
	  || (!reg && rewrite_enclosing_scope_clocking_member_path(this, scope, rewritten_path,
								   true, &clk_input_write,
								   &mapped_access))) {
	    if (clk_input_write)
		  des->errors += 1;
	    if (path_.package) {
		  PEIdent mapped_ident(path_.package, rewritten_path, lexical_pos_);
		  mapped_ident.set_line(*this);
		  mapped_ident.set_clocking_access(mapped_access);
		  return mapped_ident.elaborate_lval(des, scope, is_cassign,
						      is_force, is_init,
						      read_only_ref);
	    }
	    PEIdent mapped_ident(rewritten_path, lexical_pos_);
	    mapped_ident.set_line(*this);
	    mapped_ident.set_clocking_access(mapped_access);
	    return mapped_ident.elaborate_lval(des, scope, is_cassign,
						is_force, is_init,
						read_only_ref);
      }

	/* The l-value must be a variable. If not, then give up and
	   print a useful error message. */
      if (reg == 0) {
	    if (scope->type()==NetScope::FUNC
		&& scope->func_def()->is_void()
		&& scope->basename()==peek_tail_name(path_)) {
		  cerr << get_fileline() << ": error: "
		       << "Cannot assign to " << path_
		       << " because function " << scope_path(scope)
		       << " is void." << endl;
		  des->errors += 1;
	    } else if (gn_system_verilog()) {
		  // Compile-progress: covergroup handles, unresolved class properties,
		  // and other SV constructs may not be found as l-value variables.
		  cerr << get_fileline() << ": warning: Could not find variable ``"
		       << path_ << "'' in ``" << scope_path(scope) << "''"
		       << " (compile-progress: assignment ignored)." << endl;
	    } else {
		  cerr << get_fileline() << ": error: Could not find variable ``"
		       << path_ << "'' in ``" << scope_path(scope) <<
			"''" << endl;
		  if (sr.decl_after_use) {
			cerr << sr.decl_after_use->get_fileline() << ":      : "
				"A symbol with that name was declared here. "
				"Check for declaration after use." << endl;
		  }
		  des->errors += 1;
	    }
	    return 0;
      }

      ivl_assert(*this, reg);

	/* Match the constant-function read-side rule for a string character
	   l-value. A declaration in the function or one of its nested lexical
	   blocks is local; module, package, and class storage is not. Ordinary
	   functions may perform the latter write, but cannot subsequently be
	   treated as constant functions. */
      if (gn_system_verilog() && reg->data_type() == IVL_VT_STRING
	  && !sr.path_head.empty() && !sr.path_head.back().index.empty()) {
	    NetScope*function_scope = scope;
	    while (function_scope && function_scope->type() != NetScope::FUNC)
		  function_scope = function_scope->parent();
	    bool local_to_function = false;
	    for (const NetScope*owner = reg->scope(); owner;
		 owner = owner->parent()) {
		  if (owner == function_scope) {
			local_to_function = true;
			break;
		  }
	    }
	    if (function_scope && !local_to_function) {
		  if (function_scope->need_const_func()) {
			cerr << get_fileline() << ": error: A reference to a non-local net "
			     << "or variable (`" << path_
			     << "') is not allowed in a constant function." << endl;
			des->errors += 1;
			return nullptr;
		  }
		  function_scope->is_const_func(false);
	    }
      }

      if (debug_elaborate) {
	    cerr << get_fileline() << ": " << __func__ << ": "
		 << "Found l-value path_=" << path_
		 << " as reg=" << reg->name() << endl;
	    cerr << get_fileline() << ": " << __func__ << ": "
		 << "reg->type()=" << reg->type()
		 << ", reg->unpacked_dimensions()=" << reg->unpacked_dimensions()
		 << endl;
	    if (reg->net_type())
		  cerr << get_fileline() << ": " << __func__ << ": "
		       << "reg->net_type()=" << *reg->net_type() << endl;
	    else
		  cerr << get_fileline() << ": " << __func__ << ": "
		       << "reg->net_type()=<nil>" << endl;
	    const pform_name_t &base_path = sr.path_head;
	    cerr << get_fileline() << ": " << __func__ << ": "
		 << " base_path=" << base_path
		 << ", member_path=" << member_path
		 << endl;
      }

	/* A static const class property is represented by a real signal in the
	   class scope.  Its declaration assignment is the one legal write and
	   must also satisfy netclass_t's missing-initializer accounting.  The
	   old class-property path never recorded this direct-signal initializer,
	   so every valid `const static T p = value;' was rejected after its
	   initializer had otherwise elaborated successfully. */
	      if (is_init && reg->scope()
		  && reg->scope()->type() == NetScope::CLASS) {
		    const netclass_t*owner_class = reg->scope()->class_def();
		    int pidx = owner_class
			  ? owner_class->property_idx_from_name(reg->name()) : -1;
		    if (pidx >= 0) {
			  property_qualifier_t qual = owner_class->get_prop_qual(pidx);
			  if (qual.test_static() && qual.test_const()) {
				if (owner_class->get_prop_initialized(pidx)) {
				      cerr << get_fileline() << ": error: Static const property `"
					   << reg->name()
					   << "' has more than one declaration initializer."
					   << endl;
				      des->errors += 1;
				      return nullptr;
				}
				owner_class->set_prop_initialized(pidx);
			  }
		    }
	      }

      // IEEE 1800 6.20.6 protects the handle, not its mutable object members.
      // Leave the actual property's const check to class-member elaboration.
      const bool class_member_write = !member_path.empty()
            && reg->unpacked_dimensions() == 0
            && !sr.path_head.empty() && sr.path_head.back().index.empty()
            && dynamic_cast<const netclass_t*>(reg->net_type());
	/* A const-ref call needs the storage address, not permission to
	   assign to it. Packed selects are not reference actuals
	   (IEEE 1800-2017/2023 13.5.2). */
      const netstruct_t*record =
	    dynamic_cast<const netstruct_t*>(reg->net_type());
      bool unpacked_member = record && !record->packed()
	    && member_path.size() == 1
	    && member_path.front().index.empty();
      bool addressable_const_ref = read_only_ref
	    && (member_path.empty() || unpacked_member);
      if (addressable_const_ref && !sr.path_head.empty()) {
	const auto&indices = sr.path_head.back().index;
	unsigned unpacked_dims = reg->unpacked_dimensions();
	if (reg->darray_type()) unpacked_dims += 1;
	if (indices.size() > unpacked_dims)
	  addressable_const_ref = false;
	for (const index_component_t&index : indices)
	  if (index.sel != index_component_t::SEL_BIT)
	    addressable_const_ref = false;
      }
	if (read_only_ref && !addressable_const_ref
	    && !class_member_write) {
	    cerr << get_fileline() << ": error: A const ref actual must be "
		 << "a variable, class property, or unpacked member or element."
		 << endl;
	    des->errors += 1;
	    return nullptr;
	}
      if (reg->get_const() && !is_init && !class_member_write
	  && !addressable_const_ref) {
	    cerr << get_fileline() << ": error: Assignment to const signal `"
	         << reg->name() << "` is not allowed." << endl;
	    des->errors++;
	    return nullptr;
      }

	/* We are elaborating procedural assignments. Wires are not allowed
	   unless this is the l-value of a force. */
      if ((reg->type() != NetNet::REG)
	  && ((reg->type() != NetNet::UNRESOLVED_WIRE) || !reg->coerced_to_uwire())
	  && !is_force) {
	    cerr << get_fileline() << ": error: '" << path_
		 << "' is not a valid l-value for a procedural assignment."
		 << endl;
	    cerr << reg->get_fileline() << ":      : '" << path_ <<
		  "' is declared here as a " << reg->type() << "." << endl;
	    des->errors += 1;
	    return 0;
      }

      ivl_assert(*this, !sr.path_head.empty());
      NetAssign_*res = elaborate_lval_var_(des, scope, is_force, is_cassign,
					 reg, sr.type, member_path,
					 sr.path_head.back().index, is_init,
					 read_only_ref);
      if (is_force && res)
	    res->mark_force_lval();
      return res;
}

NetAssign_*PEIdent::elaborate_lval_var_(Design *des, NetScope *scope,
				        bool is_force, bool is_cassign,
					NetNet *reg, ivl_type_t data_type,
					const pform_name_t tail_path,
					const list<index_component_t>&base_index,
					bool is_init, bool read_only_ref) const
{
	// We are processing the tail of a string of names. For
	// example, the Verilog may be "a.b.c", so we are processing
	// "c" at this point.
      const name_component_t&name_tail = path_.back();

	// Use the last index to determine what kind of select
	// (bit/part/etc) we are processing. For example, the Verilog
	// may be "a.b.c[1][2][<index>]". All but the last index must
	// be simple expressions, only the <index> may be a part
	// select etc., so look at it to determine how we will be
	// proceeding.
      index_component_t::ctype_t use_sel = index_component_t::SEL_NONE;
      if (!name_tail.index.empty())
	    use_sel = name_tail.index.back().sel;

	/* An associative element that is a fixed unpacked array has two
	 * independent indices: a key and a declared fixed-array slot. Keep
	 * both l-value ranks so the target can materialize the keyed array
	 * before storing its selected word. */
	const netqueue_t*assoc = reg->queue_type();
	const netuarray_t*fixed_assoc_element = assoc && assoc->assoc_compat()
	      ? dynamic_cast<const netuarray_t*>(assoc->element_type()) : nullptr;
	if (tail_path.empty() && fixed_assoc_element
	    && name_tail.index.size() >= 2) {
	      if (fixed_assoc_element->static_dimensions().size() != 1
		  || name_tail.index.size() != 2) {
		cerr << get_fileline() << ": sorry: this associative-array value"
		     << " with a fixed unpacked dimension needs one key and"
		     << " one fixed slot index." << endl;
		des->errors += 1;
		return nullptr;
	      }
	      const index_component_t&key = name_tail.index.front();
	      const index_component_t&slot = name_tail.index.back();
	      if (key.sel != index_component_t::SEL_BIT || !key.msb || key.lsb
		  || slot.sel != index_component_t::SEL_BIT || !slot.msb
		  || slot.lsb) {
		cerr << get_fileline() << ": sorry: an associative-array"
		     << " fixed-element write needs simple key and slot indices."
		     << endl;
		des->errors += 1;
		return nullptr;
	      }
	      NetExpr*key_expr = elab_lval_container_index_(
		    des, scope, *this, key, reg);
	      if (!key_expr)
		return nullptr;
	      list<index_component_t>slot_index(1, slot);
	      NetExpr*slot_expr = make_checked_canonical_property_index(
		    des, scope, this, slot_index, fixed_assoc_element, false);
	      if (!slot_expr) {
		delete key_expr;
		return nullptr;
	      }
	      NetAssign_*key_lv = new NetAssign_(reg);
	      key_lv->set_word(key_expr);
	      NetAssign_*slot_lv = new NetAssign_(key_lv);
	      slot_lv->set_word(slot_expr);
	      return slot_lv;
	}

	// Special case: The l-value is an entire memory, or array
	// slice. Detect the situation by noting if the index count
	// is less than the array dimensions (unpacked).
	//
	// This must not fire for a member access on an array element
	// (`arr[i].prop = ...`): there the array index sits on the base
	// component (base_index), while name_tail is the member and
	// carries no index, so name_tail.index.size() is 0. Guard on an
	// empty tail_path so such references fall through to the
	// class/struct member l-value path below.
      bool one_dim_range_slice = reg->unpacked_dimensions() == 1
	    && name_tail.index.size() == 1
	    && (use_sel == index_component_t::SEL_PART
		|| use_sel == index_component_t::SEL_IDX_UP
		|| use_sel == index_component_t::SEL_IDX_DO);
      if (tail_path.empty()
	  && (reg->unpacked_dimensions() > name_tail.index.size()
	      || one_dim_range_slice)) {
	    return elaborate_lval_array_(des, scope, is_force, reg);
      }

	// If we find that the matched variable is a packed struct,
	// then we can handled it with the net_packed_member_ method.
      if (reg->struct_type() && reg->struct_type()->packed() && !tail_path.empty()) {
	      // A CONTAINER (darray/queue/assoc) of a packed struct:
	      // `pm[key].member = v` is a part-write into the keyed ELEMENT
	      // at the member's bit range — NOT a packed-member select of
	      // the container signal (which asserted on the dimension
	      // check, elab_lval.cc ICE). Lower to word(key) + part(off).
	    const name_component_t*cont_base = nullptr;
	    if (reg->darray_type() && path_.name.size() >= 2) {
		    // The container KEY sits on the component BEFORE the
		    // member tail: pm["x"].a -> base comp is pm["x"].
		  auto bit = path_.name.end();
		  --bit; --bit;
		  cont_base = &*bit;
	    }
	    if (cont_base && cont_base->index.size() == 1) {
		  const netstruct_t*es = reg->struct_type();
		  const name_component_t&mcomp = tail_path.front();
		  unsigned long moff = 0;
		  const netstruct_t::member_t*mbr =
			es->packed_member(mcomp.name, moff);
		  if (!mbr) {
			cerr << get_fileline() << ": error: Packed struct "
			     << "has no member " << mcomp.name << "." << endl;
			des->errors += 1;
			return 0;
		  }
		    // A trailing constant bit/part select ON the member
		    // (pm[key].a[3:0] = v) narrows the range: compose the
		    // member base offset with the canonical sub-offset.
		  long sub_off = 0;
		  unsigned long sub_wid = 0;
		  ivl_type_t part_type = mbr->net_type;
		  bool sub_ok = mcomp.index.empty();
		  if (!mcomp.index.empty() && mcomp.index.size() == 1) {
			const netvector_t*fv =
			      dynamic_cast<const netvector_t*>(mbr->net_type);
			const index_component_t&fs = mcomp.index.front();
			if (fv && fv->packed_dims().size() == 1
			    && fv->packed_dims()[0].defined()) {
			      long bm = fv->packed_dims()[0].get_msb();
			      long bl = fv->packed_dims()[0].get_lsb();
			      bool desc = bm >= bl;
			      auto canon = [&](long i)->long {
				    return desc ? (i-bl) : (bl-i); };
			      if (fs.sel == index_component_t::SEL_BIT
				  && fs.msb && !fs.lsb) {
				    NetExpr*ie = elab_and_eval(des, scope,
							       fs.msb, -1);
				    NetEConst*ic = dynamic_cast<NetEConst*>(ie);
				    if (ic && ic->value().is_defined()) {
					  sub_off = canon(ic->value().as_long());
					  sub_wid = 1;
					  part_type = new netvector_t(
						fv->base_type(), 0, 0);
					  sub_ok = true;
				    }
			      } else if (fs.sel == index_component_t::SEL_PART
					 && fs.msb && fs.lsb) {
				    NetExpr*me = elab_and_eval(des, scope,
							       fs.msb, -1);
				    NetExpr*le = elab_and_eval(des, scope,
							       fs.lsb, -1);
				    NetEConst*mc = dynamic_cast<NetEConst*>(me);
				    NetEConst*lc = dynamic_cast<NetEConst*>(le);
				    if (mc && lc && mc->value().is_defined()
					&& lc->value().is_defined()) {
					  long mv = mc->value().as_long();
					  long lv2 = lc->value().as_long();
					  long ca = canon(mv), cb = canon(lv2);
					  sub_off = ca < cb ? ca : cb;
					  sub_wid = (unsigned long)
						((mv>=lv2 ? mv-lv2 : lv2-mv)+1);
					  part_type = new netvector_t(
						fv->base_type(),
						(long)sub_wid-1, 0);
					  sub_ok = true;
				    }
			      }
			}
		  }
		  if (tail_path.size() != 1 || !sub_ok) {
			cerr << get_fileline() << ": sorry: this form of "
			     << "member select on a container element of "
			     << "packed-struct type is not yet supported as "
			     << "an l-value." << endl;
			des->errors += 1;
			return 0;
		  }
		  NetAssign_*lv = new NetAssign_(reg);
		  NetExpr*key = elab_assoc_index(des, scope,
					       cont_base->index.front().msb,
					       reg->queue_type());
		  if (!key)
			return 0;
		  lv->set_word(key);
		  if (sub_wid)
			lv->set_part(new NetEConst(
				       verinum((uint64_t)(moff + sub_off), 64u)),
				     part_type);
		  else
			lv->set_part(new NetEConst(verinum((uint64_t)moff, 64u)),
				     mbr->net_type);
		  return lv;
	    }
	    NetAssign_*lv = new NetAssign_(reg);
	    elaborate_lval_net_packed_member_(des, scope, lv, tail_path, is_force);
	    return lv;
      }

	// Class objects and unpacked structs use nested property l-values.
	// If the root expression is indexed (e.g. queue[idx].member), then
	// walk through the indexed container type to get the element type
	// before deciding whether the remaining tail is a member l-value.
      ivl_type_t member_root_type = data_type;
      if (!member_root_type && !base_index.empty())
	    member_root_type = reg->array_type();
      for (size_t depth = base_index.size()
		 ; member_root_type && depth > 0 ; depth -= 1) {
	    if (const netdarray_t*darray =
			dynamic_cast<const netdarray_t*>(member_root_type)) {
		  member_root_type = darray->element_type();
	    } else if (const netuarray_t*uarray =
			dynamic_cast<const netuarray_t*>(member_root_type)) {
		  member_root_type = uarray->element_type();
	    } else if (const netarray_t*array =
			dynamic_cast<const netarray_t*>(member_root_type)) {
		  member_root_type = array->element_type();
	    } else {
		  break;
	    }
      }
      if (!tail_path.empty() && gn_system_verilog()) {
	    const netclass_t *class_type =
		  dynamic_cast<const netclass_t *>(member_root_type);
	    const netstruct_t *struct_type =
		  dynamic_cast<const netstruct_t *>(member_root_type);
	      // Member access on an element of an unpacked-struct
	      // container -- a static array (netuarray_t), a dynamic
	      // array (netdarray_t), a queue, or an associative array --
	      // is object-backed: each element is stored as an object and
	      // lazily default-constructed at run time, so
	      // container[i].field = ... addresses the right element
	      // (IEEE 1800-2017 7.2.1).
	    if (class_type || (struct_type && !struct_type->packed()))
		  return elaborate_lval_net_class_member_(des, scope, member_root_type,
							  reg, tail_path, base_index,
							  is_cassign || is_force,
							  is_init, read_only_ref);
      }


	// Past this point, we should have taken care of the cases
	// where the name is a member/method of a struct/class.
	// XXXX ivl_assert(*this, method_name.nil());
	//
	// A member tail that is left over here means the base did not
	// resolve to something that HAS members -- normally because an
	// earlier error already rejected it, and elaboration carried on.
	// `module m(interface b); initial b.x = 1;' instantiated with a
	// plain wire reports "the actual for generic interface port must
	// be an interface instance" and then arrived here with `.x'
	// still attached; the assertion turned a clean diagnostic into
	// SIGABRT. Report and fail instead of dying: the compile is
	// already failing, and an abort loses every later diagnostic.
      if (!tail_path.empty()) {
	    cerr << get_fileline() << ": error: `" << reg->name()
		 << "' has no member `" << tail_path << "'";
	    if (des->errors)
		  cerr << " (after an earlier error on this name)";
	    cerr << "." << endl;
	    des->errors += 1;
	    return 0;
      }

      bool need_const_idx = is_cassign || is_force;

      if (reg->unpacked_dimensions() > 0)
	    return elaborate_lval_net_word_(des, scope, reg, need_const_idx, is_force);

	// IEEE 1800-2017 7.10.1: q[lo:$] on the left-hand side denotes
	// the existing suffix of the queue, not one queue element and not a
	// packed part-select.  Preserve the queue type on the l-value so the
	// assignment context checks the complete RHS queue (including its
	// element type), while carrying the lower bound as the slice base.
	// The target has an explicit queue-slice bit, so this cannot be
	// confused with the ordinary indexed-element form q[lo].
      if (use_sel == index_component_t::SEL_PART_LAST) {
	    if (name_tail.index.size() == 1
		&& name_tail.index.front().lsb) {
		  cerr << get_fileline() << ": sorry: assignment to queue slice"
		       << " [lo:$-offset] is not yet supported." << endl;
		  des->errors += 1;
		  return 0;
	    }
	    const netqueue_t*queue_type = reg->queue_type();
	    if (!queue_type || queue_type->assoc_compat()) {
		  cerr << get_fileline() << ": error: [lo:$] is only valid "
		       << "as a positional queue slice l-value." << endl;
		  des->errors += 1;
		  return 0;
	    }

	    if (name_tail.index.size() != 1
		|| !name_tail.index.front().msb) {
		  cerr << get_fileline() << ": error: malformed queue suffix "
		       << "slice l-value." << endl;
		  des->errors += 1;
		  return 0;
	    }

	    if ((reg->type() == NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  report_mixed_assignment_conflict_("queue slice");
		  des->errors += 1;
		  return 0;
	    }

	    NetExpr*lo = elab_and_eval(des, scope,
					 name_tail.index.front().msb, -1);
	    if (!lo)
		  return 0;
	    lo->set_line(*this);

	    NetAssign_*lv = new NetAssign_(reg);
	    lv->set_array_slice(lo, reg->net_type());
	    return lv;
      }

	// This must be after the array word elaboration above!
      if (reg->get_scalar() &&
          use_sel != index_component_t::SEL_NONE) {
	    cerr << get_fileline() << ": error: can not select part of ";
	    if (reg->data_type() == IVL_VT_REAL) cerr << "real: ";
	    else cerr << "scalar: ";
	    cerr << reg->name() << endl;
	    des->errors += 1;
	    return 0;
      }

	// IEEE 1800-2017 11.5.2: a run-time index is legal in ANY packed
	// dimension, and 7.4.6 lets a part-select follow it -- so
	// `d[i][31:0] = ...' and `d[i][b +: 8] = ...' are valid
	// l-values. The per-select helpers below all reach the
	// constant-folding prefix path, which cannot carry a run-time
	// leading index; elaborate_lval_net_part_() in particular falls
	// back to index 0 with a warning, which writes the WRONG
	// element. Take the computed-base path first, exactly as the
	// r-value side does, so both sides address the same bits.
	//
	// SEL_BIT keeps its own hook inside elaborate_lval_net_bit_();
	// this covers only the tails that hook never saw.
      if (!need_const_idx && !reg->darray_type()
	  && (use_sel == index_component_t::SEL_PART
	      || use_sel == index_component_t::SEL_IDX_UP
	      || use_sel == index_component_t::SEL_IDX_DO)
	  && reg->unpacked_dimensions() == 0
	  && packed_base_needs_expr_(des, scope, reg,
				     path_.back().index)) {
	    unsigned long sel_wid = 0;
	    unsigned long carrier_wid = 0;
	    NetExpr*pbase = 0;
	    NetExpr*dynamic_carrier = 0;
	    const list<index_component_t>&all_indices = path_.back().index;
	    if (!all_indices.empty()
		&& all_indices.size() <= reg->packed_dimensions()
		&& (all_indices.back().sel == index_component_t::SEL_IDX_UP
		    || all_indices.back().sel == index_component_t::SEL_IDX_DO
		    || all_indices.back().sel == index_component_t::SEL_PART)) {
		  list<index_component_t> prefix = all_indices;
		  index_component_t tail = prefix.back();
		  prefix.pop_back();
		  netranges_t prefix_dims;
		  size_t tail_dim = all_indices.size()-1;
		  unsigned long suffix_wid = 1;
		  for (size_t idx = 0; idx < reg->packed_dims().size(); ++idx) {
			if (idx < tail_dim)
			      prefix_dims.push_back(reg->packed_dims()[idx]);
			else if (idx > tail_dim)
			      suffix_wid *= reg->packed_dims()[idx].width();
		  }
		  carrier_wid = reg->packed_dims()[tail_dim].width() * suffix_wid;
		  dynamic_carrier = make_checked_canonical_packed_prefix(
			des, scope, this, prefix, prefix_dims, carrier_wid);
		  bool final_ok = false;
		  if (dynamic_carrier && tail.sel == index_component_t::SEL_PART) {
			netranges_t final_dims;
			final_dims.insert(final_dims.end(),
				  reg->packed_dims().begin()+tail_dim,
				  reg->packed_dims().end());
			list<index_component_t> final_index(1, tail);
			final_ok = collapse_packed_member_indices(
			      des, scope, this, final_dims, final_index,
			      pbase, sel_wid, /*quiet=*/true);
		  } else if (dynamic_carrier) {
			calculate_up_do_width_(des, scope, sel_wid);
			NetExpr*raw_base = elab_and_eval(des, scope, tail.msb, -1);
			if (raw_base) {
			      const netrange_t&leaf = reg->packed_dims()[tail_dim];
			      pbase = normalize_variable_base(
				    raw_base, leaf.get_msb(), leaf.get_lsb(),
				    sel_wid,
				    tail.sel == index_component_t::SEL_IDX_UP);
			      pbase = scale_index_to_bits(pbase, suffix_wid, *this);
			      sel_wid *= suffix_wid;
			      final_ok = true;
			}
		  }
		  if (dynamic_carrier && final_ok) {
			// The final select is relative to the checked carrier.
		  } else {
			delete dynamic_carrier;
			dynamic_carrier = 0;
			delete pbase;
			pbase = 0;
		  }
	    }
	    if (!pbase)
		  pbase = collapse_packed_base(des, scope, this, reg,
					       all_indices, sel_wid);
	    if (pbase && sel_wid > 0) {
		  pbase->set_line(*this);
		  if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
			ivl_assert(*this, reg->coerced_to_uwire());
			report_mixed_assignment_conflict_("part select");
			des->errors += 1;
			delete pbase;
			delete dynamic_carrier;
			return 0;
		  }
		  NetAssign_*lv = new NetAssign_(reg);
		  lv->set_part(pbase, sel_wid);
		  if (dynamic_carrier)
			lv->set_dynamic_part_carrier(
			      dynamic_carrier, carrier_wid);
		  return lv;
	    }
	    delete pbase;
	    delete dynamic_carrier;
      }

      if (use_sel == index_component_t::SEL_PART ||
          use_sel == index_component_t::SEL_PART_LAST) {
	    NetAssign_*lv = new NetAssign_(reg);
            if (reg->darray_type()) {
                  if (!elaborate_lval_darray_part_(des, scope, lv, is_force)) {
                        delete lv;
                        return nullptr;
                  }
            } else
		  elaborate_lval_net_part_(des, scope, lv, is_force);
	    return lv;
      }

      if (use_sel == index_component_t::SEL_IDX_UP ||
          use_sel == index_component_t::SEL_IDX_DO) {
	    if (reg->darray_type()) {
	      const name_component_t&nt = path_.back();
	      if (nt.index.size() == 1 && !reg->queue_type()) {
		if (need_const_idx) {
		    cerr << get_fileline() << ": sorry: indexed dynamic-array "
			 << "slice l-values require a procedural assignment."
			 << endl;
		    des->errors += 1;
		    return nullptr;
		}
		if ((reg->type() == NetNet::UNRESOLVED_WIRE) && !is_force) {
		    ivl_assert(*this, reg->coerced_to_uwire());
		    report_mixed_assignment_conflict_("dynamic-array slice");
		    des->errors += 1;
		    return nullptr;
		}
		unsigned count = 0;
		NetExpr*base = elaborate_direct_darray_indexed_base_(
		  des, scope, *this, nt.index.front(), count);
		if (!base) return nullptr;
		netranges_t dimensions;
		dimensions.push_back(netrange_t(0, static_cast<long>(count - 1)));
		ivl_type_t slice_type = new netuarray_t(
		  dimensions, reg->darray_type()->element_type());
		NetAssign_*lv = new NetAssign_(reg);
		lv->set_array_slice(base, slice_type);
		return lv;
	      }
		    // `d[i][base +: w]` / `[base -: w]` into a darray/queue/
		    // assoc element: word(first index) + part(base, w). The
		    // codegen RMW paths (%store/dar/vec4/off and the assoc
		    // %setbits/vec4 sequence) take run-time offsets; only the
		    // width must be constant. Element vectors are canonical
		    // LSB-0, so the source base needs no range shift; the
		    // [b -: w] form addresses down from b (LSB = b-w+1).
		  const netdarray_t*da = reg->darray_type();
		  const netvector_t*ev =
			dynamic_cast<const netvector_t*>(da->element_type());
		  if (nt.index.size() == 2 && ev
		      && ev->packed_dims().size() == 1
		      && ev->packed_dims()[0].defined()
		      && ev->packed_dims()[0].get_msb()
			 >= ev->packed_dims()[0].get_lsb()) {
			const index_component_t&pidx = nt.index.back();
			NetExpr*we = elab_and_eval(des, scope, pidx.lsb, -1, true);
			long w = 0;
			if (we && eval_as_long(w, we) && w > 0) {
			      delete we;
			      NetAssign_*lv = new NetAssign_(reg);
			      NetExpr*key = elab_lval_container_index_(
                                    des, scope, *this, nt.index.front(), reg);
			      NetExpr*base = elab_and_eval(des, scope,
							   pidx.msb, -1);
                              if (!key || !base) {
                                    delete key;
                                    delete base;
                                    delete lv;
                                    return nullptr;
                              }
			      lv->set_word(key);
			      long blsb = ev->packed_dims()[0].get_lsb();
			      if (blsb != 0)
				    base = new NetEBAdd('-', pad_to_width(base, 32, true, *this),
					  new NetEConst(verinum((uint64_t)(uint32_t)(int32_t)blsb, 32)),
					  32, true);
			      if (use_sel == index_component_t::SEL_IDX_DO && w > 1)
				    base = new NetEBAdd('-', pad_to_width(base, 32, true, *this),
					  new NetEConst(verinum((uint64_t)(w-1), 32)),
					  32, true);
			      lv->set_part(base, (unsigned)w);
			      return lv;
			}
			delete we;
		  }
		  cerr << get_fileline() << ": sorry: assignment to an indexed "
		          "part-select of a dynamic-array element is not yet "
		          "supported." << endl;
		  des->errors += 1;
		  return 0;
	    }
	    NetAssign_*lv = new NetAssign_(reg);
	    elaborate_lval_net_idx_(des, scope, lv, use_sel, need_const_idx, is_force);
	    return lv;
      }


      if (use_sel == index_component_t::SEL_BIT
          || use_sel == index_component_t::SEL_BIT_LAST) {
	    if (reg->darray_type() || use_sel == index_component_t::SEL_BIT_LAST) {
		  NetAssign_*lv = new NetAssign_(reg);
                  if (!elaborate_lval_darray_bit_(des, scope, lv, is_force)) {
                        delete lv;
                        return nullptr;
                  }
		  return lv;
	    } else {
		  NetAssign_*lv = new NetAssign_(reg);
		  elaborate_lval_net_bit_(des, scope, lv, need_const_idx, is_force);
		  return lv;
	    }
      }

      ivl_assert(*this, use_sel == index_component_t::SEL_NONE);

      if (reg->type()==NetNet::UNRESOLVED_WIRE && !is_force) {
	    ivl_assert(*this, reg->coerced_to_uwire());
	    report_mixed_assignment_conflict_("variable");
	    des->errors += 1;
	    return 0;
      }

	/* No select expressions. */

      NetAssign_*lv = new NetAssign_(reg);
      lv->set_signed(reg->get_signed());

      return lv;
}

NetAssign_*PEIdent::elaborate_lval_array_(Design *des, NetScope *scope,
				          bool is_force, NetNet *reg) const
{
      if (!gn_system_verilog()) {
	    cerr << get_fileline() << ": error: Assignment to an entire"
		  " array or to an array slice requires SystemVerilog."
		 << endl;
	    des->errors += 1;
	    return 0;
      }

      const name_component_t&name_tail = path_.back();
      if (name_tail.index.empty()) {
	    if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  report_mixed_assignment_conflict_("array");
		  des->errors += 1;
		  return 0;
	    }
	    NetAssign_*lv = new NetAssign_(reg);
	    return lv;
      }

	// A range on the sole unpacked dimension selects a one-dimensional
	// fixed-array slice (7.4.3/7.4.6), not a packed part-select and not a
	// single memory word. Carry its canonical low word and presented range
	// through the same slice l-value representation used by a partial prefix
	// of a multidimensional array.
      fixed_uarray_slice_t range_slice;
      int range_slice_rc = decode_fixed_uarray_slice(
	    des, scope, *this, this, false, range_slice);
      if (range_slice_rc < 0)
	    return 0;
      if (range_slice_rc > 0) {
	    ivl_assert(*this, range_slice.signal == reg);
	    if ((reg->type() == NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  bool overlap = false;
		  for (unsigned long word = 0;
		       !overlap && word < range_slice.count; word += 1) {
			if (reg->test_part_driven(reg->vector_width()-1, 0,
					  range_slice.canonical_base + word))
			      overlap = true;
		  }
		  if (overlap) {
			report_mixed_assignment_conflict_("array slice");
			des->errors += 1;
			return 0;
		  }
	    }

	    netranges_t slice_dims;
	    slice_dims.push_back(range_slice.selected_range);
	    ivl_type_t slice_type =
		  new netuarray_t(slice_dims, range_slice.element_type);
	    NetEConst*base = make_const_val_s(range_slice.canonical_base);
	    base->set_line(*this);
	    NetAssign_*lv = new NetAssign_(reg);
	    lv->set_array_slice(base, slice_type);
	    return lv;
      }

	// A partial index into a multi-dimensional unpacked array selects a
	// sub-array — an array slice, e.g. `m[i]` where m is int[2][3] picks
	// the int[3] row. Support this as the target of an assignment pattern
	// (`m[i] = '{...}`, IEEE 1800-2017 7.6 / 10.9.1): build a slice
	// l-value carrying the flat base word index and the sub-array type.
	// The pattern's element count drives how many words are written, so
	// no separate slice length has to be threaded to the code generator.
      const netsarray_t*full_arr =
	    dynamic_cast<const netsarray_t*>(reg->array_type());
      unsigned nidx = name_tail.index.size();
      if (full_arr && nidx < full_arr->static_dimensions().size()) {
	    const netranges_t&dims = full_arr->static_dimensions();

	      // The slice presents the remaining dimensions as its type.
	    netranges_t sub_dims;
	    for (size_t d = nidx ; d < dims.size() ; d += 1)
		  sub_dims.push_back(dims[d]);
	    netranges_t prefix_dims;
	    for (size_t d = 0 ; d < nidx ; d += 1)
		  prefix_dims.push_back(dims[d]);
	    netuarray_t prefix_type(prefix_dims, full_arr->element_type());

	    // Check every selected dimension before flattening it. A flat
	    // arithmetic address alone aliases e.g. m[0][row_width] to m[1][0].
	    // The checked canonicalizer retains X/Z as an invalid word address,
	    // so the ordinary l-value store performs no operation while its RHS
	    // still evaluates.
	    NetExpr*base = make_checked_canonical_property_index(
		  des, scope, this, name_tail.index, &prefix_type, false);
	    if (!base) return 0;
	    unsigned long row_words = netrange_width(sub_dims);
	    base = scale_index_to_bits(base, row_words, *this);
	    eval_expr(base);
	    base->set_line(*this);
	    ivl_type_t slice_type =
		  new netuarray_t(sub_dims, full_arr->element_type());

	    if ((reg->type() == NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  long first_word = 0;
		  bool have_base = eval_as_long(first_word, base);
		  const NetEConst*base_const = dynamic_cast<const NetEConst*>(base);
		  bool invalid_constant_base = base_const
			&& !base_const->value().is_defined();
		  unsigned long word_count = netrange_width(sub_dims);
		  bool overlap = !invalid_constant_base
			&& (!have_base || first_word < 0 || word_count == 0);
		  for (unsigned long word = 0;
		       !invalid_constant_base && !overlap && word < word_count;
		       word += 1) {
			if (reg->test_part_driven(reg->vector_width()-1, 0,
					  first_word + word))
			      overlap = true;
		  }
		  if (overlap) {
			report_mixed_assignment_conflict_("array slice");
			des->errors += 1;
			delete base;
			return 0;
		  }
	    }

	    NetAssign_*lv = new NetAssign_(reg);
	    lv->set_array_slice(base, slice_type);
	    return lv;
      }

      cerr << get_fileline() << ": sorry: Assignment to an "
	    " array slice is not yet supported."
	   << endl;
      des->errors += 1;
      return 0;
}

static void set_packed_slice_part_(NetAssign_*lv, NetExpr*base,
				   const NetNet*reg, size_t dims_used,
				   unsigned long lwid);

NetAssign_* PEIdent::elaborate_lval_net_word_(Design*des,
					      NetScope*scope,
					      NetNet*reg,
					      bool need_const_idx,
					      bool is_force) const
{
      const name_component_t&name_tail = path_.back();
      ivl_assert(*this, !name_tail.index.empty());

      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_word_: "
		 << "Handle as n-dimensional array." << endl;
      }

      if (name_tail.index.size() < reg->unpacked_dimensions()) {
	    cerr << get_fileline() << ": error: Array " << reg->name()
		 << " needs " << reg->unpacked_dimensions() << " indices,"
		 << " but got only " << name_tail.index.size() << "." << endl;
	    des->errors += 1;
	    return 0;
      }

	/* A signal-backed fixed unpacked prefix can have a Q/D/A leaf. The fixed
	 * word and each dynamic-container index are distinct l-value ranks:
	 * a[fixed][key] first selects the object-array slot that contains the
	 * container, then selects an entry in that value. Treating KEY as a packed
	 * suffix either drops it or reaches packed-dimension normalizers with the
	 * wrong index type. Keep unsupported slices/packed tails loud instead of
	 * silently reinterpreting them. */
	const netdarray_t*fixed_container_leaf = reg->darray_type();
	const size_t fixed_rank = reg->unpacked_dimensions();
	const bool selects_fixed_container_entry = fixed_container_leaf
	      && name_tail.index.size() > fixed_rank;
	if (selects_fixed_container_entry) {
	      list<index_component_t>::const_iterator idx_it =
		    name_tail.index.begin();
	    for (size_t rank = 0 ; rank < fixed_rank ; ++rank, ++idx_it) {
		  if (idx_it->sel != index_component_t::SEL_BIT
		      || !idx_it->msb || idx_it->lsb) {
			cerr << get_fileline() << ": error: fixed unpacked-array "
			     << "prefix of dynamic-container `" << reg->name()
			     << "' requires a simple index at rank " << rank
			     << "." << endl;
			des->errors += 1;
			return 0;
		  }
	    }


	      ivl_type_t selected_type = fixed_container_leaf;
	      for ( ; idx_it != name_tail.index.end(); ++idx_it) {
		    const netarray_t*array_type =
			  dynamic_cast<const netarray_t*>(selected_type);
		    if (!array_type || idx_it->sel != index_component_t::SEL_BIT
			|| !idx_it->msb || idx_it->lsb) {
			  cerr << get_fileline() << ": sorry: assignment through "
			       << "fixed unpacked-array dynamic-container `"
			       << reg->name() << "' requires one simple index at "
			       << "each trailing Q/D/A level; slices and packed "
			       << "tails are not yet supported." << endl;
			  des->errors += 1;
			  return 0;
		    }
		    selected_type = array_type->element_type();
	      }
	}

	// Make sure there are enough indices to address an array element.
      const index_component_t&index_head = name_tail.index.front();
      if (index_head.sel == index_component_t::SEL_PART) {
	    cerr << get_fileline() << ": error: cannot perform a part "
	         << "select on array " << reg->name() << "." << endl;
	    des->errors += 1;
	    return 0;
      }


      NetExpr*canon_index = 0;
      list<NetExpr*>unpacked_indices;
      list<long>unpacked_indices_const;
      string unpacked_indices_text;
      indices_flags flags;
	if (fixed_container_leaf) {
	      const netsarray_t*fixed_type =
		    dynamic_cast<const netsarray_t*>(reg->array_type());
	      if (!fixed_type
		  || fixed_type->static_dimensions().size() != fixed_rank) {
		    cerr << get_fileline() << ": internal error: fixed-prefix "
			 << "dynamic-container signal `" << reg->name()
			 << "' has inconsistent fixed-array type metadata." << endl;
		  des->errors += 1;
		  return 0;
	    }

	    list<index_component_t>fixed_indices;
	    list<index_component_t>::const_iterator fixed_end =
		  name_tail.index.begin();
	    advance(fixed_end, fixed_rank);
	    fixed_indices.assign(name_tail.index.begin(), fixed_end);
	    canon_index = make_checked_canonical_property_index(
		  des, scope, this, fixed_indices, fixed_type, need_const_idx);
      } else {
	      // Evaluate all the index expressions into an "unpacked_indices"
	      // array for ordinary signal-backed fixed arrays.
	    indices_to_expressions(des, scope, this,
		   name_tail.index, reg->unpacked_dimensions(), false,
		   flags, unpacked_indices, unpacked_indices_const);

            // Checked canonicalization consumes the expressions. Preserve
            // their spelling for later scalar-select diagnostics.
            ostringstream index_text;
            index_text << as_indices(unpacked_indices);
            unpacked_indices_text = index_text.str();

	    if (flags.invalid) {
		  // Nothing to do.
	    } else if (flags.undefined) {
		  cerr << get_fileline() << ": warning: "
		       << "ignoring undefined l-value array access "
		       << reg->name() << as_indices(unpacked_indices)
		       << "." << endl;
	    } else if (flags.variable) {
		  if (need_const_idx) {
			cerr << get_fileline() << ": error: array '" << reg->name()
			     << "' index must be a constant in this context." << endl;
			des->errors += 1;
			return 0;
		  }
		  ivl_assert(*this, unpacked_indices.size()
			     == reg->unpacked_dimensions());
		  canon_index = normalize_variable_unpacked(reg, unpacked_indices);
	    } else {
		  ivl_assert(*this, unpacked_indices_const.size()
			     == reg->unpacked_dimensions());
                  const netsarray_t*fixed_type =
                        dynamic_cast<const netsarray_t*>(reg->array_type());
                  bool wide_index = false;
                  for (NetExpr*index : unpacked_indices) {
                        const NetEConst*constant = dynamic_cast<const NetEConst*>(index);
                        if (constant && constant->value().len() > sizeof(long)*8)
                              wide_index = true;
                  }
                  if (fixed_type) {
                        canon_index = make_checked_canonical_property_index(
                              des, this, unpacked_indices, flags, fixed_type);
                        const NetEConst*constant = dynamic_cast<const NetEConst*>(canon_index);
                        if (constant && !constant->value().is_defined()) {
                              delete canon_index;
                              canon_index = nullptr;
                        }
                  } else {
                        canon_index = normalize_variable_unpacked(
                              reg, unpacked_indices_const);
                  }
		  if (canon_index == 0) {
			cerr << get_fileline() << ": warning: "
			     << "ignoring out of bounds l-value array access "
                             << reg->name();
                        if (wide_index)
                              cerr << unpacked_indices_text;
                        else
                              cerr << as_indices(unpacked_indices_const);
                        cerr << "." << endl;
		  }
	    }
      }

	// Ensure invalid array accesses are ignored.
      if (canon_index == 0)
	    canon_index = new NetEConst(verinum(verinum::Vx));
      canon_index->set_line(*this);

      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_word_: "
		 << "canon_index=" << *canon_index << endl;
      }

      if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
	    ivl_assert(*this, reg->coerced_to_uwire());
	    const NetEConst*canon_const = dynamic_cast<NetEConst*>(canon_index);
	    if (!canon_const || reg->test_part_driven(reg->vector_width() - 1, 0,
						      canon_const->value().as_long())) {
		  report_mixed_assignment_conflict_("array word");
		  des->errors += 1;
		  return 0;
	     }
      }

      NetAssign_*lv = new NetAssign_(reg);
      lv->set_word(canon_index);

      if (debug_elaborate)
	    cerr << get_fileline() << ": debug: Set array word=" << *canon_index << endl;

	/* Preserve the fixed word and every trailing Q/D/A index as separate
	 * l-value nodes. The outer node's type is the complete container stored in
	 * the selected fixed slot; each nested word descends exactly one level,
	 * matching the r-value and method-call rank split. */
	if (selects_fixed_container_entry) {
	      list<index_component_t>::const_iterator index_it =
		    name_tail.index.begin();
	      advance(index_it, fixed_rank);
	      ivl_type_t selected_type = fixed_container_leaf;
	      for ( ; index_it != name_tail.index.end(); ++index_it) {
		    NetExpr*index = elab_assoc_index(
			  des, scope, index_it->msb, selected_type);
		    if (!index) {
			  delete lv;
			  return 0;
		    }
		    index->set_line(*this);

		    NetAssign_*entry_lv = new NetAssign_(lv);
		    entry_lv->set_word(index);
		    lv = entry_lv;
		    selected_type = lv->net_type();
	      }
	      return lv;
	}

	/* set_word() preserves the unpacked address. Collapse any remaining
	   packed suffix relative to that word, including a run-time index in
	   a non-final packed dimension. */
      list<index_component_t> packed_indices = name_tail.index;
      for (size_t idx = 0 ; idx < reg->unpacked_dimensions() ; idx += 1)
	    packed_indices.pop_front();
      if (!need_const_idx && packed_indices.size() >= 2) {
	    unsigned long sel_wid = 0;
	    unsigned long carrier_wid = 0;
	    NetExpr*pbase = 0;
	    NetExpr*dynamic_carrier = 0;
	    const netranges_t&dims = reg->packed_dims();
	    if (!packed_indices.empty()
		&& packed_indices.size() <= dims.size()) {
		  list<index_component_t> prefix = packed_indices;
		  index_component_t tail = prefix.back();
		  bool final_select = packed_indices.size() == dims.size();
		  bool indexed_part = tail.sel == index_component_t::SEL_IDX_UP
				   || tail.sel == index_component_t::SEL_IDX_DO;
		  bool tail_operation = final_select || indexed_part
			|| tail.sel == index_component_t::SEL_PART;
		  if (tail_operation)
			prefix.pop_back();
		  size_t prefix_count = prefix.size();
		  size_t tail_dim = packed_indices.size()-1;
		  unsigned long suffix_wid = 1;
		  netranges_t prefix_dims;
		  carrier_wid = 1;
		  for (size_t idx = 0; idx < dims.size(); ++idx) {
			if (idx < prefix_count)
			      prefix_dims.push_back(dims[idx]);
			else if (idx >= tail_dim)
			      carrier_wid *= dims[idx].width();
			if (idx > tail_dim)
			      suffix_wid *= dims[idx].width();
		  }
		  dynamic_carrier = make_checked_canonical_packed_prefix(
			des, scope, this, prefix, prefix_dims, carrier_wid);
		  if (dynamic_carrier && tail_operation) {
			if (tail.sel == index_component_t::SEL_PART) {
			      netranges_t final_dims;
			      final_dims.insert(final_dims.end(),
					dims.begin()+tail_dim, dims.end());
			      list<index_component_t> final_index(1, tail);
			      collapse_packed_member_indices(
				des, scope, this, final_dims, final_index,
				pbase, sel_wid, /*quiet=*/true);
			} else {
			      NetExpr*raw = elab_and_eval(des, scope, tail.msb, -1);
			      if (raw) {
				    const netrange_t&leaf = dims[tail_dim];
				    if (indexed_part)
					  calculate_up_do_width_(des, scope, sel_wid);
				    else
					  sel_wid = 1;
				    pbase = normalize_variable_base(raw,
					  leaf.get_msb(), leaf.get_lsb(), sel_wid,
					  !indexed_part
					  || tail.sel == index_component_t::SEL_IDX_UP);
				    if (indexed_part) {
					  pbase = scale_index_to_bits(
						pbase, suffix_wid, *this);
					  sel_wid *= suffix_wid;
				    }
			      }
			}
		  } else if (dynamic_carrier) {
			pbase = new NetEConst(verinum(0L));
			sel_wid = carrier_wid;
		  }
	    }
	    if (!pbase)
		  pbase = collapse_packed_base(des, scope, this, reg,
					       packed_indices, sel_wid);
	    if (pbase && sel_wid > 0) {
		  pbase->set_line(*this);
		  set_packed_slice_part_(lv, pbase, reg,
					 packed_indices.size(), sel_wid);
		  if (dynamic_carrier)
			lv->set_dynamic_part_carrier(dynamic_carrier, carrier_wid);
		  return lv;
	    }
	    delete pbase;
	    delete dynamic_carrier;
      }


	/* An array word may also have part selects applied to them. */

      index_component_t::ctype_t use_sel = index_component_t::SEL_NONE;
      if (name_tail.index.size() > reg->unpacked_dimensions())
	    use_sel = name_tail.index.back().sel;

      if (reg->get_scalar() &&
          use_sel != index_component_t::SEL_NONE) {
	    cerr << get_fileline() << ": error: can not select part of ";
	    if (reg->data_type() == IVL_VT_REAL) cerr << "real";
	    else cerr << "scalar";
	    cerr << " array word: " << reg->name()
	         << unpacked_indices_text << endl;
	    des->errors += 1;
	    return 0;
      }

      if (use_sel == index_component_t::SEL_BIT)
	    elaborate_lval_net_bit_(des, scope, lv, need_const_idx, is_force);

      if (use_sel == index_component_t::SEL_PART)
	    elaborate_lval_net_part_(des, scope, lv, is_force);

      if (use_sel == index_component_t::SEL_IDX_UP ||
          use_sel == index_component_t::SEL_IDX_DO)
	    elaborate_lval_net_idx_(des, scope, lv, use_sel,
				    need_const_idx, is_force);

      return lv;
}

/*
 * Attach an element select on a multi-dimensional PACKED variable to the
 * l-value, carrying the element's declared type when it has one.
 *
 * `set_part(base, width)' records only how many bits are being written.
 * That is enough for a bare vector, but it throws away the fact that the
 * element is a struct -- and NetAssign_::net_type() then answers null,
 * which is the r-value's only source of context. An assignment pattern
 * has nowhere to get its member types from and dies in the width-driven
 * PEAssignPattern::elaborate_expr, which used to WARN and drop the whole
 * assignment.
 *
 * OpenTitan's spi_device declares
 *
 *     cmd_info_t [NumTotalCmdInfo-1:0] cmd_info;   // PACKED array
 *
 * and fills it with `cmd_info[i] = '{ valid: ..., opcode: ..., ... }'
 * (spi_device.sv:631). Every one of those assignments was silently
 * discarded: the compiled model ran with an all-zero command table.
 *
 * packed_type_after_dims() walks the real type tree, so it stops at the
 * struct rather than dissolving it into bits. When it cannot descend
 * exactly -- the select lands mid-way through one array level -- there
 * is no named type to carry and the width-only form is still right.
 *
 * A slice of a multi-dimensional plain packed vector also keeps its
 * remaining declared dimensions. Ordinary r-values still take the
 * width-driven path, but assignment patterns require those dimensions
 * as their context (for example `x[i][j] = '{default:'1}`).
 */
static void set_packed_slice_part_(NetAssign_*lv, NetExpr*base,
				   const NetNet*reg, size_t dims_used,
				   unsigned long lwid)
{
      ivl_type_t elem = packed_type_after_dims(reg->net_type(), dims_used);
      if (elem && elem->packed() && elem->packed_width() == (long)lwid
	  && dynamic_cast<const netvector_t*>(elem) == 0) {
	    lv->set_part(base, elem);
	    return;
      }

      if (const netvector_t*vec =
		dynamic_cast<const netvector_t*>(reg->net_type())) {
	    const netranges_t&dims = vec->packed_dims();
	    if (dims_used < dims.size()) {
		  netranges_t remain;
		  netranges_t::const_iterator cur = dims.begin();
		  std::advance(cur, dims_used);
		  remain.insert(remain.end(), cur, dims.end());
		  netvector_t*slice_type = new netvector_t(remain,
						       vec->base_type());
		  slice_type->set_signed(vec->get_signed());
		  if (slice_type->packed_width() == (long)lwid) {
			lv->set_part(base, slice_type);
			return;
		  }
		  delete slice_type;
	    }
      }
      lv->set_part(base, lwid);
}

bool PEIdent::elaborate_lval_net_bit_(Design*des,
				      NetScope*scope,
				      NetAssign_*lv,
				      bool need_const_idx,
				      bool is_force) const
{
	// IEEE 1800-2017 11.5.2: a run-time index is legal in ANY packed
	// dimension, so `t[i][j] = ...' with a variable i is a valid
	// l-value. calculate_packed_indices_ can only fold CONSTANT
	// leading indices into a slice offset, so that shape needs the
	// general computed base. False for everything the prefix path
	// already handles, which keeps it in charge of those.
      if (!need_const_idx && lv->sig()->unpacked_dimensions() == 0
	  && packed_base_needs_expr_(des, scope, lv->sig(),
				     path_.back().index)) {
	    NetNet*preg = lv->sig();
	    unsigned long sel_wid = 0;
	    unsigned long carrier_wid = 0;
	    NetExpr*pbase = 0;
	    NetExpr*dynamic_carrier = 0;
	    const list<index_component_t>&all_indices = path_.back().index;
	    const netranges_t&all_dims = preg->packed_dims();
	    if (!all_indices.empty() && all_indices.size() <= all_dims.size()) {
		  list<index_component_t> prefix = all_indices;
		  netranges_t prefix_dims;
		  size_t prefix_count = all_indices.size();
		  bool has_final_bit = prefix_count == all_dims.size();
		  index_component_t tail;
		  if (has_final_bit) {
			tail = prefix.back();
			prefix.pop_back();
			prefix_count -= 1;
		  }
		  carrier_wid = 1;
		  for (size_t idx = 0; idx < all_dims.size(); ++idx) {
			if (idx < prefix_count)
			      prefix_dims.push_back(all_dims[idx]);
			else
			      carrier_wid *= all_dims[idx].width();
		  }
		  dynamic_carrier = make_checked_canonical_packed_prefix(
			des, scope, this, prefix, prefix_dims, carrier_wid);
		  if (dynamic_carrier) {
			if (has_final_bit) {
			      NetExpr*raw = elab_and_eval(des, scope, tail.msb, -1);
			      if (raw) {
				    const netrange_t&leaf = all_dims.back();
				    pbase = normalize_variable_base(raw,
					  leaf.get_msb(), leaf.get_lsb(), 1, true);
				    sel_wid = 1;
			      }
			} else {
			      pbase = new NetEConst(verinum(0L));
			      sel_wid = carrier_wid;
			}
		  }
	    }
	    if (!pbase)
		  pbase = collapse_packed_base(des, scope, this, preg,
					       all_indices, sel_wid);
	    if (pbase && sel_wid > 0) {
		  pbase->set_line(*this);
		  if ((preg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
			ivl_assert(*this, preg->coerced_to_uwire());
			report_mixed_assignment_conflict_("bit select");
			des->errors += 1;
			delete pbase;
			delete dynamic_carrier;
			return false;
		  }
		  set_packed_slice_part_(lv, pbase, preg,
					 path_.back().index.size(), sel_wid);
		  if (dynamic_carrier)
			lv->set_dynamic_part_carrier(dynamic_carrier,
						 carrier_wid);
		  return true;
	    }
	    delete pbase;
	    delete dynamic_carrier;
      }

      list<long>prefix_indices;
      bool rc = calculate_packed_indices_(des, scope, lv->sig(), prefix_indices);
      if (!rc) return false;

      const name_component_t&name_tail = path_.back();
      ivl_assert(*this, !name_tail.index.empty());

      const index_component_t&index_tail = name_tail.index.back();
      ivl_assert(*this, index_tail.msb != 0);
      ivl_assert(*this, index_tail.lsb == 0);

      NetNet*reg = lv->sig();
      ivl_assert(*this, reg);

	// Bit selects have a single select expression. Evaluate the
	// constant value and treat it as a part select with a bit
	// width of 1.
      NetExpr*mux = elab_and_eval(des, scope, index_tail.msb, -1);
      long lsb = 0;
      bool exact_constant_mux = false;
      string exact_constant_text;

      if (mux && mux->expr_type() == IVL_VT_REAL) {
           cerr << get_fileline() << ": error: Index expression for "
                << reg->name() << "[" << *mux
                << "] cannot be a real value." << endl;
           des->errors += 1;
           return false;
      }

      if (const NetEConst*index_con = dynamic_cast<NetEConst*> (mux)) {
	      // The index has a constant defined value.
	    if (index_con->value().is_defined()) {
		  if (reg->data_type() != IVL_VT_STRING
		      && prefix_indices.size()+1 == reg->packed_dims().size()) {
			ostringstream text;
			text << index_con->value();
			exact_constant_text = text.str();
			mux = normalize_variable_bit_base(prefix_indices, mux, reg);
			eval_expr(mux, -1);
			mux->cast_signed(true);
			const NetEConst*canonical =
			      dynamic_cast<const NetEConst*>(mux);
			ivl_assert(*this, canonical);
			ivl_assert(*this, canonical->value().is_defined());
			exact_constant_mux = true;
		  } else {
			lsb = index_con->value().as_long();
			mux = 0;
		  }
	      // The index is undefined and this is a packed array.
	    } else if (prefix_indices.size()+2 <= reg->packed_dims().size()) {
		  long loff;
		  unsigned long lwid;
		  bool rcl = reg->sb_to_slice(prefix_indices, lsb, loff, lwid);
		  ivl_assert(*this, rcl);
		  if (warn_ob_select) {
			cerr << get_fileline()
			     << ": warning: L-value packed array select of "
			     << reg->name();
			if (reg->unpacked_dimensions() > 0) cerr << "[]";
			cerr << " has an undefined index." << endl;
		  }
		  lv->set_part(new NetEConst(verinum(verinum::Vx)), lwid);
		  return true;
	      // The index is undefined and this is a bit select.
	    } else {
		  if (warn_ob_select) {
			cerr << get_fileline()
			     << ": warning: L-value bit select of "
			     << reg->name();
			if (reg->unpacked_dimensions() > 0) cerr << "[]";
			cerr << " has an undefined index." << endl;
		  }
		  lv->set_part(new NetEConst(verinum(verinum::Vx)), 1);
		  return true;
	    }
      }

      if (debug_elaborate && (reg->type()==NetNet::UNRESOLVED_WIRE)) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_bit_: "
		 << "Try to assign bits of variable which is also continuously assigned."
		 << endl;
      }

      if (prefix_indices.size()+2 <= reg->packed_dims().size()) {
	      // Special case: this is a slice of a multi-dimensional
	      // packed array. For example:
	      //   reg [3:0][7:0] x;
	      //   x[2] = ...
	      // This shows up as the prefix_indices being too short
	      // for the packed dimensions of the vector. What we do
	      // here is convert to a "slice" of the vector.
	    if (mux == 0) {
		  long loff;
		  unsigned long lwid;
		  bool rcl = reg->sb_to_slice(prefix_indices, lsb, loff, lwid);
		  if (!rcl) {
			  // Constant OUT-OF-BOUNDS element index on a
			  // multi-dimensional packed variable (m[7] = ...
			  // where m is [3:0][...]). IEEE 1800-2017 11.5.1/
			  // 7.4.6: an out-of-range select write is a no-op.
			  // This used to be an ivl_assert ICE.
			if (warn_ob_select) {
			      cerr << get_fileline() << ": warning: "
				   << "L-value packed array select of "
				   << reg->name()
				   << " is out of bounds (write ignored)."
				   << endl;
			}
			lv->set_part(new NetEConst(verinum(verinum::Vx)),
				     reg->slice_width(prefix_indices.size()+1));
			return true;
		  }

		  if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
			ivl_assert(*this, reg->coerced_to_uwire());
			if (reg->test_part_driven(loff+lwid-1, loff)) {
			      report_mixed_assignment_conflict_("slice");
			      des->errors += 1;
			      return false;
			}
		  }

		  set_packed_slice_part_(lv, new NetEConst(verinum(loff)),
					 reg, prefix_indices.size()+1, lwid);

	    } else {
		  unsigned long lwid;
		  mux = normalize_variable_slice_base(prefix_indices, mux,
						      reg, lwid);

		  if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
			ivl_assert(*this, reg->coerced_to_uwire());
			report_mixed_assignment_conflict_("slice");
			des->errors += 1;
			return false;
		  }

		  set_packed_slice_part_(lv, mux, reg,
					 prefix_indices.size()+1, lwid);
	    }

      } else if (reg->data_type() == IVL_VT_STRING) {
	    ivl_assert(*this, reg->type()!=NetNet::UNRESOLVED_WIRE);
	      // Special case: This is a select of a string
	      // variable. The target of the assignment is a character
	      // select of a string. Force the r-value to be an 8bit
	      // vector and set the "part" to be the character select
	      // expression. The code generator knows what to do with
	      // this.
	    if (debug_elaborate) {
		  cerr << get_fileline() << ": debug: "
		       << "Bit select of string becomes character select." << endl;
	    }
	    if (!mux)
		  mux = new NetEConst(verinum(lsb));
	    lv->set_part(mux, &netvector_t::atom2s8);
	      /* IEEE 1800-2017/2023 6.16: a selected string character has
	       * signed byte type. NetAssign_ keeps compressed-assignment
	       * signedness separately from the selected net type, so carry it
	       * explicitly to preserve >>>= and signed arithmetic semantics. */
	    lv->set_signed(true);

      } else if (mux) {
	      // Non-constant bit mux. Correct the mux for the range
	      // of the vector, then set the l-value part select
	      // expression.
	    if (need_const_idx && !exact_constant_mux) {
		  cerr << get_fileline() << ": error: '" << reg->name()
		       << "' bit select must be a constant in this context."
		       << endl;
		  des->errors += 1;
		  return false;
	    }
	    if (!exact_constant_mux)
		  mux = normalize_variable_bit_base(prefix_indices, mux, reg);

	    if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  if (exact_constant_mux) {
			const NetEConst*canonical =
			      dynamic_cast<const NetEConst*>(mux);
			ivl_assert(*this, canonical);
			verinum_part_select_t overlap =
			      verinum_part_select_overlap(
				    canonical->value(), 1, reg->vector_width());
			if (overlap.width > 0
			    && reg->test_part_driven(
				  static_cast<unsigned>(
					overlap.destination_base),
				  static_cast<unsigned>(
					overlap.destination_base))) {
			      report_mixed_assignment_conflict_("bit select");
			      des->errors += 1;
			      delete mux;
			      return false;
			}
		  } else {
			report_mixed_assignment_conflict_("bit select");
			des->errors += 1;
			return false;
		  }
	    }
	    if (warn_ob_select && exact_constant_mux) {
		  const NetEConst*canonical =
			dynamic_cast<const NetEConst*>(mux);
		  ivl_assert(*this, canonical);
		  verinum_part_select_t overlap = verinum_part_select_overlap(
			canonical->value(), 1, reg->vector_width());
		  if (overlap.width == 0) {
			cerr << get_fileline() << ": warning: bit select "
			     << reg->name() << "[" << exact_constant_text
			     << "] is out of range." << endl;
		  }
	    }

	    lv->set_part(mux, 1);

      } else {
	      // Keep an explicitly written bit select even when it happens
	      // to cover the signal's only bit. A select has the type of the
	      // selected bit, not the named type of the whole object (notably
	      // for a one-bit enum), so erasing it changes assignment typing.
	    long loff = reg->sb_to_idx(prefix_indices,lsb);

	    if (warn_ob_select && (loff < 0 || loff >= (long)reg->vector_width())) {
		  cerr << get_fileline() << ": warning: bit select "
		       << reg->name() << "[" <<lsb<<"]"
		       << " is out of range." << endl;
	    }

	    if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  if (reg->test_part_driven(loff, loff)) {
			report_mixed_assignment_conflict_("bit select");
			des->errors += 1;
			return false;
		  }
	    }

	    lv->set_part(new NetEConst(verinum(loff)), 1);
      }

      return true;
}

/*
 * Compute the element-relative bit offset for a constant index into a
 * dynamic-array (or queue) element that is a simple (single packed
 * dimension) vector, e.g. `d[i][idx]` where the element is `bit[msb:lsb]`.
 * Returns true and sets `off` (normalized, 0 == the lsb bit) on success;
 * false if the element is not a single-dimension vector, in which case the
 * caller emits a loud sorry rather than a silent wrong store.
 */
static bool darray_elem_bit_offset(const netdarray_t*da, long index, long&off)
{
      ivl_type_t et = da->element_type();
      const netvector_t*ev = dynamic_cast<const netvector_t*>(et);
      if (ev == 0)
	    return false;
      const netranges_t&dims = ev->packed_dims();
      if (dims.size() != 1)
	    return false;
      long msb = dims[0].get_msb();
      long lsb = dims[0].get_lsb();
      if (msb >= lsb)
	    off = index - lsb;
      else
	    off = lsb - index;
      return true;
}

/*
 * Fetch the single packed-dimension range [msb:lsb] of a dynamic-array
 * element that is a simple vector. Returns false (caller emits a loud
 * sorry) if the element is not a single-dimension vector.
 */
static bool darray_elem_vector_range(const netdarray_t*da, long&msb, long&lsb)
{
      const netvector_t*ev = dynamic_cast<const netvector_t*>(da->element_type());
      if (ev == 0)
	    return false;
      const netranges_t&dims = ev->packed_dims();
      if (dims.size() != 1)
	    return false;
      msb = dims[0].get_msb();
      lsb = dims[0].get_lsb();
      return true;
}

bool PEIdent::elaborate_lval_darray_bit_(Design*des,
					 NetScope*scope,
					 NetAssign_*lv,
					 bool is_force) const
{
      const name_component_t&name_tail = path_.back();
      ivl_assert(*this, !name_tail.index.empty());

      const index_component_t&word_index = name_tail.index.front();
      ivl_assert(*this, word_index.msb != 0
                 || word_index.sel == index_component_t::SEL_BIT_LAST);
      ivl_assert(*this, word_index.lsb == 0);

      if ((lv->sig()->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
	    ivl_assert(*this, lv->sig()->coerced_to_uwire());
	    report_mixed_assignment_conflict_("darray word");
	    des->errors += 1;
	    return false;
      }

	// First index always selects the darray word. Associative-array keys
	// are assignment-context expressions of the declared index type.
      NetExpr*mux = elab_lval_container_index_(
            des, scope, *this, word_index, lv->sig());
      if (!mux) return false;

      lv->set_word(mux);

	// A trailing bit-select on the darray element, `d[i][bit] = v`.
	// Lower it as an element part-select: keep the word select and add a
	// constant part offset of width 1, which the vvp backend turns into a
	// read-modify-write (%store/dar/vec4/off). Previously the bit index
	// was silently dropped, writing the whole element.
      if (name_tail.index.size() == 2) {
	    const index_component_t&elem_index = name_tail.index.back();
	    if (elem_index.sel == index_component_t::SEL_BIT) {
		    // The bit index may be a run-time expression (UVM's
		    // uvm_packer does `value[i/8][i%8] = ...`). Normalize it
		    // to an element-relative offset; the backend evaluates it
		    // into a register for the read-modify-write.
		  NetExpr*bexpr = elab_and_eval(des, scope, elem_index.msb, -1);
		  long emsb = 0, elsb = 0;
		  const netdarray_t*da = lv->sig()->darray_type();
		  if (bexpr && da && darray_elem_vector_range(da, emsb, elsb)) {
			NetExpr*off = normalize_variable_base(bexpr, emsb, elsb,
							      1, true, 0);
			lv->set_part(off, 1);
			return true;
		  }
		  delete bexpr;
		  cerr << get_fileline() << ": sorry: assignment to a "
		          "dynamic-array element bit-select requires a simple "
		          "vector element." << endl;
		  des->errors += 1;
		  return false;
	    }
      }

      if (name_tail.index.size() != 1) {
	    cerr << get_fileline() << ": sorry: Only single-dimension darray "
	            "index selects are supported in this l-value form." << endl;
	    des->errors += 1;
	    return false;
      }

      return true;
}

/*
 * Assignment to a part-select of a dynamic-array (or queue) element:
 * `d[i][msb:lsb] = v`. Keep the word select and add a constant,
 * element-relative part offset; the vvp backend does a read-modify-write.
 */
bool PEIdent::elaborate_lval_darray_part_(Design*des,
					  NetScope*scope,
					  NetAssign_*lv,
					  bool is_force) const
{
      const name_component_t&name_tail = path_.back();
      ivl_assert(*this, !name_tail.index.empty());

      const index_component_t&word_index = name_tail.index.front();
      ivl_assert(*this, word_index.msb != 0
                 || word_index.sel == index_component_t::SEL_BIT_LAST);

      if ((lv->sig()->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
	    ivl_assert(*this, lv->sig()->coerced_to_uwire());
	    report_mixed_assignment_conflict_("darray word");
	    des->errors += 1;
	    return false;
      }

	// First index selects the darray word.
      NetExpr*mux = elab_lval_container_index_(
            des, scope, *this, word_index, lv->sig());
      if (!mux) return false;
      lv->set_word(mux);

      if (name_tail.index.size() != 2) {
	    cerr << get_fileline() << ": sorry: only a single word index "
	            "with a part-select is supported for a dynamic-array "
	            "element l-value." << endl;
	    des->errors += 1;
	    return false;
      }

      const index_component_t&pindex = name_tail.index.back();
      NetExpr*me = elab_and_eval(des, scope, pindex.msb, -1, true);
      NetExpr*le = elab_and_eval(des, scope, pindex.lsb, -1, true);
      long msb = 0, lsb = 0;
      long moff = 0, loff = 0;
      const netdarray_t*da = lv->sig()->darray_type();
      if (me && le && eval_as_long(msb, me) && eval_as_long(lsb, le) && da
	  && darray_elem_bit_offset(da, msb, moff)
	  && darray_elem_bit_offset(da, lsb, loff)) {
	    delete me;
	    delete le;
	    long base = moff < loff ? moff : loff;
	    long span = moff < loff ? (loff - moff) : (moff - loff);
	    lv->set_part(new NetEConst(verinum(base)), (unsigned long)(span + 1));
	    return true;
      }
      delete me;
      delete le;
      cerr << get_fileline() << ": sorry: assignment to a dynamic-array "
              "element part-select requires constant bounds into a simple "
              "vector element." << endl;
      des->errors += 1;
      return false;
}

bool PEIdent::elaborate_lval_net_part_(Design*des,
				       NetScope*scope,
				       NetAssign_*lv,
				       bool is_force) const
{
      if (lv->sig()->data_type() == IVL_VT_STRING) {
           cerr << get_fileline() << ": error: Cannot part select assign to a string ('"
                << lv->sig()->name() << "')." << endl;
           des->errors += 1;
           return false;
      }

      list<long> prefix_indices;
      bool rc = calculate_packed_indices_(des, scope, lv->sig(), prefix_indices);
      ivl_assert(*this, rc);

	// The range expressions of a part select must be
	// constant. The calculate_parts_ function calculates the
	// values into msb and lsb.
      long msb, lsb;
      bool parts_defined_flag;
      calculate_parts_(des, scope, msb, lsb, parts_defined_flag);

      NetNet*reg = lv->sig();
      ivl_assert(*this, reg);

      if (! parts_defined_flag) {
	    if (warn_ob_select) {
		  cerr << get_fileline()
		       << ": warning: L-value part select of "
		       << reg->name();
		  if (reg->unpacked_dimensions() > 0) cerr << "[]";
		  cerr << " has an undefined index." << endl;
	    }
	      // Use a width of two here so we can distinguish between an
	      // undefined bit or part select.
	    lv->set_part(new NetEConst(verinum(verinum::Vx)), 2);
	    return true;
      }

      const netranges_t&packed = reg->packed_dims();

      long loff, moff;
      if (prefix_indices.size()+1 < packed.size()) {
	      // If there are fewer indices then there are packed
	      // dimensions, then this is a range of slices. Calculate
	      // it into a big slice.
	    bool lrc, mrc;
	    unsigned long lwid, mwid;
	    lrc = reg->sb_to_slice(prefix_indices, lsb, loff, lwid);
	    mrc = reg->sb_to_slice(prefix_indices, msb, moff, mwid);
	    if (!mrc || !lrc) {
		  cerr << get_fileline() << ": error: ";
		  cerr << "Part-select [" << msb << ":" << lsb;
		  cerr << "] exceeds the declared bounds for ";
		  cerr << reg->name();
		  if (reg->unpacked_dimensions() > 0) cerr << "[]";
		  cerr << "." << endl;
		  des->errors += 1;
		  return 0;
	    }
	    assert(lwid == mwid);
	    moff += mwid - 1;
      } else {
	    loff = reg->sb_to_idx(prefix_indices,lsb);
	    moff = reg->sb_to_idx(prefix_indices,msb);
      }

      if (moff < loff) {
	    cerr << get_fileline() << ": error: part select "
		 << reg->name() << "[" << msb<<":"<<lsb<<"]"
		 << " is reversed." << endl;
	    des->errors += 1;
	    return false;
      }

	/* The driver mask uses the signal's flattened, LSB-zero bit
	   numbering. For a multidimensional packed part select, msb/lsb
	   above are indices in the selected source dimension and are not
	   comparable with that mask. Check only after sb_to_slice/sb_to_idx
	   has produced canonical loff/moff. Clip an out-of-range select to
	   the physical bits it can actually drive. */
      if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
	    ivl_assert(*this, reg->coerced_to_uwire());
	    long driven_lo = std::max<long>(loff, 0);
	    long driven_hi = std::min<long>(moff,
					     (long)reg->vector_width() - 1);
	    if (driven_lo <= driven_hi
		&& reg->test_part_driven((unsigned)driven_hi,
					 (unsigned)driven_lo)) {
		  report_mixed_assignment_conflict_("part select");
		  des->errors += 1;
		  return false;
	    }
      }

      unsigned long wid = moff - loff + 1;

	/* Preserve an explicitly written part select even when its range
	   spans the entire vector. IEEE 1800-2017 gives a part select the
	   type of an unsigned packed vector, not the named type of the whole
	   object. Erasing a full-width select therefore makes, for example,
	   `enum_var[3:0] = bits' look like the illegal implicit assignment
	   `enum_var = bits'. */

	/* If the part select extends beyond the extremes of the
	   variable, then output a warning. Note that loff is
	   converted to normalized form so is relative the
	   variable pins. */

      if (warn_ob_select && (loff < 0 || moff >= (long)reg->vector_width())) {
	    cerr << get_fileline() << ": warning: Part select "
		 << reg->name() << "[" << msb<<":"<<lsb<<"]"
		 << " is out of range." << endl;
      }

      lv->set_part(new NetEConst(verinum(loff)), wid);

      return true;
}

bool PEIdent::elaborate_lval_net_idx_(Design*des,
				      NetScope*scope,
				      NetAssign_*lv,
				      index_component_t::ctype_t use_sel,
				      bool need_const_idx,
				      bool is_force) const
{
      if (lv->sig()->data_type() == IVL_VT_STRING) {
           cerr << get_fileline() << ": error: Cannot index part select assign to a string ('"
                << lv->sig()->name() << "')." << endl;
           des->errors += 1;
           return false;
      }

      list<long>prefix_indices;
      bool rc = calculate_packed_indices_(des, scope, lv->sig(), prefix_indices);
      ivl_assert(*this, rc);

      const name_component_t&name_tail = path_.back();;
      ivl_assert(*this, !name_tail.index.empty());

      const index_component_t&index_tail = name_tail.index.back();
      ivl_assert(*this, index_tail.msb != 0);
      ivl_assert(*this, index_tail.lsb != 0);

      NetNet*reg = lv->sig();
      ivl_assert(*this, reg);

      unsigned long wid;
      calculate_up_do_width_(des, scope, wid);

      NetExpr*base = elab_and_eval(des, scope, index_tail.msb, -1);

      if (base && base->expr_type() == IVL_VT_REAL) {
	    cerr << get_fileline() << ": error: Indexed part select base "
	            "expression for ";
	    cerr << lv->sig()->name() << "[" << *base;
	    if (index_tail.sel == index_component_t::SEL_IDX_UP) {
		  cerr << "+:";
	    } else {
		  cerr << "-:";
	    }
	    cerr << wid << "] cannot be a real value." << endl;
	    des->errors += 1;
	    return 0;
      }

	/* A constant packed prefix is part of the selected element, not part of
	 * the final indexed-select arithmetic. Preserve the final base expression
	 * evaluation, but make the normalized base unknown when an earlier packed
	 * dimension is provably invalid. VVP then performs the required no-op for
	 * blocking and nonblocking stores while compound assignments still read
	 * the invalid select value. */
      bool invalid_constant_prefix = false;
      bool valid_constant_prefix = false;
      uint64_t prefix_carrier_off = 0;
      unsigned prefix_carrier_wid = 0;
      if (!prefix_indices.empty()
	  && prefix_indices.size()+1 == reg->packed_dims().size()) {
	    list<index_component_t> packed_indices = path_.back().index;
	    for (size_t idx = 0; idx < reg->unpacked_dimensions(); idx += 1)
		  packed_indices.pop_front();
	    switch (reg->data_type()) {
		case IVL_VT_STRING:
		case IVL_VT_DARRAY:
		case IVL_VT_QUEUE:
		  if (!packed_indices.empty()) packed_indices.pop_front();
		  break;
		default:
		  break;
	    }
	    valid_constant_prefix =
		  packed_indices.size() == prefix_indices.size()+1;
	    list<index_component_t>::const_iterator raw = packed_indices.begin();
	    list<long>::const_iterator folded = prefix_indices.begin();
	    netranges_t::const_iterator dim = reg->packed_dims().begin();
	    for (; valid_constant_prefix && raw != packed_indices.end()
		 && folded != prefix_indices.end();
		 ++raw, ++folded, ++dim) {
		  NetExpr*raw_expr = elab_and_eval(des, scope, raw->msb, -1, false);
		  const NetEConst*raw_constant =
			dynamic_cast<const NetEConst*>(raw_expr);
		  if (raw_constant) {
			if (!raw_constant->value().is_defined()) {
			      invalid_constant_prefix = true;
			      valid_constant_prefix = false;
			} else {
			      bool negative = false;
			      uint64_t magnitude = verinum_signed_magnitude(
				    raw_constant->value(), negative);
			      uint64_t expected = *folded < 0
				    ? uint64_t(-(*folded+1))+1
				    : static_cast<uint64_t>(*folded);
			      long low = min(dim->get_msb(), dim->get_lsb());
			      long high = max(dim->get_msb(), dim->get_lsb());
			      if (negative != (*folded < 0) || magnitude != expected
				  || *folded < low || *folded > high) {
				    invalid_constant_prefix = true;
				    valid_constant_prefix = false;
			      }
			}
		  } else {
			valid_constant_prefix = false;
		  }
		  delete raw_expr;
	    }
	    if (valid_constant_prefix) {
		  const netrange_t&leaf = reg->packed_dims().back();
		  long carrier_off = reg->sb_to_idx(prefix_indices, leaf.get_lsb());
		  ivl_assert(*this, carrier_off >= 0);
		  prefix_carrier_off = static_cast<uint64_t>(carrier_off);
		  prefix_carrier_wid = leaf.width();
	    }
	}
	if (invalid_constant_prefix && base) {
	    unsigned base_width = base->expr_width();
	    NetEConst*xbase = new NetEConst(
		  verinum(verinum::Vx, base_width, true));
	    xbase->set_line(*base);
	    NetEBAdd*invalid_base = new NetEBAdd(
		  '+', base, xbase, base_width, base->has_sign());
	    invalid_base->set_line(*base);
	    base = invalid_base;
	}

      ivl_select_type_t sel_type = IVL_SEL_OTHER;

	/* Normalize a constant in the final packed dimension with the same
	 * width-preserving, signed expression machinery used for a run-time base.
	 * The historical as_long()/sb_to_idx() shortcut both truncated constants
	 * wider than the host long and represented negative canonical offsets as
	 * unsigned constants. Folding this expression retains the exact
	 * mathematical base for later code generation and synthesis. */
      const NetEConst*initial_base_constant =
	    dynamic_cast<const NetEConst*>(base);
      if (initial_base_constant
	  && initial_base_constant->value().is_defined()
	  && prefix_indices.size()+1 == reg->packed_dims().size()) {
	    ostringstream source_base_text;
	    source_base_text << initial_base_constant->value();
	    base = normalize_variable_part_base(
		  prefix_indices, base, reg, wid,
		  use_sel == index_component_t::SEL_IDX_UP);
	    eval_expr(base, -1);
	    base->cast_signed(true);
	    const NetEConst*canonical_base =
		  dynamic_cast<const NetEConst*>(base);
	    ivl_assert(*this, canonical_base);
	    ivl_assert(*this, canonical_base->value().is_defined());

	    verinum_part_select_t overlap = verinum_part_select_overlap(
		  canonical_base->value(), wid, reg->vector_width());
	    if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  if (overlap.width > 0
		      && reg->test_part_driven(
			    static_cast<unsigned>(overlap.destination_base
						 + overlap.width-1),
			    static_cast<unsigned>(overlap.destination_base))) {
			report_mixed_assignment_conflict_("part select");
			des->errors += 1;
			delete base;
			return false;
		  }
	    }

	    if (warn_ob_select) {
		  bool negative = false;
		  uint64_t magnitude = verinum_signed_magnitude(
			canonical_base->value(), negative);
		  uint64_t select_width = wid;
		  uint64_t carrier_width = reg->vector_width();
		  bool selects_before = negative;
		  bool selects_after = negative
			? (magnitude < select_width
			   && select_width-magnitude > carrier_width)
			: (magnitude >= carrier_width
			   || select_width > carrier_width-magnitude);
		  if (selects_before || selects_after) {
			cerr << get_fileline() << ": warning: " << reg->name();
			if (reg->unpacked_dimensions() > 0) cerr << "[]";
			cerr << "[" << source_base_text.str()
			     << (use_sel == index_component_t::SEL_IDX_UP
				   ? "+:" : "-:") << wid << "] is selecting ";
			if (selects_before && selects_after)
			      cerr << "before and after vector.";
			else if (selects_before)
			      cerr << "before vector.";
			else
			      cerr << "after vector.";
			cerr << endl;
		  }
	    }

	// Handle the special case that the base is constant. For this
	// case we can reduce the expression.
      } else if (const NetEConst*base_c = dynamic_cast<NetEConst*> (base)) {
	      // For the undefined case just let the constant pass and
	      // we will handle it in the code generator.
	    if (base_c->value().is_defined()) {
		  long lsv = base_c->value().as_long();
		  long rel_base = 0;

		    // Check whether an unsigned base fits in a 32 bit int.
		    // This ensures correct results for the vlog95 target, and
		    // for the vvp target on LLP64 platforms (Microsoft Windows).
		  if (!base_c->has_sign() && (int32_t)lsv < 0) {
		          // The base is wrapped around.
			delete base;
			if (warn_ob_select) {
			      cerr << get_fileline() << ": warning: " << lv->name();
			      if (lv->word()) cerr << "[]";
			      cerr << "[" << (unsigned long)lsv
				   << (index_tail.sel == index_component_t::SEL_IDX_UP ? "+:" : "-:")
				   << wid << "] is always outside vector." << endl;
			}
			return false;
		  }

		    // Get the signal range.
		  const netranges_t&packed = reg->packed_dims();
		  if (prefix_indices.size()+1 < reg->packed_dims().size()) {
			  // Here we are selecting one or more sub-arrays.
			  // Make this work by finding the indexed sub-arrays and
			  // creating a generated slice that spans the whole range.
			long loff, moff;
			unsigned long lwid, mwid;
			bool lrc, mrc;
			mrc = reg->sb_to_slice(prefix_indices, lsv, moff, mwid);
			if (use_sel == index_component_t::SEL_IDX_UP)
			      lrc = reg->sb_to_slice(prefix_indices, lsv+wid-1, loff, lwid);
			else
			      lrc = reg->sb_to_slice(prefix_indices, lsv-wid+1, loff, lwid);
			if (!mrc || !lrc) {
			      cerr << get_fileline() << ": error: ";
			      cerr << "Part-select [" << lsv;
			      if (index_tail.sel == index_component_t::SEL_IDX_UP) {
				    cerr << "+:";
			      } else {
				    cerr << "-:";
			      }
			      cerr << wid << "] exceeds the declared bounds for ";
			      cerr << reg->name();
			      if (reg->unpacked_dimensions() > 0) cerr << "[]";
			      cerr << "." << endl;
			      des->errors += 1;
			      return 0;
			}
			ivl_assert(*this, lwid == mwid);

			if (moff > loff) {
			      rel_base = loff;
			      wid = moff + mwid - loff;
			} else {
			      rel_base = moff;
			      wid = loff + lwid - moff;
			}
		  } else {
			long offset = 0;
			  // We want the last range, which is where we work.
			const netrange_t&rng = packed.back();
			if (((rng.get_msb() < rng.get_lsb()) &&
			     use_sel == index_component_t::SEL_IDX_UP) ||
			    ((rng.get_msb() > rng.get_lsb()) &&
			     use_sel == index_component_t::SEL_IDX_DO)) {
			      offset = -wid + 1;
			}
			rel_base = reg->sb_to_idx(prefix_indices,lsv) + offset;
		  }
		  delete base;
		  if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
			ivl_assert(*this, reg->coerced_to_uwire());
			if (reg->test_part_driven(rel_base+wid-1, rel_base)) {
			      report_mixed_assignment_conflict_("part select");
			      des->errors += 1;
			      return false;
			}
		  }
		    /* Keep an explicitly written indexed select even when it
		       spans the complete object. Like a fixed part select, it has
		       plain packed-vector typing rather than the named type of the
		       unselected object (notably an enum). */
		  base = new NetEConst(verinum(rel_base));
		  if (warn_ob_select) {
			if (rel_base < 0) {
			      cerr << get_fileline() << ": warning: " << reg->name();
			      if (reg->unpacked_dimensions() > 0) cerr << "[]";
			      cerr << "[" << lsv;
			      if (use_sel == index_component_t::SEL_IDX_UP) {
				    cerr << "+:";
			      } else {
				    cerr << "-:";
			      }
			      cerr << wid << "] is selecting before vector." << endl;
			}
			if (rel_base + wid > reg->vector_width()) {
			      cerr << get_fileline() << ": warning: " << reg->name();
			      if (reg->unpacked_dimensions() > 0) cerr << "[]";
			      cerr << "[" << lsv;
			      if (use_sel == index_component_t::SEL_IDX_UP) {
				    cerr << "+:";
			      } else {
				    cerr << "-:";
			      }
			      cerr << wid << "] is selecting after vector." << endl;
			}
		  }
	    } else if (warn_ob_select) {
		  cerr << get_fileline() << ": warning: L-value indexed part "
		       << "select of " << reg->name();
		  if (reg->unpacked_dimensions() > 0) cerr << "[]";
		  cerr << " has an undefined base." << endl;
	    }
      } else {
	    if (need_const_idx) {
		  cerr << get_fileline() << ": error: '" << reg->name()
		       << "' base index must be a constant in this context."
		       << endl;
		  des->errors += 1;
		  return false;
	    }
	    if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
		  ivl_assert(*this, reg->coerced_to_uwire());
		  bool conflict = true;
		  if (valid_constant_prefix) {
			int word_index = 0;
			bool known_word = lv->word() == 0;
			if (const NetEConst*word =
			      dynamic_cast<const NetEConst*>(lv->word())) {
			      if (word->value().is_defined()) {
				    word_index = word->value().as_long();
				    known_word = true;
			      }
			}
			if (known_word)
			      conflict = reg->test_part_driven(
				    prefix_carrier_off+prefix_carrier_wid-1,
				    prefix_carrier_off, word_index);
		  }
		  if (conflict) {
			report_mixed_assignment_conflict_("part select");
			des->errors += 1;
			return false;
		  }
	    }
	    ivl_assert(*this, prefix_indices.size()+1 == reg->packed_dims().size());
	      /* Correct the mux for the range of the vector. */
	    if (use_sel == index_component_t::SEL_IDX_UP) {
		  base = normalize_variable_part_base(prefix_indices, base,
						      reg, wid, true);
		  sel_type = IVL_SEL_IDX_UP;
	    } else {
		    // This is assumed to be a SEL_IDX_DO.
		  base = normalize_variable_part_base(prefix_indices, base,
						      reg, wid, false);
		  sel_type = IVL_SEL_IDX_DOWN;
	    }
      }

      if (debug_elaborate)
	    cerr << get_fileline() << ": debug: Set part select width="
		 << wid << ", base=" << *base << endl;

      lv->set_part(base, wid, sel_type);

      if (valid_constant_prefix) {
		  const NetEConst*constant_base = dynamic_cast<const NetEConst*>(base);
		  verinum_part_select_t overlap;
		  if (constant_base && constant_base->value().is_defined())
			overlap = verinum_part_select_overlap(
			      constant_base->value(), wid, reg->vector_width());
		  bool within_carrier = constant_base
			&& constant_base->value().is_defined()
			&& overlap.width == wid && overlap.source_base == 0
			&& overlap.destination_base
				   >= prefix_carrier_off
			&& overlap.destination_base
				   - prefix_carrier_off <= prefix_carrier_wid
			&& wid <= prefix_carrier_wid
				   - (overlap.destination_base
				      - prefix_carrier_off);
		  if (!within_carrier)
			lv->set_part_carrier(prefix_carrier_off,
					     prefix_carrier_wid);
      }

      return true;
}

/* Keep the fixed-property path separate from generic unpacked-array indexing:
 * every declared dimension must be checked before the index is flattened. */
static NetExpr* make_canonical_property_lval_index_(
      Design*des, NetScope*scope, const LineInfo*loc,
      const std::list<index_component_t>&indices,
      const netsarray_t*array_type, bool need_const)
{
      return make_checked_canonical_property_index(des, scope, loc, indices,
						     array_type, need_const);
}

/*
 * When the l-value turns out to be a class object, this method is
 * called with the bound variable, and the method path. For example,
 * if path_=a.b.c and a.b binds to the variable, then sig is b, and
 * member_path=c. if path_=obj.base.x, and base_path=obj, then sig is
 * obj, and member_path=base.x.
 */
NetAssign_* PEIdent::elaborate_lval_net_class_member_(Design*des, NetScope*scope,
				    ivl_type_t root_type, NetNet*sig,
				    pform_name_t member_path,
				    const list<index_component_t>&base_index,
				    bool need_const_idx, bool is_init,
				    bool read_only_ref) const
{
      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_class_member_: "
		 << "l-value is property " << member_path
		 << " of " << sig->name() << "." << endl;
      }

	      ivl_assert(*this, root_type);

	/* Track the selected interface view through nested class properties.
	   A module/static virtual-interface signal carries the same qualifier
	   directly as an attribute. */
      perm_string active_modport;
      verinum root_modport =
	    sig->attribute(perm_string::literal("ivl_modport"));
      if (root_modport != verinum())
	    active_modport = lex_strings.make(root_modport.as_string().c_str());

	      NetAssign_*lv = 0;
	      if (!base_index.empty() && sig->darray_type()) {
		    const index_component_t&root_index = base_index.front();
		    if ((root_index.sel == index_component_t::SEL_BIT
			 && (root_index.msb == 0 || root_index.lsb != 0))
			|| (root_index.sel != index_component_t::SEL_BIT
			 && root_index.sel != index_component_t::SEL_BIT_LAST)) {
			  cerr << get_fileline() << ": sorry: "
			       << "Only simple index selects of dynamic/queue class l-value roots are supported."
			       << endl;
			  des->errors += 1;
			  return 0;
		    }

		    NetExpr*root_word_index = elab_lval_container_index_(
			  des, scope, *this, root_index, sig);
		    if (!root_word_index)
			  return 0;

		    lv = new NetAssign_(sig);
		    lv->set_word(root_word_index);
		    root_type = lv->net_type();

		      /* Stacked container selects (`aa[k1][k2].member'): each
		       * further index selects inside the container the previous
		       * one produced, expressed as one more nested word node. */
		    list<index_component_t>::const_iterator more_index = base_index.begin();
		    for (++more_index ; more_index != base_index.end() ; ++more_index) {
			  const netqueue_t*cur_queue =
				dynamic_cast<const netqueue_t*>(root_type);
			  const netdarray_t*cur_darray =
				dynamic_cast<const netdarray_t*>(root_type);
			  if ((!cur_queue && !cur_darray)
			      || more_index->sel != index_component_t::SEL_BIT
			      || !more_index->msb || more_index->lsb) {
				cerr << get_fileline() << ": sorry: this stacked "
				     << "container select before a member l-value "
				     << "is not supported." << endl;
				des->errors += 1;
				delete lv;
				return 0;
			  }
			  NetExpr*nested_key = elab_assoc_index(des, scope,
				more_index->msb, cur_queue, false);
			  if (!nested_key) {
				delete lv;
				return 0;
			  }
			  NetAssign_*outer = new NetAssign_(lv);
			  outer->set_word(nested_key);
			  lv = outer;
			  root_type = lv->net_type();
		    }
	      } else if (!base_index.empty() && sig->unpacked_dimensions() > 0) {
		      // Static unpacked array of class handles, e.g.
		      // `c arr[N]; arr[i].prop = ...`. Convert the element
		      // index to canonical form (accounting for the array's
		      // declared range) exactly as elaborate_lval_net_word_
		      // does, then address the element. Previously only the
		      // dynamic-array case above was handled, so the index was
		      // silently dropped and the l-value referenced the whole
		      // array -- a null word index then crashed tgt-vvp.
		    std::list<NetExpr*> unpacked_indices;
		    std::list<long> unpacked_indices_const;
		    indices_flags flags;
		    indices_to_expressions(des, scope, this,
					   base_index, sig->unpacked_dimensions(),
					   need_const_idx, flags,
					   unpacked_indices, unpacked_indices_const);

		    NetExpr*canon_index = 0;
		    if (flags.invalid || flags.undefined) {
			  // leave canon_index null -> ignored below
		    } else if (flags.variable) {
			  canon_index = normalize_variable_unpacked(sig, unpacked_indices);
		    } else {
			  canon_index = normalize_variable_unpacked(sig, unpacked_indices_const);
		    }
		    if (canon_index == 0)
			  canon_index = new NetEConst(verinum(verinum::Vx));
		    canon_index->set_line(*this);

		    lv = new NetAssign_(sig);
		    lv->set_word(canon_index);
		    root_type = lv->net_type();
	      }

	// Iterate over the member_path. This handles nested class
	// object, by generating nested NetAssign_ object. We start
	// with lv==0, so the front of the member_path is the member
	// of the outermost class. This generates an lv from sig. Then
	// iterate over the remaining of the member_path, replacing
	// the outer lv with an lv that nests the lv from the previous
	// iteration.
	      do {
		      ivl_type_t owner_type = lv ? lv->net_type() : root_type;
		      const netclass_t*owner_class = dynamic_cast<const netclass_t*>(owner_type);
		      const netstruct_t*owner_struct = dynamic_cast<const netstruct_t*>(owner_type);
		      // Packed struct field access within a VIF/class property: compute
	      // the bit offset of the named field within the packed struct and
	      // encode as a part-select on the current lv (read-modify-write at
	      // runtime via %store/prop/v/bits).
	      if (!owner_class && owner_struct && owner_struct->packed()) {
		      // Packed struct field access within a VIF/class
		      // property: walk the member path, accumulating the
		      // canonical bit offset of every hop -- nested struct
		      // fields, indexed packed-array-of-struct members
		      // (constant or RUN-TIME indices), and indexed vector
		      // leaves -- then encode ONE part-select on the current
		      // lv (run-time RMW via %store/prop/v/bits[/x]).
		      // Recovery C4 wave 3: this block previously handled
		      // only constant single-level vector selects; array-of-
		      // struct hops and variable indices were loud sorries.
		    unsigned long member_off = 0;
		    NetExpr*var_off = 0;
		    ivl_type_t cur_type = owner_struct;
		    ivl_type_t part_type = nullptr;
		    unsigned long leaf_wid = owner_struct->packed_width();
		    bool bad = false;

		    while (!member_path.empty()) {
			  name_component_t field_comp = member_path.front();
			  member_path.pop_front();

			  const netstruct_t*cs =
				dynamic_cast<const netstruct_t*>(cur_type);
			  if (!cs || !cs->packed()) {
				cerr << get_fileline() << ": sorry: member `"
				     << field_comp.name << "' cannot be reached"
				     << " through this packed property path yet."
				     << endl;
				bad = true;
				break;
			  }

			  unsigned long hop_off = 0;
			  const netstruct_t::member_t*mbr =
				cs->packed_member(field_comp.name, hop_off);
			  if (!mbr) {
				cerr << get_fileline() << ": error: Packed struct "
				     << "does not have member " << field_comp.name
				     << "." << endl;
				bad = true;
				break;
			  }
			  member_off += hop_off;
			  cur_type = mbr->net_type;
			  leaf_wid = (unsigned long)cur_type->packed_width();
			  part_type = cur_type;

			  if (field_comp.index.empty())
				continue;

			  if (const netvector_t*mv =
				    dynamic_cast<const netvector_t*>(cur_type)) {
				NetExpr*moff = 0;
				unsigned long mwid = 0;
				if (!collapse_packed_member_indices(des, scope, this,
						mv->packed_dims(),
						field_comp.index, moff, mwid))
				      return 0;
				long cfold = 0;
				if (eval_as_long(cfold, moff)) {
				      member_off += cfold;
				      delete moff;
				} else {
				      var_off = var_off
					    ? make_packed_offset_sum(this, var_off, moff)
					    : moff;
				}
				leaf_wid = mwid;
				part_type = new netvector_t(mv->base_type(),
							    (long)mwid - 1, 0);
				cur_type = nullptr;
				continue;
			  }

			  if (const netparray_t*pa =
				    dynamic_cast<const netparray_t*>(cur_type)) {
				NetExpr*moff = 0;
				unsigned long mwid = 0;
				if (!collapse_packed_member_indices(des, scope, this,
						pa->static_dimensions(),
						field_comp.index, moff, mwid))
				      return 0;
				ivl_type_t elem_type = pa->element_type();
				long ew = elem_type->packed_width();
				long cfold = 0;
				if (eval_as_long(cfold, moff)) {
				      member_off += cfold * ew;
				      delete moff;
				} else {
				      if (ew > 1)
					    moff = scale_index_to_bits(moff,
							(unsigned long)ew, *this);
				      var_off = var_off
					    ? make_packed_offset_sum(this, var_off, moff)
					    : moff;
				}
				leaf_wid = mwid * (unsigned long)ew;
				if (mwid == 1) {
				      // A single element: descend into it when the
				      // path continues (array-of-struct hop).
				      part_type = elem_type;
				      cur_type = elem_type;
				} else {
				      part_type = nullptr;
				      cur_type = nullptr;
				}
				continue;
			  }

			  cerr << get_fileline() << ": sorry: an index on packed"
			       << " struct member " << field_comp.name
			       << " of this type is not yet supported here."
			       << endl;
			  bad = true;
			  break;
		    }

		    if (bad || !member_path.empty()) {
			  if (!bad)
				cerr << get_fileline() << ": sorry: this nested"
				     << " packed struct field l-value form is not"
				     << " yet supported." << endl;
			  des->errors += 1;
			  return 0;
		    }

		    if (leaf_wid == 0) {
			  cerr << get_fileline() << ": sorry: packed struct field"
			       << " has non-positive width." << endl;
			  des->errors += 1;
			  return 0;
		    }

		    {
			  NetExpr*base = new NetEConst(
				verinum((uint64_t)member_off, 64u));
			  if (var_off)
				base = make_packed_offset_sum(this, base, var_off);
			  if (part_type)
				lv->set_part(base, part_type);
			  else
				lv->set_part(base, new netvector_t(IVL_VT_LOGIC,
						(long)leaf_wid - 1, 0));
		    }
		    break;
	      }

	      if (!owner_class && !(gn_system_verilog() && owner_struct && !owner_struct->packed())) {
			    if (const char*trace = getenv("IVL_NESTED_PATH_TRACE")) {
				  cerr << get_fileline() << ": debug: "
				       << "nested l-value tail rejected"
				       << " trace=" << trace
				       << " member=" << member_path.front().name
				       << " owner_type=";
				  if (owner_type)
					owner_type->debug_dump(cerr);
				  else
					cerr << "<null>";
				  cerr << endl;
			    }
			    // Dropping the assignment would silently lose the write.
			    cerr << get_fileline() << ": sorry: "
			         << "Nested member path `" << member_path.front().name
			         << "' is not a supported class/struct l-value in this context."
			         << endl;
			    des->errors += 1;
			    return 0;
		      }

	      // Pull the first component from the member_path. We need to
	      // know the current member being worked on, and will
	      // need to know if there are more members to be worked on.
	    name_component_t member_cur = member_path.front();
	    member_path.pop_front();
	      // vif.mp.member: a modport selects a view of the interface
	      // (IEEE 1800-2017 25.5); the next component names an item of
	      // that view, validated against it below.
	    if (owner_class && owner_class->is_interface()
		&& member_cur.index.empty() && !member_path.empty()
		&& owner_class->property_idx_from_name(member_cur.name) < 0
		&& interface_modport_view(owner_class, member_cur.name)) {
		  active_modport = member_cur.name;
		  member_cur = member_path.front();
		  member_path.pop_front();
		  const PModport*view =
			interface_modport_view(owner_class, active_modport);
		  if (owner_class->find_clocking_block(member_cur.name)
		      && !view->clocking_ports.count(member_cur.name)) {
			cerr << get_fileline() << ": error: cannot access clocking "
			     << "block '" << member_cur.name << "' through modport '"
			     << active_modport << "' of interface '"
			     << owner_class->get_name() << "' — that clocking block "
			     << "is not exported by the modport (IEEE 1800-2017 25.5)."
			     << endl;
			des->errors += 1;
			return 0;
		  }
	    }
	    if (owner_class && owner_class->is_interface()
		&& !validate_interface_modport_access(
		      des, this, owner_class, active_modport,
		      member_cur.name, clocking_access(), true)) {
		  delete lv;
		  return 0;
	    }

            if (owner_class && owner_class->is_covergroup()
                  && member_cur.name == perm_string::literal("option")
                  && member_cur.index.empty() && !member_path.empty()
                  && member_path.front().index.empty()) {
                  perm_string option = member_path.front().name;
                  if (option == perm_string::literal("get_inst_coverage")
                        || option == perm_string::literal("per_instance")) {
                        cerr << get_fileline() << ": error: option." << option << " "
                             << "can only be set in a covergroup definition." << endl;
                        des->errors += 1;
                        return 0;
                  }
                  int property = owner_class->covgrp_option_prop(option);
                  if (property >= 0) {
                        member_cur.name = lex_strings.make(
                              owner_class->get_prop_name(property));
                        member_path.pop_front();
                  }
            }

	      // IEEE 1800-2023 19.5/19.7.1: coverpoint and cross labels form
	      // pseudo hierarchy under a covergroup instance. Rewrite the two
	      // supported mutable item options to the synthesized scalar slot on
	      // this particular covergroup object before ordinary property lookup.
	    if (owner_class && owner_class->is_covergroup()
		&& member_cur.index.empty() && member_path.size() >= 2) {
		  const name_component_t&option_comp = member_path.front();
		  auto value_it = member_path.begin();
		  ++value_it;
		  const name_component_t&value_comp = *value_it;
		  if (option_comp.name == perm_string::literal("option")
		      && option_comp.index.empty() && value_comp.index.empty()) {
			int option_prop = owner_class->covgrp_item_option_prop(
			      member_cur.name, value_comp.name);
			if (option_prop >= 0) {
			      member_cur.name = lex_strings.make(owner_class->get_prop_name(
				    static_cast<size_t>(option_prop)));
			      member_path.pop_front();
			      member_path.pop_front();
			} else if (owner_class->has_covgrp_item(member_cur.name)) {
			      cerr << get_fileline() << ": sorry: procedural write of "
				   << "coverpoint/cross option `" << member_cur.name
				   << ".option." << value_comp.name
				   << "' is not supported; only option.at_least and "
				   << "option.weight are implemented." << endl;
			      des->errors += 1;
			      return 0;
			}
		  }
	    }
	    perm_string method_name = member_cur.name;

	    if (debug_elaborate) {
		  cerr << get_fileline() << ": PEIdent::elaborate_lval_net_class_member_: "
		       << "Processing member_cur=" << member_cur
		       << endl;
	    }

	      // Make sure the property/member is really present. If not,
	      // then generate an error message and return an error.
	    int pidx = -1;
	    ivl_type_t ptype = nullptr;
	    perm_string next_modport;
	    if (owner_class) {
		  pidx = const_cast<netclass_t*>(owner_class)->ensure_property_decl(des, method_name);
		  if (pidx < 0) {
			cerr << get_fileline() << ": error: Class " << owner_class->get_name()
			     << " does not have a property " << method_name << "." << endl;
			des->errors += 1;
			return 0;
		  }
		  next_modport = owner_class->get_prop_interface_modport(pidx);

		  property_qualifier_t qual = owner_class->get_prop_qual(pidx);
		  if (qual.test_local() && ! owner_class->test_scope_is_method(scope)) {
			cerr << get_fileline() << ": error: "
			     << "Local property " << owner_class->get_prop_name(pidx)
			     << " is not accessible (l-value) in this context."
			     << " (scope=" << scope_path(scope) << ")" << endl;
			des->errors += 1;

		  } else if (qual.test_static()) {
			  if (qual.test_const()
			      && !(read_only_ref && member_cur.index.empty()
				   && member_path.empty())) {
				cerr << get_fileline() << ": error: Assignment to const class property `"
				     << owner_class->get_prop_name(pidx)
				     << "' is not allowed." << endl;
				des->errors += 1;
				return 0;
			  }

			  // Special case: this is a static property. Ignore the
			  // "this" sig and use the property itself, which is not
			  // part of the sig, as the l-value.
			NetNet*psig = owner_class->get_prop_static_signal((size_t)pidx);
			ivl_assert(*this, psig);

			if (member_cur.index.empty()) {
			      // A static property can be selected through an
			      // object handle (IEEE 1800-2017 8.9). If more of
			      // the member path remains, the static property is
			      // the new root of that path; returning here drops
			      // the tail. In particular,
			      //
			      //   singleton.member = new(...);
			      //
			      // was contextualized as the singleton type and the
			      // generated store overwrote singleton instead of
			      // constructing member. Rebase on the real static
			      // signal and continue walking the complete l-value.
			      delete lv;
			      lv = new NetAssign_(psig);
			      if (member_path.empty())
				    return lv;
			      active_modport = next_modport;
			      continue;
			}

			  // Rebase a member path through a fully indexed fixed
			  // array on the real declaring-class signal. The shared
			  // member walker already understands array-of-struct/class
			  // roots and preserves the canonical flattened word index.
			if (!member_path.empty()) {
			      if (psig->unpacked_dimensions() > 0
				  && member_cur.index.size()
				     == psig->unpacked_dimensions()) {
				    delete lv;
				    return elaborate_lval_net_class_member_(
					  des, scope, psig->net_type(), psig,
					  member_path, member_cur.index,
					  need_const_idx, is_init,
					  read_only_ref);
			      }
			      cerr << get_fileline() << ": sorry: member"
				   << " access into an indexed static-property"
				   << " element requires a complete fixed-array index."
				   << endl;
			      des->errors += 1;
			      return 0;
			}

			  // Indexed static property (recovery D9): the
			  // property is a real signal in the class scope,
			  // so build the same word/element l-value a plain
			  // variable gets. The old unconditional return
			  // dropped the index, so the assignment tried to
			  // store a scalar into the whole array and failed
			  // with a cast error.
			if (psig->unpacked_dimensions() > 0
			    && member_cur.index.size() == psig->unpacked_dimensions()) {
			      list<NetExpr*>uidx;
			      list<long>uidx_const;
			      indices_flags iflags;
			      indices_to_expressions(des, scope, this,
						     member_cur.index,
						     psig->unpacked_dimensions(),
						     false, iflags,
						     uidx, uidx_const);
			      NetExpr*canon = 0;
			      if (!iflags.invalid && !iflags.undefined) {
				    canon = iflags.variable
					  ? normalize_variable_unpacked(psig, uidx)
					  : normalize_variable_unpacked(psig, uidx_const);
			      }
			      if (canon) {
				    canon->set_line(*this);
				    lv = new NetAssign_(psig);
				    lv->set_word(canon);
				    return lv;
			      }
			}
			if (psig->queue_type()
			    && !psig->queue_type()->assoc_compat()
			    && member_cur.index.size() == 1
			    && member_cur.index.front().sel
			       == index_component_t::SEL_PART_LAST
			    && member_cur.index.front().msb) {
			      if (member_cur.index.front().lsb) {
				    cerr << get_fileline() << ": sorry: assignment to"
					 << " queue slice [lo:$-offset] is not yet"
					 << " supported." << endl;
				    des->errors += 1;
				    return 0;
			      }
			      NetExpr*lo = elab_and_eval(
				    des, scope, member_cur.index.front().msb, -1);
			      if (lo) {
				    lo->set_line(*this);
				    delete lv;
				    lv = new NetAssign_(psig);
				    lv->set_array_slice(lo, psig->net_type());
				    return lv;
			      }
			}
			if ((psig->darray_type() || psig->queue_type())
			    && member_cur.index.size() == 1
			    && member_cur.index.front().sel == index_component_t::SEL_BIT) {
			      NetExpr*mux = elab_assoc_index(
				    des, scope, member_cur.index.front().msb,
				    psig->queue_type());
			      if (mux) {
				    lv = new NetAssign_(psig);
				    lv->set_word(mux);
				    return lv;
			      }
			}
			cerr << get_fileline() << ": sorry: this indexed"
			     << " static-property l-value form is not yet"
			     << " supported." << endl;
			des->errors += 1;
			return 0;

		  } else if (qual.test_const()
			     && !(read_only_ref && member_cur.index.empty()
				  && member_path.empty())) {
			// Instance-constant writes are authorized per assignment site by
			// the unlowered constructor control-flow audit. A single mutable
			// bit cannot decide this: assignments in mutually exclusive arms
			// are both legal even though both sites are elaborated.
			NetScope*method_scope =
			      find_method_containing_scope(*this, scope);
			perm_string containing_method_name = method_scope
			      ? method_scope->basename() : perm_string();
			const netclass_t*declaring_class =
			      owner_class->get_prop_declaring_class((size_t)pidx);
			const PFunction*method_pform = method_scope
			      ? method_scope->func_pform() : nullptr;
			const NetScope*declaring_scope = declaring_class
			      ? declaring_class->class_scope() : nullptr;
			const PClass*declaring_pform = declaring_scope
			      ? declaring_scope->class_pform() : nullptr;
			// In-class method scopes do not consistently retain a func_pform
			// pointer during l-value elaboration. Extern methods have no
			// enclosing CLASS scope, so retain the parse-form owner fallback.
			const netclass_t*method_class =
			      find_class_containing_scope(*this, method_scope);
			bool corresponding_class = method_class
			      ? method_class == declaring_class
			      : method_pform && declaring_pform
				&& method_pform->method_of() == declaring_pform->type;
			bool corresponding_constructor =
			      (containing_method_name == perm_string::literal("new")
			       || containing_method_name == perm_string::literal("new@"));
			bool declaration_initializer =
			      owner_class->get_prop_has_decl_initializer((size_t)pidx);

			if (!corresponding_constructor) {
			      cerr << get_fileline() << ": error: "
				   << "Property " << owner_class->get_prop_name(pidx)
				   << " is constant in this method."
				   << " (scope=" << scope_path(scope) << ")" << endl;
			      des->errors++;
			} else if (!corresponding_class) {
			      cerr << get_fileline()
				   << ": error: Instance constant `"
				   << owner_class->get_prop_name(pidx)
				   << "' may be initialized only in the constructor "
				      "of its declaring class (IEEE 1800 8.19)."
				   << endl;
			      des->errors++;
			} else if (!is_init) {
			      if (declaration_initializer) {
				    cerr << get_fileline() << ": error: Global constant "
					 << "class property `"
					 << owner_class->get_prop_name(pidx)
					 << "' may be initialized only in its declaration "
					    "(IEEE 1800 8.19)." << endl;
			      } else {
				    cerr << get_fileline() << ": error: Assignment to "
					 << "instance constant `"
					 << owner_class->get_prop_name(pidx)
					 << "' is not an authorized single assignment in "
					    "its corresponding class constructor "
					    "(IEEE 1800 8.19)." << endl;
			      }
			      des->errors++;
			} else if (declaration_initializer
				   && owner_class->get_prop_initialized(pidx)) {
			      cerr << get_fileline() << ": error: Global constant "
				   << "class property `"
				   << owner_class->get_prop_name(pidx)
				   << "' has more than one declaration initializer."
				   << endl;
			      des->errors++;
			} else {
			      // Keep the existing class-level missing-initializer
			      // bookkeeping, but never use it to authorize or reject a
			      // procedural instance-constant assignment site.
			      if (!owner_class->get_prop_initialized(pidx))
				    owner_class->set_prop_initialized(pidx);

			      if (debug_elaborate) {
				    cerr << get_fileline()
					 << ": PEIdent::elaborate_lval_method_class_member_: "
					 << "Found authorized initializer for property "
					 << owner_class->get_prop_name(pidx) << endl;
			      }
			}
		  }

		  ptype = owner_class->get_prop_type(pidx);

		  // If ptype is not a class type (e.g. it was stored as an
		  // integer-handle fallback due to a circular-elaboration race),
		  // try to recover the real class type directly from the scope
		  // hierarchy, bypassing the elaborate_type cache entirely.
		  if (!dynamic_cast<const netclass_t*>(ptype)) {
			const NetScope*cls_scope = owner_class->class_scope();
			const PClass*pclass = cls_scope ? cls_scope->class_pform() : nullptr;
			if (pclass && pclass->type) {
			      perm_string pname = perm_string::literal(owner_class->get_prop_name(pidx));
			      auto pit = pclass->type->properties.find(pname);
			      if (pit != pclass->type->properties.end() && pit->second.type) {
				    perm_string resolved_name;
				    if (const typeref_t*tref =
					  dynamic_cast<const typeref_t*>(pit->second.type.get())) {
					  if (tref->typedef_ref())
						resolved_name = tref->typedef_ref()->name;
				    } else if (const class_type_t*ct =
					  dynamic_cast<const class_type_t*>(pit->second.type.get())) {
					  resolved_name = ct->name;
				    }
				    if (!resolved_name.nil()) {
					  NetScope*search_scope =
						cls_scope ? const_cast<NetScope*>(cls_scope) : scope;
					  if (netclass_t*resolved =
						ensure_visible_class_type(des, search_scope, resolved_name)) {
						const_cast<netclass_t*>(owner_class)->repair_property_type(
							pname, resolved);
						ptype = resolved;
					  }
				    }
			      }
			}
		  }
	    } else {
		  unsigned long member_off = 0;
		  const netstruct_t::member_t*member =
			owner_struct->packed_member(method_name, member_off);
		  if (!member) {
			cerr << get_fileline() << ": error: Struct "
			     << *owner_struct << " does not have a member "
			     << method_name << "." << endl;
			des->errors += 1;
			return 0;
		  }
		  const auto&members = owner_struct->members();
		  pidx = member - &members.front();
		  ptype = member->net_type;
		  next_modport = member->interface_modport;
	    }

	    lv = lv? new NetAssign_(lv) : new NetAssign_(sig);
	    lv->set_property(method_name, pidx);

	    NetExpr *word_index = nullptr;
	    bool applied_multi_dyn_word_index = false;
	    if (!member_cur.index.empty()) {
		  if (const netparray_t*packed =
			    dynamic_cast<const netparray_t*>(ptype)) {
			// A packed array occupies one property slot. Its indices are
			// bit offsets within that slot, not property word indices.
			NetExpr*part_off = nullptr;
			unsigned long part_wid = 0;
			const netranges_t packed_dims = packed->slice_dimensions();
			if (!collapse_checked_packed_property_indices(
			      des, scope, this, packed_dims, member_cur.index,
			      (unsigned long)packed->packed_width(),
			      part_off, part_wid)) {
			      delete lv;
			      return 0;
			}
			if (part_wid == 0 || part_wid > UINT_MAX) {
			      cerr << get_fileline() << ": error: packed property "
				   << "select width is out of range." << endl;
			      des->errors += 1;
			      delete part_off;
			      delete lv;
			      return 0;
			}
			ivl_type_t part_type = nullptr;
			const netranges_t&dims = packed->static_dimensions();
			bool element_indices = true;
			for (const index_component_t&ic : member_cur.index)
			      element_indices &= ic.sel == index_component_t::SEL_BIT;
			if (element_indices) {
			      part_type = packed_type_after_dims(
				    packed, member_cur.index.size());
			      if (!part_type && member_cur.index.size() < dims.size()) {
				    netranges_t remaining(
					  dims.begin() + member_cur.index.size(),
					  dims.end());
				    part_type = new netparray_t(
					  remaining, packed->element_type());
			      }
			}
			if (!part_type)
			      part_type = new netvector_t(
				    packed->base_type(), (long)part_wid - 1, 0);
			lv->set_part(part_off, part_type);
		  } else if (const netsarray_t *stype = dynamic_cast<const netsarray_t*>(ptype)) {
			  // Element access + bit/part-select of a packed-vector
			  // element (c.arr[i][m:l] = v): leading indices address
			  // the element (word index), the trailing select becomes
			  // a part on it; codegen RMWs via %prop/v/i + %setbits +
			  // %store/prop/v/i.
			const size_t adims = stype->static_dimensions().size();
			const netuarray_t*utype =
			      dynamic_cast<const netuarray_t*>(ptype);
			const netvector_t*evec =
			      packed_select_view_(stype->element_type());

			/* A final range on a one-dimensional fixed class property is
			 * an unpacked-array slice, not an element index. Decode it
			 * before the scalar index path calls indices_to_expressions(),
			 * which intentionally rejects every range. The selected range
			 * remains the l-value type so assignment-pattern contextualization
			 * preserves its declared left-to-right order. */
			fixed_uarray_slice_t range_slice;
			int range_slice_rc = member_path.empty() && utype
			      ? decode_fixed_uarray_slice_select(
				    des, scope, *this, member_cur.index, utype,
				    range_slice)
			      : 0;
			if (range_slice_rc < 0) {
			      delete lv;
			      return 0;
			}
			if (range_slice_rc > 0) {
			      if (dynamic_cast<const netuarray_t*>(
					 range_slice.element_type)) {
				    cerr << get_fileline() << ": sorry: a nested"
					 << " fixed-array class or aggregate property"
					 << " slice is not yet supported as an l-value."
					 << endl;
				    des->errors += 1;
				    delete lv;
				    return 0;
			      }
			      netranges_t slice_dims;
			      slice_dims.push_back(range_slice.selected_range);
			      ivl_type_t slice_type = new netuarray_t(
				    slice_dims, range_slice.element_type);
			      NetEConst*base = make_const_val_s(
				    range_slice.canonical_base);
			      base->set_line(*this);
			      lv->set_array_slice(base, slice_type);
			      ptype = slice_type;

			} else if (dynamic_cast<const netuarray_t*>(
				     stype->element_type())) {
			      /* A typedef can preserve another fixed unpacked array as
			       * this property's element type. An ordinary outer index then
			       * denotes a subarray, but it is not the explicit range slice
			       * carried above. Reject this distinct nested form before the
			       * target can mistake its fixed result type for a range marker. */
			      cerr << get_fileline() << ": sorry: a nested fixed-array"
				   << " class or aggregate property slice is not yet"
				   << " supported as an l-value." << endl;
			      des->errors += 1;
			      delete lv;
			      return 0;

			} else if (member_cur.index.size() < adims) {
			      cerr << get_fileline() << ": error: Got "
				   << member_cur.index.size() << " indices, expecting "
				   << adims << " to index the property "
				   << method_name << "." << endl;
			      des->errors += 1;
			      delete lv;
			      return 0;
			} else if (member_cur.index.size() > adims && evec) {
			      std::list<index_component_t> elem_idx(
				    member_cur.index.begin(),
				    std::next(member_cur.index.begin(), adims));
			      std::list<index_component_t> tail_idx(
				    std::next(member_cur.index.begin(), adims),
				    member_cur.index.end());
			      word_index = make_canonical_property_lval_index_(
				    des, scope, this, elem_idx, stype, false);
			      NetExpr*part_off = 0;
			      unsigned long part_wid = 0;
			      bool tail_ok = word_index
				    && collapse_packed_member_indices(
					 des, scope, this, evec->packed_dims(),
					 tail_idx, part_off, part_wid);
			      if (tail_ok) {
				    lv->set_part(part_off,
					  new netvector_t(evec->base_type(),
							   (long)part_wid-1, 0));
			      }
			      if (!tail_ok) {
				    cerr << get_fileline() << ": sorry: this form"
					 << " of select on array property element "
					 << method_name << " is not yet supported"
					 << " as an l-value." << endl;
				    des->errors += 1;
				    return 0;
			      }
			} else if (member_cur.index.size() > adims
				   && dynamic_cast<const netdarray_t*>(
					 stype->element_type())) {
			      /* A fixed unpacked prefix selects the property slot;
			       * trailing indices select through the queue/associative
			       * value stored in that slot. Represent these as nested
			       * l-values so the property word is never overwritten by
			       * the container key. This also makes a fully-selected
			       * struct/class element available to the next member hop. */
			      std::list<index_component_t>::const_iterator split =
				    std::next(member_cur.index.cbegin(), adims);
			      std::list<index_component_t> fixed_idx(
				    member_cur.index.cbegin(), split);
			      word_index = make_canonical_property_lval_index_(
				    des, scope, this, fixed_idx, stype, false);
			      if (!word_index) {
				    delete lv;
				    return 0;
			      }
			      lv->set_word(word_index);
			      word_index = nullptr;
			      ptype = lv->net_type();

			      for (std::list<index_component_t>::const_iterator idx_it = split
				     ; idx_it != member_cur.index.end(); ++idx_it) {
				    const index_component_t&index_tail = *idx_it;

				      /* A queue/map element can itself be a packed vector. Its
				       * residual brackets are packed selects on the current
				       * element l-value, not more container word indices. */
				    if (const netvector_t*vector_type =
					  packed_select_view_(ptype)) {
					  std::list<index_component_t>packed_indices(
						idx_it, member_cur.index.cend());
					  NetExpr*part_off = nullptr;
					  unsigned long part_wid = 0;
					  if (!collapse_packed_member_indices(
						des, scope, this, vector_type->packed_dims(),
						packed_indices, part_off, part_wid)) {
						cerr << get_fileline() << ": sorry: this packed "
						     << "select after a queue or associative-array "
						     << "element is not yet supported as an l-value."
						     << endl;
						des->errors += 1;
						delete lv;
						return 0;
					  }
					  lv->set_part(part_off,
						new netvector_t(vector_type->base_type(),
							     (long)part_wid - 1, 0));
					  ptype = lv->net_type();
					  break;
				    }

				    const netqueue_t*queue_type =
					  dynamic_cast<const netqueue_t*>(ptype);

				    if (index_tail.sel == index_component_t::SEL_PART_LAST) {
					  std::list<index_component_t>::const_iterator next = idx_it;
					  ++next;
					  if (!queue_type || queue_type->assoc_compat()
					      || next != member_cur.index.end()
					      || !index_tail.msb || index_tail.lsb) {
						cerr << get_fileline() << ": sorry: only a final "
						     << "[lo:$] positional-queue slice is supported "
						     << "after a fixed-array class-property index "
						     << "as an l-value." << endl;
						des->errors += 1;
						delete lv;
						return 0;
					  }

					  NetExpr*lo = elab_and_eval(des, scope,
							       index_tail.msb, -1);
					  if (!lo) {
						delete lv;
						return 0;
					  }
					  lo->set_line(*this);
					  NetAssign_*slice_lv = new NetAssign_(lv);
					  slice_lv->set_array_slice(lo, ptype);
					  lv = slice_lv;
					  ptype = lv->net_type();
					  continue;
				    }

				    if (index_tail.sel == index_component_t::SEL_BIT_LAST) {
					  cerr << get_fileline() << ": sorry: last-element "
					       << "selection after a fixed-array class-property "
					       << "index is not yet supported as an l-value." << endl;
					  des->errors += 1;
					  delete lv;
					  return 0;
				    }
				    if (index_tail.sel != index_component_t::SEL_BIT
					|| !index_tail.msb || index_tail.lsb) {
					  cerr << get_fileline() << ": sorry: this trailing "
					       << "select after a fixed-array class-property "
					       << "index is not yet supported as an l-value." << endl;
					  des->errors += 1;
					  delete lv;
					  return 0;
				    }
				    if (!dynamic_cast<const netarray_t*>(ptype)) {
					  cerr << get_fileline() << ": error: trailing index "
					       << "does not apply to the selected property "
					       << "element." << endl;
					  des->errors += 1;
					  delete lv;
					  return 0;
				    }

				    NetExpr*idx_expr = elab_assoc_index(
					  des, scope, index_tail.msb, ptype);
				    if (!idx_expr) {
					  delete lv;
					  return 0;
				    }

				    NetAssign_*element_lv = new NetAssign_(lv);
				    element_lv->set_word(idx_expr);
				    lv = element_lv;
				    ptype = lv->net_type();
			      }
			} else {
			      word_index = make_canonical_property_lval_index_(
				    des, scope, this, member_cur.index, stype, false);
			      if (!word_index) {
				    delete lv;
				    return 0;
			      }
			}

		  } else if (dynamic_cast<const netdarray_t*>(ptype)) {
			auto packed_element_type = [](ivl_type_t type) -> ivl_type_t {
			      return dynamic_cast<const netvector_t*>(type)
				    || dynamic_cast<const netenum_t*>(type)
				    ? type : nullptr;
			};
			size_t idx_pos = 0;
			const size_t idx_count = member_cur.index.size();
			for (std::list<index_component_t>::const_iterator idx_it =
			       member_cur.index.begin();
			     idx_it != member_cur.index.end(); ) {
			      if (applied_multi_dyn_word_index) {
				    if (ivl_type_t vector_type =
					  packed_element_type(ptype)) {
					  std::list<index_component_t>packed_indices(
						idx_it, member_cur.index.cend());
					  NetExpr*part_off = nullptr;
					  unsigned long part_wid = 0;
					  if (!collapse_packed_member_indices(
						des, scope, this,
						vector_type->slice_dimensions(),
						packed_indices, part_off, part_wid)) {
						cerr << get_fileline() << ": sorry: this packed "
						     << "select after a queue or associative-array "
						     << "element is not yet supported as an l-value."
						     << endl;
						des->errors += 1;
						delete lv;
						return 0;
					  }
					  lv->set_part(part_off,
						new netvector_t(
						      vector_type->base_type(),
						      (long)part_wid - 1, 0));
					  ptype = lv->net_type();
					  idx_pos = idx_count;
					  break;
				    }
			      }

			      const index_component_t&index_tail = *idx_it;
			      if (index_tail.sel != index_component_t::SEL_BIT_LAST
				  && (!index_tail.msb || index_tail.lsb
				      || index_tail.sel != index_component_t::SEL_BIT)) {
				    cerr << get_fileline() << ": sorry: "
					 << "Part-select of dynamic/queue class properties "
					 << "is not supported." << endl;
				    des->errors += 1;
				    delete lv;
				    return 0;
			      }

			      NetExpr*idx_expr = nullptr;
			      if (const netuarray_t*fixed =
				    dynamic_cast<const netuarray_t*>(ptype)) {
				if (fixed->static_dimensions().size() != 1) {
				      cerr << get_fileline() << ": sorry: an associative-array"
					   << " value with more than one fixed dimension is not"
					   << " yet supported as an l-value." << endl;
				      des->errors += 1;
				      delete lv;
				      return 0;
				}
				list<index_component_t>fixed_index(1, index_tail);
				idx_expr = make_canonical_property_lval_index_(
				      des, scope, this, fixed_index, fixed, false);
			      } else if (index_tail.sel == index_component_t::SEL_BIT_LAST) {
			const netqueue_t*queue = dynamic_cast<const netqueue_t*>(ptype);
			if (!queue || queue->assoc_compat()) {
			      cerr << get_fileline()
				   << ": error: `$' requires a positional queue." << endl;
			      des->errors += 1;
			      delete lv;
			      return 0;
			}
			PEIdent*queue_ref = clone_for_reference();
			queue_ref->set_line(*this);
			while (queue_ref->path_.name.size()
			       > path_.name.size() - member_path.size())
			      queue_ref->path_.name.pop_back();
			auto&indices = queue_ref->path_.name.back().index;
			while (indices.size() > idx_pos) indices.pop_back();
			/* ponytail: non-$ indexed receivers fail closed; capture the
			 * receiver once to support them without duplicate side effects. */
			for (const auto&comp : queue_ref->path_.name)
			      for (const auto&index : comp.index)
				    if (index.sel != index_component_t::SEL_BIT_LAST) {
					  cerr << get_fileline() << ": sorry: queue `[$]'"
					       << " property write through a non-`$' indexed"
					       << " receiver is not supported." << endl;
					  des->errors += 1;
					  delete queue_ref;
					  delete lv;
					  return 0;
				    }
			NetExpr*queue_expr = queue_ref->elaborate_expr(
			      des, scope, 0u, 0u);
			delete queue_ref;
			if (!queue_expr) {
			      delete lv;
			      return 0;
			}
			NetESFunc*size = new NetESFunc("$ivl_queue_method$size",
						 &netvector_t::atom2u32, 1);
			size->set_line(*this);
			size->parm(0, queue_expr);
			NetEConst*one = make_const_val(1);
			one->set_line(*this);
			idx_expr = new NetEBAdd('-', size, one, 32, true);
			idx_expr->set_line(*this);
		      } else {
				idx_expr = elab_assoc_index(
				      des, scope, index_tail.msb, ptype);
			      }
			      if (!idx_expr) {
				    delete lv;
				    return 0;
			      }

			      const netdarray_t*word_container =
				    dynamic_cast<const netdarray_t*>(ptype);
			      const bool packed_element_tail =
				    idx_pos + 1 < idx_count && word_container
				    && packed_element_type(
					  word_container->element_type());
			      if (applied_multi_dyn_word_index || packed_element_tail)
				    lv = new NetAssign_(lv);
			      lv->set_word(idx_expr);
			      applied_multi_dyn_word_index = true;

			      ptype = lv->net_type();
			      idx_pos += 1;
			      ++idx_it;
			      if (idx_pos < idx_count
				  && !dynamic_cast<const netarray_t*>(ptype)
				  && !packed_element_type(ptype)) {
				    cerr << get_fileline() << ": error: residual index "
					 << "does not apply to the selected property element."
					 << endl;
				    des->errors += 1;
				    delete lv;
				    return 0;
			      }
			}

		  } else if (const netvector_t*pvec = packed_select_view_(ptype)) {
			// A bit- or part-select of a packed-vector member is a
			// PARTIAL WRITE. This applies both to a class-OBJECT
			// property (owner_class) and to a member of a plain
			// UNPACKED struct (owner_struct): both are cobject-backed
			// and expose the same vec4 property API, so both must
			// read-modify-write (set_part) the vector rather than
			// store the whole property (which silently clobbers the
			// untouched bits) or set a word index (which mis-treats
			// the vector as an unpacked array and crashes the
			// runtime). Constant offsets fold to a NetEConst; run-time
			// offsets flow to the %store/prop/v/bits/x codegen path.
			const netranges_t&dims = pvec->packed_dims();
			const index_component_t&sel = member_cur.index.front();

			NetExpr*canonical_off = 0;
			unsigned long canonical_wid = 0;
			unsigned errors_before = des->errors;
			bool used_dynamic_carrier = false;
			size_t prefix_count = 0;
			for (const index_component_t&index : member_cur.index) {
			      if (index.sel != index_component_t::SEL_BIT
				  || !index.msb || index.lsb)
				    break;
			      prefix_count += 1;
			}
			if (prefix_count != 0
			    && prefix_count + 1 == member_cur.index.size()
			    && prefix_count < dims.size()) {
			      const index_component_t&tail = member_cur.index.back();
			      if (tail.sel == index_component_t::SEL_IDX_UP
				  || tail.sel == index_component_t::SEL_IDX_DO) {
				    bool runtime_checked = false;
				    if (!check_packed_property_tail_range(
					  des, scope, this, tail, dims[prefix_count],
					  &runtime_checked)) {
					  delete lv;
					  return 0;
				    }
				    if (runtime_checked) {
					  std::list<index_component_t>::iterator
						prefix_end = member_cur.index.end();
					  --prefix_end;
					  std::list<index_component_t>prefix(
						member_cur.index.begin(),
						prefix_end);
					  netranges_t prefix_dims(dims.begin(),
							dims.begin() + prefix_count);
					  unsigned long carrier_width =
						(unsigned long)pvec->packed_width();
					  for (size_t idx = 0; idx < prefix_count; ++idx)
						carrier_width /= dims[idx].width();
					  NetExpr*carrier_off =
						make_checked_canonical_packed_prefix(
						      des, scope, this, prefix, prefix_dims,
						      carrier_width, false);
					  netranges_t tail_dims(
						dims.begin() + prefix_count, dims.end());
					  std::list<index_component_t>tail_only(1, tail);
					  NetExpr*tail_off = 0;
					  unsigned long tail_width = 0;
					  if (carrier_off && collapse_packed_member_indices(
						des, scope, this, tail_dims, tail_only,
						tail_off, tail_width, true)) {
						canonical_wid = tail_width;
						lv->set_part(tail_off,
						      new netvector_t(pvec->base_type(),
							     (long)tail_width - 1, 0));
						lv->set_dynamic_part_carrier(
						      carrier_off,
						      (unsigned)carrier_width);
						used_dynamic_carrier = true;
					  } else {
						delete carrier_off;
						delete tail_off;
					  }
				    }
			      }
			}
			if (used_dynamic_carrier) {
			      canonical_off = nullptr;
			} else if (collapse_checked_packed_property_indices(
			      des, scope, this, dims, member_cur.index,
			      (unsigned long)pvec->packed_width(),
			      canonical_off, canonical_wid)) {
			      if (canonical_wid > 0)
				    lv->set_part(canonical_off,
					  new netvector_t(pvec->base_type(),
							 (long)canonical_wid - 1, 0));
			} else {
			      const index_component_t&tail = member_cur.index.back();
			      bool mixed_range = member_cur.index.size() > 1
				    && dims.size() > 1
				    && (tail.sel == index_component_t::SEL_PART
					|| tail.sel == index_component_t::SEL_IDX_UP
					|| tail.sel == index_component_t::SEL_IDX_DO);
			      if (mixed_range && des->errors > errors_before) {
				    delete lv;
				    return 0;
			      }
			{
			      bool handled = false;

			      if (member_cur.index.size() == 1 && dims.size() == 1
				  && dims[0].defined()) {
				    const long base_msb = dims[0].get_msb();
				    const long base_lsb = dims[0].get_lsb();
				    const bool descending = base_msb >= base_lsb;
				      // Build the part's own packed data type so
				      // NetAssign_::net_type()/expr_type() report
				      // the selected sub-vector (logic/bit) rather
				      // than falling back to the class-handle's
				      // IVL_VT_CLASS, which corrupts r-value
				      // elaboration.
				    auto make_part_type = [&](unsigned w)->ivl_type_t {
					  return new netvector_t(pvec->base_type(),
								 (long)w - 1, 0);
				    };
				      // Canonicalize a (possibly non-constant)
				      // source-space index to an LSB-0 bit offset.
				      // Constant offsets fold to NetEConst so the
				      // constant %store/prop/v/bits path is used;
				      // variable offsets flow to the /x path. Only
				      // the descending (msb>=lsb) direction is
				      // handled for variable offsets; ascending
				      // packed vectors fall through to the sorry.
				    auto canon_expr =
					  [&](NetExpr*e)->NetExpr* {
					  if (NetEConst*ec =
						dynamic_cast<NetEConst*>(e)) {
						if (!ec->value().is_defined()) {
						      delete e;
						      return nullptr;
						}

						/* Canonical offsets are compiler metadata, not an
						 * expression-width arithmetic result. Preserve an
						 * arbitrary-width source index exactly and add one
						 * sign bit so subtracting the declared LSB cannot
						 * wrap. Converting through native long both warned
						 * and aliased values below INT64_MIN. */
						unsigned work_width =
						      std::max(ec->value().len(), 64u) + 1;
						verinum index_value(ec->value(), work_width);
						index_value.has_sign(true);
						verinum bound_value((int64_t)base_lsb);
						bound_value = verinum(bound_value, work_width);
						bound_value.has_sign(true);
						verinum offset_value = descending
						      ? index_value - bound_value
						      : bound_value - index_value;
						offset_value.has_sign(true);
						delete e;
						return new NetEConst(offset_value);
					  }
					  if (!descending)
						return nullptr;
					  if (base_lsb == 0)
						return e;
					  return new NetEBAdd('-', e,
						new NetEConst(verinum(
						  (int64_t)base_lsb)), 32, true);
				    };

				    NetExpr*off_expr = nullptr;
				    unsigned wid = 0;

				    if (sel.sel == index_component_t::SEL_BIT
					&& sel.msb && !sel.lsb) {
					  NetExpr*ie = elab_and_eval(des, scope,
								     sel.msb, -1);
					  if (ie) {
						off_expr = canon_expr(ie);
						wid = 1;
					  }
				    } else if ((sel.sel == index_component_t::SEL_IDX_UP
						|| sel.sel == index_component_t::SEL_IDX_DO)
					       && sel.msb && sel.lsb) {
					  NetExpr*be = elab_and_eval(des, scope,
								     sel.msb, -1);
					  NetExpr*we = elab_and_eval(des, scope,
								     sel.lsb, -1);
					  NetEConst*wec =
						dynamic_cast<NetEConst*>(we);
					  if (be && wec
					      && wec->value().is_defined()
					      && wec->value().as_long() > 0) {
						long w = wec->value().as_long();
						off_expr = canon_expr(be);
						  // [b -: w] addresses down from
						  // b, so its LSB is b-(w-1).
						if (off_expr
						    && sel.sel == index_component_t::SEL_IDX_DO
						    && w > 1)
						      off_expr = new NetEBAdd('-',
							off_expr,
							new NetEConst(verinum(
							  (int64_t)(w-1))),
							32, true);
						wid = (unsigned)w;
					  }
				    } else if (sel.sel == index_component_t::SEL_PART
					       && sel.msb && sel.lsb) {
					  NetExpr*me = elab_and_eval(des, scope,
								     sel.msb, -1);
					  NetExpr*le = elab_and_eval(des, scope,
								     sel.lsb, -1);
					  NetEConst*mec =
						dynamic_cast<NetEConst*>(me);
					  NetEConst*lec =
						dynamic_cast<NetEConst*>(le);
					  if (mec && lec
					      && mec->value().is_defined()
					      && lec->value().is_defined()) {
						long mv = mec->value().as_long();
						long lv_ = lec->value().as_long();
						long ca = descending
							? (mv-base_lsb)
							: (base_lsb-mv);
						long cb = descending
							? (lv_-base_lsb)
							: (base_lsb-lv_);
						long off = ca < cb ? ca : cb;
						off_expr = new NetEConst(
						      verinum((int64_t)off));
						wid = (unsigned)
						      ((mv >= lv_ ? mv-lv_
								  : lv_-mv) + 1);
					  }
				    }

				    if (off_expr && wid > 0) {
					  lv->set_part(off_expr,
						       make_part_type(wid));
					  handled = true;
				    }
			      }

			      // Multi-dimensional packed vector (e.g. `logic [3:0][7:0]`):
			      // a slice/element write `m[i]`, a full bit select `m[i][j]`,
			      // or an element then part-select `m[i][3:0]`, for CONSTANT
			      // indices. Reuse prefix_to_slice to map the leading bit indices
			      // to a canonical (LSB-0) offset and slice width, then narrow by
			      // an optional trailing part-select on the innermost dimension.
			      // (IEEE 1800-2017 7.4.) Variable multi-dim indices remain a
			      // loud sorry below.
			      if (!handled && !member_cur.index.empty() && dims.size() > 1) {
			            bool all_def = true;
			            for (size_t di = 0; di < dims.size(); di += 1)
			      	    if (!dims[di].defined()) all_def = false;

			            std::list<long> bit_ix;
			            bool ok = all_def;
			            bool has_part = false;
			            long part_msb = 0, part_lsb = 0;
			            unsigned n_comp = member_cur.index.size();
			            unsigned ci = 0;
			            for (const index_component_t&ic : member_cur.index) {
			      	    ci += 1;
			      	    if (ic.sel == index_component_t::SEL_BIT
			      		&& ic.msb && !ic.lsb) {
			      		  NetExpr*e = elab_and_eval(des, scope, ic.msb, -1);
			      		  NetEConst*ec = dynamic_cast<NetEConst*>(e);
			      		  if (ec && ec->value().is_defined())
			      			bit_ix.push_back(ec->value().as_long());
			      		  else ok = false;
			      	    } else if (ic.sel == index_component_t::SEL_PART
			      		       && ic.msb && ic.lsb && ci == n_comp) {
			      		  has_part = true;
			      		  NetExpr*me = elab_and_eval(des, scope, ic.msb, -1);
			      		  NetExpr*le = elab_and_eval(des, scope, ic.lsb, -1);
			      		  NetEConst*mec = dynamic_cast<NetEConst*>(me);
			      		  NetEConst*lec = dynamic_cast<NetEConst*>(le);
			      		  if (mec && lec && mec->value().is_defined()
			      		      && lec->value().is_defined()) {
			      			part_msb = mec->value().as_long();
			      			part_lsb = lec->value().as_long();
			      		  } else ok = false;
			      	    } else {
			      		  ok = false;
			      	    }
			            }

			            if (ok && !bit_ix.empty() && bit_ix.size() <= dims.size()) {
			      	    long loff = 0; unsigned long lwid = 0;
			      	    std::list<long> prefix = bit_ix;
			      	    long sb = prefix.back(); prefix.pop_back();
			      	    if (prefix_to_slice(dims, prefix, sb, loff, lwid)) {
			      		  long foff = loff;
			      		  unsigned fwid = (unsigned)lwid;
			      		  bool part_ok = true;
			      		  if (has_part) {
			      			const netrange_t&inr = dims.back();
			      			bool idesc = inr.get_msb() >= inr.get_lsb();
			      			long ca = idesc ? part_msb-inr.get_lsb()
			      					: inr.get_lsb()-part_msb;
			      			long cb = idesc ? part_lsb-inr.get_lsb()
			      					: inr.get_lsb()-part_lsb;
			      			long lo = ca < cb ? ca : cb;
			      			unsigned pw = (unsigned)((part_msb>=part_lsb
			      				? part_msb-part_lsb : part_lsb-part_msb)+1);
			      			if (lo < 0 || lo + (long)pw > (long)lwid)
			      			      part_ok = false;
			      			else { foff = loff + lo; fwid = pw; }
			      		  }
			      		  if (part_ok && fwid > 0) {
			      			lv->set_part(new NetEConst(verinum((int64_t)foff)),
			      				     new netvector_t(pvec->base_type(),
			      						     (long)fwid - 1, 0));
			      			handled = true;
			      		  }
			      	    }
			            }
			      }

			      // VARIABLE leading indices on a multi-dim packed vector
			      // (r.m[i][3:0] = v): build the canonical offset as an
			      // expression (per-dim canon x stride), like the read-side
			      // helper; the /x store opcode takes run-time offsets. The
			      // trailing component must be a constant bit or [m:l] part
			      // on the innermost dimension (or absent for a full slice).
			      if (!handled && !member_cur.index.empty() && dims.size() > 1) {
			            bool all_def2 = true;
			            for (size_t di = 0; di < dims.size(); di += 1)
			      	    if (!dims[di].defined()) all_def2 = false;
			            std::vector<long> stride(dims.size(), 1);
			            for (size_t k = dims.size(); k-- > 1; )
			      	    stride[k-1] = stride[k] * (long)dims[k].width();
			            NetExpr*offx = nullptr;
			            long coff = 0;
			            size_t depth2 = 0;
			            unsigned wid2 = 0;
			            bool ok2 = all_def2;
			            size_t nci = member_cur.index.size();
			            size_t cci = 0;
			            for (const index_component_t&ic2 : member_cur.index) {
			      	    cci += 1;
			      	    if (!ok2) break;
			      	    if (ic2.sel == index_component_t::SEL_BIT
			      		&& ic2.msb && !ic2.lsb && depth2 < dims.size()) {
			      		  NetExpr*e2 = elab_and_eval(des, scope, ic2.msb, -1);
			      		  if (!e2) { ok2 = false; break; }
			      		  const netrange_t&r2 = dims[depth2];
			      		  bool d2 = r2.get_msb() >= r2.get_lsb();
			      		  if (NetEConst*ec2 = dynamic_cast<NetEConst*>(e2)) {
			      			if (!ec2->value().is_defined()) { ok2=false; break; }
			      			long i2 = ec2->value().as_long();
			      			coff += (d2 ? i2-r2.get_lsb() : r2.get_lsb()-i2)
			      			        * stride[depth2];
			      			delete e2;
			      		  } else {
			      			e2 = pad_to_width(e2, 32, true, *this);
			      			if (r2.get_lsb() != 0)
			      			      e2 = d2
			      				? new NetEBAdd('-', e2, new NetEConst(verinum((uint64_t)(uint32_t)(int32_t)r2.get_lsb(), 32)), 32, true)
			      				: new NetEBAdd('-', new NetEConst(verinum((uint64_t)(uint32_t)(int32_t)r2.get_lsb(), 32)), e2, 32, true);
			      			else if (!d2)
			      			      { ok2 = false; break; }
			      			if (stride[depth2] != 1)
			      			      e2 = new NetEBMult('*', e2, new NetEConst(verinum((uint64_t)stride[depth2], 32)), 32, true);
			      			offx = offx ? new NetEBAdd('+', offx, e2, 32, true) : e2;
			      		  }
			      		  depth2 += 1;
			      		  if (cci == nci)
			      			wid2 = (depth2 == dims.size()) ? 1 : (unsigned)stride[depth2-1];
			      	    } else if (ic2.sel == index_component_t::SEL_PART
			      		       && ic2.msb && ic2.lsb && cci == nci
			      		       && depth2 == dims.size()-1) {
			      		  NetExpr*m2 = elab_and_eval(des, scope, ic2.msb, -1);
			      		  NetExpr*l2 = elab_and_eval(des, scope, ic2.lsb, -1);
			      		  NetEConst*mc2 = dynamic_cast<NetEConst*>(m2);
			      		  NetEConst*lc2 = dynamic_cast<NetEConst*>(l2);
			      		  if (!mc2 || !lc2 || !mc2->value().is_defined()
			      		      || !lc2->value().is_defined()) { ok2=false; break; }
			      		  const netrange_t&ir2 = dims.back();
			      		  bool id2 = ir2.get_msb() >= ir2.get_lsb();
			      		  long mv2 = mc2->value().as_long();
			      		  long lv3 = lc2->value().as_long();
			      		  long ca2 = id2 ? mv2-ir2.get_lsb() : ir2.get_lsb()-mv2;
			      		  long cb2 = id2 ? lv3-ir2.get_lsb() : ir2.get_lsb()-lv3;
			      		  coff += (ca2 < cb2 ? ca2 : cb2);
			      		  wid2 = (unsigned)((mv2>=lv3 ? mv2-lv3 : lv3-mv2)+1);
			      	    } else {
			      		  ok2 = false;
			      	    }
			            }
			            if (ok2 && wid2 > 0 && offx) {
			      	    NetExpr*base2 = coff
			      		  ? new NetEBAdd('+', offx, new NetEConst(verinum((uint64_t)(uint32_t)(int32_t)coff, 32)), 32, true)
			      		  : offx;
			      	    lv->set_part(base2,
			      			 new netvector_t(pvec->base_type(), (long)wid2-1, 0));
			      	    handled = true;
			            }
			      }

			      if (!handled) {
				    cerr << get_fileline() << ": sorry: "
					 << "This form of partial write to packed "
					 << "vector member " << method_name
					 << " (unsupported select form) is not"
					 << " yet supported." << endl;
				    des->errors += 1;
			      }
			}
			}
		  } else {
			cerr << get_fileline() << ": warning: "
			     << "Index expressions on this property type used as "
			     << "compile-progress fallback." << endl;
		  }
	    }

	    if (const netuarray_t *tmp_ua = dynamic_cast<const netuarray_t*>(ptype)) {
		  const auto &dims = tmp_ua->static_dimensions();

		  if (debug_elaborate) {
			cerr << get_fileline() << ": PEIdent::elaborate_lval_method_class_member_: "
			     << "Property " << method_name
			     << " has " << dims.size() << " dimensions, "
			     << " got " << member_cur.index.size() << " indices." << endl;
			if (word_index) {
			      cerr << get_fileline() << ": PEIdent::elaborate_lval_method_class_member_: "
				   << "Canonical index is:" << *word_index << endl;
			}
		  }

		  if (!member_cur.index.empty()
		      && dims.size() != member_cur.index.size()
		      && !(member_cur.index.size() > dims.size()
			   && packed_select_view_(tmp_ua->element_type()))) {
			cerr << get_fileline() << ": error: "
			     << "Got " << member_cur.index.size() << " indices, "
			     << "expecting " << dims.size()
			     << " to index the property " << method_name << "." << endl;
			des->errors++;
		  }
	    }

	    if (word_index)
		  lv->set_word(word_index);

	      // Preserve a virtual-interface property's selected view through
	      // the next member hop; an ordinary property clears it.
	    active_modport = next_modport;

      } while (!member_path.empty());


      return lv;
}

/*
 * This method is caled to handle l-value identifiers that are packed
 * structs. The lv is already attached to the variable, so this method
 * calculates the part select that is defined by the member_path. For
 * example, if the path_ is main.sub.sub_local, and the variable is
 * main, then we know at this point that main is a packed struct, and
 * lv contains the reference to the bound variable (main). In this
 * case member_path==sub.sub_local, and it is up to this method to
 * work out the part select that the member_path represents.
 */
bool PEIdent::elaborate_lval_net_packed_member_(Design*des, NetScope*scope,
						NetAssign_*lv,
						pform_name_t member_path,
						bool is_force) const
{
      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_packed_member_: "
		 << "path_=" << path_
		 << " member_path=" << member_path
		 << endl;
      }

      NetNet*reg = lv->sig();
      ivl_assert(*this, reg);

      const netstruct_t*struct_type = reg->struct_type();
      ivl_assert(*this, struct_type);
      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_packed_member_: "
		 << "Type=" << *struct_type
		 << endl;
      }

      if (! struct_type->packed()) {
	      // SV compile-progress fallback: unpacked struct l-value
	      // member access is not fully implemented yet.  Instead of
	      // rejecting the entire statement, walk the member path to
	      // find the leaf member type and create a simplified l-value
	      // that allows elaboration to continue.
	    const netstruct_t*cur_stype = struct_type;
	    ivl_type_t leaf_type = nullptr;
	    pform_name_t mp_copy = member_path;
	    while (!mp_copy.empty() && cur_stype) {
		  const name_component_t& mc = mp_copy.front();
		  unsigned long dummy_off;
		  const netstruct_t::member_t* mbr =
			cur_stype->packed_member(mc.name, dummy_off);
		  if (!mbr) break;
		  leaf_type = mbr->net_type;
		  mp_copy.pop_front();
		  cur_stype = dynamic_cast<const netstruct_t*>(leaf_type);
	    }
	    if (leaf_type) {
		  long pw = leaf_type->packed_width();
		  if (pw > 0) {
			lv->set_part(new NetEConst(verinum((uint64_t)0, 32)),
				     (unsigned)pw);
		  }
	    }
	    return true;
      }

	// Looking for the base name. We need that to know about
	// indices we may need to apply. This is to handle the case
	// that the base is an array of structs, and not just a
	// struct.
      pform_name_t::const_reverse_iterator name_idx = path_.name.rbegin();
      for (size_t idx = 1 ; idx < member_path.size() ; idx += 1)
	    ++ name_idx;
      if (name_idx->name != peek_head_name(member_path)) {
	    cerr << get_fileline() << ": internal error: "
		 << "name_idx=" << name_idx->name
		 << ", expecting member_name=" << peek_head_name(member_path)
		 << endl;
	    des->errors += 1;
	    return false;
      }
      ivl_assert(*this, name_idx->name == peek_head_name(member_path));
      ++ name_idx;
      const name_component_t&name_base = *name_idx;

	// An UNPACKED array of a PACKED struct (`pair_t arr[N]; arr[i].m =`)
	// indexes the unpacked element with name_base.index and then
	// part-selects the member off the element vector. Set the array
	// word index on the l-value here; the member part-select (off /
	// use_width computed below) is relative to the element.
      bool ua_of_packed = reg->unpacked_dimensions() > 0
	    && struct_type->packed()
	    && !name_base.index.empty()
	    && name_base.index.size() == reg->unpacked_dimensions();
      if (ua_of_packed) {
	    std::list<NetExpr*> ua_idx;
	    std::list<long> ua_idx_const;
	    indices_flags ua_flags;
	    indices_to_expressions(des, scope, this, name_base.index,
				   reg->unpacked_dimensions(), false, ua_flags,
				   ua_idx, ua_idx_const);
	    NetExpr*ua_canon = 0;
	    if (!ua_flags.invalid && !ua_flags.undefined)
		  ua_canon = ua_flags.variable
			? normalize_variable_unpacked(reg, ua_idx)
			: normalize_variable_unpacked(reg, ua_idx_const);
	    if (!ua_canon)
		  return false;
	    ua_canon->set_line(*this);
	    lv->set_word(ua_canon);
      } else {
	      // Shouldn't be seeing unpacked arrays of packed structs...
	    ivl_assert(*this, reg->unpacked_dimensions() == 0);
      }

	// These make up the "part" select that is the equivilent of
	// following the member path through the nested structs. To
	// start with, the off[set] is zero, and use_width is the
	// width of the entire variable. The first member_comp is at
	// some offset within the variable, and will have a reduced
	// width. As we step through the member_path the off
	// increases, and use_width shrinks.
      unsigned long off = 0;
      unsigned long use_width = struct_type->packed_width();
	// Run-time member-offset contributions (variable indices into
	// member vectors/arrays, recovery C4).
      NetExpr*var_off = 0;
      ivl_type_t member_type;

      pform_name_t completed_path;
      do {
	    const name_component_t member_comp = member_path.front();
	    const perm_string&member_name = member_comp.name;

	    if (debug_elaborate) {
		  cerr << get_fileline() << ": PEIdent::elaborate_lval_net_packed_member_: "
		       << "Processing member_comp=" << member_comp
		       << " (completed_path=" << completed_path << ")"
		       << endl;
	    }

	      // This is a packed member, so the name is of the form
	      // "a.b[...].c[...]" which means that the path_ must have at
	      // least 2 components. We are processing "c[...]" at that
	      // point (otherwise known as member_name) and we have a
	      // reference to it in member_comp.

	      // The member_path is the members we want to follow for the
	      // variable. For example, main[N].a.b may have main[N] as the
	      // base_name, and member_path=a.b. The member_name is the
	      // start of the member_path, and is "a". The member_name
	      // should be a member of the struct_type type.

	      // Calculate the offset within the packed structure of the
	      // member, and any indices. We will add in the offset of the
	      // struct into the packed array later. Note that this works
	      // for packed unions as well (although the offset will be 0
	      // for union members).
	    unsigned long tmp_off;
	    const netstruct_t::member_t* member = struct_type->packed_member(member_name, tmp_off);

	    if (member == 0) {
		  cerr << get_fileline() << ": error: Member " << member_name
		       << " is not a member of struct type of "
		       << reg->name()
		       << "." << completed_path << endl;
		  des->errors += 1;
		  return false;
	    }
	    if (debug_elaborate) {
		  cerr << get_fileline() << ": PEIdent::elaborate_lval_net_packed_member_: "
		       << "Member type: " << *(member->net_type)
		       << endl;
	    }

	    off += tmp_off;
	    ivl_assert(*this, use_width >= (unsigned long)member->net_type->packed_width());
	    use_width = member->net_type->packed_width();

	      // At this point, off and use_width are the part select
	      // expressed by the member_comp, which is a member of the
	      // struct. We can further refine the part select with any
	      // indices that might be present.

	      // Get the index component type. The canonical member-index
	      // collapse also lowers the indexed part-select forms
	      // ([b +: w] / [b -: w], run-time base allowed), so only
	      // genuinely unknown select kinds are refused -- inside
	      // collapse_packed_member_indices, loudly.

	    member_type = member->net_type;

	    if (const netvector_t*mem_vec = dynamic_cast<const netvector_t*>(member->net_type)) {
		    // If the member type is a netvector_t, then it is a
		    // vector of atom or scaler objects. For example, if the
		    // l-value expression is "foo.member[1][2]",
		    // then the member should be something like:
		    //    ... logic [h:l][m:n] member;
		    // There should be index expressions index the vector
		    // down, but there doesn't need to be all of them. We
		    // can, for example, be selecting a part of the vector.

		    // We only need to process this if there are any
		    // index expressions. If not, then the packed
		    // vector can be handled atomically.

		    // In any case, this should be the tail of the
		    // member_path, because the array element of this
		    // kind of array cannot be a struct.
		  if (!member_comp.index.empty()) {
			  // These are the dimensions defined by the type
			const netranges_t&mem_packed_dims = mem_vec->packed_dims();

			  // One canonical member-select calculation (recovery C4):
			  // constant and run-time indices alike, incl. a trailing
			  // part-select. Constants fold into `off'; run-time
			  // contributions accumulate in var_off.
			NetExpr*moff = 0;
			unsigned long mwid = 0;
			if (!collapse_packed_member_indices(des, scope, this,
							    mem_packed_dims,
							    member_comp.index,
							    moff, mwid))
				return false;

			long cfold = 0;
			if (eval_as_long(cfold, moff)) {
				off += cfold;
				delete moff;
			} else {
				var_off = var_off
				      ? make_packed_offset_sum(this, var_off, moff)
				      : moff;
			}
			use_width = mwid;
			member_type = nullptr;
		  }

		    // The netvector_t only has atom elements, to
		    // there is no next struct type.
		  struct_type = 0;

	    } else if (const netparray_t*array = dynamic_cast<const netparray_t*> (member->net_type)) {
		    // If the member is a parray, then the elements
		    // are themselves packed object, including
		    // possibly a struct. Handle this by taking the
		    // part select of the current part of the
		    // variable, then stepping to the element type to
		    // possibly iterate through more of the member_path.

		  ivl_assert(*this, array->packed());

		  if (member_comp.index.empty()) {
			struct_type = 0;
			continue;
		  }

		    // These are the dimensions defined by the type
		  const netranges_t&mem_packed_dims = array->static_dimensions();

		    // Canonical element addressing in ELEMENT units, scaled
		    // to bits below (recovery C4).
		  NetExpr*moff = 0;
		  unsigned long mwid = 0;
		  if (!collapse_packed_member_indices(des, scope, this,
						      mem_packed_dims,
						      member_comp.index,
						      moff, mwid))
			return false;

		  ivl_type_t element_type = array->element_type();
		  long element_width = element_type->packed_width();

		  long cfold = 0;
		  if (eval_as_long(cfold, moff)) {
			off += cfold * element_width;
			delete moff;
		  } else {
			if (element_width > 1)
			      moff = scale_index_to_bits(moff,
						 (unsigned long)element_width, *this);
			var_off = var_off
			      ? make_packed_offset_sum(this, var_off, moff)
			      : moff;
		  }
		  use_width = mwid * element_width;
		    /* An indexed parray selects a SLICE; the final set_part
		       must size from use_width, not from the whole parray
		       type. (Reassigned next iteration when the walk continues
		       into a struct element.) */
		  member_type = nullptr;

		    // To move on to the next component in the member
		    // path, get the element type. For example, for
		    // the path a.b[1].c, we are processing b[1] here,
		    // and the element type should be a netstruct_t
		    // that will wind up containing the member c.
		  struct_type = dynamic_cast<const netstruct_t*> (element_type);

	    } else if (const netstruct_t*tmp_struct = dynamic_cast<const netstruct_t*> (member->net_type)) {
		    // If the member is itself a struct, then get
		    // ready to go on to the next iteration.
		  struct_type = tmp_struct;

	    } else if (const netenum_t*tmp_enum = dynamic_cast<const netenum_t*> (member->net_type)) {
		    // If the element is an enum, then we don't have
		    // anything special to do.
		  if (debug_elaborate) {
			cerr << get_fileline() << ": PEIdent::elaborate_lval_net_packed_member_: "
			     << "Tail element is an enum: " << *tmp_enum
			     << endl;
		  }
		  struct_type = 0;

	    } else {
		    // Unknown type?
		  cerr << get_fileline() << ": internal error: "
		       << "Unexpected member type? " << *(member->net_type)
		       << endl;
		  des->errors += 1;
		  return false;
	    }

	      // Complete this component of the path, mark it
	      // completed, and set up for the next component.
	    completed_path .push_back(member_comp);
	    member_path.pop_front();

      } while (!member_path.empty() && struct_type != 0);

      if (debug_elaborate) {
	    cerr << get_fileline() << ": PEIdent::elaborate_lval_net_packed_member_: "
		 << "After processing member_path, "
		 << "off=" << off
		 << ", use_width=" << use_width
		 << ", completed_path=" << completed_path
		 << ", member_path=" << member_path
		 << endl;
      }

	// The dimensions in the expression must match the packed
	// dimensions that are declared for the variable. For example,
	// if foo is a packed array of struct, then this expression
	// must be "b[n][m]" with the right number of dimensions to
	// match the declaration of "b".
	// Note that one of the packed dimensions is the packed struct
	// itself.
      if (!ua_of_packed)
	    ivl_assert(*this, name_base.index.size()+1 == reg->packed_dimensions());

	// Generate an expression that takes the input array of
	// expressions and generates a canonical offset into the
	// packed array.
      NetExpr*packed_base = 0;
      if (!ua_of_packed && reg->packed_dimensions() > 1) {
	    list<index_component_t>tmp_index = name_base.index;
	    index_component_t member_select;
	    member_select.sel = index_component_t::SEL_BIT;
	    member_select.msb = new PENumber(new verinum(off));
	    tmp_index.push_back(member_select);
	      /* collapse_array_exprs is the run-time-capable collapse
	         (the rvalue twin already uses it); the constant-only
	         collapse_array_indices asserted on a variable word
	         index (recovery C4 / G16 l-value). */
	    packed_base = collapse_array_exprs(des, scope, this, reg, tmp_index);
	    if (!packed_base)
		  return false;
      }

      long tmp;
      if (packed_base && eval_as_long(tmp, packed_base)) {
	    off = tmp;
	    delete packed_base;
	    packed_base = 0;
      }

      if ((reg->type()==NetNet::UNRESOLVED_WIRE) && !is_force) {
	    ivl_assert(*this, reg->coerced_to_uwire());
	      /* IEEE 1800-2017 6.5 forbids mixing continuous and
	         procedural assignment to the same VARIABLE, and 7.2.1
	         stores a packed structure without gaps so a member IS a
	         part select of the containing vector. The conflict must
	         therefore be judged over the BITS actually written --
	         which `off'/`use_width' above already hold.
	         This tested the whole NetNet instead, so two spellings of
	         the SAME bits disagreed:
	           assign s.a;   always_comb s[1:0] = x;   // accepted
	           assign s[3:2]; always_comb s.b   = x;   // rejected
	         Disjoint members of one struct -- the ordinary way to
	         drive a control register from several sources -- were
	         rejected outright. Every other l-value path here (array
	         word, packed slice, bit select, part select) already
	         consults test_part_driven; this was the one that did not.
	         A run-time offset makes the written bits unknowable at
	         elaboration, so that case stays conservative and reports,
	         rather than silently permitting a real overlap. */
	    if (packed_base) {
		  report_mixed_assignment_conflict_("variable");
		  des->errors += 1;
		  return false;
	    }
	    if (reg->test_part_driven(off + use_width - 1, off)) {
		  report_mixed_assignment_conflict_("variable");
		  des->errors += 1;
		  return false;
	    }
      }

      {
	      /* The select base may now carry run-time components: a
	         variable word index collapsed into packed_base, and/or
	         variable member indices accumulated in var_off
	         (recovery C4). The part-select store is a run-time RMW
	         either way. */
	    NetExpr *base = packed_base
		  ? packed_base
		  : new NetEConst(verinum(off));
	    if (var_off)
		  base = make_packed_offset_sum(this, base, var_off);
	    if (member_type)
		  lv->set_part(base, member_type);
	    else
		  lv->set_part(base, use_width);
	    return true;
      }
}

NetAssign_* PENumber::elaborate_lval(Design*des, NetScope*, bool, bool, bool,
				    bool) const
{
      cerr << get_fileline() << ": error: Constant values not allowed "
	   << "in l-value expressions." << endl;
      des->errors += 1;
      return 0;
}
