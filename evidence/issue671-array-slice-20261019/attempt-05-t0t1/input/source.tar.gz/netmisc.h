#ifndef IVL_netmisc_H
#define IVL_netmisc_H
/*
 * Copyright (c) 1999-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "netlist.h"

class netsarray_t;
class netuarray_t;
class netdarray_t;
class Statement;
class PExpr;
class netclass_t;
struct index_component_t;

/* Validate an indexed dynamic-array slice and return its ascending low
 * element address. The caller owns the expression. */
extern NetExpr* elaborate_direct_darray_indexed_base_(
      Design*, NetScope*, const LineInfo&, const index_component_t&,
      unsigned&count);

/* Parse the leading digits accepted by the SystemVerilog string-to-integer
 * methods and return their signed 32-bit result without signed host overflow. */
extern int64_t string_method_parse_integer(const std::string&text,
					   unsigned base);

// A referenced integral function-name variable needs addressable storage.
inline void materialize_ref_return(NetNet*sig)
{
      if (sig && sig->scope()->type() == NetScope::FUNC
          && sig->name() == sig->scope()->basename()
          && sig->unpacked_dimensions() == 0
          && (sig->data_type() == IVL_VT_BOOL || sig->data_type() == IVL_VT_LOGIC))
            sig->attribute(perm_string::literal("_ivl_materialize_return"), verinum("1"));
}

/*
 * Search for a hierarchical name. The input path is one or more name
 * components (name_component_t) which describe a path to the object. The
 * simplest case is the path is a single name_component_t. This is the most
 * usual case. More complex cases might include a string of name components
 * that end in an item or scope, like this:
 *
 *   a.b[1].c
 *
 * In this case, the "path input would include a.b.c, with index expressions
 * on name_component_t for "b". In this case, usually "c" is the found item
 * and "a" and "b" are scopes that lead up to the item.
 *
 * The search will stop when it finds a component in the path that is an
 * object of some sort (other then a scope. So for example, if a.b is an
 * array, then the search for a.b[1].c will stop at a.b, leave a.b[1] in
 * path_head, and "c" in path_tail. It is up to the caller to then note that
 * "c" must be a method of some sort.
 */
struct symbol_search_results {
      inline symbol_search_results() {
	    scope = 0;
	    net = 0;
	    par_val = 0;
	    type = 0;
	    eve = 0;
	    decl_after_use = 0;
	    scope_index_error = false;
      }

      inline bool is_scope() const {
	    if (net) return false;
	    if (eve) return false;
	    if (par_val) return false;
	    if (scope) return true;
	    return false;
      }

      inline bool is_found() const {
	    if (net) return true;
	    if (eve) return true;
	    if (par_val) return true;
	    if (scope) return true;
	    return false;
      }

      inline const char *result_type() const {
	    if (net)     return "net";
	    if (eve)     return "named event";
	    if (par_val) return "parameter";
	    if (scope)   return "scope";
	    return "nothing found";
      }

	// Scope where symbol was located. This is set in all cases,
	// assuming the search succeeded.
      NetScope*scope;
	// If this was a net, the signal itself.
      NetNet*net;
	// If this was a parameter, the value expression and the
	// optional value dimensions.
      const NetExpr*par_val;
      ivl_type_t type;
	// If this is a named event, ...
      NetEvent*eve;
	// If a symbol was located but skipped because its lexical position
	// is after the lexical position of the name being searched, it is
	// stored here. If more than one such symbol is found, the first
	// one is retained.
      const LineInfo*decl_after_use;

        // A scope component existed, but one of its instance-array indices
        // was not a constant expression. Callers must not replace that
        // specific diagnostic with a generic unresolved-name warning.
      bool scope_index_error;

        // Store bread crumbs of the search here. The path_tail is the parts
        // of the original path that were not found, or are after an object
        // (and so are probably members or methods).
      pform_name_t path_tail;
        // The path_head is the parts of the original path that were found.
        // The last item in path_head is the final name (possibly before the
        // path_tail items) that identifies the object. This name may contain
        // index expressions. If the search result is a scope, then this name
        // is also the name of the scope identified.
      pform_name_t path_head;
};

/*
 * Test the search results and return true if this represents a function
 * return value. That will be the case if the object is a net, the scope
 * containing the object is a FUNCtion, and the containing scope and the
 * object have the same name.
 */
static inline bool test_function_return_value(const symbol_search_results&search_results)
{
      if (!search_results.net) return false;
      if (search_results.scope->type()!=NetScope::FUNC) return false;
      if (search_results.net->name() != search_results.scope->basename()) return false;
      return true;
}

extern bool symbol_search(const LineInfo*li, Design*des, NetScope*scope,
			  pform_name_t path, unsigned lexical_pos,
			  struct symbol_search_results*res,
			  NetScope*start_scope = nullptr, bool prefix_scope = false);

extern bool symbol_search(const LineInfo *li, Design *des, NetScope *scope,
			  const pform_scoped_name_t &path, unsigned lexical_pos,
			  struct symbol_search_results*res);

/*
 * Canonical description of a whole one-dimensional fixed unpacked array or
 * a constant slice of one. Array storage is flattened in increasing numeric
 * index order, while SystemVerilog assignment and comparison pair elements
 * in the slice's declared left-to-right order. Keeping both the canonical
 * low word and the selected range direction lets callers perform the right
 * reversal without inventing an aggregate run-time value.
 *
 * decode_fixed_uarray_slice() returns 1 on success, 0 when expr is not this
 * shape, and -1 for a recognized but invalid/unsupported slice. When quiet
 * is true, -1 is returned without emitting a diagnostic; width inference
 * uses that mode so the later elaboration pass remains the sole reporter.
 */
struct fixed_uarray_slice_t {
      NetNet*signal = nullptr;       // Borrowed from the design.
      long canonical_base = 0;      // Lowest canonical word in the slice.
      unsigned long count = 0;
      netrange_t selected_range;
      ivl_type_t element_type = nullptr; // Borrowed from signal.
      bool whole = false;
};

extern int decode_fixed_uarray_slice(Design*des, NetScope*scope,
				     const LineInfo&loc, const PExpr*expr,
				     bool allow_whole,
				     fixed_uarray_slice_t&out,
				     bool quiet = false);

/* Decode a range written directly on a one-dimensional fixed unpacked-array
 * type. This is the declaration-independent counterpart used for class and
 * aggregate properties, where symbol_search() resolves the receiver rather
 * than a standalone array signal. The return convention matches
 * decode_fixed_uarray_slice(). */
extern int decode_fixed_uarray_slice_select(
				     Design*des, NetScope*scope,
				     const LineInfo&loc,
				     const std::list<index_component_t>&indices,
				     const netsarray_t*array_type,
				     fixed_uarray_slice_t&out,
				     bool quiet = false);

/*
 * symbol_search() caches resolved (scope, name-path) lookups. That
 * cache assumes ordinary declarations, which are stable for the rest
 * of elaboration once found. NetScope::set_signal_alias() breaks that
 * assumption: it transiently overwrites a scope's signals_map_ entry
 * (e.g. binding the name "item" to a fresh per-with-clause iterator
 * net for IEEE 1800-2017 7.12.4 array-manipulation-method predicates,
 * then restoring whatever was there before). Call this whenever an
 * alias is installed or restored so a later, unrelated query for the
 * same name in the same scope cannot be served a stale cached net
 * left over from a previous alias window.
 */
extern void symbol_search_cache_clear();

/*
 * IEEE 1800-2017 clause 14 — clocking-block member path rewrites.
 * The current clocking-block model aliases cb.sig to the underlying
 * signal (sample/drive skew semantics are not implemented yet): these
 * helpers detect a clocking-block component in an identifier path and
 * rewrite it. All return true and fill `rewritten` only when a
 * clocking block and one of its signals were positively identified.
 *
 * The scope-based helpers implement sampled input semantics
 * (IEEE 1800-2017 14.13, M8-2a): READS of input/inout clockvars route
 * to the hidden per-instance sample variable `_ivl_smp$<cb>$<sig>`
 * when it exists; WRITES to input clockvars are reported as errors
 * (14.3) with *input_write set so the caller can count them; all
 * other references keep the alias rewrite (erase the clocking
 * component so the raw signal resolves).
 *
 * - rewrite_class_clocking_member_path: virtual-interface receivers
 *   (the interface is modeled as a netclass_t carrying clocking
 *   blocks). Sampled reads route to the sample-variable PROPERTY the
 *   interface class registered (resolved by name in the bound
 *   instance scope at run time).
 * - rewrite_clocking_member_path_via_scope: the receiver resolved to
 *   an instance scope (interface, module, or program instance) and the
 *   clocking block is found in its pform Module.
 * - rewrite_enclosing_scope_clocking_member_path: same-scope
 *   references — the leading path component names a clocking block of
 *   an enclosing module/interface/program scope.
 */
class PEIdent;
extern bool rewrite_class_clocking_member_path(const PEIdent*ident,
					       const symbol_search_results&sr,
					       pform_name_t&rewritten,
					       bool as_lvalue = false,
					       bool*input_write = nullptr,
					       perm_string*clocking_access = nullptr);
extern bool rewrite_clocking_member_path_via_scope(const PEIdent*ident,
						   const symbol_search_results&sr,
						   pform_name_t&rewritten,
						   bool as_lvalue = false,
						   bool*input_write = nullptr,
						   perm_string*clocking_access = nullptr);
extern bool rewrite_enclosing_scope_clocking_member_path(const PEIdent*ident,
							 const NetScope*scope,
							 pform_name_t&rewritten,
							 bool as_lvalue = false,
							 bool*input_write = nullptr,
							 perm_string*clocking_access = nullptr);

/* Enforce the member surface and write directions of one modport-qualified
   interface handle. Compiler-generated clocking state is admitted only when
   its exact clocking block is exported by the selected modport. */
/* The named modport of an interface type, or null (IEEE 1800-2017 25.5). */
class PModport;
extern const PModport* interface_modport_view(const netclass_t*interface_type,
					      perm_string modport);

extern bool validate_interface_modport_access(Design*des,
					       const LineInfo*loc,
					       const netclass_t*interface_type,
					       perm_string modport,
					       perm_string member,
					       perm_string clocking_access,
					       bool as_lvalue);

/*
 * This function transforms an expression by either zero or sign extending
 * the high bits until the expression has the desired width. This may mean
 * not transforming the expression at all, if it is already wide enough.
 * The extension method and the returned expression type is determined by
 * signed_flag.
 */
extern NetExpr*pad_to_width(NetExpr*expr, unsigned wid, bool signed_flag,
			    const LineInfo&info, ivl_type_t use_type = 0);
/*
 * This version determines the extension method from the base expression type.
 */
inline NetExpr*pad_to_width(NetExpr*expr, unsigned wid, const LineInfo&info, ivl_type_t use_type = 0)
{
      return pad_to_width(expr, wid, expr->has_sign(), info, use_type);
}

/*
 * This function transforms an expression by either zero or sign extending
 * or discarding the high bits until the expression has the desired width.
 * This may mean not transforming the expression at all, if it is already
 * the correct width. The extension method (if needed) and the returned
 * expression type is determined by signed_flag.
 */
extern NetExpr*cast_to_width(NetExpr*expr, unsigned wid, bool signed_flag,
			     const LineInfo&info);

extern NetNet*pad_to_width(Design*des, NetNet*n, unsigned w,
                           const LineInfo&info);

extern NetNet*pad_to_width_signed(Design*des, NetNet*n, unsigned w,
                                  const LineInfo&info);

/*
 * Generate the nodes necessary to cast an expression (a net) to a
 * real value.
 */
extern NetNet*cast_to_int4(Design*des, NetScope*scope, NetNet*src, unsigned wid);
extern NetNet*cast_to_int2(Design*des, NetScope*scope, NetNet*src, unsigned wid);
extern NetNet*cast_to_real(Design*des, NetScope*scope, NetNet*src);

extern NetExpr*cast_to_int4(NetExpr*expr, unsigned width);
extern NetExpr*cast_to_int2(NetExpr*expr, unsigned width);
extern NetExpr*cast_to_real(NetExpr*expr);

/*
 * Take the input expression and return a variation that assures that
 * the expression is 1-bit wide and logical. This reflects the needs
 * of conditions i.e. for "if" statements or logical operators.
 */
extern NetExpr*condition_reduce(NetExpr*expr);

/*
 * This function transforms an expression by cropping the high bits
 * off with a part select. The result has the width w passed in. This
 * function does not pad, use pad_to_width if padding is desired.
 */
extern NetNet*crop_to_width(Design*des, NetNet*n, unsigned w);

extern bool calculate_part(const LineInfo*li, Design*des, NetScope*scope,
			   const index_component_t&index,
			   long&off, unsigned long&wid);

/*
 * These functions generate an equation to normalize an expression using
 * the provided vector/array information.
 */
extern NetExpr*normalize_variable_base(NetExpr *base, long msb, long lsb,
                                       unsigned long wid, bool is_up,
				       long slice_off =0);

/*
 * Calculate a canonicalizing expression for a bit select, when the
 * base expression is the last index of an otherwise complete bit
 * select. For example:
 *   reg [3:0][7:0] foo;
 *   ... foo[1][x] ...
 * base is (x) and the generated expression will be (x+8).
 */
extern NetExpr*normalize_variable_bit_base(const std::list<long>&indices, NetExpr *base,
					   const NetNet*reg);

/*
 * This is similar to normalize_variable_bit_base, but the tail index
 * it a base and width, instead of a bit. This is used for handling
 * indexed part selects:
 *   reg [3:0][7:0] foo;
 *   ... foo[1][x +: 2]
 * base is (x), wid input is (2), and is_up is (true). The output
 * expression is (x+8).
 */
extern NetExpr *normalize_variable_part_base(const std::list<long>&indices, NetExpr*base,
					     const NetNet*reg,
					     unsigned long wid, bool is_up);
/*
 * Calculate a canonicalizing expression for a slice select. The
 * indices array is less than needed to fully address a bit, so the
 * result is a slice of the packed array. The return value is an
 * expression that gets to the base of the slice, and (lwid) becomes
 * the width of the slice, in bits. For example:
 *   reg [4:1][7:0] foo
 *   ...foo[x]...
 * base is (x) and the generated expression will be (x*8 - 8), with
 * lwid set to (8).
 */
extern NetExpr*normalize_variable_slice_base(const std::list<long>&indices, NetExpr *base,
					     const NetNet*reg, unsigned long&lwid);

/*
 * The as_indices() manipulator is a convenient way to emit a list of
 * index values in the form [<>][<>]....
 */
template <class TYPE> struct __IndicesManip {
      explicit inline __IndicesManip(const std::list<TYPE>&v) : val(v) { }
      const std::list<TYPE>&val;
};
template <class TYPE> inline __IndicesManip<TYPE> as_indices(const std::list<TYPE>&indices)
{ return __IndicesManip<TYPE>(indices); }

extern std::ostream& operator << (std::ostream&o, __IndicesManip<long>);
extern std::ostream& operator << (std::ostream&o, __IndicesManip<NetExpr*>);

/*
 * Given a list of index expressions, generate elaborated expressions
 * and constant values, if possible.
 */
struct indices_flags {
      bool invalid;    // at least one index failed elaboration
      bool variable;   // at least one index is a dynamic value
      bool undefined;  // at least one index is an undefined value
};
extern void indices_to_expressions(Design*des, NetScope*scope,
				     // loc is for error messages.
				   const LineInfo*loc,
				     // src is the index list, and count is
				     // the number of items in the list to use.
				   const std::list<index_component_t>&src, unsigned count,
				     // True if the expression MUST be constant.
				   bool need_const,
				     // These are the outputs.
				   indices_flags&flags,
				   std::list<NetExpr*>&indices,std::list<long>&indices_const);

extern NetExpr*normalize_variable_unpacked(const NetNet*net, const std::list<long>&indices);
extern NetExpr*normalize_variable_unpacked(const netsarray_t*net, const std::list<long>&indices);

extern NetExpr*normalize_variable_unpacked(const NetNet*net, const std::list<NetExpr*>&indices);
extern NetExpr*normalize_variable_unpacked(const LineInfo&loc, const netsarray_t*net, const std::list<NetExpr*>&indices);

extern NetExpr*make_canonical_index(Design*des, NetScope*scope,
				      // loc for error messages
				    const LineInfo*loc,
				      // src is the index list
				    const std::list<index_component_t>&src,
				      // This is the reference type
				    const netsarray_t*stype,
				      // True if the expression MUST be constant.
				    bool need_const);

/* Canonicalize the fixed unpacked prefix of a class property while checking
 * every declared dimension independently. Dynamic indices are kept together
 * in one synthetic expression so each source expression is evaluated exactly
 * once. An undefined or out-of-range dimension produces an X canonical slot. */
extern NetExpr*make_checked_canonical_property_index(
				    Design*des, NetScope*scope,
				    const LineInfo*loc,
				    const std::list<index_component_t>&src,
				    const netsarray_t*stype,
      bool need_const);
/* Consumes already-elaborated indices, preserving their full constant width. */
extern NetExpr*make_checked_canonical_property_index(
      Design*des, const LineInfo*loc, std::list<NetExpr*>&indices_expr,
      const indices_flags&flags, const netsarray_t*stype);
extern NetExpr*make_checked_canonical_packed_prefix(
      Design*des, NetScope*scope, const LineInfo*loc,
      const std::list<index_component_t>&src, const netranges_t&dims,
      unsigned long carrier_width, bool warn_undefined = true,
      bool property_index = false);
/* A trailing range after a packed-property element index must stay within
 * its own declared dimension; flattening a crossing range aliases a neighbor.
 * Until partial crossing ranges are lowered element by element, diagnose them
 * and run-time indexed bases instead of generating an aliased offset. A
 * caller that passes RUNTIME_CHECKED lowers an unproven run-time base itself
 * (select the element, then part-select it) and gets true plus the flag. */
extern bool check_packed_property_tail_range(
      Design*des, NetScope*scope, const LineInfo*loc,
      const index_component_t&select, const netrange_t&dim,
      bool*runtime_checked = nullptr);

/*
 * This function takes as input a NetNet signal and adds a constant
 * value to it. If the val is 0, then simply return sig. Otherwise,
 * return a new NetNet value that is the output of an addition.
 *
 * Not currently used.
 */
#if 0
extern NetNet*add_to_net(Design*des, NetNet*sig, long val);
#endif
extern NetNet*sub_net_from(Design*des, NetScope*scope, long val, NetNet*sig);

/*
 * Make a NetEConst object that contains only X bits.
 */
extern NetEConst*make_const_x(unsigned long wid);
extern NetEConst*make_const_0(unsigned long wid);
extern NetEConst*make_const_val(unsigned long val);
extern NetEConst*make_const_val_s(long val);

/*
 * Make a const net.
 */
extern NetNet* make_const_0(Design*des, NetScope*scope, unsigned long wid);
extern NetNet* make_const_x(Design*des, NetScope*scope, unsigned long wid);
extern NetNet* make_const_z(Design*des, NetScope*scope, unsigned long wid);

/*
 * In some cases the lval is accessible as a pointer to the head of
 * a list of NetAssign_ objects. This function returns the width of
 * the l-value represented by this list.
 */
extern unsigned count_lval_width(const class NetAssign_*first);

/*
 * This function elaborates an expression, and tries to evaluate it
 * right away. If the expression can be evaluated, this returns a
 * constant expression. If it cannot be evaluated, it returns whatever
 * it can. If the expression cannot be elaborated, return 0.
 *
 * The context_width is the width of the context where the expression is
 * being elaborated, or -1 if the expression is self-determined, or -2
 * if the expression is lossless self-determined (this last option is
 * treated as standard self-determined if the gn_strict_expr_width flag
 * is set).
 *
 * cast_type allows the expression to be cast to a different type
 * (before it is evaluated). If cast to a vector type, the vector
 * width will be set to the context_width. The default value of
 * IVL_VT_NO_TYPE causes the expression to retain its self-determined
 * type.
 */
class PExpr;

/* Return the complete declared type of an elaborated expression when it has
 * one, or synthesize the self-determined scalar type carried only by the
 * expression width/state/sign fields. This is for IEEE 1800 type-equivalence
 * checks (6.22.2), not assignment-context conversion. The synthesized type is
 * compiler-lifetime storage, like the other elaborated anonymous types. */
extern ivl_type_t netexpr_type_for_equivalence(const NetExpr*expr);
extern ivl_type_t netassign_type_for_equivalence(const NetAssign_*lval);

/* Queue and dynamic-array assignment compatibility is shared by casts and
 * subroutine copy boundaries. The return value reports element equivalence;
 * handled is set only when both types are positional containers (rather than
 * the associative-array representation that also derives from netqueue_t). */
extern bool positional_container_type_match(ivl_type_t target,
					     ivl_type_t source,
					     bool&handled);
extern bool positional_container_expr_type_match(ivl_type_t target,
						  const NetExpr*source,
						  bool&handled);

extern bool commercial_unsafe_positional_container_type_match(
		ivl_type_t target, ivl_type_t source, bool allow_same_kind);

/* netqueue_t is also the internal carrier for associative arrays. Its
 * inherited equivalence check covers the queue category and element type,
 * but not the associative key type or wildcard state. Keep the stricter
 * comparison shared by casts and assignment-like contexts. */
enum assoc_array_type_match_t {
      ASSOC_ARRAY_TYPE_MATCH,
      ASSOC_ARRAY_TYPE_NOT_ASSOC,
      ASSOC_ARRAY_TYPE_ELEMENT_MISMATCH,
      ASSOC_ARRAY_TYPE_INDEX_MISMATCH
};

extern assoc_array_type_match_t assoc_array_type_match(ivl_type_t target,
						ivl_type_t source);
extern bool assoc_array_type_contains(ivl_type_t type);
extern bool assoc_array_expr_contains(const NetExpr*expr);
extern assoc_array_type_match_t assoc_array_expr_type_match(
						ivl_type_t target,
						const NetExpr*source);

/* IEEE 1800-2017 7.12.4 iterator index querying: while an array
 * method's with expression elaborates, register the iterator net and
 * the loop-counter net so `item.index` resolves to the element index.
 * Nesting-safe (a stack).  Defined in elab_expr.cc. */
extern void push_array_method_iter_ctx(const NetNet*iter_net, NetNet*idx_net);
extern void push_array_method_iter_ctx_named(const NetNet*iter_net,
					     NetNet*idx_net,
					     perm_string index_name,
					     bool index_query_allowed = true);
extern void pop_array_method_iter_ctx(void);
extern NetNet* find_array_method_iter_index(const NetNet*iter_net);
extern NetNet* find_array_method_iter_index(const NetNet*iter_net,
					    perm_string index_name);

extern NetExpr* elab_and_eval(Design*des, NetScope*scope,
			      PExpr*pe, int context_width,
                              bool need_const =false,
                              bool annotatable =false,
			      ivl_variable_type_t cast_type =IVL_VT_NO_TYPE,
			      bool force_unsigned =false,
			      unsigned extra_flags =0);

/*
 * This form of elab_and_eval uses the ivl_type_t to carry type
 * information instead of the piecemeal form. We should transition to
 * this form as we reasonably can.
 */
extern NetExpr* elab_and_eval(Design*des, NetScope*scope,
			      PExpr*expr, ivl_type_t lv_net_type,
			      bool need_const,
			      unsigned extra_flags = 0);

/* IEEE 1800-2017 7.9.1: an associative-array index expression is evaluated
 * in the assignment context of the declared index type. The queue carrier is
 * also used for ordinary queues, so non-associative callers retain the usual
 * self-determined index behavior. */
extern NetExpr* elab_assoc_index(Design*des, NetScope*scope,
				 PExpr*expr, ivl_type_t container_type,
				 bool need_const = false);
extern NetExpr* cast_assoc_index(NetExpr*expr, ivl_type_t container_type,
				 const LineInfo&info);

/*
 * This function is a variant of elab_and_eval that elaborates and
 * evaluates the arguments of a system task.
 */
extern NetExpr* elab_sys_task_arg(Design*des, NetScope*scope,
                                  perm_string name, unsigned arg_idx,
                                  PExpr*pe, bool need_const =false);

/* Elaborate a typed-mailbox input without losing the dynamic string category.
 * Generic system-task arguments intentionally lower a string literal through
 * the width-based packed-constant path; mailbox#(string) instead needs a
 * NetECString so both the 15.4.9 equivalence check and VVP value transport see
 * a string value. */
extern NetExpr* elab_typed_mailbox_input(Design*des, NetScope*scope,
                                         perm_string method_name,
                                         PExpr*pe,
                                         const netclass_t*mailbox);
/* IEEE 1800-2017/2023 15.4.9 requires put/try_put arguments of a type
 * equivalent to the mailbox type. Under -gcommercial-unsafe, accept what
 * commercial simulators accept for this input argument: for a class T, null or
 * a handle of T or a class derived from T; for an integral or real T, any
 * integral or real value (elab_typed_mailbox_input converts it to T). */
extern bool typed_mailbox_put_compatible(const netclass_t*mailbox,
                                         const NetExpr*actual);
/*
 * This function elaborates an expression as if it is for the r-value
 * of an assignment, The lv_type and lv_width are the type and width
 * of the l-value, and the expr is the expression to elaborate. The
 * result is the NetExpr elaborated and evaluated. (See elab_expr.cc)
 *
 * I would rather that all calls to elaborate_rval_expr use the
 * lv_net_type argument to express the l-value type, but, for now,
 * that it not possible. Those cases will be indicated by the
 * lv_net_type being set to nil.
 */
extern NetExpr* elaborate_rval_expr(Design*des, NetScope*scope,
				    ivl_type_t lv_net_type,
				    ivl_variable_type_t lv_type,
				    unsigned lv_width, PExpr*expr,
				    bool need_const =false,
				    bool force_unsigned =false,
				    unsigned extra_flags =0);
/*
 * Same as above, but lv_width and lv_type are derived from the lv_net_type.
 */
extern NetExpr* elaborate_rval_expr(Design *des, NetScope *scope,
				    ivl_type_t lv_net_type, PExpr *expr,
				    bool need_const = false,
				    bool force_unsigned = false,
				    unsigned extra_flags = 0);

/*
 * True under -gcommercial-unsafe for a concatenation whose operands are all
 * untyped assignment patterns; such a concatenation needs the target type.
 */
extern bool concat_of_assign_patterns_is_unsafe_typed(const PExpr*expr);

extern bool evaluate_range(Design*des, NetScope*scope, const LineInfo*li,
                           const pform_range_t&range,
                           long&index_l, long&index_r);

extern bool evaluate_ranges(Design*des, NetScope*scope, const LineInfo*li,
			    netranges_t&llist,
			    const std::list<pform_range_t>&rlist);
/*
 * This procedure evaluates an expression and if the evaluation is
 * successful the original expression is replaced with the new one.
 */
void eval_expr(NetExpr*&expr, int context_width =-1);

/*
 * Get the long integer value for the passed in expression, if
 * possible. If it is not possible (the expression is not evaluated
 * down to a constant) then return false and leave value unchanged.
 */
bool eval_as_long(long&value, const NetExpr*expr);
bool eval_as_double(double&value, NetExpr*expr);

/* Return the mathematical sign and absolute value of a defined constant.
 * Magnitudes that do not fit in 64 bits saturate at UINT64_MAX. This avoids
 * host-long truncation and, in particular, never negates INT64_MIN. */
uint64_t verinum_signed_magnitude(const verinum&value, bool&negative);

/* Exact intersection of a constant-base indexed part select with a packed
 * carrier. source_base is the first replacement bit that survives clipping;
 * destination_base is the first carrier bit written. A zero width means the
 * select is wholly outside the carrier. */
struct verinum_part_select_t {
      verinum_part_select_t()
      : destination_base(0), source_base(0), width(0) { }

      uint64_t destination_base;
      uint64_t source_base;
      uint64_t width;
};

verinum_part_select_t verinum_part_select_overlap(
		const verinum&base, uint64_t select_width,
		uint64_t carrier_width);

/*
 * Evaluate an entire scope path in the context of the given scope.
 *
 * `quiet', when true, suppresses the diagnostic and the des->errors
 * increment for a non-constant scope index -- for a caller that is
 * only PROBING whether a path names a scope (its own contract is
 * already "0/empty means try something else", e.g.
 * Design::find_signal()), a failed probe must not be reported as a
 * compile error out from under it. `error_flag' (out) still reports
 * the failure either way so the caller can tell success from failure.
 */
extern std::list<hname_t> eval_scope_path(Design*des, NetScope*scope,
					  const pform_name_t&path,
					  bool quiet = false);
extern hname_t eval_path_component(Design*des, NetScope*scope,
				   const name_component_t&comp,
				   bool&error_flag,
				   bool quiet = false);

/*
 * If this scope is contained within a class scope (i.e. a method of a
 * class) then return the class definition that contains it.
 */
extern const netclass_t*find_class_containing_scope(const LineInfo&loc,const NetScope*scope);
extern NetScope* find_method_containing_scope(const LineInfo&log, NetScope*scope);
extern const netclass_t* find_method_containing_class(
      Design*des, const LineInfo&loc, NetScope*scope);
extern bool scope_method_uses_implicit_this(Design*des, NetScope*scope);
extern NetNet* find_implicit_this_handle(Design*des, NetScope*scope);
extern void netmisc_release_elaboration_caches();

/*
 * Return true if the data type is a type that is normally available
 * in vector for. IVL_VT_BOOL and IVL_VT_LOGIC are vectorable,
 * IVL_VT_REAL is not.
 */
extern bool type_is_vectorable(ivl_variable_type_t type);

/*
 * Return a human readable version of the operator.
 */
const char *human_readable_op(const char op, bool unary = false);

/*
 * Is the expression a constant value and if so what is its logical
 * value.
 *
 * C_NON - the expression is not a constant value.
 * C_0   - the expression is constant and it has a false value.
 * C_1   - the expression is constant and it has a true value.
 * C_X   - the expression is constant and it has an 'bX value.
 */
enum const_bool { C_NON, C_0, C_1, C_X };
const_bool const_logical(const NetExpr*expr);

/*
 * When scaling a real value to a time we need to do some standard
 * processing.
 */
extern uint64_t get_scaled_time_from_real(const Design*des,
                                          NetScope*scope,
                                          const NetECReal*val);

/* When true, NetAssign_::nex_output() reports only the bits a CONSTANT,
   in-range bit/part select actually assigns, instead of claiming the
   whole signal. OFF by default -- synthesis reads that set to decide
   what a process drives and needs the whole-signal answer. Only the
   always_comb sensitivity subtraction in NetBlock::nex_input() turns it
   on, and only around its own walk. */
extern bool nex_output_precise_partsel;

/* When true, a run-time-selected unpacked-array l-value contributes no
   words to the output set used for always_comb sensitivity subtraction.
   A synthesis ownership walk leaves this false because the write may land
   on any word and therefore must claim every possible destination. */
extern bool nex_output_precise_array_word;

/* During synchronous synthesis, intercept eligible unpacked-array writes so
   the process output/enable machinery can use one synthetic token instead of
   materializing every possible word. Returns true when the active compact
   write pass handled this l-value (including its counting-only prepass). */
extern bool synth_array_write_nex_output(NetAssign_*lval, NexusSet&out);

/* Mark the lexical extent of a procedural for-loop while the synchronous
   synthesis output prepass walks it. A run-time array-word assignment in
   that extent is replicated by loop unrolling, so it cannot use the
   single-write-port compact representation. */
extern void synth_array_write_loop_enter();
extern void synth_array_write_loop_leave();

/* Collapse the leading indices of a packed select into constants. With
   quiet=true a non-constant prefix simply returns false with no
   diagnostic, so the caller can fall back to collapse_packed_base(). */
extern bool evaluate_index_prefix(Design*des, NetScope*scope,
				  std::list<long>&prefix_indices,
				  const std::list<index_component_t>&indices,
				  bool quiet = false);

/* Scale an ELEMENT index into a bit offset for an element `wid' bits
   wide (a no-op when wid <= 1). */
extern NetExpr*scale_index_to_bits(NetExpr*idx, unsigned long wid,
				   const LineInfo&loc);

/* The declared type left after `count' of a signal's FLATTENED packed
   dimensions (NetNet::packed_dims()) have been indexed away. Returns
   nil when the count lands mid-way through one array level, i.e. when
   the selection is a sub-slice rather than a whole element. Lets an
   element select keep a declared element type -- an enum, notably --
   that the flat dimension list alone cannot express. */
extern ivl_type_t packed_type_after_dims(ivl_type_t base, size_t count);

/* General packed-array addressing: a run-time index in ANY dimension.
   Returns the canonical bit offset of the addressed slice and sets
   sel_wid to that slice's width. Returns 0 if the index list is longer
   than the signal's packed dimensionality. */
extern NetExpr*collapse_packed_base(Design*des, NetScope*scope,
				    const LineInfo*loc, const NetNet*net,
				    const std::list<index_component_t>&indices,
				    unsigned long&sel_wid);

extern NetExpr*collapse_array_indices(Design*des, NetScope*scope, const NetNet*net,
				      const std::list<index_component_t>&indices);

extern NetExpr*collapse_array_exprs(Design*des, NetScope*scope,
				    const LineInfo*loc, const NetNet*net,
				    const std::list<index_component_t>&indices);

/* The dimension-list core of collapse_array_exprs: build the canonical
   bit offset for a chain of SEL_BIT indices against an explicit packed
   dimension list (indices must already be padded to pdims.size()
   components). Every index is normalized against its dimension --
   unlike collapse_array_exprs there is no raw single-dimension
   shortcut, so the result is canonical for any declared range. */
extern NetExpr*collapse_dims_exprs(Design*des, NetScope*scope,
				   const LineInfo*loc,
				   const netranges_t&pdims,
				   const std::list<index_component_t>&indices);

/* Sum of two canonical offset expressions (width-harmonized add).
   Companion to the member-index collapse below. */
extern NetExpr*make_packed_offset_sum(const LineInfo*loc,
				      NetExpr*a, NetExpr*b);

/* Canonical select into a PACKED MEMBER with dimensions pdims (a
   struct member vector or packed array): any mix of constant and
   run-time SEL_BIT element indices, plus an optional trailing
   part-select ([m:l] constant, or [b +: w]/[b -: w] with constant
   width and possibly run-time base). On success off_expr holds the
   member-relative canonical bit offset (fold it with eval_as_long for
   the all-constant case) and sel_wid the selected width in units of
   the innermost dimension. Diagnoses and returns false on an illegal
   or unsupported index shape; with quiet=true it returns false with no
   diagnostic and no error count, so a caller that has another path to
   try (collapse_packed_base) can fall back and let THAT path issue the
   diagnostic rather than emitting two for one mistake. */
extern bool collapse_packed_member_indices(Design*des, NetScope*scope,
					   const LineInfo*loc,
					   const netranges_t&pdims,
					   const std::list<index_component_t>&indices,
					   NetExpr*&off_expr,
					   unsigned long&sel_wid,
					   bool quiet = false);

/* Packed class-property l-value offset: check each leading bit dimension
 * independently and confine a trailing range to its own dimension. */
extern bool collapse_checked_packed_property_indices(
      Design*des, NetScope*scope, const LineInfo*loc,
      const netranges_t&pdims,
      const std::list<index_component_t>&indices,
      unsigned long packed_width, NetExpr*&off_expr,
      unsigned long&sel_wid);

extern void assign_unpacked_with_bufz(Design*des, NetScope*scope,
				      const LineInfo*loc,
				      NetNet*lval, NetNet*rval);

extern NetPartSelect* detect_partselect_lval(Link&pin);

/*
 * True when a `ref' subroutine formal (IEEE 1800-2017 13.5.2) is
 * represented as a real reference -- a name bound to the caller's
 * variable -- rather than as the copy-in/copy-out pair it used to be.
 *
 * The answer depends only on the FORMAL, never on a particular
 * actual: the formal's storage kind is fixed by its declaration, and
 * every call site has to agree with it. A call whose actual cannot be
 * named directly binds to a temporary instead (see
 * PCallTask::elaborate_ref_bind_), which reproduces the copy pair for
 * that one argument without changing what the formal is.
 */
extern bool ref_formal_is_bound(const NetNet*port);

/* A `ref static` actual must refer to static-lifetime storage, except when
 * the actual is another `ref static` formal. */
extern bool ref_static_actual_is_static_lifetime(const NetAssign_*actual,
						 bool emit_diagnostic = true);

/* Enforce IEEE 1800-2017/2023 9.3.2 for a subroutine's ref formals. */
extern bool check_ref_formal_detached_fork_use(
		Design*des, const NetNet*port, const Statement*body);

/*
 * R25 (IEEE 1800-2017 13.5.2, Option B diagnostic): a `ref' formal that
 * ref_formal_is_bound() answers false for still takes the legacy
 * copy-in/copy-out pair. For a real/string/container (dynamic array,
 * queue, associative array, fixed array) formal that copy-out runs when
 * the TASK ITSELF returns; if the task body contains a detached fork
 * (join_none/join_any) ANYWHERE, a branch that outlives the call and
 * later writes the formal writes into dead frame storage that the
 * copy-out already flushed -- the caller's actual never sees it, with
 * no diagnostic before this change (see ref_formal_is_bound() above and
 * ROADMAP.md row R25).
 *
 * This does not attempt to prove that a particular branch writes this
 * particular formal after the call returns -- that needs alias/dataflow
 * analysis this pass does not have. It warns structurally, once per
 * (task, formal), whenever the shape is POSSIBLE: a copy-bound
 * real/string/container ref formal on a task whose body contains a
 * detached fork anywhere. A fork that provably completes before the
 * task returns is a false positive, but a false positive here is a
 * warning, not a rejection.
 *
 * `port' is a formal of `task_body's own task (not a nested task/function
 * -- the walk this relies on, Statement::contains_detached_fork(), does
 * not descend into nested subroutine bodies, since those are separate
 * frames with their own call-return hazard, if any).
 */
extern void warn_ref_formal_fork_hazard(const NetNet*port, const Statement*task_body);

/*
 * Conservative "does this pform path mention `name'?" test, shared by the
 * PExpr and Statement refs_name() walks that back the IEEE 1800-2017 9.3.2
 * check. Index expressions are searched too.
 */
extern bool pform_name_refs_name(const pform_name_t&path, perm_string name);

/*
 * True when a dynamic array or queue holds elements that a fixed-size
 * unpacked array can receive at their single permitted array-kind boundary
 * (IEEE 1800-2017/2023 7.6). For a multidimensional fixed array, every
 * faster-varying dimension is part of the element type and must remain
 * equivalent. The outer ELEMENT COUNT is deliberately not part of this test
 * -- a dynamic source does not have one until run time, so the count is
 * checked by %store/arr/dar when the copy happens.
 */
extern bool uarray_element_matches_container_(const netuarray_t*dst,
					      const netdarray_t*src);

/* Strict counterpart for native task/function formal binding. Unlike
 * ordinary assignment, this does not apply the documented packed bit/logic
 * cross-state interoperability conversion. */
extern bool uarray_element_equivalent_container_(const netuarray_t*actual,
						 const netdarray_t*formal);

/* DPI open-array formals are a distinct boundary: every unsized unpacked
 * dimension adopts the corresponding actual range (IEEE 1800-2017/2023
 * 35.5.6.1). Match a fixed actual against that complete formal shape without
 * applying the native-subroutine one-kind-boundary rule above. */
extern bool uarray_matches_dpi_open_array_(const netuarray_t*actual,
					   const netdarray_t*formal);

/* Populate enum types and their literal names in a declaration-only scope.
 * This is the same scope pass used by ordinary modules/packages, exposed
 * narrowly for rootless interface signature elaboration. */
extern void elaborate_scope_declaration_enumerations(
		Design*des, NetScope*scope,
		const std::vector<enum_type_t*>&enum_types);

/* Materialize one declaration-only interface method scope for signature
 * elaboration when no concrete interface instance exists. The retained
 * interface scope is rootless and is therefore neither a hierarchy root nor
 * a runtime virtual-interface dispatch candidate. The caller remains
 * responsible for invoking PFunction/PTask::elaborate_sig when required. */
extern NetScope* ensure_interface_declaration_method_scope(
		Design*des, NetScope*caller_scope,
		const netclass_t*interface_type, perm_string method_name);

/*
 * A class body may contain a call through a type-parameter receiver before
 * that parameter has a concrete specialization. Keep the parse-form type
 * identity and the specialization provenance together: name-only matching is
 * not sufficient because an unrelated package typedef can have the same
 * spelling as the class parameter.
 *
 * find_class_type_parameter_reference() recognizes only the exact parameter
 * typedef (or an unqualified alias chain that reaches it). A qualified or
 * parameterized typedef is a concrete external type and is an alias boundary.
 * class_type_parameter_is_deferred() follows both dependent defaults and
 * explicit forwarding overrides recursively. It is true for a generic master,
 * and for a specialization that still forwards from an unresolved enclosing
 * parameter; it is false for a concrete specialization, including one whose
 * value happens to equal the parameter's declared default. A forwarding cycle
 * fails closed (not deferred), leaving ordinary type elaboration to diagnose
 * the invalid declaration.
 */
extern bool find_class_type_parameter_reference(const NetScope*class_scope,
						  const data_type_t*type,
						  perm_string&name);
extern bool find_class_type_parameter_reference(Design*des,
						  const NetScope*class_scope,
						  const PExpr*expr,
						  perm_string&name);
extern bool class_type_parameter_is_deferred(Design*des,
					      const NetScope*class_scope,
					      perm_string name);

/*
 * A bare use of a parameterized class denotes its concrete default
 * specialization.  Keep generic class masters generic while their template
 * bodies are seeded, but when a real receiver is used, resolve a bare
 * parse-form declaration to the #() specialization before method lookup.
 * Explicit/forwarded parameterizations and type-parameter declarations are
 * deliberately left alone.
 */
extern ivl_type_t specialize_bare_class_receiver_on_use(
		Design*des, NetScope*call_scope,
		const data_type_t*declared_type, ivl_type_t current_type);

/* Resolve a bare parameterized class declaration to its concrete default
 * specialization at a real use site.  Callers that are only seeding a
 * circular placeholder must not use this helper. */
extern ivl_type_t specialize_bare_class_at_concrete_use(
		Design*des, NetScope*use_scope,
		const data_type_t*declared_type, ivl_type_t current_type,
		bool fully_elaborate);

/*
 * Print a warning if we find a mixture of default and explicit timescale
 * based delays in the design, since this is likely an error.
 */
extern void check_for_inconsistent_delays(const NetScope*scope);

#endif /* IVL_netmisc_H */
