#ifndef IVL_pform_H
#define IVL_pform_H
/*
 * Copyright (c) 1998-2026 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "netlist.h"
# include  "HName.h"
# include  "named.h"
# include  "Module.h"
# include  "Statement.h"
# include  "AStatement.h"
# include  "PGate.h"
# include  "PExpr.h"
# include  "PTask.h"
# include  "PUdp.h"
# include  "PWire.h"
# include  "PTimingCheck.h"
# include  "verinum.h"
# include  "discipline.h"
# include  <iostream>
# include  <string>
# include  <list>
# include  <map>
# include  <memory>
# include  <cstdio>

/*
 * These classes implement the parsed form (P-form for short) of the
 * original Verilog source. the parser generates the pform for the
 * convenience of later processing steps.
 */


/*
 * Wire objects represent the named wires (of various flavor) declared
 * in the source.
 *
 * Gate objects are the functional modules that are connected together
 * by wires.
 *
 * Wires and gates, connected by joints, represent a netlist. The
 * netlist is therefore a representation of the desired circuit.
 */
class PGate;
class PExpr;
class PPackage;
class PSpecPath;
class PClass;
class PPackage;
struct vlltype;
struct lgate;

/*
 * The min:typ:max expression s selected at parse time using the
 * enumeration. When the compiler makes a choice, it also prints a
 * warning if min_typ_max_warn > 0.
 */
extern enum MIN_TYP_MAX { MIN, TYP, MAX } min_typ_max_flag;
extern unsigned min_typ_max_warn;
PExpr* pform_select_mtm_expr(PExpr*min, PExpr*typ, PExpr*max);

/*
 * This flag is true if the lexor thinks we are in a library source
 * file.
 */
extern bool pform_library_flag;

/*
 * These type are lexical types -- that is, types that are used as
 * lexical values to decorate the parse tree during parsing. They are
 * not in any way preserved once parsing is done.
 */

/* This is information about port name information for named port
   connections. */


struct parmvalue_t {
      std::list<PExpr*>*by_order;
      std::list<named_pexpr_t>*by_name;
};

extern void delete_parmvalue(struct parmvalue_t*parms);

struct str_pair_t { ivl_drive_t str0, str1; };

  /* Use this function to transform the parted form of the attribute
     list to the attribute map that is used later. */
extern void pform_bind_attributes(std::map<perm_string,PExpr*>&attributes,
				  std::list<named_pexpr_t>*attr,
				  bool keep_attr =false);

  /* The lexor calls this function to change the default nettype. */
extern void pform_set_default_nettype(NetNet::Type net,
				     const char*file,
				     unsigned lineno);

  /* Return true if currently processing a program block. This can be
     used to reject statements that cannot exist in program blocks. */
extern bool pform_in_program_block(void);

  /* Return true if currently processing an interface. This can be
     used to reject statements that cannot exist in interfaces. */
extern bool pform_in_interface(void);

/*
 * Look for the given wire in the current lexical scope. If the wire
 * (including variables of any type) cannot be found in the current
 * scope, then return 0.
 */
extern PWire* pform_get_wire_in_scope(perm_string name);

/* Is NAME a value visible from the current lexical scope, through any
 * enclosing scope or import? Used to tell a foreach selector prefix from a
 * new loop variable. */
extern bool pform_name_visible_in_enclosing_scope(const struct vlltype&loc,
						  perm_string name);

extern PWire* pform_get_make_wire_in_scope(const struct vlltype&li,
                                           perm_string name,
                                           NetNet::Type net_type,
                                           ivl_variable_type_t vt_type);

/*
 * The parser uses startmodule and endmodule together to build up a
 * module as it parses it. The startmodule tells the pform code that a
 * module has been noticed in the source file and the following events
 * are to apply to the scope of that module. The endmodule causes the
 * pform to close up and finish the named module.
 *
 * The program_block flag indicates that the module is actually a program
 * block. The is_interface flag indicates that the module is actually
 * an interface. These flags have implications during parse and during
 * elaboration/code generation.
 */
extern void pform_startmodule(const struct vlltype&loc, const char*name,
			      bool program_block, bool is_interface,
			      bool is_checker,
			      LexicalScope::lifetime_t lifetime,
			      std::list<named_pexpr_t>*attr);
extern void pform_module_set_ports(std::vector<Module::port_t*>*);
extern void pform_set_scope_timescale(const struct vlltype&loc);

/* These functions are used when we have a complete port definition, either
   in an ansi style or non-ansi style declaration. In this case, we have
   everything needed to define the port, all in one place. */
extern void pform_module_define_port(const struct vlltype&li,
				     const pform_ident_t&name,
				     NetNet::PortType,
				     NetNet::Type type,
				     data_type_t*vtype,
				     std::list<pform_range_t>*urange,
				     std::list<named_pexpr_t>*attr,
				     bool keep_attr =false);
extern void pform_module_define_port(const struct vlltype&li,
				     std::list<pform_port_t>*ports,
				     NetNet::PortType,
				     NetNet::Type type,
				     data_type_t*vtype,
				     std::list<named_pexpr_t>*attr);
extern void pform_module_define_nettype_port(
                                     const struct vlltype&li,
                                     const pform_ident_t&name,
                                     NetNet::PortType port_kind,
                                     nettype_t*nettype,
                                     std::list<pform_range_t>*urange,
                                     std::list<named_pexpr_t>*attr,
                                     bool keep_attr = false);
extern void pform_module_define_nettype_port(
                                     const struct vlltype&li,
                                     std::list<pform_port_t>*ports,
                                     NetNet::PortType port_kind,
                                     nettype_t*nettype,
                                     std::list<named_pexpr_t>*attr);
extern data_type_t* pform_module_define_interconnect_port(
                                     const struct vlltype&li,
                                     const pform_ident_t&name,
                                     NetNet::PortType port_kind,
                                     data_type_t*implicit_type,
                                     std::list<pform_range_t>*urange,
                                     std::list<named_pexpr_t>*attr,
                                     bool keep_attr = false);
extern void pform_module_define_interconnect_port(
                                     const struct vlltype&li,
                                     std::list<pform_port_t>*ports,
                                     NetNet::PortType port_kind,
                                     data_type_t*implicit_type,
                                     std::list<named_pexpr_t>*attr);

extern Module::port_t* pform_module_port_reference(const struct vlltype&loc,
						   perm_string name);
extern void pform_endmodule(const char*, bool inside_celldefine,
                            Module::UCDriveType uc_drive_def);

extern void pform_start_class_declaration(const struct vlltype&loc,
					  class_type_t*type,
					  data_type_t*base_type,
					  std::list<named_pexpr_t> *base_args,
					  bool virtual_class,
					  bool interface_class = false,
					  std::list<data_type_t*>*interface_types = 0,
					  bool base_default = false);
extern void pform_class_property(const struct vlltype&loc,
				 property_qualifier_t pq,
				 data_type_t*data_type,
				 std::list<decl_assignment_t*>*decls);
extern void pform_set_this_class(const struct vlltype&loc, PTaskFunc*net);
extern void pform_mark_recent_class_method_virtual(void);
extern void pform_set_recent_class_method_qualifiers(property_qualifier_t qual);
extern void pform_set_constructor_return(PFunction*net);
extern bool pform_reenter_class_scope(const struct vlltype&loc, const char*name);
extern void pform_leave_class_scope(const struct vlltype&loc);

extern void pform_end_class_declaration(const struct vlltype&loc);
extern bool pform_in_class();
extern void pform_bind_extern_func(PFunction*func);
extern void pform_bind_extern_task(PTask*task);
extern void pform_blend_class_constructors(PClass*pclass);
extern PClass* pform_find_visible_class_scope(LexicalScope*start, perm_string name);
extern std::vector<pform_tf_port_t>* pform_class_constructor_default_ports(
					const struct vlltype&loc, PFunction*constructor);
extern std::vector<named_pexpr_t> pform_class_constructor_default_args(
					PFunction*constructor);

extern void pform_class_constraint(const struct vlltype&loc,
				    bool is_static,
				    unsigned override_specifiers,
				    const char*name,
				    std::list<PExpr*>*items);
extern void pform_class_constraint_prototype(const struct vlltype&loc,
					      bool is_static,
                                              unsigned override_specifiers,
					      const char*name, bool is_extern = true);
extern void pform_class_pure_constraint(const struct vlltype&loc,
					 unsigned override_specifiers,
					 const char*name);

// covergroup declaration inside a class body.
// coverpoints is a list<pform_covergroup_t::pform_coverpoint_t*> built by parse.y.
// Takes ownership of the list; each element is move-constructed into covergroup.
#include "pform_types.h"
extern void pform_class_covergroup_set_extends(const char*name);
extern void pform_class_covergroup(const struct vlltype&loc,
				    const char*name,
				    std::list<class_type_t::pform_coverpoint_t*>*coverpoints,
				    std::vector<perm_string>*sample_formals = nullptr,
				    std::vector<PWire*>*sample_formal_types = nullptr,
				    std::vector<PEEvent*>*sample_events = nullptr,
				    std::vector<perm_string>*ctor_formals = nullptr,
				    std::vector<data_type_t*>*ctor_formal_types = nullptr,
				    std::vector<bool>*ctor_formal_is_ref = nullptr,
				    std::vector<PExpr*>*ctor_defaults = nullptr,
				    std::vector<PExpr*>*sample_formal_defaults = nullptr);

// M11-1/2: a STANDALONE covergroup declaration (module/package/
// interface scope). Synthesizes a class type of the same name whose
// elaboration IS the covergroup class; `cg cg_inst = new;` then
// creates a live covergroup object.
extern void pform_standalone_covergroup(const struct vlltype&loc,
				    const char*name,
				    std::list<class_type_t::pform_coverpoint_t*>*coverpoints,
				    std::vector<PEEvent*>*sample_events = nullptr,
				    std::vector<perm_string>*sample_formals = nullptr,
				    std::vector<PWire*>*sample_formal_types = nullptr,
				    std::vector<perm_string>*ctor_formals = nullptr,
				    std::vector<data_type_t*>*ctor_formal_types = nullptr,
				    std::vector<bool>*ctor_formal_is_ref = nullptr,
				    std::vector<PExpr*>*ctor_defaults = nullptr,
				    std::vector<PExpr*>*sample_formal_defaults = nullptr);

extern void pform_make_udp(const struct vlltype&loc, perm_string name,
			   std::list<pform_ident_t>*parms,
			   std::vector<PWire*>*decl, std::list<std::string>*table,
			   Statement*init);

extern void pform_make_udp(const struct vlltype&loc, perm_string name,
			   bool sync_flag, const pform_ident_t&out_name,
			   PExpr*sync_init,
			   std::list<pform_ident_t>*parms,
			   std::list<std::string>*table);
/*
 * Package related functions.
 */
extern void pform_start_package_declaration(const struct vlltype&loc,
					    const char*type,
					    LexicalScope::lifetime_t lifetime);
extern void pform_end_package_declaration(const struct vlltype&loc);
extern void pform_package_import(const struct vlltype&loc,
				 PPackage*pkg, const char*ident);
extern void pform_package_export(const struct vlltype &loc, PPackage *pkg,
			         const char *ident);
PPackage *pform_package_importable(PPackage *pkg, perm_string name);
PPackage *pform_find_potential_import(const struct vlltype&loc, LexicalScope*scope,
				      perm_string name, bool tf_call, bool make_explicit);


extern PExpr* pform_package_ident(const struct vlltype&loc,
				  PPackage*pkg, const pform_name_t*ident);

/*
 * Interface related functions.
 */
extern void pform_start_modport_item(const struct vlltype&loc, const char*name);
extern void pform_end_modport_item(const struct vlltype&loc);
extern void pform_abort_modport_item(void);
extern bool pform_modport_item_pending(void);
extern bool pform_add_modport_tf_port(const struct vlltype&loc,
                                      bool is_import, perm_string name);
extern void pform_start_modport_tf_prototype(const struct vlltype&loc);
extern void pform_finish_modport_tf_prototype(
                                      const struct vlltype&loc,
                                      perm_string name,
                                      bool is_function,
                                      data_type_t*return_type,
                                      std::vector<pform_tf_port_t>*ports);
extern void pform_commit_modport_tf_prototype(const struct vlltype&loc,
                                              bool is_import);
extern void pform_discard_modport_tf_prototype(void);
extern void pform_add_modport_clocking_port(const struct vlltype&loc,
                                            perm_string name);
extern void pform_add_modport_port(const struct vlltype&loc,
				   NetNet::PortType port_type,
				   perm_string name, PExpr*expr);
/* Open a clocking block declaration in the current module, interface,
   or program scope (IEEE 1800-2017 14.3). A null name declares an
   anonymous default clocking block (14.12), registered under an
   internal name. is_default records the block as the scope's default
   clocking. */
extern void pform_start_clocking_block(const struct vlltype&loc,
				       const char*name,
				       PEventStatement*event,
				       bool is_default = false,
				       bool is_global = false);
extern void pform_add_clocking_signal(const struct vlltype&loc, perm_string name,
				      NetNet::PortType dir,
				      const pform_clocking_skew_t*in_skew,
				      const pform_clocking_skew_t*out_skew,
				      PExpr*decl_assign = nullptr);
extern void pform_set_clocking_default_skews(const struct vlltype&loc,
					     const pform_clocking_skew_t*in_skew,
					     const pform_clocking_skew_t*out_skew);
extern Statement* pform_make_clocking_drive(const struct vlltype&loc,
					    PExpr*lval, PExpr*cycles,
					    PExpr*rval);

/* M9 core SVA (IEEE 1800-2017 clause 16): lower one concurrent
   assertion to a synthesized clocked token-pipeline checker.
   kind: 0=assert, 1=assume, 2=cover. */
struct sva_property_t;
struct sva_seq_step_t;
struct sva_mc_seg_t;
struct sva_prop_case_item_t;
struct rs_production_t;
/* Ownership helpers used by parser error/disabled-feature paths as well as
   the SVA lowerers. They delete all expressions and event controls still
   owned by the supplied IR object. */
extern void pform_sva_destroy_sequence(std::vector<sva_seq_step_t>*seq);
extern void pform_sva_destroy_property(sva_property_t*prop);
/* Preserve an optional source label while the assertion statement itself
   reduces. The enclosing grammar item owns the label token. */
extern void pform_sva_set_assertion_label(const char*label);
extern void pform_sva_clear_assertion_label(void);
/* Apply the optional clock/disable prefix of a property_spec without
   discarding a clock already carried by an embedded named sequence. */
extern sva_property_t* pform_sva_apply_property_context(
				       const struct vlltype&loc,
				       sva_property_t*prop,
				       PEventStatement*clk,
				       PExpr*disable_iff);
extern void pform_sva_destroy_mc_segments(std::vector<sva_mc_seg_t>*segs);
extern void pform_make_assertion(const struct vlltype&loc,
				 sva_property_t*prop,
				 Statement*fail_stmt, Statement*pass_stmt,
				 int kind, perm_string label = perm_string());
/* M9-10: implicit clock inference for a concurrent assertion written
   inside procedural code (IEEE 1800-2017 16.14.6). An unclocked assertion
   with no default clocking is parked by pform_make_assertion; the first
   enclosing `event_control statement_or_null' supplies its event, and
   anything still parked when the module (or checker) ends is an error. */
extern void pform_sva_infer_procedural_clock(PEventStatement*ctl);
extern void pform_sva_flush_pending_procedural(void);
extern void pform_sva_flush_pending_named_properties(void);
/* M9-frontier (Phase 3): `expect (property) pass; else fail;' (IEEE
   1800-2017 16.17) — a PROCEDURAL statement that blocks the executing
   process until a single attempt of the property completes, then runs
   the pass or the else action. For a fixed-length boolean sequence this
   lowers to procedural clock-waits + checks (no new runtime); other
   shapes are a loud sorry. Consumes prop, pass_stmt, else_stmt; returns
   the lowered procedural statement (an empty block when diagnosed). */
extern Statement* pform_make_expect(const struct vlltype&loc,
				    sva_property_t*prop,
				    Statement*pass_stmt, Statement*else_stmt);
/* Assertion-local declarations are parsed before their sequence match
   assignments. Preserve the declared integral conversion so the synthesized
   per-attempt carrier has the local's type, rather than the assignment RHS
   type. The packed-logic helper consumes dimensions. */
extern void pform_sva_begin_local_declarations(void);
extern void pform_sva_declare_int_local(const struct vlltype&loc,
					const char*name);
/* owns_dimensions=false borrows *dimensions to compute a width for one
   name among several sharing a single comma-separated declaration,
   without freeing the shared list; exactly one call among the group
   (typically the last) must pass owns_dimensions=true to release it. */
extern void pform_sva_declare_logic_local(
					const struct vlltype&loc,
					const char*name,
					std::list<pform_range_t>*dimensions,
					bool owns_dimensions = true);
extern PExpr* pform_sva_coerce_local_assignment(
					const struct vlltype&loc,
					const char*name, PExpr*rhs);
/* Turn a direct bit/constant part-select local assignment into a full-value
   update expression. Takes ownership of both bounds and rhs. */
extern PExpr* pform_sva_selected_local_assignment(
					const struct vlltype&loc,
					const char*name, PExpr*msb, PExpr*lsb,
					PExpr*rhs, bool bit_select);
extern void pform_sva_end_local_declarations(void);
extern void pform_sva_declare_property(const struct vlltype&loc,
				       const char*name, sva_property_t*prop);
extern void pform_sva_declare_sequence(const struct vlltype&loc,
				       const char*name,
				       std::vector<sva_seq_step_t>*steps);
/* A complete sequence-declaration body can carry its own clock, clock-flow
   boundary, or regular-language combinator.  Preserve that property-shaped
   IR while still routing a plain unclocked chain through the longstanding
   named-sequence splice table. */
extern void pform_sva_declare_sequence_spec(const struct vlltype&loc,
					    const char*name,
					    sva_property_t*body);
/* M9D: parameterized named property/sequence declarations. `formals` is
   the ordered list of formal-argument names (may be null/empty). */
extern void pform_sva_declare_property_p(const struct vlltype&loc,
					 const char*name,
					 std::list<perm_string>*formals,
					 sva_property_t*prop);
extern void pform_sva_declare_sequence_p(const struct vlltype&loc,
					 const char*name,
					 std::list<perm_string>*formals,
					 std::vector<sva_seq_step_t>*steps);
extern void pform_sva_set_default_disable(PExpr*expr);
extern void pform_sva_sorry(const struct vlltype&loc, const char*what);
/* Evaluate the integral constant-expression subset used by SVA
   repetition and cycle-delay bounds while the module is being parsed. */
extern bool pform_sva_const_long(PExpr*expr, long&value);
extern bool pform_sva_overridable_bound(PExpr*expr);
extern void pform_sva_single_delay(const struct vlltype&loc, sva_seq_step_t&step, PExpr*delay);
/* A bare genvar is a constant expression only after its generate loop is
   unrolled and each generated scope receives the implicit localparam value.
   Preserve that name through the parse-time SVA lowering instead of treating
   it as a run-time variable or folding every instance to the loop initializer. */
extern bool pform_sva_deferred_genvar(PExpr*expr, perm_string&name);
extern void pform_sva_module_done(void);

/* M9-2: consecutive repetition e[*lo] / e[*lo:hi] — expands the step
   list in place (clones for lo>1; [*lo:hi] expands to [*lo] with a
   rep_tail marker validated at lowering). hi may be null. */
extern std::vector<sva_seq_step_t>*
pform_sva_repeat(const struct vlltype&loc,
		 std::vector<sva_seq_step_t>*steps,
		 PExpr*lo, PExpr*hi, bool unbounded = false);

/* M9-NFA stage C.1: goto `b[->m:n]' (kind 1) / nonconsecutive `b[=m:n]'
   (kind 2) repetition of a boolean (IEEE 1800-2017 16.9.2). `steps' must
   be a single boolean atom; the repetition is recorded on that step for
   the automaton engine (the legacy engine loudly rejects it). `hi' may
   be null for the single-count `[->n]' form (hi := lo); `unbounded'
   marks the `[->m:$]' upper. Consumes lo and hi. */
extern std::vector<sva_seq_step_t>*
pform_sva_goto_repeat(const struct vlltype&loc,
		      std::vector<sva_seq_step_t>*steps,
		      int kind, PExpr*lo, PExpr*hi, bool unbounded);

/* M9C: `guard throughout seq` (IEEE 1800-2017 16.9.9) — lowered to an
   ordinary unit-delay sequence with `guard` AND-ed into every cycle.
   Returns the transformed step list, or nullptr (diagnosed) for the
   variable-window shapes it does not support. Consumes guard and seq. */
extern std::vector<sva_seq_step_t>*
pform_sva_throughout(const struct vlltype&loc, PExpr*guard,
		     std::vector<sva_seq_step_t>*seq);

/* M9B: `s1 intersect s2` (IEEE 1800-2017 16.9.6) — both operands must
   match over the same interval. Lowered, for fixed-length operands of
   equal length, to a single unit-delay chain whose per-cycle boolean is
   the AND of the two operands' per-cycle booleans. Returns the merged
   step list, or nullptr (diagnosed) for variable-length or unequal-
   length operands. Consumes s1 and s2. */
extern std::vector<sva_seq_step_t>*
pform_sva_intersect(const struct vlltype&loc,
		    std::vector<sva_seq_step_t>*s1,
		    std::vector<sva_seq_step_t>*s2);

/* M9-NFA stage B: package a sequence `or'/`and' (op 'o'/'a') as a
   combinator tree on an sva_property_t. Consumes both chains. Only the
   automaton engine lowers these; without IVL_SVA_NFA=1 the assertion
   is a loud sorry at lowering. */
extern sva_property_t*
pform_sva_seq_comb(const struct vlltype&loc, char op,
		   std::vector<sva_seq_step_t>*s1,
		   std::vector<sva_seq_step_t>*s2);

/* M9-NFA stage B.2: `intersect` — equal-length fixed operands keep the
   legacy AND-chain lowering; unequal fixed lengths keep the parse-time
   sorry; non-fixed shapes build a SEQ_INTERSECT product tree for the
   automaton engine. Consumes both chains. */
extern sva_property_t*
pform_sva_seq_intersect(const struct vlltype&loc,
			std::vector<sva_seq_step_t>*s1,
			std::vector<sva_seq_step_t>*s2);

/* M9-NFA stage B.3: recursive combinator nesting. pform_sva_leaf_prop
   wraps a chain as a leaf-tree operand; pform_sva_tree_comb (op 'o'/'a')
   and pform_sva_tree_intersect combine two operand properties (each
   carrying a tree, or a chain from the legacy fixed-intersect path).
   All consume their operands. */
extern sva_property_t*
pform_sva_leaf_prop(std::vector<sva_seq_step_t>*chain);
extern sva_property_t*
pform_sva_tree_comb(const struct vlltype&loc, char op,
		    sva_property_t*a, sva_property_t*b);
extern sva_property_t*
pform_sva_tree_intersect(const struct vlltype&loc,
			 sva_property_t*a, sva_property_t*b);
/* Continue an arbitrary sequence-combinator tree through a fixed cycle
   delay and a linear suffix, e.g. `(a and b) ##0 c'. */
extern sva_property_t*
pform_sva_tree_concat(const struct vlltype&loc, sva_property_t*prefix,
		      PExpr*delay, std::vector<sva_seq_step_t>*suffix);

/* M9-NFA stage B.4: `within`. Both-fixed operands keep the legacy op-8
   lowering; a non-fixed operand builds a SEQ_WITHIN tree for the
   automaton engine. Consumes both chains. */
extern sva_property_t*
pform_sva_seq_within(const struct vlltype&loc,
		     std::vector<sva_seq_step_t>*s1,
		     std::vector<sva_seq_step_t>*s2);

/* M9-NFA stage B.5: `throughout`. A fixed-length sequence keeps the
   legacy source-level lowering; a variable-length sequence builds a
   SEQ_THROUGHOUT tree for the automaton engine. Consumes guard and
   seq. */
extern sva_property_t*
pform_sva_seq_throughout(const struct vlltype&loc, PExpr*guard,
			 std::vector<sva_seq_step_t>*seq);

/* M9C temporal property operators (IEEE 1800-2017 16.12.10 `until` /
   `until_with` / `s_until` / `s_until_with`, 16.9.6 `within`). These do
   not fit the linear token pipeline, so they are stashed on an
   sva_property_t with a dedicated op_type and lowered by
   pform_make_assertion once the assertion `kind` is known. The builders
   below just package the operands; sub is the left operand, obj the
   right. within takes two sequences (sub within obj); the until family
   takes two booleans (sub until obj). */
extern sva_property_t*
pform_sva_binprop(const struct vlltype&loc, int op_type,
		  std::vector<sva_seq_step_t>*sub,
		  std::vector<sva_seq_step_t>*obj);

/* M9C-live / M9F: unary liveness/safety property operators (IEEE 1800-2017
   16.12.2 `nexttime`/`s_nexttime`, 16.12.5 `s_eventually`, 16.12.6-.7 bounded
   `eventually`/`s_eventually`/`always`/`s_always`). The operand must be a
   boolean property; it is repackaged onto an sva_property_t with a dedicated
   op_type (9 nexttime, 10 s_nexttime, 11 s_eventually unbounded, 12 always
   family, 13 bounded eventually family) and lowered by pform_make_assertion.
   `strength` marks the strong form (s_always/s_eventually). Consumes sub. */
extern sva_property_t*
pform_sva_unprop(const struct vlltype&loc, int op_type, sva_property_t*sub,
		 long win_lo = -1, long win_hi = -1, int strength = 0);
/* M9-2: abort operators (IEEE 1800-2017 16.12.9). `accept_on(c) p' aborts to
   a PASS the instant c holds; `reject_on(c) p' aborts to a FAIL. The sync_
   variants sample c at the clock (op_type 14 accept_on, 15 reject_on,
   16 sync_accept_on, 17 sync_reject_on). The operand must be a boolean
   property; cond and sub are consumed. */
extern sva_property_t*
pform_sva_abort(const struct vlltype&loc, int op_type, PExpr*cond,
		sva_property_t*sub);
/* M9-3: property combinators (IEEE 1800-2017 16.12.8). For boolean operands
   `a implies b', `a iff b', `if (c) p [else q]' and `case (e) ... endcase'
   reduce to a single boolean property (`!a|b', `(a&b)|(!a&!b)',
   `(c&p)|(!c&q)', and a nested match chain respectively). Operands must be
   boolean properties; a sequence/nested operand is a loud sorry. All
   operands (and, for case, the item list) are consumed. */
extern sva_property_t*
pform_sva_prop_implies(const struct vlltype&loc,
		       std::vector<sva_seq_step_t>*a,
		       std::vector<sva_seq_step_t>*b);
extern sva_property_t*
pform_sva_prop_iff(const struct vlltype&loc,
		   std::vector<sva_seq_step_t>*a,
		   std::vector<sva_seq_step_t>*b);
extern sva_property_t*
pform_sva_prop_not(const struct vlltype&loc, sva_property_t*sub);
extern sva_property_t*
pform_sva_comb_antecedent_sorry(const struct vlltype&loc, int op_type,
				sva_property_t*ante,
				std::vector<sva_seq_step_t>*conseq,
				bool strong_eventually = false);
extern sva_property_t*
pform_sva_comb_consequent_sorry(const struct vlltype&loc, int op_type,
				std::vector<sva_seq_step_t>*ante,
				sva_property_t*conseq);
extern sva_property_t*
pform_sva_tree_implication(const struct vlltype&loc, int op_type,
			   sva_property_t*ante, sva_property_t*conseq);
extern sva_property_t*
pform_sva_multiclock_comb_antecedent(
			   const struct vlltype&loc, int op_type,
			   sva_property_t*ante, PEventStatement*clk,
			   std::vector<sva_seq_step_t>*conseq,
			   std::vector<sva_mc_seg_t>*tail);
extern sva_property_t*
pform_sva_paren_conseq(const struct vlltype&loc, int op_type,
		       std::vector<sva_seq_step_t>*ante,
		       sva_property_t*conseq);
extern sva_property_t*
pform_sva_prop_if(const struct vlltype&loc, PExpr*cond, sva_property_t*then_p,
		  sva_property_t*else_p);
extern sva_property_t*
pform_sva_case(const struct vlltype&loc, PExpr*sel,
	       std::vector<sva_prop_case_item_t>*items);
/* M3B-2: expand a `randsequence' (IEEE 1800-2017 18.17) into procedural
   code. `start' is the initial production (empty => the first listed).
   Alternatives lower to a weighted PRandCase; a production sequence lowers
   to a block; a non-terminal reference expands recursively (a cyclic
   grammar is a loud sorry — the source-level expansion cannot unroll it).
   Consumes the production list. */
extern Statement* pform_make_randsequence(const struct vlltype&loc,
					  perm_string start,
					  std::vector<rs_production_t>*prods);
extern void pform_end_clocking_block(const struct vlltype&loc);
/* `default clocking <id>;` — select an existing clocking block as the
   scope default (IEEE 1800-2017 14.12). Existence is checked at
   endmodule so declaration order doesn't matter. */
extern void pform_set_default_clocking_ref(const struct vlltype&loc,
					   const char*name);

/*
 * This creates an identifier aware of names that may have been
 * imported from other packages.
 */
extern PEIdent* pform_new_ident(const struct vlltype&loc, const pform_name_t&name);

extern PTrigger* pform_new_trigger(const struct vlltype&loc, PPackage*pkg,
				   const pform_name_t&name, unsigned lexical_pos);
extern PNBTrigger* pform_new_nb_trigger(const struct vlltype&loc,
				        const std::list<PExpr*>*dly,
				        const pform_name_t&name,
				        unsigned lexical_pos);

/*
 * Enter/exit name scopes. The push_scope function pushes the scope
 * name string onto the scope hierarchy. The pop pulls it off and
 * deletes it. Thus, the string pushed must be allocated.
 */
extern void pform_pop_scope();

/*
 * Peek at the current (most recently active) scope.
 */
extern LexicalScope* pform_peek_scope();
extern bool pform_in_compilation_unit_scope();
extern bool pform_in_task_function_scope();
extern void pform_push_existing_scope(LexicalScope*scope);

extern PClass* pform_push_class_scope(const struct vlltype&loc, perm_string name);

extern PFunction*pform_push_constructor_scope(const struct vlltype&loc);

extern PPackage* pform_push_package_scope(const struct vlltype&loc, perm_string name,
					  LexicalScope::lifetime_t lifetime);

extern PTask*pform_push_task_scope(const struct vlltype&loc, const char*name,
				   LexicalScope::lifetime_t lifetime);
extern PTask*pform_push_task_scope_unbound(const struct vlltype&loc, const char*name,
					   LexicalScope::lifetime_t lifetime);

extern PFunction*pform_push_function_scope(const struct vlltype&loc, const char*name,
					   LexicalScope::lifetime_t lifetime);
extern PFunction*pform_push_function_scope_unbound(const struct vlltype&loc, const char*name,
					     LexicalScope::lifetime_t lifetime,
					     bool procedural_body = true);

// DPI export (IEEE 1800-2017 35.5): mark an already-defined SV
// function/task in the current scope as callable from C under c_name.
// The export declaration must follow the subroutine definition in the
// same scope; sv_name names the SV subroutine, c_name is the exported C
// symbol (== sv_name for the plain form). is_task selects the tasks map.
extern void pform_set_dpi_export(const struct vlltype&loc, const char*c_name,
				 const char*sv_name, bool is_task);
// Resolve all deferred `export "DPI-C"' declarations once every source
// file has been parsed (an export may precede its subroutine definition).
extern int pform_resolve_dpi_exports(void);

extern PBlock*pform_push_block_scope(const struct vlltype&loc, const char*name,
				     PBlock::BL_TYPE tt);

/* Create/finalize the implicit lexical block that owns pattern variables for
 * one case item or the true arm of a pattern conditional. */
extern PBlock*pform_pattern_push_scope(const struct vlltype&loc,
                                       const PExpr*subject,
                                       const PMatchPattern*pattern);
extern PBlock*pform_pattern_finish_scope(const struct vlltype&loc,
                                         PBlock*block,
                                         Statement*statement,
                                         const PExpr*subject,
                                         const PMatchPattern*pattern);

extern void pform_put_behavior_in_scope(AProcess*proc);

extern verinum* pform_verinum_with_size(verinum*s, verinum*val,
					const char*file, unsigned lineno);

/*
 * This function takes the list of names as new genvars to declare in
 * the current module or generate scope.
 */
extern void pform_genvars(const struct vlltype&li, std::list<pform_ident_t>*names);

/*
 * This flag is set by the parser to indicate the current generate block
 * was not enclosed in a begin-end pair. This is a pre-requisite for
 * directly nesting generate constructs.
 */
extern bool pform_generate_single_item;

extern void pform_start_generate_for(const struct vlltype&li,
				     bool local_index,
				     char*ident1,
				     PExpr*init,
				     PExpr*test,
				     char*ident2,
				     PExpr*next);
extern void pform_start_generate_if(const struct vlltype&li, PExpr*test);
extern void pform_start_generate_else(const struct vlltype&li);
extern void pform_start_generate_case(const struct vlltype&lp, PExpr*test);
extern void pform_start_generate_nblock(const struct vlltype&lp, char*name);
extern void pform_generate_case_item(const struct vlltype&lp, std::list<PExpr*>*test);
extern void pform_generate_block_name(const char*name);
extern void pform_endgenerate(bool end_conditional);

/*
 * This function returns the lexically containing generate scheme, if
 * there is one. The parser may use this to check if we are within a
 * generate scheme.
 */
extern PGenerate* pform_parent_generate(void);

bool pform_error_in_generate(const vlltype&loc, const char *type);

extern void pform_make_elab_task(const struct vlltype&li,
                                 perm_string name,
                                 const std::list<named_pexpr_t> &params);

extern void pform_set_typedef(const struct vlltype&loc, perm_string name,
			      data_type_t*data_type,
			      std::list<pform_range_t>*unp_ranges = nullptr);
extern void pform_forward_typedef(const struct vlltype&loc, perm_string name,
			      enum typedef_t::basic_type basic_type);

extern void pform_set_type_referenced(const struct vlltype&loc, const char*name);

/* User-defined nettype registration and lookup. The declaration scope owns
 * returned descriptors; references and PWire objects borrow them. */
extern nettype_t* pform_declare_nettype(
                              const struct vlltype&loc, perm_string name,
                              data_type_t*data_type,
                              const pform_scoped_name_t*resolution_function);
extern nettype_t* pform_declare_nettype_alias(
                              const struct vlltype&loc, perm_string name,
                              nettype_t*alias);
extern nettype_t* pform_test_nettype_identifier(
                              const struct vlltype&loc, const char*name);
extern nettype_t* pform_test_nettype_identifier(PPackage*pkg,
                                                const char*name);
extern void pform_set_nettype_referenced(const struct vlltype&loc,
                                         const char*name);

/*
 * This function makes a PECallFunction of the named function.
 */
extern PECallFunction* pform_make_call_function(const struct vlltype&loc,
						const pform_name_t&name,
						const std::list<named_pexpr_t> &parms,
						struct parmvalue_t*type_args = 0);
extern PCallTask* pform_make_call_task(const struct vlltype&loc,
				       const pform_name_t&name,
				       const std::list<named_pexpr_t> &parms,
				       struct parmvalue_t*type_args = 0);

extern void pform_make_foreach_declarations(const struct vlltype&loc,
					    const pform_name_t*array_name,
					    std::list<perm_string>*loop_vars);
extern PForeach* pform_make_foreach(const struct vlltype&loc,
				    const pform_name_t&ident,
				    std::list<perm_string>*loop_vars,
				    Statement*stmt);

/*
 * The makewire functions announce to the pform code new wires. These
 * go into a module that is currently opened.
 */
extern PWire *pform_makewire(const struct vlltype&li,
                             const pform_ident_t&name,
			     NetNet::Type type,
			     const std::list<pform_range_t> *indices);

extern void pform_set_nettype_wires(const struct vlltype&li,
                                    nettype_t*nettype,
                                    std::vector<PWire*>*wires,
                                    std::list<named_pexpr_t>*attr = nullptr);
extern void pform_make_nettype_wires(const struct vlltype&li,
                                     nettype_t*nettype,
                                     std::list<PExpr*>*delay,
                                     str_pair_t str,
                                     std::list<decl_assignment_t*>*assign_list,
                                     std::list<named_pexpr_t>*attr = nullptr);
extern void pform_set_interconnect_wires(const struct vlltype&li,
                                         data_type_t*implicit_type,
                                         std::vector<PWire*>*wires,
                                         std::list<named_pexpr_t>*attr = nullptr);
extern void pform_make_interconnect_wires(
                                         const struct vlltype&li,
                                         data_type_t*implicit_type,
                                         std::list<decl_assignment_t*>*assign_list,
                                         std::list<named_pexpr_t>*attr = nullptr);

/* This form handles assignment declarations. */

extern void pform_makewire(const struct vlltype&li,
			   std::list<PExpr*>*delay,
			   str_pair_t str,
			   std::list<decl_assignment_t*>*assign_list,
			   NetNet::Type type,
			   data_type_t*data_type,
			   std::list<named_pexpr_t>*attr = 0,
			   bool is_const = false);

extern void pform_make_var(const struct vlltype&loc,
			   std::list<decl_assignment_t*>*assign_list,
			   data_type_t*data_type,
			   std::list<named_pexpr_t>*attr = 0,
			   bool is_const = false);
extern void pform_set_var_lifetime(ivl_lifetime_t lifetime);

extern void pform_make_var_init(const struct vlltype&li,
				const pform_ident_t&name,
				PExpr*expr);

extern void pform_make_struct_member_defaults(
				const struct vlltype&li,
				const data_type_t*data_type,
				decl_assignment_t*variable,
				std::vector<Statement*>&initializers);
extern bool pform_has_implicit_struct_member_defaults(
				const data_type_t*data_type,
				const decl_assignment_t*variable);
extern bool pform_validate_struct_member_defaults(
				const struct vlltype&li,
				const data_type_t*data_type,
				const decl_assignment_t*variable);

/* This function is used when we have an incomplete port definition in
   a non-ansi style declaration. Look up the names of the wires, and set
   the port type, i.e. input, output or inout, and, if specified, the
   range and signedness. If the wire does not exist, create it. */
extern void pform_set_port_type(const struct vlltype&li,
				std::list<pform_port_t>*ports,
				NetNet::PortType,
				data_type_t*dt,
				std::list<named_pexpr_t>*attr);

extern void pform_set_data_type(const struct vlltype&li,
				data_type_t *data_type,
				std::vector<PWire*> *wires,
				NetNet::Type net_type,
				std::list<named_pexpr_t>*attr,
				bool is_const = false);

extern void pform_set_net_delay(const struct vlltype&li,
				std::list<PExpr*>*delay,
				std::vector<PWire*>*wires);

extern void pform_set_string_type(const struct vlltype&li, const string_type_t*string_type, std::list<perm_string>*names, NetNet::Type net_type, std::list<named_pexpr_t>*attr);

extern void pform_set_class_type(const struct vlltype&li, class_type_t*class_type, std::list<perm_string>*names, NetNet::Type net_type, std::list<named_pexpr_t>*addr);


  /* pform_set_attrib and pform_set_type_attrib exist to support the
     $attribute syntax, which can only set string values to
     attributes. The functions keep the value strings that are
     passed in. */
extern void pform_set_attrib(perm_string name, perm_string key,
			     char*value);
extern void pform_set_type_attrib(perm_string name, const std::string&key,
				  char*value);

extern LexicalScope::range_t* pform_parameter_value_range(bool exclude_flag,
						    bool low_open, PExpr*low_expr,
						    bool hig_open, PExpr*hig_expr);

extern void pform_set_parameter(const struct vlltype&loc,
                                perm_string name,
                                bool is_local, bool is_type,
                                data_type_t*data_type, const std::list<pform_range_t>*udims,
                                PExpr*expr, LexicalScope::range_t*value_range,
                                type_parameter_restriction_t restriction =
                                      type_parameter_restriction_t::NONE);
extern void pform_set_specparam(const struct vlltype&loc,
				 perm_string name,
				 std::list<pform_range_t>*range,
				 PExpr*expr);
extern void pform_set_defparam(const pform_name_t&name, PExpr*expr);

/* M14: lower `case (X) inside {items}` to membership tests. */
extern Statement* pform_make_case_inside(const struct vlltype&loc,
					 ivl_case_quality_t qual,
					 PExpr*sel,
					 std::vector<PCase::Item*>*items);

/* IEEE 1800-2017 12.4.2: lower a qualified if/else-if chain to the
 * equivalent quality-checked case (1'b1) form. */
extern Statement* pform_make_quality_if(const struct vlltype&loc,
                                        ivl_case_quality_t qual,
                                        PExpr*cond,
                                        Statement*if_clause,
                                        Statement*else_clause);

extern void pform_make_let(const struct vlltype&loc,
                           perm_string name,
                           std::list<PLet::let_port_t*>*ports,
                           PExpr*expr);

extern PLet::let_port_t* pform_make_let_port(data_type_t*data_type,
                                             perm_string name,
                                             std::list<pform_range_t>*range,
                                             PExpr*def);

/*
 * Functions related to specify blocks.
 */
extern PSpecPath*pform_make_specify_path(const struct vlltype&li,
					 std::list<perm_string>*src, char pol,
					 bool full_flag, std::list<perm_string>*dst);
extern PSpecPath*pform_make_specify_edge_path(const struct vlltype&li,
					 int edge_flag, /*posedge==true */
					 std::list<perm_string>*src, char pol,
					 bool full_flag, std::list<perm_string>*dst,
					 PExpr*data_source_expression);
extern PSpecPath*pform_assign_path_delay(PSpecPath*obj, std::list<PExpr*>*delays);

extern void pform_module_specify_path(PSpecPath*obj);

/*
 * Functions related to timing checks.
 */
extern PRecRem* pform_make_recrem(const struct vlltype&li,
			    PTimingCheck::event_t*reference_event,
			    PTimingCheck::event_t*data_event,
			    PExpr*setup_limit,
			    PExpr*hold_limit,
			    PTimingCheck::optional_args_t* args
			    );
extern PSetupHold* pform_make_setuphold(const struct vlltype&li,
			    PTimingCheck::event_t*reference_event,
			    PTimingCheck::event_t*data_event,
			    PExpr*setup_limit,
			    PExpr*hold_limit,
			    PTimingCheck::optional_args_t* args
			    );
extern void pform_module_timing_check(PTimingCheck*obj);

/* M9-NFA (Phase 2): automaton-based SVA engine, staged behind the
   IVL_SVA_NFA env flag. try_assertion builds the automaton and, once
   the stage-A synthesizer lands, lowers supported assertions and
   returns true; returning false means the caller must fall back to
   the legacy linear engine. See
   docs/conformance/m9_nfa_design_2026-07-19.md. */
extern bool pform_sva_nfa_enabled();
extern bool pform_sva_nfa_try_assertion(const struct vlltype&loc,
					struct sva_property_t*prop,
					Statement*fail_stmt,
					Statement*pass_stmt,
					int kind);

/* M13: synthesize real timing-check checker processes (clause 31).
   Active with -gspecify; loud ignored-warning otherwise. The event
   arguments are borrowed (caller keeps ownership). */
extern void pform_timing_check_pair(const struct vlltype&loc,
				    const char*check_name,
				    const PTimingCheck::event_t&stamp_ev,
				    const PTimingCheck::event_t&check_ev,
				    PExpr*limit,
				    bool violation_if_greater,
				    const pform_name_t*notifier);
extern void pform_timing_check_setuphold_recrem(const struct vlltype&loc,
						const char*base_name,
						const PTimingCheck::event_t&ref_ev,
						const PTimingCheck::event_t&data_ev,
						PExpr*lim1,
						PExpr*lim2,
						const pform_name_t*notifier);
extern void pform_timing_check_period(const struct vlltype&loc,
				      const PTimingCheck::event_t&ev,
				      PExpr*limit,
				      const pform_name_t*notifier);
extern void pform_timing_check_width(const struct vlltype&loc,
				     const PTimingCheck::event_t&ev,
				     PExpr*limit,
				     PExpr*threshold,
				     const pform_name_t*notifier);
/* M13B: $timeskew/$fullskew are skew checks (violation when the delta
   exceeds the limit). have_flags is true when the source gave the
   event_based/remain_active flag arguments, whose report-granularity
   semantics are not modeled: loud sorry, check dropped. */
extern void pform_timing_check_timeskew(const struct vlltype&loc,
					const PTimingCheck::event_t&ref_ev,
					const PTimingCheck::event_t&data_ev,
					PExpr*limit,
					const pform_name_t*notifier,
					bool have_flags);
extern void pform_timing_check_fullskew(const struct vlltype&loc,
					const PTimingCheck::event_t&ref_ev,
					const PTimingCheck::event_t&data_ev,
					PExpr*lim1,
					PExpr*lim2,
					const pform_name_t*notifier,
					bool have_flags);
/* M13B: $nochange(edge ref, data, start_off, end_off): data must not
   change during the reference level following the edge. Exact for
   zero offsets; non-zero offsets get a loud sorry. */
extern void pform_timing_check_nochange(const struct vlltype&loc,
					const PTimingCheck::event_t&ref_ev,
					const PTimingCheck::event_t&data_ev,
					PExpr*start_off,
					PExpr*end_off,
					const pform_name_t*notifier);
extern void pform_timing_check_sorry(const struct vlltype&loc,
				     const char*check_name);

/*
 * pform_make_behavior creates processes that are declared with always
 * or initial items.
 */
/* M9-SV: procedural sampled value functions (IEEE 1800-2017 16.9.3).
 * The parser records each $past/$rose/$fell/$stable/$changed call it
 * builds; pform_make_behavior binds the ones written inside an
 * edge-triggered always block to that block's clock, and whatever is
 * still unbound when the module closes gets a diagnostic instead of a
 * silent unsampled answer. */
extern bool pform_is_sampled_value_function(const char*name);
extern void pform_note_sampled_call(const struct vlltype&loc,
				    class PECallFunction*cf);
extern void pform_flush_pending_sampled_calls();
/* Bind ONE sampled value call to an explicit clocking event, given as
 * that call's last argument. Consumes nothing; the caller still owns
 * the event statement. */
extern void pform_bind_sampled_call_to_event(const struct vlltype&loc,
					     class PECallFunction*cf,
					     class PEventStatement*ev);

extern PProcess*  pform_make_behavior(ivl_process_type_t, Statement*,
				      std::list<named_pexpr_t>*attr);

/* Lower the supported deferred-immediate assertion and cover subset
   (IEEE 1800-2017 16.4) into evaluate-now / per-process queued reporting.
   pass_stmt/fail_stmt may be nil; a nil fail_stmt gets the default $error.
   Unsupported action shapes fail loudly. */
extern Statement* pform_make_deferred_assertion(const struct vlltype&loc,
					 PExpr*expr,
					 Statement*pass_stmt,
					 Statement*fail_stmt,
					 unsigned assertion_kind,
					 bool is_final);
extern Statement* pform_make_deferred_cover(const struct vlltype&loc,
				     PExpr*expr,
				     Statement*pass_stmt,
				     bool is_final);
extern void pform_mc_translate_on(bool flag);

extern std::vector<PWire*>* pform_make_udp_input_ports(std::list<pform_ident_t>*);

extern void pform_make_events(const struct vlltype&loc,
			      const std::list<pform_event_ident_t*>*names,
			      ivl_lifetime_t lifetime = IVL_VLT_INHERITED);
/*
 * The makegate function creates a new gate (which need not have a
 * name) and connects it to the specified wires.
 */
extern void pform_makegates(const struct vlltype&loc,
			    PGBuiltin::Type type,
			    struct str_pair_t str,
			    const std::list<PExpr*>*delay,
			    std::vector<lgate>*gates,
			    std::list<named_pexpr_t>*attr);

extern void pform_make_modgates(const struct vlltype&loc,
				perm_string type,
				struct parmvalue_t*overrides,
				std::vector<lgate>*gates,
				std::list<named_pexpr_t>*attr);

/* SystemVerilog bind directive (IEEE 1800-2017 23.11): record a bind
   of a module instantiation into a named target module/interface.
   Binds are collected during parse and applied by pform_apply_binds()
   after all source files have been parsed, because the target module
   may be defined in a later file than the bind directive.

   inst_paths selects the bind-to-instance forms: for
     bind <mod> : <inst_list> ...   target is the module name and
                                    inst_paths lists the instances;
     bind <hier.path> ...           target is empty ("") and inst_paths
                                    holds the single structured path.
   Each path retains its constant bit selects. Target-list entries use the
   same hierarchical lookup as a direct bind target: first relative to the
   containing generate/module scope, then as an absolute path rooted at a
   module/interface definition. There is no designwide terminal-name search.
   nullptr means bind to the definition (every instance). */
extern void pform_bind_directive(const struct vlltype&loc,
				 perm_string target,
				 perm_string type,
				 struct parmvalue_t*overrides,
				 std::vector<lgate>*gates,
				 std::list<pform_name_t>*inst_paths = nullptr);
extern void pform_apply_binds(void);
extern void pform_find_bind_module_mentions(
				std::map<perm_string,bool>&mentions);
extern bool pform_activate_deferred_binds(Design*des);
extern void pform_check_bind_matches(Design*des);

/* Make a continuous assignment node, with optional bit- or part- select. */
extern void pform_make_alias(const struct vlltype&loc,
			     std::list<PExpr*>*nets);
extern void pform_make_pgassign_list(const struct vlltype&loc,
				     std::list<PExpr*>*alist,
				     std::list<PExpr*>*del,
				     struct str_pair_t str);

extern std::vector<pform_tf_port_t>*pform_make_task_ports(const struct vlltype&loc,
					     NetNet::PortType pt,
					     data_type_t*vtype,
				     std::list<pform_port_t>*ports,
				     bool allow_implicit = false,
				     bool is_const = false,
				     bool is_ref_static = false);

/*
 * The parser uses this function to convert a unary
 * increment/decrement expression to the equivalent compressed
 * assignment statement.
 */
extern PAssign* pform_compressed_assign_from_inc_dec(const struct vlltype&loc,
						     PExpr*exp);

/*
 * The parser uses this function to convert a genvar increment/decrement
 * expression to the equivalent binary add/subtract expression.
 */
extern PExpr* pform_genvar_inc_dec(const struct vlltype&loc, const char*name,
                                   bool inc_flag);

extern PExpr* pform_genvar_compressed(const struct vlltype &loc,
				      const char *name, char op, PExpr *rval);

/*
 * These are functions that the outside-the-parser code uses the do
 * interesting things to the Verilog. The parse function reads and
 * parses the source file and places all the modules it finds into the
 * mod list. The dump function dumps a module to the output stream.
 */
extern void pform_dump(std::ostream&out, const Module*mod);

/* ** pform_discipline.cc
 * Functions for handling the parse of natures and disciplines. These
 * functions are in pform_disciplines.cc
 */

extern void pform_start_nature(const char*name);
extern void pform_end_nature(const struct vlltype&loc);

extern void pform_nature_access(const struct vlltype&loc, const char*name);

extern void pform_start_discipline(const char*name);
extern void pform_end_discipline(const struct vlltype&loc);

extern void pform_discipline_domain(const struct vlltype&loc, ivl_dis_domain_t use_domain);
extern void pform_discipline_potential(const struct vlltype&loc, const char*name);
extern void pform_discipline_flow(const struct vlltype&loc, const char*name);

extern void pform_attach_discipline(const struct vlltype&loc,
				    ivl_discipline_t discipline, std::list<pform_ident_t>*names);

extern void pform_dump(std::ostream&out, const ivl_nature_s*);
extern void pform_dump(std::ostream&out, const ivl_discipline_s*);

/* ** pform_analog.cc
*/
extern void pform_make_analog_behavior(const struct vlltype&loc,
				       ivl_process_type_t type, Statement*st);

extern AContrib*pform_contribution_statement(const struct vlltype&loc,
					     PExpr*lval, PExpr*rval);

extern PExpr* pform_make_branch_probe_expression(const struct vlltype&loc,
                                                 const char*name, const char*n1, const char*n2);

extern PExpr* pform_make_branch_probe_expression(const struct vlltype&loc,
                                                 const char*name, const char*branch);

/*
 * Parse configuration file with format <key>=<value>, where key
 * is the hierarchical name of a valid parameter name and value
 * is the value user wants to assign to. The value should be constant.
 */
extern void parm_to_defparam_list(const std::string&param);

/*
 * Tasks to set the timeunit or timeprecision for SystemVerilog.
 */
extern bool get_time_unit(const char*cp, int &unit);
extern int  pform_get_timeunit();
extern int  pform_get_timeprec();
extern void pform_set_timeunit(const char*txt, bool initial_decl);
extern void pform_set_timeprec(const char*txt, bool initial_decl);
/*
 * Flags to determine whether this is an initial declaration.
 */
extern bool allow_timeunit_decl;
extern bool allow_timeprec_decl;

void pform_put_enum_type_in_scope(enum_type_t*enum_set);

bool pform_requires_sv(const struct vlltype&loc, const char *feature);
void pform_block_decls_requires_sv(void);
bool pform_block_scope_is_empty(void);
bool pform_scope_in_routine(void);

void pform_start_parameter_port_list();
void pform_end_parameter_port_list();

void pform_check_net_data_type(const struct vlltype&loc, NetNet::Type net_type,
			       const data_type_t *data_type);

#endif /* IVL_pform_H */
