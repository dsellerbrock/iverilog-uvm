#ifndef IVL_t_dll_H
#define IVL_t_dll_H
/*
 * Copyright (c) 2000-2026 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "target.h"
# include  "ivl_target.h"
# include  "ivl_target_priv.h"
# include  "StringHeap.h"
# include  "netlist.h"
# include  <cstddef>
# include  <new>
# include  <type_traits>
# include  <vector>
# include  <map>

/* Procedure target records are consumed synchronously by the target. These
 * helpers let the caller bound their backing storage by the largest procedure
 * while retaining the allocated blocks for reuse by the next procedure. */
void dll_procedure_begin();
void dll_procedure_reset();
bool dll_procedure_active();
void*dll_procedure_malloc(size_t bytes);
void*dll_procedure_malloc(size_t bytes, size_t alignment);
void*dll_procedure_calloc(size_t count, size_t bytes);
void*dll_procedure_calloc(size_t count, size_t bytes, size_t alignment);
char*dll_procedure_strdup(const char*text);

template <class TYPE> TYPE*dll_procedure_new()
{
      if (!dll_procedure_active())
	    return new TYPE();

      static_assert(std::is_trivially_destructible<TYPE>::value,
		    "procedure arena objects cannot require destruction");
      void*mem = dll_procedure_calloc(1, sizeof(TYPE), alignof(TYPE));
      return mem? ::new (mem) TYPE : 0;
}

template <class TYPE> TYPE*dll_procedure_new_array(size_t count)
{
      if (!dll_procedure_active())
	    return new TYPE[count]();
      if (count == 0)
	    return 0;

      static_assert(std::is_trivially_destructible<TYPE>::value
		    || std::is_same<TYPE, struct ivl_statement_s>::value,
		    "procedure arena arrays cannot require destruction");
      TYPE*mem = static_cast<TYPE*>(
	    dll_procedure_calloc(count, sizeof(TYPE), alignof(TYPE)));
      if (!mem)
	    return 0;
      for (size_t idx = 0; idx < count; idx += 1)
	    ::new (static_cast<void*>(mem + idx)) TYPE;
      return mem;
}

#if defined(__MINGW32__)
#include <windows.h>
typedef void *ivl_dll_t;
#elif defined(HAVE_DLFCN_H)
# include  <dlfcn.h>
typedef void* ivl_dll_t;
#elif defined(HAVE_DL_H)
# include  <dl.h>
typedef shl_t ivl_dll_t;
#else
# error No DLL stub support for this target.
#endif

/*
 * The DLL target type loads a named object file to handle the process
 * of scanning the netlist. When it is time to start the design, I
 * locate and link in the desired DLL, then start calling methods. The
 * DLL will call me back to get information out of the netlist in
 * particular.
 */
struct dll_target  : public target_t, public expr_scan_t {

	// This is a special function for loading and testing the
	// version of a loadable target code generator.
      void test_version(const char*target_name);

      bool start_design(const Design*) override;
      bool needs_design() const override { return needs_design_; }
      int  end_design(const Design*) override;

      bool bufz(const NetBUFZ*) override;
      bool branch(const NetBranch*) override;
      bool end_nodes() override;
      bool can_release_source_connectivity() const override { return true; }
      bool can_emit_processes_before_definitions() const override
	    { return !stream_processes_; }
      bool start_processes() override;
      bool end_processes() override;
      bool ordered_process_callbacks() const override
	    { return order_processes_; }
      bool order_processes(std::vector<target_process_ref_t>&) override;
      bool class_type(const NetScope*, netclass_t*) override;
      bool enumeration(const NetScope*, netenum_t*) override;
      void event(const NetEvent*) override;
      void logic(const NetLogic*) override;
      bool tran(const NetTran*) override;
      bool ureduce(const NetUReduce*) override;
      void net_case_cmp(const NetCaseCmp*) override;
      void udp(const NetUDP*) override;
      void lpm_abs(const NetAbs*) override;
      void lpm_add_sub(const NetAddSub*) override;
      bool lpm_array_dq(const NetArrayDq*) override;
      bool lpm_cast_int2(const NetCastInt2*) override;
      bool lpm_cast_int4(const NetCastInt4*) override;
      bool lpm_cast_real(const NetCastReal*) override;
      void lpm_clshift(const NetCLShift*) override;
      void lpm_compare(const NetCompare*) override;
      void lpm_divide(const NetDivide*) override;
      void lpm_ff(const NetFF*) override;
      void lpm_latch(const NetLatch*) override;
      void lpm_modulo(const NetModulo*) override;
      void lpm_mult(const NetMult*) override;
      void lpm_mux(const NetMux*) override;
      void lpm_pow(const NetPow*) override;
      bool concat(const NetConcat*) override;
      bool part_select(const NetPartSelect*) override;
      bool replicate(const NetReplicate*) override;
      bool vif_proxy(const NetVifProxy*) override;
      static void net_assign(const NetAssign_*);
      bool net_sysfunction(const NetSysFunc*) override;
      bool net_function(const NetUserFunc*) override;
      bool net_const(const NetConst*) override;
      bool net_literal(const NetLiteral*) override;
      void net_probe(const NetEvProbe*) override;
      bool sign_extend(const NetSignExtend*) override;
      bool substitute(const NetSubstitute*) override;

      bool process(const NetProcTop*) override;
      bool process(const NetAnalogTop*) override;
      void scope(const NetScope*) override;
      void convert_module_ports(const NetScope*) override;
      void signal(const NetNet*) override;
      bool signal_paths(const NetNet*) override;
      ivl_dll_t dll_;

      ivl_design_s des_;

      target_design_f target_;
      target_design_begin_f target_begin_ = 0;
      target_process_f target_process_ = 0;
      target_design_end_f target_end_ = 0;
      target_process_order_f target_process_order_ = 0;
      bool stream_processes_ = false;
      bool order_processes_ = false;
      bool stream_started_ = false;
      bool stream_begin_succeeded_ = false;
      bool stream_finished_ = false;
      int stream_result_ = 0;

      bool streaming_processes() const { return stream_processes_; }
      bool stream_process(ivl_process_t);


	/* These methods and members are used for forming the
	   statements of a thread. */
      struct ivl_statement_s*stmt_cur_;
      void proc_alloc(const NetAlloc*) override;
      bool proc_assign(const NetAssign*) override;
      void proc_assign_nb(const NetAssignNB*) override;
      bool proc_block(const NetBlock*) override;
      bool proc_break(const NetBreak*) override;
      void proc_case(const NetCase*) override;
      bool proc_cassign(const NetCAssign*) override;
      bool proc_condit(const NetCondit*) override;
      bool proc_continue(const NetContinue*) override;
      bool proc_contribution(const NetContribution*) override;
      bool proc_deassign(const NetDeassign*) override;
      bool proc_delay(const NetPDelay*) override;
      bool proc_disable(const NetDisable*) override;
      void proc_do_while(const NetDoWhile*) override;
      bool proc_force(const NetForce*) override;
      void proc_forever(const NetForever*) override;
      bool proc_forloop(const NetForLoop*) override;
      void proc_free(const NetFree*) override;
      bool proc_release(const NetRelease*) override;
      void proc_repeat(const NetRepeat*) override;
      void proc_stask(const NetSTask*) override;
      bool proc_trigger(const NetEvTrig*) override;
      bool proc_nb_trigger(const NetEvNBTrig*) override;
      bool proc_trigger_obj(const NetEvTrigObj*) override;
      bool proc_wait_obj(const NetEvWaitObj*) override;
      bool proc_trigger_arr(const NetEvTrigArr*) override;
      bool proc_wait_arr(const NetEvWaitArr*) override;
      void proc_utask(const NetUTask*) override;
      bool proc_wait(const NetEvWait*) override;
      void proc_while(const NetWhile*) override;

      bool func_def(const NetScope*) override;
      void task_def(const NetScope*) override;

      struct ivl_expr_s*expr_;
      void expr_access_func(const NetEAccess*) override;
      void expr_array_pattern(const NetEArrayPattern*) override;
      void expr_array_slice(const NetEArraySlice*) override;
      void expr_binary(const NetEBinary*) override;
      void expr_concat(const NetEConcat*) override;
      void expr_const(const NetEConst*) override;
      void expr_creal(const NetECReal*) override;
      void expr_last(const NetELast*) override;
      void expr_new(const NetENew*) override;
      void expr_null(const NetENull*) override;
      void expr_param(const NetEConstParam*) override;
      void expr_property(const NetEProperty*) override;
      void expr_rparam(const NetECRealParam*) override;
      void expr_event(const NetEEvent*) override;
      void expr_scope(const NetEScope*) override;
      void expr_scopy(const NetEShallowCopy*) override;
      void expr_netenum(const NetENetenum*) override;
      void expr_select(const NetESelect*) override;
      void expr_sfunc(const NetESFunc*) override;
      void expr_ternary(const NetETernary*) override;
      void expr_ufunc(const NetEUFunc*) override;
      void expr_unary(const NetEUnary*) override;
      void expr_signal(const NetESignal*) override;

      ivl_scope_t lookup_scope_(const NetScope*scope);

      ivl_attribute_s* fill_in_attributes(const Attrib*net);
      void switch_attributes(struct ivl_switch_s *obj, const NetNode*net);
      void logic_attributes(struct ivl_net_logic_s *obj, const NetNode*net);

    private:
      bool needs_design_ = true;
      StringHeap strings_;

      static ivl_scope_t find_scope(ivl_design_s &des, const NetScope*cur);
      ivl_signal_t find_signal(const NetNet*net);
      static ivl_parameter_t scope_find_param(ivl_scope_t scope,
					      const char*name);

      ivl_event_t find_event_(const NetEvent*net);
      bool finalize_event_pins_(const NetEvent*net);
      bool validate_scope_event_pins_(ivl_scope_t scope) const;

      void add_root(const NetScope *s);

      bool make_assign_lvals_(const NetAssignBase*net);
      bool make_single_lval_(const LineInfo*li, struct ivl_lval_s*cur, const NetAssign_*asn);
      void sub_off_from_expr_(long);
      void mul_expr_by_const_(long);

      void fill_delays_(ivl_expr_t*delay, const NetObj*net);
      ivl_expr_t* make_sparse_delays_(const NetObj*net);
      void make_logic_delays_(struct ivl_net_logic_s*obj, const NetObj*net);
      void make_switch_delays_(struct ivl_switch_s*obj, const NetObj*net);
      void make_lpm_delays_(struct ivl_lpm_s*obj, const NetObj*net);
      void make_const_delays_(struct ivl_net_const_s*obj, const NetObj*net);
      void make_scope_parameters(ivl_scope_t scope, const NetScope*net);
      void make_scope_param_expr(ivl_parameter_t cur_par, NetExpr*etmp);

      ivl_event_t make_lpm_trigger(const NetEvWait*ev);

      bool lpm_arith1_(ivl_lpm_type_t lpm_type, unsigned wid, bool signed_flag, const NetNode*net);

      static ivl_expr_t expr_from_value_(const verinum&that);
};

extern struct dll_target dll_target_obj;

/*
 * These are various private declarations used by the t-dll target.
 */

struct ivl_delaypath_s {
      ivl_scope_t scope;
      ivl_nexus_t src;
      ivl_nexus_t condit;
      bool conditional;
      bool parallel;
      bool posedge;
      bool negedge;
      uint64_t delay[12];
};

struct ivl_obj_mutation_path_s {
      unsigned obj_N;
      unsigned obj_pre_N;
      unsigned root_pin;
      unsigned property_N;
      unsigned property_word;
      ivl_expr_t property_word_expr;
      unsigned property_bit;
      ivl_expr_t property_bit_expr;
      ivl_expr_t owner_expr;
};

struct ivl_event_s {
      perm_string name;
      ivl_scope_t scope;
      ivl_lifetime_t lifetime;
      perm_string file;
      unsigned lineno;
      unsigned nany, nneg, npos, nedg;
      ivl_nexus_t*pins;
      std::vector<bool> any_is_obj_handle_change;
      bool pins_finalized;
      // VIF edge support: @(posedge/negedge/edge vif.signal)
      bool is_vif_posedge;
      bool is_vif_negedge;
      bool is_vif_anyedge;
      unsigned vif_N;
      unsigned vif_M;
      unsigned vif_member_word;
      unsigned vif_pre_N; // UINT_MAX = unused (2-level); set = extra prop hop (3-level)
      std::vector<unsigned> vif_path; // root-to-interface property indices
      unsigned vif_root_pin;
      ivl_expr_t vif_object_expr; // runtime-selected VIF receiver, if any
      ivl_nexus_t vif_validity;
      bool is_obj_mutation;
      unsigned obj_N;
      unsigned obj_pre_N;
      std::vector<ivl_obj_mutation_path_s> obj_mutation_paths;
      ivl_expr_t observer_expr;
      unsigned observer_edge;
      // Named-event array support (IEEE 1800-2017 6.20): see
      // ivl_event_is_array() et al. in ivl_target.h.
      bool is_array;
      unsigned array_base;
      unsigned array_count;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/*
 * The ivl_expr_t is an opaque reference to one of these
 * structures. This structure holds all the information we need about
 * an expression node, including its type, the expression width, and
 * type specific properties.
 */
uint64_t dll_target_expr_location(const LineInfo*info);
const char* dll_target_expr_file(uint64_t location);
unsigned dll_target_signal_array_words(const NetNet*net);
int dll_target_signal_array_base(const NetNet*net);
bool dll_target_signal_array_addr_swapped(const NetNet*net);

struct ivl_expr_s {
      const NetExpr*origin_ = nullptr;
      unsigned type_ : 8;
      unsigned value_ : 8;
      unsigned signed_ : 1;
      unsigned sized_  : 1;
      unsigned super_call_ : 1;
      unsigned property_signal_ : 1;
      unsigned width_;
      ivl_type_t net_type;
      /* High 32 bits identify an interned source filename; low 32 bits are
       * the full LineInfo line number. This copies location identity without
       * retaining a soon-to-be-released NetExpr and keeps the opaque target
       * expression record compact on 64-bit hosts. */
      uint64_t location_;

      union {
	    struct {
		  char op_;
		  ivl_expr_t lef_;
		  ivl_expr_t rig_;
	    } binary_;

	    struct {
		  size_t parms;
		  ivl_expr_t*parm;
		  int union_active_member;
	    } array_pattern_;

	    struct {
		  ivl_signal_t sig;
		  long canonical_base;
		  unsigned long count;
		  long left;
		  long right;
	    } array_slice_;

	    struct {
		  ivl_select_type_t  sel_type_;
		  ivl_expr_t expr_;
		  ivl_expr_t base_;
	    } select_;

	    struct {
		  ivl_expr_t dest;
		  ivl_expr_t src;
	    } shallow_;

	    struct {
		  ivl_branch_t branch;
		  ivl_nature_t nature;
	    } branch_;

	    struct {
		  unsigned   rept;
		  unsigned   parms;
		  ivl_expr_t*parm;
	    } concat_;

	    struct {
		  char*bits_;
		  ivl_parameter_t parameter;
	    } number_;

	    struct {
		  ivl_event_t event;
	    } event_;

	    struct {
		  ivl_scope_t scope;
	    } scope_;

	    struct {
		  ivl_enumtype_t type;
	    } enumtype_;

	    struct {
		  ivl_signal_t sig;
		  ivl_expr_t word;
	    } signal_;

	    struct {
		  const char *name_;
		  ivl_expr_t *parm;
		  unsigned   parms;
		  ivl_scope_t *vif_method;
		  unsigned   vif_methods;
		  unsigned char *vif_parm_default;
		  ivl_lval_t ref_lval;
	    } sfunc_;

	    struct {
		  char*value_;
		  ivl_parameter_t parameter;
	    } string_;

	    struct {
		  ivl_expr_t cond;
		  ivl_expr_t true_e;
		  ivl_expr_t false_e;
	    } ternary_;

	    struct {
		  ivl_memory_t mem_;
		  ivl_expr_t idx_;
	    } memory_;

	    struct {
		  ivl_scope_t def;
		  ivl_expr_t  *parm;
		  unsigned    parms;
	    } ufunc_;

	    struct {
		  unsigned long value;
	    } ulong_;

	    struct {
		  double value;
		  ivl_parameter_t parameter;
	    } real_;

	    struct {
		  char op_;
		  ivl_expr_t sub_;
	    } unary_;

	    struct {
		  uint64_t value;
	    } delay_;

	    struct {
		  ivl_expr_t size;
		  ivl_expr_t init_val;
	    } new_;

	    struct {
		  union {
			ivl_signal_t sig;
			ivl_expr_t base;
		  } source;
		  unsigned prop_idx;
		  ivl_expr_t index;
	    } property_;
      } u_;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

static_assert(IVL_EX_ARRAY_SLICE < 256,
	      "ivl_expr_s expression tag exceeds packed storage");
static_assert(IVL_VT_QUEUE < 256,
	      "ivl_expr_s value tag exceeds packed storage");

/*
 * LPM devices are handled by this suite of types. The ivl_lpm_s
 * structure holds the core, including a type code, the object name
 * and scope. The other properties of the device are held in the type
 * specific member of the union.
 */

struct ivl_lpm_s {
      ivl_lpm_type_t type;
      ivl_scope_t scope;
      perm_string name;
      perm_string file;
      unsigned lineno;
	// Value returned by ivl_lpm_width;
      unsigned width;
      unsigned event_synchronous = 0;
      ivl_expr_t*delay;

      union {
	    struct ivl_lpm_ff_s {
		  unsigned negedge_flag :1;
		  unsigned aset_priority_flag :1;
		  ivl_nexus_t clk;
		  ivl_nexus_t we;
		  ivl_nexus_t aclr;
		  ivl_nexus_t aset;
		  ivl_nexus_t sclr;
		  ivl_nexus_t sset;
		  union {
			ivl_nexus_t*pins;
			ivl_nexus_t pin;
		  } q;
		  union {
			ivl_nexus_t*pins;
			ivl_nexus_t pin;
		  } d;
		  ivl_expr_t aset_value;
		  ivl_expr_t sset_value;
	    } ff;
	    struct ivl_lpm_latch_s {
		  ivl_nexus_t e;
		  union {
			ivl_nexus_t*pins;
			ivl_nexus_t pin;
		  } q;
		  union {
			ivl_nexus_t*pins;
			ivl_nexus_t pin;
		  } d;
	    } latch;

	    struct ivl_lpm_mux_s {
		  unsigned size;
		  unsigned swid;
		  ivl_nexus_t*d;
		  ivl_nexus_t q, s;
	    } mux;

	    struct ivl_lpm_shift_s {
		  unsigned select;
		  unsigned signed_flag :1;
		  ivl_nexus_t q, d, s;
	    } shift;

	    struct ivl_lpm_arith_s {
		  unsigned signed_flag :1;
		  ivl_nexus_t q,  a,  b;
	    } arith;

	    struct ivl_lpm_array_s {
		  ivl_signal_t sig;
		  unsigned swid;
		  unsigned negedge_flag :1;
		  unsigned write_flag :1;
		  ivl_nexus_t q, a, d, clk, we;
	    } array;

	    struct ivl_concat_s {
		  unsigned inputs;
		  ivl_nexus_t*pins;
	    } concat;

	    struct ivl_part_s {
		  unsigned base;
		  unsigned signed_flag :1;
		  ivl_nexus_t q, a, s;
	    } part;

	      // IVL_LPM_RE_* and IVL_LPM_SIGN_EXT use this.
	    struct ivl_lpm_reduce_s {
		  ivl_nexus_t q,  a;
	    } reduce;

	    struct ivl_lpm_repeat_s {
		  unsigned count;
		  ivl_nexus_t q, a;
	    } repeat;

	    struct ivl_lpm_sfunc_s {
		  const char* fun_name;
		  unsigned ports;
		  ivl_nexus_t*pins;
		  ivl_event_t trigger;
	    } sfunc;

	    struct ivl_lpm_substitute {
		  unsigned base;
		  unsigned signed_flag :1;
		  ivl_nexus_t q, a, s, b;
	    } substitute;

	    struct ivl_lpm_vif_proxy_s {
		  ivl_nexus_t q, root, valid;
		  unsigned root_word, member, word;
		  unsigned path_count;
		  unsigned*path;
	    } vif_proxy;

	    struct ivl_lpm_ufunc_s {
		  ivl_scope_t def;
		  unsigned ports;
		  ivl_nexus_t*pins;
		  ivl_event_t trigger;
	    } ufunc;
      } u_;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/*
 * This object represents l-values to assignments. The l-value can be
 * a register bit or part select, or a memory word select with a part
 * select.
 */

enum ivl_lval_type_t {
      IVL_LVAL_REG = 0,
      IVL_LVAL_ARR = 4,
      IVL_LVAL_LVAL= 5  // Nested l-value
};

struct ivl_lval_s {
      ivl_expr_t loff;
      ivl_expr_t idx;
      ivl_signal_t sig;
      ivl_lval_t nest;
      ivl_type_t net_type_;
      ivl_expr_t stream_range_first_;
      ivl_expr_t stream_range_second_;
      unsigned width_;
      uint64_t part_carrier_off_;
      unsigned part_carrier_wid_;
      ivl_expr_t dynamic_part_carrier_;
      int property_idx;
      unsigned sel_type : 3;
      unsigned array_slice_ : 1;
      unsigned queue_slice_ : 1;
      unsigned type_ : 3; /* values from ivl_lval_type_t */
      unsigned stream_range_ : 3;
};

static_assert(IVL_LVAL_LVAL < 8,
	      "ivl_lval_s l-value tag exceeds packed storage");
static_assert(IVL_STREAM_RANGE_DOWN < 8,
	      "ivl_lval_s stream-range tag exceeds packed storage");

/*
 * This object represents a literal constant, possibly signed, in a
 * structural context.
 */
struct ivl_net_const_s {
      ivl_variable_type_t type :  4;
      unsigned width_          : 24;
      unsigned signed_         :  1;
      unsigned event_synchronous : 1;
      perm_string file;
      unsigned lineno;
      ivl_scope_t scope;

      union {
	    double real_value;
	    char bit_[sizeof(char*)];
	    const char* bits_;
      } b;

      ivl_nexus_t pin_;
      ivl_expr_t*delay;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/*
 * Logic gates (just about everything that has a single output) are
 * represented structurally by instances of this object.
 */
struct ivl_net_logic_s {
      ivl_logic_t type_;
      unsigned width_;
      unsigned is_cassign;
      unsigned is_port_buffer;
      unsigned event_synchronous;
      unsigned delay_is_per_bit = 0;
      unsigned delay_is_whole_vector = 0;
      ivl_udp_t udp;

      perm_string name_;
      ivl_scope_t scope_;
      perm_string file;
      unsigned lineno;

      unsigned npins_;
      ivl_nexus_t*pins_;

      struct ivl_attribute_s*attr;
      unsigned nattr;

      ivl_expr_t*delay;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

struct ivl_switch_s {
      ivl_switch_type_t type;
      unsigned width;
      unsigned part;
      unsigned offset;
      int port_info_index;
      int port_component_index;

      perm_string name;
      ivl_scope_t scope;
      ivl_island_t island;

      struct ivl_attribute_s*attr;
      unsigned nattr;

      ivl_expr_t delay[3];

      ivl_nexus_t pins[3];
      perm_string file;
      unsigned lineno;
};

/*
 * UDP definition.
 */
struct ivl_udp_s {
      perm_string name;
      unsigned nin;
      int sequ; /* boolean */
      char init;
      unsigned nrows;
      typedef const char*ccharp_t;
      ccharp_t*table; // zero terminated array of pointers
      perm_string file;
      unsigned lineno;
      std::string*ports;
};

/*
 * The ivl_nexus_t is a single-bit link of some number of pins of
 * devices. the __nexus_ptr structure is a helper that actually does
 * the pointing.
 *
 * The type_ member specifies which of the object pointers in the
 * union are valid.
 *
 * The drive01 members gives the strength of the drive that the device
 * is applying to the nexus, with 0 HiZ and 3 supply. If the pin is an
 * input to the device, then the drives are both HiZ.
 */
struct ivl_nexus_ptr_s {
      unsigned pin_;
      unsigned type_ : 8;
      unsigned drive0 : 3;
      unsigned drive1 : 3;
      union {
	    ivl_signal_t    sig; /* type 0 */
	    ivl_net_logic_t log; /* type 1 */
	    ivl_net_const_t con; /* type 2 */
	    ivl_lpm_t       lpm; /* type 3 */
	    ivl_switch_t    swi; /* type 4 */
	    ivl_branch_t    bra; /* type 5 */
      } l;
};
# define __NEXUS_PTR_SIG 0
# define __NEXUS_PTR_LOG 1
# define __NEXUS_PTR_CON 2
# define __NEXUS_PTR_LPM 3
# define __NEXUS_PTR_SWI 4
# define __NEXUS_PTR_BRA 5

/*
 * NOTE: ONLY allocate ivl_nexus_s objects with the included "new" operator.
 */
struct ivl_nexus_s {
      ivl_nexus_s() : private_data(0) { }
      std::vector<ivl_nexus_ptr_s>ptrs_;
      void*private_data;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/*
 * This is the implementation of a parameter. Each scope has a list of
 * these.
 */
struct ivl_parameter_s {
      perm_string basename;
      ivl_scope_t scope;
      ivl_expr_t  value;
      long          msb;
      long          lsb;
      bool  signed_flag;
      bool        local;
      bool      is_type;
      perm_string file;
      unsigned lineno;
};
/*
 * All we know about a process is its type (initial or always) and the
 * single statement that is it. A process also has a scope, although
 * that generally only matters for VPI calls.
 */
struct ivl_process_s {
      ivl_process_type_t type_ : 3;
      unsigned int analog_flag : 1;
      ivl_scope_t scope_;
      ivl_statement_t stmt_;
      perm_string file;
      unsigned lineno;

      struct ivl_attribute_s*attr;
      unsigned nattr;

      ivl_process_t next_;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/* Rare scope-owned collections are allocated only for scopes that use them.
 * The source NetScope remains live throughout the synchronous target callback,
 * but these records continue to own the same copied target objects as before. */
struct ivl_scope_objects_s {
      ivl_net_logic_t*log_;
      ivl_event_t*event_;
      ivl_lpm_t*lpm_;
      unsigned nlog_;
      unsigned nevent_;
      unsigned nlpm_;
};

struct ivl_scope_proc_s {
      ivl_statement_t def;
      union {
	    ivl_signal_t*port;
	    ivl_nexus_t*nex;
      } u_;
      const char*dpi_c_name;
      const char*dpi_export_c_name;
      unsigned ports;
};

struct ivl_scope_aux_s {
      std::vector<ivl_type_t>*classes;
      std::vector<ivl_enumtype_t>*enumerations_;
      std::vector<struct ivl_parameter_s>*param;
      std::vector<ivl_switch_t>*switches;
      ivl_scope_objects_s*objects_;
      ivl_scope_proc_s*proc_;
      struct ivl_attribute_s*attr;
};

/* Scopes are kept in a tree. Children retain the exact target creation order.
 * Their source count is known before target emission, so an exact pointer span
 * avoids a vector object in every scope without changing indexed traversal. */
struct ivl_scope_s {
      ivl_scope_s();

      ivl_scope_t parent;
      ivl_scope_t*child;
      const NetScope*net_;

      perm_string name_;
      perm_string tname_;

      std::vector<ivl_signal_t> sigs_;
      ivl_scope_aux_s*aux_;

      unsigned child_count_;
      ivl_scope_type_t type_;
      ivl_variable_type_t func_type;
      unsigned func_width;

      unsigned is_auto : 1;
      unsigned is_disable_target : 1;
      unsigned auto_frame : 1;
      unsigned is_program : 1;
      unsigned is_interface : 1;
      unsigned is_virtual_method : 1;
      unsigned is_cell : 1;
      unsigned func_signed : 1;
      unsigned is_dpi_import : 1;
      unsigned is_dpi_export : 1;

      signed int time_precision :8;
      signed int time_units :8;

	/* NetScope remains live through the synchronous target callback. Source
	   locations, attributes, modport descriptions and module-port
	   introspection data are immutable and are borrowed through net_. */

      ivl_scope_aux_s*ensure_aux_();
      ivl_scope_objects_s*ensure_objects_();
      ivl_scope_proc_s*ensure_proc_();
      ivl_scope_objects_s*objects_() const
      { return aux_ ? aux_->objects_ : 0; }
      ivl_scope_proc_s*proc_() const
      { return aux_ ? aux_->proc_ : 0; }

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/*
 * A signal is a thing like a wire, a reg, or whatever. It has a type,
 * and if it is a port is also has a direction. Signals are collected
 * into scopes (which also point back to me) and have pins that
 * connect to the rest of the netlist.
 */
/* Rare signal payloads are kept out of the high-count base record. Most
 * signals have neither attributes nor specify delay paths. */
struct ivl_signal_aux_s {
      ivl_delaypath_s*path;
      struct ivl_attribute_s*attr;
      unsigned npath;
};

struct ivl_signal_s {
      const NetNet* net_;
      union {
	    ivl_nexus_t pin;
	    ivl_nexus_t*pins;
      };
      ivl_signal_aux_s*aux_;

	/* The source NetNet and its NetScope remain alive through the
	   synchronous target callback. Borrow immutable name, location, type,
	   discipline, dimension, resolver, scope and flag metadata from net_
	   instead of duplicating it in every high-count target record. */
      unsigned type_ : 4;
      unsigned port_ : 3;
      unsigned forced_net_ : 1;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};


/*
 * The ivl_statement_t represents any statement. The type of statement
 * is defined by the ivl_statement_type_t enumeration. Given the type,
 * certain information about the statement may be available.
 */
struct ivl_statement_assign_aux_s {
      ivl_expr_t delay;
      ivl_expr_t count;
      union {
	    ivl_event_t event;
	    ivl_event_t*events;
      };
      unsigned nevent;
};

struct ivl_statement_s {
      enum ivl_statement_type_e type_;
      unsigned lineno;
      perm_string file;

      union {
	    struct { /* IVL_ST_ALLOC */
		  ivl_scope_t scope;
	    } alloc_;

	    struct { /* IVL_ST_ASSIGN IVL_ST_ASSIGN_NB, IVL_ST_CASSIGN,
			IVL_ST_DEASSIGN, IVL_ST_FORCE, IVL_ST_RELEASE */
		  struct ivl_lval_s*lval_;
		  ivl_expr_t rval_;
		  ivl_expr_t force_link_rval_;
		  ivl_statement_assign_aux_s*aux_;
		  unsigned lvals_;
		  char oper; // Operator if this is a compressed assignment.
		  bool assoc_rmw;
	    } assign_;

	    struct { /* IVL_ST_BLOCK, IVL_ST_FORK */
		  struct ivl_statement_s*stmt_;
		  unsigned nstmt_;
		  ivl_scope_t scope;
		  ivl_randsequence_block_t randsequence;
	    } block_;

	    struct { /* IVL_ST_BREAK */
		  ivl_flow_control_t kind;
	    } flow_;

	    struct { /* IVL_ST_CASE, IVL_ST_CASEX, IVL_ST_CASEZ */
		  ivl_expr_t cond;
		  ivl_expr_t*case_ex;
		  struct ivl_statement_s*case_st;
		  unsigned ncase;
		  unsigned char quality;
		  bool quality_if;
	    } case_;

	    struct { /* IVL_ST_CONDIT */
		    /* This is the condition expression */
		  ivl_expr_t cond_;
		    /* This is two statements, the true and false. */
		  struct ivl_statement_s*stmt_;
		    /* This conditional implements an immediate assertion. */
		  bool immediate_assertion;
	    } condit_;

	    struct { /* IVL_ST_CONTRIB */
		  ivl_expr_t lval;
		  ivl_expr_t rval;
	    } contrib_;

	    struct { /* IVL_ST_DELAY */
		  uint64_t value;
		  ivl_statement_t stmt_;
	    } delay_;

	    struct { /* IVL_ST_DELAYX */
		  ivl_expr_t expr; /* XXXX */
		  ivl_statement_t stmt_;
	    } delayx_;

	    struct { /* IVL_ST_DISABLE */
		  ivl_scope_t scope;
		  bool flow_control;
	    } disable_;

	    struct { /* IVL_ST_FOREVER */
		  ivl_statement_t stmt_;
	    } forever_;

	    struct { /* IVL_ST_FORLOOP */
		  ivl_statement_t init_stmt;
		  ivl_expr_t condition;
		  ivl_statement_t stmt;
		  ivl_statement_t step;
	    } forloop_;

	    struct { /* IVL_ST_FREE */
		  ivl_scope_t scope;
	    } free_;

	    struct { /* IVL_ST_STASK */
		  const char*name_;
		  ivl_sfunc_as_task_t sfunc_as_task_;
		  unsigned   nparm_;
		  ivl_expr_t*parms_;
		  ivl_scope_t*vif_method_;
		  unsigned   vif_methods_;
		  ivl_lval_t ref_lval_;
	    } stask_;

	    struct { /* IVL_ST_UTASK */
		  ivl_scope_t def;
		  unsigned super_call;
	    } utask_;

	    struct { /* IVL_ST_TRIGGER IVL_ST_NB_TRIGGER IVL_ST_WAIT, IVL_ST_WAIT_ORDER */
		  unsigned needs_t0_trigger;
		  unsigned nevent;
		  union {
			ivl_event_t event;
			ivl_event_t*events;
		  };
		  ivl_expr_t delay;
		  ivl_statement_t stmt_;
		  ivl_statement_t failure_stmt_;
	    } wait_;

	    struct { /* IVL_ST_TRIGGER_OBJ IVL_ST_NB_TRIGGER_OBJ
			IVL_ST_WAIT_OBJ */
		  ivl_expr_t obj;      /* object-handle expression */
		  unsigned ev_slot;    /* per-class event slot */
		  ivl_expr_t delay;    /* NB trigger delay, else 0 */
		  ivl_statement_t stmt_; /* wait body, else 0 */
	    } evobj_;

	    struct { /* IVL_ST_TRIGGER_ARR IVL_ST_NB_TRIGGER_ARR
			IVL_ST_WAIT_ARR */
		  ivl_expr_t index;      /* element index expression */
		  unsigned   base_slot;  /* design-global base slot */
		  unsigned   count;      /* element count (bounds check) */
		  ivl_expr_t delay;      /* NB trigger delay, else 0 */
		  ivl_statement_t stmt_; /* wait body, else 0 */
	    } evarr_;

	    struct { /* IVL_ST_WHILE IVL_ST_REPEAT */
		  ivl_expr_t cond_;
		  ivl_statement_t stmt_;
	    } while_;
      } u_;

      void* operator new (size_t s);
      void  operator delete(void*obj, size_t s); // Not implemented
};

/*
 * The FILE_NAME function is a shorthand for attaching file/line
 * information to the statement object.
 */
static inline void FILE_NAME(ivl_expr_t expr, const LineInfo*info)
{
      expr->location_ = dll_target_expr_location(info);
      expr->origin_ = dynamic_cast<const NetExpr*>(info);
}

static inline void FILE_NAME(ivl_event_t event, const LineInfo*info)
{
      event->file = info->get_file();
      event->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_lpm_t lpm, const LineInfo*info)
{
      lpm->file = info->get_file();
      lpm->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_net_const_t net, const LineInfo*info)
{
      net->file = info->get_file();
      net->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_net_logic_t net, const LineInfo*info)
{
      net->file = info->get_file();
      net->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_parameter_t net, const LineInfo*info)
{
      net->file = info->get_file();
      net->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_process_t net, const LineInfo*info)
{
      net->file = info->get_file();
      net->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_statement_t stmt, const LineInfo*info)
{
      stmt->file = info->get_file();
      stmt->lineno = info->get_lineno();
}

static inline void FILE_NAME(ivl_switch_t net, const LineInfo*info)
{
      net->file = info->get_file();
      net->lineno = info->get_lineno();
}

#endif /* IVL_t_dll_H */
