/*
 * Copyright (c) 2011-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "vvp_priv.h"
# include  <string.h>
# include  <assert.h>
# include  <stdlib.h>
# include  <limits.h>
# include  <inttypes.h>

/*
 * These functions handle the blocking assignment. Use the %set
 * instruction to perform the actual assignment, and calculate any
 * lvalues and rvalues that need calculating.
 *
 * The set_to_lvariable function takes a particular nexus and generates
 * the %set statements to assign the value.
 *
 * The show_stmt_assign function looks at the assign statement, scans
 * the l-values, and matches bits of the r-value with the correct
 * nexus.
 */

enum slice_type_e {
      SLICE_NO_TYPE = 0,
      SLICE_SIMPLE_VECTOR,
      SLICE_PART_SELECT_STATIC,
      SLICE_PART_SELECT_DYNAMIC,
      SLICE_MEMORY_WORD_STATIC,
      SLICE_MEMORY_WORD_DYNAMIC
};

struct vec_slice_info {
      enum slice_type_e type;
      uint64_t carrier_off;
      unsigned carrier_wid;
      int dynamic_carrier_reg;

      union {
	    struct {
		  unsigned long use_word;
	    } simple_vector;

	    struct {
		  unsigned long part_off;
	    } part_select_static;

	    struct {
		    /* Index reg that holds the memory word index */
		  int word_idx_reg;
		    /* Stored x/non-x flag */
		  unsigned x_flag;
	    } part_select_dynamic;

	    struct {
		  unsigned long use_word;
		    /* Constant bit offset of a part-select ON the word
		       (arr[i][m:l] op= ...); part_wid != 0 marks a partial
		       slice (it can be offset 0 with a narrow width). */
		  unsigned long part_off;
		  unsigned part_wid;
		    /* Reg holding a DYNAMIC part offset, or 0. */
		  int part_off_reg;
		    /* Stored validity flag for that dynamic part offset, or 0. */
		  unsigned part_x_flag;
	    } memory_word_static;

	    struct {
		    /* Index reg that holds the memory word index */
		  int word_idx_reg;
		    /* Stored x/non-x flag */
		  unsigned x_flag;
		    /* Partial slice on the word: see memory_word_static. */
		  unsigned long part_off;
		  unsigned part_wid;
		  int part_off_reg;
		  unsigned part_x_flag;
	    } memory_word_dynamic;
      } u_;
};

static int expr_is_numeric_container_index_(ivl_expr_t expr);
static int prop_is_numeric_queue_index_(ivl_type_t prop_type, ivl_expr_t idx_expr);
static int show_stmt_assign_sig_assoc_index(ivl_statement_t net,
                                            ivl_signal_t var,
                                            ivl_type_t var_type);


static ivl_expr_t prop_lval_index_expr_(ivl_lval_t lval)
{
      /* The enclosing index selects the receiver in a[i].queue, not an
       * element of queue. Only this l-value's own index selects a queue
       * element (IEEE 1800-2017/2023 7.10.1). */
      return ivl_lval_idx(lval);
}

static void get_vec_from_lval_slice(ivl_lval_t lval, struct vec_slice_info*slice,
				    unsigned wid)
{
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_expr_t part_off_ex = ivl_lval_part_off(lval);
      unsigned long part_off = 0;
      slice->carrier_off = ivl_lval_part_carrier_off(lval);
      slice->carrier_wid = ivl_lval_part_carrier_width(lval);
      slice->dynamic_carrier_reg = 0;
      ivl_expr_t dynamic_carrier = ivl_lval_dynamic_part_carrier(lval);

	/* Although Verilog doesn't support it, we'll handle
	   here the case of an l-value part select of an array
	   word if the address is constant. */
      ivl_expr_t word_ix = ivl_lval_idx(lval);
      unsigned long use_word = 0;

      if (part_off_ex == 0) {
	    part_off = 0;
      } else if (slice->carrier_wid == 0
		 && number_is_immediate(part_off_ex, IMM_WID, 0)
		 && !number_is_unknown(part_off_ex)) {
	    long immediate = get_number_immediate(part_off_ex);
	    if (immediate >= 0) {
		  part_off = (unsigned long)immediate;
		  part_off_ex = 0;
	    }
      }

	/* If the word index is a constant expression, then evaluate
	   it to select the word, and pay no further heed to the
	   expression itself. */
      if (word_ix && number_is_immediate(word_ix, IMM_WID, 0)) {
	    if (number_is_unknown(word_ix))
		  use_word = ULONG_MAX; // The largest valid index is ULONG_MAX - 1
	    else
		  use_word = get_number_immediate(word_ix);
	    word_ix = 0;
      }

      if (ivl_signal_dimensions(sig)==0 && part_off_ex==0 && word_ix==0
	  && part_off==0 && wid==ivl_signal_width(sig)) {

	    slice->type = SLICE_SIMPLE_VECTOR;
	    slice->u_.simple_vector.use_word = use_word;
	    if (signal_is_return_value(sig)) {
		  assert(use_word==0);
		  fprintf(vvp_out, "    %%retload/vec4 0;\n");
	    } else {
		  fprintf(vvp_out, "    %%load/vec4 v%p_%lu;\n", sig, use_word);
	    }

      } else if (ivl_signal_dimensions(sig)==0 && part_off_ex==0 && word_ix==0) {

	    assert(use_word == 0);

	    slice->type = SLICE_PART_SELECT_STATIC;
	    slice->u_.part_select_static.part_off = part_off;

	    if (signal_is_return_value(sig)) {
		  assert(use_word==0);
		  fprintf(vvp_out, "    %%retload/vec4 0;\n");
	    } else {
		  fprintf(vvp_out, "    %%load/vec4 v%p_%lu;\n", sig, use_word);
	    }
	    fprintf(vvp_out, "    %%parti/u %u, %lu, 32;\n", wid, part_off);

      } else if (ivl_signal_dimensions(sig)==0 && part_off_ex!=0 && word_ix==0) {

	    assert(use_word == 0);
	    assert(part_off == 0);

	    slice->type = SLICE_PART_SELECT_DYNAMIC;

	    slice->u_.part_select_dynamic.word_idx_reg = allocate_word();
	    slice->u_.part_select_dynamic.x_flag = allocate_flag();

	    if (signal_is_return_value(sig))
		  fprintf(vvp_out, "    %%retload/vec4 0;\n");
	    else
		  fprintf(vvp_out, "    %%load/vec4 v%p_%lu;\n", sig, use_word);
	    if (dynamic_carrier) {
		  int carrier_flag = allocate_flag();
		  slice->dynamic_carrier_reg = allocate_word();
		  draw_eval_vec4(dynamic_carrier);
		  fprintf(vvp_out, "    %%dup/vec4;\n");
		  fprintf(vvp_out, "    %%ix/vec4/s %d; dynamic packed carrier\n",
			  slice->dynamic_carrier_reg);
		  fprintf(vvp_out, "    %%flag_mov %u, 4; carrier validity\n",
			  carrier_flag);
		  fprintf(vvp_out, "    %%part/s %u; selected packed carrier\n",
			  slice->carrier_wid);
		  draw_eval_vec4(part_off_ex);
		  fprintf(vvp_out, "    %%dup/vec4;\n");
		  fprintf(vvp_out, "    %%ix/vec4%s %d; carrier-relative base\n",
			  ivl_expr_signed(part_off_ex) ? "/s" : "",
			  slice->u_.part_select_dynamic.word_idx_reg);
		  fprintf(vvp_out, "    %%flag_or 4, %u; combine carrier validity\n",
			  carrier_flag);
		  clr_flag(carrier_flag);
		  fprintf(vvp_out, "    %%flag_mov %u, 4;\n",
			  slice->u_.part_select_dynamic.x_flag);
		  fprintf(vvp_out, "    %%part/s %u;\n", wid);
	    } else {
	    if (slice->carrier_wid)
		  fprintf(vvp_out, "    %%parti/u %u, %" PRIu64 ", 32; packed carrier\n",
			  slice->carrier_wid, slice->carrier_off);
	    draw_eval_vec4(part_off_ex);
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
		    ivl_expr_signed(part_off_ex) ? "/s" : "",
		    slice->u_.part_select_dynamic.word_idx_reg);
	    fprintf(vvp_out, "    %%flag_mov %u, 4;\n", slice->u_.part_select_dynamic.x_flag);
	    if (slice->carrier_wid)
		  fprintf(vvp_out, "    %%subi %" PRIu64 ", 0, %u; carrier-relative base\n",
			  slice->carrier_off, ivl_expr_width(part_off_ex));
	    fprintf(vvp_out, "    %%part/%c %u;\n",
		    ivl_expr_signed(part_off_ex) ? 's' : 'u', wid);
	    }

      } else if (ivl_signal_dimensions(sig) > 0 && word_ix == 0) {

	    assert(!signal_is_return_value(sig)); // NOT IMPLEMENTED

	    slice->type = SLICE_MEMORY_WORD_STATIC;
	    slice->u_.memory_word_static.use_word = use_word;
	    slice->u_.memory_word_static.part_off = part_off;
	    slice->u_.memory_word_static.part_wid =
		  (wid < ivl_signal_width(sig) || part_off != 0) ? wid : 0;
	    slice->u_.memory_word_static.part_off_reg = 0;
	    slice->u_.memory_word_static.part_x_flag = 0;
	    if (use_word < ivl_signal_array_count(sig)) {
		  fprintf(vvp_out, "    %%ix/load 3, %lu, 0;\n",
			  use_word);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  fprintf(vvp_out, "    %%load/vec4a v%p, 3;\n", sig);
		    /* A part-select ON the array word (arr[i][m:l] op= ...):
		       extract the part so the compound opcode sees matching
		       operand widths. The old code loaded the WHOLE word,
		       crashing %add/%xor on width mismatch and applying |=
		       to the entire element; the store side then wrote back
		       at offset 0. */
		  if (part_off_ex) {
			slice->u_.memory_word_static.part_off_reg = allocate_word();
			slice->u_.memory_word_static.part_x_flag = allocate_flag();
			slice->u_.memory_word_static.part_wid = wid;
			if (dynamic_carrier) {
			      int carrier_flag = allocate_flag();
			      slice->dynamic_carrier_reg = allocate_word();
			      draw_eval_vec4(dynamic_carrier);
			      fprintf(vvp_out, "    %%dup/vec4;\n");
			      fprintf(vvp_out, "    %%ix/vec4/s %d; dynamic packed carrier\n",
				      slice->dynamic_carrier_reg);
			      fprintf(vvp_out, "    %%flag_mov %u, 4; carrier validity\n",
				      carrier_flag);
			      fprintf(vvp_out, "    %%part/s %u; selected packed carrier\n",
				      slice->carrier_wid);
			      draw_eval_vec4(part_off_ex);
			      fprintf(vvp_out, "    %%dup/vec4;\n");
			      fprintf(vvp_out, "    %%ix/vec4%s %d; carrier-relative base\n",
				      ivl_expr_signed(part_off_ex) ? "/s" : "",
				      slice->u_.memory_word_static.part_off_reg);
			      fprintf(vvp_out, "    %%flag_or 4, %u; combine carrier validity\n",
				      carrier_flag);
			      clr_flag(carrier_flag);
			      fprintf(vvp_out, "    %%flag_mov %u, 4;\n",
				      slice->u_.memory_word_static.part_x_flag);
			      fprintf(vvp_out, "    %%part/s %u;\n", wid);
			} else {
			if (slice->carrier_wid)
			      fprintf(vvp_out, "    %%parti/u %u, %" PRIu64 ", 32; packed carrier\n",
				      slice->carrier_wid, slice->carrier_off);
			draw_eval_vec4(part_off_ex);
			fprintf(vvp_out, "    %%dup/vec4;\n");
			fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
				ivl_expr_signed(part_off_ex) ? "/s" : "",
				slice->u_.memory_word_static.part_off_reg);
			fprintf(vvp_out, "    %%flag_mov %u, 4;\n",
				slice->u_.memory_word_static.part_x_flag);
			if (slice->carrier_wid)
			      fprintf(vvp_out, "    %%subi %" PRIu64 ", 0, %u; carrier-relative base\n",
				      slice->carrier_off, ivl_expr_width(part_off_ex));
			fprintf(vvp_out, "    %%part/%c %u;\n",
				ivl_expr_signed(part_off_ex) ? 's' : 'u', wid);
			}
		  } else if (slice->u_.memory_word_static.part_wid) {
			fprintf(vvp_out, "    %%parti/u %u, %lu, 32;\n",
				wid, part_off);
		  }
	    } else {
		  if (dynamic_carrier) {
			draw_eval_vec4(dynamic_carrier);
			fprintf(vvp_out, "    %%pop/vec4 1; invalid array word carrier\n");
		  }
		  if (part_off_ex) {
			draw_eval_vec4(part_off_ex);
			fprintf(vvp_out, "    %%pop/vec4 1; invalid array word part base\n");
		  }
		  if (wid <= 32) {
			fprintf(vvp_out, "    %%pushi/vec4 4294967295, 4294967295, %u;\n", wid);
		  } else {
			fprintf(vvp_out, "    %%pushi/vec4 4294967295, 4294967295, 32;\n");
			fprintf(vvp_out, "    %%pad/s %u;\n", wid);
		  }
	    }

      } else if (ivl_signal_dimensions(sig) > 0 && word_ix != 0) {

	    assert(!signal_is_return_value(sig)); // NOT IMPLEMENTED
	    slice->type = SLICE_MEMORY_WORD_DYNAMIC;

	    slice->u_.memory_word_dynamic.word_idx_reg = allocate_word();
	    slice->u_.memory_word_dynamic.x_flag = allocate_flag();
	    slice->u_.memory_word_dynamic.part_off = part_off;
	    slice->u_.memory_word_dynamic.part_wid =
		  (wid < ivl_signal_width(sig) || part_off != 0) ? wid : 0;
	    slice->u_.memory_word_dynamic.part_off_reg = 0;
	    slice->u_.memory_word_dynamic.part_x_flag = 0;

		  draw_eval_expr_into_integer(word_ix, slice->u_.memory_word_dynamic.word_idx_reg);
		  fprintf(vvp_out, "    %%flag_mov %u, 4;\n", slice->u_.memory_word_dynamic.x_flag);
		  note_array_signal_use(sig);
		  fprintf(vvp_out, "    %%load/vec4a v%p, %d;\n", sig, slice->u_.memory_word_dynamic.word_idx_reg);
		    /* Part-select on the dynamically-indexed word: see the
		       static-word branch above. */
		  if (part_off_ex) {
			slice->u_.memory_word_dynamic.part_off_reg = allocate_word();
			slice->u_.memory_word_dynamic.part_x_flag = allocate_flag();
			slice->u_.memory_word_dynamic.part_wid = wid;
			if (dynamic_carrier) {
			      int carrier_flag = allocate_flag();
			      slice->dynamic_carrier_reg = allocate_word();
			      draw_eval_vec4(dynamic_carrier);
			      fprintf(vvp_out, "    %%dup/vec4;\n");
			      fprintf(vvp_out, "    %%ix/vec4/s %d; dynamic packed carrier\n",
				      slice->dynamic_carrier_reg);
			      fprintf(vvp_out, "    %%flag_mov %u, 4; carrier validity\n",
				      carrier_flag);
			      fprintf(vvp_out, "    %%part/s %u; selected packed carrier\n",
				      slice->carrier_wid);
			      draw_eval_vec4(part_off_ex);
			      fprintf(vvp_out, "    %%dup/vec4;\n");
			      fprintf(vvp_out, "    %%ix/vec4%s %d; carrier-relative base\n",
				      ivl_expr_signed(part_off_ex) ? "/s" : "",
				      slice->u_.memory_word_dynamic.part_off_reg);
			      fprintf(vvp_out, "    %%flag_or 4, %u; combine carrier validity\n",
				      carrier_flag);
			      clr_flag(carrier_flag);
			      fprintf(vvp_out, "    %%flag_mov %u, 4;\n",
				      slice->u_.memory_word_dynamic.part_x_flag);
			      fprintf(vvp_out, "    %%part/s %u;\n", wid);
			} else {
			if (slice->carrier_wid)
			      fprintf(vvp_out, "    %%parti/u %u, %" PRIu64 ", 32; packed carrier\n",
				      slice->carrier_wid, slice->carrier_off);
			draw_eval_vec4(part_off_ex);
			fprintf(vvp_out, "    %%dup/vec4;\n");
			fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
				ivl_expr_signed(part_off_ex) ? "/s" : "",
				slice->u_.memory_word_dynamic.part_off_reg);
			fprintf(vvp_out, "    %%flag_mov %u, 4;\n",
				slice->u_.memory_word_dynamic.part_x_flag);
			if (slice->carrier_wid)
			      fprintf(vvp_out, "    %%subi %" PRIu64 ", 0, %u; carrier-relative base\n",
				      slice->carrier_off, ivl_expr_width(part_off_ex));
			fprintf(vvp_out, "    %%part/%c %u;\n",
				ivl_expr_signed(part_off_ex) ? 's' : 'u', wid);
			}
		  } else if (slice->u_.memory_word_dynamic.part_wid) {
			fprintf(vvp_out, "    %%parti/u %u, %lu, 32;\n",
				wid, part_off);
		  }

      } else {
	    assert(0);
      }

      /* A two-state l-value reads zero for every X/Z bit, including the
       * padding of an out-of-range part select, before the compound operator
       * is applied. */
      if (ivl_signal_data_type(sig) == IVL_VT_BOOL)
	    fprintf(vvp_out, "    %%cast2; compound l-value read\n");
}

/*
 * This loads the l-value values into the top of the stack, and also
 * leaves in the slices the information needed to store the slice
 * results back.
 */
static void get_vec_from_lval(ivl_statement_t net, struct vec_slice_info*slices)
{
      unsigned lidx;
      unsigned cur_bit;

      unsigned wid = ivl_stmt_lwidth(net);

      cur_bit = 0;
      for (lidx = ivl_stmt_lvals(net) ; lidx > 0 ; lidx -= 1) {
	    ivl_lval_t lval;
	    unsigned bit_limit = wid - cur_bit;

	    lval = ivl_stmt_lval(net, lidx-1);

	    if (bit_limit > ivl_lval_width(lval))
		  bit_limit = ivl_lval_width(lval);

	    get_vec_from_lval_slice(lval, slices+lidx-1, bit_limit);
	    if (cur_bit > 0) {
		  fprintf(vvp_out, "    %%concat/vec4;\n");
	    }

	    cur_bit += bit_limit;
      }

}

static void put_vec_to_ret_slice(ivl_signal_t sig, struct vec_slice_info*slice,
				 unsigned wid)
{
      int part_off_idx;

	/* If the slice of the l-value is a BOOL variable, then cast
	   the data to a BOOL vector so that the stores can be valid. */
      if (ivl_signal_data_type(sig) == IVL_VT_BOOL) {
	    fprintf(vvp_out, "    %%cast2;\n");
      }

      switch (slice->type) {
	  default:
	    fprintf(vvp_out, " ; XXXX slice->type=%d\n", slice->type);
	    assert(0);
	    break;

	  case SLICE_SIMPLE_VECTOR:
	    assert(slice->u_.simple_vector.use_word == 0);
	    fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", wid);
	    break;

	  case SLICE_PART_SELECT_STATIC:
	    part_off_idx = allocate_word();
	    fprintf(vvp_out, "    %%ix/load %d, %lu, 0;\n",
		    part_off_idx, slice->u_.part_select_static.part_off);
	    fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
	    fprintf(vvp_out, "    %%ret/vec4 0, %d, %u;\n", part_off_idx, wid);
	    clr_word(part_off_idx);
	    break;

	  case SLICE_PART_SELECT_DYNAMIC:
	    fprintf(vvp_out, "    %%flag_mov 4, %u;\n",
		    slice->u_.part_select_dynamic.x_flag);
	    if (slice->dynamic_carrier_reg) {
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  slice->carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
			  slice->u_.part_select_dynamic.word_idx_reg,
			  slice->dynamic_carrier_reg);
		  fprintf(vvp_out, "    %%ret/vec4/v 0, %d;\n",
			  slice->u_.part_select_dynamic.word_idx_reg);
	    } else if (slice->carrier_wid) {
		  fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64 ", 0, 32; carrier offset\n",
			  slice->carrier_off);
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  slice->carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/b %d;\n",
			  slice->u_.part_select_dynamic.word_idx_reg);
		  fprintf(vvp_out, "    %%ret/vec4/v 0, %d;\n",
			  slice->u_.part_select_dynamic.word_idx_reg);
	    } else {
		  fprintf(vvp_out, "    %%ret/vec4 0, %d, %u;\n",
			  slice->u_.part_select_dynamic.word_idx_reg, wid);
	    }
	    clr_word(slice->u_.part_select_dynamic.word_idx_reg);
	    if (slice->dynamic_carrier_reg)
		  clr_word(slice->dynamic_carrier_reg);
	    clr_flag(slice->u_.part_select_dynamic.x_flag);
	    break;

      }
}

static void put_vec_to_signal_part(ivl_signal_t sig, int part_off_idx,
				   unsigned wid)
{
      if (ivl_signal_type(sig) == IVL_SIT_UWIRE)
	    fprintf(vvp_out, "    %%force/vec4/off v%p_0, %d;\n",
		    sig, part_off_idx);
      else
	    fprintf(vvp_out, "    %%store/vec4 v%p_0, %d, %u;\n",
		    sig, part_off_idx, wid);
}

static void put_vec_to_lval_slice(ivl_lval_t lval, struct vec_slice_info*slice,
				  unsigned wid)
{
	//unsigned skip_set = transient_id++;
      ivl_signal_t sig = ivl_lval_sig(lval);
      int part_off_idx;


	/* Special Case: If the l-value signal is named after its scope,
	   and the scope is a function, then this is an assign to a return
	   value and should be handled differently. */
      if (signal_is_return_value(sig)) {
	    put_vec_to_ret_slice(sig, slice, wid);
	    return;
      }

	/* If the slice of the l-value is a BOOL variable, then cast
	   the data to a BOOL vector so that the stores can be valid. */
      if (ivl_signal_data_type(sig) == IVL_VT_BOOL) {
	    fprintf(vvp_out, "    %%cast2;\n");
      }

      switch (slice->type) {
	  default:
	    fprintf(vvp_out, " ; XXXX slice->type=%d\n", slice->type);
	    assert(0);
	    break;

	  case SLICE_SIMPLE_VECTOR:
	    fprintf(vvp_out, "    %%store/vec4 v%p_%lu, 0, %u;\n",
		    sig, slice->u_.simple_vector.use_word, wid);
	    break;

	  case SLICE_PART_SELECT_STATIC:
	    part_off_idx = allocate_word();
	    fprintf(vvp_out, "    %%ix/load %d, %lu, 0;\n",
		    part_off_idx, slice->u_.part_select_static.part_off);
	    fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
	    put_vec_to_signal_part(sig, part_off_idx, wid);
	    clr_word(part_off_idx);
	    break;

	  case SLICE_PART_SELECT_DYNAMIC:
	    fprintf(vvp_out, "    %%flag_mov 4, %u;\n",
		    slice->u_.part_select_dynamic.x_flag);
	    if (slice->dynamic_carrier_reg) {
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  slice->carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
			  slice->u_.part_select_dynamic.word_idx_reg,
			  slice->dynamic_carrier_reg);
		  if (ivl_signal_type(sig) == IVL_SIT_UWIRE)
			fprintf(vvp_out, "    %%force/vec4/off v%p_0, %d;\n", sig,
				slice->u_.part_select_dynamic.word_idx_reg);
		  else
			fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n", sig,
				slice->u_.part_select_dynamic.word_idx_reg);
	    } else if (slice->carrier_wid) {
		  fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64 ", 0, 32; carrier offset\n",
			  slice->carrier_off);
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  slice->carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/b %d;\n",
			  slice->u_.part_select_dynamic.word_idx_reg);
		  if (ivl_signal_type(sig) == IVL_SIT_UWIRE)
			fprintf(vvp_out, "    %%force/vec4/off v%p_0, %d;\n", sig,
				slice->u_.part_select_dynamic.word_idx_reg);
		  else
			fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n", sig,
				slice->u_.part_select_dynamic.word_idx_reg);
	    } else {
		  put_vec_to_signal_part(sig,
			slice->u_.part_select_dynamic.word_idx_reg, wid);
	    }
	    clr_word(slice->u_.part_select_dynamic.word_idx_reg);
	    if (slice->dynamic_carrier_reg)
		  clr_word(slice->dynamic_carrier_reg);
	    clr_flag(slice->u_.part_select_dynamic.x_flag);
	    break;

	  case SLICE_MEMORY_WORD_STATIC:
	    if (slice->u_.memory_word_static.use_word < ivl_signal_array_count(sig)) {
		  int word_idx = allocate_word();
		  int off_idx = slice->u_.memory_word_static.part_off_reg;
		  fprintf(vvp_out,"    %%ix/load %d, %lu, 0;\n", word_idx, slice->u_.memory_word_static.use_word);
		  note_array_signal_use(sig);
		    /* Partial slice: store back AT the part offset — the runtime
		       set_word(adr, off, val) read-modify-writes the word (a
		       narrow in-bounds value is left alone by resize_rval_vec).
		       The old code always stored at offset 0. */
		  if (!off_idx && slice->u_.memory_word_static.part_wid
		      && slice->u_.memory_word_static.part_off) {
			off_idx = allocate_word();
			fprintf(vvp_out,"    %%ix/load %d, %lu, 0;\n",
				off_idx, slice->u_.memory_word_static.part_off);
		  }
		  if (slice->u_.memory_word_static.part_x_flag)
			fprintf(vvp_out, "    %%flag_mov 4, %u;\n",
				slice->u_.memory_word_static.part_x_flag);
		  else
			fprintf(vvp_out,"    %%flag_set/imm 4, 0;\n");
		  if (slice->dynamic_carrier_reg && off_idx) {
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
				slice->carrier_wid);
			fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n", off_idx,
				slice->dynamic_carrier_reg);
		  } else if (slice->carrier_wid && off_idx) {
			fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64 ", 0, 32; carrier offset\n",
				slice->carrier_off);
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
				slice->carrier_wid);
			fprintf(vvp_out, "    %%clip/vec4/b %d;\n", off_idx);
		  }
		  fprintf(vvp_out,"    %%store/vec4a v%p, %d, %d;\n", sig,
			  word_idx, off_idx);
		  clr_word(word_idx);
		  if (off_idx) clr_word(off_idx);
		  if (slice->u_.memory_word_static.part_x_flag)
			clr_flag(slice->u_.memory_word_static.part_x_flag);
		  if (slice->dynamic_carrier_reg)
			clr_word(slice->dynamic_carrier_reg);
	    } else {
		  fprintf(vvp_out," ; Skip this slice write to v%p [%lu]\n", sig, slice->u_.memory_word_static.use_word);
		  fprintf(vvp_out,"    %%pop/vec4 1;\n");
	    }
	    break;

	  case SLICE_MEMORY_WORD_DYNAMIC: {
	    int off_idx = slice->u_.memory_word_dynamic.part_off_reg;
	    note_array_signal_use(sig);
	    if (!off_idx && slice->u_.memory_word_dynamic.part_wid
		&& slice->u_.memory_word_dynamic.part_off) {
		  off_idx = allocate_word();
		  fprintf(vvp_out,"    %%ix/load %d, %lu, 0;\n",
			  off_idx, slice->u_.memory_word_dynamic.part_off);
	    }
	    fprintf(vvp_out, "    %%flag_mov 4, %u;\n",
		    slice->u_.memory_word_dynamic.x_flag);
	    if (slice->u_.memory_word_dynamic.part_x_flag)
		  fprintf(vvp_out, "    %%flag_or 4, %u;\n",
			  slice->u_.memory_word_dynamic.part_x_flag);
	    if (slice->dynamic_carrier_reg && off_idx) {
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  slice->carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n", off_idx,
			  slice->dynamic_carrier_reg);
	    } else if (slice->carrier_wid && off_idx) {
		  fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64 ", 0, 32; carrier offset\n",
			  slice->carrier_off);
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  slice->carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/b %d;\n", off_idx);
	    }
	    fprintf(vvp_out, "    %%store/vec4a v%p, %d, %d;\n", sig,
		    slice->u_.memory_word_dynamic.word_idx_reg, off_idx);
	    clr_word(slice->u_.memory_word_dynamic.word_idx_reg);
	    if (off_idx) clr_word(off_idx);
	    clr_flag(slice->u_.memory_word_dynamic.x_flag);
	    if (slice->u_.memory_word_dynamic.part_x_flag)
		  clr_flag(slice->u_.memory_word_dynamic.part_x_flag);
	    if (slice->dynamic_carrier_reg)
		  clr_word(slice->dynamic_carrier_reg);
	    break;
	  }

      }
}

static void put_vec_to_lval(ivl_statement_t net, struct vec_slice_info*slices)
{
      unsigned lidx;
      unsigned cur_bit;

      unsigned wid = ivl_stmt_lwidth(net);

      cur_bit = 0;
      for (lidx = 0 ; lidx < ivl_stmt_lvals(net) ; lidx += 1) {
	    ivl_lval_t lval;
	    unsigned bit_limit = wid - cur_bit;

	    lval = ivl_stmt_lval(net, lidx);

	    if (bit_limit > ivl_lval_width(lval))
		  bit_limit = ivl_lval_width(lval);

	    if (lidx+1 < ivl_stmt_lvals(net))
		  fprintf(vvp_out, "    %%split/vec4 %u;\n", bit_limit);

	    put_vec_to_lval_slice(lval, slices+lidx, bit_limit);

	    cur_bit += bit_limit;
      }
}

/* Queue/dynamic-array assignment creates a value of the destination type
 * (IEEE 1800-2017/2023 7.6), and a bounded queue discards excess source
 * elements (7.10.5). Different runtime kinds and bounded same-kind queues
 * therefore need a destination-typed temporary before an object-backed store.
 * The documented ordinary-assignment bit/logic extension also comes through
 * this path; its 2-state destination conversion maps X/Z to zero as required
 * by 6.11.2. FORCE is used by an explicit cast, whose 6.24.1 temporary must be
 * fresh even when source and destination have the same unbounded kind. */
static ivl_type_t container_materialization_target_element_(
      ivl_type_t source_type, ivl_type_t target_type, int force)
{
      ivl_variable_type_t source_kind;
      ivl_variable_type_t target_kind;
      ivl_type_t target_element;
      int bounded_target;

      if (!source_type || !target_type)
            return 0;

      source_kind = ivl_type_base(source_type);
      target_kind = ivl_type_base(target_type);
      if ((source_kind != IVL_VT_DARRAY && source_kind != IVL_VT_QUEUE)
          || (target_kind != IVL_VT_DARRAY && target_kind != IVL_VT_QUEUE))
            return 0;

      /* Associative-array compatibility queues have a different key/value
       * representation and are not positional queue/darray values. */
      if ((source_kind == IVL_VT_QUEUE
           && ivl_type_queue_assoc_compat(source_type))
          || (target_kind == IVL_VT_QUEUE
              && ivl_type_queue_assoc_compat(target_type)))
            return 0;

      bounded_target = target_kind == IVL_VT_QUEUE
          && ivl_type_queue_max_size(target_type) != 0;
      if (!force && source_kind == target_kind && !bounded_target)
            return 0;

      target_element = ivl_type_element(target_type);
      if (!target_element)
            return 0;

      return target_element;
}

static int draw_convert_container_value_for_target_(ivl_type_t source_type,
                                                     ivl_type_t target_type,
                                                     int force)
{
      ivl_type_t target_element = container_materialization_target_element_(
            source_type, target_type, force);
      char element_text[32];

      if (!target_element)
            return 0;

      stream_elem_type_text(target_element, element_text,
                            sizeof element_text);
      if (ivl_type_base(target_type) == IVL_VT_DARRAY) {
            fprintf(vvp_out, "    %%queue/to/darray \"%s\";"
                    " destination-typed container copy\n", element_text);
      } else {
            fprintf(vvp_out, "    %%container/to/queue \"%s\", %" PRIu64 ";"
                    " destination-typed container copy\n",
                    element_text, queue_type_max_count_(target_type));
      }

      /* A property or nested container has no signal declaration from which
       * VVP can recover an unpacked-struct element prototype. Install the
       * destination declaration's prototype on the materialized value. */
      if (ivl_type_base(target_element) == IVL_VT_NO_TYPE
          && ivl_type_properties(target_element) > 0) {
            ensure_class_type_emitted(target_element);
            fprintf(vvp_out,
                    "    %%new/cobj C%p; destination element prototype\n",
                    target_element);
            fprintf(vvp_out, "    %%dar/elem/proto;\n");
      }

      return 1;
}

int draw_convert_container_value_for_target(ivl_type_t source_type,
                                             ivl_type_t target_type)
{
      return draw_convert_container_value_for_target_(source_type,
                                                       target_type, 0);
}

int draw_eval_container_value_for_target(ivl_expr_t expr,
                                          ivl_type_t target_type)
{
      ivl_type_t source_type = receiver_container_type_(expr);
      int errors;

      if (!container_materialization_target_element_(source_type,
                                                     target_type, 0))
            return -1;

      errors = draw_eval_object(expr);
      assert(draw_convert_container_value_for_target_(source_type,
                                                      target_type, 0));
      return errors;
}

int draw_eval_explicit_container_cast(ivl_expr_t marker)
{
      ivl_expr_t source;
      ivl_type_t source_type;
      ivl_type_t target_type;
      int errors;

      if (!marker || ivl_expr_parms(marker) != 1) {
            fprintf(stderr, "%s:%u: internal error: malformed explicit "
                    "container-cast marker\n",
                    marker ? ivl_expr_file(marker) : "<unknown>",
                    marker ? ivl_expr_lineno(marker) : 0);
            fprintf(vvp_out,
                    "    %%null; ; malformed explicit container cast\n");
            return 1;
      }

      source = ivl_expr_parm(marker, 0);
      source_type = receiver_container_type_(source);
      target_type = ivl_expr_net_type(marker);

      /* A conditional can legally select between queue and dynamic-array
       * arms with equivalent elements. The frontend validates every arm
       * before creating this marker, but the target's generic provenance
       * helper deliberately reports no single kind for a mixed-kind ternary.
       * Both materialization opcodes accept either positional runtime kind,
       * so use the already-validated target as the force-copy descriptor. */
      if (!source_type && ivl_expr_type(source) == IVL_EX_TERNARY)
            source_type = target_type;
      if (!container_materialization_target_element_(source_type,
                                                     target_type, 1)) {
            fprintf(stderr, "%s:%u: internal error: explicit container cast "
                    "lost its positional source or target type\n",
                    ivl_expr_file(marker), ivl_expr_lineno(marker));
            fprintf(vvp_out,
                    "    %%null; ; invalid explicit container cast\n");
            return 1;
      }

      errors = draw_eval_object(source);
      assert(draw_convert_container_value_for_target_(source_type,
                                                      target_type, 1));
      return errors;
}

void emit_append_object_collection(ivl_type_t target_element_type)
{
      ivl_type_t inner_element;
      char element_text[32];
      int has_struct_prototype;

      if (!target_element_type
          || (ivl_type_base(target_element_type) != IVL_VT_DARRAY
              && ivl_type_base(target_element_type) != IVL_VT_QUEUE)
          || (ivl_type_base(target_element_type) == IVL_VT_QUEUE
              && ivl_type_queue_assoc_compat(target_element_type))) {
            fprintf(vvp_out, "    %%append/qo/obj;\n");
            return;
      }

      inner_element = ivl_type_element(target_element_type);
      if (!inner_element) {
            fprintf(vvp_out, "    %%append/qo/obj;\n");
            return;
      }

      stream_elem_type_text(inner_element, element_text,
                            sizeof element_text);
      has_struct_prototype = ivl_type_base(inner_element) == IVL_VT_NO_TYPE
          && ivl_type_properties(inner_element) > 0;
      if (has_struct_prototype)
            ensure_class_type_emitted(inner_element);

      if (ivl_type_base(target_element_type) == IVL_VT_DARRAY) {
            if (has_struct_prototype)
                  fprintf(vvp_out,
                          "    %%append/qo/obj/darray/proto \"%s\", C%p;\n",
                          element_text, inner_element);
            else
                  fprintf(vvp_out,
                          "    %%append/qo/obj/darray \"%s\";\n",
                          element_text);
      } else if (has_struct_prototype) {
            fprintf(vvp_out,
                          "    %%append/qo/obj/queue/proto \"%s\", %" PRIu64 ", C%p;\n",
                    element_text, queue_type_max_count_(target_element_type),
                    inner_element);
      } else {
            fprintf(vvp_out,
                    "    %%append/qo/obj/queue \"%s\", %" PRIu64 ";\n",
                    element_text,
                    queue_type_max_count_(target_element_type));
      }
}

/* Evaluate a value that is about to become an object-backed container
 * element. RUNTIME_COPIES says the receiving opcode applies
 * value_copy_element(); property stores do not, so selected container values
 * are copied by draw_eval_object_value_copy(). Neither runtime can see the
 * declared type of an inner bounded queue, so that one case needs a private
 * pre-store copy that can be shortened to the declared maximum. Preserve word
 * 3 and flag 4: callers commonly keep the destination element index there
 * while evaluating the RHS. */
static int draw_eval_nested_object_value_(ivl_expr_t expr,
                                          ivl_type_t element_type,
                                          int runtime_copies)
{
      int errors = draw_eval_container_value_for_target(expr, element_type);
      uint64_t max_size;

      if (errors >= 0)
            return errors;

      errors = runtime_copies
            ? draw_eval_object(expr)
            : draw_eval_object_value_copy(expr, element_type);

      if (!element_type
          || (ivl_type_base(element_type) != IVL_VT_QUEUE
              && ivl_type_base(element_type) != IVL_VT_DARRAY))
            return errors;

      if (ivl_type_base(element_type) != IVL_VT_QUEUE
          || ivl_type_queue_assoc_compat(element_type))
            return errors;

      max_size = ivl_type_queue_max_size(element_type);
      if (max_size == 0)
            return errors;

      /* A runtime store will make the assignment copy after this helper. Make
       * one private copy first only because trimming must not mutate its RHS.
       * A property store already received either a copied alias or a fresh
       * value from draw_eval_object_value_copy(), so another copy here would
       * only amplify memory use. */
      if (runtime_copies) {
            fprintf(vvp_out,
                    "    %%dup/obj; bounded nested queue pre-trim copy\n");
            fprintf(vvp_out,
                    "    %%pop/obj 1, 1; discard bounded queue source\n");
      }

      fprintf(vvp_out, "    %%queue/trim/o %" PRIu64
              "; destination-bound nested queue copy\n", max_size);
      return errors;
}

/* Materialize a bare fixed unpacked-array expression as the queue object
 * required by a queue-valued class property. draw_eval_object() normally
 * turns IVL_EX_ARRAY into a dynamic array because most object contexts do
 * not carry a queue destination type. Property assignment does, including
 * its declared maximum, so use the queue form of %load/arr/dar here. */
static int draw_fixed_uarray_queue_object_(ivl_expr_t expr,
                                           ivl_type_t queue_type)
{
      ivl_signal_t sig = ivl_expr_signal(expr);
      uint64_t queue_max_size;
      unsigned marshal_max;
      unsigned kind;

      assert(ivl_expr_type(expr) == IVL_EX_ARRAY);
      assert(ivl_type_base(queue_type) == IVL_VT_QUEUE);

      if (!sig || ivl_signal_dimensions(sig) != 1) {
            fprintf(stderr, "%s:%u: sorry: a fixed unpacked array assigned "
                    "to a queue property must be one-dimensional\n",
                    ivl_expr_file(expr), ivl_expr_lineno(expr));
            vvp_errors += 1;
            fprintf(vvp_out, "    %%null; ; invalid fixed-array queue source\n");
            return 1;
      }

      if (!uarray_container_kind_(sig, &kind, ivl_expr_file(expr),
                                  ivl_expr_lineno(expr))) {
            fprintf(vvp_out, "    %%null; ; unsupported fixed-array queue source\n");
            return 1;
      }

      if (ivl_signal_array_addr_swapped(sig))
            kind |= VVP_ARRDAR_DESC;
      kind |= VVP_ARRDAR_QUEUE;

      queue_max_size = ivl_type_queue_max_size(queue_type);
      marshal_max = queue_max_size > UINT32_MAX
            ? 0 : (unsigned)queue_max_size;
      note_array_signal_use(sig);
      fprintf(vvp_out, "    %%load/arr/dar v%p, %u, %u;"
              " fixed array to queue property\n",
              sig, kind, marshal_max);
      fprintf(vvp_out, "    %%container/layout/q %" PRIu64
              "; exact fixed-array queue layout\n", queue_max_size);
      return 0;
}

/* Container constructor code shared with %aa/viv and the "@N" form of
 * %qdar/loadlv/o. This helper is intentionally limited to queue/associative
 * children: a dynamic array cannot be usefully auto-created without its
 * source-visible size. AA_VIV_DARRAY_NIL is a separate %aa/viv protocol code:
 * it inserts a missing associative element with its nil dynamic-array default
 * without manufacturing a queue. */
#define AA_VIV_DARRAY_NIL 16
#define AA_VIV_FIXED 17
static unsigned nested_queue_spec_(ivl_type_t container_type)
{
      ivl_type_t element_type = ivl_type_element(container_type);
      unsigned kind = 3;

      if (element_type && !type_is_fixed_uarray_property_(element_type)) {
	    switch (ivl_type_base(element_type)) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:  kind = 0; break;
		case IVL_VT_REAL:   kind = 1; break;
		case IVL_VT_STRING: kind = 2; break;
		default:            kind = 3; break;
	    }
      }
      if (ivl_type_queue_assoc_compat(container_type))
	    kind += 4;
      return kind;
}

/* A null receiver suppresses the access, not evaluation of its index. */
static void discard_nested_container_index_(ivl_expr_t index,
					     ivl_type_t container_type)
{
      if (ivl_type_base(container_type) == IVL_VT_QUEUE
	  && ivl_type_queue_assoc_compat(container_type)) {
	    const char*key_kind = draw_eval_assoc_key_(index, 0);
	    if (strcmp(key_kind, "str") == 0)
		  fprintf(vvp_out, "    %%pop/str 1; discarded nested key\n");
	    else if (strcmp(key_kind, "obj") == 0)
		  fprintf(vvp_out, "    %%pop/obj 1, 0; discarded nested key\n");
	    else
		  fprintf(vvp_out, "    %%pop/vec4 1; discarded nested key\n");
      } else {
	    int index_word = allocate_word();
	    draw_eval_expr_into_integer(index, index_word);
	    clr_word(index_word);
      }
}

static ivl_type_t draw_lval_expr(ivl_lval_t lval)
{
      static int warned_invalid_prop_index = 0;
      ivl_lval_t lval_nest = ivl_lval_nest(lval);
      ivl_signal_t lval_sig = ivl_lval_sig(lval);
      unsigned lab_null = local_count++;
      unsigned lab_out = local_count++;

      if (lval_sig) {
	    ivl_expr_t word_ex = ivl_lval_idx(lval);
	    ivl_type_t sig_type = ivl_signal_net_type(lval_sig);

	      /* A fixed unpacked prefix around a queue, dynamic array, or
		 associative-array leaf is stored as an object array.  The signal
		 node's word selects that fixed slot; a separate outer l-value node
		 carries any index/key inside the selected container.  Loading the
		 scalar object label here drops the fixed word and makes the caller
		 reinterpret it as the inner key. */
	    if (word_ex && sig_type
		&& ivl_signal_dimensions(lval_sig) > 0
		&& (ivl_type_base(sig_type) == IVL_VT_QUEUE
		    || ivl_type_base(sig_type) == IVL_VT_DARRAY)) {
		  int slot_word = allocate_word();
		  draw_eval_expr_into_integer(word_ex, slot_word);
		  note_array_signal_use(lval_sig);
		  fprintf(vvp_out,
			  "    %%load/obja v%p, %d; fixed-array container slot\n",
			  lval_sig, slot_word);

		    /* Queue and associative-array variables default to an empty
		       container. Compact fixed object-array storage starts each
		       word nil, so materialize that default lazily on an l-value
		       access and retain one alias as the receiver. Restore the
		       address-validity flag before %store/obja: an X/Z or OOB slot
		       may still evaluate its inner key and RHS, but the runtime
		       setter must skip the write-back. Dynamic arrays deliberately
		       remain nil until explicitly allocated. */
		  if (ivl_type_base(sig_type) == IVL_VT_QUEUE) {
			int slot_flag = allocate_flag();
			fprintf(vvp_out, "    %%flag_mov %d, 4; fixed-slot validity\n",
				slot_flag);
			fprintf(vvp_out, "    %%test_nul/obj;\n");
			fprintf(vvp_out, "    %%jmp/0 T_%u.%u, 4; fixed-slot container exists\n",
				thread_count, lab_out);
			fprintf(vvp_out, "    %%pop/obj 1, 0; replace nil fixed-slot container\n");
			fprintf(vvp_out, "    %%new/queue \"@%u\"; fixed-slot container default\n",
				nested_queue_spec_(sig_type));
			fprintf(vvp_out, "    %%flag_mov 4, %d; restore fixed-slot validity\n",
				slot_flag);
			fprintf(vvp_out, "    %%store/obja v%p, %d; initialize fixed-slot container\n",
				lval_sig, slot_word);
			fprintf(vvp_out,
				"    %%load/obja v%p, %d; reload destination-bound fixed-slot receiver\n",
				lval_sig, slot_word);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			clr_flag(slot_flag);
		  }
		  clr_word(slot_word);
		  return sig_type;
	    }

	      /* A static unpacked array of class handles (`c arr[N]`) reports
		 its net_type as the ELEMENT class directly (no array wrapper),
		 while still carrying array dimensions. Load the indexed
		 element with %load/obja; the element type IS sig_type. Without
		 this the class-index block below (which expects an array
		 wrapper with a non-null ivl_type_element) fell through to the
		 scalar %load/obj fallback, dropping the index. */
	    if (word_ex && sig_type
		&& ivl_type_base(sig_type) == IVL_VT_CLASS
		&& ivl_signal_dimensions(lval_sig) > 0) {
		  draw_eval_expr_into_integer(word_ex, 3);
		  fprintf(vvp_out, "    %%load/obja v%p, 3;\n", lval_sig);
		  return sig_type;
	    }

	      /* A static unpacked array of an object-backed UNPACKED struct
		 (`struct{...} arr[N]`) reports the element struct directly as
		 its net_type (base IVL_VT_NO_TYPE with properties) while still
		 carrying array dimensions, like the class-array case above.
		 Load the indexed element with %load/obja so a member write
		 `arr[i].field = ...` addresses the right element; the runtime
		 lazily default-constructs a nil element on load. Without this
		 the scalar %load/obj fallback loaded the whole array-of-objects
		 as a single (nil) handle and dropped every member write. */
	    if (word_ex && sig_type
		&& ivl_type_base(sig_type) == IVL_VT_NO_TYPE
		&& ivl_type_properties(sig_type) > 0
		&& ivl_signal_dimensions(lval_sig) > 0) {
		  draw_eval_expr_into_integer(word_ex, 3);
		  fprintf(vvp_out, "    %%load/obja v%p, 3;\n", lval_sig);
		  return sig_type;
	    }

	    if (word_ex && sig_type) {
		  ivl_type_t element_type = ivl_type_element(sig_type);
		    /* IEEE 1800-2017/2023 §7.8.7 allocates a missing key used as
		       a nested fixed-array assignment target. */
		  if (ivl_type_base(sig_type) == IVL_VT_QUEUE
		      && ivl_type_queue_assoc_compat(sig_type)
		      && type_is_fixed_uarray_property_(element_type)) {
			const char*key_kind = draw_eval_assoc_key_(word_ex, 0);
			fprintf(vvp_out, "    %%aa/viv/sig/%s v%p_0, %u;\n",
				key_kind, lval_sig, AA_VIV_FIXED);
			return element_type;
		  }
		    /* The element is object-backed when it is a class handle or
		       an object-backed unpacked struct (base IVL_VT_NO_TYPE with
		       properties). A dynamic array / queue of such an element
		       stores each entry as an object, so a member write
		       `arr[i].field = ...` must load the addressed ELEMENT as an
		       object (not the whole array) and return the element type so
		       the property store selects the right opcode. Without the
		       NO_TYPE case a darray/queue of unpacked structs fell through
		       to the whole-array %load/obj below and dropped the index. */
		  int elem_is_object = element_type &&
			(ivl_type_base(element_type) == IVL_VT_CLASS
			 || (ivl_type_base(element_type) == IVL_VT_NO_TYPE
			     && ivl_type_properties(element_type) > 0));
		  if (elem_is_object) {
			  /* An associative array keyed by a class handle (or any
			     assoc key) is an IVL_VT_QUEUE with assoc-compat. Its
			     element is fetched with %aa/load using the real key —
			     NOT %load/dar/obj with the key coerced to an integer,
			     which turned `assoc[classkey].prop = v` into a store
			     against a garbage darray word (the key's null-test
			     flag), so uvm_reg's `m_regs_info[rg].addr = addrs`
			     register-address cache silently vanished. */
			if (ivl_type_base(sig_type) == IVL_VT_QUEUE &&
			    ivl_type_queue_assoc_compat(sig_type)) {
			      const char*key_kind = draw_eval_assoc_key_(word_ex, 0);
			      /* L-value path: get-or-CREATE the element so a
				 member write into a not-yet-present assoc entry
				 (`a[key].field = ...`) is inserted and persists,
				 instead of storing through a discarded default. */
			      fprintf(vvp_out, "    %%aa/loadlv/sig/obj/%s v%p_0;\n",
				      key_kind, lval_sig);
			      return element_type;
			}
			draw_eval_expr_into_integer(word_ex, 3);
			if (ivl_type_base(sig_type) == IVL_VT_DARRAY ||
			    ivl_type_base(sig_type) == IVL_VT_QUEUE) {
			      fprintf(vvp_out, "    %%load/dar/obj v%p_0;\n", lval_sig);
			      return element_type;
			}
			if (ivl_signal_dimensions(lval_sig) > 0) {
			      fprintf(vvp_out, "    %%load/obja v%p, 3;\n", lval_sig);
			      return element_type;
			}
		  }
	    }

	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", lval_sig);
	    return sig_type;
      }

      assert (lval_nest);
      ivl_type_t sub_type = draw_lval_expr(lval_nest);
      ivl_type_t prop_type;
      ivl_type_t element_type;
      ivl_expr_t nested_idx_expr;
      int idx_word = 0;
      int assoc_indexed = 0;
      int queue_indexed = 0;
      int fixed_slot_index = 0;
      int fixed_slot_x_flag = -1;
      int fixed_slot_in_range_flag = -1;
      unsigned lab_bad_slot = 0;
      int prop_idx = ivl_lval_property_idx(lval_nest);

      /* A separate nest node with no property id is a trailing index into
       * the container object produced by the deeper property node.  This is
       * how a fixed-array-of-containers chain keeps the canonical outer slot
       * distinct from an inner queue/map index. */
      if (prop_idx < 0 && ivl_lval_idx(lval_nest) && sub_type
	  && !(ivl_lval_sig(lval_nest)
	       && ivl_signal_dimensions(ivl_lval_sig(lval_nest)) > 0)
	  && (ivl_type_base(sub_type) == IVL_VT_QUEUE
	      || ivl_type_base(sub_type) == IVL_VT_DARRAY)) {
	    ivl_expr_t container_idx = ivl_lval_idx(lval_nest);
	    ivl_type_t selected_type = ivl_type_element(sub_type);

	    fprintf(vvp_out, "    %%test_nul/obj;\n");
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
		    thread_count, lab_null);
	    if (ivl_type_base(sub_type) == IVL_VT_QUEUE
		&& ivl_type_queue_assoc_compat(sub_type)) {
		  if (selected_type
		      && ivl_type_base(selected_type) == IVL_VT_NO_TYPE
		      && ivl_type_properties(selected_type) > 0) {
			/* A member write through an associative array of unpacked
			 * structs must insert a live default value when the key is
			 * absent. String and integral keys live on independent VVP
			 * stacks, so retain two copies across the probe/store/reload
			 * sequence and still evaluate the SV key exactly once. */
			if (expr_is_object_assoc_key_(container_idx)) {
			      fprintf(stderr, "%s:%u: sorry: member assignment through "
				      "an object-keyed associative array of unpacked "
				      "struct values is not supported.\n",
				      ivl_expr_file(container_idx),
				      ivl_expr_lineno(container_idx));
			      vvp_errors += 1;
			      fprintf(vvp_out, "    %%pop/obj 1, 0; unsupported object-keyed struct l-value\n");
			      fprintf(vvp_out, "    %%null;\n");
			} else {
			      const char*key_kind = draw_eval_assoc_key_(container_idx, 0);
			      unsigned lab_make = local_count++;
			      unsigned lab_ready = local_count++;
			      const char*dup_key = strcmp(key_kind, "str") == 0
				    ? "%dup/str" : "%dup/vec4";
			      const char*load_keep = strcmp(key_kind, "str") == 0
				    ? "%aa/loadk/obj/str" : "%aa/loadk/obj/v";
			      const char*pop_keys = strcmp(key_kind, "str") == 0
				    ? "%pop/str 2" : "%pop/vec4 2";

			      fprintf(vvp_out, "    %s;\n", dup_key);
			      fprintf(vvp_out, "    %s; l-value probe\n", load_keep);
			      fprintf(vvp_out, "    %%test_nul/obj;\n");
			      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
				      thread_count, lab_make);
			      fprintf(vvp_out, "    %s;\n", pop_keys);
			      fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
			      fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				      thread_count, lab_ready);
			      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_make);
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			      ensure_class_type_emitted(selected_type);
			      fprintf(vvp_out, "    %%new/cobj C%p; assoc struct l-value default\n",
				      selected_type);
			      fprintf(vvp_out, "    %%aa/store/obj/%s;\n", key_kind);
			      fprintf(vvp_out, "    %%aa/load/obj/%s;\n", key_kind);
			      fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
			      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_ready);
			}
		  } else if (selected_type
			     && (type_is_fixed_uarray_property_(selected_type)
				 || ivl_type_base(selected_type) == IVL_VT_QUEUE
				 || ivl_type_base(selected_type) == IVL_VT_DARRAY)) {
			const char*key_kind = draw_eval_assoc_key_(container_idx, 0);
			unsigned spec = type_is_fixed_uarray_property_(selected_type)
			      ? AA_VIV_FIXED
			      : (ivl_type_base(selected_type) == IVL_VT_DARRAY
				 ? AA_VIV_DARRAY_NIL
				 : nested_queue_spec_(selected_type));
			if (strcmp(key_kind, "obj") == 0)
			      spec += 8;
			fprintf(vvp_out, "    %%aa/viv/o/%s %u;\n",
				key_kind, spec);
		  } else {
			const char*key_kind = draw_eval_assoc_key_(container_idx, 0);
			fprintf(vvp_out, "    %%aa/load/obj/%s;\n", key_kind);
			fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		  }
	    } else {
		  draw_eval_expr_into_integer(container_idx, 3);
		  if (selected_type
		      && ivl_type_base(selected_type) == IVL_VT_QUEUE)
			fprintf(vvp_out, "    %%qdar/loadlv/o \"@%u\";\n",
				nested_queue_spec_(selected_type));
		  else
			fprintf(vvp_out, "    %%load/qo/obj;\n");
	    }
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
	    discard_nested_container_index_(container_idx, sub_type);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    fprintf(vvp_out, "    %%null;\n");
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
	    return selected_type;
      }

      /* A pure-index wrapper immediately outside a fixed-array signal node
       * carries the inner queue/map index.  Its dedicated store helper owns
       * that index, so keep the selected container and its type intact. */
      if (prop_idx < 0 && ivl_lval_idx(lval)
	  && ivl_lval_sig(lval_nest)
	  && ivl_signal_dimensions(ivl_lval_sig(lval_nest)) > 0
	  && sub_type
	  && (ivl_type_base(sub_type) == IVL_VT_QUEUE
	      || ivl_type_base(sub_type) == IVL_VT_DARRAY))
	    return sub_type;

      /* Keep a module associative array's fixed child alive for the
	 fixed-slot store in its enclosing l-value. */
      if (prop_idx < 0 && ivl_lval_idx(lval) && sub_type
	  && type_is_fixed_uarray_property_(sub_type)) {
	    ivl_signal_t assoc_sig = ivl_lval_sig(lval_nest);
	    ivl_type_t assoc_type = assoc_sig
		  ? ivl_signal_net_type(assoc_sig) : 0;
	    if (assoc_type && ivl_type_base(assoc_type) == IVL_VT_QUEUE
		&& ivl_type_queue_assoc_compat(assoc_type))
		  return sub_type;
      }

      if ((sub_type == 0) || (ivl_type_properties(sub_type) <= 0)) {
	    /* Compile-progress fallback: nested receiver is not class-typed,
	       preserve object-stack discipline with a null object. */
	    fprintf(vvp_out, "    %%pop/obj 1, 0; discard malformed nested receiver\n");
	    fprintf(vvp_out, "    %%null;\n");
	    return 0;
      }
      if (prop_idx < 0)
	    return sub_type;

      if ((prop_idx < 0) || (prop_idx >= ivl_type_properties(sub_type))) {
	    if (!warned_invalid_prop_index) {
		  fprintf(stderr, "Warning: invalid class property index %d in nested l-value; "
				  "using null object fallback"
				  " (further similar warnings suppressed)\n", prop_idx);
		  warned_invalid_prop_index = 1;
	    }
	    fprintf(vvp_out, "    %%pop/obj 1, 0; discard invalid-property receiver\n");
	    fprintf(vvp_out, "    %%null; ; invalid-property object fallback\n");
	    return 0;
      }

      prop_type = ivl_type_prop_type(sub_type, prop_idx);
      element_type = ivl_type_element(prop_type);
      nested_idx_expr = ivl_lval_idx(lval_nest);
      if (nested_idx_expr) {
	      /* A DYNAMIC ARRAY property indexes like a queue property:
		 the property slot holds ONE object (the container), so
		 the element index belongs inside the container, not on
		 %prop/obj. Passing it as a slot index made
		 `obj.arr[i].member = v' read the CONTAINER as the
		 receiver -- a silent wrong store for index 0 and a
		 runtime abort (assert idx < array_size_) for index >= 1.
		 %load/qo/obj accepts any vvp_darray receiver, queue or
		 plain dynamic array, so the queue lowering is exactly
		 right here. A fixed-size unpacked array property still
		 takes the slot-index path below, where the index IS a
		 slot index. */
	    if (type_is_fixed_uarray_property_(prop_type)) {
		  /* The wrapper's base kind reflects its queue/map LEAF, but
		   * this index belongs to the fixed property storage itself.
		   * Preserve it as the %prop/obj slot word; only a separate
		   * outer l-value node may index inside the selected leaf. */
		  idx_word = allocate_word();
		  draw_fixed_uarray_slot_index_(nested_idx_expr, prop_type,
						idx_word, &fixed_slot_x_flag,
						&fixed_slot_in_range_flag);
		  fixed_slot_index = 1;
		  lab_bad_slot = local_count++;
	    } else if (prop_is_numeric_queue_index_(prop_type, nested_idx_expr)
		|| (prop_type
		    && ivl_type_base(prop_type) == IVL_VT_DARRAY
		    && expr_is_numeric_container_index_(nested_idx_expr))) {
		  queue_indexed = 1;
	    } else if (prop_type
	               && ivl_type_base(prop_type) == IVL_VT_QUEUE
	               && ivl_type_queue_assoc_compat(prop_type)) {
		  assoc_indexed = 1;
	    } else {
		  idx_word = allocate_word();
		  draw_eval_expr_into_integer(nested_idx_expr, idx_word);
	    }
      }

      fprintf(vvp_out, "    %%test_nul/obj;\n");
      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
      if (fixed_slot_index) {
	    fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; fixed property slot is X/Z\n",
		    thread_count, lab_bad_slot, fixed_slot_x_flag);
	    if (fixed_slot_in_range_flag >= 0)
		  fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; fixed property slot is OOB\n",
			  thread_count, lab_bad_slot, fixed_slot_in_range_flag);
      }
      if (queue_indexed) {
	    draw_eval_expr_into_integer(nested_idx_expr, 3);
	    fprintf(vvp_out, "    %%prop/obj %d, 0; Load queue property %s\n",
	            prop_idx, ivl_type_prop_name(sub_type, prop_idx));
	    fprintf(vvp_out, "    %%load/qo/obj;\n");
	    fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
      } else if (assoc_indexed) {
            const char*key_kind;
	    fprintf(vvp_out, "    %%prop/obj %d, 0; Load assoc property %s\n",
	            prop_idx, ivl_type_prop_name(sub_type, prop_idx));
            key_kind = draw_eval_assoc_key_(nested_idx_expr, 0);
	    if (type_is_fixed_uarray_property_(element_type)) {
		  unsigned spec = AA_VIV_FIXED;
		  if (strcmp(key_kind, "obj") == 0)
			  spec += 8;
		  fprintf(vvp_out, "    %%aa/viv/o/%s %u;\n",
			  key_kind, spec);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
	    } else {
		  fprintf(vvp_out, "    %%aa/load/obj/%s;\n", key_kind);
		  fprintf(vvp_out, "    %%pop/obj 2, 1;\n");
	    }
      } else if (idx_word) {
	    fprintf(vvp_out, "    %%prop/obj %d, %d; Load property %s\n", prop_idx,
	            idx_word, ivl_type_prop_name(sub_type, prop_idx));
	    fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
      } else {
	    fprintf(vvp_out, "    %%prop/obj %d, 0; Load property %s\n", prop_idx,
	            ivl_type_prop_name(sub_type, prop_idx));
	    fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
      }
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      if (fixed_slot_index) {
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_bad_slot);
	    fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
		    "\"fixed unpacked-array property index is undefined or out of range; "
		    "write was ignored\" {0 0 0 0};\n",
		    ivl_file_table_index(ivl_expr_file(nested_idx_expr)),
		    ivl_expr_lineno(nested_idx_expr));
	    fprintf(vvp_out, "    %%pop/obj 1, 0; invalid fixed property slot\n");
	    fprintf(vvp_out, "    %%null;\n");
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      }
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      fprintf(vvp_out, "    %%null;\n");
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);

      if (idx_word) clr_word(idx_word);
      if (fixed_slot_x_flag >= 0) clr_flag(fixed_slot_x_flag);
      if (fixed_slot_in_range_flag >= 0) clr_flag(fixed_slot_in_range_flag);

      if (nested_idx_expr && element_type)
	    return element_type;

      return prop_type;
}

/* Value-kind tags shared with vvp_lvalue_ref::value_kind_t. Keep the text
 * target independent of the C++ header while retaining one compact opcode
 * family for all four VVP value stacks. */
static unsigned mailbox_ref_value_kind_(ivl_type_t type)
{
      switch (type ? ivl_type_base(type) : IVL_VT_LOGIC) {
          case IVL_VT_REAL:   return 1;
          case IVL_VT_STRING: return 2;
          case IVL_VT_CLASS:
          case IVL_VT_DARRAY:
          case IVL_VT_QUEUE:
          case IVL_VT_NO_TYPE:
            return 3;
          default:
            return 0;
      }
}

static unsigned mailbox_ref_storage_width_(ivl_type_t type,
                                            unsigned fallback)
{
      if (type) {
            long width = ivl_type_packed_width(type);
            if (width > 0 && (uint64_t)width <= UINT32_MAX)
                  return (unsigned)width;
      }
      return fallback ? fallback : 1;
}

static void mailbox_ref_apply_part_(ivl_lval_t lval)
{
      ivl_expr_t part = ivl_lval_part_off(lval);
      if (!part) return;
      draw_eval_expr_into_integer(part, 3);
      fprintf(vvp_out, "    %%ref/part; capture packed output selection\n");
}

static ivl_signal_t mailbox_ref_base_signal_(ivl_lval_t lval)
{
      for (ivl_lval_t cur = lval; cur; cur = ivl_lval_nest(cur))
            if (ivl_lval_sig(cur)) return ivl_lval_sig(cur);
      return 0;
}

/*
 * Capture an arbitrary mailbox ref-output target before the mailbox access.
 * The returned object names physical storage, not merely the expression that
 * reached it, so a blocking get/peek cannot be retargeted by later changes to
 * a receiver handle or index expression.
 */
int draw_capture_lval_ref(ivl_lval_t lval)
{
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_expr_t index = ivl_lval_idx(lval);
      int property = ivl_lval_property_idx(lval);

      if (ivl_lval_is_array_slice(lval) || ivl_lval_is_queue_slice(lval)) {
            ivl_signal_t base = mailbox_ref_base_signal_(lval);
            fprintf(stderr, "%s:%u: sorry: mailbox ref-output array and queue "
                    "slices are not supported.\n",
                    base ? ivl_signal_file(base) : "<unknown>",
                    base ? ivl_signal_lineno(base) : 0);
            vvp_errors += 1;
            fprintf(vvp_out, "    %%null; unsupported mailbox output slice\n");
            return 1;
      }

        /* A property target names storage INSIDE the object the signal
         * holds, not the handle signal itself, so it belongs to the
         * property path below whether the owner arrives through a nested
         * l-value or directly through this signal. Letting it fall into the
         * signal path captured the class handle instead: an indexed
         * property (`h.values[0]') reported "unsupported indexed mailbox
         * ref-output signal shape", and an unindexed one (`h.value')
         * silently emitted a plain capture of the handle and then aborted
         * vvp at run time with "vvp_fun_signal_object_sa: recv_vec4 not
         * implemented" when the retrieved value was written back. */
      if (sig && property < 0) {
            ivl_type_t sig_type = ivl_signal_net_type(sig);

            if (index && sig_type
                && (ivl_type_base(sig_type) == IVL_VT_QUEUE
                    || ivl_type_base(sig_type) == IVL_VT_DARRAY)) {
                  if (ivl_type_base(sig_type) == IVL_VT_QUEUE
                      && ivl_type_queue_assoc_compat(sig_type)) {
                        ivl_type_t element = ivl_type_element(sig_type);
                        unsigned kind = mailbox_ref_value_kind_(element);
                        unsigned width = mailbox_ref_storage_width_(
                              element, ivl_lval_width(lval));
                        const char*key_kind = draw_eval_assoc_key_(index, 0);
                        fprintf(vvp_out,
                                "    %%ref/capture/aa/%s v%p_0, %u, %u; mailbox associative element\n",
                                key_kind, sig, kind, width);
                        mailbox_ref_apply_part_(lval);
                        return 0;
                  }
                  ivl_type_t element = ivl_type_element(sig_type);
                  unsigned kind = mailbox_ref_value_kind_(element);
                  unsigned width = mailbox_ref_storage_width_(
                        element, ivl_lval_width(lval));
                  draw_eval_expr_into_integer(index, 3);
                  fprintf(vvp_out,
                          "    %%ref/capture/el v%p_0, %u, %u; mailbox container element\n",
                          sig, kind, width);
                  mailbox_ref_apply_part_(lval);
                  return 0;
            }

            if (index && ivl_signal_dimensions(sig) > 0) {
                  ivl_type_t value_type = ivl_lval_net_type(lval);
                  unsigned kind = mailbox_ref_value_kind_(value_type);
                  unsigned width = ivl_signal_width(sig);
                  if (!width)
                        width = mailbox_ref_storage_width_(
                              value_type, ivl_lval_width(lval));
                  draw_eval_expr_into_integer(index, 3);
                  note_array_signal_use(sig);
                  fprintf(vvp_out,
                          "    %%ref/capture/w v%p, %u, %u; mailbox fixed-array word\n",
                          sig, kind, width);
                  mailbox_ref_apply_part_(lval);
                  return 0;
            }

            if (index) {
                  fprintf(stderr, "%s:%u: sorry: unsupported indexed mailbox "
                          "ref-output signal shape.\n",
                          ivl_signal_file(sig), ivl_signal_lineno(sig));
                  vvp_errors += 1;
                  draw_eval_expr_into_integer(index, 3);
                  fprintf(vvp_out, "    %%null; unsupported indexed mailbox output\n");
                  return 1;
            }

            ivl_type_t value_type = ivl_lval_net_type(lval);
            unsigned kind = mailbox_ref_value_kind_(value_type);
            unsigned width = ivl_signal_width(sig);
            if (!width)
                  width = mailbox_ref_storage_width_(value_type,
                                                     ivl_lval_width(lval));
            fprintf(vvp_out,
                    "    %%ref/capture v%p_0, %u, %u; mailbox variable output\n",
                    sig, kind, width);
            mailbox_ref_apply_part_(lval);
            return 0;
      }

        /* draw_lval_expr() pushes the owning object for a nested l-value AND
         * for one that names its owner directly through a signal, so this
         * path serves both spellings. */
      if (property >= 0) {
            ivl_type_t owner_type = draw_lval_expr(lval);
            if (!owner_type || property >= ivl_type_properties(owner_type)) {
                  fprintf(stderr, "vvp.tgt error: cannot resolve mailbox "
                          "ref-output property %d.\n", property);
                  vvp_errors += 1;
                  fprintf(vvp_out, "    %%pop/obj 1, 0; malformed mailbox receiver\n");
                  fprintf(vvp_out, "    %%null; malformed mailbox output\n");
                  return 1;
            }

            ivl_type_t prop_type = ivl_type_prop_type(owner_type, property);
            ivl_type_t value_type = prop_type;

            if (index && type_is_fixed_uarray_property_(prop_type)) {
                  value_type = ivl_type_element(prop_type);
                  unsigned kind = mailbox_ref_value_kind_(value_type);
                  unsigned width = mailbox_ref_storage_width_(
                        value_type, ivl_lval_width(lval));
                  int slot = allocate_word();
                  int x_flag = -1;
                  int range_flag = -1;
                  unsigned bad = local_count++;
                  unsigned done = local_count++;
                  draw_fixed_uarray_slot_index_(index, prop_type, slot,
                                                &x_flag, &range_flag);
                  fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; mailbox property index X/Z\n",
                          thread_count, bad, x_flag);
                  if (range_flag >= 0)
                        fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; mailbox property index OOB\n",
                                thread_count, bad, range_flag);
                  fprintf(vvp_out, "    %%ix/mov 3, %d; captured property word\n",
                          slot);
                  fprintf(vvp_out,
                          "    %%ref/capture/pr/i %d, %u, %u; mailbox property word\n",
                          property, kind, width);
                  fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
                  fprintf(vvp_out, "T_%u.%u;\n", thread_count, bad);
                  fprintf(vvp_out, "    %%pop/obj 1, 0; invalid mailbox property receiver\n");
                  fprintf(vvp_out, "    %%null; invalid mailbox property word\n");
                  fprintf(vvp_out, "T_%u.%u;\n", thread_count, done);
                  clr_word(slot);
                  if (x_flag >= 0) clr_flag(x_flag);
                  if (range_flag >= 0) clr_flag(range_flag);
                  mailbox_ref_apply_part_(lval);
                  return 0;
            }

            if (index && prop_type
                && (ivl_type_base(prop_type) == IVL_VT_QUEUE
                    || ivl_type_base(prop_type) == IVL_VT_DARRAY)) {
                  if (ivl_type_base(prop_type) == IVL_VT_QUEUE
                      && ivl_type_queue_assoc_compat(prop_type)) {
                        value_type = ivl_type_element(prop_type);
                        unsigned kind = mailbox_ref_value_kind_(value_type);
                        unsigned width = mailbox_ref_storage_width_(
                              value_type, ivl_lval_width(lval));
                        fprintf(vvp_out,
                                "    %%prop/obj %d, 0; mailbox associative property\n",
                                property);
                        fprintf(vvp_out,
                                "    %%pop/obj 1, 1; retain selected associative array\n");
                        const char*key_kind = draw_eval_assoc_key_(index, 0);
                        fprintf(vvp_out,
                                "    %%ref/capture/aa/o/%s %u, %u; mailbox associative property element\n",
                                key_kind, kind, width);
                        mailbox_ref_apply_part_(lval);
                        return 0;
                  }
                  value_type = ivl_type_element(prop_type);
                  unsigned kind = mailbox_ref_value_kind_(value_type);
                  unsigned width = mailbox_ref_storage_width_(
                        value_type, ivl_lval_width(lval));
                  fprintf(vvp_out, "    %%prop/obj %d, 0; mailbox container property\n",
                          property);
                  fprintf(vvp_out, "    %%pop/obj 1, 1; retain selected container\n");
                  draw_eval_expr_into_integer(index, 3);
                  fprintf(vvp_out,
                          "    %%ref/capture/el/o %u, %u; mailbox property element\n",
                          kind, width);
                  mailbox_ref_apply_part_(lval);
                  return 0;
            }

            if (index) {
                  fprintf(stderr, "vvp.tgt sorry: unsupported indexed mailbox "
                          "ref-output property shape.\n");
                  vvp_errors += 1;
                  draw_eval_expr_into_integer(index, 3);
                  fprintf(vvp_out, "    %%pop/obj 1, 0; unsupported mailbox receiver\n");
                  fprintf(vvp_out, "    %%null; unsupported indexed mailbox property\n");
                  return 1;
            }

            unsigned kind = mailbox_ref_value_kind_(prop_type);
            unsigned width = mailbox_ref_storage_width_(
                  prop_type, ivl_lval_width(lval));
            fprintf(vvp_out,
                    "    %%ref/capture/pr %d, %u, %u; mailbox property output\n",
                    property, kind, width);
            mailbox_ref_apply_part_(lval);
            return 0;
      }

      fprintf(stderr, "vvp.tgt error: malformed mailbox ref-output l-value.\n");
      vvp_errors += 1;
      fprintf(vvp_out, "    %%null; malformed mailbox ref-output\n");
      return 1;
}

/*
 * Store a vector from the vec4 stack to the statement l-values. This
 * all assumes that the value to be assigned is already on the top of
 * the stack.
 *
 * NOTE TO SELF: The %store/vec4 takes a width, but the %assign/vec4
 * instructions do not, instead relying on the expression width. I
 * think that it the proper way to do it, so soon I should change the
 * %store/vec4 to not include the width operand.
 */
static void store_vec4_to_one_lval(ivl_lval_t lval)
{
	    ivl_signal_t lsig = ivl_lval_sig(lval);
	    unsigned lwid = ivl_lval_width(lval);
	    ivl_expr_t part_off_ex = ivl_lval_part_off(lval);
	      /* This is non-nil if the l-val is the word of a memory,
		 and nil otherwise. */
	    ivl_expr_t word_ex = ivl_lval_idx(lval);
	    unsigned carrier_wid = ivl_lval_part_carrier_width(lval);
	    uint64_t carrier_off = ivl_lval_part_carrier_off(lval);
	    ivl_expr_t dynamic_carrier = ivl_lval_dynamic_part_carrier(lval);

	    if (word_ex) {
		    /* Handle index into an array */
		  int word_index = allocate_word();
		  int part_index = 0;
		    /* Calculate the word address into word_index */
		  draw_eval_expr_into_integer(word_ex, word_index);
		    /* If there is a part_offset, calculate it into part_index. */
		  if (part_off_ex && !carrier_wid) {
			int flag_index = allocate_flag();
			part_index = allocate_word();
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag_index);
			draw_eval_expr_into_integer(part_off_ex, part_index);
			fprintf(vvp_out, "    %%flag_or 4, %d;\n", flag_index);
			clr_flag(flag_index);
		  }

		  assert(lsig);
		  note_array_signal_use(lsig);
		  if (dynamic_carrier) {
			int carrier_index = allocate_word();
			int carrier_flag = allocate_flag();
			int word_flag = allocate_flag();
			part_index = allocate_word();
			fprintf(vvp_out, "    %%flag_mov %d, 4; preserve array address\n",
				word_flag);
			draw_eval_expr_into_integer(dynamic_carrier, carrier_index);
			fprintf(vvp_out, "    %%flag_mov %d, 4; carrier validity\n",
				carrier_flag);
			draw_eval_expr_into_integer(part_off_ex, part_index);
			fprintf(vvp_out, "    %%flag_or 4, %d; combine carrier validity\n",
				carrier_flag);
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
				carrier_wid);
			fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
				part_index, carrier_index);
			fprintf(vvp_out, "    %%flag_or 4, %d; combine array address\n",
				word_flag);
			fprintf(vvp_out, "    %%store/vec4a v%p, %d, %d;\n",
				lsig, word_index, part_index);
			clr_flag(carrier_flag);
			clr_flag(word_flag);
			clr_word(carrier_index);
		  } else if (carrier_wid) {
			int word_flag = allocate_flag();
			part_index = allocate_word();
			fprintf(vvp_out, "    %%flag_mov %d, 4; preserve array address\n",
				word_flag);
			draw_eval_expr_into_integer(part_off_ex, part_index);
			fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64 ", 0, 32; carrier offset\n",
				carrier_off);
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
				carrier_wid);
			fprintf(vvp_out, "    %%clip/vec4/b %d;\n", part_index);
			fprintf(vvp_out, "    %%flag_or 4, %d;\n", word_flag);
			fprintf(vvp_out, "    %%store/vec4a v%p, %d, %d;\n",
				lsig, word_index, part_index);
			clr_flag(word_flag);
		  } else {
			fprintf(vvp_out, "    %%store/vec4a v%p, %d, %d;\n",
				lsig, word_index, part_index);
		  }

		  clr_word(word_index);
		  if (part_index)
			clr_word(part_index);

	    } else if (part_off_ex && dynamic_carrier) {
		  int carrier_index = allocate_word();
		  int carrier_flag = allocate_flag();
		  int offset_index = allocate_word();
		  draw_eval_expr_into_integer(dynamic_carrier, carrier_index);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve carrier validity\n",
			  carrier_flag);
		  draw_eval_expr_into_integer(part_off_ex, offset_index);
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine carrier validity\n",
			  carrier_flag);
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
			  offset_index, carrier_index);
		  assert(lsig);
		  if (signal_is_return_value(lsig))
			fprintf(vvp_out, "    %%ret/vec4/v 0, %d; Assign to %s\n",
				offset_index, ivl_signal_basename(lsig));
		  else if (ivl_signal_type(lsig) == IVL_SIT_UWIRE)
			fprintf(vvp_out, "    %%force/vec4/off v%p_0, %d;\n",
				lsig, offset_index);
		  else
			fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n",
				lsig, offset_index);
		  clr_flag(carrier_flag);
		  clr_word(carrier_index);
		  clr_word(offset_index);

	    } else if (part_off_ex && carrier_wid) {
		  int offset_index = allocate_word();
		  draw_eval_expr_into_integer(part_off_ex, offset_index);
		  fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64 ", 0, 32; carrier offset\n",
			  carrier_off);
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/b %d;\n", offset_index);
		  assert(lsig);
		  if (signal_is_return_value(lsig))
			fprintf(vvp_out, "    %%ret/vec4/v 0, %d; Assign to %s\n",
				offset_index, ivl_signal_basename(lsig));
		  else if (ivl_signal_type(lsig) == IVL_SIT_UWIRE)
			fprintf(vvp_out, "    %%force/vec4/off v%p_0, %d;\n",
				lsig, offset_index);
		  else
			fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n",
				lsig, offset_index);
		  clr_word(offset_index);

	    } else if (part_off_ex) {
		    /* Dynamically calculated part offset */
		  int offset_index = allocate_word();
		  draw_eval_expr_into_integer(part_off_ex, offset_index);
		    /* Note that flag4 is set by the eval above. */
		  assert(lsig);
		  if (signal_is_return_value(lsig)) {
			fprintf(vvp_out, "    %%ret/vec4 0, %d, %u; Assign to %s (store_vec4_to_lval)\n",
				offset_index, lwid, ivl_signal_basename(lsig));
		  } else {
			put_vec_to_signal_part(lsig, offset_index, lwid);
		  }
		  clr_word(offset_index);

	    } else {
		    /* No offset expression, so use simpler store function. */
		  assert(lsig);
		  assert(lwid == ivl_signal_width(lsig));
		  if (signal_is_return_value(lsig)) {
			fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;  Assign to %s (store_vec4_to_lval)\n",
				lwid, ivl_signal_basename(lsig));
		  } else {
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
				lsig, lwid);
		  }
	    }
}

static void store_vec4_to_lval(ivl_statement_t net)
{
      for (unsigned lidx = 0 ; lidx < ivl_stmt_lvals(net) ; lidx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net,lidx);
	    unsigned lwid = ivl_lval_width(lval);

	    if (lidx+1 < ivl_stmt_lvals(net))
		  fprintf(vvp_out, "    %%split/vec4 %u;\n", lwid);

	    store_vec4_to_one_lval(lval);
      }
}

/* Base word for an array-pattern store. A partial index on the l-value is
 * an unpacked-array slice (m[i] = '{...}); elaboration put the slice's flat
 * base word into the l-value index, so the pattern store starts there. A
 * whole-array pattern has no l-value index and starts at word 0. */
static unsigned int array_pattern_base_(ivl_lval_t lval)
{
      ivl_expr_t idx = ivl_lval_idx(lval);
      if (idx == 0)
	    return 0;
      assert(ivl_expr_type(idx) == IVL_EX_NUMBER);
      return (unsigned int) get_number_immediate(idx);
}

static unsigned int draw_array_pattern(ivl_signal_t var, ivl_expr_t rval,
					   unsigned int array_idx)
{
      ivl_type_t var_type = ivl_signal_net_type(var);
      ivl_type_t elem_type = var_type;

      /* A scalar aggregate cobject target is not an unpacked array. Build
       * the whole aggregate object and store it as a single handle. */
      if (ivl_signal_dimensions(var) == 0
          && var_type
          && ivl_type_base(var_type) == IVL_VT_NO_TYPE
          && ivl_type_properties(var_type) > 0) {
	    draw_eval_object(rval);
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", var);
	    return array_idx;
      }

      if (ivl_signal_dimensions(var) > 0) {
	    ivl_type_t unpacked_elem = ivl_type_element(var_type);
	    if (unpacked_elem)
		  elem_type = unpacked_elem;
      }

      for (unsigned int idx = 0; idx < ivl_expr_parms(rval); idx += 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx);

	    switch (ivl_expr_type(expr)) {
		case IVL_EX_ARRAY_PATTERN:
		    /* An object-like array element can itself be written as an
		     * assignment pattern, but a multidimensional array also uses
		     * nested IVL_EX_ARRAY_PATTERN nodes for its remaining unpacked
		     * dimensions.  The expression's net type distinguishes them:
		     * an unpacked-array node still has an element type, while the
		     * terminal struct/union aggregate has properties instead. */
		  if (type_is_object_like_(elem_type)
		      && !(ivl_expr_net_type(expr)
			   && ivl_type_element(ivl_expr_net_type(expr))
			   && !ivl_type_is_packed_vector(
				 ivl_expr_net_type(expr)))) {
			draw_eval_object(expr);
			fprintf(vvp_out, "    %%ix/load 3, %u, 0;\n", array_idx);
			fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
			fprintf(vvp_out, "    %%store/obja v%p, 3;\n", var);
			array_idx += 1;
		  } else {
			array_idx = draw_array_pattern(var, expr, array_idx);
		  }
		  break;
		default:
		  if (ivl_expr_type(expr) == IVL_EX_UFUNC) {
			ivl_scope_t def = ivl_expr_def(expr);
			ivl_signal_t retval = def ? ivl_scope_port(def, 0) : 0;
			if (retval && ivl_signal_dimensions(retval) > 0) {
			      draw_ufunc_uarray(expr, var, array_idx);
			      array_idx += ivl_signal_array_count(retval);
			      break;
			}
		  }
		  switch (ivl_type_base(elem_type)) {
		      case IVL_VT_BOOL:
		      case IVL_VT_LOGIC:
			draw_eval_vec4(expr);
			fprintf(vvp_out, "    %%ix/load 3, %u, 0;\n", array_idx);
			fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
			fprintf(vvp_out, "    %%store/vec4a v%p, 3, 0;\n", var);
			break;
		      case IVL_VT_REAL:
			draw_eval_real(expr);
			fprintf(vvp_out, "    %%ix/load 3, %u, 0;\n", array_idx);
			fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
			fprintf(vvp_out, "    %%store/reala v%p, 3;\n", var);
			break;
		      case IVL_VT_STRING:
			draw_eval_string(expr);
			fprintf(vvp_out, "    %%ix/load 3, %u, 0;\n", array_idx);
			fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
			fprintf(vvp_out, "    %%store/stra v%p, 3;\n", var);
			break;
		      case IVL_VT_CLASS:
		      case IVL_VT_DARRAY:
		      case IVL_VT_QUEUE:
		      case IVL_VT_NO_TYPE:
			draw_eval_object(expr);
			fprintf(vvp_out, "    %%ix/load 3, %u, 0;\n", array_idx);
			fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
			fprintf(vvp_out, "    %%store/obja v%p, 3;\n", var);
			break;
		      default:
			assert(0);
			break;
		  }
		  array_idx++;
		  break;
	    }
      }

      return array_idx;
}

/* Store an unpacked-array assignment pattern into a logic-array class
 * property, element by element (`obj.arr = '{...}` where arr is an
 * unpacked array of packed values).  The receiver object must already be
 * on top of the object stack: %store/prop/v/i peeks it (does not pop), so
 * one push serves every element and the caller pops once afterward.
 * word_reg is a scratch integer register carrying each element's array
 * index; array_idx is the running flat element counter.  A nested pattern
 * (a multidimensional unpacked array) recurses with the same running
 * index.  Returns the next flat element index. */
static unsigned int draw_prop_array_pattern_values_(ivl_expr_t rval)
{
      unsigned int count = 0;
      for (unsigned int idx = 0; idx < ivl_expr_parms(rval); idx += 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx);
	    if (ivl_expr_type(expr) == IVL_EX_ARRAY_PATTERN) {
		  count += draw_prop_array_pattern_values_(expr);
		  continue;
	    }
	    draw_eval_vec4(expr);
	    count += 1;
      }
      return count;
}

static unsigned int draw_prop_array_pattern_stores_(
					    int prop_idx, const char*prop_name,
					    ivl_expr_t rval, int word_reg,
					    unsigned int next_idx)
{
      for (unsigned int idx = ivl_expr_parms(rval); idx > 0; idx -= 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx - 1);
	    if (ivl_expr_type(expr) == IVL_EX_ARRAY_PATTERN) {
		  next_idx = draw_prop_array_pattern_stores_(
			prop_idx, prop_name, expr, word_reg, next_idx);
		  continue;
	    }
	    assert(next_idx > 0);
	    next_idx -= 1;
	    fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", word_reg,
		    next_idx);
	    fprintf(vvp_out, "    %%store/prop/v/i %d, %d, %u;"
		    " array-pattern element into logic property %s\n",
		    prop_idx, word_reg, ivl_expr_width(expr), prop_name);
      }
      return next_idx;
}

static unsigned int draw_prop_array_pattern(int prop_idx, const char*prop_name,
					    ivl_expr_t rval, int word_reg,
					    unsigned int array_idx)
{
      unsigned int count = draw_prop_array_pattern_values_(rval);
      unsigned int next_idx = array_idx + count;
      assert(next_idx >= array_idx);
      unsigned int first_idx = draw_prop_array_pattern_stores_(
	    prop_idx, prop_name, rval, word_reg, next_idx);
      assert(first_idx == array_idx);
      return next_idx;
}

/* As draw_prop_array_pattern, but for a real-valued class-property array
 * (`obj.arr = '{...}` where arr is an unpacked array of real). */
static unsigned int draw_prop_real_array_pattern_values_(ivl_expr_t rval)
{
      unsigned int count = 0;
      for (unsigned int idx = 0; idx < ivl_expr_parms(rval); idx += 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx);
	    if (ivl_expr_type(expr) == IVL_EX_ARRAY_PATTERN) {
		  count += draw_prop_real_array_pattern_values_(expr);
		  continue;
	    }
	    draw_eval_real(expr);
	    count += 1;
      }
      return count;
}

static unsigned int draw_prop_real_array_pattern_stores_(
						 int prop_idx, const char*prop_name,
						 ivl_expr_t rval, int word_reg,
						 unsigned int next_idx)
{
      for (unsigned int idx = ivl_expr_parms(rval); idx > 0; idx -= 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx - 1);
	    if (ivl_expr_type(expr) == IVL_EX_ARRAY_PATTERN) {
		  next_idx = draw_prop_real_array_pattern_stores_(
			prop_idx, prop_name, expr, word_reg, next_idx);
		  continue;
	    }
	    assert(next_idx > 0);
	    next_idx -= 1;
	    fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", word_reg,
		    next_idx);
	    fprintf(vvp_out, "    %%store/prop/r/i %d, %d;"
		    " array-pattern element into real property %s\n",
		    prop_idx, word_reg, prop_name);
      }
      return next_idx;
}

static unsigned int draw_prop_real_array_pattern(int prop_idx,
						 const char*prop_name,
						 ivl_expr_t rval, int word_reg,
						 unsigned int array_idx)
{
      unsigned int count = draw_prop_real_array_pattern_values_(rval);
      unsigned int next_idx = array_idx + count;
      assert(next_idx >= array_idx);
      unsigned int first_idx = draw_prop_real_array_pattern_stores_(
	    prop_idx, prop_name, rval, word_reg, next_idx);
      assert(first_idx == array_idx);
      return next_idx;
}

/* As draw_prop_array_pattern, but for a string-valued class-property
 * array (`obj.arr = '{...}` where arr is an unpacked array of string). */
static unsigned int draw_prop_str_array_pattern_values_(ivl_expr_t rval)
{
      unsigned int count = 0;
      for (unsigned int idx = 0; idx < ivl_expr_parms(rval); idx += 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx);
	    if (ivl_expr_type(expr) == IVL_EX_ARRAY_PATTERN) {
		  count += draw_prop_str_array_pattern_values_(expr);
		  continue;
	    }
	    draw_eval_string(expr);
	    count += 1;
      }
      return count;
}

static unsigned int draw_prop_str_array_pattern_stores_(
						int prop_idx, const char*prop_name,
						ivl_expr_t rval, int word_reg,
						unsigned int next_idx)
{
      for (unsigned int idx = ivl_expr_parms(rval); idx > 0; idx -= 1) {
	    ivl_expr_t expr = ivl_expr_parm(rval, idx - 1);
	    if (ivl_expr_type(expr) == IVL_EX_ARRAY_PATTERN) {
		  next_idx = draw_prop_str_array_pattern_stores_(
			prop_idx, prop_name, expr, word_reg, next_idx);
		  continue;
	    }
	    assert(next_idx > 0);
	    next_idx -= 1;
	    fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", word_reg,
		    next_idx);
	    fprintf(vvp_out, "    %%store/prop/str/i %d, %d;"
		    " array-pattern element into string property %s\n",
		    prop_idx, word_reg, prop_name);
      }
      return next_idx;
}

static unsigned int draw_prop_str_array_pattern(int prop_idx,
						const char*prop_name,
						ivl_expr_t rval, int word_reg,
						unsigned int array_idx)
{
      unsigned int count = draw_prop_str_array_pattern_values_(rval);
      unsigned int next_idx = array_idx + count;
      assert(next_idx >= array_idx);
      unsigned int first_idx = draw_prop_str_array_pattern_stores_(
	    prop_idx, prop_name, rval, word_reg, next_idx);
      assert(first_idx == array_idx);
      return next_idx;
}

static void draw_stmt_assign_vector_opcode(unsigned char opcode, bool is_signed)
{
      int idx_reg;

      switch (opcode) {
	  case 0:
	    break;

	  case '+':
	    fprintf(vvp_out, "    %%add;\n");
	    break;

	  case '-':
	    fprintf(vvp_out, "    %%sub;\n");
	    break;

	  case '*':
	    fprintf(vvp_out, "    %%mul;\n");
	    break;

	  case '/':
	    fprintf(vvp_out, "    %%div%s;\n", is_signed ? "/s":"");
	    break;

	  case '%':
	    fprintf(vvp_out, "    %%mod%s;\n", is_signed ? "/s":"");
	    break;

	  case '&':
	    fprintf(vvp_out, "    %%and;\n");
	    break;

	  case '|':
	    fprintf(vvp_out, "    %%or;\n");
	    break;

	  case '^':
	    fprintf(vvp_out, "    %%xor;\n");
	    break;

	  case 'l': /* lval <<= expr */
	    idx_reg = allocate_word();
	    fprintf(vvp_out, "    %%ix/vec4 %d;\n", idx_reg);
	    fprintf(vvp_out, "    %%shiftl %d;\n", idx_reg);
	    clr_word(idx_reg);
	    break;

	  case 'r': /* lval >>= expr */
	    idx_reg = allocate_word();
	    fprintf(vvp_out, "    %%ix/vec4 %d;\n", idx_reg);
	    fprintf(vvp_out, "    %%shiftr %d;\n", idx_reg);
	    clr_word(idx_reg);
	    break;

	  case 'R': /* lval >>>= expr */
	    idx_reg = allocate_word();
	    fprintf(vvp_out, "    %%ix/vec4 %d;\n", idx_reg);
	    fprintf(vvp_out, "    %%shiftr/s %d;\n", idx_reg);
	    clr_word(idx_reg);
	    break;

	  default:
	    fprintf(vvp_out, "; UNSUPPORTED ASSIGNMENT OPCODE: %c\n", opcode);
	    assert(0);
	    break;
      }
}

/* A compound update has its old l-value on the vector stack. Size the
   operation before evaluating it, and only then truncate for assignment.
   Opcode zero also serves plain stores in the shared property paths. */
static void draw_stmt_assign_vector_rhs(ivl_statement_t net, unsigned wid)
{
      ivl_expr_t rval = ivl_stmt_rval(net);
      unsigned char op = ivl_stmt_opcode(net);
      bool shift = op == 'l' || op == 'r' || op == 'R';
      unsigned op_wid = wid;
      if (op && !shift && ivl_expr_width(rval) > op_wid)
            op_wid = ivl_expr_width(rval);
      if (op)
            fprintf(vvp_out, "    %%pad/%c %u;\n",
                    ivl_expr_signed(rval) ? 's' : 'u', op_wid);
      draw_eval_vec4(rval);
      if (!shift)
            fprintf(vvp_out, "    %%pad/%c %u;\n",
                    ivl_expr_signed(rval) ? 's' : 'u', op_wid);
      draw_stmt_assign_vector_opcode(op, ivl_expr_signed(rval));
      if (op_wid > wid)
            fprintf(vvp_out, "    %%pad/u %u;\n", wid);
}

static int show_stmt_assign_vector(ivl_statement_t net)
{
      ivl_expr_t rval = ivl_stmt_rval(net);

      if (ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
	    ivl_lval_t lval = ivl_stmt_lval(net, 0);
	    ivl_signal_t sig = ivl_lval_sig(lval);
	    draw_array_pattern(sig, rval, array_pattern_base_(lval));
	    return 0;
      }

      unsigned wid = ivl_stmt_lwidth(net);

	/* If this is a compressed assignment, then get the contents
	   of the l-value. We need these values as part of the r-value
	   calculation. */
      if (ivl_stmt_opcode(net) != 0) {
	    struct vec_slice_info *slices;

	    slices = calloc(ivl_stmt_lvals(net), sizeof(struct vec_slice_info));

	    fprintf(vvp_out, "    ; show_stmt_assign_vector: Get l-value for compressed %c= operand\n", ivl_stmt_opcode(net));
	    get_vec_from_lval(net, slices);
	    draw_stmt_assign_vector_rhs(net, wid);
	    put_vec_to_lval(net, slices);
	    free(slices);
      } else {
	    draw_eval_vec4(rval);
	    resize_vec4_wid(rval, wid);
	    store_vec4_to_lval(net);
      }

      return 0;
}

static int packed_property_offset_is_unknown_(ivl_expr_t expr)
{
      return ivl_expr_type(expr) == IVL_EX_NUMBER
	  && number_is_unknown(expr);
}

static int packed_property_offset_is_negative_(ivl_expr_t expr)
{
      if (ivl_expr_type(expr) != IVL_EX_NUMBER || !ivl_expr_signed(expr)
	  || ivl_expr_width(expr) == 0 || number_is_unknown(expr))
	    return 0;

      return ivl_expr_bits(expr)[ivl_expr_width(expr)-1] == '1';
}

static int packed_property_offset_is_immediate_(ivl_expr_t expr)
{
      if (ivl_expr_type(expr) != IVL_EX_NUMBER
	  && ivl_expr_type(expr) != IVL_EX_ULONG)
	    return 0;
      if (packed_property_offset_is_unknown_(expr))
	    return 0;
      return number_is_immediate(expr, 32, 0);
}

/* Return the exact two's-complement bits of a defined negative constant when
 * it fits the run-time signed property-offset register. This deliberately
 * includes INT64_MIN, which number_is_immediate(..., 64, true) rejects because
 * that older helper assumes every negative immediate will later be negated.
 * Property offsets are never negated by code generation. */
static int packed_property_negative_offset_bits64_(ivl_expr_t expr,
						     uint64_t*value)
{
      const char*bits;
      unsigned width;
      uint64_t result = 0;

      if (!packed_property_offset_is_negative_(expr)
	  || number_is_unknown(expr))
	    return 0;

      bits = ivl_expr_bits(expr);
      width = ivl_expr_width(expr);

	/* A value wider than int64_t fits only when bit 63 and every more
	 * significant bit are sign-extension ones. */
      if (width > 64) {
	    for (unsigned idx = 63; idx < width; idx += 1)
		  if (bits[idx] != '1')
			return 0;
      }

      unsigned copy_width = width < 64 ? width : 64;
      for (unsigned idx = 0; idx < copy_width; idx += 1) {
	    if (bits[idx] == '1')
		  result |= UINT64_C(1) << idx;
	    else if (bits[idx] != '0')
		  return 0;
      }
      if (width < 64)
	    result |= ~UINT64_C(0) << width;

      *value = result;
      return 1;
}

static void emit_packed_property_negative_offset_(int word,
						    uint64_t value)
{
      fprintf(vvp_out, "    %%ix/load %d, %" PRIu32 ", %" PRIu32 ";\n",
	      word, (uint32_t)value, (uint32_t)(value >> 32));
      fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
}

/* A concatenation containing interface/class integral properties is exported
 * as multiple l-values, least-significant (source-rightmost) first. The
 * ordinary class-property path handles one l-value and would silently store
 * only index zero, while the ordinary vector path cannot store through an
 * object receiver. Split the packed r-value exactly as an ordinary
 * concatenation, dispatching each slice to either a property or vector store.
 * This also handles constant packed-field offsets within a property. */
static int show_stmt_assign_concat_cobject_(ivl_statement_t net)
{
      unsigned lvals = ivl_stmt_lvals(net);
      ivl_expr_t rval = ivl_stmt_rval(net);
      int have_property = 0;

      if (lvals < 2 || ivl_stmt_opcode(net) != 0 || !rval)
	    return -1;

	/* First distinguish this path from an ordinary vector concatenation. */
      for (unsigned idx = 0; idx < lvals; idx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, idx);
	    if (ivl_lval_property_idx(lval) >= 0)
		  have_property = 1;
      }
      if (!have_property)
	    return -1;

	/* Validate the complete destination before emitting any partial store. */
      for (unsigned idx = 0; idx < lvals; idx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, idx);
	    ivl_signal_t sig = ivl_lval_sig(lval);
	    int prop_idx = ivl_lval_property_idx(lval);
	    if (!sig || ivl_lval_nest(lval)) {
		  fprintf(stderr, "%s:%u: sorry: nested or signal-less member in "
			  "a packed property concatenation is not yet supported.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }

	    if (prop_idx >= 0) {
		  ivl_type_t owner_type = ivl_signal_net_type(sig);
		  ivl_expr_t part_off = ivl_lval_part_off(lval);
		  if (ivl_lval_idx(lval) || (part_off
		      && ivl_expr_type(part_off) != IVL_EX_NUMBER
		      && ivl_expr_type(part_off) != IVL_EX_ULONG)) {
			fprintf(stderr, "%s:%u: sorry: indexed or dynamically "
				"selected member in a packed property concatenation "
				"is not yet supported.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			return 1;
		  }
		  if (!owner_type || prop_idx >= ivl_type_properties(owner_type)) {
			fprintf(stderr, "%s:%u: error: cannot resolve property %d "
				"in packed concatenation assignment.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net), prop_idx);
			return 1;
		  }
		  ivl_type_t prop_type = ivl_type_prop_type(owner_type, prop_idx);
		  if (!prop_type || (ivl_type_base(prop_type) != IVL_VT_BOOL
			       && ivl_type_base(prop_type) != IVL_VT_LOGIC)) {
			fprintf(stderr, "%s:%u: error: property in packed "
				"concatenation assignment is not an integral packed "
				"type.\n", ivl_stmt_file(net), ivl_stmt_lineno(net));
			return 1;
		  }
	    } else {
		  ivl_type_t lval_type = ivl_lval_net_type(lval);
		  if (!lval_type)
			lval_type = ivl_signal_net_type(sig);
		  if (!lval_type || (ivl_type_base(lval_type) != IVL_VT_BOOL
			       && ivl_type_base(lval_type) != IVL_VT_LOGIC)) {
			fprintf(stderr, "%s:%u: error: nonintegral ordinary "
				"member in packed property concatenation assignment.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			return 1;
		  }
	    }
      }

      draw_eval_vec4(rval);
      resize_vec4_wid(rval, ivl_stmt_lwidth(net));

      for (unsigned idx = 0; idx < lvals; idx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, idx);
	    unsigned width = ivl_lval_width(lval);
	    int prop_idx = ivl_lval_property_idx(lval);

	    if (idx + 1 < lvals)
		  fprintf(vvp_out, "    %%split/vec4 %u;\n", width);

	    if (prop_idx < 0) {
		  store_vec4_to_one_lval(lval);
		  continue;
	    }

	    unsigned lab_null = local_count++;
	    unsigned lab_out = local_count++;
	    ivl_type_t owner_type = draw_lval_expr(lval);
	    ivl_type_t prop_type = ivl_type_prop_type(owner_type, prop_idx);
	    ivl_expr_t part_off = ivl_lval_part_off(lval);
	    uint64_t negative_part_off_bits = 0;
	    int dynamic_part_off = part_off
		  && packed_property_negative_offset_bits64_(
			part_off, &negative_part_off_bits);
	      /* An X/Z or nonnegative constant too large for any packed property
	       * is wholly out of bounds. The assignment slice is a no-op, but the
	       * complete r-value and receiver have already been evaluated and
	       * ordinary sibling slices must still be stored. A defined negative
	       * base instead takes the dynamic opcode so a partially overlapping
	       * indexed part-select still updates its in-range bits. */
	    if (part_off && !dynamic_part_off
		  && !packed_property_offset_is_immediate_(part_off)) {
		  fprintf(vvp_out, "    %%pop/obj 1, 0; Discard receiver for "
			  "unknown/out-of-range property offset\n");
		  fprintf(vvp_out, "    %%pop/vec4 1; Discard no-op "
			  "concatenation slice\n");
		  continue;
	    }
	    int off_reg = 0;
	    int off_flag = 0;
	    if (dynamic_part_off) {
		  off_reg = allocate_word();
		  off_flag = allocate_flag();
		  emit_packed_property_negative_offset_(
			off_reg, negative_part_off_bits);
		  fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
	    }
	    fprintf(vvp_out, "    %%test_nul/obj;\n");
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
		    thread_count, lab_null);
	    if (ivl_type_base(prop_type) == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    if (dynamic_part_off) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
		  fprintf(vvp_out,
			  "    %%store/prop/v/bits/x %d, %d, %u; Store "
			  "concatenation slice at signed property offset\n",
			  prop_idx, off_reg, width);
	    } else if (part_off) {
		  unsigned bitoff = (unsigned)ivl_expr_uvalue(part_off);
		  fprintf(vvp_out,
			  "    %%store/prop/v/bits %d, %u, %u; Store "
			  "concatenation slice in field [%u+:%u] of property %s\n",
			  prop_idx, bitoff, width, bitoff, width,
			  ivl_type_prop_name(owner_type, prop_idx));
	    } else {
		  fprintf(vvp_out,
			  "    %%store/prop/v %d, %u; Store concatenation slice "
			  "in logic property %s\n",
			  prop_idx, width,
			  ivl_type_prop_name(owner_type, prop_idx));
	    }
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    fprintf(vvp_out, "    %%pop/vec4 1;\n");
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
	    if (dynamic_part_off) {
		  clr_word(off_reg);
		  clr_flag(off_flag);
	    }
      }

      return 0;
}

enum real_lval_type_e {
      REAL_NO_TYPE = 0,
      REAL_SIMPLE_WORD,
      REAL_MEMORY_WORD_STATIC,
      REAL_MEMORY_WORD_DYNAMIC
};

struct real_lval_info {
      enum real_lval_type_e type;

      union {
	    struct {
		  unsigned long use_word;
	    } simple_word;

	    struct {
		  unsigned long use_word;
	    } memory_word_static;

	    struct {
		    /* Index reg that holds the memory word index */
		  int word_idx_reg;
		    /* Stored x/non-x flag */
		  unsigned x_flag;
	    } memory_word_dynamic;
      } u_;
};

static void get_real_from_lval(ivl_lval_t lval, struct real_lval_info*slice)
{
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_expr_t word_ix = ivl_lval_idx(lval);
      unsigned long use_word = 0;

	/* If the word index is a constant expression, then evaluate
	   it to select the word, and pay no further heed to the
	   expression itself. */
      if (word_ix && number_is_immediate(word_ix, IMM_WID, 0)) {
	    if (number_is_unknown(word_ix))
		  use_word = ULONG_MAX; // The largest valid index is ULONG_MAX - 1
	    else
		  use_word = get_number_immediate(word_ix);
	    word_ix = 0;
      }

      if (ivl_signal_dimensions(sig)==0 && word_ix==0) {

	    slice->type = REAL_SIMPLE_WORD;
	    slice->u_.simple_word.use_word = use_word;
	    if (signal_is_return_value(sig)) {
		  assert(use_word==0);
		  fprintf(vvp_out, "    %%retload/real 0;\n");
	    } else {
		  fprintf(vvp_out, "    %%load/real v%p_%lu;\n", sig, use_word);
	    }

      } else if (ivl_signal_dimensions(sig) > 0 && word_ix == 0) {

	    slice->type = REAL_MEMORY_WORD_STATIC;
	    slice->u_.memory_word_static.use_word = use_word;
	    if (use_word < ivl_signal_array_count(sig)) {
		  fprintf(vvp_out, "    %%ix/load 3, %lu, 0;\n",
			  use_word);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  fprintf(vvp_out, "    %%load/ar v%p, 3;\n", sig);
	    } else {
		  fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
	    }

      } else if (ivl_signal_dimensions(sig) > 0 && word_ix != 0) {
	    slice->type = REAL_MEMORY_WORD_DYNAMIC;

	    slice->u_.memory_word_dynamic.word_idx_reg = allocate_word();
	    slice->u_.memory_word_dynamic.x_flag = allocate_flag();

	    draw_eval_expr_into_integer(word_ix, slice->u_.memory_word_dynamic.word_idx_reg);
	    fprintf(vvp_out, "    %%flag_mov %u, 4;\n", slice->u_.memory_word_dynamic.x_flag);
	    fprintf(vvp_out, "    %%load/ar v%p, %d;\n", sig, slice->u_.memory_word_dynamic.word_idx_reg);

      } else {
	    assert(0);
      }
}

static void put_real_to_lval(ivl_lval_t lval, struct real_lval_info*slice)
{
      ivl_signal_t sig = ivl_lval_sig(lval);

	/* Special Case: If the l-value signal is named after its scope,
	   and the scope is a function, then this is an assign to a return
	   value and should be handled differently. */
      if (signal_is_return_value(sig) && ivl_signal_dimensions(sig) == 0) {
	    assert(slice->u_.simple_word.use_word == 0);
	    fprintf(vvp_out, "    %%ret/real 0;\n");
	    return;
      }

      switch (slice->type) {
	  default:
	    fprintf(vvp_out, " ; XXXX slice->type=%d\n", slice->type);
	    assert(0);
	    break;

	  case REAL_SIMPLE_WORD:
	    fprintf(vvp_out, "    %%store/real v%p_%lu;\n",
		    sig, slice->u_.simple_word.use_word);
	    break;

	  case REAL_MEMORY_WORD_STATIC:
	    if (slice->u_.memory_word_static.use_word < ivl_signal_array_count(sig)) {
		  int word_idx = allocate_word();
		  fprintf(vvp_out,"    %%flag_set/imm 4, 0;\n");
		  fprintf(vvp_out,"    %%ix/load %d, %lu, 0;\n", word_idx, slice->u_.memory_word_static.use_word);
		  fprintf(vvp_out,"    %%store/reala v%p, %d;\n", sig, word_idx);
		  clr_word(word_idx);
	    } else {
		  fprintf(vvp_out," ; Skip this slice write to v%p [%lu]\n", sig, slice->u_.memory_word_static.use_word);
		  fprintf(vvp_out,"    %%pop/real 1;\n");
	    }
	    break;

	  case REAL_MEMORY_WORD_DYNAMIC:
	    fprintf(vvp_out, "    %%flag_mov 4, %u;\n", slice->u_.memory_word_dynamic.x_flag);
	    fprintf(vvp_out, "    %%store/reala v%p, %d;\n", sig, slice->u_.memory_word_dynamic.word_idx_reg);
	    clr_word(slice->u_.memory_word_dynamic.word_idx_reg);
	    clr_flag(slice->u_.memory_word_dynamic.x_flag);
	    break;

      }
}

static void store_real_to_lval(ivl_lval_t lval)
{
      ivl_signal_t var;

      var = ivl_lval_sig(lval);
      assert(var != 0);

	/* Special Case: If the l-value signal is named after its scope,
	   and the scope is a function, then this is an assign to a return
	   value and should be handled differently. */
      ivl_scope_t sig_scope = ivl_signal_scope(var);
      if ((ivl_scope_type(sig_scope) == IVL_SCT_FUNCTION)
	  && (strcmp(ivl_signal_basename(var), ivl_scope_basename(sig_scope)) == 0)
	  && ivl_signal_dimensions(var) == 0) {
	    fprintf(vvp_out, "    %%ret/real 0; Assign to %s\n",
		    ivl_signal_basename(var));
	    return;
      }

      if (ivl_signal_dimensions(var) == 0) {
	    fprintf(vvp_out, "    %%store/real v%p_0;\n", var);
	    return;
      }

      ivl_expr_t word_ex = ivl_lval_idx(lval);
      int word_ix = allocate_word();

      draw_eval_expr_into_integer(word_ex, word_ix);
      fprintf(vvp_out, "    %%store/reala v%p, %d;\n", var, word_ix);

      clr_word(word_ix);
}

static void draw_stmt_assign_real_opcode(unsigned char opcode)
{
      switch (opcode) {
	  case 0:
	    break;

	  case '+':
	    fprintf(vvp_out, "    %%add/wr;\n");
	    break;

	  case '-':
	    fprintf(vvp_out, "    %%sub/wr;\n");
	    break;

	  case '*':
	    fprintf(vvp_out, "    %%mul/wr;\n");
	    break;

	  case '/':
	    fprintf(vvp_out, "    %%div/wr;\n");
	    break;

	  case '%':
	    fprintf(vvp_out, "    %%mod/wr;\n");
	    break;

	  default:
	    fprintf(vvp_out, "; UNSUPPORTED ASSIGNMENT OPCODE: %c\n", opcode);
	    assert(0);
	    break;
      }
}

/*
 * This function assigns a value to a real variable. This is destined
 * for /dev/null when typed ivl_signal_t takes over all the real
 * variable support.
 */
static int show_stmt_assign_sig_real(ivl_statement_t net)
{
      ivl_lval_t lval;

      assert(ivl_stmt_lvals(net) == 1);
      lval = ivl_stmt_lval(net, 0);

      ivl_expr_t rval = ivl_stmt_rval(net);
      if (ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
	    ivl_signal_t sig = ivl_lval_sig(lval);
	    draw_array_pattern(sig, rval, array_pattern_base_(lval));
	    return 0;
      }

	/* If this is a compressed assignment, then get the contents
	   of the l-value. We need this value as part of the r-value
	   calculation. */
      if (ivl_stmt_opcode(net) != 0) {
	    struct real_lval_info slice;

	    fprintf(vvp_out, "    ; show_stmt_assign_real: Get l-value for compressed %c= operand\n", ivl_stmt_opcode(net));
	    get_real_from_lval(lval, &slice);
	    draw_eval_real(rval);
	    draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
	    put_real_to_lval(lval, &slice);
      } else {
	    draw_eval_real(rval);
	    store_real_to_lval(lval);
      }

      return 0;
}

static int show_stmt_assign_sig_string(ivl_statement_t net)
{
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t part = ivl_lval_part_off(lval);
      ivl_expr_t aidx = ivl_lval_idx(lval);
      ivl_signal_t var= ivl_lval_sig(lval);

      assert(ivl_stmt_lvals(net) == 1);
      if (ivl_stmt_opcode(net) != 0) {
	    if (part && aidx && !signal_is_return_value(var)) {
		  int word_index = allocate_word();
		  int word_flag = allocate_flag();
		  int character_index = allocate_word();
		  draw_eval_expr_into_integer(aidx, word_index);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve string array word selector\n",
		          word_flag);
		  draw_eval_vec4(part);
		  resize_vec4_wid(part, 32);
		  fprintf(vvp_out, "    %%cast2; string array character selector to int\n");
		  fprintf(vvp_out, "    %%ix/vec4/s %d; capture string array character selector\n",
		          character_index);
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string array word selector for read\n",
		          word_flag);
		  fprintf(vvp_out, "    %%load/stra v%p, %d; string array character compound read\n",
		          var, word_index);
		  fprintf(vvp_out, "    %%substr/vec4 %d, 8; selected string array character\n",
		          character_index);
		  fprintf(vvp_out, "    %%pop/str 1; discard captured string array word\n");
		  draw_stmt_assign_vector_rhs(net, 8);
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string array word selector\n",
		          word_flag);
		  fprintf(vvp_out, "    %%putc/stra/vec4 v%p, %d, %d; string array character compound store\n",
		          var, word_index, character_index);
		  clr_word(word_index);
		  clr_flag(word_flag);
		  clr_word(character_index);
		  return 0;
	    }
	    /* A character selection is an 8-bit integral l-value. Capture its
	     * selector once, read the old byte with the established string-select
	     * path, apply the ordinary vector compound operation, and write it
	     * through putc. putc retains the standard invalid-index, empty-string,
	     * and zero-byte behavior. */
	    if (part && !aidx
	        && (!signal_is_return_value(var)
	            || ivl_signal_dimensions(var) == 0)) {
		  int mux_word = allocate_word();
		  int mux_flag = allocate_flag();
		  /* string.getc/putc take a two-state signed int index. Perform
		   * that conversion once here so reads and writes use the same
		   * low 32 bits, including X/Z-to-zero conversion. */
		  draw_eval_vec4(part);
		  resize_vec4_wid(part, 32);
		  fprintf(vvp_out, "    %%cast2; string character selector to int\n");
		  fprintf(vvp_out, "    %%ix/vec4/s %d; capture string character selector\n",
		          mux_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve string character selector\n",
		          mux_flag);
		  if (signal_is_return_value(var))
			fprintf(vvp_out, "    %%retload/str 0; string return character compound read\n");
		  else
			fprintf(vvp_out, "    %%load/str v%p_0; string character compound read\n",
			        var);
		  fprintf(vvp_out, "    %%substr/vec4 %d, 8; selected string character\n",
		          mux_word);
		  fprintf(vvp_out, "    %%pop/str 1; discard captured string\n");
		  draw_stmt_assign_vector_rhs(net, 8);
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string character selector\n",
		          mux_flag);
		  if (signal_is_return_value(var))
			fprintf(vvp_out, "    %%putc/ret/vec4 0, %d; string return character compound store\n",
			        mux_word);
		  else
			fprintf(vvp_out, "    %%putc/str/vec4 v%p_0, %d; string character compound store\n",
			        var, mux_word);
		  clr_word(mux_word);
		  clr_flag(mux_flag);
		  return 0;
	    }
	    /* Whole-string and string-array compound assignments remain separate
	     * unsupported forms. */
	    fprintf(stderr, "%s: warning: compound string assignment (op='%c') "
		    "not yet supported (compile-progress: skipped).\n",
		    ivl_stmt_file(net), ivl_stmt_opcode(net));
	    return 0;
      }

      if (ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
	    draw_array_pattern(var, rval, array_pattern_base_(lval));
	    return 0;
      }

	/* Special case: If the l-value signal (string) is named after
	   its scope, and the scope is a function, then this is an
	   assign to a return value and should be handled
	   differently. */
      if (signal_is_return_value(var) && ivl_signal_dimensions(var) == 0) {
	    if (part == 0 && aidx == 0) {
		  draw_eval_string(rval);
		  fprintf(vvp_out, "    %%ret/str 0; Assign to %s\n",
			  ivl_signal_basename(var));
		  return 0;
	    }
	    if (part && !aidx) {
		  int mux_word = allocate_word();
		  int mux_flag = allocate_flag();
		  draw_eval_vec4(part);
		  resize_vec4_wid(part, 32);
		  fprintf(vvp_out, "    %%cast2; string return character selector to int\n");
		  fprintf(vvp_out, "    %%ix/vec4/s %d; capture string return character selector\n",
		          mux_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve string return character selector\n",
		          mux_flag);
		  draw_eval_vec4(rval);
		  resize_vec4_wid(rval, 8);
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string return character selector\n",
		          mux_flag);
		  fprintf(vvp_out, "    %%putc/ret/vec4 0, %d; assign string return character\n",
		          mux_word);
		  clr_word(mux_word);
		  clr_flag(mux_flag);
		  return 0;
	    }
	    /* Compile-progress fallback: unsupported indexed string return
	       value is not materialized. Preserve side effects, then discard. */
	    draw_eval_string(rval);
	    fprintf(vvp_out, "    %%pop/str 1;\n");
	    if (aidx != 0) {
		  unsigned ix = allocate_word();
		  draw_eval_expr_into_integer(aidx, ix);
		  clr_word(ix);
	    }
	    if (part != 0) {
		  int mux_word = allocate_word();
		  draw_eval_expr_into_integer(part, mux_word);
		  clr_word(mux_word);
	    }
	    return 0;
      }

	/* Simplest case: no mux. Evaluate the r-value as a string and
	   store the result into the variable. Note that the
	   %store/str opcode pops the string result. */
      if (part == 0 && aidx == 0) {
	    draw_eval_string(rval);
	    fprintf(vvp_out, "    %%store/str v%p_0;\n", var);
	    return 0;
      }

	/* Assign to array. The l-value has an index expression
	   expression so we are assigning to an array word. */
      if (aidx != 0) {
	    unsigned ix;
	    if (part != 0) {
		  int word_index = allocate_word();
		  int word_flag = allocate_flag();
		  int character_index = allocate_word();
		  draw_eval_expr_into_integer(aidx, word_index);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve string array word selector\n",
		          word_flag);
		  /* A string CHARACTER selector is a signed two-state int. */
		  draw_eval_vec4(part);
		  resize_vec4_wid(part, 32);
		  fprintf(vvp_out, "    %%cast2; string array character selector to int\n");
		  fprintf(vvp_out, "    %%ix/vec4/s %d; capture string array character selector\n",
		          character_index);
		  draw_eval_vec4(rval);
		  resize_vec4_wid(rval, 8);
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string array word selector\n",
		          word_flag);
		  fprintf(vvp_out, "    %%putc/stra/vec4 v%p, %d, %d; assign string array character\n",
		          var, word_index, character_index);
		  clr_word(word_index);
		  clr_flag(word_flag);
		  clr_word(character_index);
		  return 0;
	    }
	    draw_eval_string(rval);
	    draw_eval_expr_into_integer(aidx, (ix = allocate_word()));
	    fprintf(vvp_out, "    %%store/stra v%p, %u;\n", var, ix);
	    clr_word(ix);
	    return 0;
      }

      draw_eval_vec4(rval);
      resize_vec4_wid(rval, 8);

	/* Calculate the character select for the word. */
      int mux_word = allocate_word();
      draw_eval_expr_into_integer(part, mux_word);

      fprintf(vvp_out, "    %%putc/str/vec4 v%p_0, %d;\n", var, mux_word);

      clr_word(mux_word);
      return 0;
}

/*
 * This function handles the special case that we assign an array
 * pattern to a dynamic array. Handle this by assigning each
 * element. The array pattern will have a fixed size.
 */
static int show_stmt_assign_darray_pattern(ivl_statement_t net)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);

      ivl_signal_t var = ivl_lval_sig(lval);
      ivl_type_t var_type= ivl_signal_net_type(var);
      assert(ivl_type_base(var_type) == IVL_VT_DARRAY);

      ivl_type_t element_type = ivl_type_element(var_type);
      unsigned idx;

        /* An unpacked-array concatenation is represented as an array pattern
         * whose collection operands retain the destination container type.
         * Its size is the sum of those runtime-sized operands plus its scalar
         * operands, not simply ivl_expr_parms(). Build it in a temporary
         * queue, then convert the queue to the declared dynamic-array type. */
      int has_collection_operand = 0;
      for (idx = 0; idx < ivl_expr_parms(rval); idx += 1) {
            if (queue_pattern_operand_is_collection_(
                        ivl_expr_parm(rval, idx), element_type)) {
                  has_collection_operand = 1;
                  break;
            }
      }

      if (has_collection_operand) {
            char enc[32];
            unsigned elem_wid = ivl_type_packed_width(element_type);
            stream_elem_type_text(element_type, enc, sizeof enc);
            fprintf(vvp_out, "    %%new/queue \"%s\"; darray concat builder\n",
                    enc);

            for (idx = 0; idx < ivl_expr_parms(rval); idx += 1) {
                  ivl_expr_t parm = ivl_expr_parm(rval, idx);
                  fprintf(vvp_out, "    %%dup/obj/ref; darray concat receiver\n");
                  if (queue_pattern_operand_is_collection_(parm, element_type)) {
                        errors += draw_eval_object(parm);
                        switch (ivl_type_base(element_type)) {
                            case IVL_VT_REAL:
                              fprintf(vvp_out, "    %%append/qo/r;\n");
                              break;
                            case IVL_VT_STRING:
                              fprintf(vvp_out, "    %%append/qo/str;\n");
                              break;
                            case IVL_VT_BOOL:
                            case IVL_VT_LOGIC:
                              fprintf(vvp_out, "    %%append/qo/v %u;\n",
                                      elem_wid);
                              break;
                            default:
                              emit_append_object_collection(element_type);
                              break;
                        }
                        continue;
                  }

                  switch (ivl_type_base(element_type)) {
                      case IVL_VT_REAL:
                        draw_eval_real(parm);
                        emit_object_queue_store_('b', "r",
                                                 queue_live_max_operand_(0), 0);
                        break;
                      case IVL_VT_STRING:
                        draw_eval_string(parm);
                        emit_object_queue_store_('b', "str",
                                                 queue_live_max_operand_(0), 0);
                        break;
                      case IVL_VT_BOOL:
                      case IVL_VT_LOGIC:
                        draw_eval_vec4(parm);
                        if (ivl_expr_width(parm) != elem_wid)
                              fprintf(vvp_out, "    %%pad/%c %u;\n",
                                      (ivl_type_signed(element_type)
                                       && ivl_expr_signed(parm)) ? 's' : 'u',
                                      elem_wid);
                        emit_object_queue_store_('b', "v",
                                                 queue_live_max_operand_(0),
                                                 elem_wid);
                        break;
                      default:
                        errors += draw_eval_object(parm);
                        emit_object_queue_store_('b', "obj",
                                                 queue_live_max_operand_(0), 0);
                        break;
                  }
            }

            fprintf(vvp_out, "    %%queue/to/darray \"%s\";\n", enc);
            if (ivl_type_base(element_type) == IVL_VT_NO_TYPE
                && ivl_type_properties(element_type) > 0) {
                  ensure_class_type_emitted(element_type);
                  fprintf(vvp_out,
                          "    %%new/cobj C%p; darray concat element prototype\n",
                          element_type);
                  fprintf(vvp_out, "    %%dar/elem/proto;\n");
            }
            fprintf(vvp_out, "    %%store/obj v%p_0;\n", var);
            return errors;
      }

        /* Build the complete value before replacing the destination object.
         * This is not just an optimization: `a = a[0:1]' reads from the old
         * dynamic array, so allocating/storing the destination first destroys
         * the receiver of every element select. The context-aware object
         * evaluator turns the fixed unpacked-array pattern into a temporary
         * dynamic array and applies the normal element value-copy policy. */
      assert(ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN);
      errors += draw_eval_object_value_copy(rval, var_type);
      fprintf(vvp_out, "    %%store/obj v%p_0; complete darray pattern\n", var);
      return errors;
}

/*
 * Loading an element and updating it is identical for queues and dynamic arrays
 * and is handled here. The updated value is left on the stack and will be
 * written back using type specific functions.
 */
static void show_stmt_assign_sig_darray_queue_mux(ivl_statement_t net)
{
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_signal_t var = ivl_lval_sig(lval);
      ivl_type_t var_type = ivl_signal_net_type(var);
      ivl_type_t element_type = ivl_type_element(var_type);
      ivl_expr_t mux  = ivl_lval_idx(lval);
      ivl_expr_t rval = ivl_stmt_rval(net);

      /*
       * Queue and dynamic array load and store functions expect the element
       * address in index register 3. The index expression must only be
       * evaluated once. So in case of an assignment operator it is moved to a
       * scratch register and restored to the index register once the rvalue has
       * been evaluated.
       */

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    if (ivl_stmt_opcode(net) != 0) {
		  int mux_word = allocate_word();
		  int flag = allocate_flag();

		  draw_eval_expr_into_integer(mux, 3);
		  fprintf(vvp_out, "    %%ix/mov %d, 3;\n", mux_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag);
		  fprintf(vvp_out, "    %%load/dar/r v%p_0;\n", var);
		  draw_eval_real(rval);
		  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", flag);
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", mux_word);
		  clr_flag(flag);
		  clr_word(mux_word);
	    } else {
		  draw_eval_real(rval);
		  draw_eval_expr_into_integer(mux, 3);
	    }
	    break;
	  case IVL_VT_STRING:
	    assert(ivl_stmt_opcode(net) == 0);
	    draw_eval_string(rval);
	    draw_eval_expr_into_integer(mux, 3);
	    break;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    if (ivl_stmt_opcode(net) != 0) {
		  int mux_word = allocate_word();
		  int flag = allocate_flag();

		  draw_eval_expr_into_integer(mux, 3);
		  fprintf(vvp_out, "    %%ix/mov %d, 3;\n", mux_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag);
		  fprintf(vvp_out, "    %%load/dar/vec4 v%p_0;\n", var);
		  draw_stmt_assign_vector_rhs(net, ivl_stmt_lwidth(net));
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", flag);
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", mux_word);
		  clr_flag(flag);
		  clr_word(mux_word);
	    } else {
		  draw_eval_vec4(rval);
		  resize_vec4_wid(rval, ivl_stmt_lwidth(net));
		  draw_eval_expr_into_integer(mux, 3);
		    }
		    break;
	  case IVL_VT_NO_TYPE:
		    assert(ivl_stmt_opcode(net) == 0);
		      /* %store/dar/obj below copies value-semantic elements;
			 evaluate the RHS only once and leave that copy to runtime. */
		    draw_eval_object(rval);
		    draw_eval_expr_into_integer(mux, 3);
		    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
		    assert(ivl_stmt_opcode(net) == 0);
		    if (draw_eval_container_value_for_target(rval,
							 element_type) < 0)
			  draw_eval_object(rval);
		    draw_eval_expr_into_integer(mux, 3);
		    break;
	  default:
		    assert(ivl_stmt_opcode(net) == 0);
		    draw_eval_object(rval);
		    draw_eval_expr_into_integer(mux, 3);
	    break;
      }
}

/* A packed concatenation may select several dynamic-array elements. */
static int show_stmt_assign_concat_darray_(ivl_statement_t net)
{
      unsigned lvals = ivl_stmt_lvals(net);
      unsigned has_darray = 0;
      if (lvals < 2)
            return -1;
      for (unsigned i = 0; i < lvals; i += 1) {
            ivl_signal_t sig = ivl_lval_sig(ivl_stmt_lval(net, i));
            if (sig && ivl_signal_data_type(sig) == IVL_VT_DARRAY)
                  has_darray = 1;
      }
      if (!has_darray)
            return -1;

      /* Validate the entire destination before emitting any stores. */
      for (unsigned i = 0; i < lvals; i += 1) {
            ivl_lval_t lval = ivl_stmt_lval(net, i);
            ivl_signal_t sig = ivl_lval_sig(lval);
            ivl_type_t container = sig ? ivl_signal_net_type(sig) : 0;
            ivl_type_t element = container ? ivl_type_element(container) : 0;
            ivl_variable_type_t kind = element ? ivl_type_base(element) : IVL_VT_NO_TYPE;
            if (ivl_stmt_opcode(net) != 0 || !sig
                || ivl_signal_data_type(sig) != IVL_VT_DARRAY
                || ivl_signal_dimensions(sig) != 0
                || !ivl_lval_idx(lval) || ivl_lval_part_off(lval)
                || ivl_lval_nest(lval) || ivl_lval_property_idx(lval) >= 0
                || (kind != IVL_VT_BOOL && kind != IVL_VT_LOGIC)
                || ivl_lval_width(lval) != ivl_type_packed_width(element)) {
                  fprintf(stderr, "%s:%u: sorry: this dynamic-array "
                          "concatenation destination is not yet supported.\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net));
                  return 1;
            }
      }

      draw_eval_vec4(ivl_stmt_rval(net));
      resize_vec4_wid(ivl_stmt_rval(net), ivl_stmt_lwidth(net));
      for (unsigned i = 0; i < lvals; i += 1) {
            ivl_lval_t lval = ivl_stmt_lval(net, i);
            ivl_signal_t sig = ivl_lval_sig(lval);
            if (i + 1 < lvals)
                  fprintf(vvp_out, "    %%split/vec4 %u;\n", ivl_lval_width(lval));
            draw_eval_expr_into_integer(ivl_lval_idx(lval), 3);
            fprintf(vvp_out, "    %%store/dar/vec4 v%p_0;\n", sig);
      }
      return 0;
}

static int show_stmt_assign_sig_darray(ivl_statement_t net)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t part = ivl_lval_part_off(lval);
      ivl_signal_t var= ivl_lval_sig(lval);
      ivl_type_t var_type= ivl_signal_net_type(var);
      assert(ivl_type_base(var_type) == IVL_VT_DARRAY);
      ivl_type_t element_type = ivl_type_element(var_type);

      assert(ivl_stmt_lvals(net) == 1);

	/* A fixed unpacked prefix around a dynamic-array leaf is represented by
	 * object-array storage. Its sole direct l-value index selects the fixed
	 * WORD, not an element inside a scalar darray v<sig>_0. Replace that whole
	 * word with an independently copied, destination-typed container value. */
      if (ivl_signal_dimensions(var) > 0 && !ivl_lval_nest(lval)) {
	    ivl_expr_t word_expr = ivl_lval_idx(lval);
	    if (!word_expr || part || ivl_stmt_opcode(net) != 0) {
		  fprintf(stderr, "%s:%u: sorry: a fixed unpacked-array slot "
			  "containing a dynamic array requires a simple "
			  "whole-container assignment.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }

	    int converted = draw_eval_container_value_for_target(rval, var_type);
	    if (converted >= 0)
		  errors += converted;
	    else
		  errors += draw_eval_object_value_copy(rval, var_type);
	    int word = allocate_word();
	    draw_eval_expr_into_integer(word_expr, word);
	    note_array_signal_use(var);
	    fprintf(vvp_out,
		    "    %%store/obja v%p, %d; fixed-array darray slot\n",
		    var, word);
	    clr_word(word);
	    return errors;
      }

	/* Part/bit-select store into a dynamic-array (or queue) element
	   whose base type is a packed vector: d[i][off +: wid] = rhs. Lower
	   as a read-modify-write with %store/dar/vec4/off. The element-
	   relative offset expression (already normalized during elaboration)
	   is evaluated into an integer register, so a run-time-variable bit
	   index works. Non-vector elements or compound assignments fall to
	   the loud sorry below. */
      if (part != 0 && ivl_lval_idx(lval) && ivl_stmt_opcode(net) == 0
	  && (ivl_type_base(element_type) == IVL_VT_BOOL
	      || ivl_type_base(element_type) == IVL_VT_LOGIC)) {
	    ivl_expr_t mux = ivl_lval_idx(lval);
	    unsigned lwid = ivl_lval_width(lval);
	    int mux_word = allocate_word();
	    int off_word = allocate_word();
	    int flag = allocate_flag();

	      /* Evaluate the element address into reg 3, then stash it (and
		 the address-undefined flag 4) across the offset and r-value
		 evaluations, which may clobber both. */
	    draw_eval_expr_into_integer(mux, 3);
	    fprintf(vvp_out, "    %%ix/mov %d, 3;\n", mux_word);
	    fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag);
	    draw_eval_expr_into_integer(part, off_word);
	    draw_eval_vec4(rval);
	    resize_vec4_wid(rval, lwid);
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", flag);
	    fprintf(vvp_out, "    %%ix/mov 3, %d;\n", mux_word);
	    fprintf(vvp_out, "    %%store/dar/vec4/off v%p_0, %d, %u;\n",
		    var, off_word, lwid);
	    clr_flag(flag);
	    clr_word(off_word);
	    clr_word(mux_word);
	    return errors;
      }

      if (part != 0) {
	      /* A darray/queue element part-select we cannot lower yet
		 (non-vector element or a compound assignment). Loud sorry —
		 never a silent wrong store. */
	    fprintf(stderr, "%s:%u: sorry: assignment to this dynamic-array "
		    "element part-select form is not yet supported.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    fprintf(vvp_out, "; ERROR: unsupported darray element part-select "
		    "l-value.\n");
	    return errors + 1;
      }

      if (ivl_lval_idx(lval)) {
	    show_stmt_assign_sig_darray_queue_mux(net);
	    switch (ivl_type_base(element_type)) {
		case IVL_VT_REAL:
		  fprintf(vvp_out, "    %%store/dar/r v%p_0;\n", var);
		  break;
		case IVL_VT_STRING:
		  fprintf(vvp_out, "    %%store/dar/str v%p_0;\n", var);
		  break;
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  fprintf(vvp_out, "    %%store/dar/vec4 v%p_0;\n", var);
		  break;
		case IVL_VT_CLASS:
		case IVL_VT_DARRAY:
		case IVL_VT_QUEUE:
		case IVL_VT_NO_TYPE:
		  fprintf(vvp_out, "    %%store/dar/obj v%p_0;\n", var);
		  break;
	    default:
		  fprintf(vvp_out, "    %%store/dar/obj v%p_0;\n", var);
		  break;
	    }
      } else if (ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
	    assert(ivl_stmt_opcode(net) == 0);
	      /* There is no l-value mux, but the r-value is an array
		 pattern. This is a special case of an assignment to
		 elements of the l-value. */
	    errors += show_stmt_assign_darray_pattern(net);

      } else if (ivl_expr_type(rval) == IVL_EX_NEW) {
	    assert(ivl_stmt_opcode(net) == 0);
	    // There is no l-value mux, and the r-value expression is
	    // a "new" expression. Handle this by simply storing the
	    // new object to the lval.
	    errors += draw_eval_object(rval);
	    fprintf(vvp_out, "    %%store/obj v%p_0; %s:%u: %s = new ...\n",
		    var, ivl_stmt_file(net), ivl_stmt_lineno(net),
		    ivl_signal_basename(var));

      } else if (ivl_expr_type(rval) == IVL_EX_SIGNAL
		 || ivl_expr_type(rval) == IVL_EX_PROPERTY) {
	    assert(ivl_stmt_opcode(net) == 0);
	    int converted = draw_eval_container_value_for_target(rval,
							    var_type);
	    if (converted >= 0) {
		  errors += converted;
		  fprintf(vvp_out,
			  "    %%store/obj v%p_0; %s:%u: %s = <converted container>\n",
			  var, ivl_stmt_file(net), ivl_stmt_lineno(net),
			  ivl_signal_basename(var));
		  return errors;
	    }

	    // There is no l-value mux, and the r-value expression is
	    // a "signal" (or class-property) expression, i.e. a live
	    // handle to existing storage. Store a duplicate into the
	    // lvalue by using the %dup/obj. Remember to pop the rvalue
	    // that is no longer needed.
	    //
	    // A whole fixed-array struct member passed to an open-array
	    // formal still needs the /open store so the DUPLICATE adopts
	    // the actual's declared-index view (the range metadata rides
	    // along on the duplicate).
	    int fixed_open_actual =
		  ivl_signal_port(var) != IVL_SIP_NONE
		  && ivl_scope_is_dpi_import(ivl_signal_scope(var))
		  && vvp_expr_is_fixed_uarray_value(rval);
	    errors += draw_eval_object(rval);
	    fprintf(vvp_out, "    %%dup/obj;\n");
	    fprintf(vvp_out, "    %%store/obj%s v%p_0; %s:%u: %s = <signal>\n",
		    fixed_open_actual ? "/open" : "",
		    var, ivl_stmt_file(net), ivl_stmt_lineno(net),
		    ivl_signal_basename(var));
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

      } else {
	    assert(ivl_stmt_opcode(net) == 0);
	    // There is no l-value mux, so this must be an
	    // assignment to the array as a whole. Evaluate the
	    // "object", copy any selected value-container result, and store the
	    // independent value. SELECT nodes are live element aliases in VVP.
	    int converted = draw_eval_container_value_for_target(rval,
							    var_type);
	    if (converted >= 0)
		  errors += converted;
	    else
		  errors += draw_eval_object_value_copy(rval, var_type);
	    int fixed_open_actual =
		  ivl_signal_port(var) != IVL_SIP_NONE
		  && ivl_scope_is_dpi_import(ivl_signal_scope(var))
		  && vvp_expr_is_fixed_uarray_value(rval);
	    fprintf(vvp_out, "    %%store/obj%s v%p_0; %s:%u: %s = <expr type %d>\n",
		    fixed_open_actual ? "/open" : "",
		    var, ivl_stmt_file(net), ivl_stmt_lineno(net),
		    ivl_signal_basename(var), ivl_expr_type(rval));
      }

      return errors;
}

/*
 * This function handles the special case that we assign an array
 * pattern or unpacked-array concatenation to a queue. Evaluate it as a
 * complete queue value before copying it into the destination; collection
 * operands can make the resulting size depend on run-time state.
 */
static int show_stmt_assign_queue_pattern(ivl_signal_t var, ivl_expr_t rval,
                                          ivl_type_t element_type, int max_idx)
{
      int errors = 0;
      assert(ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN);

      /* Evaluate the complete right-hand concatenation into fresh queue
       * storage before changing the destination. This is required even
       * when every operand is scalar: an operand may read the destination
       * queue, and assignment must not expose partially written elements.
       * The object-context evaluator visits every operand exactly once and
       * appends its result in source order, splicing collection operands into
       * the fresh builder. The final whole-queue copy applies the destination
       * bound once. */
      errors += draw_eval_object_value_copy(rval, ivl_signal_net_type(var));
      switch (ivl_type_base(element_type)) {
          case IVL_VT_BOOL:
          case IVL_VT_LOGIC:
            fprintf(vvp_out, "    %%store/qobj/v v%p_0, %d, %u;\n",
                    var, max_idx, ivl_type_packed_width(element_type));
            break;
          case IVL_VT_REAL:
            fprintf(vvp_out, "    %%store/qobj/r v%p_0, %d;\n",
                    var, max_idx);
            break;
          case IVL_VT_STRING:
            fprintf(vvp_out, "    %%store/qobj/str v%p_0, %d;\n",
                    var, max_idx);
            break;
          default:
            fprintf(vvp_out, "    %%store/qobj/obj v%p_0, %d;\n",
                    var, max_idx);
            break;
      }

      return errors;
}

/* The elaborator represents an associative-array `'{default: value}' whole
 * assignment as an internal system-function node. Keeping the marker typed as
 * the destination container prevents ordinary assignment compatibility from
 * degrading it to a scalar. Direct assignments recognize it here; ordinary
 * object-valued expression contexts recognize the same marker in
 * eval_object_sfunc(). */
static int expr_is_assoc_default_(ivl_expr_t expr)
{
      return expr
	  && ivl_expr_type(expr) == IVL_EX_SFUNC
	  && ivl_expr_name(expr)
	  && strcmp(ivl_expr_name(expr), "$ivl_assoc_default") == 0
	  && ivl_expr_parms(expr) == 1;
}

/* A variable-size pattern item is evaluated before the new associative map
 * has its destination fixed-child layout. If its size is wrong, replacing
 * the map would discard existing keys before a run-time check can reject it.
 * Keep this legal 7.6 form as an explicit unsupported compile boundary until
 * pattern installation can be validated transactionally. Ordinary keyed
 * dynamic/queue-to-fixed assignments are checked at run time. */
static int reject_variable_fixed_assoc_pattern_value_(ivl_expr_t marker,
						 ivl_expr_t value)
{
      ivl_type_t source = receiver_container_type_(value);
      ivl_variable_type_t base = source ? ivl_type_base(source)
	    : IVL_VT_NO_TYPE;
      if (base != IVL_VT_DARRAY
	  && (base != IVL_VT_QUEUE
	      || ivl_type_queue_assoc_compat(source)))
	    return 0;
      fprintf(stderr, "%s:%u: error: a dynamic-array or queue value in "
	      "an associative fixed-array pattern is not yet supported\n",
	      ivl_expr_file(marker), ivl_expr_lineno(marker));
      return 1;
}

/* Evaluate the sentinel's sole value in its declared element category, then
 * construct a fresh typed associative-array object carrying that default.
 * The fresh object is left on the object stack for an ordinary signal/property
 * store. This ordering is essential when RHS side effects replace the same
 * array: no destination container is captured until the RHS is complete. */
int draw_eval_assoc_default(ivl_expr_t marker, ivl_type_t element_type)
{
      int errors = 0;
      ivl_expr_t value = ivl_expr_parm(marker, 0);

      if (type_is_fixed_uarray_property_(element_type)) {
            if (reject_variable_fixed_assoc_pattern_value_(marker, value))
		  return 1;
            errors += draw_eval_object_value_copy(value, element_type);
            fprintf(vvp_out, "    %%aa/new/default/obj;\n");
            return errors;
      }

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    draw_eval_real(value);
	    fprintf(vvp_out, "    %%aa/new/default/r;\n");
	    break;
	  case IVL_VT_STRING:
	    draw_eval_string(value);
	    fprintf(vvp_out, "    %%aa/new/default/str;\n");
	    break;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC: {
	    unsigned wid = ivl_type_packed_width(element_type);
	    draw_eval_vec4(value);
	    resize_vec4_wid(value, wid);
	    if (ivl_type_base(element_type) == IVL_VT_BOOL
		&& ivl_expr_value(value) != IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    fprintf(vvp_out, "    %%aa/new/default/v %u;\n", wid);
	    break;
	  }
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    {
	      int converted = draw_eval_container_value_for_target(
		    value, element_type);
	      if (converted >= 0)
		    errors += converted;
	      else if (ivl_expr_type(value) == IVL_EX_ARRAY_PATTERN
		&& (ivl_type_base(element_type) == IVL_VT_DARRAY
		    || ivl_type_base(element_type) == IVL_VT_QUEUE))
		    errors += draw_eval_object_value_copy(value, element_type);
	      else
		    errors += draw_eval_object(value);
	    }
	    fprintf(vvp_out, "    %%aa/new/default/obj;\n");
	    break;
	  default:
	    fprintf(stderr, "%s:%u: internal error: unsupported associative "
		    "default element type %d\n",
		    ivl_expr_file(marker), ivl_expr_lineno(marker),
		    (int)ivl_type_base(element_type));
	    fprintf(vvp_out, "    %%null; ; unsupported associative default type\n");
	    errors += 1;
	    break;
      }

      return errors;
}

/* Read one frontend-generated associative-pattern item tag without executing
 * it. The complete marker is preflighted before a builder or any user
 * expression is evaluated, so a malformed netlist cannot expose a partial
 * literal value. NetEConst normally reaches the target as IVL_EX_NUMBER, but
 * accept the target API's immediate form as well. */
static int assoc_pattern_item_kind_(ivl_expr_t expr, unsigned*kind)
{
      unsigned idx;
      unsigned wid;
      const char*bits;

      if (!expr || !kind)
	    return 0;

      if (ivl_expr_type(expr) == IVL_EX_ULONG) {
	    uint64_t value = ivl_expr_uvalue(expr);
	    if (value > 1)
		  return 0;
	    *kind = (unsigned)value;
	    return 1;
      }

      if (ivl_expr_type(expr) != IVL_EX_NUMBER || number_is_unknown(expr))
	    return 0;

      wid = ivl_expr_width(expr);
      bits = ivl_expr_bits(expr);
      if (!bits || wid == 0)
	    return 0;

      *kind = bits[0] == '1' ? 1 : 0;
      for (idx = 1; idx < wid; idx += 1)
	    if (bits[idx] != '0')
		  return 0;

      return bits[0] == '0' || bits[0] == '1';
}

static int assoc_pattern_object_value_(ivl_expr_t value,
				       ivl_type_t element_type)
{
      int converted = draw_eval_container_value_for_target(value,
						    element_type);
      if (converted >= 0)
	    return converted;

      if (ivl_expr_type(value) == IVL_EX_ARRAY_PATTERN
	  && (ivl_type_base(element_type) == IVL_VT_DARRAY
	      || ivl_type_base(element_type) == IVL_VT_QUEUE))
	    return draw_eval_object_value_copy(value, element_type);

      return draw_eval_object(value);
}

/* Emit one value and its typed map mutation. The receiver builder remains on
 * the object stack. Existing %aa/store operations copy array-like values into
 * entries; the new default setter applies the same policy without clearing
 * entries that appeared earlier in source order. */
static int draw_assoc_pattern_value_(ivl_expr_t marker, ivl_expr_t value,
				     ivl_type_t element_type,
				     const char*key_kind, int is_default)
{
      int errors = 0;
      const char*operation = is_default ? "set/default" : "store";

      if (type_is_fixed_uarray_property_(element_type)) {
	    if (reject_variable_fixed_assoc_pattern_value_(marker, value))
		  return 1;
	    errors += assoc_pattern_object_value_(value, element_type);
	    if (is_default)
		  fprintf(vvp_out, "    %%aa/%s/obj;\n", operation);
	    else
		  fprintf(vvp_out, "    %%aa/%s/obj/%s;\n",
			  operation, key_kind);
	    return errors;
      }

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    draw_eval_real(value);
	    if (is_default)
		  fprintf(vvp_out, "    %%aa/%s/r;\n", operation);
	    else
		  fprintf(vvp_out, "    %%aa/%s/r/%s;\n", operation, key_kind);
	    break;

	  case IVL_VT_STRING:
	    draw_eval_string(value);
	    if (is_default)
		  fprintf(vvp_out, "    %%aa/%s/str;\n", operation);
	    else
		  fprintf(vvp_out, "    %%aa/%s/str/%s;\n", operation, key_kind);
	    break;

	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC: {
	    unsigned wid = ivl_type_packed_width(element_type);
	    if (wid == 0) {
		  fprintf(stderr, "%s:%u: internal error: zero-width integral "
			  "associative-array pattern element\n",
			  ivl_expr_file(marker), ivl_expr_lineno(marker));
		  return 1;
	    }
	    draw_eval_vec4(value);
	    resize_vec4_wid(value, wid);
	    if (ivl_type_base(element_type) == IVL_VT_BOOL
		&& ivl_expr_value(value) != IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    if (is_default)
		  fprintf(vvp_out, "    %%aa/%s/v %u;\n", operation, wid);
	    else
		  fprintf(vvp_out, "    %%aa/%s/v/%s %u;\n",
			  operation, key_kind, wid);
	    break;
	  }

	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    errors += assoc_pattern_object_value_(value, element_type);
	    if (is_default)
		  fprintf(vvp_out, "    %%aa/%s/obj;\n", operation);
	    else
		  fprintf(vvp_out, "    %%aa/%s/obj/%s;\n", operation, key_kind);
	    break;

	  default:
	    fprintf(stderr, "%s:%u: internal error: unsupported associative "
		    "pattern element type %d\n",
		    ivl_expr_file(marker), ivl_expr_lineno(marker),
		    (int)ivl_type_base(element_type));
	    errors += 1;
	    break;
      }

      return errors;
}

/* Materialize a nonempty associative-array literal into a fresh typed map.
 * Parameters are source-ordered (kind,key,value) triplets: kind 0 denotes an
 * explicit entry and kind 1 denotes default. Default's key is a dummy carrier
 * and is deliberately not evaluated. */
int draw_eval_assoc_pattern(ivl_expr_t marker, ivl_type_t element_type)
{
      ivl_type_t assoc_type = ivl_expr_net_type(marker);
      unsigned default_count = 0;
      unsigned parm_count = ivl_expr_parms(marker);
      unsigned parm;
      int errors = 0;

      if (!assoc_type || !element_type || parm_count == 0
	  || (parm_count % 3) != 0
	  || ivl_type_base(assoc_type) != IVL_VT_QUEUE
	  || !ivl_type_queue_assoc_compat(assoc_type))
	    goto malformed;

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	  case IVL_VT_STRING:
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    break;
	  default:
	    goto malformed;
      }

      for (parm = 0; parm < parm_count; parm += 3) {
	    unsigned kind;
	    ivl_expr_t kind_expr = ivl_expr_parm(marker, parm);
	    ivl_expr_t key_expr = ivl_expr_parm(marker, parm + 1);
	    ivl_expr_t value_expr = ivl_expr_parm(marker, parm + 2);

	    if (!assoc_pattern_item_kind_(kind_expr, &kind)
		|| !key_expr || !value_expr)
		  goto malformed;
	    if (kind == 1 && ++default_count > 1)
		  goto malformed;
	    if (kind == 0 && ivl_expr_value(key_expr) == IVL_VT_REAL)
		  goto malformed;
      }

      fprintf(vvp_out, "    %%new/queue \"@%u\"; associative pattern builder\n",
	      nested_queue_spec_(assoc_type));

      for (parm = 0; parm < parm_count; parm += 3) {
	    unsigned kind;
	    ivl_expr_t key_expr = ivl_expr_parm(marker, parm + 1);
	    ivl_expr_t value_expr = ivl_expr_parm(marker, parm + 2);
	    assoc_pattern_item_kind_(ivl_expr_parm(marker, parm), &kind);

	    if (kind == 1) {
		  errors += draw_assoc_pattern_value_(marker, value_expr,
					       element_type, 0, 1);
	    } else {
		  const char*key_kind = draw_eval_assoc_key_(key_expr, &errors);
		  errors += draw_assoc_pattern_value_(marker, value_expr,
					       element_type, key_kind, 0);
	    }
      }

      return errors;

malformed:
      fprintf(stderr, "%s:%u: internal error: malformed typed "
	      "associative-array pattern marker\n",
	      ivl_expr_file(marker), ivl_expr_lineno(marker));
      fprintf(vvp_out, "    %%null; ; malformed associative pattern marker\n");
      return 1;
}

/* Store into the existing suffix selected by q[lo:$].  The l-value API bit
 * is essential here: ivl_lval_idx alone also denotes q[lo], whose assignment
 * is an element store with append-at-size behavior.  A suffix-slice store is
 * instead an exact-cardinality, no-resize operation.  The runtime opcode
 * validates the dynamic bound and source size atomically before copying. */
static int show_stmt_assign_sig_queue_slice(ivl_statement_t net,
					     ivl_lval_t lval,
					     ivl_signal_t var,
					     ivl_type_t element_type)
{
      int errors = 0;
      ivl_expr_t lo = ivl_lval_idx(lval);
      ivl_expr_t rval = ivl_stmt_rval(net);

      if (ivl_stmt_opcode(net) != 0) {
	    fprintf(stderr, "%s:%u: sorry: compound assignment to a queue "
		    "suffix slice is not supported.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }
      if (!lo) {
	    fprintf(stderr, "%s:%u: internal error: queue suffix-slice "
		    "l-value has no lower bound.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }

      /* Match ordinary blocking container assignment evaluation: form the
	 * complete RHS value first, then evaluate the l-value index exactly once.
	 * IEEE 1800-2017/2023 7.6 permits an equivalent-element dynamic array
	 * here, but %store/qslice dispatches by the destination queue's concrete
	 * runtime element class. Materialize a destination-typed queue before the
	 * store so the outer container kind does not leak into that dispatch.
	 * Keeping the RHS on the object stack is safe across the scalar bound
	 * evaluation and lets the runtime take a full snapshot before mutation. */
      int converted = draw_eval_container_value_for_target(
	    rval, ivl_signal_net_type(var));
      if (converted >= 0)
	    errors += converted;
      else
	    errors += draw_eval_object(rval);
      int lo_word = allocate_word();
      draw_eval_expr_into_integer(lo, lo_word);

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    fprintf(vvp_out, "    %%store/qslice/v v%p_0, %d, %u;\n",
		    var, lo_word, ivl_type_packed_width(element_type));
	    break;
	  case IVL_VT_REAL:
	    fprintf(vvp_out, "    %%store/qslice/r v%p_0, %d;\n",
		    var, lo_word);
	    break;
	  case IVL_VT_STRING:
	    fprintf(vvp_out, "    %%store/qslice/str v%p_0, %d;\n",
		    var, lo_word);
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	  default:
	    fprintf(vvp_out, "    %%store/qslice/obj v%p_0, %d;\n",
		    var, lo_word);
	    break;
      }

      clr_word(lo_word);
      return errors;
}

static int show_stmt_assign_sig_queue(ivl_statement_t net)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t part = ivl_lval_part_off(lval);
      ivl_signal_t var= ivl_lval_sig(lval);
      ivl_type_t var_type= ivl_signal_net_type(var);
      ivl_type_t element_type = ivl_type_element(var_type);

      assert(ivl_stmt_lvals(net) == 1);

	/* A signal-backed fixed unpacked prefix around a queue/associative
	 * leaf is emitted as an object array. The sole l-value index here selects
	 * the OUTER fixed word; it is not a queue offset or associative key.
	 * Materialize and value-copy the complete RHS before replacing that word,
	 * preserving the same atomic whole-container assignment used by scalar
	 * maps. Nested element assignments retain their separate l-value chain and
	 * do not enter this whole-slot path. */
      if (ivl_signal_dimensions(var) > 0 && !ivl_lval_nest(lval)) {
	    ivl_expr_t word_expr = ivl_lval_idx(lval);
	    if (!word_expr || part || ivl_stmt_opcode(net) != 0) {
		  fprintf(stderr, "%s:%u: sorry: a fixed unpacked-array slot "
			  "containing a queue or associative array requires a simple "
			  "whole-container assignment.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }

	    int converted = draw_eval_container_value_for_target(rval,
							    var_type);
	    if (converted >= 0)
		  errors += converted;
	    else
		  errors += draw_eval_object_value_copy(rval, var_type);
	    int word = allocate_word();
	    draw_eval_expr_into_integer(word_expr, word);
	    note_array_signal_use(var);
	    fprintf(vvp_out,
		    "    %%store/obja v%p, %d; fixed-array container slot\n",
		    var, word);
	    clr_word(word);
	    return errors;
      }

      if (ivl_lval_is_queue_slice(lval))
	    return show_stmt_assign_sig_queue_slice(net, lval, var,
					       element_type);

	/* Part/bit-select store into an ASSOCIATIVE-array element
	   (am[key][m:l] = v; packed-struct member writes are lowered by
	   elaboration to the member's bit range). The numeric-index queue
	   path below coerces the key to an integer element address, which
	   corrupted the store ("cannot write to an undefined darray").
	   Lower as an assoc RMW instead: load the element keeping the key,
	   merge the value at the bit offset (%setbits/vec4), store back. */
      if (part != 0 && ivl_lval_idx(lval) && ivl_stmt_opcode(net) == 0
	  && ivl_type_queue_assoc_compat(var_type)
	  && (ivl_type_base(element_type) == IVL_VT_BOOL
	      || ivl_type_base(element_type) == IVL_VT_LOGIC)) {
	    ivl_expr_t key = ivl_lval_idx(lval);
	    unsigned lwid = ivl_lval_width(lval);
	    unsigned elem_wid = ivl_type_packed_width(element_type);
	    const char*key_kind;
	    int key_is_object = expr_is_object_assoc_key_(key);
	    int key_is_string = expr_is_string_assoc_key_(key);

	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", var);
	    if (key_is_string) {
		  key_kind = "str";
		  draw_eval_string(key);
	    } else if (key_is_object) {
		  key_kind = "obj";
		  errors += draw_eval_object(key);
	    } else {
		  key_kind = "v";
		  draw_eval_vec4(key);
	    }
	    fprintf(vvp_out, "    %%aa/loadk/v/%s %u;\n", key_kind, elem_wid);

	    int off_word = allocate_word();
	    int off_flag = allocate_flag();
	    draw_eval_expr_into_integer(part, off_word);
	    fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
	    draw_eval_vec4(rval);
	    resize_vec4_wid(rval, lwid);
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
	    fprintf(vvp_out, "    %%setbits/vec4/x %d, %u;\n",
		    off_word, lwid);
	    clr_word(off_word);
	    clr_flag(off_flag);
	    fprintf(vvp_out, "    %%aa/store/v/%s %u;\n", key_kind, elem_wid);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    return errors;
      }

	/* Part/bit-select store into a queue element that is a packed
	   vector: q[i][off +: wid] = rhs. Same read-modify-write lowering as
	   for dynamic arrays (%store/dar/vec4/off operates on the shared
	   vvp_darray base, which queues subclass). */
      if (part != 0 && ivl_lval_idx(lval) && ivl_stmt_opcode(net) == 0
	  && (ivl_type_base(element_type) == IVL_VT_BOOL
	      || ivl_type_base(element_type) == IVL_VT_LOGIC)) {
	    ivl_expr_t mux = ivl_lval_idx(lval);
	    unsigned lwid = ivl_lval_width(lval);
	    int mux_word = allocate_word();
	    int off_word = allocate_word();
	    int flag = allocate_flag();

	    draw_eval_expr_into_integer(mux, 3);
	    fprintf(vvp_out, "    %%ix/mov %d, 3;\n", mux_word);
	    fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag);
	    draw_eval_expr_into_integer(part, off_word);
	    draw_eval_vec4(rval);
	    resize_vec4_wid(rval, lwid);
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", flag);
	    fprintf(vvp_out, "    %%ix/mov 3, %d;\n", mux_word);
	    fprintf(vvp_out, "    %%store/dar/vec4/off v%p_0, %d, %u;\n",
		    var, off_word, lwid);
	    clr_flag(flag);
	    clr_word(off_word);
	    clr_word(mux_word);
	    return errors;
      }

      if (part != 0) {
	    fprintf(stderr, "%s:%u: sorry: assignment to this queue element "
		    "part-select form is not yet supported.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    fprintf(vvp_out, "; ERROR: unsupported queue element part-select "
		    "l-value.\n");
	    return errors + 1;
      }

      assert(ivl_type_base(var_type) == IVL_VT_QUEUE);

      int idx = allocate_word();
      assert(idx >= 0);
        /* Save the queue maximum index value to an integer register. */
      fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", idx, ivl_signal_array_count(var));

      if (ivl_type_queue_assoc_compat(var_type)
	  && !ivl_lval_idx(lval)
	  && expr_is_assoc_default_(rval)) {
	    assert(ivl_stmt_opcode(net) == 0);
	    errors += draw_eval_assoc_default(rval, element_type);
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", var);
	    clr_word(idx);
	    return errors;

      } else if (ivl_expr_type(rval) == IVL_EX_NULL) {
	    assert(ivl_stmt_opcode(net) == 0);
	    errors += draw_eval_object(rval);
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", var);

      } else if (ivl_lval_idx(lval)) {
            if (ivl_type_queue_assoc_compat(var_type)) {
                  int handled_errors = show_stmt_assign_sig_assoc_index(net, var, var_type);
                  if (handled_errors >= 0) {
                        clr_word(idx);
                        return errors + handled_errors;
                  }
            }
	    show_stmt_assign_sig_darray_queue_mux(net);
	    switch (ivl_type_base(element_type)) {
		case IVL_VT_REAL:
		  fprintf(vvp_out, "    %%store/qdar/r v%p_0, %d;\n", var, idx);
		  break;
		case IVL_VT_STRING:
		  fprintf(vvp_out, "    %%store/qdar/str v%p_0, %d;\n", var, idx);
		  break;
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  fprintf(vvp_out, "    %%store/qdar/v v%p_0, %d, %u;\n", var, idx,
	                     ivl_type_packed_width(element_type));
		  break;
		case IVL_VT_CLASS:
		case IVL_VT_DARRAY:
		case IVL_VT_QUEUE:
		case IVL_VT_NO_TYPE:
		  fprintf(vvp_out, "    %%store/qdar/obj v%p_0, %d;\n", var, idx);
		  break;
	    default:
		  fprintf(vvp_out, "    %%store/qdar/obj v%p_0, %d;\n", var, idx);
		  break;
	    }
      } else if (ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
	    assert(ivl_stmt_opcode(net) == 0);

	      /* There is no l-value mux, but the r-value is an array
		 pattern. This is a special case of an assignment to
		 the l-value. */
	    errors += show_stmt_assign_queue_pattern(var, rval, element_type, idx);

      } else {
	    assert(ivl_stmt_opcode(net) == 0);

	      /* There is no l-value mux, so this must be an
		 assignment to the array as a whole. Evaluate the
		 "object", and store the evaluated result. */
	    int converted = draw_eval_container_value_for_target(rval,
							    var_type);
	    if (converted >= 0)
		  errors += converted;
	    else
		  errors += draw_eval_object(rval);
	    if (ivl_type_queue_assoc_compat(var_type)) {
		  /* Assoc-compat queues are represented as associative-array
		   * objects at runtime. Copy the whole container object, do not
                   * route through the typed queue-element %store/qobj helpers. */
		  fprintf(vvp_out, "    %%dup/obj;\n");
		  fprintf(vvp_out, "    %%store/obj v%p_0;\n", var);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    } else if (type_is_fixed_uarray_property_(element_type)) {
		  fprintf(vvp_out, "    %%store/qobj/obj v%p_0, %d;\n",
			  var, idx);
	    } else if (ivl_type_base(element_type) == IVL_VT_REAL)
		  fprintf(vvp_out, "    %%store/qobj/r v%p_0, %d;\n", var, idx);
	    else if (ivl_type_base(element_type) == IVL_VT_STRING)
		  fprintf(vvp_out, "    %%store/qobj/str v%p_0, %d;\n", var, idx);
	    else if (ivl_type_base(element_type) == IVL_VT_BOOL ||
		     ivl_type_base(element_type) == IVL_VT_LOGIC) {
		  fprintf(vvp_out, "    %%store/qobj/v v%p_0, %d, %u;\n",
		                   var, idx, ivl_type_packed_width(element_type));
	    } else if (ivl_type_base(element_type) == IVL_VT_CLASS ||
		       ivl_type_base(element_type) == IVL_VT_DARRAY ||
		       ivl_type_base(element_type) == IVL_VT_QUEUE ||
		       ivl_type_base(element_type) == IVL_VT_NO_TYPE) {
		    /* A plain %store/obj here would alias the whole
		       container (and its elements) instead of copying
		       (recovery D11). Copy element-wise like the other
		       element kinds; the runtime element policy keeps
		       class handles shared. */
		  fprintf(vvp_out, "    %%store/qobj/obj v%p_0, %d;\n", var, idx);
	    } else {
		  fprintf(vvp_out, "    %%store/qobj/obj v%p_0, %d;\n", var, idx);
	    }
      }
      clr_word(idx);

      return errors;
}

static int expr_is_numeric_container_index_(ivl_expr_t expr)
{
      switch (ivl_expr_value(expr)) {
	  case IVL_VT_STRING:
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	    return 0;
	  default:
	    return 1;
      }
}

static int show_stmt_assign_sig_assoc_index(ivl_statement_t net,
                                            ivl_signal_t var,
                                            ivl_type_t var_type)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t idx_expr = ivl_lval_idx(lval);
      ivl_type_t element_type = ivl_type_element(var_type);
      unsigned wid;
      const char*key_kind;
      int key_is_object;
      int key_is_string;
      int use_signal_scalar_ops;
      int object_like_elem;
      int assoc_rmw = ivl_stmt_is_assoc_rmw(net);

      if (!element_type || !ivl_type_queue_assoc_compat(var_type))
            return -1;
      if (!idx_expr)
            return -1;
      if (type_is_fixed_uarray_property_(element_type)
          && ivl_stmt_opcode(net) != 0)
            return -1;
      if (ivl_stmt_opcode(net) != 0) {
            switch (ivl_type_base(element_type)) {
                case IVL_VT_REAL:
                case IVL_VT_BOOL:
                case IVL_VT_LOGIC:
                  break;
                default:
                  return -1;
            }
      }

      object_like_elem =
            type_is_fixed_uarray_property_(element_type)
         || ivl_type_base(element_type) == IVL_VT_CLASS
         || ivl_type_base(element_type) == IVL_VT_DARRAY
         || ivl_type_base(element_type) == IVL_VT_QUEUE
         || ivl_type_base(element_type) == IVL_VT_NO_TYPE;

      key_is_object = expr_is_object_assoc_key_(idx_expr);
      key_is_string = expr_is_string_assoc_key_(idx_expr);
      use_signal_scalar_ops = key_is_object;

      if (use_signal_scalar_ops && assoc_rmw)
	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", var);

      if (key_is_string) {
            key_kind = "str";
            draw_eval_string(idx_expr);
      } else if (key_is_object) {
            key_kind = "obj";
            errors += draw_eval_object(idx_expr);
      } else {
            key_kind = "v";
            draw_eval_vec4(idx_expr);
      }

      if (type_is_fixed_uarray_property_(element_type)) {
            errors += draw_eval_nested_object_value_(rval, element_type, 1);
            fprintf(vvp_out, "    %%aa/store/sig/obj/%s v%p_0;\n",
                    key_kind, var);
            return errors;
      }

      if (!object_like_elem && !use_signal_scalar_ops)
            fprintf(vvp_out, "    %%load/obj v%p_0;\n", var);

      switch (ivl_type_base(element_type)) {
          case IVL_VT_REAL:
            if (assoc_rmw) {
                  fprintf(vvp_out, "    %%aa/loadk/r/%s;\n", key_kind);
                  fprintf(vvp_out, "    %%pop/real 1; discard RMW value before RHS\n");
            }
            if (use_signal_scalar_ops && ivl_stmt_opcode(net) != 0) {
                  fprintf(vvp_out, "    %%aa/load/sig/r/obj v%p_0;\n", var);
                  draw_eval_real(rval);
                  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
            } else if (ivl_stmt_opcode(net) != 0) {
                  fprintf(vvp_out, "    %%aa/loadk/r/%s;\n", key_kind);
                  draw_eval_real(rval);
                  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
            } else {
                  draw_eval_real(rval);
            }
            if (use_signal_scalar_ops)
                  fprintf(vvp_out, "    %%aa/store/sig/r/obj v%p_0;\n", var);
            else
                  fprintf(vvp_out, "    %%aa/store/r/%s;\n", key_kind);
            if (!use_signal_scalar_ops)
                  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return errors;
          case IVL_VT_STRING:
            draw_eval_string(rval);
            if (use_signal_scalar_ops)
                  fprintf(vvp_out, "    %%aa/store/sig/str/obj v%p_0;\n", var);
            else
                  fprintf(vvp_out, "    %%aa/store/str/%s;\n", key_kind);
            if (!use_signal_scalar_ops)
                  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return errors;
          case IVL_VT_BOOL:
          case IVL_VT_LOGIC:
            wid = ivl_type_packed_width(element_type);
            if (wid == 0)
                  wid = ivl_stmt_lwidth(net);
            if (use_signal_scalar_ops && ivl_stmt_opcode(net) != 0) {
                  fprintf(vvp_out, "    %%aa/load/sig/v/obj v%p_0, %u;\n", var, wid);
                  draw_stmt_assign_vector_rhs(net, ivl_stmt_lwidth(net));
            } else if (ivl_stmt_opcode(net) != 0) {
                  fprintf(vvp_out, "    %%aa/loadk/v/%s %u;\n", key_kind, wid);
                  draw_stmt_assign_vector_rhs(net, ivl_stmt_lwidth(net));
            } else {
                  if (assoc_rmw) {
                        fprintf(vvp_out, "    %%aa/loadk/v/%s %u;\n", key_kind, wid);
                        fprintf(vvp_out, "    %%pop/vec4 1; discard RMW value before RHS\n");
                        if (use_signal_scalar_ops)
                              fprintf(vvp_out, "    %%pop/obj 1, 1; discard temporary array receiver\n");
                  }
                  draw_eval_vec4(rval);
                  resize_vec4_wid(rval, ivl_stmt_lwidth(net));
            }
            if (use_signal_scalar_ops)
                  fprintf(vvp_out, "    %%aa/store/sig/v/obj v%p_0, %u;\n", var, wid);
            else
                  fprintf(vvp_out, "    %%aa/store/v/%s %u;\n", key_kind, wid);
            if (!use_signal_scalar_ops)
                  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return errors;
          case IVL_VT_CLASS:
          case IVL_VT_DARRAY:
          case IVL_VT_QUEUE:
          case IVL_VT_NO_TYPE:
              /* %aa/store/sig/obj applies container/struct value semantics. */
            errors += draw_eval_nested_object_value_(rval, element_type, 1);
            fprintf(vvp_out, "    %%aa/store/sig/obj/%s v%p_0;\n", key_kind, var);
            return errors;
          default:
            return -1;
      }
}

static int prop_is_numeric_queue_index_(ivl_type_t prop_type, ivl_expr_t idx_expr)
{
      if (!idx_expr || !prop_type || ivl_type_base(prop_type) != IVL_VT_QUEUE)
            return 0;

      if (ivl_type_queue_assoc_compat(prop_type))
            return 0;

      return expr_is_numeric_container_index_(idx_expr);
}

static int show_stmt_assign_sig_prop_queue_index(ivl_statement_t net,
                                                 int prop_idx,
                                                 ivl_type_t prop_type)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_signal_t recv = ivl_lval_sig(lval);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t idx_expr = prop_lval_index_expr_(lval);
      ivl_type_t element_type;

      if (!prop_is_numeric_queue_index_(prop_type, idx_expr))
	    return -1;

      element_type = ivl_type_element(prop_type);
      if (!element_type)
	    return -1;

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    if (ivl_stmt_opcode(net) != 0) {
		  int mux_word = allocate_word();
		  int flag = allocate_flag();

		  draw_eval_expr_into_integer(idx_expr, 3);
		  fprintf(vvp_out, "    %%ix/mov %d, 3;\n", mux_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag);
		  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		  fprintf(vvp_out, "    %%load/qo/r;\n");
		  draw_eval_real(rval);
		  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", flag);
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", mux_word);
		  fprintf(vvp_out, "    %%load/obj v%p_0;\n", recv);
		  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		  fprintf(vvp_out, "    %%set/dar/obj/real 3;\n");
		  fprintf(vvp_out, "    %%pop/real 1;\n");
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  clr_flag(flag);
		  clr_word(mux_word);
	    } else {
		  int idx_word = allocate_word();
		  draw_eval_real(rval);
		  draw_eval_expr_into_integer(idx_expr, idx_word);
		  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		  fprintf(vvp_out, "    %%set/dar/obj/real %d;\n", idx_word);
		  fprintf(vvp_out, "    %%pop/real 1;\n");
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  clr_word(idx_word);
	    }
	    return errors;

	  case IVL_VT_STRING:
	    if (ivl_stmt_opcode(net) != 0)
		  return -1;
	    {
		  int idx_word = allocate_word();
		  draw_eval_string(rval);
		  draw_eval_expr_into_integer(idx_expr, idx_word);
		  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		  fprintf(vvp_out, "    %%set/dar/obj/str %d;\n", idx_word);
		  fprintf(vvp_out, "    %%pop/str 1;\n");
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  clr_word(idx_word);
	    }
	    return errors;

	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC: {
		unsigned wid = ivl_type_packed_width(element_type);
		if (wid == 0)
		      wid = ivl_stmt_lwidth(net);

		if (ivl_stmt_opcode(net) != 0) {
		      int mux_word = allocate_word();
		      int flag = allocate_flag();

		      draw_eval_expr_into_integer(idx_expr, 3);
		      fprintf(vvp_out, "    %%ix/mov %d, 3;\n", mux_word);
		      fprintf(vvp_out, "    %%flag_mov %d, 4;\n", flag);
		      fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		      fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		      fprintf(vvp_out, "    %%load/qo/v %u;\n", wid);
		      draw_stmt_assign_vector_rhs(net, ivl_stmt_lwidth(net));
		      fprintf(vvp_out, "    %%flag_mov 4, %d;\n", flag);
		      fprintf(vvp_out, "    %%ix/mov 3, %d;\n", mux_word);
		      fprintf(vvp_out, "    %%load/obj v%p_0;\n", recv);
		      fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		      fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		      fprintf(vvp_out, "    %%set/dar/obj/vec4 3;\n");
		      fprintf(vvp_out, "    %%pop/vec4 1;\n");
		      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		      clr_flag(flag);
		      clr_word(mux_word);
		} else {
		      int idx_word = allocate_word();
		      draw_eval_vec4(rval);
		      resize_vec4_wid(rval, ivl_stmt_lwidth(net));
		      draw_eval_expr_into_integer(idx_expr, idx_word);
		      fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		      fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		      fprintf(vvp_out, "    %%set/dar/obj/vec4 %d;\n", idx_word);
		      fprintf(vvp_out, "    %%pop/vec4 1;\n");
		      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		      clr_word(idx_word);
		}
		return errors;
	  }

	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    if (ivl_stmt_opcode(net) != 0)
		  return -1;
	    {
		  int idx_word = allocate_word();
		  draw_eval_expr_into_integer(idx_expr, idx_word);
		  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
		    /* An object-backed unpacked struct is a VALUE (7.2):
		       storing the r-value's handle would alias the source,
		       so every element written from one struct variable
		       ended up sharing it -- silently. The module-scope
		       store already copies; this one has to as well. */
		  errors += draw_eval_nested_object_value_(rval, element_type,
							       0);
		  fprintf(vvp_out, "    %%set/dar/obj/obj %d;\n", idx_word);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  clr_word(idx_word);
	    }
	    return errors;

	  default:
	    return -1;
      }
}

static int show_stmt_assign_sig_prop_darray_index(ivl_statement_t net,
                                                  int prop_idx,
                                                  ivl_type_t prop_type)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
	/* Use the property's OWN index (obj.addr[i]), never the base
	   container index inherited from a nest. A whole-darray-property
	   store through an indexed base (da[0].addr = a, or the register
	   model's m_regs_info[rg].addr = addrs) has no property index and
	   must fall through to the whole-object %store/prop/obj path — the
	   nest-index fallback misread it as an element store (%prop/obj load
	   + %set/dar), silently dropping the assignment. */
      ivl_expr_t idx_expr = ivl_lval_idx(lval);
      ivl_type_t element_type;

      if (!idx_expr || !prop_type || ivl_type_base(prop_type) != IVL_VT_DARRAY)
            return -1;

      element_type = ivl_type_element(prop_type);
      if (!element_type)
            return -1;

      if (ivl_stmt_opcode(net) != 0
          && ivl_type_base(element_type) != IVL_VT_BOOL
          && ivl_type_base(element_type) != IVL_VT_LOGIC)
            return -1;

      switch (ivl_type_base(element_type)) {
          case IVL_VT_REAL: {
            int idx_word = allocate_word();
            draw_eval_real(rval);
            draw_eval_expr_into_integer(idx_expr, idx_word);
            fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
            fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
            fprintf(vvp_out, "    %%set/dar/obj/real %d;\n", idx_word);
            fprintf(vvp_out, "    %%pop/real 1;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            clr_word(idx_word);
            return errors;
          }

          case IVL_VT_STRING: {
            int idx_word = allocate_word();
            draw_eval_string(rval);
            draw_eval_expr_into_integer(idx_expr, idx_word);
            fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
            fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
            fprintf(vvp_out, "    %%set/dar/obj/str %d;\n", idx_word);
            fprintf(vvp_out, "    %%pop/str 1;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            clr_word(idx_word);
            return errors;
          }

          case IVL_VT_BOOL:
          case IVL_VT_LOGIC: {
            unsigned wid = ivl_type_packed_width(element_type);
            int idx_word = allocate_word();
            if (wid == 0)
                  wid = ivl_stmt_lwidth(net);

            if (ivl_stmt_opcode(net) != 0) {
                  int idx_flag = allocate_flag();
                  unsigned skip = local_count++;

                    /* Retain the selected array, not a receiver reloaded
                       after RHS side effects. Evaluate its index once. */
                  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
                  fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
                  draw_eval_expr_into_integer(idx_expr, 3);
                  fprintf(vvp_out, "    %%ix/mov %d, 3;\n", idx_word);
                  fprintf(vvp_out, "    %%flag_mov %d, 4;\n", idx_flag);
                  fprintf(vvp_out, "    %%dup/obj/ref;\n");
                  fprintf(vvp_out, "    %%load/qo/v %u;\n", wid);
                  draw_stmt_assign_vector_rhs(net, wid);
                  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
                  fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
                          thread_count, skip);
                  fprintf(vvp_out, "    %%set/dar/obj/vec4 %d;\n", idx_word);
                  fprintf(vvp_out, "T_%u.%u ;\n", thread_count, skip);
                  fprintf(vvp_out, "    %%pop/vec4 1;\n");
                  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
                  clr_flag(idx_flag);
                  clr_word(idx_word);
                  return errors;
            }

            draw_eval_vec4(rval);
            resize_vec4_wid(rval, ivl_stmt_lwidth(net));
            draw_eval_expr_into_integer(idx_expr, idx_word);
            fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
            fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
            fprintf(vvp_out, "    %%set/dar/obj/vec4 %d;\n", idx_word);
            fprintf(vvp_out, "    %%pop/vec4 1;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            clr_word(idx_word);
            return errors;
          }

          case IVL_VT_CLASS:
          case IVL_VT_DARRAY:
          case IVL_VT_QUEUE:
          case IVL_VT_NO_TYPE: {
            int idx_word = allocate_word();
            draw_eval_expr_into_integer(idx_expr, idx_word);
            fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
            fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
              /* Value-copy an unpacked-struct element -- see above. */
            errors += draw_eval_nested_object_value_(rval, element_type, 0);
            fprintf(vvp_out, "    %%set/dar/obj/obj %d;\n", idx_word);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            clr_word(idx_word);
            return errors;
          }

          default:
            return -1;
      }
}

static int show_stmt_assign_sig_prop_assoc_index(ivl_statement_t net,
                                                 int prop_idx,
                                                 ivl_type_t prop_type)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t idx_expr = ivl_lval_idx(lval);
      ivl_type_t element_type = ivl_type_element(prop_type);
      unsigned wid;
      const char*key_kind;

      if (!element_type || !ivl_type_queue_assoc_compat(prop_type))
	    return -1;
      if (!idx_expr)
	    return -1;
      if (type_is_fixed_uarray_property_(element_type)
	  && ivl_stmt_opcode(net) != 0)
	    return -1;
      if (ivl_stmt_opcode(net) != 0) {
	    switch (ivl_type_base(element_type)) {
		case IVL_VT_REAL:
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  break;
		default:
		  return -1;
	    }
      }

      fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);

      key_kind = draw_eval_assoc_key_(idx_expr, &errors);

      if (type_is_fixed_uarray_property_(element_type)) {
	    errors += draw_eval_nested_object_value_(rval, element_type, 1);
	    fprintf(vvp_out, "    %%aa/store/obj/%s;\n", key_kind);
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	    return errors;
      }

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    if (ivl_stmt_is_assoc_rmw(net)) {
		  fprintf(vvp_out, "    %%aa/loadk/r/%s;\n", key_kind);
		  fprintf(vvp_out, "    %%pop/real 1; discard RMW value before RHS\n");
	    }
	    if (ivl_stmt_opcode(net) != 0) {
		  fprintf(vvp_out, "    %%aa/loadk/r/%s;\n", key_kind);
		  draw_eval_real(rval);
		  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
	    } else {
		  draw_eval_real(rval);
	    }
	    fprintf(vvp_out, "    %%aa/store/r/%s;\n", key_kind);
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	    return errors;
	  case IVL_VT_STRING:
	    draw_eval_string(rval);
	    fprintf(vvp_out, "    %%aa/store/str/%s;\n", key_kind);
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	    return errors;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    wid = ivl_type_packed_width(element_type);
	    if (wid == 0)
		  wid = ivl_stmt_lwidth(net);
	    if (ivl_stmt_opcode(net) != 0) {
		  fprintf(vvp_out, "    %%aa/loadk/v/%s %u;\n", key_kind, wid);
		  draw_stmt_assign_vector_rhs(net, ivl_stmt_lwidth(net));
	    } else {
		  if (ivl_stmt_is_assoc_rmw(net)) {
			fprintf(vvp_out, "    %%aa/loadk/v/%s %u;\n", key_kind, wid);
			fprintf(vvp_out, "    %%pop/vec4 1; discard RMW value before RHS\n");
		  }
		  draw_eval_vec4(rval);
		  resize_vec4_wid(rval, ivl_stmt_lwidth(net));
	    }
	    fprintf(vvp_out, "    %%aa/store/v/%s %u;\n", key_kind, wid);
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	    return errors;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	      /* %aa/store/obj applies container/struct value semantics. */
	    errors += draw_eval_nested_object_value_(rval, element_type, 1);
	    fprintf(vvp_out, "    %%aa/store/obj/%s;\n", key_kind);
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	    return errors;
	  default:
	    return -1;
	      }
}

/* type_is_object_like_, container_type_shape_eq_ and the queue-pattern
 * operand classifiers moved to vvp_priv.h (shared with eval_object.c's
 * container-literal builder). */

/* The signal-backed suffix-slice opcodes name their receiver by net label;
 * there is no equivalent opcode for an object-backed property slot. Never
 * reinterpret the lower bound as a scalar element index -- that corrupts one
 * element (and can attempt to evaluate the queue-valued RHS as a vec4).
 * Reject this shape loudly until the object-receiver slice opcode exists. */
static int show_stmt_assign_nested_queue_slice(ivl_statement_t net)
{
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_lval_t lval_nest = ivl_lval_nest(lval);
      ivl_type_t hint_type;

      if (!lval_nest || !ivl_lval_is_queue_slice(lval))
            return -1;

      hint_type = ivl_lval_net_type(lval_nest);
      if (!hint_type || ivl_type_base(hint_type) != IVL_VT_QUEUE
          || ivl_type_queue_assoc_compat(hint_type))
            return -1;

      fprintf(stderr, "%s:%u: sorry: assignment to a queue suffix slice "
              "through a selected fixed-array class property is not "
              "supported.\n", ivl_stmt_file(net), ivl_stmt_lineno(net));
      return 1;
}

/* A selected fixed-container receiver may be null because the class handle
 * is null or its fixed property slot is invalid. The write is ignored, but
 * SystemVerilog still evaluates the remaining l-value index/part offset and
 * the RHS exactly once. Emit those evaluations on the null branch and leave
 * every value stack balanced. */
static int discard_nested_container_write_(ivl_expr_t idx_expr,
					    ivl_expr_t part_expr,
					    ivl_expr_t rval,
					    ivl_type_t container_type,
					    ivl_type_t element_type)
{
      int errors = 0;

      if (ivl_type_base(container_type) == IVL_VT_QUEUE
	  && ivl_type_queue_assoc_compat(container_type)) {
	    const char*key_kind = draw_eval_assoc_key_(idx_expr, &errors);
	    if (strcmp(key_kind, "str") == 0)
		  fprintf(vvp_out, "    %%pop/str 1; discarded assoc key\n");
	    else if (strcmp(key_kind, "obj") == 0)
		  fprintf(vvp_out, "    %%pop/obj 1, 0; discarded assoc key\n");
	    else
		  fprintf(vvp_out, "    %%pop/vec4 1; discarded assoc key\n");
      } else {
	    int idx_word = allocate_word();
	    draw_eval_expr_into_integer(idx_expr, idx_word);
	    clr_word(idx_word);
      }

      if (part_expr) {
	    int off_word = allocate_word();
	    draw_eval_expr_into_integer(part_expr, off_word);
	    clr_word(off_word);
      }

      switch (element_type ? ivl_type_base(element_type) : IVL_VT_VOID) {
	  case IVL_VT_REAL:
	    draw_eval_real(rval);
	    fprintf(vvp_out, "    %%pop/real 1; discarded nested RHS\n");
	    break;
	  case IVL_VT_STRING:
	    draw_eval_string(rval);
	    fprintf(vvp_out, "    %%pop/str 1; discarded nested RHS\n");
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    errors += draw_eval_object(rval);
	    fprintf(vvp_out, "    %%pop/obj 1, 0; discarded nested RHS\n");
	    break;
	  default:
	    draw_eval_vec4(rval);
	    fprintf(vvp_out, "    %%pop/vec4 1; discarded nested RHS\n");
	    break;
      }
      return errors;
}

/* Store an integral element (or a packed field of one) through a nested
 * object-backed container receiver.  This is the shape produced for
 *
 *     object.fixed_array_slot[queue_or_assoc_index][packed_field] = value
 *
 * after the fixed prefix has been canonicalized into the enclosing property
 * node.  The outer property word is consumed by draw_lval_expr(); IDX_EXPR is
 * therefore strictly an index/key in the selected leaf container. */
static int show_stmt_assign_nested_index_vec4(ivl_statement_t net)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_lval_t lval_nest = ivl_lval_nest(lval);
      ivl_expr_t idx_expr = ivl_lval_idx(lval);
      ivl_expr_t part_expr = ivl_lval_part_off(lval);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_type_t hint_type;
      ivl_type_t container_type;
      ivl_type_t element_type;
      unsigned elem_wid;
      unsigned lval_wid;
      unsigned lab_null;
      unsigned lab_out;

      if (!lval_nest || !idx_expr)
	    return -1;
      if (ivl_lval_is_queue_slice(lval))
	    return -1;

      hint_type = ivl_lval_net_type(lval_nest);
      if (!hint_type
	  || (!type_is_fixed_uarray_property_(hint_type)
	      && ivl_type_base(hint_type) != IVL_VT_QUEUE
	      && ivl_type_base(hint_type) != IVL_VT_DARRAY))
	    return -1;

      element_type = ivl_type_element(hint_type);
      if (!element_type
	  || (ivl_type_base(element_type) != IVL_VT_BOOL
	      && ivl_type_base(element_type) != IVL_VT_LOGIC))
	    return -1;

      /* Pass the current pure-index node so draw_lval_expr consumes the
       * property selection carried by its nest and leaves that selected
       * fixed slot on the object stack. */
      container_type = draw_lval_expr(lval);
      if (!container_type
	  || (!type_is_fixed_uarray_property_(container_type)
	      && ivl_type_base(container_type) != IVL_VT_QUEUE
	      && ivl_type_base(container_type) != IVL_VT_DARRAY)) {
	    fprintf(stderr, "%s:%u: internal error: nested integral container "
		    "receiver lost its leaf type.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    fprintf(vvp_out, "    %%pop/obj 1, 0; malformed nested container receiver\n");
	    return 1;
      }

      element_type = ivl_type_element(container_type);
      elem_wid = element_type ? ivl_type_packed_width(element_type) : 0;
      if (elem_wid == 0)
	    elem_wid = ivl_lval_width(lval);
      lval_wid = ivl_lval_width(lval);
      lab_null = local_count++;
      lab_out = local_count++;

      fprintf(vvp_out, "    %%test_nul/obj;\n");
      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);

      if (ivl_type_base(container_type) == IVL_VT_QUEUE
	  && ivl_type_queue_assoc_compat(container_type)) {
	    const char*key_kind = draw_eval_assoc_key_(idx_expr, &errors);

	    if (part_expr || ivl_stmt_opcode(net) != 0)
		  fprintf(vvp_out, "    %%aa/loadk/v/%s %u;\n",
			  key_kind, elem_wid);

	    if (part_expr) {
		  int off_word = allocate_word();
		  int off_flag = allocate_flag();

		  if (ivl_stmt_opcode(net) != 0)
			fprintf(vvp_out, "    %%dup/vec4;\n");

		  if (packed_property_offset_is_immediate_(part_expr)) {
			unsigned bitoff = (unsigned)ivl_expr_uvalue(part_expr);
			fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n",
				off_word, bitoff);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
			if (ivl_stmt_opcode(net) != 0)
			      fprintf(vvp_out, "    %%parti/u %u, %u, 32;\n",
				      lval_wid, bitoff);
		  } else if (ivl_stmt_opcode(net) != 0) {
			draw_eval_vec4(part_expr);
			fprintf(vvp_out, "    %%dup/vec4;\n");
			fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
				ivl_expr_signed(part_expr) ? "/s" : "", off_word);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
			fprintf(vvp_out, "    %%part/%c %u;\n",
				ivl_expr_signed(part_expr) ? 's' : 'u', lval_wid);
		  } else {
			draw_eval_expr_into_integer(part_expr, off_word);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
		  }

		  draw_stmt_assign_vector_rhs(net, lval_wid);
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
		  fprintf(vvp_out, "    %%setbits/vec4/x %d, %u;\n",
			  off_word, lval_wid);
		  clr_flag(off_flag);
		  clr_word(off_word);
	    } else {
		  draw_stmt_assign_vector_rhs(net, elem_wid);
	    }

	    fprintf(vvp_out, "    %%aa/store/v/%s %u;\n", key_kind, elem_wid);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

      } else {
	    int idx_word = allocate_word();
	    int idx_flag = allocate_flag();

	    draw_eval_expr_into_integer(idx_expr, 3);
	    fprintf(vvp_out, "    %%ix/mov %d, 3;\n", idx_word);
	    fprintf(vvp_out, "    %%flag_mov %d, 4;\n", idx_flag);

	    if (part_expr || ivl_stmt_opcode(net) != 0) {
		  fprintf(vvp_out, "    %%dup/obj/ref;\n");
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", idx_word);
		  fprintf(vvp_out, "    %%load/qo/v %u;\n", elem_wid);
	    }

	    if (part_expr) {
		  int off_word = allocate_word();
		  int off_flag = allocate_flag();

		  if (ivl_stmt_opcode(net) != 0)
			fprintf(vvp_out, "    %%dup/vec4;\n");

		  if (packed_property_offset_is_immediate_(part_expr)) {
			unsigned bitoff = (unsigned)ivl_expr_uvalue(part_expr);
			fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n",
				off_word, bitoff);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
			if (ivl_stmt_opcode(net) != 0)
			      fprintf(vvp_out, "    %%parti/u %u, %u, 32;\n",
				      lval_wid, bitoff);
		  } else if (ivl_stmt_opcode(net) != 0) {
			draw_eval_vec4(part_expr);
			fprintf(vvp_out, "    %%dup/vec4;\n");
			fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
				ivl_expr_signed(part_expr) ? "/s" : "", off_word);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
			fprintf(vvp_out, "    %%part/%c %u;\n",
				ivl_expr_signed(part_expr) ? 's' : 'u', lval_wid);
		  } else {
			draw_eval_expr_into_integer(part_expr, off_word);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
		  }

		  draw_stmt_assign_vector_rhs(net, lval_wid);
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
		  fprintf(vvp_out, "    %%setbits/vec4/x %d, %u;\n",
			  off_word, lval_wid);
		  clr_flag(off_flag);
		  clr_word(off_word);
	    } else {
		  draw_stmt_assign_vector_rhs(net, elem_wid);
	    }

	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
	    fprintf(vvp_out, "    %%ix/mov 3, %d;\n", idx_word);
	    emit_object_queue_store_('i', "v",
	                             queue_live_max_operand_(container_type),
	                             elem_wid);
	    clr_flag(idx_flag);
	    clr_word(idx_word);
      }

      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
      errors += discard_nested_container_write_(idx_expr, part_expr, rval,
						 container_type, element_type);
      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
      return errors;
}

static int show_stmt_assign_nested_index_object(ivl_statement_t net)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_lval_t lval_nest = ivl_lval_nest(lval);
      ivl_expr_t idx_expr = ivl_lval_idx(lval);
      ivl_expr_t part_expr = ivl_lval_part_off(lval);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_type_t hint_type;
      ivl_type_t container_type;
      ivl_type_t element_type;
      ivl_variable_type_t element_kind;
      unsigned lab_null;
      unsigned lab_out;

      if (!lval_nest || !idx_expr || ivl_lval_is_queue_slice(lval))
            return -1;

      /* Preflight before drawing anything. The old helper claimed every
       * nested simple assignment, then silently popped and returned success
       * for real/string leaves (and for unrelated unsupported shapes). */
      hint_type = ivl_lval_net_type(lval_nest);
      if (!hint_type
          || (!type_is_fixed_uarray_property_(hint_type)
              && ivl_type_base(hint_type) != IVL_VT_QUEUE
              && ivl_type_base(hint_type) != IVL_VT_DARRAY))
            return -1;
      element_type = ivl_type_element(hint_type);
      if (!element_type)
            return -1;
      element_kind = ivl_type_base(element_type);
      if (element_kind != IVL_VT_REAL && element_kind != IVL_VT_STRING
          && !type_is_object_like_(element_type))
            return -1;

      if (part_expr) {
            fprintf(stderr, "%s:%u: sorry: part-select assignment to a "
                    "non-integral nested container element is not supported.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            return 1;
      }
      if (ivl_stmt_opcode(net) != 0 && element_kind != IVL_VT_REAL) {
            fprintf(stderr, "%s:%u: sorry: compound assignment to a nested "
                    "container element of type %d is not supported.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net), element_kind);
            return 1;
      }

      container_type = draw_lval_expr(lval);
      if (!container_type) {
            fprintf(stderr, "%s:%u: sorry: could not recover the selected "
                    "nested container type for this assignment.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            fprintf(vvp_out,
                    "    %%pop/obj 1, 0; missing nested container type\n");
            return 1;
      }

      element_type = ivl_type_element(container_type);
      element_kind = element_type ? ivl_type_base(element_type) : IVL_VT_VOID;
      if ((!type_is_fixed_uarray_property_(container_type)
	   && ivl_type_base(container_type) != IVL_VT_QUEUE
	   && ivl_type_base(container_type) != IVL_VT_DARRAY)
	  || (element_kind != IVL_VT_REAL
	      && element_kind != IVL_VT_STRING
	      && !type_is_object_like_(element_type))) {
	    fprintf(stderr, "%s:%u: sorry: recovered nested container element "
		    "type %d is not supported for this assignment.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net), element_kind);
	    fprintf(vvp_out,
		    "    %%pop/obj 1, 0; unsupported recovered nested receiver\n");
	    return 1;
      }
      lab_null = local_count++;
      lab_out = local_count++;

      fprintf(vvp_out, "    %%test_nul/obj;\n");
      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);

      if ((ivl_type_base(container_type) == IVL_VT_QUEUE)
          && ivl_type_queue_assoc_compat(container_type)) {
            const char*key_kind;

            key_kind = draw_eval_assoc_key_(idx_expr, &errors);

            switch (element_kind) {
                case IVL_VT_REAL:
                  if (ivl_stmt_opcode(net) != 0)
                        fprintf(vvp_out, "    %%aa/loadk/r/%s;\n", key_kind);
                  draw_eval_real(rval);
                  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
                  fprintf(vvp_out, "    %%aa/store/r/%s;\n", key_kind);
                  break;
                case IVL_VT_STRING:
                  draw_eval_string(rval);
                  fprintf(vvp_out, "    %%aa/store/str/%s;\n", key_kind);
                  break;
                case IVL_VT_CLASS:
                case IVL_VT_DARRAY:
                case IVL_VT_QUEUE:
                case IVL_VT_NO_TYPE:
                  errors += draw_eval_nested_object_value_(rval, element_type,
                                                           1);
                  fprintf(vvp_out, "    %%aa/store/obj/%s;\n", key_kind);
                  break;
                default:
                  break;
            }
            /* draw_lval_expr(lval) has already discarded the enclosing
             * class receiver and leaves only the selected map. The store
             * consumes its value and key, so pop exactly that map. */
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

      } else if ((type_is_fixed_uarray_property_(container_type)
                  || ivl_type_base(container_type) == IVL_VT_DARRAY
                  || ivl_type_base(container_type) == IVL_VT_QUEUE)) {
            int idx_word = allocate_word();
            int idx_flag = allocate_flag();

            draw_eval_expr_into_integer(idx_expr, 3);
            fprintf(vvp_out, "    %%ix/mov %d, 3;\n", idx_word);
            fprintf(vvp_out, "    %%flag_mov %d, 4;\n", idx_flag);

            /* A compound real assignment needs a receiver copy for its
             * old-value load; every simple store keeps the sole receiver
             * until the receiver-popping %store/qo/i opcode. */
            if (element_kind == IVL_VT_REAL && ivl_stmt_opcode(net) != 0) {
                  fprintf(vvp_out, "    %%dup/obj/ref;\n");
                  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
                  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", idx_word);
                  fprintf(vvp_out, "    %%load/qo/r;\n");
            }

            switch (element_kind) {
                case IVL_VT_REAL:
                  draw_eval_real(rval);
                  draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
                  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
                  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", idx_word);
                  emit_object_queue_store_('i', "r",
					   queue_live_max_operand_(container_type),
                                           0);
                  break;
                case IVL_VT_STRING:
                  draw_eval_string(rval);
                  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
                  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", idx_word);
                  emit_object_queue_store_('i', "str",
					   queue_live_max_operand_(container_type),
                                           0);
                  break;
                case IVL_VT_CLASS:
                case IVL_VT_DARRAY:
                case IVL_VT_QUEUE:
                case IVL_VT_NO_TYPE:
                  errors += draw_eval_nested_object_value_(rval, element_type,
                                                           1);
                  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", idx_flag);
                  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", idx_word);
                  /* This opcode checks flag4 and applies container value-copy
                   * semantics. %set/dar/obj/obj did neither. */
                  emit_object_queue_store_('i', "obj",
					   queue_live_max_operand_(container_type),
                                           0);
                  break;
                default:
                  break;
            }
            clr_flag(idx_flag);
            clr_word(idx_word);

      } else {
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
            return 0;
      }

      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
      errors += discard_nested_container_write_(idx_expr, 0, rval,
						 container_type, element_type);
      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
      return errors;
}

/* A class/VIF property expression can have a run-time width that differs
   from ivl_expr_width(). In particular, a virtual handle to a parameterized
   interface currently carries the default-specialization netclass while the
   bound member produces the instance's actual width. Property store opcodes
   consume the l-value width, so do not statically elide this assignment-size
   conversion as resize_vec4_wid() normally does. */
static void resize_property_vec4_wid(ivl_expr_t expr, unsigned wid)
{
      fprintf(vvp_out, "    %%pad/%s %u; property assignment width\n",
	      ivl_expr_signed(expr) ? "s" : "u", wid);
}

/* Nonblocking assignment to a vec4 class-object / virtual-interface
   property: `obj.prop <= [#d] value` or a packed field thereof
   (IEEE 1800-2017 10.4.2). Evaluates the receiver and the r-value NOW and
   schedules the store in the NBA region via %assign/prop/v[/bits]. Returns
   0 on success and -1 when the l-value form is not supported here. The
   caller must reject that residual; executing it as a blocking assignment
   would be a silent event-region miscompile. */
int show_stmt_assign_nb_cobject(ivl_statement_t net, uint64_t delay)
{
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t part_off_ex = ivl_lval_part_off(lval);
      ivl_expr_t dynamic_carrier = ivl_lval_dynamic_part_carrier(lval);
      unsigned carrier_wid = ivl_lval_part_carrier_width(lval);
      unsigned lwid = ivl_lval_width(lval);
      int prop_idx = ivl_lval_property_idx(lval);
      unsigned bitoff = 0;
      int off_reg = 0, off_flag = 0;
      int carrier_reg = 0, carrier_flag = 0;
      int dynamic_part_off = 0;

      if (ivl_stmt_lvals(net) != 1)
	    return -1;
      if (prop_idx < 0)
	    return -1;
      if (ivl_lval_idx(lval))
	    return -1;
      if (part_off_ex) {
	    if (packed_property_offset_is_immediate_(part_off_ex))
		  bitoff = (unsigned)ivl_expr_uvalue(part_off_ex);
	    else
		  dynamic_part_off = 1;
      }
      if (ivl_stmt_opcode(net) != 0)
	    return -1;
      if (delay > 0xffffffffUL)
	    return -1;
      if (dynamic_carrier && carrier_wid == 0)
	    return -1;

      ivl_type_t sig_type = draw_lval_expr(lval);
      ivl_type_t prop_type = ivl_type_prop_type(sig_type, prop_idx);
      if (ivl_type_base(prop_type) != IVL_VT_BOOL &&
	  ivl_type_base(prop_type) != IVL_VT_LOGIC) {
	      /* Receiver already pushed: discard and fall back. */
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    return -1;
      }

      if (dynamic_part_off) {
	    uint64_t negative_bits;
	    off_reg = allocate_word();
	    off_flag = allocate_flag();
	    if (dynamic_carrier) {
		  carrier_reg = allocate_word();
		  carrier_flag = allocate_flag();
		  draw_eval_expr_into_integer(dynamic_carrier, carrier_reg);
		  fprintf(vvp_out,
			  "    %%flag_mov %d, 4; capture NBA carrier validity\n",
			  carrier_flag);
	    }
	    if (packed_property_negative_offset_bits64_(part_off_ex,
						 &negative_bits))
		  emit_packed_property_negative_offset_(off_reg, negative_bits);
	    else if ((ivl_expr_type(part_off_ex) == IVL_EX_NUMBER
		      || ivl_expr_type(part_off_ex) == IVL_EX_ULONG)
		     && !packed_property_offset_is_unknown_(part_off_ex)) {
		  /* A defined constant beyond the packed offset range cannot
		     overlap this property; do not truncate it to another bit. */
		  fprintf(vvp_out, "    %%ix/load %d, 0, 0;\n", off_reg);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 1;\n");
	    }
	    else
		  draw_eval_expr_into_integer(part_off_ex, off_reg);
	    if (dynamic_carrier)
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine NBA carrier validity\n",
			  carrier_flag);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; capture NBA offset validity\n",
		    off_flag);
      }

      draw_eval_vec4(rval);
      resize_property_vec4_wid(rval, lwid);
      if (ivl_type_base(prop_type) == IVL_VT_BOOL &&
	  ivl_expr_value(rval) != IVL_VT_BOOL)
	    fprintf(vvp_out, "    %%cast2;\n");

      if (dynamic_part_off) {
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
	    if (dynamic_carrier) {
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			  carrier_wid);
		  fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
			  off_reg, carrier_reg);
	    }
	    fprintf(vvp_out, "    %%assign/prop/v/bits/%s %d, %lu, %d;"
		    " NBA store to selected property %s\n",
		    ivl_expr_signed(part_off_ex) ? "x" : "ux",
		    prop_idx, (unsigned long)delay, off_reg,
		    ivl_type_prop_name(sig_type, prop_idx));
	    clr_word(off_reg);
	    clr_flag(off_flag);
	    if (carrier_reg) {
		  clr_word(carrier_reg);
		  clr_flag(carrier_flag);
	    }
      } else if (part_off_ex) {
	    fprintf(vvp_out, "    %%assign/prop/v/bits %d, %lu, %u;"
		    " NBA store to field [%u+:%u] of property %s\n",
		    prop_idx, (unsigned long)delay, bitoff, bitoff, lwid,
		    ivl_type_prop_name(sig_type, prop_idx));
      } else {
	    fprintf(vvp_out, "    %%assign/prop/v %d, %lu, %u;"
		    " NBA store to property %s\n",
		    prop_idx, (unsigned long)delay, lwid,
		    ivl_type_prop_name(sig_type, prop_idx));
      }
      return 0;
}

/* An invalid checked slot still evaluates every remaining l-value/RHS
   expression once, but must not issue any property load or store. Discard the
   value from the stack selected by the declared leaf type. */
static int draw_discard_fixed_property_rhs_(ivl_statement_t net,
                                             ivl_expr_t rval,
                                             ivl_type_t value_type,
                                             ivl_expr_t part_off)
{
      int errors = 0;

      if (part_off) {
            int off_word = allocate_word();
            draw_eval_expr_into_integer(part_off, off_word);
            clr_word(off_word);
      }

      switch (value_type ? ivl_type_base(value_type) : IVL_VT_LOGIC) {
          case IVL_VT_REAL:
            draw_eval_real(rval);
            fprintf(vvp_out, "    %%pop/real 1; discard invalid-slot RHS\n");
            break;
          case IVL_VT_STRING:
            draw_eval_string(rval);
            fprintf(vvp_out, "    %%pop/str 1; discard invalid-slot RHS\n");
            break;
          case IVL_VT_CLASS:
          case IVL_VT_DARRAY:
          case IVL_VT_QUEUE:
          case IVL_VT_NO_TYPE:
            errors += draw_eval_object(rval);
            fprintf(vvp_out, "    %%pop/obj 1, 0; discard invalid-slot RHS\n");
            break;
          default:
            draw_eval_vec4(rval);
            fprintf(vvp_out, "    %%pop/vec4 1; discard invalid-slot RHS\n");
            break;
      }

      fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
              "\"fixed unpacked-array property index is undefined or out of range; "
              "write was ignored\" {0 0 0 0};\n",
              ivl_file_table_index(ivl_stmt_file(net)),
              ivl_stmt_lineno(net));
      return errors;
}

static int show_stmt_assign_sig_cobject(ivl_statement_t net)
{
      int errors = 0;
      ivl_lval_t lval = ivl_stmt_lval(net, 0);
      ivl_expr_t rval = ivl_stmt_rval(net);
      unsigned lwid = ivl_lval_width(lval);
      int prop_idx = ivl_lval_property_idx(lval);
      static int warned_prop_unhandled_type = 0;

      /* Signal-backed queue slices are handled by show_stmt_assign_sig_queue,
       * but no object-receiver slice-store opcode exists. Reject a scalar
       * class queue property here before drawing its receiver; otherwise the
       * slice lower bound is silently reinterpreted as one element index. */
      if (prop_idx >= 0 && ivl_lval_is_queue_slice(lval)) {
            fprintf(stderr, "%s:%u: sorry: assignment to a queue suffix "
                    "slice through an object-backed class property is not "
                    "supported.\n", ivl_stmt_file(net),
                    ivl_stmt_lineno(net));
            return 1;
      }

      if (prop_idx >= 0) {
	    ivl_type_t sig_type = draw_lval_expr(lval);
	    ivl_type_t prop_type = ivl_type_prop_type(sig_type, prop_idx);
	    unsigned lab_null = local_count++;
	    unsigned lab_out = local_count++;
	    int whole_fixed_array =
		  !ivl_lval_idx(lval) && !ivl_lval_part_off(lval)
		  && type_is_fixed_uarray_property_(prop_type);
	    ivl_expr_t fixed_slot_expr = ivl_lval_idx(lval);
	    ivl_type_t lval_type = ivl_lval_net_type(lval);
	    int fixed_array_slice = ivl_lval_is_array_slice(lval)
		  && fixed_slot_expr
		  && type_is_fixed_uarray_property_(prop_type)
		  && type_is_fixed_uarray_property_(lval_type);
	    ivl_type_t fixed_slot_type =
		  fixed_slot_expr && !fixed_array_slice
		  && type_is_fixed_uarray_property_(prop_type)
		  ? ivl_type_element(prop_type) : 0;
	    int fixed_container_slot = fixed_slot_type
		  && (ivl_type_base(fixed_slot_type) == IVL_VT_QUEUE
		      || ivl_type_base(fixed_slot_type) == IVL_VT_DARRAY);
	    int fixed_scalar_slot = fixed_slot_type && !fixed_container_slot;
	    ivl_type_t value_type = fixed_scalar_slot
		  ? fixed_slot_type : prop_type;
	    int fixed_slot_word = 0;
	    int fixed_slot_x_flag = -1;
	    int fixed_slot_in_range_flag = -1;
	    unsigned lab_bad_fixed_slot = fixed_scalar_slot
		  ? local_count++ : 0;
	    ivl_type_t whole_fixed_leaf = whole_fixed_array
		  ? ivl_type_element(prop_type) : 0;
	    int whole_fixed_container_array = whole_fixed_leaf
		  && (ivl_type_base(whole_fixed_leaf) == IVL_VT_QUEUE
		      || ivl_type_base(whole_fixed_leaf) == IVL_VT_DARRAY);

	    /* Dynamic null-handle guard: if the receiver object is null, skip
	       property assignment and pop the receiver object without issuing
	       %store/prop* opcodes. */
	    fprintf(vvp_out, "    %%test_nul/obj;\n");
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
	    if (fixed_scalar_slot) {
		  fixed_slot_word = allocate_word();
		  draw_fixed_uarray_slot_index_(fixed_slot_expr, prop_type,
					       fixed_slot_word,
					       &fixed_slot_x_flag,
					       &fixed_slot_in_range_flag);
		  fprintf(vvp_out,
			  "    %%jmp/1xz T_%u.%u, %d; fixed property slot is X/Z\n",
			  thread_count, lab_bad_fixed_slot, fixed_slot_x_flag);
		  fprintf(vvp_out,
			  "    %%jmp/0xz T_%u.%u, %d; fixed property slot is OOB\n",
			  thread_count, lab_bad_fixed_slot,
			  fixed_slot_in_range_flag);
	    }

	    if (fixed_array_slice) {
		  ivl_type_t slice_element_type = ivl_type_element(lval_type);

		  if (ivl_lval_part_off(lval) || ivl_stmt_opcode(net) != 0
		      || ivl_expr_type(rval) != IVL_EX_ARRAY_PATTERN) {
			fprintf(stderr, "%s:%u: sorry: fixed unpacked-array "
				"property slices currently require a simple blocking "
				"assignment-pattern value.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			fprintf(vvp_out,
				"    %%pop/obj 1, 0; unsupported fixed property slice store\n");
			errors += 1;
		  } else {
			int wreg = allocate_word();
			unsigned int base = array_pattern_base_(lval);
			ivl_variable_type_t element_kind =
			      ivl_type_base(slice_element_type);

			switch (element_kind) {
			    case IVL_VT_BOOL:
			    case IVL_VT_LOGIC:
				draw_prop_array_pattern(
				      prop_idx,
				      ivl_type_prop_name(sig_type, prop_idx),
				      rval, wreg, base);
				break;
			    case IVL_VT_REAL:
				draw_prop_real_array_pattern(
				      prop_idx,
				      ivl_type_prop_name(sig_type, prop_idx),
				      rval, wreg, base);
				break;
			    case IVL_VT_STRING:
				draw_prop_str_array_pattern(
				      prop_idx,
				      ivl_type_prop_name(sig_type, prop_idx),
				      rval, wreg, base);
				break;
			    default:
				fprintf(stderr, "%s:%u: sorry: assignment-pattern "
					"store to a fixed property slice with element "
					"type %d is not supported.\n",
					ivl_stmt_file(net), ivl_stmt_lineno(net),
					element_kind);
				errors += 1;
				break;
			}
			clr_word(wreg);
			fprintf(vvp_out, "    %%pop/obj 1, 0; fixed property slice store\n");
		  }

	    } else if (fixed_container_slot) {
		  int slot_word;

		  if (ivl_lval_part_off(lval) || ivl_stmt_opcode(net) != 0) {
			fprintf(stderr, "%s:%u: sorry: selected fixed-array container "
				"properties do not support packed or compound whole-container "
				"assignment.\n", ivl_stmt_file(net),
				ivl_stmt_lineno(net));
			fprintf(vvp_out, "    %%pop/obj 1, 0; unsupported fixed container slot store\n");
			errors += 1;
		  } else {
			ivl_scope_t rv_def = ivl_expr_type(rval) == IVL_EX_UFUNC
			      ? ivl_expr_def(rval) : 0;
			ivl_signal_t rv_ret = rv_def ? ivl_scope_port(rv_def, 0) : 0;
			int slot_x_flag = -1;
			int slot_in_range_flag = -1;
			unsigned lab_bad_slot = local_count++;
			unsigned lab_slot_done = local_count++;

			/* The fixed prefix is a PROPERTY SLOT index, not a dynamic
			 * container element index. Container property storage keeps
			 * every fixed slot independent. */
			if (ivl_expr_type(rval) == IVL_EX_ARRAY
			    && ivl_type_base(fixed_slot_type) == IVL_VT_QUEUE) {
			      errors += draw_fixed_uarray_queue_object_(
				    rval, fixed_slot_type);
			} else if (rv_ret && ivl_signal_dimensions(rv_ret) > 0) {
			      if (ivl_type_base(fixed_slot_type) == IVL_VT_QUEUE) {
				    /* Convert a fixed-array result to the selected queue
				     * leaf and enforce that leaf's declared bound. */
				    draw_ufunc_uarray_object(
					  rval, 1,
					  ivl_type_queue_max_size(fixed_slot_type));
			      } else {
				    draw_ufunc_uarray_object(rval, 0, 0);
			      }
			} else if (ivl_type_queue_assoc_compat(fixed_slot_type)
			    && expr_is_assoc_default_(rval)) {
			      errors += draw_eval_assoc_default(
				    rval, ivl_type_element(fixed_slot_type));
			} else if (ivl_type_base(fixed_slot_type) == IVL_VT_QUEUE) {
			      errors += draw_eval_nested_object_value_(
				    rval, fixed_slot_type, 1);
			} else {
			      errors += draw_eval_nested_object_value_(
				    rval, fixed_slot_type, 0);
			}
			slot_word = allocate_word();
			draw_fixed_uarray_slot_index_(fixed_slot_expr, prop_type,
						      slot_word, &slot_x_flag,
						      &slot_in_range_flag);
			fprintf(vvp_out,
				"    %%jmp/1xz T_%u.%u, %d; fixed property slot is X/Z\n",
				thread_count, lab_bad_slot, slot_x_flag);
			if (slot_in_range_flag >= 0)
			      fprintf(vvp_out,
				      "    %%jmp/0xz T_%u.%u, %d; fixed property slot is OOB\n",
				      thread_count, lab_bad_slot, slot_in_range_flag);
			fprintf(vvp_out, "    %%store/prop/obj %d, %d; fixed-array container slot\n",
				prop_idx, slot_word);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				thread_count, lab_slot_done);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_bad_slot);
			fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
				"\"fixed unpacked-array property index is undefined or out of range; "
				"write was ignored\" {0 0 0 0};\n",
				ivl_file_table_index(ivl_stmt_file(net)),
				ivl_stmt_lineno(net));
			fprintf(vvp_out, "    %%pop/obj 2, 0; invalid fixed container slot store\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_slot_done);
			clr_word(slot_word);
			clr_flag(slot_x_flag);
			if (slot_in_range_flag >= 0)
			      clr_flag(slot_in_range_flag);
		  }

	    } else if (whole_fixed_container_array) {
		  /* Whole-array assignment to a fixed property whose words are
		   * queues / dynamic / associative arrays: the source is a
		   * container-per-word array and the copy-back installs a
		   * by-value copy of each word (7.6). */
		  errors += draw_eval_object(rval);
		  fprintf(vvp_out, "    %%store/prop/arr/dar %d;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

	    } else if (whole_fixed_array
		&& (ivl_expr_value(rval) == IVL_VT_DARRAY
		    || ivl_expr_value(rval) == IVL_VT_QUEUE)) {
		  errors += draw_eval_object(rval);
		  fprintf(vvp_out, "    %%store/prop/arr/dar %d;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

	    } else if (ivl_type_base(value_type) == IVL_VT_BOOL ||
	        ivl_type_base(value_type) == IVL_VT_LOGIC) {
		  int prop_word_idx = 0;
		  ivl_expr_t idx_expr = ivl_lval_idx(lval);
		  ivl_expr_t part_off_ex = ivl_lval_part_off(lval);
		  ivl_expr_t dynamic_carrier =
			ivl_lval_dynamic_part_carrier(lval);
		  unsigned carrier_wid =
			ivl_lval_part_carrier_width(lval);
		  uint64_t negative_part_off_bits = 0;
		  int negative_part_off_fits = part_off_ex
			&& packed_property_negative_offset_bits64_(
			      part_off_ex, &negative_part_off_bits);

		  /* Whole-array assignment pattern into a logic-array
		     property (`obj.arr = '{...}` where arr is an unpacked
		     array of packed values).  draw_eval_vec4 cannot evaluate
		     an array pattern (it is not a single vector) and used to
		     fall through to a zero fallback, silently clobbering the
		     array.  Store each element to its own word instead. */
		  if (!idx_expr && !part_off_ex &&
		      ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
			int wreg = allocate_word();
			draw_prop_array_pattern(prop_idx,
						ivl_type_prop_name(sig_type, prop_idx),
						rval, wreg, 0);
			clr_word(wreg);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			/* Emit the null-guard epilogue inline and return. */
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			return errors;
		  }

		    /* A defined constant outside the run-time signed offset range
		       is wholly out of bounds. The same is true of a nonnegative
		       constant outside the compact unsigned literal range. Evaluate
		       the RHS (and therefore any function side effects), discard its
		       converted value, and leave the property unchanged. */
		  if (part_off_ex && !idx_expr
		      && (ivl_expr_type(part_off_ex) == IVL_EX_NUMBER
			  || ivl_expr_type(part_off_ex) == IVL_EX_ULONG)
		      && !packed_property_offset_is_unknown_(part_off_ex)
		      && ((packed_property_offset_is_negative_(part_off_ex)
			   && !negative_part_off_fits)
			  || (!packed_property_offset_is_negative_(part_off_ex)
			      && !packed_property_offset_is_immediate_(
				    part_off_ex)))) {
			draw_eval_vec4(rval);
			resize_property_vec4_wid(rval, lwid);
			fprintf(vvp_out, "    %%pop/vec4 1; Discard RHS for "
				"out-of-range property offset\n");
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				thread_count, lab_out);
			fprintf(vvp_out, "T_%u.%u;\n",
				thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n",
				thread_count, lab_out);
			return errors;
		  }

		  /* Packed struct field write via bit-offset RMW.  This is
		     generated when a VIF packed-struct property field is
		     used as an l-value (e.g. cfg.vif.h2d_int.a_valid <= 1).
		     The part_off_ex holds the field's bit offset within the
		     property and lwid is the field width. */
		  if (part_off_ex && !idx_expr &&
		      packed_property_offset_is_immediate_(part_off_ex)) {
			unsigned bitoff = (unsigned)ivl_expr_uvalue(part_off_ex);
			/* Compound assignment (`fld |= x`) needs the current
			   field value on the stack before the r-value so the
			   binary opcode has both operands. Load the whole
			   property and part-select [bitoff+:lwid]. */
			if (ivl_stmt_opcode(net) != 0) {
			      fprintf(vvp_out, "    %%prop/v %d;\n", prop_idx);
			      fprintf(vvp_out, "    %%parti/u %u, %u, 32;\n",
				      lwid, bitoff);
			}
			/* The helper forces runtime sizing even when the static
			   expression width matches (specialized VIF properties). */
			draw_stmt_assign_vector_rhs(net, lwid);
			fprintf(vvp_out,
				"    %%store/prop/v/bits %d, %u, %u;"
				" Store field [%u+:%u] of property %s\n",
				prop_idx, bitoff, lwid, bitoff, lwid,
				ivl_type_prop_name(sig_type, prop_idx));
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			/* Emit the null-guard epilogue inline and return. */
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			return errors;
		  }

		  /* Variable bit-offset RMW: a bit-select or indexed part-
		     select of a vector property with a run-time offset (e.g.
		     `obj.m_bits[i +: 4] = ...`).  The canonical bit offset is
		     evaluated into an index register and consumed by the
		     signed %store/prop/v/bits/x or unsigned
		     %store/prop/v/bits/ux handler, which read-modify-writes the
		     property so bits outside [off+:wid] are preserved. */
		  if (part_off_ex && !idx_expr) {
			int off_reg = allocate_word();
			int off_flag = allocate_flag();
			int carrier_reg = 0;
			int carrier_flag = 0;
			int signed_offset = ivl_expr_signed(part_off_ex);
			const char*store_opcode = signed_offset
			      ? "%store/prop/v/bits/x"
			      : "%store/prop/v/bits/ux";
			if (dynamic_carrier && carrier_wid == 0) {
			      fprintf(stderr,
				      "vvp.tgt error: dynamic packed-property carrier has zero width.\n");
			      vvp_errors += 1;
			      return errors + 1;
			}
			if (ivl_stmt_opcode(net) != 0) {
			      /* Compound assignment: select the packed carrier first so
				 an out-of-range inner part sees X, not adjacent bits. */
			      fprintf(vvp_out, "    %%prop/v %d;\n", prop_idx);
			      if (dynamic_carrier) {
				    carrier_reg = allocate_word();
				    carrier_flag = allocate_flag();
				    draw_eval_vec4(dynamic_carrier);
				    fprintf(vvp_out, "    %%dup/vec4;\n");
				    fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
					    ivl_expr_signed(dynamic_carrier)
						  ? "/s" : "", carrier_reg);
				    fprintf(vvp_out,
					    "    %%flag_mov %d, 4; capture carrier validity\n",
					    carrier_flag);
				    fprintf(vvp_out,
					    "    %%part/u %u; select packed carrier\n",
					    carrier_wid);
			      }
			      draw_eval_vec4(part_off_ex);
			      fprintf(vvp_out, "    %%dup/vec4;\n");
			      fprintf(vvp_out, "    %%ix/vec4%s %d;\n",
				      signed_offset ? "/s" : "", off_reg);
			      if (dynamic_carrier)
				    fprintf(vvp_out,
					    "    %%flag_or 4, %d; combine carrier validity\n",
					    carrier_flag);
			      fprintf(vvp_out, "    %%flag_mov %d, 4;\n",
				      off_flag);
			      fprintf(vvp_out, "    %%part/%c %u;\n",
				      signed_offset ? 's' : 'u', lwid);
			} else {
			      if (dynamic_carrier) {
				    carrier_reg = allocate_word();
				    carrier_flag = allocate_flag();
				    draw_eval_expr_into_integer(dynamic_carrier,
							       carrier_reg);
				    fprintf(vvp_out,
					    "    %%flag_mov %d, 4; capture carrier validity\n",
					    carrier_flag);
			      }
			      if (negative_part_off_fits)
				    emit_packed_property_negative_offset_(
					  off_reg, negative_part_off_bits);
			      else
				    draw_eval_expr_into_integer(part_off_ex,
							 off_reg);
			      if (dynamic_carrier)
				    fprintf(vvp_out,
					    "    %%flag_or 4, %d; combine carrier validity\n",
					    carrier_flag);
			      fprintf(vvp_out, "    %%flag_mov %d, 4;\n",
				      off_flag);
			}
			draw_stmt_assign_vector_rhs(net, lwid);
			  /* R-value evaluation and a compound opcode may change flag
			     4. Restore the offset-validity flag immediately before
			     the run-time partial store consumes it. */
			fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
			if (dynamic_carrier) {
			      fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
				      carrier_wid);
			      fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
				      off_reg, carrier_reg);
			}
			fprintf(vvp_out,
				"    %s %d, %d, %u;"
				" Store field [<var>+:%u] of property %s\n",
				store_opcode, prop_idx, off_reg,
				dynamic_carrier ? 0 : lwid, lwid,
				ivl_type_prop_name(sig_type, prop_idx));
			clr_word(off_reg);
			clr_flag(off_flag);
			if (carrier_reg) {
			      clr_word(carrier_reg);
			      clr_flag(carrier_flag);
			}
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			/* Emit the null-guard epilogue inline and return. */
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			return errors;
		  }

		  /* Element index PLUS a bit/part-select on the element
		     (c.arr[i][m:l] = v): read-modify-write the ELEMENT via
		     %prop/v/i, merge with %setbits, store back. */
		  if (idx_expr && part_off_ex && ivl_stmt_opcode(net) == 0) {
			ivl_type_t elem_t = ivl_type_element(prop_type);
			unsigned elem_wid = elem_t
			      ? ivl_type_packed_width(elem_t)
			      : ivl_type_packed_width(prop_type);
			prop_word_idx = fixed_scalar_slot
			      ? fixed_slot_word : allocate_word();
			if (!fixed_scalar_slot)
			      draw_eval_expr_into_integer(idx_expr, prop_word_idx);
			fprintf(vvp_out, "    %%prop/v/i %d, %d;\n",
				prop_idx, prop_word_idx);
			int off_word = allocate_word();
			int off_flag = allocate_flag();
			draw_eval_expr_into_integer(part_off_ex, off_word);
			fprintf(vvp_out, "    %%flag_mov %d, 4;\n", off_flag);
			draw_eval_vec4(rval);
			resize_property_vec4_wid(rval, lwid);
			fprintf(vvp_out, "    %%flag_mov 4, %d;\n", off_flag);
			fprintf(vvp_out, "    %%setbits/vec4/x %d, %u;\n",
				off_word, lwid);
			clr_word(off_word);
			clr_flag(off_flag);
			fprintf(vvp_out, "    %%store/prop/v/i %d, %d, %u;"
				" RMW element part of property %s\n",
				prop_idx, prop_word_idx, elem_wid,
				ivl_type_prop_name(sig_type, prop_idx));
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
			if (fixed_scalar_slot) {
			      fprintf(vvp_out, "T_%u.%u;\n", thread_count,
				      lab_bad_fixed_slot);
			      errors += draw_discard_fixed_property_rhs_(
				      net, rval, value_type, part_off_ex);
			      fprintf(vvp_out, "    %%pop/obj 1, 0; invalid fixed slot receiver\n");
			      fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				      thread_count, lab_out);
			}
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			if (fixed_scalar_slot) {
			      clr_word(fixed_slot_word);
			      clr_flag(fixed_slot_x_flag);
			      clr_flag(fixed_slot_in_range_flag);
			} else {
			      clr_word(prop_word_idx);
			}
			return errors;
		  }

		  if (idx_expr) {
			prop_word_idx = fixed_scalar_slot
			      ? fixed_slot_word : allocate_word();
			if (!fixed_scalar_slot)
			      draw_eval_expr_into_integer(idx_expr, prop_word_idx);
		  }

		  if (ivl_stmt_opcode(net) != 0) {
			if (prop_word_idx)
			      fprintf(vvp_out, "    %%prop/v/i %d, %d;\n", prop_idx, prop_word_idx);
			else
			      fprintf(vvp_out, "    %%prop/v %d;\n", prop_idx);
			fprintf(vvp_out, "    %%pad/%s %u; property l-value width\n",
				ivl_type_signed(value_type) ? "s" : "u", lwid);
		  }

		  draw_stmt_assign_vector_rhs(net, lwid);

		  if (ivl_type_base(value_type) == IVL_VT_BOOL &&
		      ivl_expr_value(rval) != IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");

		  if (prop_word_idx)
			fprintf(vvp_out, "    %%store/prop/v/i %d, %d, %u; Store in logic property %s\n",
				prop_idx, prop_word_idx, lwid, ivl_type_prop_name(sig_type, prop_idx));
		  else
			fprintf(vvp_out, "    %%store/prop/v %d, %u; Store in logic property %s\n",
				prop_idx, lwid, ivl_type_prop_name(sig_type, prop_idx));
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  if (prop_word_idx && !fixed_scalar_slot)
			clr_word(prop_word_idx);

	    } else if (ivl_type_base(value_type) == IVL_VT_REAL) {
		  ivl_expr_t idx_expr = ivl_lval_idx(lval);

		    /* Whole-array pattern into a real-array property. */
		  if (!idx_expr &&
		      ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
			int wreg = allocate_word();
			draw_prop_real_array_pattern(prop_idx,
						     ivl_type_prop_name(sig_type, prop_idx),
						     rval, wreg, 0);
			clr_word(wreg);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			return errors;
		  }

		  if (idx_expr) {
			  /* Element of a real-array property (`obj.arr[i]`). */
			int wreg = fixed_scalar_slot
			      ? fixed_slot_word : allocate_word();
			if (!fixed_scalar_slot)
			      draw_eval_expr_into_integer(idx_expr, wreg);
			if (ivl_stmt_opcode(net) != 0)
			      fprintf(vvp_out, "    %%prop/r/i %d, %d;\n", prop_idx, wreg);
			draw_eval_real(rval);
			draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));
			fprintf(vvp_out, "    %%store/prop/r/i %d, %d;"
				" Store in real property %s\n",
				prop_idx, wreg, ivl_type_prop_name(sig_type, prop_idx));
			if (!fixed_scalar_slot)
			      clr_word(wreg);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

		  } else {
			if (ivl_stmt_opcode(net) != 0) {
			      fprintf(vvp_out, "    %%prop/r %d;\n", prop_idx);
			}

			  /* Calculate the real value into the real value
			     stack. The %store/prop/r will pop the stack
			     value. */
			draw_eval_real(rval);

			draw_stmt_assign_real_opcode(ivl_stmt_opcode(net));

			fprintf(vvp_out, "    %%store/prop/r %d;\n", prop_idx);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  }

	    } else if (ivl_type_base(value_type) == IVL_VT_STRING) {
		  ivl_expr_t idx_expr = ivl_lval_idx(lval);

		    /* Whole-array pattern into a string-array property. */
		  if (!idx_expr &&
		      ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN) {
			int wreg = allocate_word();
			draw_prop_str_array_pattern(prop_idx,
						    ivl_type_prop_name(sig_type, prop_idx),
						    rval, wreg, 0);
			clr_word(wreg);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
			return errors;
		  }

		  if (idx_expr) {
			  /* Element of a string-array property. */
			int wreg = fixed_scalar_slot
			      ? fixed_slot_word : allocate_word();
			if (!fixed_scalar_slot)
			      draw_eval_expr_into_integer(idx_expr, wreg);
			draw_eval_string(rval);
			fprintf(vvp_out, "    %%store/prop/str/i %d, %d;"
				" Store in string property %s\n",
				prop_idx, wreg, ivl_type_prop_name(sig_type, prop_idx));
			if (!fixed_scalar_slot)
			      clr_word(wreg);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  } else {
			  /* Calculate the string value into the string value
			     stack. The %store/prop/str will pop the stack
			     value. */
			draw_eval_string(rval);
			fprintf(vvp_out, "    %%store/prop/str %d;\n", prop_idx);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  }

	    } else if (ivl_type_base(value_type) == IVL_VT_DARRAY) {
		  int handled_errors = show_stmt_assign_sig_prop_darray_index(net,
		                                                           prop_idx,
		                                                           prop_type);
		  if (handled_errors >= 0) {
			errors += handled_errors;
		  } else {
			int idx = 0;

			  /* The property is a darray, and there is no mux
			     expression to the assignment is of an entire
			     array object. */
			int converted = draw_eval_container_value_for_target(
			      rval, prop_type);
			if (converted >= 0)
			      errors += converted;
			else
			      errors += draw_eval_object_value_copy(rval,
								    prop_type);
			fprintf(vvp_out, "    %%store/prop/obj %d, %d; IVL_VT_DARRAY\n",
			        prop_idx, idx);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  }

	    } else if (ivl_type_base(value_type) == IVL_VT_CLASS) {
		  int idx = 0;
		  ivl_expr_t idx_expr;
		  if ( (idx_expr = ivl_lval_idx(lval)) ) {
			idx = fixed_scalar_slot
			      ? fixed_slot_word : allocate_word();
		  }

		    /* The property is a class object. */
		  errors += draw_eval_object(rval);
		  if (idx_expr && !fixed_scalar_slot)
			draw_eval_expr_into_integer(idx_expr, idx);
		  fprintf(vvp_out, "    %%store/prop/obj %d, %d; IVL_VT_CLASS\n", prop_idx, idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

		  if (idx_expr && !fixed_scalar_slot)
			clr_word(idx);

		    } else if (ivl_type_base(value_type) == IVL_VT_QUEUE) {
			  if (ivl_type_queue_assoc_compat(prop_type)
			      && !ivl_lval_idx(lval)
			      && expr_is_assoc_default_(rval)) {
				ivl_type_t elem_type = ivl_type_element(prop_type);
				errors += draw_eval_assoc_default(rval, elem_type);
				fprintf(vvp_out, "    %%store/prop/obj %d, 0;\n",
					prop_idx);
				fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			  } else {
				int handled_errors = show_stmt_assign_sig_prop_assoc_index(net,
				                                                     prop_idx,
				                                                     prop_type);
				if (handled_errors >= 0) {
				      errors += handled_errors;
				} else {
				  handled_errors = show_stmt_assign_sig_prop_queue_index(net,
			                                                           prop_idx,
			                                                           prop_type);
				  if (handled_errors >= 0) {
					errors += handled_errors;
				  } else {
				ivl_scope_t rv_def = ivl_expr_type(rval) == IVL_EX_UFUNC
			      ? ivl_expr_def(rval) : 0;
			ivl_signal_t rv_ret = rv_def ? ivl_scope_port(rv_def, 0) : 0;
			if (ivl_expr_type(rval) == IVL_EX_ARRAY) {
			      errors += draw_fixed_uarray_queue_object_(rval,
							 prop_type);
			      fprintf(vvp_out, "    %%store/prop/obj %d, 0;"
				      " fixed array to queue\n", prop_idx);
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			} else if (rv_ret && ivl_signal_dimensions(rv_ret) > 0) {
			      /* NetEUFunc now carries the fixed aggregate type, so a
			       * fixed-array return is a legal queue RHS. Its IVL value
			       * category is still the element's scalar category; routing
			       * on ivl_expr_value() below would evaluate an array-returning
			       * function as vec4/real/string even though %callf/void leaves
			       * no such stack value. Materialize directly as a queue and
			       * store that queue object in the property. */
			      draw_ufunc_uarray_object(
				    rval, 1, ivl_type_queue_max_size(prop_type));
			      fprintf(vvp_out, "    %%store/prop/obj %d, 0;"
				      " fixed-array function return to queue\n",
				      prop_idx);
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			} else {
			ivl_variable_type_t rv_type = ivl_expr_value(rval);
			if (rv_type == IVL_VT_CLASS ||
			    rv_type == IVL_VT_DARRAY ||
			    rv_type == IVL_VT_QUEUE ||
			    ivl_expr_type(rval) == IVL_EX_NULL) {
			      /* The property setter applies the value copy, but only the
			       * target knows a bounded queue's declared maximum. */
			      errors += draw_eval_nested_object_value_(rval,
							   prop_type, 1);
			      fprintf(vvp_out, "    %%store/prop/obj %d, 0;"
				      " ; type-%d fallback\n", prop_idx,
				      ivl_type_base(prop_type));
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			} else {
			      /* Preserve RHS side effects, then coerce to null object. */
			      draw_eval_vec4(rval);
			      fprintf(vvp_out, "    %%pop/vec4 1;\n");
			      fprintf(vvp_out, "    %%null;\n");
			      fprintf(vvp_out, "    %%store/prop/obj %d, 0;"
				      " ; type-%d null-coerce fallback from rhs-type-%d\n",
				      prop_idx, ivl_type_base(prop_type), rv_type);
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			}
				}
			  }
			  }
			  }

		    } else if (ivl_type_base(value_type) == IVL_VT_NO_TYPE) {
		  ivl_variable_type_t rv_type = ivl_expr_value(rval);
		  ivl_type_t rval_type = ivl_expr_net_type(rval);
		  ivl_type_t nt_elem_type = ivl_type_element(prop_type);
		  int lval_is_value_struct =
			(ivl_type_properties(prop_type) > 0)
			|| (nt_elem_type
			    && ivl_type_properties(nt_elem_type) > 0);
		  int rval_is_value_struct =
			lval_is_value_struct
			&& rv_type != IVL_VT_CLASS
			&& rv_type != IVL_VT_DARRAY
			&& rv_type != IVL_VT_QUEUE
			&& ivl_expr_type(rval) != IVL_EX_NULL
			&& (rval_type == 0
			    || ivl_type_base(rval_type) == IVL_VT_NO_TYPE);
		  ivl_expr_t no_type_idx_expr = ivl_lval_idx(lval);

		    /* An unpacked struct stored into a slot of a FIXED-SIZE
		       unpacked array property. The branch below ignores the
		       l-value index entirely and, because a struct r-value
		       is not one of the object-like value kinds it tests
		       for, took the "coerce to null" path -- so the element
		       was silently left empty and every slot read back
		       zero. Store the struct as an object, value-copied
		       (7.2), into the slot the index names. */
		  if (rval_is_value_struct) {
			int nt_idx = 0;
			ivl_type_t nt_elem = nt_elem_type;
			if (no_type_idx_expr)
			      nt_idx = fixed_scalar_slot
				    ? fixed_slot_word : allocate_word();
			errors += draw_eval_object_value_copy(rval,
				      nt_elem ? nt_elem : value_type);
			if (no_type_idx_expr && !fixed_scalar_slot)
			      draw_eval_expr_into_integer(no_type_idx_expr,
						  nt_idx);
			fprintf(vvp_out, "    %%store/prop/obj %d, %d;"
				" ; value struct\n", prop_idx, nt_idx);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			if (no_type_idx_expr && !fixed_scalar_slot)
			      clr_word(nt_idx);
		  } else if (rv_type == IVL_VT_CLASS ||
			     rv_type == IVL_VT_DARRAY ||
			     rv_type == IVL_VT_QUEUE ||
			     ivl_expr_type(rval) == IVL_EX_NULL) {
			/* Queue or unresolved property: object-like RHS stores as object. */
			errors += draw_eval_object(rval);
			fprintf(vvp_out, "    %%store/prop/obj %d, 0;"
				" ; type-%d fallback\n", prop_idx,
				ivl_type_base(prop_type));
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  } else {
			/* Preserve RHS side effects, then coerce to null object. */
			draw_eval_vec4(rval);
			fprintf(vvp_out, "    %%pop/vec4 1;\n");
			fprintf(vvp_out, "    %%null;\n");
			fprintf(vvp_out, "    %%store/prop/obj %d, 0;"
				" ; type-%d null-coerce fallback from rhs-type-%d\n",
				prop_idx, ivl_type_base(prop_type), rv_type);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  }

		    } else {
			  if (!warned_prop_unhandled_type) {
				fprintf(stderr, "Warning: unhandled class property type %d;"
					" skipping assignment"
					" (further similar warnings suppressed)\n",
					ivl_type_base(prop_type));
				warned_prop_unhandled_type = 1;
			  }
			  fprintf(vvp_out, " ; skipped: unhandled prop type %d\n",
				  ivl_type_base(prop_type));
			  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    }
		    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
		    if (fixed_scalar_slot) {
			  fprintf(vvp_out, "T_%u.%u;\n", thread_count,
				  lab_bad_fixed_slot);
			  errors += draw_discard_fixed_property_rhs_(
				  net, rval, value_type, ivl_lval_part_off(lval));
			  fprintf(vvp_out,
				  "    %%pop/obj 1, 0; invalid fixed slot receiver\n");
			  fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				  thread_count, lab_out);
		    }
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
		    if (fixed_scalar_slot) {
			  clr_word(fixed_slot_word);
			  clr_flag(fixed_slot_x_flag);
			  clr_flag(fixed_slot_in_range_flag);
		    }

	      } else {
		    ivl_signal_t sig = ivl_lval_sig(lval);
		    int handled_errors;

                    if (sig) {
                          ivl_type_t net_type = ivl_signal_net_type(sig);
                          handled_errors = show_stmt_assign_sig_assoc_index(net, sig, net_type);
                          if (handled_errors >= 0)
                                return errors + handled_errors;
                    }

		    handled_errors = show_stmt_assign_nested_queue_slice(net);
		    if (handled_errors >= 0)
			  return errors + handled_errors;

		    handled_errors = show_stmt_assign_nested_index_vec4(net);
		    if (handled_errors >= 0)
			  return errors + handled_errors;

		    handled_errors = show_stmt_assign_nested_index_object(net);
		    if (handled_errors >= 0)
			  return errors + handled_errors;

		    assert(!ivl_lval_nest(lval));

		    if (ivl_expr_type(rval) == IVL_EX_ARRAY_PATTERN
			&& ivl_lval_idx(lval) == 0) {
			    /* Whole-array pattern assign (no element index):
			       draw_array_pattern distributes the pattern's
			       entries across the array's elements. */
			  draw_array_pattern(sig, rval, 0);
		  return 0;
	    }

	      /* A per-element assignment of an aggregate literal
		 (`arr[i] = '{...}`) has a word index on the l-value; the
		 pattern is a STRUCT literal for that one element, not a list
		 of array elements. Fall through to build the whole aggregate
		 object from the pattern (draw_eval_object handles the
		 IVL_EX_ARRAY_PATTERN aggregate the same way the scalar
		 `s = '{...}` case does) and store it into the indexed element
		 with %store/obja below. Feeding it to draw_array_pattern here
		 would mis-read the struct fields as successive array elements
		 and null them out. */

	      /* There is no property select, so evaluate the r-value as an
		 object and assign the entire object to the variable.

		 An object-backed unpacked struct has VALUE semantics: `y = x`
		 (or `arr[i] = x`) must copy x's contents into a fresh object,
		 not alias x's object — otherwise a later `y.field = ...` would
		 also mutate x. draw_eval_object_value_copy clones a value-struct
		 read; a class handle (reference) and a freshly built aggregate
		 pass through unchanged. (IEEE 1800-2017 7.2.) */
	    errors += draw_eval_object_value_copy(rval, ivl_signal_net_type(sig));

	    if (ivl_signal_dimensions(sig) > 0) {
		  unsigned ix;
		  ivl_expr_t aidx = ivl_lval_idx(lval);

		  draw_eval_expr_into_integer(aidx, (ix = allocate_word()));
		  fprintf(vvp_out, "    %%store/obja v%p, %u;\n", sig, ix);
		  clr_word(ix);

	    } else {
		    /* Not an array, so no index expression */
		  fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
	    }
      }

      return errors;
}

/* The element descriptor %store/arr/dar wants, in the same packed
   encoding %load/arr/dar uses (see of_LOAD_ARR_DAR). Returns 0 and
   reports if the element kind cannot be carried. */
int uarray_container_kind_(ivl_signal_t sig, unsigned*kind_out,
			   const char*file, unsigned lineno)
{
      ivl_variable_type_t dt = ivl_signal_data_type(sig);
      ivl_type_t net_type = ivl_signal_net_type(sig);
      unsigned wid = ivl_signal_width(sig);
      unsigned kind;

      switch (dt) {
	  case IVL_VT_REAL:
	    kind = 0;                           /* ARRDAR_REAL */
	    break;
	  case IVL_VT_STRING:
	    kind = VVP_ARRDAR_STRING;
	    break;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    if (wid == 0) wid = 1;
	    if (wid > VVP_ARRDAR_WIDTH_MAX) {
		  fprintf(stderr, "%s:%u: sorry: unpacked array `%s' has "
			  "%u-bit elements; the VVP array descriptor supports "
			  "integral widths through %u bits.\n",
			  file ? file : "<unknown>", lineno,
			  ivl_signal_basename(sig), wid,
			  VVP_ARRDAR_WIDTH_MAX);
		  vvp_errors += 1;
		  return 0;
	    }
	    kind = VVP_ARRDAR_WIDTH_KIND(wid)
		 | (ivl_signal_signed(sig) ? VVP_ARRDAR_SIGNED : 0u)
		 | ((dt == IVL_VT_LOGIC) ? VVP_ARRDAR_FOUR : 0u);
	    break;
	  case IVL_VT_CLASS:
	    kind = VVP_ARRDAR_OBJ;
	    break;
	  case IVL_VT_QUEUE:
	  case IVL_VT_DARRAY:
	      /* Fixed arrays of queues, dynamic arrays and associative arrays
		 move one container object per word, copied by value. */
	    kind = VVP_ARRDAR_OBJ | VVP_ARRDAR_COPY;
	    break;
	  case IVL_VT_NO_TYPE:
	      /* Unpacked structs are object-backed value elements too. */
	    if (net_type && ivl_type_properties(net_type) > 0) {
		  kind = VVP_ARRDAR_OBJ | VVP_ARRDAR_COPY;
		  break;
	    }
	    /* Fall through: an untyped, property-less element has no runtime
	       representation in an array descriptor. */
	  default:
	    fprintf(stderr, "%s:%u: sorry: the whole unpacked array `%s' "
		    "cannot receive a dynamic array or queue: only arrays "
		    "of integral, real, string, unpacked-struct or class-handle elements have a "
		    "matching element representation.\n",
		    file ? file : "<unknown>", lineno,
		    ivl_signal_basename(sig));
	    vvp_errors += 1;
	    return 0;
      }

      *kind_out = kind;
      return 1;
}

/* Marshal a fixed unpacked-array signal to the runtime container stack.
   This is the expression-free twin of eval_object_array(), used where a
   synthesized subroutine body has the formal signal but no IVL_EX_ARRAY
   node (notably fixed unpacked-array DPI imports). */
void emit_load_arr_dar_(ivl_signal_t sig, unsigned kind)
{
      int left = ivl_signal_array_dim_msb(sig, 0);
      int right = ivl_signal_array_dim_lsb(sig, 0);

      if (left > right)
	    kind |= VVP_ARRDAR_DESC;

      note_array_signal_use(sig);
      if (ivl_signal_dimensions(sig) > 1) {
	    unsigned dim;
	    for (dim = 0 ; dim < ivl_signal_dimensions(sig) ; dim += 1)
		  fprintf(vvp_out, "    %%dim/push %u, %u;\n",
			  (unsigned)ivl_signal_array_dim_msb(sig, dim),
			  (unsigned)ivl_signal_array_dim_lsb(sig, dim));
	    fprintf(vvp_out, "    %%load/arr/dar/md v%p, %u;\n", sig, kind);
	    return;
      }

      fprintf(vvp_out, "    %%load/arr/dar v%p, %u, %u;\n",
	      sig, kind, (unsigned)left);
}

void emit_load_arr_dar_slice_(ivl_signal_t sig, unsigned kind,
			      unsigned canonical_base, unsigned count,
			      int left, int right)
{
      assert(ivl_signal_dimensions(sig) == 1);
      assert(count > 0);
      if (left > right)
	    kind |= VVP_ARRDAR_DESC;
      else
	    kind &= ~VVP_ARRDAR_DESC;

      note_array_signal_use(sig);
      fprintf(vvp_out, "    %%slice/push %u, %u;\n",
	      canonical_base, count);
      fprintf(vvp_out, "    %%load/arr/dar/slice v%p, %u, %u;\n",
	      sig, kind, (unsigned)left);
}

/* Emit the container -> fixed-array store for one signal. A
   multi-dimensional destination is stored as one flat word array, so
   the declared shape has to be handed over separately before the
   nesting form of the instruction can walk the container back. */
void emit_store_arr_dar_(ivl_signal_t sig, unsigned kind)
{
      if (ivl_signal_dimensions(sig) > 1) {
	    unsigned dim;
	    for (dim = 0 ; dim < ivl_signal_dimensions(sig) ; dim += 1)
		  fprintf(vvp_out, "    %%dim/push %u, %u;\n",
			  (unsigned)ivl_signal_array_dim_msb(sig, dim),
			  (unsigned)ivl_signal_array_dim_lsb(sig, dim));
	    fprintf(vvp_out, "    %%store/arr/dar/md v%p, %u;\n", sig, kind);
	    return;
      }

      if (ivl_signal_array_dim_msb(sig, 0)
	  > ivl_signal_array_dim_lsb(sig, 0))
	    kind |= VVP_ARRDAR_DESC;

      fprintf(vvp_out, "    %%store/arr/dar v%p, %u;\n", sig, kind);
}

void emit_store_arr_dar_slice_(ivl_signal_t sig, unsigned kind,
			       unsigned canonical_base, unsigned count,
			       int left, int right)
{
      assert(ivl_signal_dimensions(sig) == 1);
      assert(count > 0);
      if (left > right)
	    kind |= VVP_ARRDAR_DESC;
      else
	    kind &= ~VVP_ARRDAR_DESC;

      fprintf(vvp_out, "    %%slice/push %u, %u;\n",
	      canonical_base, count);
      fprintf(vvp_out, "    %%store/arr/dar/slice v%p, %u;\n",
	      sig, kind);
}

/* A sized DPI array is passed to C as a pointer to contiguous elements. VVP
   stores every fixed multidimensional signal as one canonical flat word
   array already, so constructing the nested svOpenArrayHandle object tree
   would both be unnecessary and hide the leaf storage from the direct-pointer
   marshaler. Preserve the one-dimensional declared-range behavior and use the
   ordinary flat instructions for additional dimensions. */
void emit_load_arr_dar_dpi_(ivl_signal_t sig, unsigned kind)
{
      if (ivl_signal_dimensions(sig) <= 1) {
	      /* Sized DPI arrays use Annex H's canonical C layout (numeric
	       * low index first). Do not apply the SystemVerilog value-assignment
	       * direction bit used by emit_load_arr_dar_. */
	    note_array_signal_use(sig);
	    fprintf(vvp_out, "    %%load/arr/dar v%p, %u, 0;"
		    " flat fixed DPI array\n", sig, kind);
	    return;
      }

      note_array_signal_use(sig);
      fprintf(vvp_out, "    %%load/arr/dar v%p, %u, 0;"
	      " flat fixed DPI array\n", sig, kind);
}

void emit_store_arr_dar_dpi_(ivl_signal_t sig, unsigned kind)
{
      if (ivl_signal_dimensions(sig) <= 1) {
	      /* A sized DPI array uses Annex H's canonical C layout (numeric
	       * low index first), not SystemVerilog 7.6 left-to-right value
	       * assignment. Keep its store descriptor direction-neutral. */
	    fprintf(vvp_out, "    %%store/arr/dar v%p, %u;"
		    " flat fixed DPI array\n", sig, kind);
	    return;
      }

      fprintf(vvp_out, "    %%store/arr/dar v%p, %u;"
	      " flat fixed DPI array\n", sig, kind);
}

/* `fa = da' and its siblings: a WHOLE fixed-size unpacked array l-value
   receiving an array value (IEEE 1800-2017 7.6). Fixed-array r-values
   are first marshaled into passive container storage by draw_eval_object.
   %load/arr/dar has marshaled the other direction since M10-1; this is
   the return trip, and it is the single instruction every legal
   container -> fixed-array copy goes through -- the plain assignment
   here, a struct member's assignment, and the copy-back of an
   `inout'/`ref'/`output' open-array formal into a fixed-array actual
   (13.5.2), which elaboration lowers to exactly this assignment. */
static int show_stmt_assign_uarray_from_container(ivl_statement_t net,
						  ivl_signal_t sig)
{
      ivl_expr_t rval = ivl_stmt_rval(net);
      unsigned kind;

      if (!uarray_container_kind_(sig, &kind, ivl_stmt_file(net),
				  ivl_stmt_lineno(net)))
	    return 1;

      draw_eval_object(rval);
      note_array_signal_use(sig);
      emit_store_arr_dar_(sig, kind);
      return 0;
}

/* True when an r-value expression is a WHOLE array value.

   ivl_expr_value() is not the test: a signal expression naming a
   dynamic array reports its ELEMENT type (IVL_VT_LOGIC for `int da[]'),
   because that is what a read of it usually yields. The container-ness
   is on the signal, so ask the signal -- and only when the expression
   carries no word index, which would make it an element read after
   all. */
static int rval_is_whole_container_(ivl_expr_t rv)
{
      ivl_type_t nt;

      if (!rv)
	    return 0;

      if (vvp_expr_is_fixed_uarray_value(rv))
	    return 1;

      if (ivl_expr_type(rv) == IVL_EX_SIGNAL && !ivl_expr_oper1(rv)) {
	    ivl_signal_t rsig = ivl_expr_signal(rv);
	    ivl_variable_type_t dt = rsig ? ivl_signal_data_type(rsig)
					  : IVL_VT_NO_TYPE;
	    if (rsig && ivl_signal_dimensions(rsig) == 0
		&& (dt == IVL_VT_DARRAY || dt == IVL_VT_QUEUE))
		  return 1;
      }

      nt = ivl_expr_net_type(rv);
	/* An expression such as map() can return a fixed unpacked-array type
	 * without being an IVL_EX_ARRAY signal. Route it through the same
	 * container-to-fixed-array store as other whole-array r-values. */
      if (nt && (type_is_fixed_uarray_property_(nt)
		 || ivl_type_base(nt) == IVL_VT_DARRAY
		 || ivl_type_base(nt) == IVL_VT_QUEUE))
	    return 1;

      return 0;
}

/* True for an l-value that names a whole unpacked array -- no word
   index, no part select, not nested inside a class object. */
static int lval_is_whole_uarray_(ivl_lval_t lval, ivl_signal_t sig)
{
      if (!sig || ivl_signal_dimensions(sig) == 0)
	    return 0;
      if (ivl_lval_nest(lval))
	    return 0;
      if (ivl_lval_idx(lval))
	    return 0;
      if (ivl_lval_part_off(lval))
	    return 0;
      return 1;
}

static int stream_lval_is_dynamic_(ivl_lval_t lval)
{
      ivl_type_t type = ivl_lval_net_type(lval);
      if (!type)
	    return 0;

      switch (ivl_type_base(type)) {
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_STRING:
	    return 1;
	  default:
	    return 0;
      }
}

static const char* stream_range_name_(ivl_stream_range_t kind)
{
      switch (kind) {
	  case IVL_STREAM_RANGE_INDEX: return "index";
	  case IVL_STREAM_RANGE_RANGE: return "range";
	  case IVL_STREAM_RANGE_UP:    return "up";
	  case IVL_STREAM_RANGE_DOWN:  return "down";
	  default: return "none";
      }
}

static int eval_stream_range_(ivl_lval_t lval, int*first_reg,
			      int*second_reg)
{
      ivl_expr_t first = ivl_lval_stream_range_first(lval);
      ivl_expr_t second = ivl_lval_stream_range_second(lval);
      if (!first)
	    return 0;

      *first_reg = allocate_word();
      *second_reg = allocate_word();
      draw_eval_expr_into_integer(first, *first_reg);
      fprintf(vvp_out, "    %%stream/range/mark %d, 4;\n", *first_reg);
      if (second)
	    draw_eval_expr_into_integer(second, *second_reg);
      else
	    fprintf(vvp_out, "    %%ix/load %d, 0, 0;\n", *second_reg);
      if (second)
	    fprintf(vvp_out, "    %%stream/range/mark %d, 4;\n", *second_reg);
      return 1;
}

static int validate_dynamic_stream_lval_(ivl_statement_t net,
					  ivl_lval_t lval)
{
      ivl_type_t type = ivl_lval_net_type(lval);
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_variable_type_t base = ivl_type_base(type);

      int prop_idx = ivl_lval_property_idx(lval);
      if ((!sig && !ivl_lval_nest(lval))
	  || (prop_idx < 0 && ivl_lval_nest(lval))
	  || ivl_lval_idx(lval) || ivl_lval_part_off(lval)) {
	    fprintf(stderr, "%s:%u: sorry: this selected or nested dynamically "
		    "sized streaming target is not yet supported (IEEE "
		    "1800-2017 11.4.14.4).\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }

      if (base == IVL_VT_QUEUE && ivl_type_queue_assoc_compat(type)) {
	    fprintf(stderr, "%s:%u: error: an associative array is not a "
		    "legal dynamically sized streaming target (IEEE 1800-2017 "
		    "11.4.14.4).\n", ivl_stmt_file(net),
		    ivl_stmt_lineno(net));
	    return 1;
      }

      ivl_type_t elem = (base == IVL_VT_STRING) ? 0
	    : ivl_type_element(type);
      if (base != IVL_VT_STRING
	  && (!elem || (ivl_type_base(elem) != IVL_VT_BOOL
			 && ivl_type_base(elem) != IVL_VT_LOGIC))) {
	    fprintf(stderr, "%s:%u: error: streaming into a dynamic array or "
		    "queue requires an integral bit-stream element type (IEEE "
		    "1800-2017 11.4.14.1).\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }

      return 0;
}

/* Store one run-time-sized member of an IEEE 1800-2017 11.4.14.4
 * streaming target. The member's complete bit stream is on the vec4 stack.
 * The caller has already rejected selections and nested/property targets, so
 * this helper performs one typed whole-variable store. */
static int store_dynamic_stream_lval_(ivl_lval_t lval)
{
      ivl_type_t type = ivl_lval_net_type(lval);
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_variable_type_t base = ivl_type_base(type);
      int prop_idx = ivl_lval_property_idx(lval);
      int is_property = prop_idx >= 0;

      if (is_property) {
	    ivl_type_t receiver_type = draw_lval_expr(lval);
	    if (!receiver_type || prop_idx >= ivl_type_properties(receiver_type)) {
		  fprintf(stderr, "sorry: cannot resolve dynamically sized "
			  "streaming target property %d.\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  return 1;
	    }
      } else {
	    assert(sig);
      }

      if (base == IVL_VT_STRING) {
	    fprintf(vvp_out, "    %%pushv/str;\n");
	    if (is_property) {
		  fprintf(vvp_out, "    %%store/prop/str %d;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    } else {
		  fprintf(vvp_out, "    %%store/str v%p_0;\n", sig);
	    }
	    return 0;
      }

      ivl_type_t elem = ivl_type_element(type);
      assert(elem);

      char elem_text[32];
      stream_elem_type_text(elem, elem_text, sizeof elem_text);
      if (base == IVL_VT_DARRAY) {
	    fprintf(vvp_out, "    %%stream/to/dar \"%s\";\n", elem_text);
	    if (is_property) {
		  fprintf(vvp_out, "    %%store/prop/obj %d, 0;\n", prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    } else {
		  fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
	    }
	    return 0;
      }

      assert(base == IVL_VT_QUEUE);
      uint64_t max_size = ivl_type_queue_max_size(type);
      int max_idx = allocate_word();
      fprintf(vvp_out, "    %%stream/to/queue \"%s:%" PRIu64 "\";\n",
	      elem_text, max_size);
      if (is_property) {
	    fprintf(vvp_out, "    %%store/prop/obj %d, 0;\n", prop_idx);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      } else {
	    fprintf(vvp_out, "    %%ix/load %d, %" PRIu32 ", %" PRIu32
		    "; exact queue maximum fallback\n", max_idx,
		    (uint32_t)max_size, (uint32_t)(max_size >> 32));
	    fprintf(vvp_out, "    %%store/qobj/v v%p_0, %d, %u;\n",
	      sig, max_idx, ivl_type_packed_width(elem));
      }
      clr_word(max_idx);
      return 0;
}

/* Store one explicitly ranged dynamic member.  The range expressions are
 * already in the two word registers and the selected field is on the vec4
 * stack.  Load the old container so elements outside the range survive, and
 * let the bounded runtime operation resize only as far as required. */
static int store_dynamic_stream_lval_with_(ivl_lval_t lval,
					    int first_reg, int second_reg,
					    int receiver_loaded)
{
      ivl_type_t type = ivl_lval_net_type(lval);
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_variable_type_t base = ivl_type_base(type);
      ivl_type_t elem = ivl_type_element(type);
      int prop_idx = ivl_lval_property_idx(lval);
      assert(elem);

      char elem_text[32];
      stream_elem_type_text(elem, elem_text, sizeof elem_text);
      const char*kind = stream_range_name_(ivl_lval_stream_range(lval));

      if (prop_idx >= 0) {
	    if (!receiver_loaded) {
		  ivl_type_t receiver_type = draw_lval_expr(lval);
		  if (!receiver_type
		      || prop_idx >= ivl_type_properties(receiver_type)) {
			fprintf(stderr, "sorry: cannot resolve nested streaming `with' "
				"container property %d.\n", prop_idx);
			return 1;
		  }
	    }
	    fprintf(vvp_out,
		    "    %%prop/obj %d, 0; load ranged stream property\n",
		    prop_idx);
      } else {
	    assert(sig);
	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
      }
      if (base == IVL_VT_DARRAY) {
	    fprintf(vvp_out, "    %%stream/to/dar/with \"%s:%s\", %d, %d;\n",
		    kind, elem_text, first_reg, second_reg);
	    if (prop_idx >= 0) {
		  fprintf(vvp_out,
			  "    %%store/prop/obj %d, 0; ranged stream property\n",
			  prop_idx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0; drop property receiver\n");
	    } else {
		  fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
	    }
	    return 0;
      }

      assert(base == IVL_VT_QUEUE);
      uint64_t max_size = ivl_type_queue_max_size(type);
      fprintf(vvp_out,
	      "    %%stream/to/queue/with \"%s:%s:%" PRIu64
	      "\", %d, %d;\n",
	      kind, elem_text, max_size, first_reg, second_reg);
      if (prop_idx >= 0) {
	    fprintf(vvp_out,
		    "    %%store/prop/obj %d, 0; ranged queue property\n",
		    prop_idx);
	    fprintf(vvp_out, "    %%pop/obj 1, 0; drop property receiver\n");
      } else {
	    int max_idx = allocate_word();
	    fprintf(vvp_out, "    %%ix/load %d, %" PRIu32 ", %" PRIu32
		    "; exact queue maximum fallback\n", max_idx,
		    (uint32_t)max_size, (uint32_t)(max_size >> 32));
	    fprintf(vvp_out, "    %%store/qobj/v v%p_0, %d, %u;\n",
		    sig, max_idx, ivl_type_packed_width(elem));
	    clr_word(max_idx);
      }
      return 0;
}

/* Return -1 when NET is not the dynamically-sized streaming-target form.
 * Otherwise lower the complete assignment and return its target error count.
 *
 * L-values are exported least-significant/source-rightmost first. Every fixed
 * member retains its declared width. The source-leftmost dynamically sized
 * member (the greatest dynamic l-value index) receives the run-time remainder
 * after all fixed widths are reserved; every later dynamic member receives an
 * empty value. This is the greedy rule in IEEE 1800-2017 11.4.14.4. */
static int show_stmt_assign_dynamic_stream_(ivl_statement_t net)
{
      ivl_expr_t rval = ivl_stmt_rval(net);
      if (ivl_stmt_opcode(net) != 0 || !rval
	  || ivl_expr_type(rval) != IVL_EX_SFUNC)
	    return -1;

      const char*name = ivl_expr_name(rval);
      if (!name || strncmp(name, "$ivl_stream$unpack$", 19) != 0)
	    return -1;

      unsigned lvals = ivl_stmt_lvals(net);
      unsigned greedy = 0;
      unsigned dynamic_count = 0;
      uint64_t fixed_width = 0;
      int have_range = 0;

      for (unsigned idx = 0 ; idx < lvals ; idx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, idx);
	    if (ivl_lval_stream_range(lval) != IVL_STREAM_RANGE_NONE)
		  have_range = 1;
	    if (stream_lval_is_dynamic_(lval)) {
		  greedy = idx;
		  dynamic_count += 1;
		  continue;
	    }

	    if (ivl_lval_stream_range(lval) != IVL_STREAM_RANGE_NONE) {
		  ivl_type_t fixed_type = ivl_lval_net_type(lval);
		  ivl_type_t elem = fixed_type ? ivl_type_element(fixed_type) : 0;
		  int prop_idx = ivl_lval_property_idx(lval);
		  int direct = ivl_lval_sig(lval) && !ivl_lval_nest(lval)
			&& prop_idx < 0
			&& ivl_signal_dimensions(ivl_lval_sig(lval)) == 1;
		  int property = prop_idx >= 0;
		  if ((!direct && !property)
		      || !elem || (ivl_type_base(elem) != IVL_VT_BOOL
				    && ivl_type_base(elem) != IVL_VT_LOGIC)) {
			fprintf(stderr, "%s:%u: sorry: this selected or nonintegral "
				"fixed-array streaming `with' target is not yet "
				"supported.\n", ivl_stmt_file(net),
				ivl_stmt_lineno(net));
			return 1;
		  }
		  continue;
	    }

	    if (!ivl_lval_sig(lval) || ivl_lval_nest(lval)
		|| ivl_lval_property_idx(lval) >= 0) {
		  fprintf(stderr, "%s:%u: sorry: this nested fixed member of a "
			  "dynamically sized streaming target is not yet "
			  "supported (IEEE 1800-2017 11.4.14.4).\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }
	    ivl_type_t type = ivl_lval_net_type(lval);
	    if (!type || (ivl_type_base(type) != IVL_VT_BOOL
			 && ivl_type_base(type) != IVL_VT_LOGIC)) {
		  fprintf(stderr, "%s:%u: error: this fixed member of a "
			  "streaming target is not a bit-stream type (IEEE "
			  "1800-2017 11.4.14.1).\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }
	    fixed_width += ivl_lval_width(lval);
      }

      if (dynamic_count == 0 && !have_range)
	    return -1;

      if (fixed_width > UINT_MAX) {
	    fprintf(stderr, "%s:%u: error: fixed members of this streaming "
		    "target exceed the VVP run-time width limit.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }

      /* Validate every dynamic destination before evaluating the source. A
	 * rejected target must not expose partial stores or source side effects. */
      for (unsigned idx = 0 ; idx < lvals ; idx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, idx);
	    if (!stream_lval_is_dynamic_(lval))
		  continue;
	    int validation_errors = validate_dynamic_stream_lval_(net, lval);
	    if (validation_errors)
		  return validation_errors;
      }

	/* An unconstrained variable-size member greedily consumes the remaining
	 * stream.  A later explicit with-range therefore has no well-defined
	 * source field; 11.4.14.4 requires all constrained variable-size fields
	 * to precede it (Slang diagnoses the same ordering). */
      int saw_unbounded = 0;
      for (unsigned pos = lvals ; pos > 0 ; pos -= 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, pos - 1);
	    if (stream_lval_is_dynamic_(lval)
		&& ivl_lval_stream_range(lval) == IVL_STREAM_RANGE_NONE) {
		  saw_unbounded = 1;
	    } else if (saw_unbounded
		       && ivl_lval_stream_range(lval) != IVL_STREAM_RANGE_NONE) {
		  fprintf(stderr, "%s:%u: error: a streaming `with' target may "
			  "not follow an unconstrained dynamically sized target "
			  "(IEEE 1800-2023 11.4.14.4).\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }
      }

      int errors = draw_stream_pack_pieces(rval, 0);
      if (errors < 0) {
	    fprintf(stderr, "%s:%u: internal error: malformed dynamic "
		    "streaming-target carrier.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }

      if (have_range) {
	    /* IVL exports concatenation members rightmost first.  Walk in reverse
	       source order so preceding fields are committed before a later
	       range expression is evaluated, exactly as 11.4.14.4 requires. */
	    int greedy_seen = 0;
	    for (unsigned pos = lvals ; pos > 0 ; pos -= 1) {
		  ivl_lval_t lval = ivl_stmt_lval(net, pos - 1);
		  ivl_stream_range_t kind = ivl_lval_stream_range(lval);
		  if (kind != IVL_STREAM_RANGE_NONE) {
			/* Evaluate a class / aggregate receiver once before its range
			   expressions. Keep that handle on the object stack until the
			   selected field has been stored, matching source evaluation
			   order even for nested or indexed receivers. */
			int prop_idx = ivl_lval_property_idx(lval);
			ivl_type_t receiver_type = 0;
			if (prop_idx >= 0) {
			      receiver_type = draw_lval_expr(lval);
			      if (!receiver_type
				  || prop_idx >= ivl_type_properties(receiver_type)) {
				    fprintf(stderr, "%s:%u: sorry: cannot resolve "
					    "streaming target property %d.\n",
					    ivl_stmt_file(net), ivl_stmt_lineno(net),
					    prop_idx);
				    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
				    return errors + 1;
			      }
			}
			int first_reg = 0, second_reg = 0;
			if (!eval_stream_range_(lval, &first_reg, &second_reg)) {
			      fprintf(stderr, "%s:%u: internal error: streaming "
				      "range metadata has no first expression.\n",
				      ivl_stmt_file(net), ivl_stmt_lineno(net));
			      return errors + 1;
			}
			ivl_type_t elem = ivl_type_element(ivl_lval_net_type(lval));
			char elem_text[32];
			stream_elem_type_text(elem, elem_text, sizeof elem_text);
			uint64_t fixed_after = 0;
			for (unsigned tail = 0 ; tail + 1 < pos ; tail += 1) {
			      ivl_lval_t later = ivl_stmt_lval(net, tail);
			      if (!stream_lval_is_dynamic_(later)
				  && ivl_lval_stream_range(later)
					== IVL_STREAM_RANGE_NONE)
				    fixed_after += ivl_lval_width(later);
			}
			fprintf(vvp_out,
				"    %%stream/take/left/with \"%s:%s:%llu\", %d, %d;\n",
				stream_range_name_(kind), elem_text,
				(unsigned long long)(greedy_seen ? fixed_after : 0),
				first_reg, second_reg);
			unsigned lab_null = 0, lab_out = 0;
			if (prop_idx >= 0) {
			      lab_null = local_count++;
			      lab_out = local_count++;
			      fprintf(vvp_out, "    %%test_nul/obj;\n");
			      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
				      thread_count, lab_null);
			}
			if (stream_lval_is_dynamic_(lval)) {
			      errors += store_dynamic_stream_lval_with_(
				    lval, first_reg, second_reg, prop_idx >= 0);
			} else {
			      if (prop_idx >= 0) {
				    fprintf(vvp_out,
						"    %%stream/store/prop/fixed/%s %d, %d, %d;\n",
						stream_range_name_(kind), prop_idx,
						first_reg, second_reg);
				    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			      } else {
				    ivl_signal_t fsig = ivl_lval_sig(lval);
				    note_array_signal_use(fsig);
				    fprintf(vvp_out,
					  "    %%stream/store/fixed/%s v%p, %d, %d;\n",
					  stream_range_name_(kind), fsig,
					  first_reg, second_reg);
				      }
			}
			if (prop_idx >= 0) {
			      fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				      thread_count, lab_out);
			      fprintf(vvp_out, "T_%u.%u;\n",
				      thread_count, lab_null);
			      fprintf(vvp_out,
				      "    %%pop/vec4 1; null ranged property field\n");
			      fprintf(vvp_out,
				      "    %%pop/obj 1, 0; null ranged property receiver\n");
			      fprintf(vvp_out, "T_%u.%u;\n",
				      thread_count, lab_out);
			}
			clr_word(second_reg);
			clr_word(first_reg);
		  } else if (stream_lval_is_dynamic_(lval)) {
			if (greedy_seen) {
			      fprintf(vvp_out, "    %%stream/take/left 0;\n");
			} else {
			      uint64_t fixed_after = 0;
			      for (unsigned tail = 0 ; tail + 1 < pos ; tail += 1) {
				    ivl_lval_t later = ivl_stmt_lval(net, tail);
				    if (!stream_lval_is_dynamic_(later)
					&& ivl_lval_stream_range(later)
					      == IVL_STREAM_RANGE_NONE)
					  fixed_after += ivl_lval_width(later);
			      }
			      fprintf(vvp_out,
				      "    %%stream/take/left/rem %llu;\n",
				      (unsigned long long)fixed_after);
			      greedy_seen = 1;
			}
			errors += store_dynamic_stream_lval_(lval);
		  } else {
			fprintf(vvp_out, "    %%stream/take/left %u;\n",
				ivl_lval_width(lval));
			store_vec4_to_one_lval(lval);
		  }
	    }
	    /* Every take leaves the unconsumed suffix below its selected piece. */
	    fprintf(vvp_out, "    %%pop/vec4 1;\n");
	    return errors;
      }

      fprintf(vvp_out, "    %%stream/pad/min %u;\n", (unsigned)fixed_width);

      for (unsigned idx = 0 ; idx < lvals ; idx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, idx);
	    if (stream_lval_is_dynamic_(lval)) {
		  if (idx < greedy) {
			fprintf(vvp_out, "    %%pushi/vec4 0, 0, 0;\n");
		  } else {
			uint64_t fixed_left = 0;
			for (unsigned tail = idx + 1 ; tail < lvals ; tail += 1)
			      if (!stream_lval_is_dynamic_(
					ivl_stmt_lval(net, tail)))
				    fixed_left += ivl_lval_width(
					  ivl_stmt_lval(net, tail));
			if (fixed_left > 0)
			      fprintf(vvp_out, "    %%stream/split/rem %u;\n",
				      (unsigned)fixed_left);
		  }
		  errors += store_dynamic_stream_lval_(lval);
		  continue;
	    }

	    if (idx + 1 < lvals)
		  fprintf(vvp_out, "    %%split/vec4 %u;\n",
			  ivl_lval_width(lval));
	    store_vec4_to_one_lval(lval);
      }

      return errors;
}

int show_stmt_assign(ivl_statement_t net)
{
      ivl_lval_t lval;
      ivl_signal_t sig;

      show_stmt_file_line(net, "Blocking assignment.");

      lval = ivl_stmt_lval(net, 0);

      sig = ivl_lval_sig(lval);

      {
	    int stream_errors = show_stmt_assign_dynamic_stream_(net);
	    if (stream_errors >= 0)
		  return stream_errors;
      }

      {
	    int concat_object_errors = show_stmt_assign_concat_cobject_(net);
	    if (concat_object_errors >= 0)
		  return concat_object_errors;
      }

      {
            int concat_array_errors = show_stmt_assign_concat_darray_(net);
            if (concat_array_errors >= 0)
                  return concat_array_errors;
      }

	/* Assignment of a function returning an unpacked array into an
	   unpacked-array (or array-slice) l-value. The function is called
	   like a void function and the result words are copied out of its
	   return-array signal; see draw_ufunc_uarray. */
      {
	    ivl_expr_t rv = ivl_stmt_rval(net);
	    if (sig && ivl_signal_dimensions(sig) > 0
		&& rv && ivl_expr_type(rv) == IVL_EX_UFUNC
		&& ivl_stmt_opcode(net) == 0) {
		  ivl_scope_t def = ivl_expr_def(rv);
		  ivl_signal_t retsig = def ? ivl_scope_port(def, 0) : 0;
		  if (retsig && ivl_signal_dimensions(retsig) > 0) {
			draw_ufunc_uarray(rv, sig, array_pattern_base_(lval));
			return 0;
		  }
	    }
      }

      /* A whole fixed unpacked array receiving a container value. */
      {
	    ivl_expr_t rv = ivl_stmt_rval(net);
	    if (rv && ivl_stmt_opcode(net) == 0
		&& lval_is_whole_uarray_(lval, sig)
		&& rval_is_whole_container_(rv))
		  return show_stmt_assign_uarray_from_container(net, sig);
      }

      if (sig && (ivl_signal_data_type(sig) == IVL_VT_REAL)) {
	    return show_stmt_assign_sig_real(net);
      }

      if (sig && (ivl_signal_data_type(sig) == IVL_VT_STRING)) {
	    return show_stmt_assign_sig_string(net);
      }

      if (sig && (ivl_signal_data_type(sig) == IVL_VT_DARRAY)) {
	    return show_stmt_assign_sig_darray(net);
      }

      if (sig && (ivl_signal_data_type(sig) == IVL_VT_QUEUE)) {
	    return show_stmt_assign_sig_queue(net);
      }

      if ((sig && ((ivl_signal_data_type(sig) == IVL_VT_CLASS)
                || (ivl_signal_data_type(sig) == IVL_VT_NO_TYPE))) ||
          ivl_lval_nest(lval)) {
	    return show_stmt_assign_sig_cobject(net);
      }

      return show_stmt_assign_vector(net);
}
