/*
 * Copyright (c) 2003-2024 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/*
 * This file includes functions for evaluating REAL expressions.
 */
# include  "vvp_priv.h"
# include  <string.h>
# include  <stdlib.h>
# include  <math.h>
# include  <assert.h>
# include  <stdbool.h>

static unsigned long word_alloc_mask = 0x0f;

int allocate_word(void)
{
      int res = 4;

      while (res < WORD_COUNT && (1U << res) & word_alloc_mask)
	    res += 1;

      if (res >= WORD_COUNT) {
	    fprintf(stderr, "vvp.tgt error: Thread words (%d) exhausted "
	                    "during VVP code generation.\n", WORD_COUNT);
	    exit(1);
      }
      word_alloc_mask |= 1U << res;
      return res;
}

void clr_word(int res)
{
      assert(res < WORD_COUNT);
      word_alloc_mask &= ~ (1U << res);
}

static void draw_binary_real(ivl_expr_t expr)
{
      switch (ivl_expr_opcode(expr)) {
	  case 'E':
	  case 'N':
	  case 'w':
	  case 'W':
	  case 'l':
	  case 'r':
	  case 'R':
	  case '&':
	  case '|':
	  case '^':
	  case 'A':
	  case 'O':
	  case 'X':
	    /* These should be caught in draw_eval_real(). */
	    assert(0);
      }

      draw_eval_real(ivl_expr_oper1(expr));
      draw_eval_real(ivl_expr_oper2(expr));

      switch (ivl_expr_opcode(expr)) {

	  case '+':
	    fprintf(vvp_out, "    %%add/wr;\n");
	    break;

	  case '-':
	    fprintf(vvp_out, "    %%sub/wr;\n");
	    break;

	  case '*':
	    fprintf(vvp_out, "    %%mul/wr;\n");
	    break;

	  case '/':
	    fprintf(vvp_out, "    %%div/wr;\n");
	    break;

	  case '%':
	    fprintf(vvp_out, "    %%mod/wr;\n");
	    break;
	  case 'p':
	    fprintf(vvp_out, "    %%pow/wr;\n");
	    break;

	  case 'm':
	    fprintf(vvp_out, "    %%min/wr;\n");
	    break;

	  case 'M':
	    fprintf(vvp_out, "    %%max/wr;\n");
	    break;

	  default:
	    fprintf(stderr, "vvp.tgt error: draw_binary_real(%c)\n",
		    ivl_expr_opcode(expr));
	    assert(0);
      }
}

static void draw_number_real(ivl_expr_t expr)
{
      unsigned int idx;
      const char*bits = ivl_expr_bits(expr);
      unsigned wid = ivl_expr_width(expr);
      unsigned long mant = 0;
      int vexp = 0x1000;

	/* If this is a negative number, then arrange for the 2's
	   complement to be calculated as we scan through the
	   value. Real values are sign-magnitude, and this negation
	   gets us a magnitude. */

      int negate = 0;
      int carry = 0;
      if (ivl_expr_signed(expr) && (bits[wid-1] == '1')) {
	    negate = 1;
	    carry = 1;
      }

      for (idx = 0 ;  idx < wid && idx < IMM_WID ;  idx += 1) {
	    int cur_bit = bits[idx] == '1'? 1 : 0;

	    if (negate) {
		  cur_bit ^= 1;
		  cur_bit += carry;
		  carry = (cur_bit >> 1) & 1;
		  cur_bit &= 1;
	    }

	    if (cur_bit) mant |= 1 << idx;
      }

      for ( ; idx < wid ; idx += 1) {
	    if (ivl_expr_signed(expr) && (bits[idx] == bits[IMM_WID-1]))
		  continue;

	    if (bits[idx] == '0')
		  continue;

	    fprintf(stderr, "vvp.tgt error: mantissa doesn't fit!\n");
	    assert(0);
      }

	/* If required, add in a sign bit. */
      if (negate)
	    vexp |= 0x4000;

      fprintf(vvp_out, "    %%pushi/real %lu, %d; load(num)= %c%lu (wid=%u)\n",
	      mant, vexp, (vexp&0x4000)? '-' : '+', mant, wid);
}

static void draw_property_real(ivl_expr_t expr)
{
      ivl_signal_t sig = ivl_expr_signal(expr);
      unsigned pidx = ivl_expr_property_idx(expr);
      ivl_expr_t base_expr = ivl_expr_oper2(expr);
      unsigned lab_null = local_count++;
      unsigned lab_out = local_count++;
      ivl_expr_t idx_expr = ivl_expr_oper1(expr);
	/* Indexed queue or plain-darray property: element access
	 * within the container value (%load/qo/r serves both). */
      int queue_indexed = property_is_indexed_queue_expr_(expr)
	    || property_is_indexed_darray_expr_(expr);
      int assoc_indexed = property_is_assoc_indexed_expr_(expr);
      ivl_type_t declared_prop_type = property_expr_type_(expr);
      int fixed_idx_word = 0;
      int fixed_idx_x_flag = -1;
      int fixed_idx_in_range_flag = -1;

      if (idx_expr && !queue_indexed && !assoc_indexed
	  && property_selects_fixed_uarray_slot_(expr)) {
	    fixed_idx_word = allocate_word();
	    draw_fixed_uarray_slot_index_(idx_expr, declared_prop_type,
					 fixed_idx_word, &fixed_idx_x_flag,
					 &fixed_idx_in_range_flag);
      }

      if (sig) {
	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
      } else if (base_expr && ivl_expr_type(base_expr) == IVL_EX_NULL) {
	      /* Compile-progress fallback: null receiver property access
	         yields numeric zero. */
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, 1;\n");
	    fprintf(vvp_out, "    %%cvt/rv;\n");
	    if (fixed_idx_word) clr_word(fixed_idx_word);
	    if (fixed_idx_x_flag >= 0) clr_flag(fixed_idx_x_flag);
	    if (fixed_idx_in_range_flag >= 0)
		  clr_flag(fixed_idx_in_range_flag);
	    return;
      } else {
	    draw_eval_object(base_expr);
      }
      fprintf(vvp_out, "    %%test_nul/obj;\n");
      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
      if (fixed_idx_x_flag >= 0) {
	    fprintf(vvp_out,
		    "    %%jmp/1xz T_%u.%u, %d; invalid fixed property slot\n",
		    thread_count, lab_null, fixed_idx_x_flag);
	    fprintf(vvp_out,
		    "    %%jmp/0xz T_%u.%u, %d; fixed property slot out of range\n",
		    thread_count, lab_null, fixed_idx_in_range_flag);
      }
      if (assoc_indexed) {
            const char*key_kind;
	    fprintf(vvp_out, "    %%prop/obj %u, 0; eval_assoc_property\n", pidx);
            key_kind = draw_eval_assoc_key_(idx_expr, 0);
	    fprintf(vvp_out, "    %%aa/load/r/%s;\n", key_kind);
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	      } else if (queue_indexed) {
		    if (!emit_property_queue_last_index_(expr, pidx, 3))
			  draw_eval_expr_into_integer(idx_expr, 3);
		    fprintf(vvp_out, "    %%prop/obj %u, 0; eval_queue_property\n", pidx);
		    fprintf(vvp_out, "    %%load/qo/r;\n");
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	      } else if (idx_expr) {
		    /* Element of a real-array property (`obj.arr[i]`): the
		       index selects a word of the property's array storage. */
		  if (!fixed_idx_word)
			draw_eval_expr_into_integer(idx_expr, 3);
		  fprintf(vvp_out, "    %%prop/r/i %u, %d;\n", pidx,
			  fixed_idx_word ? fixed_idx_word : 3);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	      } else {
	    fprintf(vvp_out, "    %%prop/r %u;\n", pidx);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      }
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      fprintf(vvp_out, "    %%pushi/vec4 0, 0, 1;\n");
      fprintf(vvp_out, "    %%cvt/rv;\n");
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
      if (fixed_idx_word) clr_word(fixed_idx_word);
      if (fixed_idx_x_flag >= 0) clr_flag(fixed_idx_x_flag);
      if (fixed_idx_in_range_flag >= 0)
	    clr_flag(fixed_idx_in_range_flag);
}

static void draw_realnum_real(ivl_expr_t expr)
{
      double value = ivl_expr_dvalue(expr);

      double fract;
      int expo, vexp;
      unsigned long mant;
      int sign = 0;

	/* Handle the special case that the value is +-inf. */
      if (isinf(value)) {
	    if (value > 0)
		  fprintf(vvp_out, "    %%pushi/real 0, %d; load=+inf\n",
			  0x3fff);
	    else
		  fprintf(vvp_out, "    %%pushi/real 0, %d; load=-inf\n",
			  0x7fff);
	    return;
      }
	/* Handle the special case that the value is NaN. */
      if (value != value) {
	    fprintf(vvp_out, "    %%pushi/real 1, %d; load=NaN\n",
	            0x3fff);
	    return;
      }

      if (value < 0) {
	    sign = 0x4000;
	    value *= -1;
      }

      fract = frexp(value, &expo);
      fract = ldexp(fract, 31);
      mant = fract;
      expo -= 31;

      vexp = expo + 0x1000;
      assert(vexp >= 0);
      assert(vexp < 0x2000);
      vexp += sign;

      fprintf(vvp_out, "    %%pushi/real %lu, %d; load=%#g\n",
	      mant, vexp, ivl_expr_dvalue(expr));

	/* Capture the residual bits, if there are any. Note that an
	   IEEE754 mantissa has 52 bits, 31 of which were accounted
	   for already. */
      fract -= floor(fract);
      fract = ldexp(fract, 22);
      mant = fract;
      expo -= 22;

      vexp = expo + 0x1000;
      assert(vexp >= 0);
      assert(vexp < 0x2000);
      vexp += sign;

      if (mant != 0) {
	    fprintf(vvp_out, "    %%pushi/real %lu, %d; load=%#g\n",
		    mant, vexp, ivl_expr_dvalue(expr));
	    fprintf(vvp_out, "    %%add/wr;\n");
      }
}

/*
 * The real value of a logic expression is the integer value of the
 * expression converted to real.
 */
static void draw_real_logic_expr(ivl_expr_t expr)
{
      draw_eval_vec4(expr);
      const char*sign_flag = ivl_expr_signed(expr)? "/s" : "";
      fprintf(vvp_out, "    %%cvt/rv%s;\n", sign_flag);
}

static void draw_select_real(ivl_expr_t expr)
{
	/* The sube references the expression to be selected from. */
      ivl_expr_t sube = ivl_expr_oper1(expr);
	/* This is the select expression */
      ivl_expr_t shift= ivl_expr_oper2(expr);

	/* A container that is not a bare signal: the value to select
	   from has to be evaluated onto the object stack first. This
	   covers a queue, and also the INNER level of a nested
	   container -- `q[i][j]' for a real `q[][]', where `q[i]' is a
	   select yielding a darray. Only the queue spelling used to be
	   recognised, so a nested real read fell through to the
	   bare-signal path below and aborted ivl on its
	   ivl_expr_signal() assert. vvp_darray backs both, so one
	   %load/qo/r serves both. */
      {
	    ivl_type_t sube_type = receiver_container_type_(sube);
	    int sube_is_container =
		  expr_is_queue_container_(sube)
		  || (sube_type && ivl_type_base(sube_type) == IVL_VT_DARRAY)
		  || (sube && ivl_expr_value(sube) == IVL_VT_DARRAY);

	    if (sube_is_container && ivl_expr_type(sube) != IVL_EX_SIGNAL) {
		  if (sube_type
		      && ivl_type_base(sube_type) == IVL_VT_QUEUE
		      && ivl_type_queue_assoc_compat(sube_type)) {
			const char*key_kind;
			draw_eval_object(sube);
			key_kind = draw_eval_assoc_key_(shift, 0);
			fprintf(vvp_out, "    %%aa/load/r/%s;\n", key_kind);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			return;
		  }
		  draw_eval_object(sube);
		  draw_eval_expr_into_integer(shift, 3);
		  fprintf(vvp_out, "    %%load/qo/r;\n");
		  return;
	    }
      }

	/* Assume the sub-expression is a signal */
      ivl_signal_t sig = ivl_expr_signal(sube);
      ivl_type_t net_type = ivl_signal_net_type(sig);
      assert(ivl_signal_data_type(sig) == IVL_VT_DARRAY || ivl_signal_data_type(sig) == IVL_VT_QUEUE);

	/* `maps[outer][key]' carries the fixed word selection on SUBE. Load
	 * that map object first; the scalar associative fast paths below address
	 * vSIG_0 and are valid only when the signal itself has no fixed prefix. */
      if (net_type && ivl_type_base(net_type) == IVL_VT_QUEUE
	  && ivl_type_queue_assoc_compat(net_type)
	  && ivl_signal_dimensions(sig) > 0
	  && ivl_expr_type(sube) == IVL_EX_SIGNAL
	  && ivl_expr_oper1(sube)) {
	    const char*key_kind;
	    draw_eval_object(sube);
	    key_kind = draw_eval_assoc_key_(shift, 0);
	    fprintf(vvp_out, "    %%aa/load/r/%s;\n", key_kind);
	    fprintf(vvp_out, "    %%pop/obj 1, 0; fixed outer map receiver\n");
	    return;
      }

      if (net_type && ivl_type_queue_assoc_compat(net_type)
          && expr_is_object_assoc_key_(shift)) {
            draw_eval_object(shift);
            fprintf(vvp_out, "    %%aa/load/sig/r/obj v%p_0;\n", sig);
            return;
      }

      /* M4-av: real-VALUED associative array with a string or integral
         key. Previously only object keys were handled; string and integer
         keys fell through to the POSITIONAL %load/dar/r below and read
         0.0 (a silent value loss on a module-static `real r[int]` /
         `real r[string]`; class-member assoc read was unaffected). Push
         the key, push the assoc object, load, then pop the object. */
      if (net_type && ivl_type_queue_assoc_compat(net_type)
          && expr_is_string_assoc_key_(shift)) {
            draw_eval_string(shift);
            fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
            fprintf(vvp_out, "    %%aa/load/r/str;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return;
      }
      if (net_type && ivl_type_queue_assoc_compat(net_type)) {
            draw_eval_vec4(shift);
            fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
            fprintf(vvp_out, "    %%aa/load/r/v;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return;
      }

      draw_eval_expr_into_integer(shift, 3);
      fprintf(vvp_out, "    %%load/dar/r v%p_0;\n", sig);
}

static void real_ex_pop(ivl_expr_t expr)
{
      static int warned_non_signal_pop = 0;
      const char*fb;
      ivl_expr_t arg;

      if (strcmp(ivl_expr_name(expr), "$ivl_queue_method$pop_back")==0)
            fb = "b";
      else
            fb = "f";

      arg = ivl_expr_parm(expr, 0);
	    if (ivl_expr_type(arg) != IVL_EX_SIGNAL
		|| expr_selects_fixed_container_slot_(arg)) {
	    if (expr_is_queue_container_(arg)) {
		  draw_eval_object(arg);
		  fprintf(vvp_out, "    %%qpop/o/%s/real;\n", fb);
		  return;
	    }
	      /* The real-valued twin of the vec4 pop fallback: a pop with
		 nothing to pop from used to warn and hand back 0.0. */
	    if (!warned_non_signal_pop) {
		  fprintf(stderr, "error: %s requires a signal operand, got "
			  "expression kind %d (further occurrences are not "
			  "reported).\n",
			  ivl_expr_name(expr), ivl_expr_type(arg));
		  warned_non_signal_pop = 1;
	    }
	    vvp_errors += 1;
	    fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
	    return;
      }

      fprintf(vvp_out, "    %%qpop/%s/real v%p_0;\n", fb, ivl_expr_signal(arg));
}

static void draw_sfunc_real(ivl_expr_t expr)
{
      if (strncmp(ivl_expr_name(expr), "$ivl_vif_func$", 14) == 0) {
            vvp_errors += draw_vif_function_call(expr);
            return;
      }

      /* R11: $ivl_clocking_sample(r) on a REAL operand -- the Preponed
       * value of the raw signal (IEEE 1800-2017 16.5.1). The vec4 form of
       * this lives in eval_vec4.c; a real operand needs the real-valued
       * load, because there is no bit width to push. */
      if (strcmp(ivl_expr_name(expr), "$ivl_clocking_sample") == 0) {
	    ivl_expr_t arg = (ivl_expr_parms(expr) > 0)
			      ? ivl_expr_parm(expr, 0) : 0;
	    if (arg && ivl_expr_type(arg) == IVL_EX_SIGNAL
		&& ivl_expr_signal(arg)) {
		  fprintf(vvp_out, "    %%load/preponed/real v%p_0;\n",
			  ivl_expr_signal(arg));
		  return;
	    }
	    /* Unexpected shape: fall back to the plain (alias) read. */
	    if (arg) {
		  draw_eval_real(arg);
		  return;
	    }
	    fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
	    return;
      }

      /* $ivl_class_method$covgrp_get_inst_coverage(cg_obj)
       * Pop cg object from obj stack, compute (hit_bins/total_bins)*100.0 */
      if (ivl_expr_value(expr) == IVL_VT_REAL &&
          strcmp(ivl_expr_name(expr),
                 "$ivl_class_method$covgrp_get_inst_coverage") == 0) {
	    ivl_expr_t obj_arg = (ivl_expr_parms(expr) > 0)
				  ? ivl_expr_parm(expr, 0) : 0;
	    if (obj_arg) draw_eval_object(obj_arg);
	    fprintf(vvp_out, "    %%covgrp/get_inst_coverage;\n");
	    return;
      }

      /* M11: covergroup TYPE coverage (merge across instances). */
      if (ivl_expr_value(expr) == IVL_VT_REAL &&
          strcmp(ivl_expr_name(expr),
                 "$ivl_class_method$covgrp_get_coverage") == 0) {
	    ivl_expr_t obj_arg = (ivl_expr_parms(expr) > 0)
				  ? ivl_expr_parm(expr, 0) : 0;
	    if (obj_arg) draw_eval_object(obj_arg);
	    fprintf(vvp_out, "    %%covgrp/get_coverage;\n");
	    return;
      }

      /* Named coverpoint coverage uses the enclosing covergroup object
       * and a compile-time item index. The method name distinguishes
       * cumulative type coverage from this receiver's instance score. */
      {
	    const char*name = ivl_expr_name(expr);
	    const char*type_prefix =
		  "$ivl_class_method$covgrp_item_get_coverage|";
	    const char*inst_prefix =
		  "$ivl_class_method$covgrp_item_get_inst_coverage|";
	    const char*index = 0;
	    const char*opcode = 0;
	    if (ivl_expr_value(expr) == IVL_VT_REAL && name) {
		  if (strncmp(name, type_prefix, strlen(type_prefix)) == 0) {
			index = name + strlen(type_prefix);
			opcode = "%covgrp/item/get_coverage";
		  } else if (strncmp(name, inst_prefix,
				  strlen(inst_prefix)) == 0) {
			index = name + strlen(inst_prefix);
			opcode = "%covgrp/item/get_inst_coverage";
		  }
	    }
	    if (opcode) {
		  ivl_expr_t obj_arg = (ivl_expr_parms(expr) > 0)
				  ? ivl_expr_parm(expr, 0) : 0;
		  if (obj_arg) draw_eval_object(obj_arg);
		  fprintf(vvp_out, "    %s %s;\n", opcode, index);
		  return;
	    }
      }

      /* M11: $get_coverage — overall coverage over all covergroup
       * types (19.9). */
      if (ivl_expr_value(expr) == IVL_VT_REAL &&
          strcmp(ivl_expr_name(expr), "$get_coverage") == 0) {
	    fprintf(vvp_out, "    %%covgrp/get_all;\n");
	    return;
      }

      switch (ivl_expr_value(expr)) {

	  case IVL_VT_REAL:
	    if (ivl_expr_parms(expr) == 0) {
		  fprintf(vvp_out, "    %%vpi_func/r %u %u \"%s\" {0 0 0 0};\n",
			  ivl_file_table_index(ivl_expr_file(expr)),
			  ivl_expr_lineno(expr), ivl_expr_name(expr));

	    } else {
		  draw_vpi_rfunc_call(expr);
	    }
	    break;

	  case IVL_VT_VECTOR:
	      /* If the value of the sfunc is a vector, then evaluate
		 it as a vector, then convert the result to a real
		 (via an index register) for the result. */
	    draw_real_logic_expr(expr);
	    break;

	  default:
	    assert(0);
      }

}

static void draw_signal_real_real(ivl_expr_t expr)
{
      ivl_signal_t sig = ivl_expr_signal(expr);

	/* Special Case: If the signal is the return value of the function,
	   then use a different opcode to get the value. */
      if (signal_is_return_value(sig) && ivl_signal_dimensions(sig) == 0) {
	    fprintf(vvp_out, "    %%retload/real 0; Load %s (draw_signal_real_real)\n",
		    ivl_signal_basename(sig));
	    return;
      }


      if (ivl_signal_dimensions(sig) == 0) {
	    fprintf(vvp_out, "    %%load/real v%p_0;\n", sig);
	    return;
      }

      ivl_expr_t word_ex = ivl_expr_oper1(expr);
      int word_ix = allocate_word();
      draw_eval_expr_into_integer(word_ex, word_ix);
      note_array_signal_use(sig);
      fprintf(vvp_out, "    %%load/ar v%p, %d;\n", sig, word_ix);
      clr_word(word_ix);
}

static void draw_signal_real(ivl_expr_t expr)
{
      ivl_signal_t sig = ivl_expr_signal(expr);
      switch (ivl_signal_data_type(sig)) {
	  case IVL_VT_LOGIC:
	    draw_real_logic_expr(expr);
	    return;
	  case IVL_VT_REAL:
	    draw_signal_real_real(expr);
	    return;
	  default:
	    fprintf(stderr, "vvp.tgt error: signal_data_type=%d\n",
		    ivl_signal_data_type(sig));
	    assert(0);
	    return;
      }
}

/* If we have nested ternary operators they are likely tail recursive.
 * This code is structured to allow this recursion without overflowing
 * the available thread words. */
static void draw_ternary_real(ivl_expr_t expr)
{
      ivl_expr_t cond = ivl_expr_oper1(expr);
      ivl_expr_t true_ex = ivl_expr_oper2(expr);
      ivl_expr_t false_ex = ivl_expr_oper3(expr);

      unsigned lab_true = local_count++;
      unsigned lab_out = local_count++;

      int cond_flag = allocate_flag();

	/* Evaluate the ternary condition. */
      draw_eval_vec4(cond);
      if (ivl_expr_width(cond) > 1 || ivl_expr_value(cond) == IVL_VT_STRING)
	    fprintf(vvp_out, "    %%or/r;\n");

      fprintf(vvp_out, "    %%flag_set/vec4 %d;\n", cond_flag);


	/* Evaluate the true expression second. */
      fprintf(vvp_out, "    %%jmp/1  T_%u.%u, %d;\n",
	      thread_count, lab_true, cond_flag);

	/* Evaluate the false expression. */
      draw_eval_real(false_ex);
      fprintf(vvp_out, "    %%jmp/0  T_%u.%u, %d; End of false expr.\n",
              thread_count, lab_out, cond_flag);

	/* If the conditional is undefined then blend the real words. */
      draw_eval_real(true_ex);
      fprintf(vvp_out, "    %%blend/wr;\n");
      fprintf(vvp_out, "    %%jmp  T_%u.%u; End of blend\n",
              thread_count, lab_out);

	/* Evaluate the true expression. */
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_true);
      draw_eval_real(true_ex);

	/* This is the out label. */
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_out);

      clr_flag(cond_flag);
}

static void change_real(ivl_expr_t e, bool pre, bool incr)
{
      ivl_signal_t sig = ivl_expr_signal(e);
      bool is_property = ivl_expr_type(e) == IVL_EX_PROPERTY;
      unsigned pidx = is_property ? ivl_expr_property_idx(e) : 0;
      ivl_expr_t prop_base = is_property ? ivl_expr_oper2(e) : 0;
      ivl_expr_t prop_word = is_property ? ivl_expr_oper1(e) : 0;
      ivl_type_t prop_type = is_property ? property_expr_type_(e) : 0;
      int word_ix = -1;
      int index_flag = -1;
      int range_flag = -1;
      unsigned lab_null = 0;
      unsigned lab_out = 0;
      unsigned lab_invalid = 0;
      unsigned lab_value = 0;
      unsigned lab_skip_store = 0;
      unsigned lab_after_store = 0;
      if (is_property
          && ((pidx == (unsigned)-1) || (!sig && !prop_base)
              || (prop_word && !property_selects_fixed_uarray_slot_(e)))) {
            fprintf(stderr, "%s:%u: vvp.tgt error: unsupported real "
                    "property ++/-- destination.\n",
                    ivl_expr_file(e), ivl_expr_lineno(e));
            vvp_errors += 1;
            draw_eval_real(e);
            return;
      }
      if (is_property) {
            lab_null = local_count++;
            lab_out = local_count++;
            if (prop_word) {
                  lab_invalid = local_count++;
                  lab_value = local_count++;
                  lab_skip_store = local_count++;
                  lab_after_store = local_count++;
            }
            if (sig)
                  fprintf(vvp_out, "    %%load/obj v%p_0; real property increment receiver\n", sig);
            else
                  draw_eval_object(prop_base);
            fprintf(vvp_out, "    %%test_nul/obj;\n");
            fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
            if (prop_word && property_selects_fixed_uarray_slot_(e)) {
                  word_ix = allocate_word();
                  draw_fixed_uarray_slot_index_(prop_word, prop_type, word_ix,
                                                &index_flag, &range_flag);
                  fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; invalid property slot\n",
                          thread_count, lab_invalid, index_flag);
                  fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; property slot out of range\n",
                          thread_count, lab_invalid, range_flag);
                  fprintf(vvp_out, "    %%prop/r/i %u, %d;\n", pidx, word_ix);
                  fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_value);
                  fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_invalid);
                  fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
                  fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_value);
            } else {
                  fprintf(vvp_out, "    %%prop/r %u;\n", pidx);
            }
      } else if (ivl_signal_dimensions(sig) > 0) {
            word_ix = allocate_word();
            index_flag = allocate_flag();
            draw_eval_expr_into_integer(ivl_expr_oper1(e), word_ix);
            fprintf(vvp_out, "    %%flag_mov %d, 4; preserve array index validity\n",
                    index_flag);
            note_array_signal_use(sig);
            fprintf(vvp_out, "    %%load/ar v%p, %d;\n", sig, word_ix);
      } else {
            fprintf(vvp_out, "    %%load/real v%p_0;\n", sig);
      }
      if (!pre) fprintf(vvp_out, "    %%dup/real;\n");
      fprintf(vvp_out, "    %%pushi/real 1, 0x1000;\n");
      fprintf(vvp_out, incr ? "    %%add/wr;\n" : "    %%sub/wr;\n");
      if ( pre) fprintf(vvp_out, "    %%dup/real;\n");
      if (word_ix >= 0) {
            if (is_property) {
                  fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; suppress invalid property store\n",
                          thread_count, lab_skip_store, index_flag);
                  fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; suppress out-of-range property store\n",
                          thread_count, lab_skip_store, range_flag);
                  fprintf(vvp_out, "    %%store/prop/r/i %u, %d;\n", pidx, word_ix);
                  fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_after_store);
                  fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_skip_store);
                  fprintf(vvp_out, "    %%pop/real 1; discard invalid property update\n");
                  fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_after_store);
            } else {
                  fprintf(vvp_out, "    %%flag_mov 4, %d; restore array index validity\n",
                          index_flag);
                  fprintf(vvp_out, "    %%store/reala v%p, %d;\n", sig, word_ix);
            }
            clr_word(word_ix);
            clr_flag(index_flag);
            if (range_flag >= 0) clr_flag(range_flag);
      } else if (is_property) {
            fprintf(vvp_out, "    %%store/prop/r %u;\n", pidx);
      } else {
            fprintf(vvp_out, "    %%store/real v%p_0;\n", sig);
      }
      if (is_property) {
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
      }
}

static void draw_unary_real(ivl_expr_t expr)
{
      ivl_expr_t sube;

	/* If the opcode is a ~ or a ! then the sub expression must not be
	 * a real expression, so use vector evaluation and then convert
	 * that result to a real value. */
      if ((ivl_expr_opcode(expr) == '~') || (ivl_expr_opcode(expr) == '!')) {
	    draw_real_logic_expr(expr);
	    return;
      }

      sube = ivl_expr_oper1(expr);

      if (ivl_expr_opcode(expr) == 'r') { /* Cast an integer value to a real. */
	    const char *suffix = "";
	    assert(ivl_expr_value(sube) != IVL_VT_REAL);
	    draw_eval_vec4(sube);
	    if (ivl_expr_signed(sube)) suffix = "/s";
	    fprintf(vvp_out, "    %%cvt/rv%s;\n", suffix);
	    return;
      }


      if (ivl_expr_opcode(expr) == '+') {
	    draw_eval_real(sube);
	    return;
      }

      if (ivl_expr_opcode(expr) == '-') {
	    fprintf(vvp_out, "    %%pushi/real 0, 0; load 0.0\n");
	    draw_eval_real(sube);
	    fprintf(vvp_out, "    %%sub/wr;\n");
	    return;
      }

      if (ivl_expr_opcode(expr) == 'm') { /* abs() */
	    draw_eval_real(sube);
	    fprintf(vvp_out, "    %%abs/wr;\n");
	    return;
      }

      if (ivl_expr_opcode(expr) == 'v') { /* Handled in eval_expr.c. */
            fprintf(stderr, "vvp.tgt error: real -> integer cast in real "
                            "context.\n");
	    assert(0);
      }

      switch (ivl_expr_opcode(expr)) {
	  case 'I':
	    change_real(sube, true, true);
	    return;
	  case 'i':
	    change_real(sube, false, true);
	    return;

	  case 'D':
	    change_real(sube, true, false);
	    return;
	  case 'd':
	    change_real(sube, false, false);
	    return;
	}

      fprintf(stderr, "vvp.tgt error: unhandled real unary operator: %c.\n",
              ivl_expr_opcode(expr));
      assert(0);
}

void draw_eval_real(ivl_expr_t expr)
{

	/* If this expression/sub-expression is not real then we need
	 * to evaluate it as a bit value and then convert the bit based
	 * result to a real value. This is required to get integer
	 * division to work correctly. */
      if (ivl_expr_value(expr) != IVL_VT_REAL) {
	    draw_real_logic_expr(expr);
	    return;
      }

      switch (ivl_expr_type(expr)) {

	  case IVL_EX_BINARY:
	    draw_binary_real(expr);
	    break;

	  case IVL_EX_NUMBER:
	    draw_number_real(expr);
	    break;

	  case IVL_EX_PROPERTY:
	    draw_property_real(expr);
	    break;

	  case IVL_EX_REALNUM:
	    draw_realnum_real(expr);
	    break;

	  case IVL_EX_SELECT:
	    draw_select_real(expr);
	    break;

	  case IVL_EX_SFUNC:
	    if (strcmp(ivl_expr_name(expr), "$ivl_queue$last") == 0) {
		  assert(ivl_expr_parms(expr) == 1);
		  draw_eval_object(ivl_expr_parm(expr, 0));
		  fprintf(vvp_out, "    %%dup/obj/ref; queue-last receiver alias\n");
		  fprintf(vvp_out, "    %%qsize/o;\n");
		  fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
		  fprintf(vvp_out, "    %%sub;\n");
		  fprintf(vvp_out, "    %%ix/vec4 3;\n");
		  fprintf(vvp_out, "    %%load/qo/r;\n");
	    } else if (strcmp(ivl_expr_name(expr), "$ivl_queue_method$pop_back")==0)
		  real_ex_pop(expr);
	    else if (strcmp(ivl_expr_name(expr), "$ivl_queue_method$pop_front")==0)
		  real_ex_pop(expr);
	    else
		  draw_sfunc_real(expr);
	    break;

	  case IVL_EX_SIGNAL:
	    draw_signal_real(expr);
	    break;

	  case IVL_EX_TERNARY:
	    draw_ternary_real(expr);
	    break;

	  case IVL_EX_UFUNC:
	    draw_ufunc_real(expr);
	    break;

	  case IVL_EX_UNARY:
	    draw_unary_real(expr);
	    break;

	  default:
		fprintf(stderr, "vvp.tgt error: XXXX Evaluate real expression (%d)\n",
			  ivl_expr_type(expr));
		fprintf(vvp_out, " ; XXXX Evaluate real expression (%d)\n",
			  ivl_expr_type(expr));
	    break;
      }

}
