/*
 * Copyright (c) 2001-2021 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "vvp_priv.h"
# include  <string.h>
# include  <assert.h>
# include  <stdlib.h>
# include  <stdbool.h>
# include  <limits.h>
# include  <inttypes.h>

unsigned local_count = 0;
unsigned thread_count = 0;

unsigned transient_id = 0;

/* A pure always_comb body has no procedural side effects: it consists only
   of blocking assignments and control flow over side-effect-free
   expressions. VVP may therefore avoid re-running such a process when a
   combinational neighbour changes an input and restores it before the
   neighbour completes. Keep this proof deliberately conservative. An
   assertion, task/function call, allocation, event operation, timing
   control, force/release, or dynamic-object access leaves the process on the
   ordinary IEEE event path. */
static ivl_statement_t pure_comb_top_wait_ = 0;

static int pure_comb_expr_(ivl_expr_t expr)
{
      unsigned idx;

      if (!expr)
	    return 1;

      switch (ivl_expr_type(expr)) {
	  case IVL_EX_NONE:
	  case IVL_EX_ENUMTYPE:
	  case IVL_EX_NULL:
	  case IVL_EX_NUMBER:
	  case IVL_EX_REALNUM:
	  case IVL_EX_STRING:
	  case IVL_EX_ULONG:
	    return 1;

	  case IVL_EX_SIGNAL: {
	    ivl_signal_t signal = ivl_expr_signal(expr);
	    ivl_variable_type_t data_type = signal
		  ? ivl_signal_data_type(signal) : IVL_VT_NO_TYPE;
	    if (!signal || signal_is_return_value(signal)
		|| ivl_signal_lifetime(signal) == IVL_VLT_AUTOMATIC
		|| ivl_scope_is_auto(ivl_signal_scope(signal)))
		  return 0;
	    if (data_type != IVL_VT_BOOL && data_type != IVL_VT_LOGIC)
		  return 0;
	    if (ivl_signal_dimensions(signal) != 0)
		  return 0;
	    return pure_comb_expr_(ivl_expr_oper1(expr));
      }

	  case IVL_EX_MEMORY:
	    /* The target API has no signal accessor for this legacy node kind. */
	    return 0;

	  case IVL_EX_ARRAY_SLICE:
	    /* Aggregate array reads remain on the ordinary event path. */
	    return 0;

	  case IVL_EX_BINARY:
	    return pure_comb_expr_(ivl_expr_oper1(expr))
		&& pure_comb_expr_(ivl_expr_oper2(expr));

	  case IVL_EX_UNARY:
	    switch (ivl_expr_opcode(expr)) {
		case 'i': case 'I': case 'd': case 'D':
		  return 0;
		default:
		  return pure_comb_expr_(ivl_expr_oper1(expr));
	    }

	  case IVL_EX_SELECT:
	    return pure_comb_expr_(ivl_expr_oper1(expr))
		&& pure_comb_expr_(ivl_expr_oper2(expr));

	  case IVL_EX_TERNARY:
	    return pure_comb_expr_(ivl_expr_oper1(expr))
		&& pure_comb_expr_(ivl_expr_oper2(expr))
		&& pure_comb_expr_(ivl_expr_oper3(expr));

	  case IVL_EX_ARRAY_PATTERN:
	  case IVL_EX_CONCAT:
	    for (idx = 0; idx < ivl_expr_parms(expr); idx += 1)
		  if (!pure_comb_expr_(ivl_expr_parm(expr, idx)))
			return 0;
	    return 1;

	  default:
	    /* In particular: SFUNC/UFUNC, NEW, PROPERTY, ARRAY,
	       SHALLOWCOPY, EVENT, SCOPE, DELAY, and BACCESS. */
	    return 0;
      }
}

static int pure_comb_lval_(ivl_lval_t lval)
{
      ivl_signal_t signal = lval ? ivl_lval_sig(lval) : 0;
      ivl_variable_type_t data_type = signal
	    ? ivl_signal_data_type(signal) : IVL_VT_NO_TYPE;

	  if (!lval || !signal || signal_is_return_value(signal)
	      || ivl_signal_lifetime(signal) == IVL_VLT_AUTOMATIC
	      || ivl_scope_is_auto(ivl_signal_scope(signal))
	      || ivl_signal_type(signal) != IVL_SIT_REG
	  || (data_type != IVL_VT_BOOL && data_type != IVL_VT_LOGIC)
	  || ivl_signal_dimensions(signal) != 0
	  || ivl_lval_nest(lval)
	  || ivl_lval_property_idx(lval) >= 0
	  || ivl_lval_is_array_slice(lval)
	  || ivl_lval_is_queue_slice(lval)
	  || ivl_lval_stream_range(lval) != IVL_STREAM_RANGE_NONE)
	    return 0;

      return pure_comb_expr_(ivl_lval_idx(lval))
	  && pure_comb_expr_(ivl_lval_part_off(lval));
}

struct pure_comb_signal_set_s {
      ivl_signal_t*items;
      unsigned count;
      unsigned capacity;
};

static void pure_comb_signal_set_add_(struct pure_comb_signal_set_s*set,
				      ivl_signal_t signal)
{
      unsigned idx;

      if (!signal)
	    return;
      for (idx = 0; idx < set->count; idx += 1)
	    if (set->items[idx] == signal)
		  return;
      if (set->count == set->capacity) {
	    unsigned next = set->capacity ? 2 * set->capacity : 16;
	    ivl_signal_t*items = realloc(set->items, next * sizeof(*items));
	    assert(items);
	    set->items = items;
	    set->capacity = next;
      }
      set->items[set->count++] = signal;
}

static void pure_comb_collect_expr_reads_(
	ivl_expr_t expr, struct pure_comb_signal_set_s*reads)
{
      unsigned idx;

      if (!expr)
	    return;
      switch (ivl_expr_type(expr)) {
	  case IVL_EX_ARRAY_SLICE:
	    pure_comb_signal_set_add_(reads, ivl_expr_signal(expr));
	    break;

	  case IVL_EX_SIGNAL:
	    pure_comb_signal_set_add_(reads, ivl_expr_signal(expr));
	    pure_comb_collect_expr_reads_(ivl_expr_oper1(expr), reads);
	    break;

	  case IVL_EX_BINARY:
	  case IVL_EX_SELECT:
	    pure_comb_collect_expr_reads_(ivl_expr_oper1(expr), reads);
	    pure_comb_collect_expr_reads_(ivl_expr_oper2(expr), reads);
	    break;

	  case IVL_EX_UNARY:
	    pure_comb_collect_expr_reads_(ivl_expr_oper1(expr), reads);
	    break;

	  case IVL_EX_TERNARY:
	    pure_comb_collect_expr_reads_(ivl_expr_oper1(expr), reads);
	    pure_comb_collect_expr_reads_(ivl_expr_oper2(expr), reads);
	    pure_comb_collect_expr_reads_(ivl_expr_oper3(expr), reads);
	    break;

	  case IVL_EX_ARRAY_PATTERN:
	  case IVL_EX_CONCAT:
	    for (idx = 0; idx < ivl_expr_parms(expr); idx += 1)
		  pure_comb_collect_expr_reads_(ivl_expr_parm(expr, idx), reads);
	    break;

	  default:
	    break;
      }
}

static void pure_comb_collect_lval_reads_(
	ivl_lval_t lval, struct pure_comb_signal_set_s*reads)
{
      if (!lval)
	    return;
      pure_comb_collect_expr_reads_(ivl_lval_idx(lval), reads);
      pure_comb_collect_expr_reads_(ivl_lval_part_off(lval), reads);
}

static void pure_comb_collect_stmt_signals_(
	ivl_statement_t stmt, struct pure_comb_signal_set_s*reads,
	struct pure_comb_signal_set_s*writes)
{
      unsigned idx;

      if (!stmt)
	    return;
      switch (ivl_statement_type(stmt)) {
	  case IVL_ST_ASSIGN:
	    pure_comb_collect_expr_reads_(ivl_stmt_rval(stmt), reads);
	    for (idx = 0; idx < ivl_stmt_lvals(stmt); idx += 1) {
		  ivl_lval_t lval = ivl_stmt_lval(stmt, idx);
		  pure_comb_collect_lval_reads_(lval, reads);
		  pure_comb_signal_set_add_(writes, ivl_lval_sig(lval));
	    }
	    break;

	  case IVL_ST_BLOCK:
	    for (idx = 0; idx < ivl_stmt_block_count(stmt); idx += 1)
		  pure_comb_collect_stmt_signals_(
			ivl_stmt_block_stmt(stmt, idx), reads, writes);
	    break;

	  case IVL_ST_CONDIT:
	    pure_comb_collect_expr_reads_(ivl_stmt_cond_expr(stmt), reads);
	    pure_comb_collect_stmt_signals_(
		  ivl_stmt_cond_true(stmt), reads, writes);
	    pure_comb_collect_stmt_signals_(
		  ivl_stmt_cond_false(stmt), reads, writes);
	    break;

	  case IVL_ST_CASE:
	  case IVL_ST_CASER:
	  case IVL_ST_CASEX:
	  case IVL_ST_CASEZ:
	    pure_comb_collect_expr_reads_(ivl_stmt_cond_expr(stmt), reads);
	    for (idx = 0; idx < ivl_stmt_case_count(stmt); idx += 1) {
		  pure_comb_collect_expr_reads_(
			ivl_stmt_case_expr(stmt, idx), reads);
		  pure_comb_collect_stmt_signals_(
			ivl_stmt_case_stmt(stmt, idx), reads, writes);
	    }
	    break;

	  case IVL_ST_DO_WHILE:
	  case IVL_ST_REPEAT:
	  case IVL_ST_WHILE:
	    pure_comb_collect_expr_reads_(ivl_stmt_cond_expr(stmt), reads);
	    pure_comb_collect_stmt_signals_(
		  ivl_stmt_sub_stmt(stmt), reads, writes);
	    break;

	  case IVL_ST_FORLOOP:
	    pure_comb_collect_stmt_signals_(
		  ivl_stmt_init_stmt(stmt), reads, writes);
	    pure_comb_collect_expr_reads_(ivl_stmt_cond_expr(stmt), reads);
	    pure_comb_collect_stmt_signals_(
		  ivl_stmt_sub_stmt(stmt), reads, writes);
	    pure_comb_collect_stmt_signals_(
		  ivl_stmt_step_stmt(stmt), reads, writes);
	    break;

	  default:
	    break;
      }
}

static int pure_comb_signals_alias_(ivl_signal_t left, ivl_signal_t right)
{
      unsigned left_count, right_count, left_word, right_word;
      uint64_t pairs;

      if (left == right)
	    return 1;
      left_count = ivl_signal_array_count(left);
      right_count = ivl_signal_array_count(right);
      pairs = (uint64_t)left_count * right_count;

      /* Very large unpacked arrays are not worth a quadratic alias proof.
	 Conservatively leave such a process on the ordinary event path. */
      if (pairs > 4096)
	    return 1;
      for (left_word = 0; left_word < left_count; left_word += 1) {
	    ivl_nexus_t left_nexus = ivl_signal_nex(left, left_word);
	    if (!left_nexus)
		  continue;
	    for (right_word = 0; right_word < right_count; right_word += 1)
		  if (left_nexus == ivl_signal_nex(right, right_word))
			return 1;
      }
      return 0;
}

static int pure_comb_signal_set_has_alias_(
	const struct pure_comb_signal_set_s*set, ivl_signal_t signal)
{
      unsigned idx;

      for (idx = 0; idx < set->count; idx += 1)
	    if (pure_comb_signals_alias_(set->items[idx], signal))
		  return 1;
      return 0;
}

static int pure_comb_signal_set_contains_(
	const struct pure_comb_signal_set_s*set, ivl_signal_t signal)
{
      unsigned idx;

      for (idx = 0; idx < set->count; idx += 1)
	    if (set->items[idx] == signal)
		  return 1;
      return 0;
}

static void pure_comb_signal_set_copy_(
	struct pure_comb_signal_set_s*dst,
	const struct pure_comb_signal_set_s*src)
{
      unsigned idx;

      for (idx = 0; idx < src->count; idx += 1)
	    pure_comb_signal_set_add_(dst, src->items[idx]);
}

static void pure_comb_signal_set_free_(struct pure_comb_signal_set_s*set)
{
      free(set->items);
      set->items = 0;
      set->count = 0;
      set->capacity = 0;
}

static void pure_comb_signal_set_intersect_(
	struct pure_comb_signal_set_s*dst,
	const struct pure_comb_signal_set_s*left,
	const struct pure_comb_signal_set_s*right)
{
      unsigned idx;

      pure_comb_signal_set_free_(dst);
      for (idx = 0; idx < left->count; idx += 1)
	    if (pure_comb_signal_set_contains_(right, left->items[idx]))
		  pure_comb_signal_set_add_(dst, left->items[idx]);
}

/* A signal written by the body is local combinational storage only when every
 * read of it is preceded, on every path reaching that read, by a whole-signal
 * blocking assignment in the current evaluation. This accepts the standard
 * default-assignment/override style used by commercial-simulator RTL while
 * rejecting stateful constructs such as "runs = runs + 1". */
static int pure_comb_expr_definite_(
	ivl_expr_t expr, const struct pure_comb_signal_set_s*writes,
	const struct pure_comb_signal_set_s*defined)
{
      unsigned idx;

      if (!expr)
	    return 1;
      switch (ivl_expr_type(expr)) {
	  case IVL_EX_ARRAY_SLICE: {
	    ivl_signal_t signal = ivl_expr_signal(expr);
	    if (pure_comb_signal_set_has_alias_(writes, signal)
		&& !pure_comb_signal_set_contains_(defined, signal))
		  return 0;
	    return 1;
	  }

	  case IVL_EX_SIGNAL: {
	    ivl_signal_t signal = ivl_expr_signal(expr);
	    if (pure_comb_signal_set_has_alias_(writes, signal)
		&& !pure_comb_signal_set_contains_(defined, signal))
		  return 0;
	    return pure_comb_expr_definite_(
		  ivl_expr_oper1(expr), writes, defined);
	  }

	  case IVL_EX_BINARY:
	  case IVL_EX_SELECT:
	    return pure_comb_expr_definite_(
		  ivl_expr_oper1(expr), writes, defined)
		&& pure_comb_expr_definite_(
		  ivl_expr_oper2(expr), writes, defined);

	  case IVL_EX_UNARY:
	    return pure_comb_expr_definite_(
		  ivl_expr_oper1(expr), writes, defined);

	  case IVL_EX_TERNARY:
	    return pure_comb_expr_definite_(
		  ivl_expr_oper1(expr), writes, defined)
		&& pure_comb_expr_definite_(
		  ivl_expr_oper2(expr), writes, defined)
		&& pure_comb_expr_definite_(
		  ivl_expr_oper3(expr), writes, defined);

	  case IVL_EX_ARRAY_PATTERN:
	  case IVL_EX_CONCAT:
	    for (idx = 0; idx < ivl_expr_parms(expr); idx += 1)
		  if (!pure_comb_expr_definite_(
			ivl_expr_parm(expr, idx), writes, defined))
			return 0;
	    return 1;

	  default:
	    return 1;
      }
}

static int pure_comb_stmt_definite_(
	ivl_statement_t stmt, const struct pure_comb_signal_set_s*writes,
	struct pure_comb_signal_set_s*defined)
{
      unsigned idx;

      if (!stmt)
	    return 1;
      switch (ivl_statement_type(stmt)) {
	  case IVL_ST_NOOP:
	    return 1;

	  case IVL_ST_ASSIGN:
	    if (!pure_comb_expr_definite_(
		  ivl_stmt_rval(stmt), writes, defined))
		  return 0;
	    for (idx = 0; idx < ivl_stmt_lvals(stmt); idx += 1) {
		  ivl_lval_t lval = ivl_stmt_lval(stmt, idx);
		  if (!pure_comb_expr_definite_(
			ivl_lval_idx(lval), writes, defined)
		      || !pure_comb_expr_definite_(
			ivl_lval_part_off(lval), writes, defined))
			return 0;
	    }
	    /* All selectors are evaluated from the incoming state. Do not let an
	       earlier concatenation component appear to define storage used by a
	       later component's selector. */
	    for (idx = 0; idx < ivl_stmt_lvals(stmt); idx += 1) {
		  ivl_lval_t lval = ivl_stmt_lval(stmt, idx);
		  ivl_signal_t signal = ivl_lval_sig(lval);
		  if (!ivl_lval_idx(lval) && !ivl_lval_part_off(lval)
		      && ivl_lval_width(lval) == ivl_signal_width(signal))
			pure_comb_signal_set_add_(defined, signal);
	    }
	    return 1;

	  case IVL_ST_BLOCK:
	    for (idx = 0; idx < ivl_stmt_block_count(stmt); idx += 1)
		  if (!pure_comb_stmt_definite_(
			ivl_stmt_block_stmt(stmt, idx), writes, defined))
			return 0;
	    return 1;

	  case IVL_ST_CONDIT: {
	    struct pure_comb_signal_set_s true_defs = { 0, 0, 0 };
	    struct pure_comb_signal_set_s false_defs = { 0, 0, 0 };
	    int safe;

	    if (!pure_comb_expr_definite_(
		  ivl_stmt_cond_expr(stmt), writes, defined))
		  return 0;
	    pure_comb_signal_set_copy_(&true_defs, defined);
	    pure_comb_signal_set_copy_(&false_defs, defined);
	    safe = pure_comb_stmt_definite_(
		  ivl_stmt_cond_true(stmt), writes, &true_defs)
		&& pure_comb_stmt_definite_(
		  ivl_stmt_cond_false(stmt), writes, &false_defs);
	    if (safe)
		  pure_comb_signal_set_intersect_(
			defined, &true_defs, &false_defs);
	    pure_comb_signal_set_free_(&true_defs);
	    pure_comb_signal_set_free_(&false_defs);
	    return safe;
	  }

	  case IVL_ST_CASE:
	  case IVL_ST_CASER:
	  case IVL_ST_CASEX:
	  case IVL_ST_CASEZ: {
	    struct pure_comb_signal_set_s incoming = { 0, 0, 0 };
	    struct pure_comb_signal_set_s merged = { 0, 0, 0 };
	    int have_merged = 0;
	    int has_default = 0;

	    if (!pure_comb_expr_definite_(
		  ivl_stmt_cond_expr(stmt), writes, defined))
		  return 0;
	    for (idx = 0; idx < ivl_stmt_case_count(stmt); idx += 1) {
		  ivl_expr_t item_expr = ivl_stmt_case_expr(stmt, idx);
		  if (!item_expr)
			has_default = 1;
		  else if (!pure_comb_expr_definite_(
			     item_expr, writes, defined))
			return 0;
	    }

	    pure_comb_signal_set_copy_(&incoming, defined);
	    for (idx = 0; idx < ivl_stmt_case_count(stmt); idx += 1) {
		  struct pure_comb_signal_set_s branch = { 0, 0, 0 };
		  pure_comb_signal_set_copy_(&branch, &incoming);
		  if (!pure_comb_stmt_definite_(
			ivl_stmt_case_stmt(stmt, idx), writes, &branch)) {
			pure_comb_signal_set_free_(&branch);
			pure_comb_signal_set_free_(&incoming);
			pure_comb_signal_set_free_(&merged);
			return 0;
		  }
		  if (!have_merged) {
			pure_comb_signal_set_copy_(&merged, &branch);
			have_merged = 1;
		  } else {
			struct pure_comb_signal_set_s next = { 0, 0, 0 };
			pure_comb_signal_set_intersect_(&next, &merged, &branch);
			pure_comb_signal_set_free_(&merged);
			merged = next;
		  }
		  pure_comb_signal_set_free_(&branch);
	    }
	    if (!has_default) {
		  struct pure_comb_signal_set_s next = { 0, 0, 0 };
		  if (have_merged)
			pure_comb_signal_set_intersect_(
			      &next, &merged, &incoming);
		  else
			pure_comb_signal_set_copy_(&next, &incoming);
		  pure_comb_signal_set_free_(&merged);
		  merged = next;
		  have_merged = 1;
	    }
	    if (have_merged) {
		  pure_comb_signal_set_free_(defined);
		  *defined = merged;
		  merged.items = 0;
		  merged.count = merged.capacity = 0;
	    }
	    pure_comb_signal_set_free_(&incoming);
	    pure_comb_signal_set_free_(&merged);
	    return 1;
	  }

	  case IVL_ST_WHILE:
	  case IVL_ST_REPEAT: {
	    struct pure_comb_signal_set_s body_defs = { 0, 0, 0 };
	    int safe;
	    if (!pure_comb_expr_definite_(
		  ivl_stmt_cond_expr(stmt), writes, defined))
		  return 0;
	    pure_comb_signal_set_copy_(&body_defs, defined);
	    safe = pure_comb_stmt_definite_(
		  ivl_stmt_sub_stmt(stmt), writes, &body_defs);
	    pure_comb_signal_set_free_(&body_defs);
	    return safe;
	  }

	  case IVL_ST_DO_WHILE: {
	    struct pure_comb_signal_set_s body_defs = { 0, 0, 0 };
	    int safe;
	    pure_comb_signal_set_copy_(&body_defs, defined);
	    safe = pure_comb_stmt_definite_(
		  ivl_stmt_sub_stmt(stmt), writes, &body_defs)
		&& pure_comb_expr_definite_(
		  ivl_stmt_cond_expr(stmt), writes, &body_defs);
	    if (safe) {
		  pure_comb_signal_set_free_(defined);
		  *defined = body_defs;
		  body_defs.items = 0;
		  body_defs.count = body_defs.capacity = 0;
	    }
	    pure_comb_signal_set_free_(&body_defs);
	    return safe;
	  }

	  case IVL_ST_FORLOOP: {
	    struct pure_comb_signal_set_s iteration = { 0, 0, 0 };
	    int safe;
	    if (!pure_comb_stmt_definite_(
		  ivl_stmt_init_stmt(stmt), writes, defined)
		|| !pure_comb_expr_definite_(
		  ivl_stmt_cond_expr(stmt), writes, defined))
		  return 0;
	    pure_comb_signal_set_copy_(&iteration, defined);
	    safe = pure_comb_stmt_definite_(
		  ivl_stmt_sub_stmt(stmt), writes, &iteration)
		&& pure_comb_stmt_definite_(
		  ivl_stmt_step_stmt(stmt), writes, &iteration);
	    pure_comb_signal_set_free_(&iteration);
	    return safe;
	  }

	  default:
	    return 0;
	}
}

static int pure_comb_has_read_before_definition_(ivl_statement_t stmt)
{
      struct pure_comb_signal_set_s reads = { 0, 0, 0 };
      struct pure_comb_signal_set_s writes = { 0, 0, 0 };
      struct pure_comb_signal_set_s defined = { 0, 0, 0 };
      int safe;

      pure_comb_collect_stmt_signals_(stmt, &reads, &writes);
      safe = pure_comb_stmt_definite_(stmt, &writes, &defined);
      pure_comb_signal_set_free_(&reads);
      pure_comb_signal_set_free_(&writes);
      pure_comb_signal_set_free_(&defined);
      return !safe;
}

/* Return true only when a case quality cannot produce an implicit runtime
 * diagnostic. This keeps the pure-combinational wake optimization from
 * suppressing warnings that a commercial event-driven simulator would emit.
 *
 * A priority case with a default is exhaustive. A plain (not casex/casez)
 * unique case is also diagnostic-free when every label is an exact-width,
 * distinct literal and unique has a default (unique0 needs no default).
 * Qualified-if lowering is intentionally excluded because its predicates can
 * overlap even when the generated case labels are distinct. */
static int pure_comb_case_quality_(ivl_statement_t stmt)
{
      ivl_case_quality_t quality = ivl_stmt_case_quality(stmt);
      unsigned count = ivl_stmt_case_count(stmt);
      unsigned condition_width = ivl_expr_width(ivl_stmt_cond_expr(stmt));
      int has_default = 0;
      unsigned idx;

      if (quality == IVL_CASE_QUALITY_BASIC)
	    return 1;
      if (ivl_stmt_case_is_quality_if(stmt))
	    return 0;

      for (idx = 0; idx < count; idx += 1)
	    if (!ivl_stmt_case_expr(stmt, idx))
		  has_default = 1;

      if (quality == IVL_CASE_QUALITY_PRIORITY)
	    return has_default;
      if (ivl_statement_type(stmt) != IVL_ST_CASE)
	    return 0;
      if (quality == IVL_CASE_QUALITY_UNIQUE && !has_default)
	    return 0;

      for (idx = 0; idx < count; idx += 1) {
	    ivl_expr_t left = ivl_stmt_case_expr(stmt, idx);
	    unsigned other;
	    if (!left)
		  continue;
	    if (ivl_expr_type(left) != IVL_EX_NUMBER
		|| ivl_expr_width(left) != condition_width)
		  return 0;
	    for (other = 0; other < idx; other += 1) {
		  ivl_expr_t right = ivl_stmt_case_expr(stmt, other);
		  if (right && ivl_expr_type(right) == IVL_EX_NUMBER
		      && ivl_expr_width(right) == condition_width
		      && strcmp(ivl_expr_bits(left), ivl_expr_bits(right)) == 0)
			return 0;
	    }
      }
      return 1;
}

static int pure_comb_stmt_impl_(ivl_statement_t stmt, int allow_named_scope)
{
      unsigned idx;

      if (!stmt)
	    return 1;

      switch (ivl_statement_type(stmt)) {
	  case IVL_ST_NOOP:
	    return 1;

	  case IVL_ST_BREAK:
	  case IVL_ST_CONTINUE:
	    /* Their path-sensitive definite-assignment merge is intentionally
	       outside this first conservative implementation. */
	    return 0;

	  case IVL_ST_ASSIGN:
	    if (ivl_stmt_delay_expr(stmt) || ivl_stmt_opcode(stmt)
		|| !pure_comb_expr_(ivl_stmt_rval(stmt)))
		  return 0;
	    for (idx = 0; idx < ivl_stmt_lvals(stmt); idx += 1)
		  if (!pure_comb_lval_(ivl_stmt_lval(stmt, idx)))
			return 0;
	    return 1;

	  case IVL_ST_BLOCK:
	    if ((ivl_stmt_block_scope(stmt) && !allow_named_scope)
		|| (ivl_stmt_block_scope(stmt)
		    && (ivl_scope_type(ivl_stmt_block_scope(stmt))
			!= IVL_SCT_BEGIN
			|| ivl_scope_is_auto(ivl_stmt_block_scope(stmt))
			|| ivl_scope_program(ivl_stmt_block_scope(stmt))))
		|| ivl_stmt_block_randsequence(stmt) != IVL_RANDSEQ_BLOCK_NONE)
		  return 0;
	    for (idx = 0; idx < ivl_stmt_block_count(stmt); idx += 1)
		  if (!pure_comb_stmt_impl_(
			ivl_stmt_block_stmt(stmt, idx), 0))
			return 0;
	    return 1;

	  case IVL_ST_CONDIT:
	    return !ivl_stmt_is_immediate_assertion(stmt)
		&& pure_comb_expr_(ivl_stmt_cond_expr(stmt))
		&& pure_comb_stmt_impl_(ivl_stmt_cond_true(stmt), 0)
		&& pure_comb_stmt_impl_(ivl_stmt_cond_false(stmt), 0);

	  case IVL_ST_CASE:
	  case IVL_ST_CASER:
	  case IVL_ST_CASEX:
	  case IVL_ST_CASEZ:
	    if (!pure_comb_case_quality_(stmt)
		|| !pure_comb_expr_(ivl_stmt_cond_expr(stmt)))
		  return 0;
	    for (idx = 0; idx < ivl_stmt_case_count(stmt); idx += 1)
		  if (!pure_comb_expr_(ivl_stmt_case_expr(stmt, idx))
		      || !pure_comb_stmt_impl_(
			ivl_stmt_case_stmt(stmt, idx), 0))
			return 0;
	    return 1;

	  case IVL_ST_DO_WHILE:
	  case IVL_ST_REPEAT:
	  case IVL_ST_WHILE:
	    return pure_comb_expr_(ivl_stmt_cond_expr(stmt))
		&& pure_comb_stmt_impl_(ivl_stmt_sub_stmt(stmt), 0);

	  case IVL_ST_FORLOOP:
	    return pure_comb_stmt_impl_(ivl_stmt_init_stmt(stmt), 0)
		&& pure_comb_expr_(ivl_stmt_cond_expr(stmt))
		&& pure_comb_stmt_impl_(ivl_stmt_sub_stmt(stmt), 0)
		&& pure_comb_stmt_impl_(ivl_stmt_step_stmt(stmt), 0);

	  default:
	    return 0;
      }
}

static int pure_comb_stmt_(ivl_statement_t stmt)
{
      return pure_comb_stmt_impl_(stmt, 1);
}

/*
 * The TD_ labels referenced and defined so far, each kept in first-seen
 * order (the stubs are emitted in reference order) with a hash index so
 * that noting a label is not a scan of every label before it. A large
 * class library notes each label many times.
 */
struct td_list_s {
      char**items;
      size_t count;
      size_t cap;
      char**slots; /* open-addressed hash of items; nil is empty */
      size_t nslots;
};

static struct td_list_s td_refs = { 0, 0, 0, 0, 0 };
static struct td_list_s td_defs = { 0, 0, 0, 0, 0 };

static size_t td_hash_(const char*label)
{
      size_t hash = (size_t)14695981039346656037ULL; /* FNV-1a */
      const unsigned char*cp;
      for (cp = (const unsigned char*)label ; *cp ; cp += 1) {
	    hash ^= *cp;
	    hash *= (size_t)1099511628211ULL;
      }
      return hash;
}

static void td_index_insert_(struct td_list_s*list, char*label)
{
      size_t idx = td_hash_(label) & (list->nslots - 1);
      while (list->slots[idx])
	    idx = (idx + 1) & (list->nslots - 1);
      list->slots[idx] = label;
}

static int td_list_contains(const struct td_list_s*list, const char*label)
{
      size_t idx;
      if (list->nslots == 0)
	    return 0;
      idx = td_hash_(label) & (list->nslots - 1);
      while (list->slots[idx]) {
	    if (strcmp(list->slots[idx], label) == 0)
		  return 1;
	    idx = (idx + 1) & (list->nslots - 1);
      }
      return 0;
}

static void td_list_append_unique(struct td_list_s*list, const char*label)
{
      size_t idx;

      if (td_list_contains(list, label))
	    return;

      if (list->count >= list->cap) {
	    size_t new_cap = (list->cap == 0)? 64 : (list->cap * 2);
	    char**tmp = (char**)realloc(list->items, new_cap * sizeof(char*));
	    assert(tmp);
	    list->items = tmp;
	    list->cap = new_cap;
      }

      list->items[list->count] = strdup(label);
      assert(list->items[list->count]);
      list->count += 1;

	/* Keep the hash at most half full. */
      if (2 * list->count > list->nslots) {
	    size_t nslots = list->nslots ? 2 * list->nslots : 128;
	    free(list->slots);
	    list->slots = (char**)calloc(nslots, sizeof(char*));
	    assert(list->slots);
	    list->nslots = nslots;
	    for (idx = 0 ; idx < list->count ; idx += 1)
		  td_index_insert_(list, list->items[idx]);
      } else {
	    td_index_insert_(list, list->items[list->count - 1]);
      }
}

void note_td_reference(const char*label)
{
      td_list_append_unique(&td_refs, label);
}

void note_td_definition(const char*label)
{
      td_list_append_unique(&td_defs, label);
}

void emit_td_stub_definitions(void)
{
      size_t idx;
      for (idx = 0; idx < td_refs.count; idx += 1) {
	    const char*label = td_refs.items[idx];
	    if (td_list_contains(&td_defs, label))
		  continue;
	    fprintf(vvp_out, "TD_%s ;\n", label);
	    fprintf(vvp_out, "    %%end;\n");
	    note_td_definition(label);
	    fprintf(stderr, "warning: emitting TD stub for unresolved target: TD_%s\n", label);
      }
}

/*
 * This file includes the code needed to generate VVP code for
 * processes. Scopes are already declared, we generate here the
 * executable code for the processes.
 */

/* Support a non-blocking assignment to a real array word. The real
   value to be written is already in the top of the stack. */
static void assign_to_array_r_word(ivl_signal_t lsig, ivl_expr_t word_ix,
                                   uint64_t delay,
                                   ivl_expr_t dexp, unsigned nevents)
{
      unsigned end_assign = transient_id++;
      int word_ix_reg = 3;

      /* if we have to evaluate a delay expression, evaluate word index into
	 temp register */
      if (dexp != 0) {
	    word_ix_reg = allocate_word();
      }

	/* This code is common to all the different types of array delays. */
      if (number_is_immediate(word_ix, IMM_WID, 0) &&
	  !number_is_unknown(word_ix)) {
	    fprintf(vvp_out, "    %%ix/load %d, %ld, 0; address\n",
		    word_ix_reg, get_number_immediate(word_ix));
      } else {
	      /* Calculate array word index into index register 3 */
	    draw_eval_expr_into_integer(word_ix, word_ix_reg);
	      /* Skip assignment if word expression is not defined. */
	    unsigned do_assign = transient_id++;
	    fprintf(vvp_out, "    %%jmp/0 t_%u, 4;\n", do_assign);
	    fprintf(vvp_out, "    %%pop/real 1;\n");
	    fprintf(vvp_out, "    %%jmp t_%u;\n", end_assign);
	    fprintf(vvp_out, "t_%u ;\n", do_assign);
      }

      if (dexp != 0) {
	      /* Calculated delay... */
	    int delay_index = allocate_word();
	    draw_eval_expr_into_integer(dexp, delay_index);
	    fprintf(vvp_out, "    %%ix/mov 3, %d;\n", word_ix_reg);
	    note_array_signal_use(lsig);
	    fprintf(vvp_out, "    %%assign/ar/d v%p, %d;\n", lsig,
	                     delay_index);
	    clr_word(word_ix_reg);
	    clr_word(delay_index);
      } else if (nevents != 0) {
	      /* Event control delay... */
	    note_array_signal_use(lsig);
	    fprintf(vvp_out, "    %%assign/ar/e v%p;\n", lsig);
      } else {
	      /* Constant delay... */
	    unsigned long low_d = delay % UINT64_C(0x100000000);
	    unsigned long hig_d = delay / UINT64_C(0x100000000);

	      /*
	       * The %assign can only take a 32 bit delay. For a larger
	       * delay we need to put it into an index register.
	       */
	    if (hig_d != 0) {
		  int delay_index = allocate_word();
		  fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
		          delay_index, low_d, hig_d);
		  note_array_signal_use(lsig);
		  fprintf(vvp_out, "    %%assign/ar/d v%p, %d;\n", lsig,
			  delay_index);
		  clr_word(delay_index);
	    } else {
		  note_array_signal_use(lsig);
		  fprintf(vvp_out, "    %%assign/ar v%p, %lu;\n",
		          lsig, low_d);
	    }
      }

      fprintf(vvp_out, "t_%u ;\n", end_assign);
      if (nevents != 0) fprintf(vvp_out, "    %%evctl/c;\n");

}

static void emit_part_carrier_clip_(ivl_lval_t lval, int offset_index)
{
      unsigned carrier_wid = ivl_lval_part_carrier_width(lval);
      uint64_t carrier_off = ivl_lval_part_carrier_off(lval);

      if (carrier_wid == 0)
	    return;
      fprintf(vvp_out, "    %%pushi/vec4 %" PRIu64
	      ", 0, 32; carrier offset\n", carrier_off);
      fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
	      carrier_wid);
      fprintf(vvp_out, "    %%clip/vec4/b %d;\n", offset_index);
}

/* Evaluate a dynamic packed carrier before its relative final index, retain
 * both validity results, then clip and translate the pending assignment. */
static void emit_dynamic_part_carrier_clip_(ivl_lval_t lval,
					    ivl_expr_t part_off_ex,
					    int offset_index)
{
      ivl_expr_t carrier = ivl_lval_dynamic_part_carrier(lval);
      int carrier_index = allocate_word();
      int carrier_flag = allocate_flag();

      assert(carrier);
      draw_eval_expr_into_integer(carrier, carrier_index);
      fprintf(vvp_out, "    %%flag_mov %d, 4; carrier validity\n",
	      carrier_flag);
      draw_eval_expr_into_integer(part_off_ex, offset_index);
      fprintf(vvp_out, "    %%flag_or 4, %d; combine carrier validity\n",
	      carrier_flag);
      fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
	      ivl_lval_part_carrier_width(lval));
      fprintf(vvp_out, "    %%clip/vec4/d %d, %d;\n",
	      offset_index, carrier_index);
      clr_flag(carrier_flag);
      clr_word(carrier_index);
}

static void assign_to_array_word(ivl_lval_t lval, ivl_signal_t lsig,
				 ivl_expr_t word_ix,
				 uint64_t delay, ivl_expr_t dexp,
				 ivl_expr_t part_off_ex,
				 unsigned nevents)
{
      int word_ix_reg = 3;
      int part_off_reg = 0;
      int delay_index;
      unsigned long part_off = 0;
      ivl_expr_t dynamic_carrier = ivl_lval_dynamic_part_carrier(lval);

      int error_flag = allocate_flag();

	/* Figure the constant part offset, if possible. If we can do
	   so, then forget about the expression and use the calculated
	   value. After this block, if the part_off_ex!=0, then the
	   part offset is used, otherwise, use part_off. */
      if (part_off_ex == 0) {
	    part_off = 0;
      } else if (!dynamic_carrier
		 && number_is_immediate(part_off_ex, IMM_WID, 0) &&
		 !number_is_unknown(part_off_ex)) {
	    part_off = get_number_immediate(part_off_ex);
	    part_off_ex = 0;
      }

      if (dexp != 0) {
	    word_ix_reg = allocate_word();
      } else if (part_off_ex) {
	    word_ix_reg = allocate_word();
      }

	/* Calculate array word index into word index register */
      draw_eval_expr_into_integer(word_ix, word_ix_reg);
      fprintf(vvp_out, "    %%flag_mov %d, 4; array word validity\n",
	      error_flag);

      if (part_off_ex && dynamic_carrier) {
	    part_off_reg = allocate_word();
	    emit_dynamic_part_carrier_clip_(lval, part_off_ex, part_off_reg);
	    fprintf(vvp_out, "    %%flag_or %d, 4; packed index validity\n",
		    error_flag);
      } else if (part_off_ex) {
	    part_off_reg = allocate_word();
	    draw_eval_expr_into_integer(part_off_ex, part_off_reg);
	      /* Add the error state of the part select to the global. */
	    fprintf(vvp_out, "    %%flag_or %d, 4;\n", error_flag);

      } else if (part_off != 0) {

	      /* Store word part select into part_off_reg */
	    part_off_reg = allocate_word();
	    fprintf(vvp_out, "    %%ix/load %d, %lu, 0; part off\n",
		             part_off_reg, part_off);
      }

      if (ivl_lval_part_carrier_width(lval) && !dynamic_carrier) {
	    if (part_off_reg == 0) {
		  part_off_reg = allocate_word();
		  fprintf(vvp_out, "    %%ix/load %d, 0, 0; part off\n",
			  part_off_reg);
	    }
	    fprintf(vvp_out, "    %%flag_mov 4, %d; index validity\n",
		    error_flag);
	    emit_part_carrier_clip_(lval, part_off_reg);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; bounded part select\n",
		    error_flag);
      }

	/* Calculated delay... */
      if (dexp != 0) {
	    delay_index = allocate_word();
	    draw_eval_expr_into_integer(dexp, delay_index);
	    if (word_ix_reg != 3) {
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", word_ix_reg);
		  clr_word(word_ix_reg);
	    }
	      /* Restore the error state since an undefined delay is okay. */
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", error_flag);
	    note_array_signal_use(lsig);
	    fprintf(vvp_out, "    %%assign/vec4/a/d v%p, %d, %d;\n",
		    lsig, part_off_reg, delay_index);

	    clr_word(delay_index);

	/* Event control delay... */
      } else if (nevents != 0) {
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", error_flag);
	    if (word_ix_reg != 3) {
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", word_ix_reg);
		  clr_word(word_ix_reg);
	    }
	    note_array_signal_use(lsig);
	    fprintf(vvp_out, "    %%assign/vec4/a/e v%p, %d;\n", lsig, part_off_reg);

	/* Constant delay... */
      } else {
	    unsigned long low_d = delay % UINT64_C(0x100000000);
	    unsigned long hig_d = delay / UINT64_C(0x100000000);

	    delay_index = allocate_word();
	    fprintf(vvp_out, "    %%ix/load %d, %lu, %lu; Constant delay\n",
		    delay_index, low_d, hig_d);
	    if (word_ix_reg != 3) {
		  fprintf(vvp_out, "    %%ix/mov 3, %d;\n", word_ix_reg);
		  clr_word(word_ix_reg);
	    }
	    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", error_flag);
	    note_array_signal_use(lsig);
	    fprintf(vvp_out, "    %%assign/vec4/a/d v%p, %d, %d;\n",
		    lsig, part_off_reg, delay_index);
	    clr_word(delay_index);
      }

      clr_flag(error_flag);
      if (part_off_reg)
	    clr_word(part_off_reg);
}

/*
 * The code to generate here assumes that a vec4 vector of the right
 * width is top of the vec4 stack. Arrange for it to be popped and
 * assigned to the given l-value.
 */
static void assign_to_lvector(ivl_lval_t lval,
			      uint64_t delay, ivl_expr_t dexp,
			      unsigned nevents)
{
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_expr_t part_off_ex = ivl_lval_part_off(lval);
      ivl_expr_t dynamic_carrier = ivl_lval_dynamic_part_carrier(lval);
      unsigned long part_off = 0;

      const unsigned long use_word = 0;

      const char*assign_op = "%assign";
      if (ivl_signal_type(sig) == IVL_SIT_UWIRE)
	    assign_op = "%force";

	// Detect the case that this is actually a non-blocking assign
	// to an array word. In that case, run off somewhere else to
	// deal with it.
      if (ivl_signal_dimensions(sig) > 0) {
	    ivl_expr_t word_ix = ivl_lval_idx(lval);
	    assert(word_ix);
	    assign_to_array_word(lval, sig, word_ix, delay, dexp, part_off_ex,
			 nevents);
	    return;
      }

      if (part_off_ex == 0) {
	    part_off = 0;
      } else if (!dynamic_carrier
		 && number_is_immediate(part_off_ex, IMM_WID, 0) &&
		 !number_is_unknown(part_off_ex)) {
	    part_off = get_number_immediate(part_off_ex);
	    part_off_ex = 0;
      }

      unsigned long low_d = delay % UINT64_C(0x100000000);
      unsigned long hig_d = delay / UINT64_C(0x100000000);
      unsigned carrier_wid = ivl_lval_part_carrier_width(lval);

      if (part_off_ex && dynamic_carrier) {
	    int offset_index = allocate_word();
	    int delay_index = allocate_word();

	    if (dexp)
		  draw_eval_expr_into_integer(dexp, delay_index);
	    else
		  fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
			  delay_index, low_d, hig_d);
	    emit_dynamic_part_carrier_clip_(lval, part_off_ex, offset_index);
	    if (nevents != 0) {
		  assert(dexp == 0);
		  fprintf(vvp_out, "    %s/vec4/off/e v%p_%lu, %d;\n",
			  assign_op, sig, use_word, offset_index);
	    } else {
		  fprintf(vvp_out, "    %s/vec4/off/d v%p_%lu, %d, %d;\n",
			  assign_op, sig, use_word, offset_index, delay_index);
	    }
	    clr_word(offset_index);
	    clr_word(delay_index);
	    return;
      }

      if (part_off_ex) {
	      // The part select offset is calculated (not constant)
	      // so in these cases we'll need to use
	      // %assign/vec4/off/... variants.

	    if (dexp != 0) {
		    /* Calculated offset... */
		  int offset_index = allocate_word();
		    /* Calculated delay... */
		  int delay_index = allocate_word();
		  draw_eval_expr_into_integer(dexp, delay_index);
		    /* Calculated part offset. This will leave flag
		       bit 4 set to 1 if the copy into the index
		       detected xz values. The %assign will use that
		       to know to skip the assign. */
		  draw_eval_expr_into_integer(part_off_ex, offset_index);
		  emit_part_carrier_clip_(lval, offset_index);
		    /* If the index expression has XZ bits, skip the assign. */
		  fprintf(vvp_out, "    %s/vec4/off/d v%p_%lu, %d, %d;\n",
			  assign_op, sig, use_word, offset_index, delay_index);

		  clr_word(offset_index);
		  clr_word(delay_index);

	    } else if (nevents != 0) {
		  int offset_index = allocate_word();
		    /* Event control delay... */
		  draw_eval_expr_into_integer(part_off_ex, offset_index);
		  emit_part_carrier_clip_(lval, offset_index);
		  fprintf(vvp_out, "    %s/vec4/off/e v%p_%lu, %d;\n",
			  assign_op, sig, use_word, offset_index);

		  clr_word(offset_index);

	    } else {
		  int offset_index = allocate_word();
		  int delay_index = allocate_word();

		    /* Constant delay... */
		  fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
			  delay_index, low_d, hig_d);
		    /* Calculated part offset. This will leave flag
		       bit 4 set to 1 if the copy into the index
		       detected xz values. The %assign will use that
		       to know to skip the assign. */
		  draw_eval_expr_into_integer(part_off_ex, offset_index);
		  emit_part_carrier_clip_(lval, offset_index);
		    /* If the index expression has XZ bits, skip the assign. */
		  fprintf(vvp_out, "    %s/vec4/off/d v%p_%lu, %d, %d;\n",
			  assign_op, sig, use_word, offset_index, delay_index);
		  clr_word(offset_index);
		  clr_word(delay_index);
	    }

      } else if (carrier_wid || part_off>0
		 || ivl_lval_width(lval)!=ivl_signal_width(sig)) {

	    if (nevents != 0) {
		  assert(dexp==0);
		  int offset_index = allocate_word();
		  fprintf(vvp_out, "    %%ix/load %d, %lu, 0;\n",
			  offset_index, part_off);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  if (carrier_wid)
			emit_part_carrier_clip_(lval, offset_index);
		  fprintf(vvp_out, "    %s/vec4/off/e v%p_%lu, %d;\n",
			  assign_op, sig, use_word, offset_index);
		  clr_word(offset_index);

	    } else {
		    // Constant part offset, non-constant (calculated)
		    // assignment delay. Use the %assign/vec4/off/d
		    // instruction to handle this case.
		  int offset_index = allocate_word();
		  int delay_index = allocate_word();
		  if (dexp) {
			draw_eval_expr_into_integer(dexp,delay_index);
		  } else {
			fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
				delay_index, low_d, hig_d);
		  }
		  fprintf(vvp_out, "    %%ix/load %d, %lu, 0;\n", offset_index, part_off);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  if (carrier_wid)
			emit_part_carrier_clip_(lval, offset_index);
		  fprintf(vvp_out, "    %s/vec4/off/d v%p_%lu, %d, %d;\n",
			  assign_op, sig, use_word, offset_index, delay_index);
		  clr_word(offset_index);
		  clr_word(delay_index);
	    }

      } else if (ivl_signal_type(sig) == IVL_SIT_UWIRE) {
	/* A whole-vector unresolved-net NBA needs the delayed force opcode.
	 * %force/vec4 takes one operand and applies immediately; the ordinary
	 * %assign/vec4 delay operand would make an invalid force instruction. */
	int delay_index = allocate_word();
	if (dexp)
	    draw_eval_expr_into_integer(dexp, delay_index);
	else
	    fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
		    delay_index, low_d, hig_d);
	fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
	fprintf(vvp_out, "    %%force/vec4/off/d v%p_%lu, 0, %d;\n",
		  sig, use_word, delay_index);
	clr_word(delay_index);
      } else if (dexp != 0) {
	      /* Calculated delay... */
	    int delay_index = allocate_word();
	    draw_eval_expr_into_integer(dexp, delay_index);
	    fprintf(vvp_out, "    %s/vec4/d v%p_%lu, %d;\n",
		    assign_op, sig, use_word, delay_index);
	    clr_word(delay_index);
      } else if (nevents != 0) {
	      /* Event control delay... */
	    fprintf(vvp_out, "    %s/vec4/e v%p_%lu;\n",
		    assign_op, sig, use_word);
      } else {
	      /*
	       * The %assign can only take a 32 bit delay. For a larger
	       * delay we need to put it into an index register.
	       */
	    if (hig_d != 0) {
		  int delay_index = allocate_word();
		  fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
		          delay_index, low_d, hig_d);
		  fprintf(vvp_out, "    %s/vec4/d v%p_%lu, %d;\n",
		          assign_op, sig, use_word, delay_index);
		  clr_word(delay_index);
	    } else {
		  fprintf(vvp_out, "    %s/vec4 v%p_%lu, %lu;\n",
		          assign_op, sig, use_word, low_d);
	    }
      }
}

/*
 * Routine to insert statement tracing information into the output stream
 * when requested by the user (compiler).
 */
void show_stmt_file_line(ivl_statement_t net, const char* desc)
{
      if (show_file_line) {
	      /* If the line number is not zero then the file should also
	       * be set. It's safe to skip the assert during debug, but
	       * the assert represents missing file/line information that
	       * should be reported/fixed. */
	    unsigned lineno = ivl_stmt_lineno(net);
	    assert(lineno);
	    fprintf(vvp_out, "    %%file_line %u %u \"%s\";\n",
	            ivl_file_table_index(ivl_stmt_file(net)), lineno, desc);
      }
}

static void emit_force_release_identity(ivl_statement_t stmt, int force)
{
      fprintf(vvp_out, "FR_%p %%file_line %u %u \"VPI %s statement\";\n",
              stmt, ivl_file_table_index(ivl_stmt_file(stmt)),
              ivl_stmt_lineno(stmt), force ? "force" : "release");
}

static void emit_force_release_identity_end(void)
{
      fprintf(vvp_out, "    %%file_line 0 0 \"End force/release statement\";\n");
}

static int show_stmt_alloc(ivl_statement_t net)
{
      ivl_scope_t scope = ivl_stmt_call(net);

      fprintf(vvp_out, "    %%alloc S_%p;\n", scope);
      return 0;
}

/*
 * This function handles the case of non-blocking assign to word
 * variables such as real, i.e:
 *
 *     real foo;
 *     foo <= 1.0;
 *
 * In this case we know (by Verilog syntax) that there is only exactly
 * 1 l-value, the target identifier, so it should be relatively easy.
 */
static int show_stmt_assign_nb_real(ivl_statement_t net)
{
      ivl_lval_t lval;
      ivl_signal_t sig;
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t del  = ivl_stmt_delay_expr(net);
	/* variables for the selection of word from an array. */
      unsigned long use_word = 0;
      uint64_t delay = 0;
      unsigned nevents = ivl_stmt_nevent(net);

	/* Must be exactly 1 l-value. */
      assert(ivl_stmt_lvals(net) == 1);

      lval = ivl_stmt_lval(net, 0);
      sig = ivl_lval_sig(lval);
      assert(sig);

      if (del && (ivl_expr_type(del) == IVL_EX_DELAY)) {
	    assert(number_is_immediate(del, 64, 0));
	    delay = ivl_expr_delay_val(del);
	    del = 0;
      }

	/* Evaluate the r-value */
      draw_eval_real(rval);

      if (ivl_signal_dimensions(sig) > 0) {
	    ivl_expr_t word_ix = ivl_lval_idx(lval);
	    assert(word_ix);
	    assign_to_array_r_word(sig, word_ix, delay, del, nevents);
	    return 0;
      }

	/* We need to calculate the delay expression. */
      if (del) {
	    assert(nevents == 0);
	    int delay_index = allocate_word();
	    draw_eval_expr_into_integer(del, delay_index);
	    fprintf(vvp_out, "    %%assign/wr/d v%p_%lu, %d;\n",
	            sig, use_word, delay_index);
	    clr_word(delay_index);
      } else if (nevents) {
	    fprintf(vvp_out, "    %%assign/wr/e v%p_%lu;\n",
	            sig, use_word);
      } else {
	    unsigned long low_d = delay % UINT64_C(0x100000000);
	    unsigned long hig_d = delay / UINT64_C(0x100000000);

	      /*
	       * The %assign can only take a 32 bit delay. For a larger
	       * delay we need to put it into an index register.
	       */
	    if (hig_d != 0) {
		  int delay_index = allocate_word();
		  fprintf(vvp_out, "    %%ix/load %d, %lu, %lu;\n",
		          delay_index, low_d, hig_d);
		  fprintf(vvp_out, "    %%assign/wr/d v%p_%lu, %d;\n",
		          sig, use_word, delay_index);
		  clr_word(delay_index);
	    } else {
		  fprintf(vvp_out, "    %%assign/wr v%p_%lu, %lu;\n",
		          sig, use_word, low_d);
	    }
      }

      return 0;
}

static int show_stmt_assign_nb(ivl_statement_t net)
{
      ivl_lval_t lval;
      ivl_expr_t rval = ivl_stmt_rval(net);
      ivl_expr_t del  = ivl_stmt_delay_expr(net);
      ivl_signal_t sig;
      unsigned nevents = ivl_stmt_nevent(net);

      show_stmt_file_line(net, "Nonblocking assignment.");

      /* The force opcodes used for unresolved nets have no event-counted
       * form. Do not emit an invalid %force/vec4/e instruction. */
      if (nevents) {
	for (unsigned idx = 0; idx < ivl_stmt_lvals(net); idx += 1) {
	    ivl_signal_t item_sig = ivl_lval_sig(ivl_stmt_lval(net, idx));
	    if (item_sig && ivl_signal_type(item_sig) == IVL_SIT_UWIRE) {
		fprintf(stderr, "%s:%u: vvp.tgt sorry: event-controlled "
			"nonblocking assignment to an unresolved net is not "
			"supported.\n", ivl_stmt_file(net),
			ivl_stmt_lineno(net));
		return 1;
	    }
	}
      }

	/* The generic vec4 NBA lowering below assumes every l-value is an
	 * ordinary signal. IVL exports concatenation members rightmost first,
	 * so checking only member zero misses a class/interface property on the
	 * source-left side and emits a malformed vector assignment for its object
	 * carrier. Validate all members before evaluating the r-value or emitting
	 * any event-control/NBA store. Supporting this form requires scheduling
	 * one atomic RHS snapshot across both property and vector destinations. */
      if (ivl_stmt_lvals(net) > 1) {
	    for (unsigned idx = 0; idx < ivl_stmt_lvals(net); idx += 1) {
		  ivl_lval_t item = ivl_stmt_lval(net, idx);
		  ivl_signal_t item_sig = ivl_lval_sig(item);
		  if (ivl_lval_property_idx(item) >= 0
		      || ivl_lval_nest(item)
		      || (item_sig
			  && ivl_signal_data_type(item_sig) == IVL_VT_CLASS)) {
			fprintf(stderr, "%s:%u: vvp.tgt error: a concatenated "
				"nonblocking assignment containing a class or "
				"interface property is not yet supported atomically "
				"in the NBA region.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			return 1;
		  }
	    }
      }

	/* If we have an event control build the control structure. */
      if (nevents) {
	    assert(del == 0);

	    ivl_expr_t cnt = ivl_stmt_cond_expr(net);
	    unsigned long count = 1;
	    if (cnt && (ivl_expr_type(cnt) == IVL_EX_ULONG)) {
		  assert(number_is_immediate(cnt, IMM_WID, 0));
		  count = ivl_expr_uvalue(cnt);
		  cnt = 0;
	    }

	    char name[256];
	    if (nevents == 1) {
		  ivl_event_t ev = ivl_stmt_events(net, 0);
		  snprintf(name, sizeof(name), "E_%p", ev);
	    } else {
		  unsigned idx;
		  static unsigned int cascade_counter = 0;
		  ivl_event_t ev = ivl_stmt_events(net, 0);
		  fprintf(vvp_out, "Eassign_%u .event/or E_%p",
		                   cascade_counter, ev);

		  for (idx = 1;  idx < nevents;  idx += 1) {
			ev = ivl_stmt_events(net, idx);
			fprintf(vvp_out, ", E_%p", ev);
		  }

		  fprintf(vvp_out, ";\n");
		  snprintf(name, sizeof(name), "Eassign_%u", cascade_counter);
		  cascade_counter += 1;
	    }

	    if (cnt) {
		  int count_index = allocate_word();
		  const char*type = ivl_expr_signed(cnt) ? "/s" : "";
		  draw_eval_expr_into_integer(cnt, count_index);
		  fprintf(vvp_out, "    %%evctl%s %s, %d;\n", type, name,
		                   count_index);
		  clr_word(count_index);
	    } else {
		  fprintf(vvp_out, "    %%evctl/i %s, %lu;\n", name, count);
	    }
      } else {
	    assert(ivl_stmt_cond_expr(net) == 0);
      }

      uint64_t delay = 0;

	/* Detect special cases that are handled elsewhere. */
      lval = ivl_stmt_lval(net,0);
      if ((sig = ivl_lval_sig(lval))) {
	    switch (ivl_signal_data_type(sig)) {
		case IVL_VT_REAL:
		  return show_stmt_assign_nb_real(net);
		default:
		  break;
	    }
      }

	/* Nonblocking store to a class-object / virtual-interface property
	   (`obj.prop <= v`, `vif.sig <= v`): schedule it in the NBA region
	   (IEEE 1800-2017 10.4.2). Whole vec4 properties and packed fields
	   are supported, including variable selectors and constant delays. Residual property
	   forms are rejected below; executing them as blocking assignments
	   would silently change their event-region semantics. */
	if (ivl_lval_property_idx(lval) >= 0 || ivl_lval_nest(lval) ||
	    (sig && ivl_signal_data_type(sig) == IVL_VT_CLASS)) {
	    uint64_t prop_delay = 0;
	    int can_delay = 1;
	    if (del && (ivl_expr_type(del) == IVL_EX_DELAY) &&
		number_is_immediate(del, 64, 0)) {
		  prop_delay = ivl_expr_delay_val(del);
	    } else if (del) {
		  can_delay = 0;
	    }
	    if (nevents == 0 && can_delay &&
	        show_stmt_assign_nb_cobject(net, prop_delay) == 0)
		  return 0;
	    fprintf(stderr, "%s:%u: vvp.tgt error: this nonblocking "
		    "property assignment form is not yet supported without "
		    "changing its NBA semantics.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
	}

      if ((del == 0) && (nevents == 0)) {
	    if (ivl_lval_nest(lval))
		  return show_stmt_assign(net);

	    if (sig) {
		  switch (ivl_signal_data_type(sig)) {
		      case IVL_VT_STRING:
		      case IVL_VT_DARRAY:
		      case IVL_VT_QUEUE:
		      case IVL_VT_CLASS:
			return show_stmt_assign(net);
		      default:
			break;
		  }
	    }
      }

      if (del && (ivl_expr_type(del) == IVL_EX_DELAY)) {
	    assert(number_is_immediate(del, 64, 0));
	    delay = ivl_expr_delay_val(del);
	    del = 0;
      }


      { unsigned wid;
	unsigned lidx;
	unsigned cur_rbit = 0;

	wid = ivl_stmt_lwidth(net);
	draw_eval_vec4(rval);
	resize_vec4_wid(rval, wid);

	  /* Spread the r-value vector over the bits of the l-value. */
	for (lidx = 0 ;  lidx < ivl_stmt_lvals(net) ;  lidx += 1) {
	      unsigned bit_limit = wid - cur_rbit;

	      lval = ivl_stmt_lval(net, lidx);

	      if (bit_limit > ivl_lval_width(lval))
		    bit_limit = ivl_lval_width(lval);

		/* If there are more lvals after this, split off from
		   the top of the vec4 stack only the bits (lsb) that
		   we need for the current lval. */
	      if (lidx+1 < ivl_stmt_lvals(net))
		    fprintf(vvp_out, "    %%split/vec4 %u;\n", bit_limit);
	      assign_to_lvector(lval, delay, del, nevents);

	      cur_rbit += bit_limit;

	}
      }

      if (nevents)
	    fprintf(vvp_out, "    %%evctl/c;\n");

      return 0;
}

static int show_stmt_block(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      unsigned idx;
      unsigned cnt = ivl_stmt_block_count(net);
      ivl_randsequence_block_t rs_kind =
            ivl_stmt_block_randsequence(net);
      unsigned rs_out = 0;
      vvp_randsequence_flow_t saved_rs = { 0, 0 };

      if (rs_kind != IVL_RANDSEQ_BLOCK_NONE) {
            rs_out = local_count++;
            saved_rs = vvp_randsequence_flow_push(rs_kind, rs_out);
      }

      for (idx = 0 ;  idx < cnt ;  idx += 1) {
	    rc += show_statement(ivl_stmt_block_stmt(net, idx), sscope);
      }

      if (rs_kind != IVL_RANDSEQ_BLOCK_NONE) {
            fprintf(vvp_out, "T_%u.%u ;\n", thread_count, rs_out);
            vvp_randsequence_flow_pop(saved_rs);
      }

      return rc;
}

static int named_block_can_inline_(ivl_scope_t subscope);

/*
 * True if STMT, and every statement nested in it, is one that runs the
 * same whether the thread executing it is the enclosing thread or a
 * child forked for a named block: no timing control, no call, no fork,
 * no disable (which also covers break, continue and return), no event
 * trigger, and no force or procedural continuous assignment. A nested
 * named block qualifies only if it can be inlined itself. This is a
 * whitelist; any statement kind not named here disqualifies the block.
 */
static int named_block_stmt_can_inline_(ivl_statement_t stmt)
{
      unsigned idx;

      if (stmt == 0)
	    return 1;

      switch (ivl_statement_type(stmt)) {
	  case IVL_ST_NOOP:
	    return 1;

	  case IVL_ST_ASSIGN:
	      /* An intra-assignment event control is lowered to a
		 separate wait, which the default case rejects. */
	    return ivl_stmt_delay_expr(stmt) == 0;

	  case IVL_ST_ASSIGN_NB:
	    return ivl_stmt_delay_expr(stmt) == 0 && ivl_stmt_nevent(stmt) == 0;

	  case IVL_ST_BLOCK:
	    if (ivl_stmt_block_scope(stmt)
		&& !named_block_can_inline_(ivl_stmt_block_scope(stmt)))
		  return 0;
	    for (idx = 0 ; idx < ivl_stmt_block_count(stmt) ; idx += 1)
		  if (!named_block_stmt_can_inline_(ivl_stmt_block_stmt(stmt, idx)))
			return 0;
	    return 1;

	  case IVL_ST_CONDIT:
	    return named_block_stmt_can_inline_(ivl_stmt_cond_true(stmt))
		&& named_block_stmt_can_inline_(ivl_stmt_cond_false(stmt));

	  case IVL_ST_CASE:
	  case IVL_ST_CASER:
	  case IVL_ST_CASEX:
	  case IVL_ST_CASEZ:
	    for (idx = 0 ; idx < ivl_stmt_case_count(stmt) ; idx += 1)
		  if (!named_block_stmt_can_inline_(ivl_stmt_case_stmt(stmt, idx)))
			return 0;
	    return 1;

	  case IVL_ST_WHILE:
	  case IVL_ST_DO_WHILE:
	  case IVL_ST_REPEAT:
	    return named_block_stmt_can_inline_(ivl_stmt_sub_stmt(stmt));

	  case IVL_ST_FORLOOP:
	    return named_block_stmt_can_inline_(ivl_stmt_init_stmt(stmt))
		&& named_block_stmt_can_inline_(ivl_stmt_sub_stmt(stmt))
		&& named_block_stmt_can_inline_(ivl_stmt_step_stmt(stmt));

	  default:
	    return 0;
      }
}

/*
 * A named block normally runs in a child thread so that its scope has
 * threads a disable can find, and so that an automatic block gets its
 * own activation frame. A static block that no disable targets, inside
 * no automatic scope, and whose body passes the whitelist above has
 * neither need. Its child would start at the front of the active queue
 * while the parent waits in %join, and the parent would resume at the
 * front as soon as the child ended, so running the body in the
 * enclosing thread executes the same statements in the same order.
 */
static int named_block_can_inline_(ivl_scope_t subscope)
{
      ivl_scope_t cur;

      if (ivl_scope_type(subscope) != IVL_SCT_BEGIN)
	    return 0;
      if (ivl_scope_is_disable_target(subscope))
	    return 0;
      for (cur = subscope ; cur ; cur = ivl_scope_parent(cur))
	    if (ivl_scope_is_auto(cur))
		  return 0;
      return 1;
}

/*
 * This draws an invocation of a named block. This is a little
 * different because a subscope is created. We do that by creating
 * a thread to deal with this, unless the block can run inline in the
 * enclosing thread (see named_block_can_inline_).
 */
static int show_stmt_block_named(ivl_statement_t net, ivl_scope_t scope)
{
      int rc;
      unsigned out_id, sub_id;
      ivl_scope_t subscope = ivl_stmt_block_scope(net);

      if (named_block_stmt_can_inline_(net)) {
	      /* Compile the body in the block's scope, as the child would
		 be, so any system call in it still reports that scope. */
	    fprintf(vvp_out, "    .scope S_%p;\n", subscope);
	    rc = show_stmt_block(net, subscope);
	    fprintf(vvp_out, "    .scope S_%p;\n", scope);
	    return rc;
      }

      out_id = transient_id++;
      sub_id = transient_id++;

      fprintf(vvp_out, "    %%fork t_%u, S_%p;\n",
	      sub_id, subscope);
      fprintf(vvp_out, "    %%jmp t_%u;\n", out_id);
	/* Change the compiling scope to be the named blocks scope. */
      fprintf(vvp_out, "    .scope S_%p;\n", subscope);
      fprintf(vvp_out, "t_%u ;\n", sub_id);

      rc = show_stmt_block(net, subscope);
      fprintf(vvp_out, "    %%end;\n");
	/* Return to the previous scope. */
      fprintf(vvp_out, "    .scope S_%p;\n", scope);

      fprintf(vvp_out, "t_%u %%join;\n", out_id);
	/* An automatic block that owns a frame dispatches after its %free
	   instead. One collapsed into the enclosing frame (".shared") has no
	   %free, so it must dispatch here or a break/continue it left
	   pending would never reach its loop. */
      if (!ivl_scope_is_auto(subscope) || !ivl_scope_auto_frame(subscope))
	    draw_nested_flow_dispatch(scope);

      return rc;
}


/*
 * G44: unique/unique0 case statements must, in addition to the
 * no-match check (handled by show_stmt_case below), detect and report
 * at runtime when MORE THAN ONE case item matches the selector value
 * (IEEE1800-2017 12.5.3). This can only be known by testing every
 * item's label, so unlike the plain/priority early-exit branch chain
 * (first match jumps straight into its branch and no further items
 * are tested), the unique/unique0 lowering has to:
 *
 *   1. Evaluate every item's label exactly once, recording the first
 *      matching item in one word register and folding the results into
 *      an "any match seen so far" flag and a "more than one match seen"
 *      flag (the latter set precisely when a match is found after a
 *      match was already seen).
 *   2. Emit the multiple-match $warning once, if the multi-match
 *      flag is set.
 *   3. Dispatch to the FIRST matching item's branch from the saved item
 *      index, without re-evaluating a label. This preserves
 *      first-match-wins semantics exactly like the plain/priority chain
 *      while using constant temporary storage even for generated register
 *      maps with hundreds of case items.
 *   4. If nothing matched, fall through to the default branch (if
 *      any) or the existing "value is unhandled" warning (unique
 *      only -- unique0 stays silent on zero matches, unchanged).
 *
 * priority and plain case are untouched (they keep the original
 * early-exit branch chain below) since they must not pay for any of
 * this extra bookkeeping.
 */
static int show_stmt_case_unique(ivl_statement_t net, ivl_scope_t sscope,
                                  ivl_case_quality_t qual)
{
      int rc = 0;
      ivl_expr_t expr = ivl_stmt_cond_expr(net);
      int string_case = ivl_expr_value(expr) == IVL_VT_STRING;
      unsigned count = ivl_stmt_case_count(net);

      unsigned idx, default_case;
      unsigned lab_out, lab_after_warn;

      int any_flag = allocate_flag();
      int multi_flag = allocate_flag();
      int first_match_word = allocate_word();
      unsigned*body_label = count ? calloc(count, sizeof(unsigned)) : 0;
      int quality_if = ivl_stmt_case_is_quality_if(net);

      show_stmt_file_line(net, "Case statement.");

	/* Keep a homogeneous string selector at its runtime length. */
      if (string_case) draw_eval_string(expr);
      else draw_eval_vec4(expr);

      fprintf(vvp_out, "    %%flag_set/imm %d, 0;\n", any_flag);
      fprintf(vvp_out, "    %%flag_set/imm %d, 0;\n", multi_flag);
      fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", first_match_word,
              count);

      default_case = count;

	/* Pass 1: evaluate every item's label exactly once, and fold
	   the per-item match result into any_flag/multi_flag. */
      for (idx = 0 ;  idx < count ;  idx += 1) {
	    ivl_expr_t cex = ivl_stmt_case_expr(net, idx);
	    unsigned lab_after, lab_already_matched;
	    int result_flag = 4;

	    if (cex == 0) {
		  default_case = idx;
		  continue;
	    }

	    body_label[idx] = local_count++;

	      /* Duplicate the case expression so that the cmp
		 instructions below do not completely erase the
		 value. Do this in front of each compare. */
	    fprintf(vvp_out, string_case ? "    %%dup/str;\n"
				       : "    %%dup/vec4;\n");
	    if (string_case) {
		  draw_eval_string(cex);
		  fprintf(vvp_out, "    %%cmp/str;\n");
		  result_flag = 4;
	    } else {
		  draw_eval_vec4(cex);

	      switch (ivl_statement_type(net)) {

		case IVL_ST_CASE:
		    /* Plain case uses case-equality (===-like); flag 6
		       (eeq) is the well-defined match flag here -- flag
		       4 (eq) can read back X when the operands carry
		       X/Z bits, which %jmp/1 would treat as "no match"
		       even though a literal case must match X/Z bits
		       exactly. This mirrors the branch table below. */
		  fprintf(vvp_out, "    %%cmp/u;\n");
		  result_flag = 6;
		  break;

		case IVL_ST_CASEX:
		  fprintf(vvp_out, "    %%cmp/x;\n");
		  result_flag = 4;
		  break;

		case IVL_ST_CASEZ:
		  fprintf(vvp_out, "    %%cmp/z;\n");
		  result_flag = 4;
		  break;

		default:
		  assert(0);
	      }
	    }

	      /* If this item did not match, skip the any/multi
		 bookkeeping below. */
	    lab_after = local_count++;
	    fprintf(vvp_out, "    %%jmp/0 T_%u.%u, %d;\n",
		    thread_count, lab_after, result_flag);

	      /* This item matched. If any_flag is already set, a
		 previous item also matched, so this is (at least) a
		 second match: fold that into multi_flag before
		 marking any_flag. */
	    fprintf(vvp_out, "    %%flag_or %d, %d;\n", multi_flag, any_flag);
	    lab_already_matched = local_count++;
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, %d;\n",
		    thread_count, lab_already_matched, any_flag);
	    fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n",
		    first_match_word, idx);
	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count,
		    lab_already_matched);
	    fprintf(vvp_out, "    %%flag_set/imm %d, 1;\n", any_flag);

	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_after);
      }

	/* Emit the multiple-match warning (unique and unique0 both
	   warn on this -- they only differ on the zero-match case). */
      lab_after_warn = local_count++;
      fprintf(vvp_out, "    %%jmp/0 T_%u.%u, %d;\n",
	      thread_count, lab_after_warn, multi_flag);
      if (quality_if)
	    fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
		    "\"multiple conditions match for unique or unique0 if "
		    "statement\" {0 0 0 0};\n",
		    ivl_file_table_index(ivl_stmt_file(net)),
		    ivl_stmt_lineno(net));
      else
	    fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
		    "\"multiple case items match for unique or unique0 case "
		    "statement\" {0 0 0 0};\n",
		    ivl_file_table_index(ivl_stmt_file(net)),
		    ivl_stmt_lineno(net));
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_after_warn);

	/* The dispatch below only reads first_match_word, so drop the
	   case expression now. A branch body can then leave the case
	   through break/continue/return/disable without leaking it. */
      fprintf(vvp_out, string_case ? "    %%pop/str 1;\n"
				  : "    %%pop/vec4 1;\n");

      lab_out = local_count++;

	/* Pass 2: dispatch to the saved first matching item without
	   re-evaluating any label. */
      for (idx = 0 ;  idx < count ;  idx += 1) {
	    if (idx == default_case)
		  continue;
	    fprintf(vvp_out, "    %%jmp/wr/e T_%u.%u, %d, %u;\n",
		    thread_count, body_label[idx], first_match_word, idx);
      }

	/* All runtime uses of these temporaries have now been emitted. Free
	   their code-generation slots before lowering any branch body so a
	   nested unique case can safely reuse them. */
      clr_flag(any_flag);
      clr_flag(multi_flag);
      clr_word(first_match_word);

	/* Nothing matched: fall through to the default (if any) or
	   the existing no-match warning (unique only; unique0 is
	   silent on zero matches). */
      if (default_case < count) {
	    ivl_statement_t cst = ivl_stmt_case_stmt(net, default_case);
	    rc += show_statement(cst, sscope);
      } else if (qual == IVL_CASE_QUALITY_UNIQUE) {
	    if (quality_if)
		  fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
			  "\"no condition matches for priority or unique if statement\""
			  " {0 0 0 0};\n",
			  ivl_file_table_index(ivl_stmt_file(net)),
			  ivl_stmt_lineno(net));
	    else
		  fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
			  "\"value is unhandled for priority or unique case statement\""
			  " {0 0 0 0};\n",
			  ivl_file_table_index(ivl_stmt_file(net)),
			  ivl_stmt_lineno(net));
      }

      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);

      for (idx = 0 ;  idx < count ;  idx += 1) {
	    ivl_statement_t cst = ivl_stmt_case_stmt(net, idx);

	    if (idx == default_case)
		  continue;

	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, body_label[idx]);
	    rc += show_statement(cst, sscope);

	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      }

      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_out);

      free(body_label);

      return rc;
}

static int show_stmt_case(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      ivl_case_quality_t qual = ivl_stmt_case_quality(net);
      int quality_if = ivl_stmt_case_is_quality_if(net);
      ivl_expr_t expr = ivl_stmt_cond_expr(net);
      int string_case = ivl_expr_value(expr) == IVL_VT_STRING;
      unsigned count = ivl_stmt_case_count(net);

      unsigned local_base = local_count;

      unsigned idx, default_case;

      /* G44: unique/unique0 case statements are lowered by
         show_stmt_case_unique (above), which additionally detects and
         reports multiple matches per IEEE1800-2017 12.5.3. This
         function handles plain and priority case, unchanged. */
      if (qual == IVL_CASE_QUALITY_UNIQUE || qual == IVL_CASE_QUALITY_UNIQUE0)
	    return show_stmt_case_unique(net, sscope, qual);

      show_stmt_file_line(net, "Case statement.");

      local_count += count + 1;

	/* Keep a homogeneous string selector at its runtime length. */
      if (string_case) draw_eval_string(expr);
      else draw_eval_vec4(expr);

	/* First draw the branch table.  All the non-default cases
	   generate a branch out of here, to the code that implements
	   the case. The default will fall through all the tests. */
      default_case = count;

      for (idx = 0 ;  idx < count ;  idx += 1) {
	    ivl_expr_t cex = ivl_stmt_case_expr(net, idx);

	    if (cex == 0) {
		  default_case = idx;
		  continue;
	    }

	      /* Duplicate the case expression so that the cmp
		 instructions below do not completely erase the
		 value. Do this in front of each compare. */
	    fprintf(vvp_out, string_case ? "    %%dup/str;\n"
				       : "    %%dup/vec4;\n");
	    if (string_case) {
		  draw_eval_string(cex);
		  fprintf(vvp_out, "    %%cmp/str;\n");
		  fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
			  thread_count, local_base+idx);
	    } else {
		  draw_eval_vec4(cex);

	      switch (ivl_statement_type(net)) {

		case IVL_ST_CASE:
		  fprintf(vvp_out, "    %%cmp/u;\n");
		  fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 6;\n",
			  thread_count, local_base+idx);
		  break;

		case IVL_ST_CASEX:
		  fprintf(vvp_out, "    %%cmp/x;\n");
		  fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
			  thread_count, local_base+idx);
		  break;

		case IVL_ST_CASEZ:
		  fprintf(vvp_out, "    %%cmp/z;\n");
		  fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
			  thread_count, local_base+idx);
		  break;

		default:
		  assert(0);
	      }
	    }
      }

	/* Every path out of the branch table pops the case expression
	   before running a body, so a body that leaves the case through
	   break/continue/return/disable leaves nothing on the stack. */
      fprintf(vvp_out, string_case ? "    %%pop/str 1;\n"
				  : "    %%pop/vec4 1;\n");

	/* Emit code for the default case. */
      if (default_case < count) {
	    ivl_statement_t cst = ivl_stmt_case_stmt(net, default_case);
	    rc += show_statement(cst, sscope);
      }
	/* Emit code to check priority has handled a value (when there
           is no default). Note: unique/unique0 never reach here -- they
           are handled by show_stmt_case_unique above. */
      else if (default_case == count) {
          if (qual == IVL_CASE_QUALITY_PRIORITY) {
              if (quality_if)
		    fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
			    "\"no condition matches for priority or unique if statement\""
			    " {0 0 0 0};\n",
			    ivl_file_table_index(ivl_stmt_file(net)),
			    ivl_stmt_lineno(net));
              else
		    fprintf(vvp_out, "    %%vpi_call/w %u %u \"$warning\", "
			    "\"value is unhandled for priority or unique case statement\""
			    " {0 0 0 0};\n",
			    ivl_file_table_index(ivl_stmt_file(net)),
			    ivl_stmt_lineno(net));
          }
      }

	/* Jump to the out of the case. */
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count,
	      local_base+count);

      for (idx = 0 ;  idx < count ;  idx += 1) {
	    ivl_statement_t cst = ivl_stmt_case_stmt(net, idx);

	    if (idx == default_case)
		  continue;

	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, local_base+idx);
	    fprintf(vvp_out, string_case ? "    %%pop/str 1;\n"
				    : "    %%pop/vec4 1;\n");
	    rc += show_statement(cst, sscope);

	      /* Statement is done, jump to the out of the case. */
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count,
		    local_base+count);

      }


	/* The out of the case. */
      fprintf(vvp_out, "T_%u.%u ;\n",  thread_count, local_base+count);

      return rc;
}

static int show_stmt_case_r(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      ivl_expr_t expr = ivl_stmt_cond_expr(net);
      unsigned count = ivl_stmt_case_count(net);

      unsigned local_base = local_count;

      unsigned idx, default_case;

      show_stmt_file_line(net, "Case statement.");

	/* Build the reference value into the top of the stack. All
	   the case comparisons will make duplicates of this value in
	   order to do their tests. */
      draw_eval_real(expr);

      local_count += count + 1;

	/* First draw the branch table.  All the non-default cases
	   generate a branch out of here, to the code that implements
	   the case. The default will fall through all the tests. */
      default_case = count;

      for (idx = 0 ;  idx < count ;  idx += 1) {
	    ivl_expr_t cex = ivl_stmt_case_expr(net, idx);

	    if (cex == 0) {
		  default_case = idx;
		  continue;
	    }

	      /* The reference value... */
	    fprintf(vvp_out, "    %%dup/real;\n");
	      /* The guard value... */
	    draw_eval_real(cex);
	      /* The comparison. */
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
		    thread_count, local_base+idx);

      }

	/* Pop the reference value before any body runs (see
	   show_stmt_case), so leaving a body early cannot leak it. */
      fprintf(vvp_out, "    %%pop/real 1;\n");

	/* Emit code for the case default. The above jump table will
	   fall through to this statement. */
      if (default_case < count) {
	    ivl_statement_t cst = ivl_stmt_case_stmt(net, default_case);
	    rc += show_statement(cst, sscope);
      }

	/* Jump to the out of the case. */
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count,
	      local_base+count);

      for (idx = 0 ;  idx < count ;  idx += 1) {
	    ivl_statement_t cst = ivl_stmt_case_stmt(net, idx);

	    if (idx == default_case)
		  continue;

	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, local_base+idx);
	    fprintf(vvp_out, "    %%pop/real 1;\n");
	    rc += show_statement(cst, sscope);

	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count,
		    local_base+count);
      }

	/* The out of the case. */
      fprintf(vvp_out, "T_%u.%u ;\n",  thread_count, local_base+count);

      return rc;
}

/*
 * The real value is already pushed to the top of the real value stack.
 */
static void force_real_to_lval(ivl_statement_t net)
{
      const char*command_name;
      ivl_lval_t lval;
      ivl_signal_t lsig;

      switch (ivl_statement_type(net)) {
	  case IVL_ST_CASSIGN:
	    command_name = "%cassign/wr";
	    break;
	  case IVL_ST_FORCE:
	    command_name = "%force/wr";
	    break;
	  default:
	    command_name = "ERROR";
	    assert(0);
	    break;
      }

      assert(ivl_stmt_lvals(net) == 1);
      lval = ivl_stmt_lval(net, 0);
      lsig = ivl_lval_sig(lval);

      assert(ivl_lval_width(lval) == 1);
      assert(ivl_lval_part_off(lval) == 0);

      ivl_expr_t word_idx = ivl_lval_idx(lval);
      unsigned long use_word = 0;
      if (word_idx != 0) {
	    assert(number_is_immediate(word_idx, IMM_WID, 0));
	      /* An out-of-range or undefined index will have been
		 converted to a canonical offset of 1'bx. Skip the
		 assignment in this case. */
	    if (number_is_unknown(word_idx)) {
		  fprintf(vvp_out, "	%%pop/real 1;\n");
		  return;
	    }
	    use_word = get_number_immediate(word_idx);

	      /* We do not currently support using a word from a variable
		 array as the L-value (SystemVerilog / Icarus extension). */
	    if (ivl_signal_type(lsig) == IVL_SIT_REG) {
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s to the "
			  "word of a variable array (%s[%ld]).\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net),
			  command_name, ivl_signal_basename(lsig),
			  ivl_signal_array_base(lsig) + (long)use_word);
	          vvp_errors += 1;
	    }
      }

	/* L-Value must be a signal: reg or wire */
      assert(lsig != 0);

      fprintf(vvp_out, "    %s v%p_%lu;\n", command_name, lsig, use_word);
}

/* A force watcher cannot safely retain a pointer to per-invocation array
   storage after its activation ends. Explicit lifetime overrides take
   precedence over the enclosing scope (IEEE 1800-2023 6.21). */
static int force_array_is_automatic_(ivl_signal_t sig)
{
      ivl_lifetime_t lifetime = ivl_signal_lifetime(sig);
      return lifetime == IVL_VLT_AUTOMATIC
          || (lifetime == IVL_VLT_INHERITED
	      && ivl_scope_is_auto(ivl_signal_scope(sig)));
}

static int force_array_is_vec4_(ivl_signal_t sig)
{
      ivl_variable_type_t type = ivl_signal_data_type(sig);
      return type == IVL_VT_BOOL || type == IVL_VT_LOGIC;
}

/* Prepare the operands shared by the variable-array force and release
   opcodes. The unpacked word index is already a canonical, zero-based array
   address by the time it reaches the target, and the /a opcodes take it in
   index register 3. A packed offset of zero is encoded by word register 0.

   Return zero for an unknown or out-of-range word. In that case the caller is
   responsible for balancing any value stack entry. */
static int prepare_force_array_lval_(ivl_lval_t lval, int*off_index)
{
      ivl_signal_t sig = ivl_lval_sig(lval);
      ivl_expr_t word_idx = ivl_lval_idx(lval);
      ivl_expr_t part_off_ex = ivl_lval_part_off(lval);
      unsigned long use_word;

      assert(sig != 0);
      assert(word_idx != 0);
      assert(number_is_immediate(word_idx, IMM_WID, 0));

      *off_index = 0;
      if (number_is_unknown(word_idx))
	    return 0;

      use_word = get_number_immediate(word_idx);
      if (use_word >= ivl_signal_array_count(sig))
	    return 0;

      if (part_off_ex != 0) {
	    if (number_is_immediate(part_off_ex, IMM_WID, 0)
		&& !number_is_unknown(part_off_ex)) {
		  unsigned long part_off = get_number_immediate(part_off_ex);
		  if (part_off != 0) {
			*off_index = allocate_word();
			fprintf(vvp_out, "    %%ix/load %d, %lu, 0; force array packed offset\n",
			        *off_index, part_off);
		  }
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
	    } else {
		  *off_index = allocate_word();
		  draw_eval_expr_into_integer(part_off_ex, *off_index);
	    }
      } else {
	    fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
      }

        /* Loading ix3 does not alter flag 4, so a dynamic/unknown packed
	   offset remains visible to the consuming opcode. */
      fprintf(vvp_out, "    %%ix/load 3, %lu, 0; force array word\n",
	      use_word);
      return 1;
}

static void force_vector_to_lval(ivl_statement_t net)
{
      unsigned lidx;

      const char*command_name;

      switch (ivl_statement_type(net)) {
	  case IVL_ST_CASSIGN:
	    command_name = "%cassign/vec4";
	    break;
	  case IVL_ST_FORCE:
	    command_name = "%force/vec4";
	    break;
	  default:
	    command_name = "ERROR";
	    assert(0);
	    break;
      }

      for (lidx = 0 ;  lidx < ivl_stmt_lvals(net) ; lidx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, lidx);
	    ivl_signal_t lsig = ivl_lval_sig(lval);
	    ivl_expr_t part_off_ex = ivl_lval_part_off(lval);

	    ivl_expr_t word_idx = ivl_lval_idx(lval);
	    unsigned long use_word = 0;
	    int array_force = 0;

	    if (word_idx != 0) {
		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		    /* An out-of-range or undefined index will have been
		       converted to a canonical offset of 1'bx. Skip the
		       assignment in this case. */
		  if (number_is_unknown(word_idx)) {
			fprintf(vvp_out, "    %%pop/vec4 1; force to out of bounds index suppressed.\n");
			return;
		  }
		  use_word = get_number_immediate(word_idx);

		    /* Procedural assign retains its existing limitation. A force
		       to a static variable array uses the compact-array path below. */
		  if (ivl_signal_type(lsig) == IVL_SIT_REG
		      && ivl_statement_type(net) == IVL_ST_FORCE
		      && force_array_is_vec4_(lsig)) {
			array_force = 1;
			if (use_word >= ivl_signal_array_count(lsig)) {
			      fprintf(vvp_out, "    %%pop/vec4 1; force to out of bounds index suppressed.\n");
			      return;
			}
			if (force_array_is_automatic_(lsig)) {
			      fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s to an "
				      "automatic variable array (%s[%ld]).\n",
				      ivl_stmt_file(net), ivl_stmt_lineno(net),
				      command_name, ivl_signal_basename(lsig),
				      ivl_signal_array_base(lsig) + (long)use_word);
			      vvp_errors += 1;
			      fprintf(vvp_out, "    %%pop/vec4 1; automatic array force suppressed.\n");
			      return;
			}
		  } else if (ivl_signal_type(lsig) == IVL_SIT_REG) {
				fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s to the "
					"word of a variable array (%s[%ld]).\n",
					ivl_stmt_file(net), ivl_stmt_lineno(net),
					command_name, ivl_signal_basename(lsig),
					ivl_signal_array_base(lsig) + (long)use_word);
		        vvp_errors += 1;
			if (ivl_statement_type(net) == IVL_ST_FORCE) {
			      fprintf(vvp_out, "    %%pop/vec4 1; unsupported array force suppressed.\n");
			      return;
			}
		  }
	    }


	    if (lidx+1 < ivl_stmt_lvals(net))
		  fprintf(vvp_out, "    %%split/vec4 %u;\n", ivl_lval_width(lval));

	      /* L-Value must be a signal: reg or wire */
	    assert(lsig != 0);

	    if (array_force) {
		  int off_index;
		  if (!prepare_force_array_lval_(lval, &off_index)) {
			fprintf(vvp_out, "    %%pop/vec4 1; force to out of bounds index suppressed.\n");
			return;
		  }
		  note_array_signal_use(lsig);
		  fprintf(vvp_out, "    %%force/vec4/a v%p, %d;\n",
		          lsig, off_index);
		  if (off_index != 0)
			clr_word(off_index);
		  continue;
	    }

	      /* Do not support bit or part selects of l-values yet. */
	    if (part_off_ex) {
		  int off_index = allocate_word();
		  draw_eval_expr_into_integer(part_off_ex, off_index);
		  fprintf(vvp_out, "    %s/off v%p_%lu, %d;\n", command_name, lsig, use_word, off_index);
		  clr_word(off_index);
	    } else {
		  assert(ivl_lval_width(lval) == ivl_signal_width(lsig));
		  assert(!ivl_lval_part_off(lval));
		  fprintf(vvp_out, "    %s v%p_%lu;\n", command_name, lsig, use_word);
	    }

      }
}

static void force_link_rval(ivl_statement_t net, ivl_expr_t rval)
{
      ivl_signal_t rsig;
      ivl_lval_t lval;
      ivl_signal_t lsig;
      const char*command_name;
      ivl_expr_t part_off_ex;

      ivl_expr_t lword_idx, rword_idx;
      unsigned long use_lword = 0, use_rword = 0;

      if (ivl_expr_type(rval) != IVL_EX_SIGNAL) {
	    if (ivl_expr_type(rval) == IVL_EX_NUMBER ||
	        ivl_expr_type(rval) == IVL_EX_REALNUM)
		  return;

	      /* A no-argument $urandom call has no RHS source element that can
	       * change and trigger reevaluation (IEEE 1800-2023 4.9.2, 10.6 and
	       * 18.13.1). It is therefore correctly evaluated exactly once when
	       * the procedural continuous assignment starts. Keep this whitelist
	       * narrow: arbitrary zero-argument system functions may observe
	       * implicit state for which the target has no dependency metadata. */
	    if (ivl_expr_type(rval) == IVL_EX_SFUNC
		&& ivl_expr_parms(rval) == 0
		&& ivl_expr_name(rval) != 0
		&& strcmp(ivl_expr_name(rval), "$urandom") == 0)
		  return;

	    fprintf(stderr, "%s:%u: vvp.tgt sorry: procedural continuous "
		    "assignments are not yet fully supported. The RHS of "
		    "this assignment will only be evaluated once, at the "
		    "time the assignment statement is executed.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return;
      }

      switch (ivl_statement_type(net)) {
	  case IVL_ST_CASSIGN:
	    command_name = "%cassign";
	    break;
	  case IVL_ST_FORCE:
	    command_name = "%force";
	    break;
	  default:
	    command_name = "ERROR";
	    assert(0);
	    break;
      }

      rsig = ivl_expr_signal(rval);
      assert(ivl_stmt_lvals(net) == 1);
      lval = ivl_stmt_lval(net, 0);
      lsig = ivl_lval_sig(lval);

	/* A force to a compact variable-array word saves its normalized
	 * address, packed offset and effective width in the immediately
	 * preceding %force/vec4/a. Link a live signal source to that saved
	 * descriptor without inventing a per-word array functor. */
      lword_idx = ivl_lval_idx(lval);
      if (ivl_statement_type(net) == IVL_ST_FORCE
	  && lword_idx != 0 && ivl_signal_type(lsig) == IVL_SIT_REG
	  && !force_array_is_vec4_(lsig))
	    return;

      if (ivl_statement_type(net) == IVL_ST_FORCE
	  && lword_idx != 0 && ivl_signal_type(lsig) == IVL_SIT_REG
	  && force_array_is_vec4_(lsig)) {
	    assert(number_is_immediate(lword_idx, IMM_WID, 0));
	    if (number_is_unknown(lword_idx)
		|| (unsigned long)get_number_immediate(lword_idx)
		   >= ivl_signal_array_count(lsig)
		|| force_array_is_automatic_(lsig))
		  return;

	    if (!force_array_is_vec4_(rsig)) {
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: procedural continuous "
			  "assignments are not yet fully supported. The RHS of "
			  "this assignment will only be evaluated once, at the "
			  "time the assignment statement is executed.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return;
	    }

	    if (signal_is_return_value(rsig)
		|| (ivl_signal_local(rsig)
		    && ivl_scope_is_auto(ivl_signal_scope(rsig)))) {
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: procedural continuous "
			  "assignments are not yet fully supported. The RHS of "
			  "this assignment will only be evaluated once, at the "
			  "time the assignment statement is executed.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return;
	    }

	    if ((rword_idx = ivl_expr_oper1(rval)) != 0) {
		  assert(ivl_signal_dimensions(rsig) != 0);
		  if (!number_is_immediate(rword_idx, IMM_WID, 0)
		      || number_is_unknown(rword_idx)) {
			fprintf(stderr, "%s:%u: vvp.tgt sorry: procedural continuous "
				"assignments are not yet fully supported. The RHS of "
				"this assignment will only be evaluated once, at the "
				"time the assignment statement is executed.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			return;
		  }
		  use_rword = get_number_immediate(rword_idx);
		  if (use_rword >= ivl_signal_array_count(rsig))
			return;
		  if (ivl_signal_type(rsig) == IVL_SIT_REG) {
			fprintf(stderr, "%s:%u: vvp.tgt sorry: procedural continuous "
				"assignments are not yet fully supported. The RHS of "
				"this assignment will only be evaluated once, at the "
				"time the assignment statement is executed.\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			return;
		  }
	    } else {
		  assert(ivl_signal_dimensions(rsig) == 0);
		  use_rword = 0;
	    }

	    note_array_signal_use(lsig);
	    fprintf(vvp_out, "    %%force/link/a v%p, v%p_%lu;\n",
		    lsig, rsig, use_rword);
	    return;
      }

	/* We do not currently support driving a signal to a bit or
	 * part select (this could give us multiple drivers). */
      part_off_ex = ivl_lval_part_off(lval);
	/* This should be verified in force_vector_to_lval() which is called
	 * before this procedure. */
      /* A force link uses the offset already evaluated by %force/vec4/off. */
      if (part_off_ex && ivl_statement_type(net) != IVL_ST_FORCE) {
	    assert(number_is_immediate(part_off_ex, IMM_WID, 0));
	    assert(! number_is_unknown(part_off_ex));
      }
      int partial_lval = part_off_ex
	  || ivl_lval_width(lval) != ivl_signal_width(lsig);
      if (ivl_statement_type(net) != IVL_ST_FORCE
	  && (ivl_signal_width(lsig) > ivl_signal_width(rsig)
	      || (part_off_ex && get_number_immediate(part_off_ex) != 0))) {
	      /* Normalize the bit/part select. This also needs to be
	       * reworked to support packed arrays. */
	    long real_msb = ivl_signal_packed_msb(lsig, 0);
	    long real_lsb = ivl_signal_packed_lsb(lsig, 0);
	    long use_wid = ivl_signal_width(rsig);
	    long use_lsb, use_msb;
	    if (ivl_signal_packed_dimensions(lsig) > 1) {
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s part of a "
		                  "packed array.\n",
		                  ivl_stmt_file(net), ivl_stmt_lineno(net),
		                  command_name);
	    }
	    if (real_msb >= real_lsb) {
		  use_lsb = get_number_immediate(part_off_ex);
		  use_lsb += real_lsb;
		  use_msb = use_lsb + use_wid - 1;
	    } else {
		  use_lsb = real_lsb;
		  use_lsb -= get_number_immediate(part_off_ex);
		  use_msb = use_lsb;
		  use_msb -= use_wid - 1;
	    }
	    fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s signal to a ",
	            ivl_stmt_file(net), ivl_stmt_lineno(net), command_name);
	    if (use_wid > 1) {
		  fprintf(stderr, "part select (%s[%ld:%ld]).\n",
		          ivl_signal_basename(lsig), use_msb, use_lsb);
	    } else {
		  fprintf(stderr, "bit select (%s[%ld]).\n",
		          ivl_signal_basename(lsig), use_lsb);
	    }
      }

	/* At least for now, only handle force to fixed words of an array. */
      if ((lword_idx = ivl_lval_idx(lval)) != 0) {
	    assert(number_is_immediate(lword_idx, IMM_WID, 0));
	      /* An out-of-range or undefined index will have been
		 converted to a canonical offset of 1'bx. Skip the
		 assignment in this case. */
	    if (number_is_unknown(lword_idx))
		  return;
	    use_lword = get_number_immediate(lword_idx);
	      /* We do not currently support using a word from a variable
	       * array as the L-value (SystemVerilog / Icarus extension). */
	    if (ivl_signal_type(lsig) == IVL_SIT_REG) {
		    /* Normalize the array access. */
		  long real_word = use_lword;
		  real_word += ivl_signal_array_base(lsig);
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s to the "
		          "word of a variable array (%s[%ld]).\n",
		          ivl_stmt_file(net), ivl_stmt_lineno(net),
		          command_name, ivl_signal_basename(lsig), real_word);
	          vvp_errors += 1;
	    }
      }

      if ((rword_idx = ivl_expr_oper1(rval)) != 0) {
	    assert(ivl_signal_dimensions(rsig) != 0);
	    if (!number_is_immediate(rword_idx, IMM_WID, 0)) {
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: procedural continuous "
			  "assignments are not yet fully supported. The RHS of "
			  "this assignment will only be evaluated once, at the "
			  "time the assignment statement is executed.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return;
	    }
	      /* An out-of-range or undefined index will have been
		 converted to a canonical offset of 1'bx. Skip the
		 assignment in this case. */
	    if (number_is_unknown(rword_idx))
		  return;
	    use_rword = get_number_immediate(rword_idx);
	      /* We do not currently support using a word from a variable
	       * array as the R-value. */
	    if (ivl_signal_type(rsig) == IVL_SIT_REG) {
		    /* Normalize the array access. */
		  long real_word = use_rword;
		  real_word += ivl_signal_array_base(rsig);
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot %s from the "
		          "word of a variable array (%s[%ld]).\n",
		          ivl_expr_file(rval), ivl_expr_lineno(rval),
		          command_name, ivl_signal_basename(rsig), real_word);
	          vvp_errors += 1;
	    }
      } else {
	    assert(ivl_signal_dimensions(rsig) == 0);
	    use_rword = 0;
      }

      fprintf(vvp_out, "    %s/link", command_name);
      if (ivl_statement_type(net) == IVL_ST_FORCE && partial_lval)
	    fprintf(vvp_out, "/off");
      fprintf(vvp_out, " v%p_%lu", lsig, use_lword);
      fprintf(vvp_out, ", v%p_%lu", rsig, use_rword);
      fprintf(vvp_out, ";\n");
}

/* Force RHS expressions are assignment-context sized by the elaborator, but
   a direct signal load still pushes the signal's physical storage width.
   Therefore ivl_expr_width(rval) cannot be used to decide that no resize is
   needed. Always normalize the actual vec4 stack entry to the selected
   l-value width; %pad/[su] truncates as well as extends. */
static void resize_force_vec4_wid_(ivl_expr_t rval, unsigned force_width)
{
      fprintf(vvp_out, ivl_expr_signed(rval)
	    ? "    %%pad/s %u; force RHS width\n"
	    : "    %%pad/u %u; force RHS width\n", force_width);
}

static int show_stmt_cassign(ivl_statement_t net)
{
      ivl_expr_t rval;
      ivl_signal_t sig;

      show_stmt_file_line(net, "Assign statement.");

      rval = ivl_stmt_rval(net);
      assert(rval);

      sig = ivl_lval_sig(ivl_stmt_lval(net, 0));
      if (sig && ivl_signal_data_type(sig) == IVL_VT_REAL) {

	    draw_eval_real(ivl_stmt_rval(net));
	    force_real_to_lval(net);

      } else {
	    unsigned force_width = 0;
	    for (unsigned idx = 0; idx < ivl_stmt_lvals(net); idx += 1)
		  force_width += ivl_lval_width(ivl_stmt_lval(net, idx));
	    assert(force_width > 0);

	    draw_eval_vec4(rval);
	      /* ivl_stmt_lwidth historically reports the containing signal width
	       * for a force part-select. The value stack must instead match the
	       * selected l-value width; otherwise a wider RHS overwrites adjacent
	       * bits and installs an over-wide live-force mask. */
	    resize_force_vec4_wid_(rval, force_width);

	      /* Write out initial continuous assign instructions to assign
	         the expression value to the l-value. */
	    force_vector_to_lval(net);
      }

      force_link_rval(net, rval);

      return 0;
}

/*
 * Handle the deassign similar to cassign. The lvals must all be
 * vectors without bit or part selects. Simply call %deassign for all
 * the values.
 */
static int show_stmt_deassign(ivl_statement_t net)
{
      ivl_signal_t sig = ivl_lval_sig(ivl_stmt_lval(net, 0));
      unsigned lidx;

      show_stmt_file_line(net, "Deassign statement.");

      if (sig && ivl_signal_data_type(sig) == IVL_VT_REAL) {
	    ivl_lval_t lval;

	    assert(ivl_stmt_lvals(net) == 1);
	    lval = ivl_stmt_lval(net, 0);
	    assert(ivl_lval_width(lval) == 1);
	    assert(ivl_lval_part_off(lval) == 0);

	    ivl_expr_t word_idx = ivl_lval_idx(lval);
	    unsigned long use_word = 0;
	    if (word_idx != 0) {
		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		    /* An out-of-range or undefined index will have been
		       converted to a canonical offset of 1'bx. Skip the
		       deassignment in this case. */
		  if (number_is_unknown(word_idx))
			return 0;
		  use_word = get_number_immediate(word_idx);
	    }

	    fprintf(vvp_out, "    %%deassign/wr v%p_%lu;\n", sig, use_word);
	    return 0;
      }

      for (lidx = 0 ;  lidx < ivl_stmt_lvals(net) ;  lidx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, lidx);
	    ivl_signal_t lsig = ivl_lval_sig(lval);

	    ivl_expr_t word_idx = ivl_lval_idx(lval);
	    unsigned long use_word = 0;
	    unsigned use_wid;
	    ivl_expr_t part_off_ex;
	    unsigned part_off;

	    assert(lsig != 0);

	    use_wid = ivl_lval_width(lval);
	    part_off_ex = ivl_lval_part_off(lval);
	    part_off = 0;
	    if (part_off_ex != 0) {
		  assert(number_is_immediate(part_off_ex, 64, 0));
		  if (number_is_unknown(part_off_ex))
			return 0;
		  part_off = get_number_immediate(part_off_ex);
	    }

	    if (word_idx != 0) {
		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		    /* An out-of-range or undefined index will have been
		       converted to a canonical offset of 1'bx. Skip the
		       deassignment in this case. */
		  if (number_is_unknown(word_idx))
			return 0;
		  use_word = get_number_immediate(word_idx);
	    }


	    fprintf(vvp_out, "    %%deassign v%p_%lu, %u, %u;\n",
		    lsig, use_word, part_off, use_wid);
      }

      return 0;
}

static int show_stmt_condit(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      unsigned lab_false, lab_out;
      ivl_expr_t expr = ivl_stmt_cond_expr(net);

      show_stmt_file_line(net, "If statement.");

      lab_false = local_count++;
      lab_out = local_count++;

      int use_flag = draw_eval_condition(expr);
      fprintf(vvp_out, "    %%jmp/0xz  T_%u.%u, %d;\n",
	      thread_count, lab_false, use_flag);
      clr_flag(use_flag);

      if (ivl_stmt_cond_true(net))
	    rc += show_statement(ivl_stmt_cond_true(net), sscope);


      if (ivl_stmt_cond_false(net)) {
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_false);

	    rc += show_statement(ivl_stmt_cond_false(net), sscope);

	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_out);

      } else {
	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, lab_false);
      }

      return rc;
}

/*
 * The delay statement is easy. Simply write a ``%delay <n>''
 * instruction to delay the thread, then draw the included statement.
 * The delay statement comes from Verilog code like this:
 *
 *        ...
 *        #<delay> <stmt>;
 */
static int show_stmt_delay(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      uint64_t delay = ivl_stmt_delay_val(net);
      ivl_statement_t stmt = ivl_stmt_sub_stmt(net);

      unsigned long low = delay % UINT64_C(0x100000000);
      unsigned long hig = delay / UINT64_C(0x100000000);

      show_stmt_file_line(net, "Delay statement.");

      fprintf(vvp_out, "    %%delay %lu, %lu;\n", low, hig);

      rc += show_statement(stmt, sscope);

      return rc;
}

void draw_expr_into_idx(ivl_expr_t expr, int use_idx)
{
      switch (ivl_expr_value(expr)) {

	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC: {
		draw_eval_vec4(expr);
		fprintf(vvp_out, "    %%ix/vec4 %d;\n", use_idx);
		break;
	  }

	  case IVL_VT_REAL: {
		draw_eval_real(expr);
		fprintf(vvp_out, "    %%cvt/ur %d;\n", use_idx);
		break;
	  }

	  default:
	    assert(0);
      }
}


/*
 * The delayx statement is slightly more complex in that it is
 * necessary to calculate the delay first. Load the calculated delay
 * into and index register and use the %delayx instruction to do the
 * actual delay.
 */
static int show_stmt_delayx(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      ivl_expr_t expr = ivl_stmt_delay_expr(net);
      ivl_statement_t stmt = ivl_stmt_sub_stmt(net);

      show_stmt_file_line(net, "Delay statement.");

      int use_idx = allocate_word();
      draw_expr_into_idx(expr, use_idx);

      fprintf(vvp_out, "    %%delayx %d;\n", use_idx);
      clr_word(use_idx);

      rc += show_statement(stmt, sscope);
      return rc;
}

static void publish_materialized_return(ivl_scope_t scope)
{
      ivl_signal_t sig;
      if (ivl_scope_type(scope) != IVL_SCT_FUNCTION || ivl_scope_ports(scope) == 0)
	    return;
      sig = ivl_scope_port(scope, 0);
      if (!signal_is_materialized_return(sig))
	    return;
      fprintf(vvp_out, "    %%load/vec4 v%p_0;\n", sig);
      fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", ivl_signal_width(sig));
}

static int scope_has_internal_attribute_(ivl_scope_t scope, const char*name)
{
      unsigned idx;
      for (idx = 0; idx < ivl_scope_attr_cnt(scope); idx += 1) {
	    ivl_attribute_t attr = ivl_scope_attr_val(scope, idx);
	    if (attr && strcmp(attr->key, name) == 0
		&& attr->type == IVL_ATT_NUM && attr->val.num != 0)
		  return 1;
      }
      return 0;
}

static int show_stmt_disable(ivl_statement_t net, ivl_scope_t sscope)
{
      int rc = 0;
      ivl_scope_t target = ivl_stmt_call(net);

      (void)sscope; /* Parameter is not used. */

	/* A normal disable statement. */
      if (target) {
	    if (ivl_stmt_flow_control(net)) {
		  publish_materialized_return(target);
		  show_stmt_file_line(net, "Flow control disable statement.");
		  fprintf(vvp_out, "    %%disable/flow S_%p;\n", target);
	    } else {
		  if (scope_has_internal_attribute_(target,
			    "_ivl_deferred_assert_label"))
			fprintf(vvp_out,
				"    %%defer/cancel/label S_%p;\n", target);
		  else if (scope_has_internal_attribute_(target,
			       "_ivl_deferred_process_scope"))
			fprintf(vvp_out,
				"    %%defer/cancel/process S_%p;\n", target);
		  show_stmt_file_line(net, "Disable statement.");
		  fprintf(vvp_out, "    %%disable S_%p;\n", target);
	    }
	/* A SystemVerilog disable fork statement. */
      } else {
	    show_stmt_file_line(net, "Disable fork statement.");
	    fprintf(vvp_out, "    %%disable/fork;\n");
      }

      return rc;
}

static int show_stmt_force(ivl_statement_t net)
{
      ivl_expr_t rval;
      ivl_signal_t sig;

      show_stmt_file_line(net, "Force statement.");

      rval = ivl_stmt_rval(net);
      assert(rval);

      sig = ivl_lval_sig(ivl_stmt_lval(net, 0));
      if (sig && ivl_signal_data_type(sig) == IVL_VT_REAL) {

            draw_eval_real(ivl_stmt_rval(net));
            emit_force_release_identity(net, 1);
            force_real_to_lval(net);
            emit_force_release_identity_end();

      } else {
	    unsigned force_width = 0;
	    for (unsigned idx = 0; idx < ivl_stmt_lvals(net); idx += 1)
		  force_width += ivl_lval_width(ivl_stmt_lval(net, idx));
	    assert(force_width > 0);

            draw_eval_vec4(rval);
	    resize_force_vec4_wid_(rval, force_width);

              /* Write out initial continuous assign instructions to assign
                 the expression value to the l-value. */
            emit_force_release_identity(net, 1);
            force_vector_to_lval(net);
            emit_force_release_identity_end();
      }

      force_link_rval(net, ivl_stmt_force_link_rval(net));

      return 0;
}

/* A detaching fork (join_none/join_any) of an automatic task/function call
 * must evaluate the call arguments at SPAWN time, capturing the current
 * value of any enclosing automatic locals (e.g. a per-iteration loop
 * variable). iverilog otherwise emits the whole wrapped call — %alloc of
 * the callee frame, the argument stores, the call, %free — inside the
 * detached thread, so the argument stores run when the thread is later
 * scheduled and read the LAST value the shared automatic held, not the
 * value at the fork (IEEE 1800-2017 9.3.2).
 *
 * When a forked child has the exact wrapped-auto-call shape
 * [ %alloc, <arg stores>, <call>, (%free) ] we hoist the prefix
 * (%alloc + the argument stores, everything up to the call) out to run in
 * the spawning thread before the %fork, and leave only the call and its
 * %free in the detached thread. The callee frame is allocated before the
 * detach exactly as the fork thread's own frame already is, so the binding
 * survives. Returns the index of the call statement within the child
 * block (the split point), or -1 if the child is not a hoistable wrapped
 * call (in which case it is emitted whole, unchanged). */
static int fork_child_hoist_split_(ivl_statement_t child)
{
      if (ivl_statement_type(child) != IVL_ST_BLOCK)
	    return -1;
	/* A named block introduces its own scope/frame; don't disturb it. */
      if (ivl_stmt_block_scope(child) != 0)
	    return -1;
      unsigned n = ivl_stmt_block_count(child);
      if (n < 2)
	    return -1;
      if (ivl_statement_type(ivl_stmt_block_stmt(child, 0)) != IVL_ST_ALLOC)
	    return -1;

      int call_idx = -1;
      for (unsigned i = 0 ; i < n ; i += 1) {
	    ivl_statement_type_t t =
		  ivl_statement_type(ivl_stmt_block_stmt(child, i));
	    if (t == IVL_ST_UTASK) {
		  if (call_idx >= 0)
			return -1; /* more than one call: not a simple wrap */
		  call_idx = (int)i;
	    }
      }
      if (call_idx <= 0)
	    return -1;

	/* Everything before the call must be only frame setup and argument
	   stores (%alloc / blocking assigns). Anything else (control flow,
	   waits, side effects) must stay in the detached thread. */
      for (int i = 0 ; i < call_idx ; i += 1) {
	    ivl_statement_type_t t =
		  ivl_statement_type(ivl_stmt_block_stmt(child, i));
	    if (t != IVL_ST_ALLOC && t != IVL_ST_ASSIGN)
		  return -1;
      }
	/* After the call, only a %free of the callee frame is expected. */
      for (unsigned i = (unsigned)call_idx + 1 ; i < n ; i += 1) {
	    if (ivl_statement_type(ivl_stmt_block_stmt(child, i)) != IVL_ST_FREE)
		  return -1;
      }
      return call_idx;
}

static int show_stmt_fork(ivl_statement_t net, ivl_scope_t sscope)
{
      unsigned idx;
      int rc = 0;
      unsigned join_count = ivl_stmt_block_count(net);
      unsigned join_detach_count = 0;
      ivl_scope_t scope = ivl_stmt_block_scope(net);
      int is_named = (scope != 0);

      unsigned out = transient_id++;
      unsigned id_base = transient_id;

	/* Increment the number of IDs needed before the join count is
	 * modified by the join_any or join_none code below. */
      transient_id += join_count;

      switch (ivl_statement_type(net)) {
	  case IVL_ST_FORK:
	    break;
	  case IVL_ST_FORK_JOIN_ANY:
	    if (join_count < 2)
		  break;
	    join_detach_count = join_count - 1;
	    join_count = 1;
	    break;
	  case IVL_ST_FORK_JOIN_NONE:
	    join_detach_count = join_count;
	    join_count = 0;
	    break;
	  default:
	    assert(0);
      }

      if (scope==0)
	    scope = sscope;

	/* Detaching forks (join_none/join_any) capture automatic-call
	   arguments at spawn: hoist each hoistable child's %alloc + argument
	   stores to run in the spawning thread, with the current values of
	   the enclosing automatics, immediately BEFORE that child's own
	   %fork. The remaining call (+ %free) is emitted in the detached
	   thread below.

	   The prefix must be interleaved with its own %fork, not batched
	   ahead of all forks: the callee frame binding is captured by the
	   spawning thread's context at %fork time, so a second %alloc of the
	   same callee scope (another child, or a later iteration) before the
	   %fork would clobber it. */
	/* Restrict the spawn-time argument capture to a SINGLE-branch
	   join_none. That is the pattern with the real hazard — a
	   `fork task(<loop automatic>); join_none` re-executed each loop
	   iteration, where the detached branch outlives the iteration and
	   must snapshot the automatic at spawn. A join_any/join blocks the
	   parent on a %join; a multi-branch fork would %alloc the same callee
	   scope more than once before its %fork consumes the binding, and the
	   allocations collide. Those forms keep the original (whole-child)
	   lowering. */
      bool is_detaching = (ivl_statement_type(net) == IVL_ST_FORK_JOIN_NONE)
	    && ((join_count + join_detach_count) == 1);
      int *child_split = calloc(join_count + join_detach_count, sizeof(int));

	/* Draw a fork statement for all but one of the threads of the
	   fork/join. Send the threads off to a bit of code where they
	   are implemented. */
      for (idx = 0 ;  idx < (join_count+join_detach_count) ;  idx += 1) {
	    ivl_statement_t child = ivl_stmt_block_stmt(net, idx);
	    int split = is_detaching ? fork_child_hoist_split_(child) : -1;
	    child_split[idx] = split;
	    for (int j = 0 ; j < split ; j += 1)
		  rc += show_statement(ivl_stmt_block_stmt(child, j), scope);
	      /* %fork/p, not %fork: a branch is its own PROCESS (9.7).
	         An anonymous branch is compiled with the ENCLOSING scope,
	         so the runtime cannot tell it from a task-call or
	         begin-frame wrapper by scope type -- inside a task body
	         every branch looked like the task frame itself, and
	         process::self() in the branch answered with the caller's
	         handle. Say it explicitly instead. */
	    fprintf(vvp_out, "    %%fork/p t_%u, S_%p;\n",
		    id_base+idx, scope);
      }


	/* Generate enough joins to collect all the sub-threads. */
      for (idx = 0 ;  idx < join_count ;  idx += 1)
	    fprintf(vvp_out, "    %%join;\n");
      if (join_detach_count > 0)
	    fprintf(vvp_out, "    %%join/detach %u;\n", join_detach_count);
	/* Jump around all the threads that I'm creating. */
      fprintf(vvp_out, "    %%jmp t_%u;\n", out);

	/* Change the compiling scope to be the named forks scope. */
      if (is_named) fprintf(vvp_out, "    .scope S_%p;\n", scope);
	/* Generate the sub-threads themselves. For a hoisted child, only
	   the call and its %free remain here; its %alloc + argument stores
	   were already emitted above, before the %fork. */
      for (idx = 0 ;  idx < (join_count + join_detach_count) ;  idx += 1) {
	    ivl_statement_t child = ivl_stmt_block_stmt(net, idx);
	    fprintf(vvp_out, "t_%u ;\n", id_base+idx);
	    if (child_split[idx] >= 0) {
		  unsigned n = ivl_stmt_block_count(child);
		  for (unsigned j = (unsigned)child_split[idx] ; j < n ; j += 1)
			rc += show_statement(ivl_stmt_block_stmt(child, j), scope);
	    } else {
		  rc += show_statement(child, scope);
	    }
	    fprintf(vvp_out, "    %%end;\n");
      }
      free(child_split);
	/* Return to the previous scope. */
      if (sscope) fprintf(vvp_out, "    .scope S_%p;\n", sscope);

	/* This is the label for the out. Use this to branch around
	   the implementations of all the child threads. */
      fprintf(vvp_out, "t_%u ;\n", out);

      return rc;
}

static int show_stmt_free(ivl_statement_t net, ivl_scope_t sscope)
{
      ivl_scope_t scope = ivl_stmt_call(net);

      fprintf(vvp_out, "    %%free S_%p;\n", scope);
      if (ivl_scope_type(scope) == IVL_SCT_BEGIN
	  || ivl_scope_type(scope) == IVL_SCT_FORK)
	    draw_nested_flow_dispatch(sscope);
      return 0;
}

/*
 * noop statements are implemented by doing nothing.
 */
static int show_stmt_noop(ivl_statement_t net)
{
      (void)net; /* Parameter is not used. */
      return 0;
}

static int show_stmt_release(ivl_statement_t net)
{
      ivl_signal_t sig = ivl_lval_sig(ivl_stmt_lval(net, 0));
      unsigned lidx;

      show_stmt_file_line(net, "Release statement.");
      emit_force_release_identity(net, 0);

      if (sig && ivl_signal_data_type(sig) == IVL_VT_REAL) {
	    unsigned type = 0;
	    ivl_lval_t lval;

	    assert(ivl_stmt_lvals(net) == 1);
	    lval = ivl_stmt_lval(net, 0);
	    assert(ivl_lval_width(lval) == 1);
	    assert(ivl_lval_part_off(lval) == 0);

	    ivl_expr_t word_idx = ivl_lval_idx(lval);
	    unsigned long use_word = 0;
	    if (word_idx != 0) {
		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		    /* An out-of-range or undefined index will have been
		       converted to a canonical offset of 1'bx. Skip the
		       deassignment in this case. */
		  if (number_is_unknown(word_idx))
			goto force_release_done;
		  use_word = get_number_immediate(word_idx);
	    }

	    if (ivl_signal_type(sig) == IVL_SIT_REG) type = 1;

	    fprintf(vvp_out, "    %%release/wr v%p_%lu, %u;\n",
		    sig, use_word, type);
	    goto force_release_done;
      }

      for (lidx = 0 ;  lidx < ivl_stmt_lvals(net) ;  lidx += 1) {
	    ivl_lval_t lval = ivl_stmt_lval(net, lidx);
	    ivl_signal_t lsig = ivl_lval_sig(lval);
	    const char*opcode = 0;

	    ivl_expr_t word_idx = ivl_lval_idx(lval);
	    unsigned long use_word = 0;
	    unsigned use_wid;
	    ivl_expr_t part_off_ex;
	    unsigned part_off;
	    int dynamic_part_off = 0;

	    assert(lsig != 0);

	    use_wid = ivl_lval_width(lval);

	      /* Static variable arrays use compact array storage, so release
		 must address the array itself instead of a nonexistent per-word
		 functor. Net arrays retain the path below. */
	    if (word_idx != 0 && ivl_signal_type(lsig) == IVL_SIT_REG
		&& force_array_is_vec4_(lsig)) {
		  int off_index;
		  int width_index;

		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		  if (number_is_unknown(word_idx))
			goto force_release_done;
		  use_word = get_number_immediate(word_idx);
		  if (use_word >= ivl_signal_array_count(lsig))
			goto force_release_done;

		  if (force_array_is_automatic_(lsig)) {
			fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot release an "
				"automatic variable array (%s[%ld]).\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net),
				ivl_signal_basename(lsig),
				ivl_signal_array_base(lsig) + (long)use_word);
			vvp_errors += 1;
			goto force_release_done;
		  }

		  if (!prepare_force_array_lval_(lval, &off_index))
			goto force_release_done;

		  width_index = allocate_word();
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0; release array width\n",
		          width_index, use_wid);
		  note_array_signal_use(lsig);
		  fprintf(vvp_out, "    %%release/reg/a v%p, %d, %d;\n",
		          lsig, off_index, width_index);
		  if (off_index != 0)
			clr_word(off_index);
		  clr_word(width_index);
		  continue;
	    }

	    if (word_idx != 0 && ivl_signal_type(lsig) == IVL_SIT_REG
		&& !force_array_is_vec4_(lsig)) {
		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		  if (number_is_unknown(word_idx))
			goto force_release_done;
		  use_word = get_number_immediate(word_idx);
		  fprintf(stderr, "%s:%u: vvp.tgt sorry: cannot release a word "
			  "of a non-integral variable array (%s[%ld]).\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net),
			  ivl_signal_basename(lsig),
			  ivl_signal_array_base(lsig) + (long)use_word);
		  vvp_errors += 1;
		  goto force_release_done;
	    }

	    part_off_ex = ivl_lval_part_off(lval);
	    part_off = 0;
	    if (part_off_ex != 0) {
		  if (number_is_immediate(part_off_ex, 64, 0)) {
			    /* An out-of-range or undefined offset will have been
			       converted to a canonical offset of 1'bx. Skip the
			       assignment in this case. */
			if (number_is_unknown(part_off_ex))
			      goto force_release_done;
			part_off = get_number_immediate(part_off_ex);
		  } else {
			dynamic_part_off = 1;
		  }
	    }

	    switch (ivl_signal_type(lsig)) {
		case IVL_SIT_REG:
		  opcode = "reg";
		  break;
		default:
		  opcode = "net";
		  break;
	    }

	    if (word_idx != 0) {
		  assert(number_is_immediate(word_idx, IMM_WID, 0));
		    /* An out-of-range or undefined index will have been
		       converted to a canonical offset of 1'bx. Skip the
		       assignment in this case. */
		  if (number_is_unknown(word_idx))
			goto force_release_done;
		  use_word = get_number_immediate(word_idx);
	    }

	      /* Generate the appropriate release statement for this
		 l-value. */
	    if (dynamic_part_off) {
		  int off_index = allocate_word();
		  draw_eval_expr_into_integer(part_off_ex, off_index);
		  fprintf(vvp_out, "    %%release/%s/off v%p_%lu, %d, %u;\n",
			  opcode, lsig, use_word, off_index, use_wid);
		  clr_word(off_index);
	    } else {
		  fprintf(vvp_out, "    %%release/%s v%p_%lu, %u, %u;\n",
			  opcode, lsig, use_word, part_off, use_wid);
	    }
      }

force_release_done:
      emit_force_release_identity_end();
      return 0;
}

/*
 * The trigger statement is straight forward. All we have to do is
 * write a single bit of fake data to the event object.
 */
static int show_stmt_trigger(ivl_statement_t net)
{
      ivl_event_t ev = ivl_stmt_events(net, 0);
      assert(ev);

      show_stmt_file_line(net, "Event trigger statement.");

      fprintf(vvp_out, "    %%event E_%p;\n", ev);
      return 0;
}

/*
 * The non-blocking trigger statement is straight forward. All we have to
 * do is write a single bit of fake data to the event object.
 */
static int show_stmt_nb_trigger(ivl_statement_t net)
{
      ivl_event_t ev = ivl_stmt_events(net, 0);
      assert(ev);

      show_stmt_file_line(net, "Non-blocking event trigger statement.");

      ivl_expr_t expr = ivl_stmt_delay_expr(net);
      int use_idx = allocate_word();
      if (expr) {
	    draw_expr_into_idx(expr, use_idx);
      } else {
	    fprintf(vvp_out, "    %%ix/load %d, 0, 0;\n", use_idx);
      }

      fprintf(vvp_out, "    %%event/nb E_%p, %d;\n", ev, use_idx);
      clr_word(use_idx);
	/* %event/nb schedules the trigger through
	 * schedule_propagate_event() in the SEQ_NBASSIGN region
	 * (IEEE 1800-2017 15.5.1: the nonblocking trigger takes
	 * effect in the NBA region of the target time step). */
      return 0;
}

/*
 * Per-instance class event trigger (IEEE 1800-2017 15.5.1):
 * `->obj.ev` (IVL_ST_TRIGGER_OBJ) or `->>obj.ev` (IVL_ST_NB_TRIGGER_OBJ).
 * Push the object handle with draw_eval_object, then emit the object
 * trigger opcode carrying the per-class event slot; the runtime resolves
 * the object's private event and triggers only its waiters.
 */
static int show_stmt_trigger_obj(ivl_statement_t net)
{
      unsigned slot = ivl_stmt_evobj_slot(net);
      int is_nb = (ivl_statement_type(net) == IVL_ST_NB_TRIGGER_OBJ);

      show_stmt_file_line(net, "Per-instance class event trigger.");

      draw_eval_object(ivl_stmt_evobj_expr(net));

      if (is_nb) {
	    ivl_expr_t expr = ivl_stmt_delay_expr(net);
	    int use_idx = allocate_word();
	    if (expr)
		  draw_expr_into_idx(expr, use_idx);
	    else
		  fprintf(vvp_out, "    %%ix/load %d, 0, 0;\n", use_idx);
	    fprintf(vvp_out, "    %%evt/obj/nb %u, %d;\n", slot, use_idx);
	    clr_word(use_idx);
      } else {
	    fprintf(vvp_out, "    %%evt/obj %u;\n", slot);
      }
      return 0;
}

/*
 * Per-instance class event wait (IEEE 1800-2017 15.5): `@(obj.ev)`.
 * Push the object handle, emit the object wait opcode with the event
 * slot, then draw the guarded sub-statement.
 */
static int show_stmt_wait_obj(ivl_statement_t net, ivl_scope_t sscope)
{
      unsigned slot = ivl_stmt_evobj_slot(net);

      show_stmt_file_line(net, "Per-instance class event wait (@).");

      draw_eval_object(ivl_stmt_evobj_expr(net));
      fprintf(vvp_out, "    %%wait/obj %u;\n", slot);

      return show_statement(ivl_stmt_sub_stmt(net), sscope);
}

/*
 * Named-event array element trigger (IEEE 1800-2017 6.20): `->arr[i]`
 * (IVL_ST_TRIGGER_ARR) or `->>arr[i]` (IVL_ST_NB_TRIGGER_ARR). Evaluate
 * the index into a register, then emit the array trigger opcode
 * carrying the array's base slot and element count; the runtime adds
 * the (bounds-checked) index to the base slot to find the element's
 * private event.
 */
static int show_stmt_trigger_arr(ivl_statement_t net)
{
      unsigned base = ivl_stmt_evarr_base(net);
      unsigned count = ivl_stmt_evarr_count(net);
      uint64_t packed = ((uint64_t)base << 32) | (uint64_t)count;
      int is_nb = (ivl_statement_type(net) == IVL_ST_NB_TRIGGER_ARR);

      show_stmt_file_line(net, "Named-event array element trigger.");

      int use_idx = allocate_word();
      draw_expr_into_idx(ivl_stmt_evarr_index(net), use_idx);

      if (is_nb) {
	    ivl_expr_t expr = ivl_stmt_delay_expr(net);
	    int use_dly = allocate_word();
	    if (expr)
		  draw_expr_into_idx(expr, use_dly);
	    else
		  fprintf(vvp_out, "    %%ix/load %d, 0, 0;\n", use_dly);
	    fprintf(vvp_out, "    %%evt/arr/nb %" PRIu64 ", %d, %d;\n",
		    packed, use_idx, use_dly);
	    clr_word(use_dly);
      } else {
	    fprintf(vvp_out, "    %%evt/arr %" PRIu64 ", %d;\n",
		    packed, use_idx);
      }
      clr_word(use_idx);
      return 0;
}

/*
 * Named-event array element wait (IEEE 1800-2017 6.20): `@(arr[i])`.
 * Evaluate the index into a register, emit the array wait opcode, then
 * draw the guarded sub-statement.
 */
static int show_stmt_wait_arr(ivl_statement_t net, ivl_scope_t sscope)
{
      unsigned base = ivl_stmt_evarr_base(net);
      unsigned count = ivl_stmt_evarr_count(net);
      uint64_t packed = ((uint64_t)base << 32) | (uint64_t)count;

      show_stmt_file_line(net, "Named-event array element wait (@).");

      int use_idx = allocate_word();
      draw_expr_into_idx(ivl_stmt_evarr_index(net), use_idx);
      fprintf(vvp_out, "    %%wait/arr %" PRIu64 ", %d;\n",
	      packed, use_idx);
      clr_word(use_idx);

      return show_statement(ivl_stmt_sub_stmt(net), sscope);
}

/*
 * A final-deferred user-task action is emitted out of line between two
 * internal marker statements. Keep enough state while drawing that small
 * source block to prove that exactly one resolved task call is enclosed and
 * that no generated statement escapes the bounded passive thunk.
 */
struct deferred_final_task_frame_s {
      int active;
      int phase; /* 0: before call, 1: after call, 2: rejected */
      int saw_alloc;
      int saw_free;
      long source_id;
      unsigned action_lab;
      unsigned after_lab;
      ivl_scope_t action_scope;
      ivl_scope_t task_scope;
      ivl_scope_t alloc_scope;
};

static struct deferred_final_task_frame_s deferred_final_task_frame_;

static int deferred_final_task_is_method_(ivl_scope_t task)
{
      ivl_scope_t cur;
      for (cur = ivl_scope_parent(task); cur; cur = ivl_scope_parent(cur)) {
            ivl_scope_type_t type = ivl_scope_type(cur);
            if (type == IVL_SCT_CLASS)
                  return 1;
            if (type == IVL_SCT_MODULE || type == IVL_SCT_PACKAGE)
                  return 0;
      }
      return 0;
}

/* A display/error operand may read state, but it must not hide a function
 * call, allocation, or other side effect. This conservative expression walk
 * is deliberately narrower than ordinary VPI argument lowering. */
static int deferred_final_task_passive_expr_(ivl_expr_t expr)
{
      unsigned idx;
      if (!expr)
            return 1;

      switch (ivl_expr_type(expr)) {
          case IVL_EX_ARRAY:
          case IVL_EX_ARRAY_SLICE:
          case IVL_EX_BACCESS:
          case IVL_EX_ENUMTYPE:
          case IVL_EX_EVENT:
          case IVL_EX_NULL:
          case IVL_EX_NUMBER:
          case IVL_EX_REALNUM:
          case IVL_EX_SCOPE:
          case IVL_EX_STRING:
          case IVL_EX_ULONG:
            return 1;

          case IVL_EX_SIGNAL:
          case IVL_EX_MEMORY:
            return deferred_final_task_passive_expr_(ivl_expr_oper1(expr));

          case IVL_EX_PROPERTY:
          case IVL_EX_SELECT:
          case IVL_EX_BINARY:
            return deferred_final_task_passive_expr_(ivl_expr_oper1(expr))
                && deferred_final_task_passive_expr_(ivl_expr_oper2(expr));

          case IVL_EX_UNARY:
            return deferred_final_task_passive_expr_(ivl_expr_oper1(expr));

          case IVL_EX_TERNARY:
            return deferred_final_task_passive_expr_(ivl_expr_oper1(expr))
                && deferred_final_task_passive_expr_(ivl_expr_oper2(expr))
                && deferred_final_task_passive_expr_(ivl_expr_oper3(expr));

          case IVL_EX_ARRAY_PATTERN:
          case IVL_EX_CONCAT:
            for (idx = 0; idx < ivl_expr_parms(expr); idx += 1)
                  if (!deferred_final_task_passive_expr_(
                            ivl_expr_parm(expr, idx)))
                        return 0;
            return 1;

          case IVL_EX_DELAY:
          case IVL_EX_NEW:
          case IVL_EX_SFUNC:
          case IVL_EX_SHALLOWCOPY:
          case IVL_EX_UFUNC:
          case IVL_EX_NONE:
            return 0;
      }
      return 0;
}

static int deferred_final_task_passive_body_(ivl_statement_t stmt,
                                              const char**reason)
{
      unsigned idx;
      const char*name;
      if (!stmt)
            return 1;

      switch (ivl_statement_type(stmt)) {
          case IVL_ST_NOOP:
            return 1;

          case IVL_ST_BLOCK:
            /* A named begin is itself lowered through fork/join. Keep the
             * first slice linear and accept only an unnamed sequential list. */
            if (ivl_stmt_block_scope(stmt)) {
                  *reason = "a named block";
                  return 0;
            }
            for (idx = 0; idx < ivl_stmt_block_count(stmt); idx += 1)
                  if (!deferred_final_task_passive_body_(
                            ivl_stmt_block_stmt(stmt, idx), reason))
                        return 0;
            return 1;

          case IVL_ST_STASK:
            name = ivl_stmt_name(stmt);
            if (strcmp(name, "$display") != 0
                && strcmp(name, "$error") != 0) {
                  *reason = "a system task other than $display/$error";
                  return 0;
            }
            for (idx = 0; idx < ivl_stmt_parm_count(stmt); idx += 1)
                  if (!deferred_final_task_passive_expr_(
                            ivl_stmt_parm(stmt, idx))) {
                        *reason = "a side-effecting display/error argument";
                        return 0;
                  }
            return 1;

          case IVL_ST_UTASK:
            *reason = "a nested user-subroutine call";
            return 0;

          case IVL_ST_DELAY:
          case IVL_ST_DELAYX:
          case IVL_ST_WAIT:
          case IVL_ST_DO_WHILE:
          case IVL_ST_FOREVER:
          case IVL_ST_FORLOOP:
          case IVL_ST_REPEAT:
          case IVL_ST_WHILE:
            *reason = "timing or iterative control";
            return 0;

          case IVL_ST_FORK:
          case IVL_ST_FORK_JOIN_ANY:
          case IVL_ST_FORK_JOIN_NONE:
            *reason = "parallel control";
            return 0;

          case IVL_ST_ASSIGN:
          case IVL_ST_ASSIGN_NB:
          case IVL_ST_CASSIGN:
          case IVL_ST_DEASSIGN:
          case IVL_ST_FORCE:
          case IVL_ST_RELEASE:
          case IVL_ST_TRIGGER:
          case IVL_ST_NB_TRIGGER:
          case IVL_ST_TRIGGER_OBJ:
          case IVL_ST_NB_TRIGGER_OBJ:
          case IVL_ST_TRIGGER_ARR:
          case IVL_ST_NB_TRIGGER_ARR:
            *reason = "a state-mutating statement";
            return 0;

          default:
            *reason = "a statement outside the passive whitelist";
            return 0;
      }
}

static int deferred_final_task_validate_(ivl_statement_t net,
                                         ivl_scope_t task)
{
      const char*reason = 0;
      if (!task || ivl_scope_type(task) != IVL_SCT_TASK) {
            reason = "the resolved subroutine is not a task";
      } else if (deferred_final_task_is_method_(task)
                 || ivl_scope_is_virtual_method(task)) {
            reason = "class/interface method calls are outside this slice";
      } else if (ivl_scope_ports(task) != 0) {
            reason = "the resolved task has formal arguments";
      } else if (ivl_scope_is_dpi_import(task)) {
            reason = "DPI task calls are outside this slice";
      } else if (!ivl_scope_def(task)) {
            reason = "the resolved task has no SystemVerilog body";
      } else if (!deferred_final_task_passive_body_(ivl_scope_def(task),
                                                    &reason)) {
            /* The recursive validator supplied the first rejected shape. */
      } else {
            return 1;
      }

      fprintf(stderr,
              "%s:%u: sorry: final-deferred user-task action is not "
              "supported yet because %s; only a zero-argument direct task "
              "with an unnamed sequential/noop body containing passive "
              "$display/$error calls is supported.\n",
              ivl_stmt_file(net), ivl_stmt_lineno(net),
              reason ? reason : "its resolved shape is unsupported");
      vvp_errors += 1;
      return 0;
}

static int show_stmt_utask(ivl_statement_t net)
{
      ivl_scope_t task = ivl_stmt_call(net);

      if (deferred_final_task_frame_.active) {
            if (deferred_final_task_frame_.phase != 0) {
                  fprintf(stderr,
                          "%s:%u: error: malformed internal final-deferred "
                          "user-task thunk contains more than one call.\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net));
                  vvp_errors += 1;
                  deferred_final_task_frame_.phase = 2;
                  return 1;
            }
            if (!deferred_final_task_validate_(net, task)) {
                  deferred_final_task_frame_.phase = 2;
                  return 1;
            }
            if (deferred_final_task_frame_.saw_alloc
                && deferred_final_task_frame_.alloc_scope != task) {
                  fprintf(stderr,
                          "%s:%u: error: malformed internal final-deferred "
                          "user-task thunk allocates a different scope from "
                          "the resolved task.\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net));
                  vvp_errors += 1;
                  deferred_final_task_frame_.phase = 2;
                  return 1;
            }
            deferred_final_task_frame_.phase = 1;
            deferred_final_task_frame_.task_scope = task;
      } else {
            show_stmt_file_line(net, "User task call.");
      }

      /* Use virtual dispatch (/v suffix) only for virtual methods or
         when calling through an object whose static type may differ from
         the dynamic type (i.e. the method is declared virtual). Super
         calls always use static dispatch. */
      int use_virtual = !ivl_stmt_is_super_call(net)
                        && ivl_scope_is_virtual_method(task);
      if (ivl_scope_type(task) == IVL_SCT_FUNCTION) {
	    const char*target = vvp_mangle_id(ivl_scope_name(task));
	    note_td_reference(target);
	      // A function called as a task is (presumably) a void function.
	      // Use the %callf/void instruction to call it.
	    fprintf(vvp_out, "    %%callf/void%s TD_%s",
		    use_virtual ? "/v" : "", target);
	    fprintf(vvp_out, ", S_%p;\n", task);
      } else {
	    const char*target = vvp_mangle_id(ivl_scope_name(task));
	    note_td_reference(target);
	    fprintf(vvp_out, "    %%fork%s TD_%s",
		    use_virtual ? "/v" : "", target);
	    fprintf(vvp_out, ", S_%p;\n", task);
	    fprintf(vvp_out, "    %%join;\n");
      }

      return 0;
}

typedef struct event_expr_capture_s {
      ivl_expr_t expr;
      unsigned slot;
      int object;
      struct event_expr_capture_s*next;
} event_expr_capture_t;

static event_expr_capture_t*event_expr_captures_ = 0;
static int event_expr_capturing_ = 0;

static unsigned event_expr_capture_slot_(ivl_expr_t expr, int object)
{
      unsigned slot = 0;
      for (event_expr_capture_t*cur = event_expr_captures_; cur; cur = cur->next) {
            if (cur->expr == expr && cur->object == object)
                  return cur->slot;
            slot += 1;
      }
      event_expr_capture_t*entry = calloc(1, sizeof *entry);
      assert(entry);
      entry->expr = expr;
      entry->slot = slot;
      entry->object = object;
      entry->next = event_expr_captures_;
      event_expr_captures_ = entry;
      return slot;
}

void event_expr_capture_vec4_result(ivl_expr_t expr)
{
      if (!event_expr_capturing_) return;
      for (event_expr_capture_t*cur = event_expr_captures_; cur; cur = cur->next)
            if (!cur->object && cur->expr == expr)
                  fprintf(vvp_out, "    %%event/expr/save/v %u;\n", cur->slot);
}

void event_expr_capture_object_result(ivl_expr_t expr)
{
      if (!event_expr_capturing_) return;
      for (event_expr_capture_t*cur = event_expr_captures_; cur; cur = cur->next)
            if (cur->object && cur->expr == expr)
                  fprintf(vvp_out, "    %%event/expr/save/o %u;\n", cur->slot);
}

int event_expr_recipe_active(void)
{
      return event_expr_capturing_;
}

int event_expr_capture_active(ivl_expr_t expr)
{
      if (!event_expr_capturing_) return 0;
      for (event_expr_capture_t*cur = event_expr_captures_; cur; cur = cur->next)
            if (cur->expr == expr)
                  return 1;
      return 0;
}

static void event_expr_capture_end_(void)
{
      while (event_expr_captures_) {
            event_expr_capture_t*entry = event_expr_captures_;
            event_expr_captures_ = entry->next;
            free(entry);
      }
}

static int show_stmt_wait(ivl_statement_t net, ivl_scope_t sscope)
{
      static unsigned int cascade_counter = 0;
      int rc;
      int pure_comb_evaluation = (net == pure_comb_top_wait_);
      ivl_statement_t body = ivl_stmt_sub_stmt(net);
	/* Look to see if this is a SystemVerilog wait fork. */
      if ((ivl_stmt_nevent(net) == 1) && (ivl_stmt_events(net, 0) == 0)) {
	    assert(ivl_statement_type(ivl_stmt_sub_stmt(net)) == IVL_ST_NOOP);
	    show_stmt_file_line(net, "Wait fork statement.");
	    fprintf(vvp_out, "    %%wait/fork;\n");
	    return 0;
      }

      show_stmt_file_line(net, "Event wait (@) statement.");

      if (ivl_stmt_nevent(net) == 0) {
	    assert(ivl_stmt_needs_t0_trigger(net) == 1);
	    fprintf(vvp_out, "    %%wait E_0x0;\n");
      } else if (ivl_stmt_nevent(net) == 1) {
	    ivl_event_t ev = ivl_stmt_events(net, 0);
	    if (ivl_stmt_needs_t0_trigger(net)) {
		  fprintf(vvp_out, "Ewait_%u .event/or E_%p, E_0x0;\n",
		                   cascade_counter, ev);
		  fprintf(vvp_out, "    %%wait Ewait_%u;\n", cascade_counter);
		  cascade_counter += 1;
	    } else if (ivl_event_is_obj_mutation(ev)
                       || ivl_event_observer_expr(ev)) {
		  /* Class-property sensitivity can span multiple objects. Load
		   * every distinct root/owner path and suspend on their combined
		   * mutation set so a change to ANY operand re-evaluates wait(). */
		  unsigned path_count = ivl_event_obj_mutation_count(ev);
		  if (path_count == 0 && !ivl_event_observer_expr(ev))
			path_count = 1; /* Compatibility with older target records. */
		  int has_property_filter = 0;
		  if (ivl_event_obj_mutation_count(ev)) {
			for (unsigned path = 0 ; path < path_count ; path += 1)
			      if (ivl_event_obj_mutation_property_N(ev, path)
				  != UINT_MAX) {
				    has_property_filter = 1;
				    break;
			      }
		  }
                  ivl_expr_t observer = ivl_event_observer_expr(ev);
                  unsigned observer_label = 0;
                  if (observer) {
                        assert(!event_expr_captures_);
                        observer_label = cascade_counter++;
                        for (unsigned path = 0; path < path_count; ++path) {
                              ivl_expr_t owner = ivl_event_obj_mutation_owner_expr(ev, path);
                              ivl_expr_t word = ivl_event_obj_mutation_property_word_expr(ev, path);
                              ivl_expr_t bit = ivl_event_obj_mutation_property_bit_expr(ev, path);
                              if (owner) event_expr_capture_slot_(owner, 1);
                              if (word) event_expr_capture_slot_(word, 0);
                              if (bit) event_expr_capture_slot_(bit, 0);
                        }
                        const char*observer_wait = "obj/expr";
                        if (ivl_event_observer_edge(ev) == 1)
                              observer_wait = "obj/expr/posedge";
                        else if (ivl_event_observer_edge(ev) == 2)
                              observer_wait = "obj/expr/negedge";
                        fprintf(vvp_out, "    %%wait/%s E_%p, Tevent_%u;\n",
                                observer_wait, ev, observer_label);
                        fprintf(vvp_out, "    %%jmp Tevent_after_%u;\n", observer_label);
                        fprintf(vvp_out, "Tevent_%u ;\n", observer_label);
                        event_expr_capturing_ = 1;
                        draw_eval_vec4(observer);
                        event_expr_capturing_ = 0;
                  }
		  for (unsigned path = 0 ; path < path_count ; path += 1) {
			ivl_expr_t owner_expr = ivl_event_obj_mutation_count(ev)
			      ? ivl_event_obj_mutation_owner_expr(ev, path) : 0;
			unsigned pre_N = ivl_event_obj_mutation_count(ev)
			      ? ivl_event_obj_mutation_pre_N(ev, path)
			      : ivl_event_obj_pre_N(ev);
			unsigned obj_N = ivl_event_obj_mutation_count(ev)
			      ? ivl_event_obj_mutation_N(ev, path)
			      : ivl_event_obj_N(ev);
			if (owner_expr) {
                              if (observer)
                                    fprintf(vvp_out, "    %%event/expr/load/o %u;\n",
                                            event_expr_capture_slot_(owner_expr, 1));
                              else
                                    draw_eval_object(owner_expr);
			} else {
			      unsigned root_pin = ivl_event_obj_mutation_count(ev)
				    ? ivl_event_obj_mutation_root_pin(ev, path) : 0;
			      ivl_nexus_t this_nex = ivl_event_nany(ev) > root_pin
				    ? ivl_event_any(ev, root_pin)
				    : ivl_event_pos(ev, root_pin);
			      const char*this_var = draw_input_from_net(
				    this_nex, ivl_event_scope(ev));
			      fprintf(vvp_out, "    %%load/obj %s;\n", this_var);
			      if (pre_N != UINT_MAX)
				    fprintf(vvp_out, "    %%prop/obj %u, 0;\n", pre_N);
			      if (obj_N != UINT_MAX)
				    fprintf(vvp_out, "    %%prop/obj %u, 0;\n", obj_N);
			      if (pre_N != UINT_MAX || obj_N != UINT_MAX)
				    fprintf(vvp_out, "    %%pop/obj %u, 1;\n",
					    (pre_N != UINT_MAX)
					    + (obj_N != UINT_MAX));
			}
			/* An observer also encodes wildcard receiver dependencies. */
			if (has_property_filter || observer) {
			      unsigned property_N =
				    ivl_event_obj_mutation_property_N(ev, path);
			      unsigned property_word =
				    ivl_event_obj_mutation_property_word(ev, path);
			      fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32;\n",
				      property_N);
			      ivl_expr_t word_expr =
				    ivl_event_obj_mutation_property_word_expr(ev, path);
                              if (word_expr && observer)
                                    fprintf(vvp_out, "    %%event/expr/load/v %u, %u;\n",
                                            event_expr_capture_slot_(word_expr, 0),
                                            ivl_expr_width(word_expr));
                              else if (word_expr)
                                    draw_eval_vec4(word_expr);
                              else
				    fprintf(vvp_out,
					  "    %%pushi/vec4 %u, 0, 32;\n",
					  property_word);
			      unsigned property_bit =
				    ivl_event_obj_mutation_property_bit(ev, path);
			      ivl_expr_t bit_expr =
				    ivl_event_obj_mutation_property_bit_expr(ev, path);
                              if (bit_expr && observer)
                                    fprintf(vvp_out, "    %%event/expr/load/v %u, %u;\n",
                                            event_expr_capture_slot_(bit_expr, 0),
                                            ivl_expr_width(bit_expr));
                              else if (bit_expr)
                                    draw_eval_vec4(bit_expr);
                              else
				    fprintf(vvp_out,
					  "    %%pushi/vec4 %u, 0, 32;\n",
					  property_bit);
			      /* The numeric UINT_MAX value is the legacy fixed-selector
			       * wildcard. Tell the runtime which selectors were evaluated
			       * dynamically so X/Z or an invalid packed index cannot be
			       * mistaken for that wildcard. bit 0=word, bit 1=packed bit. */
			      fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 2;\n",
				    (word_expr ? 1U : 0U) | (bit_expr ? 2U : 0U));
			}
		  }
                  if (observer) {
                        fprintf(vvp_out, "    %%event/expr/return %u;\n", path_count);
                        fprintf(vvp_out, "Tevent_after_%u ;\n", observer_label);
                        event_expr_capture_end_();
                  } else if (has_property_filter && path_count == 1)
			fprintf(vvp_out, "    %%wait/obj/mutation/filtered;\n");
		  else if (has_property_filter)
			fprintf(vvp_out,
			      "    %%wait/obj/mutation/filtered/multi %u;\n",
			      path_count);
		  else if (path_count == 1)
			fprintf(vvp_out, "    %%wait/obj/mutation;\n");
		  else
			fprintf(vvp_out, "    %%wait/obj/mutation/multi %u;\n",
				path_count);
	    } else if (ivl_event_is_vif_posedge(ev)
		       || ivl_event_is_vif_negedge(ev)
		       || ivl_event_is_vif_anyedge(ev)) {
		  /* VIF edge: @(posedge/negedge/edge [cfg.]vif.clk) in a class method.
		   * 2-level: base→vif[N]→sig[M]:
		   *   %load/obj base; %prop/obj N,0; %pop/obj 1,1; %wait/vif/edge M
		   * 3-level: base→cfg[pre_N]→vif[N]→sig[M]:
		   *   %load/obj base; %prop/obj pre_N,0; %prop/obj N,0; %pop/obj 2,1; %wait/vif/edge M
		   */
		  const char*opcode = ivl_event_is_vif_posedge(ev)
			? "posedge"
			: ivl_event_is_vif_negedge(ev) ? "negedge" : "anyedge";
		  unsigned root_pin = ivl_event_vif_root_pin(ev);
		  ivl_expr_t vif_object_expr = ivl_event_vif_object_expr(ev);
		  ivl_nexus_t this_nex = 0;
		  if (ivl_event_npos(ev) > root_pin) this_nex = ivl_event_pos(ev, root_pin);
		  else if (ivl_event_nneg(ev) > root_pin) this_nex = ivl_event_neg(ev, root_pin);
		  else if (ivl_event_nany(ev) > root_pin) this_nex = ivl_event_any(ev, root_pin);
		  unsigned path_count = ivl_event_vif_path_count(ev);
		  if (!this_nex && !vif_object_expr) {
			fprintf(stderr,
			      "error: virtual-interface wait event %s has no root nexus "
			      "(nany=%u, npos=%u, nneg=%u, root=%u)\n",
			      ivl_event_basename(ev), ivl_event_nany(ev),
			      ivl_event_npos(ev), ivl_event_nneg(ev), root_pin);
			return 1;
		  }
		  if (vif_object_expr) {
			if (draw_eval_object(vif_object_expr)) return 1;
		  } else {
			draw_object_from_net(this_nex, ivl_event_scope(ev));
		  }
		  if (path_count == 0 && ivl_event_vif_N(ev) == UINT_MAX) {
			/* Direct interface-port member `@(edge p.sig)`: the base
			   object loaded above IS the virtual interface, so there
			   is no intermediate vif property to extract. %wait/vif
			   pops the object it waits on. */
			unsigned member_word = ivl_event_vif_member_word(ev);
			if (member_word == UINT_MAX)
			      fprintf(vvp_out, "    %%wait/vif/%s %u;\n",
				      opcode, ivl_event_vif_M(ev));
			else
			      fprintf(vvp_out, "    %%wait/vif/%s/i %u, %u;\n",
				      opcode, ivl_event_vif_M(ev), member_word);
		  } else {
			if (path_count > 0) {
			      for (unsigned idx = 0 ; idx < path_count ; idx += 1)
				    fprintf(vvp_out, "    %%prop/obj %u, 0;\n",
					    ivl_event_vif_path_index(ev, idx));
			      fprintf(vvp_out, "    %%pop/obj %u, 1;\n", path_count);
			} else {
			      /* Compatibility with targets produced before the full
			       * path metadata was added. */
			      unsigned pre_N = ivl_event_vif_pre_N(ev);
			      int has_pre = (pre_N != UINT_MAX);
			      if (has_pre)
				    fprintf(vvp_out, "    %%prop/obj %u, 0;\n", pre_N);
			      fprintf(vvp_out, "    %%prop/obj %u, 0;\n",
				      ivl_event_vif_N(ev));
			      fprintf(vvp_out, "    %%pop/obj %d, 1;\n", has_pre ? 2 : 1);
			}
			unsigned member_word = ivl_event_vif_member_word(ev);
			if (member_word == UINT_MAX)
			      fprintf(vvp_out, "    %%wait/vif/%s %u;\n",
				      opcode, ivl_event_vif_M(ev));
			else
			      fprintf(vvp_out, "    %%wait/vif/%s/i %u, %u;\n",
				      opcode, ivl_event_vif_M(ev), member_word);
		  }
	    } else {
		  fprintf(vvp_out, "    %%wait E_%p;\n", ev);
	    }

      } else {
	    unsigned idx;
	    int all_vif_edges = 1;
	    int all_vif_anyedge = 1;
	    for (idx = 0 ; idx < ivl_stmt_nevent(net) ; idx += 1) {
		  ivl_event_t ev = ivl_stmt_events(net, idx);
		  if (!ivl_event_is_vif_anyedge(ev)) {
			all_vif_anyedge = 0;
			if (!ivl_event_is_vif_posedge(ev)
			    && !ivl_event_is_vif_negedge(ev))
			      all_vif_edges = 0;
		  }
	    }

	    if (all_vif_edges) {
		  /* A compound expression such as @(cfg.vif.a || cfg.vif.b)
		   * produces one dynamic VIF event per member. Load every
		   * runtime VIF object and pair it with its member index and
		   * optional unpacked-array word;
		   * the multi wait resumes on the first edge and unregisters
		   * the thread from all sibling edge functors. */
		  for (idx = 0 ; idx < ivl_stmt_nevent(net) ; idx += 1) {
		  ivl_event_t ev = ivl_stmt_events(net, idx);
		  unsigned root_pin = ivl_event_vif_root_pin(ev);
		  ivl_expr_t vif_object_expr = ivl_event_vif_object_expr(ev);
		  ivl_nexus_t this_nex = 0;
		  if (ivl_event_nany(ev) > root_pin)
			this_nex = ivl_event_any(ev, root_pin);
		  else if (ivl_event_npos(ev) > root_pin)
			this_nex = ivl_event_pos(ev, root_pin);
		  else if (ivl_event_nneg(ev) > root_pin)
			this_nex = ivl_event_neg(ev, root_pin);
		  if (!this_nex && !vif_object_expr) {
			fprintf(stderr,
			      "error: virtual-interface event %s has no root nexus\n",
			      ivl_event_basename(ev));
			return 1;
		  }
			unsigned path_count = ivl_event_vif_path_count(ev);
			if (vif_object_expr) {
				if (draw_eval_object(vif_object_expr)) return 1;
			} else {
				draw_object_from_net(this_nex, ivl_event_scope(ev));
			}
			if (path_count > 0) {
			      for (unsigned path = 0 ; path < path_count ; path += 1)
				    fprintf(vvp_out, "    %%prop/obj %u, 0;\n",
					  ivl_event_vif_path_index(ev, path));
			      fprintf(vvp_out, "    %%pop/obj %u, 1;\n", path_count);
			} else if (ivl_event_vif_N(ev) != UINT_MAX) {
			      unsigned pre_N = ivl_event_vif_pre_N(ev);
			      int has_pre = (pre_N != UINT_MAX);
			      if (has_pre)
				    fprintf(vvp_out, "    %%prop/obj %u, 0;\n", pre_N);
			      fprintf(vvp_out, "    %%prop/obj %u, 0;\n",
				    ivl_event_vif_N(ev));
			      fprintf(vvp_out, "    %%pop/obj %d, 1;\n",
				    has_pre ? 2 : 1);
			}
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32;\n",
			      ivl_event_vif_M(ev));
		  fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32;\n",
			ivl_event_vif_member_word(ev));
		  if (!all_vif_anyedge)
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 2;\n",
			      ivl_event_is_vif_posedge(ev) ? 1U
			      : ivl_event_is_vif_negedge(ev) ? 2U : 0U);
		  }
		  assert(ivl_stmt_needs_t0_trigger(net) == 0);
		  fprintf(vvp_out, "    %%wait/vif/%s %u;\n",
			all_vif_anyedge ? "anyedge/multi" : "multi",
			ivl_stmt_nevent(net));
	    } else {
		  ivl_event_t ev = ivl_stmt_events(net, 0);
		  fprintf(vvp_out, "Ewait_%u .event/or E_%p", cascade_counter, ev);

		  for (idx = 1 ; idx < ivl_stmt_nevent(net) ; idx += 1) {
			ev = ivl_stmt_events(net, idx);
			fprintf(vvp_out, ", E_%p", ev);
		  }
		  if (ivl_stmt_needs_t0_trigger(net))
			fprintf(vvp_out, ", E_0x0");
		  fprintf(vvp_out, ";\n    %%wait Ewait_%u;\n", cascade_counter);
		  cascade_counter += 1;
	    }
      }

      if (pure_comb_evaluation)
	    fprintf(vvp_out, "    %%comb/begin;\n");
      rc = show_statement(body, sscope);
      if (pure_comb_evaluation)
	    fprintf(vvp_out, "    %%comb/end;\n");
      return rc;
}

static int show_stmt_wait_order(ivl_statement_t net, ivl_scope_t sscope)
{
      static unsigned monitor_count = 0;
      unsigned success_label = local_count++;
      unsigned failure_label = local_count++;
      unsigned done_label = local_count++;
      unsigned monitor = monitor_count++;
      unsigned count = ivl_stmt_nevent(net);
      int rc = 0;

      if (count == 0) {
	    fprintf(stderr, "%s:%u: internal error: wait_order has no events.\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 1;
      }

      show_stmt_file_line(net, "wait_order statement.");
      fprintf(vvp_out, "Ewaitorder_%u .event/order", monitor);
      for (unsigned idx = 0; idx < count; idx += 1)
	    fprintf(vvp_out, " E_%p%s", ivl_stmt_events(net, idx),
		    idx + 1 == count ? ";\n" : ",");

      fprintf(vvp_out, "    %%wait/order Ewaitorder_%u, T_%u.%u, T_%u.%u;\n",
	      monitor, thread_count, success_label,
	      thread_count, failure_label);
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done_label);
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, success_label);
      rc += show_statement(ivl_stmt_sub_stmt(net), sscope);
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done_label);
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, failure_label);
      rc += show_statement(ivl_stmt_wait_order_fail_stmt(net), sscope);
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, done_label);
      return rc;
}

static int expr_is_queue_expr(ivl_expr_t expr);
static int show_queue_object_receiver(ivl_expr_t parm);
static int expr_is_static_array_expr(ivl_expr_t expr);

/* Runtime element-kind encoding of a queue type (as used by
 * %new/queue and %aa/loadlv/o/q). */
static void queue_elem_enc_(ivl_type_t queue_type, char*enc, size_t enc_len)
{
      ivl_type_t element_type = ivl_type_element(queue_type);
      ivl_variable_type_t type = element_type ? ivl_type_base(element_type) : IVL_VT_NO_TYPE;
      int wid = 0;
      const char*signed_char = "";

      if ((type == IVL_VT_BOOL) || (type == IVL_VT_LOGIC)) {
	    wid = ivl_type_packed_width(element_type);
	    signed_char = ivl_type_signed(element_type) ? "s" : "";
      }

      switch (type) {
	  case IVL_VT_REAL:
	    snprintf(enc, enc_len, "r");
	    break;
	  case IVL_VT_STRING:
	    snprintf(enc, enc_len, "S");
	    break;
	  case IVL_VT_BOOL:
	    snprintf(enc, enc_len, "%sb%d", signed_char, wid);
	    break;
	  case IVL_VT_LOGIC:
	    snprintf(enc, enc_len, "%sv%d", signed_char, wid);
	    break;
	  default:
	    snprintf(enc, enc_len, "o");
	    break;
      }
}

/* Runtime nested-container constructor code. This matches aa_viv_spec_code
 * in vvp/vthread.cc. Positional load-or-vivify encodes the same code as
 * "@N", so a mixed queue/associative chain constructs the declared child
 * container instead of assuming that every positional child is a queue. */
static unsigned dynamic_container_spec_(ivl_type_t container_type)
{
      ivl_type_t element_type = ivl_type_element(container_type);
      unsigned kind = 3;

      if (element_type) {
	    switch (ivl_type_base(element_type)) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:  kind = 0; break;
		case IVL_VT_REAL:   kind = 1; break;
		case IVL_VT_STRING: kind = 2; break;
		default:            kind = 3; break;
	    }
      }

      if (ivl_type_base(container_type) == IVL_VT_QUEUE
	  && ivl_type_queue_assoc_compat(container_type))
	    kind += 4;
      return kind;
}

/* A queue/darray used as another container's element has value semantics.
 * Materialize a cross-kind RHS as the destination's declared container kind;
 * the receiving object-store opcode otherwise sees only the source object's
 * concrete runtime kind. Object-store opcodes make the final ordinary copy,
 * but have no target-type operand from which to learn an inner queue's bound.
 * Make a private copy and trim it before the store. Keep word 3/flag 4 intact
 * because insert() evaluates its position before its value. */
static void draw_queue_element_object_value_(ivl_expr_t expr,
                                             ivl_type_t element_type)
{
      uint64_t max_size;

      if (draw_eval_container_value_for_target(expr, element_type) < 0)
            draw_eval_object(expr);
      if (!element_type || ivl_type_base(element_type) != IVL_VT_QUEUE
          || ivl_type_queue_assoc_compat(element_type))
            return;

      max_size = ivl_type_queue_max_size(element_type);
      if (max_size == 0)
            return;

      /* Trimming must never mutate the RHS. Only bounded queue elements need
       * this target-side private copy; every other element is copied exactly
       * once by the runtime store's value_copy_element() policy. */
      fprintf(vvp_out, "    %%dup/obj; bounded queue element value copy\n");
      fprintf(vvp_out, "    %%pop/obj 1, 1; discard source queue value\n");

      fprintf(vvp_out, "    %%queue/trim/o %" PRIu64
              "; destination-bound queue element copy\n", max_size);
}

static int show_delete_static_array_signal_method(ivl_statement_t net,
						  ivl_signal_t var,
						  ivl_type_t array_type,
						  unsigned parm_count)
{
      ivl_type_t element_type = ivl_type_element(array_type);
      if (!element_type || parm_count != 2)
	    return -1;

      draw_eval_expr_into_integer(ivl_stmt_parm(net, 1), 3);

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
	    note_array_signal_use(var);
	    fprintf(vvp_out, "    %%store/reala v%p, 3;\n", var);
	    return 0;
	  case IVL_VT_STRING:
	    fprintf(vvp_out, "    %%pushi/str \"\";\n");
	    note_array_signal_use(var);
	    fprintf(vvp_out, "    %%store/stra v%p, 3;\n", var);
	    return 0;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    fprintf(vvp_out, "    %%null;\n");
	    note_array_signal_use(var);
	    fprintf(vvp_out, "    %%store/obja v%p, 3;\n", var);
	    return 0;
	  default:
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n",
		    ivl_type_packed_width(element_type));
	    note_array_signal_use(var);
	    fprintf(vvp_out, "    %%store/vec4a v%p, 3, 0;\n", var);
	    return 0;
      }
}

static int show_delete_static_array_property_method(ivl_statement_t net,
						    ivl_expr_t parm,
						    unsigned parm_count)
{
      ivl_expr_t base = ivl_expr_oper2(parm);
      ivl_expr_t prop_word = ivl_expr_oper1(parm);
      ivl_type_t array_type = ivl_expr_net_type(parm);
      ivl_type_t element_type = ivl_type_element(array_type);
      int prop_idx = ivl_expr_property_idx(parm);
      int idx_reg;

      if (!base || prop_idx < 0 || !element_type || prop_word || parm_count != 2)
	    return -1;

      draw_eval_object(base);
      idx_reg = allocate_word();
      draw_eval_expr_into_integer(ivl_stmt_parm(net, 1), idx_reg);

      switch (ivl_type_base(element_type)) {
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    fprintf(vvp_out, "    %%null;\n");
	    fprintf(vvp_out, "    %%store/prop/obj %d, %d;\n", prop_idx, idx_reg);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    clr_word(idx_reg);
	    return 0;
	  case IVL_VT_REAL:
	  case IVL_VT_STRING:
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    clr_word(idx_reg);
	    return -1;
	  default:
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n",
		    ivl_type_packed_width(element_type));
	    fprintf(vvp_out, "    %%store/prop/v/i %d, %d, %u;\n",
		    prop_idx, idx_reg, ivl_type_packed_width(element_type));
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    clr_word(idx_reg);
	    return 0;
      }
}

static int show_delete_property_method(ivl_statement_t net, ivl_expr_t parm, unsigned parm_count)
{
	      ivl_expr_t base = ivl_expr_oper2(parm);
	      int prop_idx = ivl_expr_property_idx(parm);
	      ivl_expr_t prop_word = ivl_expr_oper1(parm);
	      ivl_type_t prop_type = 0;
	      int word_reg = 0;

	      if (!base || prop_idx < 0)
		    return -1;

	      /* An indexed fixed-array property denotes its leaf container.
	       * Let the object-receiver path operate on that selected slot;
	       * the direct property path below interprets prop_word as an
	       * index inside a scalar container property. */
	      if (property_selects_fixed_uarray_slot_(parm)) {
		    ivl_type_t value_type = property_expr_value_type_(parm);
		    if (value_type
			&& (ivl_type_base(value_type) == IVL_VT_QUEUE
			    || ivl_type_base(value_type) == IVL_VT_DARRAY))
			  return -1;
	      }

	      {
		    ivl_type_t recv_type = ivl_expr_net_type(base);
		    if (recv_type && ivl_type_base(recv_type) == IVL_VT_CLASS)
			  prop_type = ivl_type_prop_type(recv_type, prop_idx);
	      }

	      if (!prop_type)
		    prop_type = property_assoc_container_type_(parm);
	      if (!prop_type)
		    prop_type = ivl_expr_net_type(parm);

	      if ((parm_count == 2) && !prop_word && prop_type
		  && ivl_type_base(prop_type) == IVL_VT_QUEUE
		  && ivl_type_queue_assoc_compat(prop_type)) {
		    ivl_expr_t key_expr = ivl_stmt_parm(net, 1);
                    const char*key_kind;
		    draw_eval_object(base);
		    fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
                    key_kind = draw_eval_assoc_key_(key_expr, 0);
		    fprintf(vvp_out, "    %%aa/delete/%s;\n", key_kind);
		    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
		    return 0;
	      }

	      /* aa.delete() with NO argument removes all entries
	       * (IEEE 1800-2017 7.9.2). Without this branch the call fell
	       * through to the plain-queue path below, whose typed
	       * vvp_queue receiver peek nulls on an assoc object -- the
	       * operation was DROPPED with only a generic (and wrong)
	       * "null queue" warning. Every stock UVM run hit this ~127
	       * times (objection counts, phase-graph splices, printer and
	       * packer caches). */
	      if ((parm_count == 1) && !prop_word && prop_type
		  && ivl_type_base(prop_type) == IVL_VT_QUEUE
		  && ivl_type_queue_assoc_compat(prop_type)) {
		    draw_eval_object(base);
		    fprintf(vvp_out, "    %%prop/obj %d, 0;\n", prop_idx);
		    fprintf(vvp_out, "    %%aa/delete/all;\n");
		    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
		    return 0;
	      }

	      if (expr_is_queue_expr(parm)) {
		    draw_eval_object(parm);
		    if (parm_count == 1) {
			  fprintf(vvp_out, "    %%delete/o/obj;\n");
		    } else if (parm_count == 2) {
			  draw_eval_expr_into_integer(ivl_stmt_parm(net, 1), 3);
			  fprintf(vvp_out, "    %%delete/o/elem;\n");
		    } else {
			  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			  return -1;
		    }
		    return 0;
	      }

	      if (expr_is_static_array_expr(parm)) {
		    if (show_delete_static_array_property_method(net, parm, parm_count) == 0)
			  return 0;
	      }

	      draw_eval_object(base);

      if (prop_word) {
	    word_reg = allocate_word();
	    draw_eval_expr_into_integer(prop_word, word_reg);
      }

      if (parm_count == 1) {
	    /* delete() on a queue/object class property clears it to null. */
	    fprintf(vvp_out, "    %%null;\n");
	    fprintf(vvp_out, "    %%store/prop/obj %d, %d;\n", prop_idx, word_reg);
      } else if (parm_count == 2) {
	    int idx_reg = allocate_word();
	    draw_eval_expr_into_integer(ivl_stmt_parm(net, 1), idx_reg);
	    clr_word(idx_reg);
      } else {
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    if (word_reg)
		  clr_word(word_reg);
	    return -1;
      }

      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");

      if (word_reg)
	    clr_word(word_reg);

	      return 0;
}

static int show_delete_queue_object_method(ivl_statement_t net, ivl_expr_t parm,
					   unsigned parm_count)
{
	      ivl_type_t rt = receiver_container_type_(parm);

	      /* delete(key) on an ASSOCIATIVE receiver expression must
	       * erase the keyed entry (IEEE 1800-2017 7.9.2), not queue
	       * position <key>. */
	      if (parm_count == 2) {
		    if (rt && ivl_type_base(rt) == IVL_VT_QUEUE
			&& ivl_type_queue_assoc_compat(rt)) {
			  const char*key_kind;
			  if (show_queue_object_receiver(parm) != 0)
				return -1;
			  key_kind = draw_eval_assoc_key_(ivl_stmt_parm(net, 1), 0);
			  fprintf(vvp_out, "    %%aa/delete/%s;\n", key_kind);
			  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			  return 0;
		    }
	      }

	      if (parm_count == 1 && rt
		  && ivl_type_base(rt) == IVL_VT_QUEUE
		  && ivl_type_queue_assoc_compat(rt)) {
		    if (show_queue_object_receiver(parm) != 0)
			  return -1;
		    fprintf(vvp_out, "    %%aa/delete/all;\n");
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    return 0;
	      }

	      if (show_queue_object_receiver(parm) != 0)
		    return -1;

	      if (parm_count == 1) {
		    fprintf(vvp_out, "    %%delete/o/obj;\n");
	      } else if (parm_count == 2) {
		    draw_eval_expr_into_integer(ivl_stmt_parm(net, 1), 3);
		    fprintf(vvp_out, "    %%delete/o/elem;\n");
	      } else {
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    return -1;
	      }

	      return 0;
}

static int show_delete_method(ivl_statement_t net)
{
      static int warned_delete_non_signal = 0;
      show_stmt_file_line(net, "Delete object");

      unsigned parm_count = ivl_stmt_parm_count(net);
      if ((parm_count < 1) || (parm_count > 2)) {
	    fprintf(stderr, "Warning: delete expects 1 or 2 parameters at %s:%u; skipping\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 0;
      }

	      ivl_expr_t parm = ivl_stmt_parm(net, 0);
	      if (ivl_expr_type(parm) != IVL_EX_SIGNAL) {
		    if (ivl_expr_type(parm) == IVL_EX_PROPERTY) {
			  if (show_delete_property_method(net, parm, parm_count) == 0)
				return 0;
		    }
		    if (show_delete_queue_object_method(net, parm, parm_count) == 0)
			  return 0;
		    if (!warned_delete_non_signal) {
			  fprintf(stderr, "Warning: delete requires signal, got expr type %d at %s:%u"
				  " (further similar warnings suppressed)\n",
			  ivl_expr_type(parm), ivl_stmt_file(net), ivl_stmt_lineno(net));
		  warned_delete_non_signal = 1;
	    }
	    return 0;
      }
      ivl_signal_t var = ivl_expr_signal(parm);
      ivl_type_t var_type = ivl_signal_net_type(var);

	/* The API keeps a selected fixed container word in IVL_EX_SIGNAL form,
	 * but it has no scalar v<array>_0 storage. Route every Q/D/A fixed word
	 * through the object-receiver implementation before the scalar/static
	 * signal cases below. */
      if (expr_selects_fixed_container_slot_(parm)) {
	    if (show_delete_queue_object_method(net, parm, parm_count) == 0)
		  return 0;
	    return -1;
      }

	/* A fully selected fixed-array word containing an associative array is
	 * an object receiver, not the nonexistent scalar signal v<array>_0.
	 * This mirrors exists/first/last/next/prev expression lowering and keeps
	 * the fixed canonical word distinct from delete's optional map key. */
      if (ivl_signal_dimensions(var) > 0 && ivl_expr_oper1(parm)
	  && var_type && ivl_type_base(var_type) == IVL_VT_QUEUE
	  && ivl_type_queue_assoc_compat(var_type)) {
	    draw_eval_object(parm);
	    if (parm_count == 2) {
		  const char*key_kind =
			draw_eval_assoc_key_(ivl_stmt_parm(net, 1), 0);
		  fprintf(vvp_out, "    %%aa/delete/%s;\n", key_kind);
	    } else {
		  fprintf(vvp_out, "    %%aa/delete/all;\n");
	    }
	    fprintf(vvp_out, "    %%pop/obj 1, 0; selected fixed map receiver\n");
	    return 0;
      }

      if (expr_is_static_array_expr(parm)) {
	    if (show_delete_static_array_signal_method(net, var, var_type, parm_count) == 0)
		  return 0;
      }

	/* Assoc-compat queues model associative arrays in the frontend.
	   delete(key) must erase the keyed entry, not queue index 1. */
      if ((parm_count == 2) && var_type
          && ivl_type_base(var_type) == IVL_VT_QUEUE
          && ivl_type_queue_assoc_compat(var_type)) {
            const char*key_kind;
            fprintf(vvp_out, "    %%load/obj v%p_0;\n", var);
            key_kind = draw_eval_assoc_key_(ivl_stmt_parm(net, 1), 0);
            fprintf(vvp_out, "    %%aa/delete/%s;\n", key_kind);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return 0;
      }

	/* An associative-array default is container state, not an entry.
	   delete() removes all explicit entries but must retain that fallback;
	   do not route through %delete/obj, which replaces the whole runtime
	   container with nil. This mirrors the class-property path above. */
      if ((parm_count == 1) && var_type
          && ivl_type_base(var_type) == IVL_VT_QUEUE
          && ivl_type_queue_assoc_compat(var_type)) {
            fprintf(vvp_out, "    %%load/obj v%p_0;\n", var);
            fprintf(vvp_out, "    %%aa/delete/all;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            return 0;
      }

	/* If this is a queue then it can have an element to delete. */
      if (parm_count == 2) {
	    if (ivl_type_base(var_type) != IVL_VT_QUEUE) {
		  fprintf(stderr, "Warning: delete index form requires queue at %s:%u; skipping\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 0;
	    }
	    draw_eval_expr_into_integer(ivl_stmt_parm(net, 1), 3);
	    fprintf(vvp_out, "    %%delete/elem v%p_0;\n", var);
      } else {
	    fprintf(vvp_out, "    %%delete/obj v%p_0;\n", var);
      }
      return 0;
}

static int expr_is_queue_expr(ivl_expr_t expr)
{
      ivl_type_t net_type;
      if (!expr)
	    return 0;

      if (property_assoc_container_type_(expr))
	    return 0;

      net_type = ivl_expr_net_type(expr);
      if (net_type && ivl_type_base(net_type) == IVL_VT_QUEUE
          && !ivl_type_queue_assoc_compat(net_type))
	    return 1;

      return ivl_expr_value(expr) == IVL_VT_QUEUE;
}

static int expr_is_static_array_expr(ivl_expr_t expr)
{
      ivl_type_t net_type;

      if (!expr)
	    return 0;

      if (expr_is_queue_expr(expr))
	    return 0;

      if (ivl_expr_value(expr) == IVL_VT_DARRAY)
	    return 0;

      net_type = ivl_expr_net_type(expr);
      return net_type && ivl_type_element(net_type) != 0;
}

/* Evaluate one selected word of a fixed object array as a live container
 * receiver. Queue/associative-array words have an empty-container default,
 * while compact object-array storage starts nil, so materialize that default
 * on first mutating use and reload the destination-bound copy. The fixed index
 * is evaluated exactly once and retained across the nil test. */
static int show_fixed_container_slot_receiver_(ivl_expr_t parm)
{
      ivl_signal_t sig;
      ivl_type_t type;
      ivl_expr_t slot_expr;
      int slot_word;

      if (!expr_selects_fixed_container_slot_(parm))
	    return -1;

      sig = ivl_expr_signal(parm);
      type = ivl_signal_net_type(sig);
      slot_expr = ivl_expr_oper1(parm);
      slot_word = allocate_word();
      draw_eval_expr_into_integer(slot_expr, slot_word);
      note_array_signal_use(sig);
      fprintf(vvp_out, "    %%load/obja v%p, %d; selected fixed container receiver\n",
	      sig, slot_word);

      if (ivl_type_base(type) == IVL_VT_QUEUE) {
	    int slot_flag = allocate_flag();
	    unsigned lab_ready = local_count++;

	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve fixed-slot validity\n",
		    slot_flag);
	    fprintf(vvp_out, "    %%test_nul/obj;\n");
	    fprintf(vvp_out, "    %%jmp/0 T_%u.%u, 4; fixed-slot container exists\n",
		    thread_count, lab_ready);
	    fprintf(vvp_out, "    %%pop/obj 1, 0; replace nil fixed-slot container\n");
	    fprintf(vvp_out, "    %%new/queue \"@%u\"; fixed-slot container default\n",
		    dynamic_container_spec_(type));
	    fprintf(vvp_out, "    %%flag_mov 4, %d; restore fixed-slot validity\n",
		    slot_flag);
	    fprintf(vvp_out, "    %%store/obja v%p, %d; initialize fixed-slot container\n",
		    sig, slot_word);
	    fprintf(vvp_out, "    %%load/obja v%p, %d; reload fixed-slot receiver\n",
		    sig, slot_word);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_ready);
	    clr_flag(slot_flag);
      }

      clr_word(slot_word);
      return 0;
}

static int show_queue_object_receiver(ivl_expr_t parm)
{
      if (getenv("IVL_QRECV_TRACE")) {
	    ivl_type_t nt = ivl_expr_net_type(parm);
	    fprintf(stderr, "[qrecv] parm etype=%d isq=%d nt=%p base=%d\n",
		    (int)ivl_expr_type(parm), expr_is_queue_expr(parm),
		    (void*)nt, nt ? (int)ivl_type_base(nt) : -1);
	    if (ivl_expr_type(parm) == IVL_EX_SELECT) {
		  ivl_expr_t sube = ivl_expr_oper1(parm);
		  ivl_type_t bt = sube && (ivl_expr_type(sube)==IVL_EX_SIGNAL||ivl_expr_type(sube)==IVL_EX_ARRAY) && ivl_expr_signal(sube) ? ivl_signal_net_type(ivl_expr_signal(sube)) : 0;
		  fprintf(stderr, "[qrecv] sube etype=%d bt=%p btbase=%d compat=%d\n",
			  sube ? (int)ivl_expr_type(sube) : -1, (void*)bt,
			  bt ? (int)ivl_type_base(bt) : -1,
			  bt ? ivl_type_queue_assoc_compat(bt) : -1);
	    }
      }
	      if (!expr_is_dynarray_container_(parm)
		  && !expr_is_assoc_queue_container_(parm))
		    return -1;

      if (show_fixed_container_slot_receiver_(parm) == 0)
	    return 0;

      if (ivl_expr_type(parm) == IVL_EX_SELECT) {
	    ivl_expr_t sube = ivl_expr_oper1(parm);
	    ivl_expr_t index = ivl_expr_oper2(parm);
	    ivl_signal_t sig = 0;
	    ivl_type_t base_type = 0;
	    ivl_type_t recv_type = 0;

	      /* Dynamic-container element through an associative class PROPERTY
	       * (c.aq[key].push_back(v)): use the typed vivify load so a missing
	       * entry is inserted and the selected child retains the property's
	       * root notification provenance. */
	    if (sube && index && ivl_expr_type(sube) == IVL_EX_PROPERTY) {
		  ivl_type_t ptype = ivl_expr_net_type(sube);
		  ivl_type_t elem = ptype ? ivl_type_element(ptype) : 0;
		  if (ptype && ivl_type_base(ptype) == IVL_VT_QUEUE
		      && ivl_type_queue_assoc_compat(ptype)
		      && elem && ivl_type_base(elem) == IVL_VT_QUEUE) {
			const char*key_kind;
			unsigned spec = dynamic_container_spec_(elem);
			/* Evaluate the property expression itself. For a fixed outer
			 * array, oper1 is its canonical SLOT; manually loading slot zero
			 * made every method mutate element zero. This also centralizes
			 * null/X/OOB handling in the ordinary property evaluator. */
			draw_eval_object(sube);
			key_kind = draw_eval_assoc_key_(index, 0);
			if (strcmp(key_kind, "obj") == 0)
			      spec += 8;
			fprintf(vvp_out, "    %%aa/viv/o/%s %u;\n",
				key_kind, spec);
			return 0;
		  }

		    /* POSITIONAL container-of-queue element through a class
		       PROPERTY (c.qq[i].push_back(v)): same fresh-element gap
		       as the assoc form above, positional index (recovery
		       D14). */
		  if (ptype
		      && (ivl_type_base(ptype) == IVL_VT_DARRAY
			  || (ivl_type_base(ptype) == IVL_VT_QUEUE
			      && !ivl_type_queue_assoc_compat(ptype)))
		      && elem && ivl_type_base(elem) == IVL_VT_QUEUE
		      && !ivl_type_queue_assoc_compat(elem)) {
			char enc[32];
			queue_elem_enc_(elem, enc, sizeof enc);
			draw_eval_object(sube);
			draw_eval_expr_into_integer(index, 3);
			fprintf(vvp_out, "    %%qdar/loadlv/o \"%s\";\n", enc);
			/* %qdar/loadlv/o consumes the selected outer container. */
			return 0;
		  }
	    }

	    if (sube && index
		&& (ivl_expr_type(sube) == IVL_EX_SIGNAL
		    || ivl_expr_type(sube) == IVL_EX_ARRAY)) {
		  sig = ivl_expr_signal(sube);
		  if (sig)
			base_type = ivl_signal_net_type(sig);
		  if (base_type)
			recv_type = ivl_type_element(base_type);
	    }

	      /* POSITIONAL container-of-queue element receiver
	         (dq[i].push_back(...) with dq a darray-of-queue or a
	         genuine queue-of-queue). The plain element load returns
	         nil for a fresh element and the runtime drops the
	         mutation with only a warning (recovery D14); per
	         IEEE 1800-2017 7.5/7.9 a fresh element is an EMPTY
	         QUEUE. Use the positional get-or-create load. */
	    if (sig
		&& base_type
		&& (ivl_type_base(base_type) == IVL_VT_DARRAY
		    || (ivl_type_base(base_type) == IVL_VT_QUEUE
			&& !ivl_type_queue_assoc_compat(base_type)))
		&& recv_type && ivl_type_base(recv_type) == IVL_VT_QUEUE
		&& !ivl_type_queue_assoc_compat(recv_type)) {
		  char enc[32];
		  queue_elem_enc_(recv_type, enc, sizeof enc);
		  if (expr_selects_fixed_container_slot_(sube))
			show_fixed_container_slot_receiver_(sube);
		  else
			fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
		  draw_eval_expr_into_integer(index, 3);
		  fprintf(vvp_out, "    %%qdar/loadlv/o \"%s\";\n", enc);
		  return 0;
	    }

	    if (sig
		&& base_type && ivl_type_base(base_type) == IVL_VT_QUEUE
		&& ivl_type_queue_assoc_compat(base_type)
		&& recv_type && ivl_type_base(recv_type) == IVL_VT_QUEUE) {
		  const char*key_kind;
		  unsigned spec = dynamic_container_spec_(recv_type);
		  if (expr_selects_fixed_container_slot_(sube)) {
			show_fixed_container_slot_receiver_(sube);
			key_kind = draw_eval_assoc_key_(index, 0);
			fprintf(vvp_out, "    %%aa/viv/o/%s %u;\n",
				key_kind, spec);
		  } else {
			key_kind = draw_eval_assoc_key_(index, 0);
			fprintf(vvp_out, "    %%aa/viv/sig/%s v%p_0, %u;\n",
				key_kind, sig, spec);
		  }
		  return 0;
	    }
      }

      draw_eval_object(parm);
      return 0;
}

static int show_insert_method(ivl_statement_t net)
{
      static int warned_insert_non_signal = 0;
      show_stmt_file_line(net, "queue: insert");

      unsigned parm_count = ivl_stmt_parm_count(net);
      if (parm_count != 3) {
	    fprintf(stderr, "Warning: insert expects 3 parameters at %s:%u; skipping\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 0;
      }

      ivl_expr_t parm0 = ivl_stmt_parm(net,0);
      if (ivl_expr_type(parm0) != IVL_EX_SIGNAL
	  || expr_selects_fixed_container_slot_(parm0)) {
            if (show_queue_object_receiver(parm0) == 0) {
                  ivl_expr_t parm2 = ivl_stmt_parm(net,2);
                  ivl_type_t recv_type = receiver_container_type_(parm0);
                  ivl_type_t elem_type = recv_type
                        ? ivl_type_element(recv_type) : 0;
                  ivl_variable_type_t elem_kind = elem_type
                        ? ivl_type_base(elem_type) : ivl_expr_value(parm2);
                  uint64_t max_count = queue_receiver_max_operand_(
			parm0, recv_type);
                  int insert_word = allocate_word();
                  int insert_flag = allocate_flag();
		  draw_eval_expr_into_integer(ivl_stmt_parm(net,1), 3);
		  fprintf(vvp_out, "    %%ix/mov %d, 3; preserve insert index\n",
			  insert_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve insert index X/Z\n",
			  insert_flag);
                  switch (elem_kind) {
                      case IVL_VT_REAL:
                        draw_eval_real(parm2);
			fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
				insert_word);
			fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
				insert_flag);
                        emit_object_queue_insert_("real", max_count, 0);
                        break;
		      case IVL_VT_STRING:
			draw_eval_string(parm2);
			fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
				insert_word);
			fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
				insert_flag);
                        emit_object_queue_insert_("str", max_count, 0);
                        break;
		      case IVL_VT_CLASS:
		      case IVL_VT_DARRAY:
		      case IVL_VT_QUEUE:
                      case IVL_VT_NO_TYPE:
                        draw_queue_element_object_value_(parm2, elem_type);
                        fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
                                insert_word);
                        fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
                                insert_flag);
                        emit_object_queue_insert_("obj", max_count, 0);
                        break;
                      default: {
                        unsigned elem_wid = elem_type
                              ? ivl_type_packed_width(elem_type) : 0;
                        if (elem_wid == 0)
                              elem_wid = ivl_expr_width(parm2);
                        draw_eval_vec4(parm2);
                        fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
                                insert_word);
                        fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
                                insert_flag);
                        emit_object_queue_insert_("v", max_count, elem_wid);
                        break;
                      }
                  }
		  clr_flag(insert_flag);
		  clr_word(insert_word);
		  return 0;
	    }
	    if (!warned_insert_non_signal) {
		  fprintf(stderr, "Warning: insert requires signal, got expr type %d at %s:%u"
			  " (further similar warnings suppressed)\n",
			  ivl_expr_type(parm0), ivl_stmt_file(net), ivl_stmt_lineno(net));
		  warned_insert_non_signal = 1;
	    }
	    return 0;
      }
      ivl_signal_t var = ivl_expr_signal(parm0);
      ivl_type_t var_type = ivl_signal_net_type(var);
      assert(ivl_type_base(var_type) == IVL_VT_QUEUE);

      int idx = allocate_word();
      assert(idx >= 0);
	/* Save the queue maximum index value to an integer register. */
      fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", idx, ivl_signal_array_count(var));

      ivl_type_t element_type = ivl_type_element(var_type);

      ivl_expr_t parm1 = ivl_stmt_parm(net,1);
	/* The %qinsert expects the array index to be in index register 3. */
      draw_eval_expr_into_integer(parm1, 3);
	/* RHS evaluation may use word 3/flag 4 for its own container index.
	 * Preserve the already-evaluated insert position across every value kind
	 * so qinsert observes the source-order parm1 result, not RHS scratch state. */
      int insert_word = allocate_word();
      int insert_flag = allocate_flag();
      fprintf(vvp_out, "    %%ix/mov %d, 3; preserve insert index\n",
	      insert_word);
      fprintf(vvp_out, "    %%flag_mov %d, 4; preserve insert index X/Z\n",
	      insert_flag);
      ivl_expr_t parm2 = ivl_stmt_parm(net,2);
      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    draw_eval_real(parm2);
	    fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
		    insert_word);
	    fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
		    insert_flag);
	    fprintf(vvp_out, "    %%qinsert/real v%p_0, %d;\n",
	            var, idx);
	    break;
	  case IVL_VT_STRING:
	    draw_eval_string(parm2);
	    fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
		    insert_word);
	    fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
		    insert_flag);
	    fprintf(vvp_out, "    %%qinsert/str v%p_0, %d;\n",
	            var, idx);
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    draw_queue_element_object_value_(parm2, element_type);
	    fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
		    insert_word);
	    fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
		    insert_flag);
	    fprintf(vvp_out, "    %%qinsert/obj v%p_0, %d;\n",
	            var, idx);
	    break;
	  default:
	    draw_eval_vec4(parm2);
	    fprintf(vvp_out, "    %%ix/mov 3, %d; restore insert index\n",
		    insert_word);
	    fprintf(vvp_out, "    %%flag_mov 4, %d; restore insert index X/Z\n",
		    insert_flag);
	    fprintf(vvp_out, "    %%qinsert/v v%p_0, %d, %u;\n",
	            var, idx,
	            ivl_type_packed_width(element_type));
	    break;
      }
      clr_flag(insert_flag);
      clr_word(insert_word);
      clr_word(idx);
      return 0;
}

static int show_push_frontback_method(ivl_statement_t net, bool is_front)
{
      static int warned_push_non_signal = 0;
      const char*type_code;
      if (is_front) {
	    show_stmt_file_line(net, "queue: push_front");
	    type_code = "qf";
      } else {
	    show_stmt_file_line(net, "queue: push_back");
	    type_code = "qb";
      }

      unsigned parm_count = ivl_stmt_parm_count(net);
      if (parm_count != 2) {
	    fprintf(stderr, "Warning: push_front/push_back expects 2 parameters at %s:%u; skipping\n",
		    ivl_stmt_file(net), ivl_stmt_lineno(net));
	    return 0;
      }

      ivl_expr_t parm0 = ivl_stmt_parm(net,0);
	      if (ivl_expr_type(parm0) != IVL_EX_SIGNAL
		  || expr_selects_fixed_container_slot_(parm0)) {
            if (show_queue_object_receiver(parm0) == 0) {
                  ivl_expr_t parm1 = ivl_stmt_parm(net,1);
			  if (!parm1) {
				fprintf(stderr,
					"Warning: push_front/push_back missing value expression at %s:%u; skipping\n",
					ivl_stmt_file(net), ivl_stmt_lineno(net));
				return 0;
			  }
			  /* Phase 50d: dispatch based on the QUEUE element type
			   * (parm0's element), not the value-expression type.  An
			   * argument like the string literal "A" is widened to
			   * IVL_VT_LOGIC and would silently take the vec4 store
			   * path, which the runtime then casts to vvp_queue_vec4
			   * and no-ops because the actual storage is
			   * vvp_queue_string.  Pull the element type off parm0
			   * when we have a net_type. */
                  ivl_type_t parm0_type = receiver_container_type_(parm0);
                  ivl_type_t elem_type = parm0_type
                        ? ivl_type_element(parm0_type) : 0;
                  ivl_variable_type_t elem_kind = elem_type
                        ? ivl_type_base(elem_type) : ivl_expr_value(parm1);
                  uint64_t max_count = queue_receiver_max_operand_(
			parm0, parm0_type);
                  switch (elem_kind) {
                      case IVL_VT_REAL:
                        draw_eval_real(parm1);
                        emit_object_queue_store_(type_code[1], "r",
                                                 max_count, 0);
                        break;
                      case IVL_VT_STRING:
                        draw_eval_string(parm1);
                        emit_object_queue_store_(type_code[1], "str",
                                                 max_count, 0);
                        break;
		      case IVL_VT_CLASS:
		      case IVL_VT_DARRAY:
		      case IVL_VT_QUEUE:
		      case IVL_VT_NO_TYPE:
                        draw_queue_element_object_value_(parm1, elem_type);
                        emit_object_queue_store_(type_code[1], "obj",
                                                 max_count, 0);
                        break;
                      default: {
                        unsigned elem_wid = elem_type
                              ? ivl_type_packed_width(elem_type) : 0;
                        if (elem_wid == 0)
                              elem_wid = ivl_expr_width(parm1);
                        draw_eval_vec4(parm1);
                        emit_object_queue_store_(type_code[1], "v",
                                                 max_count, elem_wid);
                        break;
                      }
                  }
		  return 0;
	    }
	    if (!warned_push_non_signal) {
		  fprintf(stderr, "Warning: push_front/push_back requires signal, got expr type %d at %s:%u"
			  " (further similar warnings suppressed)\n",
			  ivl_expr_type(parm0), ivl_stmt_file(net), ivl_stmt_lineno(net));
		  warned_push_non_signal = 1;
	    }
	    return 0;
      }
      ivl_signal_t var = ivl_expr_signal(parm0);
      ivl_type_t var_type = ivl_signal_net_type(var);
      assert(ivl_type_base(var_type) == IVL_VT_QUEUE);

      int idx = allocate_word();
      assert(idx >= 0);
	/* Save the queue maximum index value to an integer register. */
      fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", idx, ivl_signal_array_count(var));

	      ivl_type_t element_type = ivl_type_element(var_type);

	      ivl_expr_t parm1 = ivl_stmt_parm(net,1);
	      if (!parm1) {
		    fprintf(stderr,
			    "Warning: push_front/push_back missing value expression at %s:%u; skipping\n",
			    ivl_stmt_file(net), ivl_stmt_lineno(net));
		    clr_word(idx);
		    return 0;
	      }
	      switch (ivl_type_base(element_type)) {
	  case IVL_VT_REAL:
	    draw_eval_real(parm1);
	    fprintf(vvp_out, "    %%store/%s/r v%p_0, %d;\n",
	            type_code, var, idx);
	    break;
	  case IVL_VT_STRING:
	    draw_eval_string(parm1);
	    fprintf(vvp_out, "    %%store/%s/str v%p_0, %d;\n",
	            type_code, var, idx);
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    draw_queue_element_object_value_(parm1, element_type);
	    fprintf(vvp_out, "    %%store/%s/obj v%p_0, %d;\n",
	            type_code, var, idx);
	    break;
	  default:
	    draw_eval_vec4(parm1);
	    fprintf(vvp_out, "    %%store/%s/v v%p_0, %d, %u;\n",
	            type_code, var, idx,
	            ivl_type_packed_width(element_type));
	    break;
      }
      clr_word(idx);

      return 0;
}

typedef struct iface_call_payload_s {
      ivl_statement_t stmt;
      ivl_expr_t expr;
} iface_call_payload_t;

static unsigned iface_call_parm_count_(const iface_call_payload_t*call)
{
      assert(call && !!call->stmt != !!call->expr);
      return call->stmt ? ivl_stmt_parm_count(call->stmt)
                        : ivl_expr_parms(call->expr);
}

static ivl_expr_t iface_call_parm_(const iface_call_payload_t*call,
                                   unsigned idx)
{
      assert(call && !!call->stmt != !!call->expr);
      return call->stmt ? ivl_stmt_parm(call->stmt, idx)
                        : ivl_expr_parm(call->expr, idx);
}

static const char*iface_call_file_(const iface_call_payload_t*call)
{
      assert(call && !!call->stmt != !!call->expr);
      return call->stmt ? ivl_stmt_file(call->stmt)
                        : ivl_expr_file(call->expr);
}

static unsigned iface_call_lineno_(const iface_call_payload_t*call)
{
      assert(call && !!call->stmt != !!call->expr);
      return call->stmt ? ivl_stmt_lineno(call->stmt)
                        : ivl_expr_lineno(call->expr);
}

/* Return the first user-port index in the instance-keyed argument row for
 * `method'. Statement and expression rows have the same internal form:
 *
 *   receiver, "complete.method.scope", arg0, ..., argN, next-key, ...
 *
 * The scope string is compile-time metadata and is never evaluated. Keeping
 * it in the payload makes row selection independent of traversal order. */
static unsigned find_iface_method_row_(const iface_call_payload_t*call,
                                       ivl_scope_t method)
{
      unsigned nports = ivl_scope_ports(method);
      unsigned port_base = (ivl_scope_type(method) == IVL_SCT_FUNCTION) ? 1 : 0;
      unsigned user_ports = nports >= port_base ? nports - port_base : 0;
      unsigned stride = user_ports + 1;
      unsigned nparms = iface_call_parm_count_(call);
      if (nparms < 2 || ((nparms - 1) % stride) != 0)
            return UINT_MAX;

      const char*method_name_tmp = ivl_scope_name(method);
      if (!method_name_tmp) return UINT_MAX;
      char*method_name = strdup(method_name_tmp);
      assert(method_name);

      unsigned answer = UINT_MAX;
      for (unsigned key_idx = 1 ; key_idx < nparms ; key_idx += stride) {
            ivl_expr_t key = iface_call_parm_(call, key_idx);
            if (!key || ivl_expr_type(key) != IVL_EX_STRING)
                  break;
            if (strcmp(ivl_expr_string(key), method_name) == 0) {
                  answer = key_idx + 1;
                  break;
            }
      }
      free(method_name);
      return answer;
}

typedef enum iface_result_kind_e {
      IFACE_RESULT_INVALID,
      IFACE_RESULT_VOID,
      IFACE_RESULT_VEC4,
      IFACE_RESULT_REAL,
      IFACE_RESULT_STRING,
      IFACE_RESULT_OBJECT
} iface_result_kind_t;

static iface_result_kind_t iface_result_kind_(ivl_variable_type_t type)
{
      switch (type) {
          case IVL_VT_VOID:
            return IFACE_RESULT_VOID;
          case IVL_VT_BOOL:
          case IVL_VT_LOGIC:
            return IFACE_RESULT_VEC4;
          case IVL_VT_REAL:
            return IFACE_RESULT_REAL;
          case IVL_VT_STRING:
            return IFACE_RESULT_STRING;
          case IVL_VT_CLASS:
          case IVL_VT_DARRAY:
          case IVL_VT_QUEUE:
          case IVL_VT_NO_TYPE:
            return IFACE_RESULT_OBJECT;
          default:
            return IFACE_RESULT_INVALID;
      }
}

static void emit_iface_result_fallback_(ivl_expr_t expr)
{
      switch (iface_result_kind_(ivl_expr_value(expr))) {
          case IFACE_RESULT_VEC4:
            fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u; "
                    "malformed virtual-interface function call\n",
                    ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
            break;
          case IFACE_RESULT_REAL:
            fprintf(vvp_out, "    %%pushi/real 0, 0; "
                    "malformed virtual-interface function call\n");
            break;
          case IFACE_RESULT_STRING:
            fprintf(vvp_out, "    %%pushi/str \"\"; "
                    "malformed virtual-interface function call\n");
            break;
          case IFACE_RESULT_OBJECT:
          default:
            fprintf(vvp_out, "    %%null; ; malformed virtual-interface "
                    "function call\n");
            break;
      }
}

/* Emit the argument stores and invocation for one resolved interface method
 * instance. parm_base selects that instance's argument row. A value-returning
 * function leaves exactly one result on its declared typed stack unless the
 * caller asks to discard it. */
static int emit_iface_method_call_(const iface_call_payload_t*call,
                                   ivl_scope_t method, unsigned parm_base,
                                   int keep_result)
{
      if (!method) {
            fprintf(stderr, "%s:%u: vvp.tgt error: missing dynamic "
                    "virtual-interface method scope\n",
                    iface_call_file_(call), iface_call_lineno_(call));
            return 1;
      }

      unsigned nparms = iface_call_parm_count_(call);
      unsigned nports = ivl_scope_ports(method);
      unsigned port_base = (ivl_scope_type(method) == IVL_SCT_FUNCTION) ? 1 : 0;
      unsigned user_ports = nports >= port_base ? nports - port_base : 0;
      ivl_expr_t*argv = user_ports
            ? calloc(user_ports, sizeof(ivl_expr_t)) : 0;
      unsigned char*is_default = user_ports
            ? calloc(user_ports, sizeof(unsigned char)) : 0;
      int vif_function_expr = call->expr
            && ivl_scope_type(method) == IVL_SCT_FUNCTION;
      int errors = 0;

      if ((user_ports && (!argv || !is_default)) || parm_base > nparms
          || user_ports > nparms - parm_base) {
            fprintf(stderr, "%s:%u: vvp.tgt error: malformed argument row "
                    "for virtual-interface method %s\n",
                    iface_call_file_(call), iface_call_lineno_(call),
                    ivl_scope_name(method));
            free(is_default);
            free(argv);
            return 1;
      }

      for (unsigned idx = 0 ; idx < user_ports ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(method, port_base + idx);
            argv[idx] = iface_call_parm_(call, parm_base + idx);
            if (call->expr)
                  is_default[idx] = ivl_expr_vif_parm_is_default(
                        call->expr, parm_base + idx) ? 1 : 0;
	            if (!port || ivl_signal_port(port) == IVL_SIP_NONE) {
	                  fprintf(stderr, "%s:%u: vvp.tgt error: dynamic "
	                          "virtual-interface method %s has an argument "
	                          "without a callable port direction\n",
	                          iface_call_file_(call), iface_call_lineno_(call),
	                          ivl_scope_name(method));
                  errors += 1;
            } else if (call->expr && !argv[idx]) {
                  fprintf(stderr, "%s:%u: vvp.tgt error: dynamic "
                          "virtual-interface function %s has a missing or "
                          "failed-to-elaborate actual argument\n",
                          iface_call_file_(call), iface_call_lineno_(call),
                          ivl_scope_name(method));
                  errors += 1;
            }
      }
      if (errors) {
            free(is_default);
            free(argv);
            return errors;
      }

      const char*method_name = ivl_scope_name(method);
      const char*mangled_tmp = method_name ? vvp_mangle_id(method_name) : 0;
      if (!mangled_tmp) {
            fprintf(stderr, "%s:%u: vvp.tgt error: unnamed dynamic "
                    "virtual-interface method\n",
                    iface_call_file_(call), iface_call_lineno_(call));
            free(is_default);
            free(argv);
            return 1;
      }
      /* vvp_mangle_id() returns reusable storage. Argument lowering may
       * mangle a user-function name, so retain the method label across the
       * draw_eval_* calls below. */
      char*mangled = strdup(mangled_tmp);
      assert(mangled);
      note_td_reference(mangled);

	/* A static interface method can still own explicitly automatic
	   declarations. Dynamic virtual-interface dispatch must allocate the
	   same mixed-lifetime call frame as an ordinary direct call. */
      int needs_call_frame = scope_needs_call_frame(method);
      if (needs_call_frame)
            fprintf(vvp_out, "    %%alloc S_%p;\n", method);
      if (vif_function_expr)
            draw_static_function_setup_begin(method);

      if (vif_function_expr)
            errors += draw_vif_function_input_arguments(
                  method, port_base, user_ports, argv, is_default);
      else
            errors += draw_vif_statement_input_arguments(
                  method, port_base, user_ports, argv);
      if (errors) {
            if (vif_function_expr)
                  draw_static_function_setup_leave(method);
            if (needs_call_frame)
                  fprintf(vvp_out, "    %%free S_%p;\n", method);
            free(is_default);
            free(argv);
            free(mangled);
            return errors;
      }

      if (ivl_scope_type(method) == IVL_SCT_FUNCTION) {
            iface_result_kind_t result_kind = iface_result_kind_(
                  ivl_scope_func_type(method));
            ivl_signal_t retval = nports ? ivl_scope_port(method, 0) : 0;
            if (vif_function_expr)
                  draw_static_function_setup_exec(method);
            switch (result_kind) {
                case IFACE_RESULT_VOID:
                  fprintf(vvp_out, "    %%callf/void TD_%s, S_%p;\n",
                          mangled, method);
                  break;
                case IFACE_RESULT_VEC4:
                  fprintf(vvp_out, "    %%callf/vec4 TD_%s, S_%p;\n",
                          mangled, method);
                  break;
                case IFACE_RESULT_REAL:
                  fprintf(vvp_out, "    %%callf/real TD_%s, S_%p;\n",
                          mangled, method);
                  break;
                case IFACE_RESULT_STRING:
                  fprintf(vvp_out, "    %%callf/str TD_%s, S_%p;\n",
                          mangled, method);
                  break;
                case IFACE_RESULT_OBJECT:
                  fprintf(vvp_out, "    %%callf/obj TD_%s, S_%p;\n",
                          mangled, method);
                  if (retval)
                        fprintf(vvp_out, "    %%load/obj v%p_0;\n", retval);
                  else
                        errors += 1;
                  break;
                default:
                  fprintf(stderr, "%s:%u: vvp.tgt error: unsupported "
                          "return type for virtual-interface function %s\n",
                          iface_call_file_(call), iface_call_lineno_(call),
                          method_name);
                  errors += 1;
                  break;
            }
            if (!keep_result) {
                  switch (result_kind) {
                      case IFACE_RESULT_VEC4:
                        fprintf(vvp_out, "    %%pop/vec4 1;\n");
                        break;
                      case IFACE_RESULT_REAL:
                        fprintf(vvp_out, "    %%pop/real 1;\n");
                        break;
                      case IFACE_RESULT_STRING:
                        fprintf(vvp_out, "    %%pop/str 1;\n");
                        break;
                      case IFACE_RESULT_OBJECT:
                        if (retval)
                              fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
                        break;
                      default:
                        break;
                  }
            }
	      } else {
	            fprintf(vvp_out, "    %%fork TD_%s, S_%p;\n", mangled, method);
	            fprintf(vvp_out, "    %%join;\n");
	      }

	      if (!call->expr)
	            errors += draw_vif_statement_output_arguments(
	                  method, port_base, user_ports, argv);

	      if (vif_function_expr)
            draw_static_function_setup_leave(method);
      if (needs_call_frame)
            fprintf(vvp_out, "    %%free S_%p;\n", method);
      free(is_default);
      free(argv);
      free(mangled);
      return errors;
}

/* Dynamic virtual-interface dispatch through one nested interface instance:
 *
 *   $ivl_vif_nested_call$<outer>$<nested>$<method>(receiver, args...)
 *
 * The receiver is the OUTER virtual-interface handle. Each branch compares
 * that handle with an outer instance, then invokes <method> in its named
 * <nested> child. */
static int show_vif_nested_dyn_call(ivl_statement_t net)
{
      static const char prefix[] = "$ivl_vif_nested_call$";
      iface_call_payload_t call = { net, 0 };
      const char*stmt_name = ivl_stmt_name(net);
      const char*p = stmt_name ? stmt_name + sizeof(prefix) - 1 : 0;
      const char*sep_outer = p ? strchr(p, '$') : 0;
      const char*sep_nested = sep_outer ? strchr(sep_outer + 1, '$') : 0;
      if (!stmt_name
          || strncmp(stmt_name, prefix, sizeof(prefix) - 1) != 0
          || !p || !*p || !sep_outer || sep_outer == p
          || !sep_outer[1] || !sep_nested || sep_nested == sep_outer + 1
          || !sep_nested[1]) {
            fprintf(stderr,
                    "%s:%u: vvp.tgt error: malformed dynamic nested "
                    "virtual-interface task statement %s\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net),
                    stmt_name ? stmt_name : "<unnamed>");
            return 1;
      }

      char outer_name[256];
      size_t outer_len = sep_outer - p;
      if (outer_len >= sizeof(outer_name)) outer_len = sizeof(outer_name) - 1;
      memcpy(outer_name, p, outer_len);
      outer_name[outer_len] = '\0';

      char nested_name[256];
      size_t nested_len = sep_nested - (sep_outer + 1);
      if (nested_len >= sizeof(nested_name))
            nested_len = sizeof(nested_name) - 1;
      memcpy(nested_name, sep_outer + 1, nested_len);
      nested_name[nested_len] = '\0';
      const char*method_name = sep_nested + 1;

      ivl_expr_t recv = (ivl_stmt_parm_count(net) > 0)
            ? ivl_stmt_parm(net, 0) : 0;
      unsigned ninst = ivl_stmt_vif_methods(net);
      if (!recv) {
            fprintf(stderr, "%s:%u: vvp.tgt error: dynamic nested "
                    "virtual-interface task call has no receiver\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            return 1;
      }

      if (ninst == 0) {
            if (ivl_stmt_parm_count(net) != 1) {
                  fprintf(stderr, "%s:%u: vvp.tgt error: candidate-free "
                          "nested virtual-interface task call has argument "
                          "rows\n", ivl_stmt_file(net),
                          ivl_stmt_lineno(net));
                  return 1;
            }
            draw_eval_object(recv);
            fprintf(vvp_out, "    %%vif/fatal;\n");
            return 0;
      }

      unsigned lab_end = local_count++;
      unsigned*lab_inst = calloc(ninst, sizeof(unsigned));
      unsigned*row_base = calloc(ninst, sizeof(unsigned));
      ivl_scope_t*methods = calloc(ninst, sizeof(ivl_scope_t));
      ivl_scope_t*insts = calloc(ninst, sizeof(ivl_scope_t));
      assert(lab_inst);
      assert(row_base);
      assert(methods);
      assert(insts);

      int malformed = 0;
      for (unsigned i = 0 ; i < ninst ; i += 1) {
            methods[i] = ivl_stmt_vif_method(net, i);
            ivl_scope_t nested = methods[i]
                  ? ivl_scope_parent(methods[i]) : 0;
            insts[i] = nested ? ivl_scope_parent(nested) : 0;
            row_base[i] = methods[i]
                  ? find_iface_method_row_(&call, methods[i]) : UINT_MAX;
            if (!methods[i]
                || (ivl_scope_type(methods[i]) != IVL_SCT_TASK
                    && ivl_scope_type(methods[i]) != IVL_SCT_FUNCTION)
                || !ivl_scope_basename(methods[i])
                || strcmp(ivl_scope_basename(methods[i]), method_name) != 0
                || !nested || ivl_scope_type(nested) != IVL_SCT_MODULE
                || !ivl_scope_basename(nested)
                || strcmp(ivl_scope_basename(nested), nested_name) != 0
                || !insts[i] || ivl_scope_type(insts[i]) != IVL_SCT_MODULE
                || !ivl_scope_tname(insts[i])
                || strcmp(ivl_scope_tname(insts[i]), outer_name) != 0
                || row_base[i] == UINT_MAX) {
                  fprintf(stderr,
                          "%s:%u: vvp.tgt error: invalid candidate %u in "
                          "nested virtual-interface task dispatch %s\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net), i,
                          stmt_name);
                  malformed = 1;
            }
      }
      if (malformed) {
            free(methods);
            free(row_base);
            free(lab_inst);
            free(insts);
            return 1;
      }

      draw_eval_object(recv);
      for (unsigned i = 0 ; i < ninst ; i += 1) {
            lab_inst[i] = local_count++;
            fprintf(vvp_out, "    %%jmp/vif T_%u.%u, S_%p;\n",
                    thread_count, lab_inst[i], insts[i]);
      }
      fprintf(vvp_out, "    %%vif/fatal;\n");
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_end);

      for (unsigned i = 0 ; i < ninst ; i += 1) {
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_inst[i]);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            malformed += emit_iface_method_call_(
                  &call, methods[i], row_base[i], 0);
            fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_end);
      }
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_end);

      free(methods);
      free(row_base);
      free(lab_inst);
      free(insts);
      return malformed;
}

/* Dynamic virtual-interface method dispatch:
 *   $ivl_vif_call$<iface>$<method>(receiver, args...)
 * The frontend exports the exact concrete method scopes represented by its
 * keyed argument rows. The receiver handle is evaluated once; a %jmp/vif
 * compare chain branches to the matching candidate instance's argument
 * stores + invocation (IEEE 1800-2023 25.9). */
static int show_vif_dyn_call(ivl_statement_t net)
{
      static const char prefix[] = "$ivl_vif_call$";
      iface_call_payload_t call = { net, 0 };
      const char*stmt_name = ivl_stmt_name(net);
      const char*p = stmt_name ? stmt_name + sizeof(prefix) - 1 : 0;
      const char*sep = p ? strchr(p, '$') : 0;
      if (!stmt_name
          || strncmp(stmt_name, prefix, sizeof(prefix) - 1) != 0
          || !p || !*p || !sep || sep == p || !sep[1]) {
            fprintf(stderr,
                    "%s:%u: vvp.tgt error: malformed dynamic "
                    "virtual-interface task statement %s\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net),
                    stmt_name ? stmt_name : "<unnamed>");
            return 1;
      }
      char iface_name[256];
      size_t ifn_len = sep - p;
      if (ifn_len >= sizeof(iface_name)) ifn_len = sizeof(iface_name) - 1;
      memcpy(iface_name, p, ifn_len);
      iface_name[ifn_len] = '\0';
      const char*method_name = sep + 1;

      ivl_expr_t recv = (ivl_stmt_parm_count(net) > 0)
            ? ivl_stmt_parm(net, 0) : 0;
      unsigned ninst = ivl_stmt_vif_methods(net);
      if (!recv) {
            fprintf(stderr, "%s:%u: vvp.tgt error: dynamic "
                    "virtual-interface task call has no receiver\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            return 1;
      }

      if (ninst == 0) {
            if (ivl_stmt_parm_count(net) != 1) {
                  fprintf(stderr, "%s:%u: vvp.tgt error: candidate-free "
                          "virtual-interface task call has argument rows\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net));
                  return 1;
            }
            draw_eval_object(recv);
            fprintf(vvp_out, "    %%vif/fatal;\n");
            return 0;
      }

      unsigned lab_end = local_count++;
      unsigned*lab_inst = calloc(ninst, sizeof(unsigned));
      unsigned*row_base = calloc(ninst, sizeof(unsigned));
      ivl_scope_t*methods = calloc(ninst, sizeof(ivl_scope_t));
      ivl_scope_t*insts = calloc(ninst, sizeof(ivl_scope_t));
      assert(lab_inst);
      assert(row_base);
      assert(methods);
      assert(insts);

      int malformed = 0;
      for (unsigned i = 0 ; i < ninst ; i += 1) {
            methods[i] = ivl_stmt_vif_method(net, i);
            insts[i] = methods[i] ? ivl_scope_parent(methods[i]) : 0;
            row_base[i] = methods[i]
                  ? find_iface_method_row_(&call, methods[i]) : UINT_MAX;
            if (!methods[i]
                || (ivl_scope_type(methods[i]) != IVL_SCT_TASK
                    && ivl_scope_type(methods[i]) != IVL_SCT_FUNCTION)
                || !ivl_scope_basename(methods[i])
                || strcmp(ivl_scope_basename(methods[i]), method_name) != 0
                || !insts[i] || ivl_scope_type(insts[i]) != IVL_SCT_MODULE
                || !ivl_scope_tname(insts[i])
                || strcmp(ivl_scope_tname(insts[i]), iface_name) != 0
                || row_base[i] == UINT_MAX) {
                  fprintf(stderr,
                          "%s:%u: vvp.tgt error: invalid candidate %u in "
                          "virtual-interface task dispatch %s\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net), i,
                          stmt_name);
                  malformed = 1;
            }
      }
      if (malformed) {
            free(methods);
            free(row_base);
            free(lab_inst);
            free(insts);
            return 1;
      }

      draw_eval_object(recv);
      for (unsigned i = 0 ; i < ninst ; i += 1) {
            lab_inst[i] = local_count++;
            fprintf(vvp_out, "    %%jmp/vif T_%u.%u, S_%p;\n",
                    thread_count, lab_inst[i], insts[i]);
      }
        /* No branch taken: IEEE 1800-2023 25.9 requires a fatal run-time
         * error for a null virtual interface. A nonmatching typed handle is
         * likewise invalid for this call site and follows the same boundary. */
      fprintf(vvp_out, "    %%vif/fatal;\n");
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_end);

      for (unsigned i = 0 ; i < ninst ; i += 1) {
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_inst[i]);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            malformed += emit_iface_method_call_(
                  &call, methods[i], row_base[i], 0);
            fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_end);
      }
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_end);
      free(methods);
      free(row_base);
      free(lab_inst);
      free(insts);
      return malformed;
}

/* Lower a value-returning dynamic virtual-interface call carried by the
 * internal system-function marker:
 *
 *   $ivl_vif_func$<interface>$<method>
 *
 * The expression exports the exact concrete method scopes represented by
 * its keyed argument rows. This is important for parameter-specialized
 * interface instances: rediscovering them from a definition name can select
 * the wrong signature. The receiver is evaluated once, %jmp/vif chooses the
 * concrete instance, and every successful branch leaves one value on the
 * expression's declared typed stack. */
int draw_vif_function_call(ivl_expr_t expr)
{
      static const char prefix[] = "$ivl_vif_func$";
      const char*name = ivl_expr_name(expr);
      const char*encoded = name ? name + sizeof(prefix) - 1 : 0;
      const char*separator = encoded ? strchr(encoded, '$') : 0;
      iface_call_payload_t call = { 0, expr };
      unsigned nparms = ivl_expr_parms(expr);
      unsigned nmethods = ivl_expr_vif_methods(expr);
      ivl_expr_t recv = nparms ? ivl_expr_parm(expr, 0) : 0;
      iface_result_kind_t want_kind = iface_result_kind_(
            ivl_expr_value(expr));
      int errors = 0;

      if (!name || strncmp(name, prefix, sizeof(prefix) - 1) != 0
          || !encoded || !*encoded || !separator || separator == encoded
          || !separator[1] || !recv
          || want_kind == IFACE_RESULT_VOID
          || want_kind == IFACE_RESULT_INVALID) {
            fprintf(stderr, "%s:%u: vvp.tgt error: malformed dynamic "
                    "virtual-interface function expression %s\n",
                    ivl_expr_file(expr), ivl_expr_lineno(expr),
                    name ? name : "<unnamed>");
            emit_iface_result_fallback_(expr);
            return 1;
      }

      /* With no concrete interface instance the frontend deliberately emits
       * a receiver-only payload. Evaluating it still preserves side effects;
       * every runtime value necessarily reaches the required fatal path. */
      if (nmethods == 0) {
            if (nparms != 1) {
                  fprintf(stderr, "%s:%u: vvp.tgt error: candidate-free "
                          "virtual-interface function call has argument rows\n",
                          ivl_expr_file(expr), ivl_expr_lineno(expr));
                  emit_iface_result_fallback_(expr);
                  return 1;
            }
            errors += draw_eval_object(recv);
            fprintf(vvp_out, "    %%vif/fatal;\n");
            return errors;
      }

      ivl_scope_t*methods = calloc(nmethods, sizeof(ivl_scope_t));
      ivl_scope_t*dispatch_scopes = calloc(nmethods, sizeof(ivl_scope_t));
      unsigned*row_base = calloc(nmethods, sizeof(unsigned));
      unsigned*lab_method = calloc(nmethods, sizeof(unsigned));
      if (!methods || !dispatch_scopes || !row_base || !lab_method) {
            fprintf(stderr, "%s:%u: vvp.tgt error: unable to allocate "
                    "virtual-interface function dispatch table\n",
                    ivl_expr_file(expr), ivl_expr_lineno(expr));
            free(lab_method);
            free(row_base);
            free(dispatch_scopes);
            free(methods);
            emit_iface_result_fallback_(expr);
            return 1;
      }

      for (unsigned idx = 0 ; idx < nmethods ; idx += 1) {
            ivl_signal_t retval;
            unsigned nports;
            unsigned user_ports;

            methods[idx] = ivl_expr_vif_method(expr, idx);
            dispatch_scopes[idx] = methods[idx]
                  ? ivl_scope_parent(methods[idx]) : 0;
            row_base[idx] = methods[idx]
                  ? find_iface_method_row_(&call, methods[idx]) : UINT_MAX;

            if (!methods[idx]
                || ivl_scope_type(methods[idx]) != IVL_SCT_FUNCTION
                || !ivl_scope_name(methods[idx])
                || !dispatch_scopes[idx]
                || ivl_scope_type(dispatch_scopes[idx]) != IVL_SCT_MODULE
                || row_base[idx] == UINT_MAX
                || iface_result_kind_(ivl_scope_func_type(methods[idx]))
                     != want_kind) {
                  fprintf(stderr, "%s:%u: vvp.tgt error: invalid candidate "
                          "%u in virtual-interface function dispatch %s\n",
                          ivl_expr_file(expr), ivl_expr_lineno(expr), idx,
                          name);
                  errors += 1;
                  continue;
            }

            nports = ivl_scope_ports(methods[idx]);
            retval = nports ? ivl_scope_port(methods[idx], 0) : 0;
            user_ports = nports ? nports - 1 : 0;
            if (!retval || ivl_signal_dimensions(retval) != 0
                || row_base[idx] > nparms
                || user_ports > nparms - row_base[idx]
                || (want_kind == IFACE_RESULT_VEC4
                    && ivl_signal_width(retval) != ivl_expr_width(expr))) {
                  fprintf(stderr, "%s:%u: vvp.tgt error: incompatible "
                          "return or argument row for virtual-interface "
                          "function %s\n",
                          ivl_expr_file(expr), ivl_expr_lineno(expr),
                          ivl_scope_name(methods[idx]));
                  errors += 1;
                  continue;
            }

            for (unsigned arg = 0 ; arg < user_ports ; arg += 1) {
                  ivl_signal_t port = ivl_scope_port(methods[idx], arg + 1);
                  if (!port || ivl_signal_port(port) != IVL_SIP_INPUT
                      || !iface_call_parm_(&call, row_base[idx] + arg)) {
                        fprintf(stderr, "%s:%u: vvp.tgt error: dynamic "
                                "virtual-interface function %s requires "
                                "input-only arguments\n",
                                ivl_expr_file(expr), ivl_expr_lineno(expr),
                                ivl_scope_name(methods[idx]));
                        errors += 1;
                        break;
                  }
            }
      }

      if (errors) {
            free(lab_method);
            free(row_base);
            free(dispatch_scopes);
            free(methods);
            emit_iface_result_fallback_(expr);
            return errors;
      }

      unsigned lab_end = local_count++;
      errors += draw_eval_object(recv);
      for (unsigned idx = 0 ; idx < nmethods ; idx += 1) {
            lab_method[idx] = local_count++;
            fprintf(vvp_out, "    %%jmp/vif T_%u.%u, S_%p;\n",
                    thread_count, lab_method[idx], dispatch_scopes[idx]);
      }
      fprintf(vvp_out, "    %%vif/fatal;\n");
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_end);

      for (unsigned idx = 0 ; idx < nmethods ; idx += 1) {
            int branch_errors;
            fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_method[idx]);
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            branch_errors = emit_iface_method_call_(
                  &call, methods[idx], row_base[idx], 1);
            errors += branch_errors;
            if (branch_errors)
                  emit_iface_result_fallback_(expr);
            fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_end);
      }
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_end);

      free(lab_method);
      free(row_base);
      free(dispatch_scopes);
      free(methods);
      return errors;
}

static long deferred_final_task_marker_id_(ivl_statement_t net)
{
      ivl_expr_t expr;
      if (ivl_stmt_parm_count(net) != 1)
            return -1;
      expr = ivl_stmt_parm(net, 0);
      if (!expr || ivl_expr_type(expr) != IVL_EX_NUMBER
          || !number_is_immediate(expr, 32, 0)
          || number_is_unknown(expr))
            return -1;
      return get_number_immediate(expr);
}

static int show_deferred_final_task_marker_(ivl_statement_t net,
                                             ivl_scope_t sscope)
{
      const char*name = ivl_stmt_name(net);
      const int is_begin = strcmp(name,
            "$ivl_deferred_final_task_begin") == 0;
      long source_id = deferred_final_task_marker_id_(net);

      if (source_id <= 0 || !sscope) {
            fprintf(stderr,
                    "%s:%u: error: malformed internal %s marker; expected "
                    "one positive source id and a lexical scope.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net), name);
            vvp_errors += 1;
            return 1;
      }

      if (is_begin) {
            if (deferred_final_task_frame_.active) {
                  fprintf(stderr,
                          "%s:%u: error: malformed nested internal "
                          "final-deferred user-task thunk.\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net));
                  vvp_errors += 1;
                  deferred_final_task_frame_.phase = 2;
                  return 1;
            }

            memset(&deferred_final_task_frame_, 0,
                   sizeof deferred_final_task_frame_);
            deferred_final_task_frame_.active = 1;
            deferred_final_task_frame_.source_id = source_id;
            deferred_final_task_frame_.action_scope = sscope;
            deferred_final_task_frame_.action_lab = local_count++;
            deferred_final_task_frame_.after_lab = local_count++;

            show_stmt_file_line(net,
                                "Final deferred user-task assertion pin.");
            fprintf(vvp_out, "    %%defer/final T_%u.%u, S_%p;\n",
                    thread_count, deferred_final_task_frame_.action_lab,
                    sscope);
            fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count,
                    deferred_final_task_frame_.after_lab);
            fprintf(vvp_out, "T_%u.%u ;\n", thread_count,
                    deferred_final_task_frame_.action_lab);
            fprintf(vvp_out, "    %%defer/final/taskkey %ld;\n",
                    source_id);
            return 0;
      }

      if (!deferred_final_task_frame_.active) {
            fprintf(stderr,
                    "%s:%u: error: internal final-deferred user-task end "
                    "marker has no matching begin marker.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            vvp_errors += 1;
            return 1;
      }

      int rc = 0;
      if (deferred_final_task_frame_.source_id != source_id) {
            fprintf(stderr,
                    "%s:%u: error: internal final-deferred user-task marker "
                    "source ids do not match.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            vvp_errors += 1;
            rc = 1;
      } else if (deferred_final_task_frame_.phase == 0) {
            fprintf(stderr,
                    "%s:%u: error: internal final-deferred user-task thunk "
                    "contains no resolved task call.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            vvp_errors += 1;
            rc = 1;
      } else if (deferred_final_task_frame_.phase == 1
                 && deferred_final_task_frame_.saw_alloc
                 != deferred_final_task_frame_.saw_free) {
            fprintf(stderr,
                    "%s:%u: error: internal final-deferred automatic-task "
                    "thunk has an unbalanced alloc/free pair.\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net));
            vvp_errors += 1;
            rc = 1;
      }

      fprintf(vvp_out, "    %%end;\n");
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count,
              deferred_final_task_frame_.after_lab);
      memset(&deferred_final_task_frame_, 0,
             sizeof deferred_final_task_frame_);
      return rc;
}

static int show_deferred_assert_enqueue_(ivl_statement_t net,
                                         ivl_scope_t sscope)
{
      const char*marker_name = ivl_stmt_name(net);
      int final_marker = strcmp(marker_name,
                                "$ivl_deferred_final_enqueue") == 0;
      unsigned parm_count = ivl_stmt_parm_count(net);
      ivl_expr_t mode_expr = parm_count > 0 ? ivl_stmt_parm(net, 0) : 0;
      ivl_expr_t source_expr = parm_count > 1 ? ivl_stmt_parm(net, 1) : 0;
      ivl_expr_t assertion_kind_expr = parm_count > 2
	    ? ivl_stmt_parm(net, 2) : 0;
      ivl_expr_t kind_expr = parm_count > 3 ? ivl_stmt_parm(net, 3) : 0;
      long mode = -1;
      long source_id = -1;
      long assertion_kind = -1;
      long kind = -1;

      if (mode_expr && ivl_expr_type(mode_expr) == IVL_EX_NUMBER
          && number_is_immediate(mode_expr, 32, 0)
          && !number_is_unknown(mode_expr))
            mode = get_number_immediate(mode_expr);

      if (source_expr && ivl_expr_type(source_expr) == IVL_EX_NUMBER
          && number_is_immediate(source_expr, 32, 0)
          && !number_is_unknown(source_expr))
            source_id = get_number_immediate(source_expr);

      if (assertion_kind_expr
	  && ivl_expr_type(assertion_kind_expr) == IVL_EX_NUMBER
	  && number_is_immediate(assertion_kind_expr, 32, 0)
	  && !number_is_unknown(assertion_kind_expr))
	    assertion_kind = get_number_immediate(assertion_kind_expr);

      if (kind_expr && ivl_expr_type(kind_expr) == IVL_EX_NUMBER
          && number_is_immediate(kind_expr, 32, 0)
          && !number_is_unknown(kind_expr))
            kind = get_number_immediate(kind_expr);

      if ((final_marker && mode != 1) || (!final_marker && mode != 0))
            kind = -1;

      if (assertion_kind != 1 && assertion_kind != 2
	  && assertion_kind != 4)
	    kind = -1;

      if (kind == 0) {
	    if (parm_count != 4)
                  kind = -1;
      } else if (kind == 1) {
            if (parm_count < 4)
                  kind = -1;
      } else if (kind == 2) {
            if (parm_count < 4)
                  kind = -1;
      } else {
            kind = -1;
      }

      if ((mode != 0 && mode != 1) || source_id <= 0
          || kind < 0 || !sscope) {
            fprintf(stderr,
                    "%s:%u: error: malformed internal "
                    "%s marker; expected a marker-consistent "
                    "mode, positive source id, and action kind 0 "
                    "(null), 1 ($error), or 2 ($display).\n",
                    ivl_stmt_file(net), ivl_stmt_lineno(net), marker_name);
            vvp_errors += 1;
            return 1;
      }

      fprintf(vvp_out,
	      "    %%defer/register \"%ld,%ld,%u,%u\", S_%p;\n",
	      source_id, assertion_kind,
	      ivl_file_table_index(ivl_stmt_file(net)), ivl_stmt_lineno(net),
	      sscope);

      /* Action arguments must be evaluated by the source process and captured
       * before either pending report is queued. The shared VPI lowering emits
       * a typed-stack action thunk and validates the complete argument list
       * before evaluating any expression. */
      if (kind != 0) {
            show_stmt_file_line(net,
                  final_marker ? "Final deferred immediate assertion pin."
                               : "Deferred immediate assertion enqueue.");
            return draw_vpi_deferred_call(net, 4,
                                          kind == 1 ? "$error" : "$display",
                                          source_id, sscope, final_marker);
      }

      /* A selected #0 null arm queues no action. A final null arm must still
       * pin its source id so it can cancel an earlier non-null selection. */
      if (mode == 0)
            return 0;

      unsigned action_lab = local_count++;
      unsigned after_lab = local_count++;

      show_stmt_file_line(net, "Final deferred immediate assertion pin.");
      fprintf(vvp_out, "    %%defer/final T_%u.%u, S_%p;\n",
              thread_count, action_lab, sscope);
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, after_lab);

      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, action_lab);
      fprintf(vvp_out, "    %%defer/final/key %ld;\n", source_id);
      fprintf(vvp_out, "    %%end;\n");
      fprintf(vvp_out, "T_%u.%u ;\n", thread_count, after_lab);

      return 0;
}

static int show_system_task_call(ivl_statement_t net, ivl_scope_t sscope)
{
      const char*stmt_name = ivl_stmt_name(net);

      if (strcmp(stmt_name, "$ivl_wait_event_triggered_change") == 0) {
	    if (ivl_stmt_parm_count(net) != 1
		|| ivl_expr_type(ivl_stmt_parm(net, 0)) != IVL_EX_EVENT) {
		  fprintf(stderr, "%s:%u: internal error: malformed triggered "
		          "event wait.\n", ivl_stmt_file(net),
		          ivl_stmt_lineno(net));
		  return 1;
	    }
	    show_stmt_file_line(net, "Named-event triggered property wait.");
	    fprintf(vvp_out, "    %%wait/triggered E_%p;\n",
		    ivl_expr_event(ivl_stmt_parm(net, 0)));
	    return 0;
      }

	/* IEEE 1800-2017/2023 8.19. This compiler-generated guard surrounds
	 * one authorized source assignment before that assignment is lowered
	 * into any element-wise stores. The receiver is always the constructor's
	 * implicit this object; %prop/const/init consumes it and test-and-sets the
	 * absolute property ID on that object. */
      if (strcmp(stmt_name, "$ivl_instance_const_init") == 0) {
	    if (ivl_stmt_parm_count(net) != 2
		|| ivl_expr_type(ivl_stmt_parm(net, 1)) != IVL_EX_NUMBER) {
		  fprintf(stderr, "%s:%u: internal error: malformed instance "
			  "constant assignment guard.\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 1;
	    }
	    show_stmt_file_line(net, "Instance constant initialization guard.");
	    int errors = draw_eval_object(ivl_stmt_parm(net, 0));
	    fprintf(vvp_out, "    %%prop/const/init %lu;\n",
		    ivl_expr_uvalue(ivl_stmt_parm(net, 1)));
	    return errors;
      }

	/* A queue-valued function used as a statement still evaluates the
	 * expression, but discards its result. In particular, unique() is a
	 * 7.12.1 locator and must not mutate its receiver. */
      if (strcmp(stmt_name, "$ivl_discard_object_expr") == 0) {
	    if (ivl_stmt_parm_count(net) != 1)
		  return 0;
	    draw_eval_object(ivl_stmt_parm(net, 0));
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    return 0;
      }

      if (strcmp(stmt_name, "$ivl_deferred_enqueue") == 0
          || strcmp(stmt_name, "$ivl_deferred_final_enqueue") == 0)
            return show_deferred_assert_enqueue_(net, sscope);

      if (strcmp(stmt_name, "$ivl_deferred_final_task_begin") == 0
          || strcmp(stmt_name, "$ivl_deferred_final_task_end") == 0)
            return show_deferred_final_task_marker_(net, sscope);

      if (strncmp(stmt_name, "$ivl_std_randomize_with|", 24) == 0) {
	      /* Task-form sibling of the expression lowering in
	       * eval_vec4.c. The runtime solves once; successful model
	       * values are copied back with the normal signal store. */
	    const char*rest = stmt_name + 24;
	    unsigned n_rand = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    unsigned n_vals = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    unsigned n_objs = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    const char*ir = rest;
	    ivl_expr_t first = n_rand ? ivl_stmt_parm(net, 0) : 0;
	    ivl_type_t dest_type = first ? ivl_expr_net_type(first) : 0;
	    if (!dest_type && first && ivl_expr_signal(first))
		  dest_type = ivl_signal_net_type(ivl_expr_signal(first));
	      /* A dynamic array uses the same container solver as a
	       * queue, with no declared maximum (IEEE 1800-2017 18.12). */
	    int queue_dest = dest_type
		&& ((ivl_type_base(dest_type) == IVL_VT_QUEUE
		     && !ivl_type_queue_assoc_compat(dest_type))
		    || ivl_type_base(dest_type) == IVL_VT_DARRAY);
	    ivl_type_t elem_type = queue_dest
		? ivl_type_element(dest_type) : 0;

	    for (unsigned i = 0 ; i < n_rand ; i++)
		  if (queue_dest) draw_eval_object(ivl_stmt_parm(net, i));
		  else draw_eval_vec4(ivl_stmt_parm(net, i));
	    for (unsigned i = 0 ; i < n_vals ; i++)
		  draw_eval_vec4(ivl_stmt_parm(net, n_rand + i));
	    for (unsigned i = 0 ; i < n_objs ; i++)
		  draw_eval_object(ivl_stmt_parm(net, n_rand + n_vals + i));
	    unsigned packed_slots = (n_objs << 16) | (n_vals & 0xffffu);
	    if (queue_dest)
		  fprintf(vvp_out,
		    "    %%std/randomize/queue/with \"%u|%llu|%s\", %u, %u;\n",
		    ivl_type_packed_width(elem_type),
		    (unsigned long long)(ivl_type_base(dest_type) == IVL_VT_QUEUE
					 ? ivl_type_queue_max_size(dest_type) : 0),
		    ir, n_vals, n_objs);
	    else
		  fprintf(vvp_out, "    %%std/randomize/with \"%s\", %u, %u;\n",
		    ir, n_rand, packed_slots);

	    unsigned lab_done = local_count++;
	    int success_flag = allocate_flag();
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    fprintf(vvp_out, "    %%flag_set/vec4 %d;\n", success_flag);
	    fprintf(vvp_out, "    %%jmp/0 T_%u.%u, %d;\n",
		    thread_count, lab_done, success_flag);
	    for (unsigned i = 0 ; i < n_rand ; i++) {
		  ivl_expr_t var = ivl_stmt_parm(net, i);
		  ivl_signal_t sig = var ? ivl_expr_signal(var) : 0;
		  unsigned wid = var ? ivl_expr_width(var) : 0;
		  if (!sig || ivl_expr_type(var) != IVL_EX_SIGNAL) {
			fprintf(stderr, "%s:%u: vvp.tgt error: unsupported "
				"std::randomize task destination; solver result "
				"not stored.\\n",
				ivl_stmt_file(net), ivl_stmt_lineno(net));
			continue;
		  }
		  fprintf(vvp_out, queue_dest
		    ? "    %%std/randomize/load/obj %u;\n"
		    : "    %%std/randomize/load %u;\n", i);
		  if (queue_dest)
		    fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
		  else if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", wid);
		  else
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
				sig, wid);
	    }
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_done);
	    clr_flag(success_flag);
	    fprintf(vvp_out, "    %%pop/vec4 1;\n");
	    return 0;
      }

      if (strncmp(stmt_name, "$ivl_vif_call$", 14) == 0)
	    return show_vif_dyn_call(net);

      if (strncmp(stmt_name, "$ivl_vif_nested_call$", 21) == 0)
	    return show_vif_nested_dyn_call(net);

	/* Suspend until the Observed region of the current time step
	 * (14.4 numeric input skews: sample the settled value). */
      if (strcmp(stmt_name,"$ivl_observed_wait") == 0) {
	    fprintf(vvp_out, "    %%wait/observed;\n");
	    return 0;
      }

	/* Suspend until the Reactive region of the current time step
	 * (4.4.2.5: assertion pass/fail action blocks).  A no-op once no
	 * Reactive region is reachable (final blocks / Postponed), so an
	 * end-of-simulation verdict is never dropped. */
      if (strcmp(stmt_name,"$ivl_reactive_wait") == 0) {
	    fprintf(vvp_out, "    %%wait/reactive;\n");
	    return 0;
      }

	/* IEEE 1800-2017/2023 13.4.4: check a function's caller before
	 * executing a deferred side effect. */
      if (strcmp(stmt_name,"$ivl_function_background_guard") == 0) {
	    fprintf(vvp_out, "    %%function/deferred/check;\n");
	    return 0;
      }

	/* A synthesized assertion-action dispatcher is permanently a
	 * Reactive-region process. Its delayed/event-controlled continuations
	 * and detached action children inherit that affinity. */
      if (strcmp(stmt_name,"$ivl_reactive_process") == 0) {
	    fprintf(vvp_out, "    %%reactive/process;\n");
	    return 0;
      }

	/* Clocking input sampling prologue (14.13): enable the 1-deep
	 * driven-value history on the raw signal so %load/preponed
	 * (from $ivl_clocking_sample) returns the Preponed value. */
      if (strcmp(stmt_name,"$ivl_clocking_hist_on") == 0) {
	    ivl_expr_t parm0 = (ivl_stmt_parm_count(net) > 0)
		  ? ivl_stmt_parm(net, 0) : 0;
	    ivl_expr_t hist_expr = parm0;
	    ivl_signal_t hsig = 0;
	      /* A direct packed member is represented as a SELECT over the
		 underlying signal. History belongs to that whole signal because
		 $ivl_clocking_sample reads it before applying the same select.
		 Stop at SIGNAL: its oper1 is an unpacked-array word index, not
		 another expression wrapper. */
	    while (hist_expr && ivl_expr_type(hist_expr) == IVL_EX_SELECT)
		  hist_expr = ivl_expr_oper1(hist_expr);
	      /* A bare unpacked-array name arrives as IVL_EX_ARRAY, not
		 IVL_EX_SIGNAL. */
	    if (hist_expr && (ivl_expr_type(hist_expr) == IVL_EX_SIGNAL
			       || ivl_expr_type(hist_expr) == IVL_EX_ARRAY))
		  hsig = ivl_expr_signal(hist_expr);
	    if (hsig) {
		    /* R11: an unpacked array carries per-word history, so
		       it needs the array form of the enable. */
		  if (ivl_signal_dimensions(hsig) > 0) {
			note_array_signal_use(hsig);
			fprintf(vvp_out, "    %%hist/on/av v%p;\n", hsig);
		  } else {
			fprintf(vvp_out, "    %%hist/on v%p_0;\n", hsig);
		  }
	    }
	    return 0;
      }

      if (strcmp(stmt_name,"$ivl_darray_method$delete") == 0)
	    return show_delete_method(net);

      if (strcmp(stmt_name,"$ivl_queue_method$insert") == 0)
	    return show_insert_method(net);

      if (strcmp(stmt_name,"$ivl_queue_method$push_front") == 0)
	    return show_push_frontback_method(net, true);

      if (strcmp(stmt_name,"$ivl_queue_method$push_back") == 0)
	    return show_push_frontback_method(net, false);

	/* Ordering methods on STATIC unpacked arrays (7.12.2):
	 * $ivl_uarray_method$order(array_signal, mode) -> %uarr/order.
	 * mode&3: 0 sort, 1 rsort, 2 reverse, 3 shuffle; mode&4 signed. */
      if (strcmp(stmt_name,"$ivl_uarray_method$order") == 0) {
	    ivl_expr_t parm0 = (ivl_stmt_parm_count(net) > 0)
		  ? ivl_stmt_parm(net, 0) : 0;
	    ivl_expr_t parm1 = (ivl_stmt_parm_count(net) > 1)
		  ? ivl_stmt_parm(net, 1) : 0;
	    ivl_signal_t sig = 0;
	    if (parm0 && parm1 && ivl_expr_type(parm1) == IVL_EX_NUMBER
		&& ivl_expr_type(parm0) == IVL_EX_SELECT) {
		ivl_expr_t map = ivl_expr_oper1(parm0);
		ivl_expr_t key = ivl_expr_oper2(parm0);
		ivl_type_t assoc = property_assoc_container_type_(map);
		ivl_type_t child = assoc ? ivl_type_element(assoc) : 0;
		ivl_type_t elem = child ? ivl_type_element(child) : 0;
		unsigned mode = ivl_expr_uvalue(parm1) & 3;
		if (map && ivl_expr_type(map) == IVL_EX_PROPERTY
		    && !ivl_expr_oper1(map) && key
		    && child && type_is_fixed_uarray_property_(child)
		    && ivl_type_packed_dimensions(child) == 1
		    && elem && (ivl_type_base(elem) == IVL_VT_BOOL
				|| ivl_type_base(elem) == IVL_VT_LOGIC)
		    && (mode == 2 || mode == 3)) {
		    /* The selected fixed child is a live vvp_darray value. Vivify
		     * before ordering so a missing key gets private stored storage. */
		    draw_eval_object(map);
		    const char*key_kind = draw_eval_assoc_key_(key, 0);
		    fprintf(vvp_out, "    %%aa/viv/o/%s %u;\n", key_kind,
			    strcmp(key_kind, "obj") == 0 ? 25U : 17U);
		    fprintf(vvp_out, "    %s;\n",
			    mode == 2 ? "%qreverse/o" : "%qshuffle/o");
		    return 0;
		}
	    }
	      /* A whole one-dimensional fixed unpacked array that is a class
	       * property: order a by-value darray image of its words and store
	       * it back, so the property itself is reordered (7.12.2). */
	    if (parm0 && parm1 && ivl_expr_type(parm1) == IVL_EX_NUMBER
		&& ivl_expr_type(parm0) == IVL_EX_PROPERTY
		&& !ivl_expr_oper1(parm0)
		&& (ivl_expr_signal(parm0) || ivl_expr_oper2(parm0))) {
		  ivl_type_t ptype = property_expr_type_(parm0);
		  ivl_type_t elem = ptype && type_is_fixed_uarray_property_(ptype)
			&& ivl_type_packed_dimensions(ptype) == 1
			? ivl_type_element(ptype) : 0;
		  if (elem && (ivl_type_base(elem) == IVL_VT_BOOL
			       || ivl_type_base(elem) == IVL_VT_LOGIC)) {
			unsigned long mode_bits = ivl_expr_uvalue(parm1);
			unsigned mode = mode_bits & 3;
			int sflag = (mode_bits & 4) ? 1 : 0;
			unsigned pidx = ivl_expr_property_idx(parm0);
			unsigned lab_null = local_count++;
			unsigned lab_done = local_count++;
			if (ivl_expr_signal(parm0))
			      fprintf(vvp_out, "    %%load/obj v%p_0;\n",
				      ivl_expr_signal(parm0));
			else
			      draw_eval_object(ivl_expr_oper2(parm0));
			fprintf(vvp_out, "    %%test_nul/obj;\n");
			fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
				thread_count, lab_null);
			fprintf(vvp_out, "    %%prop/arr/dar %u; order fixed property array\n",
				pidx);
			  /* The order opcodes consume their receiver: order an
			     aliasing reference and keep the array for the store. */
			fprintf(vvp_out, "    %%dup/obj/ref;\n");
			if (mode == 0)
			      fprintf(vvp_out, "    %%qsort/o %d;\n", sflag);
			else if (mode == 1)
			      fprintf(vvp_out, "    %%qsort/r/o %d;\n", sflag);
			else if (mode == 2)
			      fprintf(vvp_out, "    %%qreverse/o;\n");
			else
			      fprintf(vvp_out, "    %%qshuffle/o;\n");
			fprintf(vvp_out, "    %%store/prop/arr/dar %u;\n", pidx);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_done);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_done);
			return 0;
		  }
	    }
	    if (parm0 && (ivl_expr_type(parm0) == IVL_EX_SIGNAL
			  || ivl_expr_type(parm0) == IVL_EX_ARRAY))
		  sig = ivl_expr_signal(parm0);
	    if (!sig || !parm1 || ivl_expr_type(parm1) != IVL_EX_NUMBER) {
		  static int warned_uarr = 0;
		  if (!warned_uarr) {
			fprintf(stderr, "Warning: %s on an unsupported"
				" receiver shape; skipping (further similar"
				" warnings suppressed)\n", stmt_name);
			warned_uarr = 1;
		  }
		  return 0;
	    }
	    note_array_signal_use(sig);
	    fprintf(vvp_out, "    %%uarr/order v%p, %lu;\n",
		    sig, ivl_expr_uvalue(parm1));
	    return 0;
      }

      if (strcmp(stmt_name,"$ivl_queue_method$sort") == 0
	  || strcmp(stmt_name,"$ivl_queue_method$rsort") == 0
	  || strcmp(stmt_name,"$ivl_queue_method$unique") == 0
	  || strcmp(stmt_name,"$ivl_queue_method$reverse") == 0
	  || strcmp(stmt_name,"$ivl_queue_method$shuffle") == 0) {
	    ivl_expr_t parm0 = (ivl_stmt_parm_count(net) > 0)
		  ? ivl_stmt_parm(net, 0) : 0;
	    ivl_signal_t sig = 0;
	    int object_receiver = 0;
	    if (parm0 && ivl_expr_type(parm0) == IVL_EX_SIGNAL
		&& ivl_expr_signal(parm0)
		&& !expr_selects_fixed_container_slot_(parm0)) {
		  sig = ivl_expr_signal(parm0);
	    } else if (parm0 && show_queue_object_receiver(parm0) == 0) {
		    /* A queue/darray property or nested selection is a value
		       receiver, not a handle alias.  Storing it in the hidden
		       scratch signal invokes the normal value-copy boundary, so an
		       in-place signal opcode would reorder only the copy. Keep the
		       evaluated receiver (and its mutation provenance) on the object
		       stack and use the object form of the ordering opcode. */
		  object_receiver = 1;
	    } else {
		  static int warned_recv = 0;
		  if (!warned_recv) {
			fprintf(stderr, "Warning: %s on an unsupported"
				" receiver shape; skipping (further similar"
				" warnings suppressed)\n", stmt_name);
			warned_recv = 1;
		  }
		  return 0;
	    }
	    const char*opcode = object_receiver
		  ? ((strcmp(stmt_name,"$ivl_queue_method$sort")==0)    ? "%qsort/o"    :
		     (strcmp(stmt_name,"$ivl_queue_method$rsort")==0)   ? "%qsort/r/o"  :
		     (strcmp(stmt_name,"$ivl_queue_method$reverse")==0) ? "%qreverse/o" :
		     (strcmp(stmt_name,"$ivl_queue_method$shuffle")==0) ? "%qshuffle/o" :
		                                                          "%qunique/o")
		  : ((strcmp(stmt_name,"$ivl_queue_method$sort")==0)    ? "%qsort"    :
		     (strcmp(stmt_name,"$ivl_queue_method$rsort")==0)   ? "%qsort/r"  :
		     (strcmp(stmt_name,"$ivl_queue_method$reverse")==0) ? "%qreverse" :
		     (strcmp(stmt_name,"$ivl_queue_method$shuffle")==0) ? "%qshuffle" :
		                                                          "%qunique");
	    if (strcmp(opcode, "%qreverse") == 0
		|| strcmp(opcode, "%qshuffle") == 0
		|| strcmp(opcode, "%qreverse/o") == 0
		|| strcmp(opcode, "%qshuffle/o") == 0) {
		  if (object_receiver)
			fprintf(vvp_out, "    %s;\n", opcode);
		  else
			fprintf(vvp_out, "    %s v%p_0;\n", opcode, sig);
	    } else {
		    /* Sorting compares element VALUES: pass the declared
		     * element signedness (G72 — vec4-backed queues do not
		     * carry it, so negative ints sorted in unsigned word
		     * order without this flag). */
		  int sflag = 0;
		  ivl_type_t cont_type = object_receiver
			? receiver_container_type_(parm0)
			: ivl_signal_net_type(sig);
		  ivl_type_t elem_type = 0;
		  if (cont_type
		      && (ivl_type_base(cont_type) == IVL_VT_QUEUE
			  || ivl_type_base(cont_type) == IVL_VT_DARRAY))
			elem_type = ivl_type_element(cont_type);
		  if (elem_type && ivl_type_signed(elem_type))
			sflag = 1;
		  if (object_receiver)
			fprintf(vvp_out, "    %s %d;\n", opcode, sflag);
		  else
			fprintf(vvp_out, "    %s v%p_0, %d;\n", opcode, sig, sflag);
	    }
	    return 0;
      }

      /* Phase 63b/Q-methods (gap close): sort/rsort/unique with
       * iterator+with-clause comparator.  Decorate-sort-undecorate:
       * walk q, evaluate predicate per element (with iter set to
       * q[i]) and push key into a parallel `keys` queue; then call
       * %qsort_with_keys / %qrsort_with_keys / %qunique_with_keys
       * which sort q by keys at runtime.
       *   parm[0]=queue NetESignal
       *   parm[1]=iter NetNet (predicate references it)
       *   parm[2]=keys queue NetNet (output of key-build loop)
       *   parm[3]=idx NetNet (loop counter)
       *   parm[4]=predicate NetExpr (yielding the key, vec4 32-bit)
       */
      if (strcmp(stmt_name,"$ivl_queue_method$sort_with") == 0
	  || strcmp(stmt_name,"$ivl_queue_method$rsort_with") == 0
	  || strcmp(stmt_name,"$ivl_queue_method$unique_with_kx") == 0) {
	    int is_rsort = (strcmp(stmt_name,"$ivl_queue_method$rsort_with") == 0);
	    int is_unique = (strcmp(stmt_name,"$ivl_queue_method$unique_with_kx") == 0);
	    if (ivl_stmt_parm_count(net) < 5) return 0;
	    ivl_expr_t q_arg = ivl_stmt_parm(net, 0);
	    ivl_expr_t iter_arg = ivl_stmt_parm(net, 1);
	    ivl_expr_t keys_arg = ivl_stmt_parm(net, 2);
	    ivl_expr_t idx_arg = ivl_stmt_parm(net, 3);
	    ivl_expr_t pred = ivl_stmt_parm(net, 4);
	    ivl_expr_t recv_parm = (ivl_stmt_parm_count(net) > 5)
		  ? ivl_stmt_parm(net, 5) : 0;
	    if (!q_arg
		|| !iter_arg || ivl_expr_type(iter_arg) != IVL_EX_SIGNAL
		|| !keys_arg || ivl_expr_type(keys_arg) != IVL_EX_SIGNAL
		|| !idx_arg || ivl_expr_type(idx_arg) != IVL_EX_SIGNAL
		|| !pred) return 0;
	    ivl_signal_t q_sig = 0;
	    int object_receiver = 0;
	    if (ivl_expr_type(q_arg) == IVL_EX_SIGNAL
		&& ivl_expr_signal(q_arg)) {
		  q_sig = ivl_expr_signal(q_arg);
	    } else if (recv_parm
		       && ivl_expr_type(recv_parm) == IVL_EX_SIGNAL
		       && ivl_expr_signal(recv_parm)) {
		    /* Retain the one-time-evaluated original receiver, including its
		       root provenance, for the final in-place reorder. The hidden
		       signal holds only a value snapshot used while evaluating keys. */
		  q_sig = ivl_expr_signal(recv_parm);
		  if (show_queue_object_receiver(q_arg) != 0)
			return 0;
		  object_receiver = 1;
		  fprintf(vvp_out, "    %%dup/obj/ref; keyed ordering snapshot\n");
		  fprintf(vvp_out, "    %%store/obj v%p_0;\n", q_sig);
	    }
	    ivl_signal_t iter_sig = ivl_expr_signal(iter_arg);
	    ivl_signal_t keys_sig = ivl_expr_signal(keys_arg);
	    ivl_signal_t idx_sig = ivl_expr_signal(idx_arg);
	    if (!q_sig || !iter_sig || !keys_sig || !idx_sig) return 0;
	    ivl_type_t iter_type = ivl_signal_net_type(iter_sig);
	    unsigned iter_wid = ivl_type_packed_width(iter_type);
	    if (iter_wid == 0) iter_wid = 32;
	    ivl_variable_type_t bt = ivl_type_base(iter_type);

	    /* Iterator-type dispatch: pick the right %load/dar/* +
	       %store/* pair to fetch q[idx] into iter.
	       Supported: BOOL/LOGIC (vec4), REAL, STRING, CLASS/
	       DARRAY/QUEUE/NO_TYPE (object).  The predicate yields a
	       32-bit vec4 key regardless of iter type. */
	    const char*load_dar = NULL;
	    const char*store_iter = NULL;
	    char store_iter_buf[64];
	    switch (bt) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  load_dar = "load/dar/vec4";
		  snprintf(store_iter_buf, sizeof store_iter_buf,
			   "store/vec4 v%p_0, 0, %u", iter_sig, iter_wid);
		  store_iter = store_iter_buf;
		  break;
		case IVL_VT_REAL:
		  load_dar = "load/dar/r";
		  snprintf(store_iter_buf, sizeof store_iter_buf,
			   "store/real v%p_0", iter_sig);
		  store_iter = store_iter_buf;
		  break;
		case IVL_VT_STRING:
		  load_dar = "load/dar/str";
		  snprintf(store_iter_buf, sizeof store_iter_buf,
			   "store/str v%p_0", iter_sig);
		  store_iter = store_iter_buf;
		  break;
		case IVL_VT_CLASS:
		case IVL_VT_DARRAY:
		case IVL_VT_QUEUE:
		case IVL_VT_NO_TYPE:
		  load_dar = "load/dar/obj";
		  snprintf(store_iter_buf, sizeof store_iter_buf,
			   "store/obj v%p_0", iter_sig);
		  store_iter = store_iter_buf;
		  break;
		default:
		  /* Truly unrecognized — fall back. */
		  break;
	    }
	    if (!load_dar) {
		  static int warned = 0;
		  if (!warned) {
			fprintf(stderr, "Warning: %s with-clause on iter type %d "
				"not yet supported; falling back to default "
				"compare (further similar warnings suppressed)\n",
				stmt_name, (int)bt);
			warned = 1;
		  }
		  if (object_receiver)
			fprintf(vvp_out, "    %s 0;\n",
				is_unique ? "%qunique/o"
				          : (is_rsort ? "%qsort/r/o" : "%qsort/o"));
		  else
			fprintf(vvp_out, "    %s v%p_0, 0;\n",
				is_unique ? "%qunique"
				          : (is_rsort ? "%qsort/r" : "%qsort"),
				q_sig);
		  return 0;
	    }

	    /* Step 1: keys = empty queue, typed by the with expression
	       (IEEE 1800-2017 7.12.2): string and real keys keep their
	       full value; everything else is a signed 32-bit key. */
	    ivl_variable_type_t key_vt = ivl_expr_value(pred);
	    const char*keys_enc =
		  (key_vt == IVL_VT_STRING) ? "S" :
		  (key_vt == IVL_VT_REAL)   ? "r" : "sb32";
	    fprintf(vvp_out, "    %%ix/load 5, 0, 0;\n");
	    fprintf(vvp_out, "    %%new/queue \"%s\";\n", keys_enc);
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", keys_sig);

	    /* Step 2: idx_sig = 0 */
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, 32;\n");
	    fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, 32;\n", idx_sig);

	    /* Step 3: outer loop building keys */
	    unsigned outer_top = local_count++;
	    unsigned outer_end = local_count++;
	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, outer_top);
	    fprintf(vvp_out, "    %%load/vec4 v%p_0;\n", idx_sig);
	    fprintf(vvp_out, "    %%qsize v%p_0;\n", q_sig);
	    fprintf(vvp_out, "    %%cmp/s;\n");
	    fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, 5;\n",
		    thread_count, outer_end);

	    /* iter = q[idx] (type-dispatched) */
	    fprintf(vvp_out, "    %%ix/getv/s 3, v%p_0;\n", idx_sig);
	    fprintf(vvp_out, "    %%%s v%p_0;\n", load_dar, q_sig);
	    fprintf(vvp_out, "    %%%s;\n", store_iter);

	    /* eval predicate (key) and store to keys queue */
	    if (key_vt == IVL_VT_STRING) {
		  draw_eval_string(pred);
		  fprintf(vvp_out, "    %%ix/load 5, 0, 0;\n");
		  fprintf(vvp_out, "    %%store/qb/str v%p_0, 5;\n",
			  keys_sig);
	    } else if (key_vt == IVL_VT_REAL) {
		  draw_eval_real(pred);
		  fprintf(vvp_out, "    %%ix/load 5, 0, 0;\n");
		  fprintf(vvp_out, "    %%store/qb/r v%p_0, 5;\n",
			  keys_sig);
	    } else {
		  unsigned pred_wid = ivl_expr_width(pred);
		  draw_eval_vec4(pred);
		  /* Pad/truncate to 32-bit signed for keys queue. */
		  if (pred_wid != 32) {
			fprintf(vvp_out, "    %%pad/%s 32;\n",
				ivl_expr_signed(pred) ? "s" : "u");
		  }
		  fprintf(vvp_out, "    %%ix/load 5, 0, 0;\n");
		  fprintf(vvp_out, "    %%store/qb/v v%p_0, 5, 32;\n",
			  keys_sig);
	    }

	    /* idx_sig += 1 */
	    fprintf(vvp_out, "    %%load/vec4 v%p_0;\n", idx_sig);
	    fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    fprintf(vvp_out, "    %%add;\n");
	    fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, 32;\n", idx_sig);
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, outer_top);

	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, outer_end);

	    /* Step 4: emit the runtime opcode that sorts q by keys */
	    if (object_receiver && is_unique) {
		  fprintf(vvp_out, "    %%qunique/keys/o v%p_0;\n", keys_sig);
	    } else if (object_receiver && is_rsort) {
		  fprintf(vvp_out, "    %%qrsort/keys/o v%p_0;\n", keys_sig);
	    } else if (object_receiver) {
		  fprintf(vvp_out, "    %%qsort/keys/o v%p_0;\n", keys_sig);
	    } else if (is_unique) {
		  fprintf(vvp_out, "    %%qunique/keys v%p_0, v%p_0;\n",
			  q_sig, keys_sig);
	    } else if (is_rsort) {
		  fprintf(vvp_out, "    %%qrsort/keys v%p_0, v%p_0;\n",
			  q_sig, keys_sig);
	    } else {
		  fprintf(vvp_out, "    %%qsort/keys v%p_0, v%p_0;\n",
			  q_sig, keys_sig);
	    }
	    return 0;
      }

      /* Chained dynamic-container element store, all four outer/inner
       * combinations of keyed (associative) and positional (queue)
       * dimensions:  $ivl_assoc$store2(outer, k1, k2, value).
       * A keyed outer auto-vivifies the inner container at k1; a
       * positional outer loads the existing element handle.  A keyed
       * inner stores through the non-sig %aa/store forms (receiver
       * peeked from the object stack); a positional inner stores
       * through %store/qo/i (receiver popped). */
      if (strcmp(stmt_name, "$ivl_assoc$store2") == 0) {
	    if (ivl_stmt_parm_count(net) < 4) return 0;
	      /* [outer, k1, k2, ... kN, value]: every key but the last
		 navigates one container level, the last one is the store
		 index. Two keys was the only shape this used to accept;
		 the count is now whatever the front end passed, so a
		 container of any legal depth stores through here. */
	    unsigned nparm_ = ivl_stmt_parm_count(net);
	    unsigned nkeys_ = (nparm_ >= 3) ? (nparm_ - 2) : 0;
	    ivl_expr_t outer_arg = ivl_stmt_parm(net, 0);
	    ivl_expr_t k1 = ivl_stmt_parm(net, 1);
	    ivl_expr_t k2 = ivl_stmt_parm(net, nkeys_);
	    ivl_expr_t val = ivl_stmt_parm(net, nparm_ - 1);
	    ivl_signal_t outer_sig =
		  (outer_arg && (ivl_expr_type(outer_arg) == IVL_EX_SIGNAL))
			? ivl_expr_signal(outer_arg) : 0;
	      /* Non-signal outer (class property): the receiver object
	       * is evaluated onto the stack instead. */
	    int outer_is_obj = !outer_sig && outer_arg
		  && ivl_expr_type(outer_arg) == IVL_EX_PROPERTY;
	    if ((!outer_sig && !outer_is_obj) || !k1 || !k2 || !val) {
		  fprintf(stderr, "Warning: $ivl_assoc$store2 with"
			  " unsupported argument shape at %s:%u; skipping\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 0;
	    }

	    ivl_type_t outer_type = outer_sig
		  ? ivl_signal_net_type(outer_sig)
		  : receiver_container_type_(outer_arg);
	    ivl_type_t inner_type = outer_type;
	    {
		  unsigned lv_;
		  for (lv_ = 1 ; lv_ < nkeys_ ; lv_ += 1) {
			if (!type_is_runtime_container_(inner_type))
			      break;
			inner_type = ivl_type_element(inner_type);
		  }
	    }
	    if (!type_is_runtime_container_(outer_type)
		|| !type_is_runtime_container_(inner_type)) {
		  fprintf(stderr, "Warning: $ivl_assoc$store2 lost a nested "
			  "container type at %s:%u; skipping\n",
			  ivl_stmt_file(net), ivl_stmt_lineno(net));
		  return 0;
	    }

	      /* Walk every navigation key against the type of its own
	       * receiver. Associative hops preserve string/object/vector key
	       * stacks; positional hops use numeric word 3. Each hop creates
	       * the declared next container when the stored handle is nil. */
	    {
		  ivl_type_t recv_type = outer_type;
		  unsigned ki_;
		  for (ki_ = 1 ; ki_ < nkeys_ ; ki_ += 1) {
			ivl_expr_t key = ivl_stmt_parm(net, ki_);
			ivl_type_t next_type = ivl_type_element(recv_type);

			if (!type_is_runtime_container_(next_type)) {
			      fprintf(stderr, "Warning: $ivl_assoc$store2 has a "
				      "non-container navigation hop at %s:%u; skipping\n",
				      ivl_stmt_file(net), ivl_stmt_lineno(net));
			      return 0;
			}
			if (ivl_type_base(recv_type) == IVL_VT_QUEUE
			    && ivl_type_queue_assoc_compat(recv_type)) {
			      const char*key_kind;
			      if (ki_ == 1 && !outer_sig)
				    draw_eval_object(outer_arg);
			      key_kind = draw_eval_assoc_key_(key, 0);
			      if (ivl_type_base(next_type) == IVL_VT_DARRAY) {
				    /* IEEE 1800-2017 7.8.7 allocates a missing
				     * associative element used as an assignment target. The
				     * element's dynamic-array default remains nil: protocol
				     * spec 16 inserts nil without manufacturing a queue. */
				    if (ki_ == 1 && outer_sig) {
					  fprintf(vvp_out,
						  "    %%aa/viv/sig/%s v%p_0, 16;\n",
						  key_kind, outer_sig);
				    } else {
					  fprintf(vvp_out, "    %%aa/viv/o/%s %u;\n",
						  key_kind,
						  strcmp(key_kind, "obj") == 0 ? 24 : 16);
				    }
			      } else {
				    unsigned next_spec =
					  dynamic_container_spec_(next_type);
				    if (ki_ == 1 && outer_sig) {
					  fprintf(vvp_out,
						  "    %%aa/viv/sig/%s v%p_0, %u;\n",
						  key_kind, outer_sig, next_spec);
				    } else {
					  fprintf(vvp_out,
						  "    %%aa/viv/o/%s %u;\n",
						  key_kind, next_spec
						  + (strcmp(key_kind, "obj") == 0 ? 8 : 0));
				    }
			      }
			} else {
			      if (ki_ == 1) {
				    if (outer_sig)
					  fprintf(vvp_out, "    %%load/obj v%p_0;\n",
						  outer_sig);
				    else
					  draw_eval_object(outer_arg);
			      }
			      draw_eval_expr_into_integer(key, 3);
			      if (ivl_type_base(next_type) == IVL_VT_DARRAY) {
				    fprintf(vvp_out, "    %%load/qo/obj;\n");
			      } else {
				    unsigned next_spec =
					  dynamic_container_spec_(next_type);
				    fprintf(vvp_out,
					    "    %%qdar/loadlv/o \"@%u\";\n",
					    next_spec);
			      }
			}
			recv_type = next_type;
		  }
	    }

		    unsigned spec = dynamic_container_spec_(inner_type);
		    int inner_keyed = spec >= 4;
		    unsigned vkind = spec & 3;
		    uint64_t inner_max_count = queue_live_max_operand_(inner_type);
		    ivl_type_t inner_element_type = ivl_type_element(inner_type);
		    unsigned inner_element_width = inner_element_type
			  ? ivl_type_packed_width(inner_element_type) : 0;
		    if (inner_element_width == 0)
			  inner_element_width = ivl_expr_width(val);
	    if (inner_keyed) {
		    /* inner[k2] = value (receiver peeked from the obj
		     * stack).  The store kind follows the declared element
		     * type of the inner container — string literals may
		     * arrive as packed vectors and need the %pushv/str
		     * conversion. */
		  const char*k2_kind = draw_eval_assoc_key_(k2, 0);
		  if (vkind == 2) {
			if (ivl_expr_value(val) == IVL_VT_STRING) {
			      draw_eval_string(val);
			} else {
			      draw_eval_vec4(val);
			      fprintf(vvp_out, "    %%pushv/str;\n");
			}
			fprintf(vvp_out, "    %%aa/store/str/%s;\n", k2_kind);
		  } else if (vkind == 1) {
			draw_eval_real(val);
			fprintf(vvp_out, "    %%aa/store/r/%s;\n", k2_kind);
		  } else if (vkind == 3) {
			draw_queue_element_object_value_(val,
						 inner_element_type);
			fprintf(vvp_out, "    %%aa/store/obj/%s;\n", k2_kind);
			  } else {
				draw_eval_vec4(val);
				resize_vec4_wid(val, inner_element_width);
				if (inner_element_type
				    && ivl_type_base(inner_element_type) == IVL_VT_BOOL
				    && ivl_expr_value(val) != IVL_VT_BOOL)
				      fprintf(vvp_out, "    %%cast2;\n");
				fprintf(vvp_out, "    %%aa/store/v/%s %u;\n",
					k2_kind, inner_element_width);
		  }
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    } else {
		    /* Positional inner: evaluate the value, then the index
		     * into word 3, then store through the queue receiver
		     * (%store/qo/i pops the receiver itself). */
		  if (vkind == 2) {
			if (ivl_expr_value(val) == IVL_VT_STRING) {
			      draw_eval_string(val);
			} else {
			      draw_eval_vec4(val);
			      fprintf(vvp_out, "    %%pushv/str;\n");
			}
			draw_eval_expr_into_integer(k2, 3);
			emit_object_queue_store_('i', "str",
			                         inner_max_count, 0);
		  } else if (vkind == 1) {
			draw_eval_real(val);
			draw_eval_expr_into_integer(k2, 3);
			emit_object_queue_store_('i', "r",
			                         inner_max_count, 0);
		  } else if (vkind == 3) {
			draw_queue_element_object_value_(val,
						 inner_element_type);
			draw_eval_expr_into_integer(k2, 3);
			emit_object_queue_store_('i', "obj",
			                         inner_max_count, 0);
			  } else {
				draw_eval_vec4(val);
				resize_vec4_wid(val, inner_element_width);
				if (inner_element_type
				    && ivl_type_base(inner_element_type) == IVL_VT_BOOL
				    && ivl_expr_value(val) != IVL_VT_BOOL)
				      fprintf(vvp_out, "    %%cast2;\n");
				draw_eval_expr_into_integer(k2, 3);
				emit_object_queue_store_('i', "v", inner_max_count,
				                         inner_element_width);
		  }
	    }
	    return 0;
      }

      if (strcmp(stmt_name, "$ivl_process$kill") == 0
	  || strcmp(stmt_name, "$ivl_process$await") == 0
	  || strcmp(stmt_name, "$ivl_process$suspend") == 0
	  || strcmp(stmt_name, "$ivl_process$resume") == 0) {
	    ivl_expr_t recv = ivl_stmt_parm(net, 0);
	    const char*op;
	    if (recv)
		  draw_eval_object(recv);
	    if (strcmp(stmt_name, "$ivl_process$kill") == 0)
		  op = "%process/kill";
	    else if (strcmp(stmt_name, "$ivl_process$await") == 0)
		  op = "%process/await";
	    else if (strcmp(stmt_name, "$ivl_process$suspend") == 0)
		  op = "%process/suspend";
	    else
		  op = "%process/resume";
	    fprintf(vvp_out, "    %s;\n", op);
	    return 0;
      }

      /* ---- Mailbox task methods ---- */

      /* Helper: push a mailbox item onto the obj stack.
       * Class types are pushed directly; strings/reals/vec4 primitives
       * are boxed as vvp_boxed_{string,real,vec4}. A string message
       * used to be drawn as vec4 string-bits and the receiving side
       * stored them into the string variable through recv_vec4, which
       * aborts the runtime. */
#define EMIT_MBX_PUSH_ITEM(item_expr) \
      do { \
	    if ((item_expr) && (ivl_expr_value(item_expr) == IVL_VT_CLASS \
			       || ivl_expr_value(item_expr) == IVL_VT_DARRAY \
			       || ivl_expr_value(item_expr) == IVL_VT_QUEUE \
			       || ivl_expr_value(item_expr) == IVL_VT_NO_TYPE)) { \
		  draw_eval_object(item_expr); \
	    } else if ((item_expr) && (ivl_expr_value(item_expr) == IVL_VT_STRING \
				       || ivl_expr_type(item_expr) == IVL_EX_STRING)) { \
		  draw_eval_string(item_expr); \
		  fprintf(vvp_out, "    %%box/str;\n"); \
	    } else if ((item_expr) && ivl_expr_value(item_expr) == IVL_VT_REAL) { \
		  draw_eval_real(item_expr); \
		  fprintf(vvp_out, "    %%box/real;\n"); \
	    } else if (item_expr) { \
		  draw_eval_vec4(item_expr); \
		  unsigned _wid = ivl_expr_width(item_expr); \
		  if (!_wid) _wid = 32; \
		  fprintf(vvp_out, "    %%box/vec4 %u;\n", _wid); \
	    } else { \
		  fprintf(vvp_out, "    %%null;\n"); \
	    } \
      } while(0)

      /* $ivl_mailbox$put(mailbox, item)
       * Blocking put: push mailbox and item onto obj stack, then %mbx/put. */
      if (strcmp(stmt_name, "$ivl_mailbox$put") == 0) {
	    ivl_expr_t mbx  = ivl_stmt_parm(net, 0);
	    ivl_expr_t item = ivl_stmt_parm_count(net) >= 2 ? ivl_stmt_parm(net, 1) : 0;
	    if (mbx) draw_eval_object(mbx);
	    EMIT_MBX_PUSH_ITEM(item);
	    fprintf(vvp_out, "    %%mbx/put;\n");
	    return 0;
      }

      /* Helper: pop item from obj stack and store to output variable.
       * Class signals: %store/obj.  Primitive signals: %unbox/vec4 + %store/vec4. */
#define EMIT_MBX_STORE_ITEM(net_arg_idx) \
      do { \
	    if (ivl_stmt_parm_count(net) > (net_arg_idx)) { \
		  ivl_expr_t _item = ivl_stmt_parm(net, net_arg_idx); \
		  if (_item && ivl_expr_type(_item) == IVL_EX_SIGNAL) { \
			ivl_signal_t _sig = ivl_expr_signal(_item); \
			if (_sig && ivl_signal_data_type(_sig) == IVL_VT_CLASS) { \
			      fprintf(vvp_out, "    %%store/obj v%p_0;\n", _sig); \
			} else if (_sig && ivl_signal_data_type(_sig) == IVL_VT_STRING) { \
			      fprintf(vvp_out, "    %%unbox/str;\n"); \
			      fprintf(vvp_out, "    %%store/str v%p_0;\n", _sig); \
			} else if (_sig && ivl_signal_data_type(_sig) == IVL_VT_REAL) { \
			      fprintf(vvp_out, "    %%unbox/real;\n"); \
			      fprintf(vvp_out, "    %%store/real v%p_0;\n", _sig); \
			} else if (_sig) { \
			      unsigned _wid = ivl_signal_width(_sig); \
			      if (!_wid) _wid = 32; \
			      fprintf(vvp_out, "    %%unbox/vec4 %u;\n", _wid); \
			      fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n", _sig, _wid); \
			} else { \
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n"); \
			} \
		  } else { \
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n"); \
		  } \
	    } else { \
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n"); \
	    } \
      } while(0)

      /* $ivl_mailbox$get(mailbox, item)
       * Blocking get: suspend if empty; on resume item is on obj stack.
       * Then store item to output variable. */
      if (strcmp(stmt_name, "$ivl_mailbox$get") == 0) {
	    ivl_expr_t mbx = ivl_stmt_parm(net, 0);
	    if (mbx) draw_eval_object(mbx);
	    if (ivl_stmt_ref_lval(net)) {
		  draw_capture_lval_ref(ivl_stmt_ref_lval(net));
		  fprintf(vvp_out, "    %%swap/obj; mailbox receiver above captured output\n");
	    }
	    fprintf(vvp_out, "    %%mbx/get;\n");
	    if (ivl_stmt_ref_lval(net))
		  fprintf(vvp_out, "    %%ref/store/mbx;\n");
	    else
		  EMIT_MBX_STORE_ITEM(1);
	    return 0;
      }

      /* $ivl_mailbox$peek(mailbox, item)
       * Blocking peek: suspend if empty; on resume item is on obj stack. */
      if (strcmp(stmt_name, "$ivl_mailbox$peek") == 0) {
	    ivl_expr_t mbx = ivl_stmt_parm(net, 0);
	    if (mbx) draw_eval_object(mbx);
	    if (ivl_stmt_ref_lval(net)) {
		  draw_capture_lval_ref(ivl_stmt_ref_lval(net));
		  fprintf(vvp_out, "    %%swap/obj; mailbox receiver above captured output\n");
	    }
	    fprintf(vvp_out, "    %%mbx/peek;\n");
	    if (ivl_stmt_ref_lval(net))
		  fprintf(vvp_out, "    %%ref/store/mbx;\n");
	    else
		  EMIT_MBX_STORE_ITEM(1);
	    return 0;
      }

      /* $ivl_mailbox$try_put(mailbox, item)
       * Non-blocking put. In task context result (1/0) is discarded. */
      if (strcmp(stmt_name, "$ivl_mailbox$try_put") == 0) {
	    ivl_expr_t mbx  = ivl_stmt_parm(net, 0);
	    ivl_expr_t item = ivl_stmt_parm_count(net) >= 2 ? ivl_stmt_parm(net, 1) : 0;
	    if (mbx) draw_eval_object(mbx);
	    EMIT_MBX_PUSH_ITEM(item);
	    fprintf(vvp_out, "    %%mbx/try_put;\n");
	    fprintf(vvp_out, "    %%pop/vec4 1;\n");  /* discard result in task ctx */
	    return 0;
      }

      /* $ivl_mailbox$try_get(mailbox, item)
       * Non-blocking get. In task context result (1/0) is discarded. */
      if (strcmp(stmt_name, "$ivl_mailbox$try_get") == 0) {
	    ivl_expr_t mbx = ivl_stmt_parm(net, 0);
	    int success_flag = allocate_flag();
	    unsigned lab_fail = local_count++;
	    unsigned lab_done = local_count++;
	    if (mbx) draw_eval_object(mbx);
	    if (ivl_stmt_ref_lval(net)) {
		  draw_capture_lval_ref(ivl_stmt_ref_lval(net));
		  fprintf(vvp_out, "    %%swap/obj; mailbox receiver above captured output\n");
	    }
	    fprintf(vvp_out, "    %%mbx/try_get;\n");
	    fprintf(vvp_out, "    %%flag_set/vec4 %d; consume task-context result\n",
		    success_flag);
	    fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; failed try_get leaves output unchanged\n",
		    thread_count, lab_fail, success_flag);
	    if (ivl_stmt_ref_lval(net))
		  fprintf(vvp_out, "    %%ref/store/mbx;\n");
	    else
		  EMIT_MBX_STORE_ITEM(1);
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_done);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_fail);
	    fprintf(vvp_out, "    %%pop/obj %u, 0; discard failed mailbox item%s\n",
		    ivl_stmt_ref_lval(net) ? 2U : 1U,
		    ivl_stmt_ref_lval(net) ? " and captured output" : "");
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_done);
	    clr_flag(success_flag);
	    return 0;
      }

      /* $ivl_mailbox$try_peek(mailbox, item)
       * Non-blocking peek. In task context result (1/0) is discarded. */
      if (strcmp(stmt_name, "$ivl_mailbox$try_peek") == 0) {
	    ivl_expr_t mbx = ivl_stmt_parm(net, 0);
	    int success_flag = allocate_flag();
	    unsigned lab_fail = local_count++;
	    unsigned lab_done = local_count++;
	    if (mbx) draw_eval_object(mbx);
	    if (ivl_stmt_ref_lval(net)) {
		  draw_capture_lval_ref(ivl_stmt_ref_lval(net));
		  fprintf(vvp_out, "    %%swap/obj; mailbox receiver above captured output\n");
	    }
	    fprintf(vvp_out, "    %%mbx/try_peek;\n");
	    fprintf(vvp_out, "    %%flag_set/vec4 %d; consume task-context result\n",
		    success_flag);
	    fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; failed try_peek leaves output unchanged\n",
		    thread_count, lab_fail, success_flag);
	    if (ivl_stmt_ref_lval(net))
		  fprintf(vvp_out, "    %%ref/store/mbx;\n");
	    else
		  EMIT_MBX_STORE_ITEM(1);
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_done);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_fail);
	    fprintf(vvp_out, "    %%pop/obj %u, 0; discard failed mailbox item%s\n",
		    ivl_stmt_ref_lval(net) ? 2U : 1U,
		    ivl_stmt_ref_lval(net) ? " and captured output" : "");
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_done);
	    clr_flag(success_flag);
	    return 0;
      }

      /* $ivl_mailbox$num(mailbox)
       * In task context: result (item count) is discarded. */
      if (strcmp(stmt_name, "$ivl_mailbox$num") == 0) {
	    ivl_expr_t mbx = ivl_stmt_parm(net, 0);
	    if (mbx) draw_eval_object(mbx);
	    fprintf(vvp_out, "    %%mbx/num;\n");
	    fprintf(vvp_out, "    %%pop/vec4 1;\n");  /* discard in task ctx */
	    return 0;
      }

      /* ---- Semaphore task methods ---- */

      /* $ivl_semaphore$get(semaphore[, N])
       * Blocking get: suspend until N keys available. */
      if (strcmp(stmt_name, "$ivl_semaphore$get") == 0) {
	    ivl_expr_t sem = ivl_stmt_parm(net, 0);
	    if (sem) draw_eval_object(sem);
	    /* Push N: evaluate arg if present, else push constant 1 */
	    if (ivl_stmt_parm_count(net) >= 2 && ivl_stmt_parm(net, 1)) {
		  draw_eval_vec4(ivl_stmt_parm(net, 1));
	    } else {
		  fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    }
	    fprintf(vvp_out, "    %%sem/get;\n");
	    return 0;
      }

      /* $ivl_semaphore$put(semaphore[, N])
       * Add N keys and wake waiters. */
      if (strcmp(stmt_name, "$ivl_semaphore$put") == 0) {
	    ivl_expr_t sem = ivl_stmt_parm(net, 0);
	    if (sem) draw_eval_object(sem);
	    if (ivl_stmt_parm_count(net) >= 2 && ivl_stmt_parm(net, 1)) {
		  draw_eval_vec4(ivl_stmt_parm(net, 1));
	    } else {
		  fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    }
	    fprintf(vvp_out, "    %%sem/put;\n");
	    return 0;
      }

      /* $ivl_semaphore$try_get(semaphore[, N])
       * Non-blocking try. In task context result (1/0) is discarded. */
      if (strcmp(stmt_name, "$ivl_semaphore$try_get") == 0) {
	    ivl_expr_t sem = ivl_stmt_parm(net, 0);
	    if (sem) draw_eval_object(sem);
	    if (ivl_stmt_parm_count(net) >= 2 && ivl_stmt_parm(net, 1)) {
		  draw_eval_vec4(ivl_stmt_parm(net, 1));
	    } else {
		  fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    }
	    fprintf(vvp_out, "    %%sem/try_get;\n");
	    fprintf(vvp_out, "    %%pop/vec4 1;\n");  /* discard result in task ctx */
	    return 0;
      }

      /* $ivl_class_method$constraint_mode(object, en, cid)
       * Set constraint_mode for constraint index cid: en=1 enable, en=0 disable. */
      if (strcmp(stmt_name, "$ivl_class_method$constraint_mode") == 0) {
	    ivl_expr_t obj_arg  = ivl_stmt_parm(net, 0);
	    ivl_expr_t mode_arg = ivl_stmt_parm(net, 1);
	    ivl_expr_t cid_arg  = ivl_stmt_parm(net, 2);
	    long cid = cid_arg ? (long)get_number_immediate(cid_arg) : 0;
	    if (mode_arg) draw_eval_vec4(mode_arg);
	    else fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    if (obj_arg) draw_eval_object(obj_arg);
	    fprintf(vvp_out, "    %%constraint_mode %ld;\n", cid);
	    return 0;
      }

      /* M3B-5 $ivl_class_method$srandom(object, seed) and
       * $ivl_class_method$set_randstate(object, state) -- IEEE 1800-2017
       * 18.13. Both opcodes want the object UNDER the value, so push the
       * value first. */
      if (strcmp(stmt_name, "$ivl_class_method$srandom") == 0) {
	    ivl_expr_t obj_arg  = ivl_stmt_parm(net, 0);
	    ivl_expr_t seed_arg = (ivl_stmt_parm_count(net) >= 2)
		  ? ivl_stmt_parm(net, 1) : 0;
	    if (obj_arg) draw_eval_object(obj_arg);
	    if (seed_arg) draw_eval_vec4(seed_arg);
	    else fprintf(vvp_out, "    %%pushi/vec4 0, 0, 32;\n");
	    fprintf(vvp_out, "    %%srandom;\n");
	    return 0;
      }
      if (strcmp(stmt_name, "$ivl_class_method$set_randstate") == 0) {
	    ivl_expr_t obj_arg = ivl_stmt_parm(net, 0);
	    ivl_expr_t st_arg  = (ivl_stmt_parm_count(net) >= 2)
		  ? ivl_stmt_parm(net, 1) : 0;
	    if (obj_arg) draw_eval_object(obj_arg);
	    if (st_arg) draw_eval_string(st_arg);
	    else fprintf(vvp_out, "    %%pushi/str \"\";\n");
	    fprintf(vvp_out, "    %%set_randstate;\n");
	    return 0;
      }

      /* $ivl_class_method$rand_mode(object, en [, pid])
       * 2 args: set rand_mode for ALL rand properties (obj.rand_mode(en)).
       * 3 args: set rand_mode for the single property `pid` only
	       *         (obj.field.rand_mode(en)) — M3-rm.
	       * 5 args: additionally carry canonical first leaf and leaf count for
	       *         an unpacked-array element/subarray. */
      if (strcmp(stmt_name, "$ivl_class_method$rand_mode") == 0
	  || strcmp(stmt_name, "$ivl_class_method$rand_mode_assoc") == 0
	  || strcmp(stmt_name, "$ivl_class_method$rand_mode_last") == 0
	  || strcmp(stmt_name, "$ivl_class_method$rand_mode_nested") == 0) {
	    int nested_index = strcmp(stmt_name,
			     "$ivl_class_method$rand_mode_nested") == 0;
	    int assoc_index = strcmp(stmt_name,
			     "$ivl_class_method$rand_mode_assoc") == 0;
	    int last_index = strcmp(stmt_name,
			     "$ivl_class_method$rand_mode_last") == 0;
	    ivl_expr_t obj_arg  = ivl_stmt_parm(net, 0);
	    ivl_expr_t mode_arg = ivl_stmt_parm(net, 1);
	    ivl_expr_t pid_arg  = (ivl_stmt_parm_count(net) >= 3)
		  ? ivl_stmt_parm(net, 2) : 0;
	    ivl_expr_t leaf_arg = (ivl_stmt_parm_count(net) >= 5)
		  ? ivl_stmt_parm(net, 3) : 0;
	    ivl_expr_t count_arg = (ivl_stmt_parm_count(net) >= 5)
		  ? ivl_stmt_parm(net, 4) : 0;
	    if (mode_arg) draw_eval_vec4(mode_arg);
	    else fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    if (obj_arg) draw_eval_object(obj_arg);
	    if (last_index && pid_arg && number_is_immediate(pid_arg, 32, 0)
		&& !number_is_unknown(pid_arg)) {
		  fprintf(vvp_out, "    %%rand_mode/p/last %ld;\n",
			  get_number_immediate(pid_arg));
		  return 0;
	    }
	    if (pid_arg && leaf_arg && count_arg
		&& number_is_immediate(pid_arg, 32, 0)
		&& !number_is_unknown(pid_arg)) {
	      long pid = get_number_immediate(pid_arg);
	      if (nested_index) {
		  int leaf_word = allocate_word();
		  int elem_word = allocate_word();
		  int invalid_flag = allocate_flag();
		  draw_expr_into_idx(leaf_arg, leaf_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve queue leaf X/Z\n",
			  invalid_flag);
		  draw_expr_into_idx(count_arg, elem_word);
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine queue index X/Z\n",
			  invalid_flag);
		  clr_flag(invalid_flag);
		  fprintf(vvp_out, "    %%rand_mode/p/q %ld, %d, %d;\n",
			  pid, leaf_word, elem_word);
		  clr_word(elem_word);
		  clr_word(leaf_word);
		  return 0;
	      }
	      if (assoc_index) {
			const char*key_kind = draw_eval_assoc_key_(leaf_arg, 0);
			fprintf(vvp_out, "    %%rand_mode/p/a/%s %ld;\n",
				key_kind, pid);
			return 0;
		  }
		  int leaf_word = allocate_word();
		  int count_word = allocate_word();
		  draw_expr_into_idx(leaf_arg, leaf_word);
		  draw_expr_into_idx(count_arg, count_word);
		  fprintf(vvp_out, "    %%rand_mode/p/i %ld, %d, %d;\n",
			  pid, leaf_word, count_word);
		  clr_word(count_word);
		  clr_word(leaf_word);
	    } else if (pid_arg && number_is_immediate(pid_arg, 32, 0)
		&& !number_is_unknown(pid_arg)) {
		  fprintf(vvp_out, "    %%rand_mode/p %ld;\n",
			  get_number_immediate(pid_arg));
	    } else {
		  fprintf(vvp_out, "    %%rand_mode;\n");
	    }
	    return 0;
      }

      /* $ivl_class_method$covgrp_sample(cg_obj, cp values..., cp guards...,
       *                                cross guards...)
       * argv[0] = cg object, argv[1..N] = coverpoint values,
       * argv[N+1..2N] = coverpoint iff guard values, followed by one
       * value per cross item for cross-level iff (M11/IEEE 19.6). The
       * final two internal constant arguments are ncp and ncross.
       * Emit all vector arguments in order, then the cg object. */
      if (strcmp(stmt_name, "$ivl_class_method$covgrp_sample") == 0) {
	    unsigned nparms = ivl_stmt_parm_count(net);
	    if (nparms < 4) {
		  fprintf(stderr, "internal error: covergroup sample payload "
			  "is missing its dimension sentinels\n");
		  return -1;
	    }
	    ivl_expr_t ncp_arg = ivl_stmt_parm(net, nparms - 3);
	    ivl_expr_t ncross_arg = ivl_stmt_parm(net, nparms - 2);
	    ivl_expr_t nbin_arg = ivl_stmt_parm(net, nparms - 1);
	    if (!ncp_arg || !ncross_arg
		|| !nbin_arg
		|| ivl_expr_type(ncp_arg) != IVL_EX_NUMBER
		|| ivl_expr_type(ncross_arg) != IVL_EX_NUMBER
		|| ivl_expr_type(nbin_arg) != IVL_EX_NUMBER) {
		  fprintf(stderr, "internal error: covergroup sample dimensions "
			  "are not constants\n");
		  return -1;
	    }
	    unsigned ncp = (unsigned)ivl_expr_uvalue(ncp_arg);
	    unsigned ncross_guards = (unsigned)ivl_expr_uvalue(ncross_arg);
	    unsigned nbin_guards = (unsigned)ivl_expr_uvalue(nbin_arg);
	    unsigned payload_end = nparms - 3;
	    uint64_t expected_end = 1 + 2*(uint64_t)ncp
		  + ncross_guards + nbin_guards;
	    if (expected_end > 2097152) {
		  fprintf(stderr, "error: covergroup sample payload exceeds "
			  "the 2097152-value runtime limit\n");
		  return -1;
	    }
	    if (payload_end != expected_end) {
		  fprintf(stderr, "internal error: covergroup sample payload has "
			  "%u vector arguments, expected %" PRIu64
			  " for %u coverpoints "
			  ", %u crosses, and %u bin guards\n", payload_end - 1,
			  expected_end - 1, ncp, ncross_guards, nbin_guards);
		  return -1;
	    }
	    ivl_expr_t obj_arg = ivl_stmt_parm(net, 0);
	    unsigned has_cp_guards = ncp ? 1 : 0;
	    if (ncross_guards > 0x7fffu || nbin_guards > 0xffffu) {
		  fprintf(stderr, "error: covergroup sample guard table exceeds "
			  "the VVP encoding limit\n");
		  return -1;
	    }
	    unsigned guard_flags = has_cp_guards | (ncross_guards << 1)
		  | (nbin_guards << 16);
	    unsigned nreal = 0;
	    for (unsigned ii = 0; ii < ncp; ii++) {
		  ivl_expr_t cp_arg = ivl_stmt_parm(net, ii + 1);
		  if (cp_arg && ivl_expr_value(cp_arg) == IVL_VT_REAL) {
			nreal += 1;
			draw_eval_real(cp_arg);
		  } else if (cp_arg) draw_eval_vec4(cp_arg);
		  else fprintf(vvp_out, "    %%pushi/vec4 0, 0, 32;\n");
	    }
	    for (unsigned ii = 1 + ncp; ii < payload_end; ii += 1) {
		  ivl_expr_t arg = ivl_stmt_parm(net, ii);
		  if (arg) draw_eval_vec4(arg);
		  else fprintf(vvp_out, "    %%pushi/vec4 0, 0, 32;\n");
	    }
	    if (obj_arg) draw_eval_object(obj_arg);
	    /* A class-embedded group can be extended at runtime. Standalone
	       covergroups keep the original stack-described VVP encoding. */
	    ivl_type_t cgtype = obj_arg ? ivl_expr_net_type(obj_arg) : 0;
	    if (cgtype && ivl_type_base(cgtype) == IVL_VT_CLASS
		&& ivl_type_covgrp_owner_prop(cgtype) >= 0) {
		  ensure_class_type_emitted(cgtype);
		  fprintf(vvp_out, "    %%covgrp/sample/dyn %u, C%p, %u;\n",
			  guard_flags, cgtype, ncp);
	    } else {
		  fprintf(vvp_out, "    %%covgrp/sample %llu, %u;\n",
			  (unsigned long long)(((uint64_t)nreal << 32) | ncp),
			  guard_flags);
	    }
	    return 0;
      }

      /* M11-3: event-driven sampling of a class-embedded covergroup:
       * sample every live instance of the covergroup class. argv[0]
       * is a type-carrier expression (never evaluated) whose net
       * type is the covergroup class. */
      if (strcmp(stmt_name, "$ivl_class_method$covgrp_sample_all") == 0) {
	    ivl_expr_t arg = ivl_stmt_parm(net, 0);
	    ivl_type_t ctype = arg ? ivl_expr_net_type(arg) : 0;
	    if (ctype) {
		  ensure_class_type_emitted(ctype);
		  fprintf(vvp_out, "    %%covgrp/sample/all C%p;\n", ctype);
	    }
	    return 0;
      }

      /* M11: covergroup start()/stop() — per-instance sampling enable. */
      if (strcmp(stmt_name, "$ivl_class_method$covgrp_start") == 0
	  || strcmp(stmt_name, "$ivl_class_method$covgrp_stop") == 0) {
	    ivl_expr_t obj_arg = ivl_stmt_parm(net, 0);
	    if (obj_arg) draw_eval_object(obj_arg);
	    fprintf(vvp_out, "    %%covgrp/%s;\n",
		    strcmp(stmt_name, "$ivl_class_method$covgrp_start") == 0
			  ? "start" : "stop");
	    return 0;
      }

      /* $ivl_ref_bind(<formal>, <actual>) — point a `ref' formal at the
       * caller's variable (IEEE 1800-2017 13.5.2). The core emits this
       * where the copy-in used to be, which puts it between the
       * callee's %alloc and its %fork: the write context is already the
       * callee's frame, and the read context is still the caller's,
       * which is the frame a caller-local automatic actual lives in. */
      if (strcmp(stmt_name, "$ivl_ref_bind") == 0) {
	    ivl_expr_t formal = ivl_stmt_parm(net, 0);
	    ivl_expr_t actual = ivl_stmt_parm_count(net) > 1
		  ? ivl_stmt_parm(net, 1) : 0;
	    ivl_signal_t fsig = formal ? ivl_expr_signal(formal) : 0;
	    ivl_signal_t asig = actual ? ivl_expr_signal(actual) : 0;
	    if (fsig && asig)
		  fprintf(vvp_out, "    %%ref/bind v%p_0, v%p_0;\n",
			  fsig, asig);
	    return 0;
      }

      /* $ivl_ref_bind_prop(<formal>, <obj>, <pid>) -- bind a ref formal
       * to a property of the receiver object (R25: a true reference to
       * storage inside a variable, replacing the copy pair whose
       * copy-out at return lost writes from detached branches). */
      if (strcmp(stmt_name, "$ivl_ref_bind_prop") == 0) {
	    ivl_expr_t formal = ivl_stmt_parm(net, 0);
	    ivl_expr_t obj = ivl_stmt_parm(net, 1);
	    ivl_expr_t pid = ivl_stmt_parm(net, 2);
	    ivl_signal_t fsig = formal ? ivl_expr_signal(formal) : 0;
	    if (fsig && obj && pid
		&& ivl_expr_type(pid) == IVL_EX_NUMBER) {
		  draw_eval_object(obj);
		  fprintf(vvp_out, "    %%ref/bind/pr v%p_0, %lu;\n",
			  fsig, (unsigned long)get_number_immediate(pid));
	    }
	    return 0;
      }

      /* $ivl_ref_bind_elem(<formal>, <container>, <index>) -- bind a
       * ref formal to an element of a dynamic array or queue. */
      if (strcmp(stmt_name, "$ivl_ref_bind_elem") == 0) {
	    ivl_expr_t formal = ivl_stmt_parm(net, 0);
	    ivl_expr_t cont = ivl_stmt_parm(net, 1);
	    ivl_expr_t idx = ivl_stmt_parm(net, 2);
	    ivl_signal_t fsig = formal ? ivl_expr_signal(formal) : 0;
	    ivl_signal_t csig = cont ? ivl_expr_signal(cont) : 0;
	    if (fsig && csig && idx) {
		  draw_eval_vec4(idx);
		  fprintf(vvp_out, "    %%ref/bind/el v%p_0, v%p_0;\n",
			  fsig, csig);
	    }
	    return 0;
      }

      /* $ivl_ref_bind_word(<formal>, <array>, <index>) -- bind a ref
       * formal to one word of a static unpacked array. The index is
       * the canonical word offset. */
      if (strcmp(stmt_name, "$ivl_ref_bind_word") == 0) {
	    ivl_expr_t formal = ivl_stmt_parm(net, 0);
	    ivl_expr_t arr = ivl_stmt_parm(net, 1);
	    ivl_expr_t idx = ivl_stmt_parm(net, 2);
	    ivl_signal_t fsig = formal ? ivl_expr_signal(formal) : 0;
	    ivl_signal_t asig = arr ? ivl_expr_signal(arr) : 0;
	    if (fsig && asig && idx) {
		  draw_eval_vec4(idx);
		  fprintf(vvp_out, "    %%ref/bind/w v%p, v%p_0;\n",
			  asig, fsig);
	    }
	    return 0;
      }

      show_stmt_file_line(net, "System task call.");

      draw_vpi_task_call(net);

      return 0;
}

/*
 * Icarus translated <var> = <delay or event> <value> into
 *   begin
 *    <tmp> = <value>;
 *    <delay or event> <var> = <tmp>;
 *   end
 * This routine looks for this pattern so we only emit one %file_line opcode.
 */

static unsigned is_delayed_or_event_assign(ivl_scope_t scope,
                                           ivl_statement_t stmt)
{
      ivl_statement_t assign, delay, delayed_assign;
      ivl_statement_type_t delay_type;
      ivl_lval_t lval;
      ivl_expr_t rval;
      ivl_signal_t lsig, rsig;

      (void)scope; /* Parameter is not used. */

	/* We must have two block elements. */
      if (ivl_stmt_block_count(stmt) != 2) return 0;
	/* The first must be an assign. */
      assign = ivl_stmt_block_stmt(stmt, 0);
      if (ivl_statement_type(assign) != IVL_ST_ASSIGN) return 0;
	/* The second must be a delayx. */
      delay = ivl_stmt_block_stmt(stmt, 1);
      delay_type = ivl_statement_type(delay);
      if ((delay_type != IVL_ST_DELAYX) &&
          (delay_type != IVL_ST_WAIT)) return 0;
	/* The statement for the delayx must be an assign. */
      delayed_assign = ivl_stmt_sub_stmt(delay);
      if (ivl_statement_type(delayed_assign) != IVL_ST_ASSIGN) return 0;
	/* The L-value must be a single signal. */
      if (ivl_stmt_lvals(assign) != 1) return 0;
      lval = ivl_stmt_lval(assign, 0);
	/* It must not have an array select. */
      if (ivl_lval_idx(lval)) return 0;
	/* It must not have a non-zero base. */
      if (ivl_lval_part_off(lval)) return 0;
      lsig = ivl_lval_sig(lval);
	/* It must not be part of the signal. */
      if (ivl_lval_width(lval) != ivl_signal_width(lsig)) return 0;
	/* The R-value must be a single signal. */
      rval = ivl_stmt_rval(delayed_assign);
      if (ivl_expr_type(rval) != IVL_EX_SIGNAL) return 0;
	/* It must not be an array word. */
      if (ivl_expr_oper1(rval)) return 0;
      rsig = ivl_expr_signal(rval);
	/* The two signals must be the same. */
      if (lsig != rsig) return 0;
	/* And finally the three statements must have the same line number
	 * as the block. */
      if ((ivl_stmt_lineno(stmt) != ivl_stmt_lineno(assign)) ||
          (ivl_stmt_lineno(stmt) != ivl_stmt_lineno(delay)) ||
          (ivl_stmt_lineno(stmt) != ivl_stmt_lineno(delayed_assign))) {
            return 0;
      }
	/* The pattern matched so this block represents a blocking
	 * assignment with an inter-assignment delay or event. */
      if (delay_type == IVL_ST_DELAYX) {
	    show_stmt_file_line(stmt, "Blocking assignment (delay).");
      } else {
	    show_stmt_file_line(stmt, "Blocking assignment (event).");
      }
      return 1;
}

/*
 * Icarus translated <var> = repeat(<count>) <event> <value> into
 *   begin
 *    <tmp> = <value>;
 *    repeat(<count>) <event>;
 *    <var> = <tmp>;
 *   end
 * This routine looks for this pattern so we only emit one %file_line opcode.
 */
static unsigned is_repeat_event_assign(ivl_scope_t scope,
                                       ivl_statement_t stmt)
{
      ivl_statement_t assign, event, event_assign, repeat;
      ivl_lval_t lval;
      ivl_expr_t rval;
      ivl_signal_t lsig, rsig;

      (void)scope; /* Parameter is not used. */

	/* We must have three block elements. */
      if (ivl_stmt_block_count(stmt) != 3) return 0;
	/* The first must be an assign. */
      assign = ivl_stmt_block_stmt(stmt, 0);
      if (ivl_statement_type(assign) != IVL_ST_ASSIGN) return 0;
	/* The second must be a repeat with an event or an event. */
      repeat = ivl_stmt_block_stmt(stmt, 1);
      if (ivl_statement_type(repeat) != IVL_ST_REPEAT) return 0;
	/* The repeat must have an event statement. */
      event = ivl_stmt_sub_stmt(repeat);
      if (ivl_statement_type(event) != IVL_ST_WAIT) return 0;
	/* The third must be an assign. */
      event_assign = ivl_stmt_block_stmt(stmt, 2);
      if (ivl_statement_type(event_assign) != IVL_ST_ASSIGN) return 0;
	/* The L-value must be a single signal. */
      if (ivl_stmt_lvals(assign) != 1) return 0;
      lval = ivl_stmt_lval(assign, 0);
	/* It must not have an array select. */
      if (ivl_lval_idx(lval)) return 0;
	/* It must not have a non-zero base. */
      if (ivl_lval_part_off(lval)) return 0;
      lsig = ivl_lval_sig(lval);
	/* It must not be part of the signal. */
      if (ivl_lval_width(lval) != ivl_signal_width(lsig)) return 0;
	/* The R-value must be a single signal. */
      rval = ivl_stmt_rval(event_assign);
      if (ivl_expr_type(rval) != IVL_EX_SIGNAL) return 0;
	/* It must not be an array word. */
      if (ivl_expr_oper1(rval)) return 0;
      rsig = ivl_expr_signal(rval);
	/* The two signals must be the same. */
      if (lsig != rsig) return 0;
	/* And finally the four statements must have the same line number
	 * as the block. */
      if ((ivl_stmt_lineno(stmt) != ivl_stmt_lineno(assign)) ||
          (ivl_stmt_lineno(stmt) != ivl_stmt_lineno(repeat)) ||
          (ivl_stmt_lineno(stmt) != ivl_stmt_lineno(event)) ||
          (ivl_stmt_lineno(stmt) != ivl_stmt_lineno(event_assign))) {
	    return 0;
      }

	/* The pattern matched so this block represents a blocking
	 * assignment with an inter-assignment repeat event. */
      show_stmt_file_line(stmt, "Blocking assignment (repeat event).");
      return 1;
}

/*
 * Icarus translated wait(<expr) <stmt> into
 *   begin
 *    while (<expr> !== 1'b1) @(<expr sensitivities>);
 *    <stmt>
 *   end
 * This routine looks for this pattern and turns it back into a
 * wait statement.
 */
static unsigned is_wait(ivl_scope_t scope, ivl_statement_t stmt)
{
      ivl_statement_t while_wait, wait_x, wait_stmt;
      ivl_expr_t while_expr, expr;
      const char *bits;

      (void)scope; /* Parameter is not used. */

	/* We must have two block elements. */
      if (ivl_stmt_block_count(stmt) != 2) return 0;
	/* The first must be a while. */
      while_wait = ivl_stmt_block_stmt(stmt, 0);
      if (ivl_statement_type(while_wait) != IVL_ST_WHILE) return 0;
	/* That has a wait with a NOOP statement. */
      wait_x = ivl_stmt_sub_stmt(while_wait);
      if (ivl_statement_type(wait_x) != IVL_ST_WAIT) return 0;
      wait_stmt = ivl_stmt_sub_stmt(wait_x);
      if (ivl_statement_type(wait_stmt) != IVL_ST_NOOP) return 0;
	/* Check that the while condition has the correct form. */
      while_expr = ivl_stmt_cond_expr(while_wait);
      if (ivl_expr_type(while_expr) != IVL_EX_BINARY) return 0;
      if (ivl_expr_opcode(while_expr) != 'N') return 0;
	/* Has a second operator that is a constant 1'b1. */
      expr = ivl_expr_oper2(while_expr);
      if (ivl_expr_type(expr) != IVL_EX_NUMBER) return 0;
      if (ivl_expr_width(expr) != 1) return 0;
      bits = ivl_expr_bits(expr);
      if (*bits != '1') return 0;
	/* There is no easy way to verify that the @ sensitivity list
	 * matches the first expression so that is not currently checked. */
	/* And finally the two statements that represent the wait must
	 * have the same line number as the block. */
      if ((ivl_stmt_lineno(stmt) != ivl_stmt_lineno(while_wait)) ||
          (ivl_stmt_lineno(stmt) != ivl_stmt_lineno(wait_x))) {
	    return 0;
      }

	/* The pattern matched so this block represents a wait statement. */
      show_stmt_file_line(stmt, "Wait statement.");
      return 1;
}

/*
 * Check to see if the statement L-value is a port in the given scope.
 * If it is return the zero based port number.
 */
static unsigned utask_in_port_idx(ivl_scope_t scope, ivl_statement_t stmt)
{
      unsigned idx, ports = ivl_scope_ports(scope);
      ivl_lval_t lval = ivl_stmt_lval(stmt, 0);
      ivl_signal_t lsig = ivl_lval_sig(lval);
      const char *sig_name;
	/* The L-value must be a single signal. */
      if (ivl_stmt_lvals(stmt) != 1) return ports;
	/* It must not have an array select. */
      if (ivl_lval_idx(lval)) return ports;
	/* It must not have a non-zero base. */
      if (ivl_lval_part_off(lval)) return ports;
	/* It must not be part of the signal. */
      if (ivl_lval_width(lval) != ivl_signal_width(lsig)) return ports;
	/* It must have the same scope as the task. */
      if (scope != ivl_signal_scope(lsig)) return ports;
	/* It must be an input or inout port of the task. */
      sig_name = ivl_signal_basename(lsig);
      for (idx = 0; idx < ports; idx += 1) {
	    ivl_signal_t port = ivl_scope_port(scope, idx);
	    if (!port) continue;
	    ivl_signal_port_t port_type = ivl_signal_port(port);
	    if ((port_type != IVL_SIP_INPUT) &&
	        (port_type != IVL_SIP_INOUT)) continue;
	    if (strcmp(sig_name, ivl_signal_basename(port)) == 0) break;
      }
      return idx;
}

/*
 * Check to see if the statement R-value is a port in the given scope.
 * If it is return the zero based port number.
 */
static unsigned utask_out_port_idx(ivl_scope_t scope, ivl_statement_t stmt)
{
      unsigned idx, ports = ivl_scope_ports(scope);
      ivl_expr_t rval = ivl_stmt_rval(stmt);
      ivl_signal_t rsig = 0;
      ivl_expr_type_t expr_type = ivl_expr_type(rval);
      const char *sig_name;
	/* We can have a simple signal. */
      if (expr_type == IVL_EX_SIGNAL) {
	    rsig = ivl_expr_signal(rval);
	/* Or a simple select of a simple signal. */
      } else if (expr_type == IVL_EX_SELECT) {
	    ivl_expr_t expr = ivl_expr_oper1(rval);
	      /* We must have a zero select base. */
	    if (ivl_expr_oper2(rval)) return ports;
	      /* We must be selecting a signal. */
	    if (ivl_expr_type(expr) != IVL_EX_SIGNAL) return ports;
	    rsig = ivl_expr_signal(expr);
      } else return ports;
	/* The R-value must have the same scope as the task. */
      if (scope != ivl_signal_scope(rsig)) return ports;
	/* It must not be an array element. */
      if (ivl_signal_dimensions(rsig)) return ports;
	/* It must be an output or inout port of the task. */
      sig_name = ivl_signal_basename(rsig);
      for (idx = 0; idx < ports; idx += 1) {
	    ivl_signal_t port = ivl_scope_port(scope, idx);
	    if (!port) continue;
	    ivl_signal_port_t port_type = ivl_signal_port(port);
	    if ((port_type != IVL_SIP_OUTPUT) &&
	        (port_type != IVL_SIP_INOUT)) continue;
	    if (strcmp(sig_name, ivl_signal_basename(port)) == 0) break;
      }
      return idx;
}

/*
 * Structure to hold the port information as we extract it from the block.
 */
typedef struct port_expr_s {
      ivl_signal_port_t type;
      union {
	    ivl_statement_t lval;
	    ivl_expr_t rval;
      } expr;
}  *port_expr_t;

/*
 * Icarus encodes a user task call with arguments as:
 *   begin
 *     <input 1> = <arg>
 *     ...
 *     <input n> = <arg>
 *     <task_call>
 *     <arg> = <output 1>
 *     ...
 *     <arg> = <output n>
 *   end
 * This routine looks for that pattern and translates it into the
 * appropriate task call. It returns true (1) if it successfully
 * translated the block to a task call, otherwise it returns false
 * (0) to indicate the block needs to be emitted.
 */
static unsigned is_utask_call_with_args(ivl_scope_t scope,
                                        ivl_statement_t stmt)
{
      unsigned idx, ports, task_idx = 0;
      unsigned is_void_func;
      unsigned count = ivl_stmt_block_count(stmt);
      unsigned lineno = ivl_stmt_lineno(stmt);
      ivl_scope_t task_scope = 0;
      port_expr_t port_exprs;

      (void)scope; /* Parameter is not used. */

	/* Check to see if the block is of the basic form first.  */
      for (idx = 0; idx < count; idx += 1) {
	    ivl_statement_t tmp = ivl_stmt_block_stmt(stmt, idx);
	    if (ivl_statement_type(tmp) == IVL_ST_ASSIGN) continue;
	    if (ivl_statement_type(tmp) == IVL_ST_UTASK && !task_scope) {
		  task_idx = idx;
		  task_scope = ivl_stmt_call(tmp);
		  assert((ivl_scope_type(task_scope) == IVL_SCT_TASK) ||
		         (ivl_scope_type(task_scope) == IVL_SCT_FUNCTION));
		  continue;
	    }
	    return 0;
      }
	/* If there is no task call or it takes no argument then return. */
      if (!task_scope) return 0;
      ports = ivl_scope_ports(task_scope);
      if (ports == 0) return 0;

	/* Allocate space to save the port information and initialize it. */
      port_exprs = (port_expr_t) malloc(sizeof(struct port_expr_s)*ports);
      for (idx = 0; idx < ports; idx += 1) {
	    port_exprs[idx].type = IVL_SIP_NONE;
	    port_exprs[idx].expr.rval = 0;
      }
	/* Check that the input arguments are correct. */
      for (idx = 0; idx < task_idx; idx += 1) {
	    ivl_statement_t assign = ivl_stmt_block_stmt(stmt, idx);
	    unsigned port = utask_in_port_idx(task_scope, assign);
	    if ((port == ports) || (lineno != ivl_stmt_lineno(assign))) {
		  free(port_exprs);
		  return 0;
	    }
	    port_exprs[port].type = IVL_SIP_INPUT;
	    port_exprs[port].expr.rval = ivl_stmt_rval(assign);
      }
	/* Check that the output arguments are correct. */
      for (idx = task_idx + 1; idx < count; idx += 1) {
	    ivl_statement_t assign = ivl_stmt_block_stmt(stmt, idx);
	    unsigned port = utask_out_port_idx(task_scope, assign);
	    if ((port == ports) || (lineno != ivl_stmt_lineno(assign))) {
		  free(port_exprs);
		  return 0;
	    }
	    if (port_exprs[port].type == IVL_SIP_INPUT) {
		    /* We probably should verify that the current R-value
		     * matches the new L-value. */
		  port_exprs[port].type = IVL_SIP_INOUT;
	    } else {
		  port_exprs[port].type = IVL_SIP_OUTPUT;
	    }
	    port_exprs[port].expr.lval = assign;
      }
	/* Check that the task call has the correct line number. */
      if (lineno != ivl_stmt_lineno(ivl_stmt_block_stmt(stmt, task_idx))) {
	    free(port_exprs);
	    return 0;
      }

	/* Verify that all the ports were defined. */
      is_void_func = (ivl_scope_type(task_scope) == IVL_SCT_FUNCTION);
      if (is_void_func) {
	    assert(port_exprs[0].type == IVL_SIP_NONE);
      }
      for (idx = is_void_func; idx < ports; idx += 1) {
	    if (port_exprs[idx].type == IVL_SIP_NONE) {
		  free(port_exprs);
		  return 0;
	    }
      }

	/* The pattern matched so this block represents a call to a user
	 * defined task with arguments. */
      show_stmt_file_line(stmt, "User task call (with arguments).");
      free(port_exprs);
      return 1;
}

/*
 * This function draws a statement as vvp assembly. It basically
 * switches on the statement type and draws code based on the type and
 * further specifics.
 */
int show_statement(ivl_statement_t net, ivl_scope_t sscope)
{
      const ivl_statement_type_t code = ivl_statement_type(net);
      int rc = 0;

      /* Nothing except the resolved call's zero-formal static/automatic
       * plumbing may appear between the internal task markers. Diagnose the
       * first escape and suppress the remainder of that already-failed thunk
       * until its end marker restores the ordinary drawing state. */
      if (deferred_final_task_frame_.active) {
            int is_end = code == IVL_ST_STASK
                  && strcmp(ivl_stmt_name(net),
                            "$ivl_deferred_final_task_end") == 0;

            if (deferred_final_task_frame_.phase == 2 && !is_end)
                  return 0;

            if (is_end) {
                  /* The ordinary STASK switch below consumes the marker. */
            } else if (code == IVL_ST_BLOCK
                       && !ivl_stmt_block_scope(net)) {
                  /* Automatic-task call setup is an unnamed sequence. */
            } else if (code == IVL_ST_NOOP) {
                  /* Recovery/noop nodes are inert. */
            } else if (code == IVL_ST_ALLOC
                       && deferred_final_task_frame_.phase == 0
                       && !deferred_final_task_frame_.saw_alloc) {
                  deferred_final_task_frame_.saw_alloc = 1;
                  deferred_final_task_frame_.alloc_scope = ivl_stmt_call(net);
            } else if (code == IVL_ST_UTASK
                       && deferred_final_task_frame_.phase == 0) {
                  /* show_stmt_utask validates the resolved task and body. */
            } else if (code == IVL_ST_FREE
                       && deferred_final_task_frame_.phase == 1
                       && deferred_final_task_frame_.saw_alloc
                       && !deferred_final_task_frame_.saw_free
                       && ivl_stmt_call(net)
                            == deferred_final_task_frame_.task_scope) {
                  deferred_final_task_frame_.saw_free = 1;
            } else {
                  fprintf(stderr,
                          "%s:%u: sorry: final-deferred user-task action "
                          "generated unsupported call plumbing; task actuals, "
                          "methods, nested/timed calls, and mutating forms "
                          "remain unsupported.\n",
                          ivl_stmt_file(net), ivl_stmt_lineno(net));
                  vvp_errors += 1;
                  deferred_final_task_frame_.phase = 2;
                  return 1;
            }
      }

      switch (code) {

	  case IVL_ST_ALLOC:
	    rc += show_stmt_alloc(net);
	    break;

	  case IVL_ST_ASSIGN:
	    rc += show_stmt_assign(net);
	    break;

	  case IVL_ST_ASSIGN_NB:
	    rc += show_stmt_assign_nb(net);
	    break;

	  case IVL_ST_BLOCK:
	    if (ivl_stmt_block_scope(net))
		  rc += show_stmt_block_named(net, sscope);
	    else {
		  unsigned saved_file_line = 0;
		    /* This block could really represent a single statement.
		     * If so only emit a single %file_line opcode. */
		  if (show_file_line) {
			if (is_delayed_or_event_assign(sscope, net) ||
			    is_repeat_event_assign(sscope, net) ||
			    is_wait(sscope, net) ||
			    is_utask_call_with_args(sscope, net)) {
			      saved_file_line = show_file_line;
			      show_file_line = 0;
			}
		  }
		  rc += show_stmt_block(net, sscope);
		  if (saved_file_line) show_file_line = 1;
	    }
	    break;

          case IVL_ST_BREAK:
	    rc += show_stmt_break(net, sscope);
	    break;

	  case IVL_ST_CASE:
	  case IVL_ST_CASEX:
	  case IVL_ST_CASEZ:
	    rc += show_stmt_case(net, sscope);
	    break;

	  case IVL_ST_CASER:
	    rc += show_stmt_case_r(net, sscope);
	    break;

	  case IVL_ST_CASSIGN:
	    rc += show_stmt_cassign(net);
	    break;

	  case IVL_ST_CONDIT:
	    rc += show_stmt_condit(net, sscope);
	    break;

          case IVL_ST_CONTINUE:
	    rc += show_stmt_continue(net, sscope);
	    break;

	  case IVL_ST_DEASSIGN:
	    rc += show_stmt_deassign(net);
	    break;

	  case IVL_ST_DELAY:
	    rc += show_stmt_delay(net, sscope);
	    break;

	  case IVL_ST_DELAYX:
	    rc += show_stmt_delayx(net, sscope);
	    break;

	  case IVL_ST_DISABLE:
	    rc += show_stmt_disable(net, sscope);
	    break;

	  case IVL_ST_DO_WHILE:
	    rc += show_stmt_do_while(net, sscope);
	    break;

	  case IVL_ST_FORCE:
	    rc += show_stmt_force(net);
	    break;

	  case IVL_ST_FOREVER:
	    rc += show_stmt_forever(net, sscope);
	    break;

	  case IVL_ST_FORK:
	  case IVL_ST_FORK_JOIN_ANY:
	  case IVL_ST_FORK_JOIN_NONE:
	    rc += show_stmt_fork(net, sscope);
	    break;

	  case IVL_ST_FORLOOP:
	    rc += show_stmt_forloop(net, sscope);
	    break;

	  case IVL_ST_FREE:
	    rc += show_stmt_free(net, sscope);
	    break;

	  case IVL_ST_NOOP:
	    rc += show_stmt_noop(net);
	    break;

	  case IVL_ST_RELEASE:
	    rc += show_stmt_release(net);
	    break;

	  case IVL_ST_REPEAT:
	    rc += show_stmt_repeat(net, sscope);
	    break;

	  case IVL_ST_STASK:
	    rc += show_system_task_call(net, sscope);
	    break;

	  case IVL_ST_TRIGGER:
	    rc += show_stmt_trigger(net);
	    break;

	  case IVL_ST_NB_TRIGGER:
	    rc += show_stmt_nb_trigger(net);
	    break;

	  case IVL_ST_TRIGGER_OBJ:
	  case IVL_ST_NB_TRIGGER_OBJ:
	    rc += show_stmt_trigger_obj(net);
	    break;

	  case IVL_ST_WAIT_OBJ:
	    rc += show_stmt_wait_obj(net, sscope);
	    break;

	  case IVL_ST_TRIGGER_ARR:
	  case IVL_ST_NB_TRIGGER_ARR:
	    rc += show_stmt_trigger_arr(net);
	    break;

	  case IVL_ST_WAIT_ARR:
	    rc += show_stmt_wait_arr(net, sscope);
	    break;

	  case IVL_ST_UTASK:
	    rc += show_stmt_utask(net);
	    break;

	  case IVL_ST_WAIT:
	    rc += show_stmt_wait(net, sscope);
	    break;

	  case IVL_ST_WAIT_ORDER:
	    rc += show_stmt_wait_order(net, sscope);
	    break;

	  case IVL_ST_WHILE:
	    rc += show_stmt_while(net, sscope);
	    break;

	  default:
	    fprintf(stderr, "vvp.tgt: Unable to draw statement type %d\n",
		    code);
	    rc += 1;
	    break;
      }

      return rc;
}


/*
 * The process as a whole is surrounded by this code. We generate a
 * start label that the .thread statement can use, and we generate
 * code to terminate the thread.
 */

int draw_process(ivl_process_t net, void*x)
{
      int rc = 0;
      unsigned idx;
      ivl_scope_t scope = ivl_process_scope(net);
      ivl_statement_t stmt = ivl_process_stmt(net);
      int pure_comb_flag = 0;

      int init_flag = 0;
      int push_flag = 0;
      int clocking_bg_flag = 0;
      int clocking_sync_flag = 0;
      int function_background_ok = 0;

      (void)x; /* Parameter is not used. */

      for (idx = 0 ;  idx < ivl_process_attr_cnt(net) ;  idx += 1) {

	    ivl_attribute_t attr = ivl_process_attr_val(net, idx);
	    if (strcmp(attr->key, "_ivl_function_background_ok") == 0)
		  function_background_ok = 1;

	    if (strcmp(attr->key, "_ivl_schedule_init") == 0) {

		  init_flag = 1;

	    }

	    if (strcmp(attr->key, "_ivl_schedule_push") == 0) {

		  push_flag = 1;

	    } else if (strcmp(attr->key, "ivl_combinational") == 0) {

		  push_flag = 1;

	    } else if (strcmp(attr->key, "_ivl_clocking_bg") == 0) {

		    /* A synthesized clocking sampler/apply process: an INITIAL
		       wrapping a forever loop that never completes. It must not
		       be tagged `$prog`, or a program whose only post-initial
		       activity is a clocking block would never reach
		       program-completion end-of-simulation. */
		  clocking_bg_flag = 1;

	    } else if (strcmp(attr->key, "_ivl_clocking_sync") == 0) {

		    /* A synthesized clocking sampler or numeric-skew shadow
		       driver. Even when declared in a program, this is design
		       scheduler infrastructure: its NBA work must settle before
		       the public clocking event fires in Observed. `$clocking`
		       clears the program scope's Reactive affinity at runtime and
		       also keeps an INITIAL sampler out of the program-completion
		       count. */
		  clocking_bg_flag = 1;
		  clocking_sync_flag = 1;

	    }
      }

      local_count = 0;
      fprintf(vvp_out, "    .scope S_%p;\n", scope);

      if (ivl_process_type(net) == IVL_PR_ALWAYS_COMB
	  && !ivl_scope_is_auto(scope)
	  && !ivl_scope_program(scope)
	  && ivl_statement_type(stmt) == IVL_ST_WAIT
	  && ivl_stmt_needs_t0_trigger(stmt)
	  && pure_comb_stmt_(ivl_stmt_sub_stmt(stmt))
	  && !pure_comb_has_read_before_definition_(
		ivl_stmt_sub_stmt(stmt)))
	    pure_comb_flag = 1;

	/* Generate the entry label. Just give the thread a number so
	   that we are certain the label is unique. */
      fprintf(vvp_out, "T_%u ;\n", thread_count);

      if (pure_comb_flag) {
	    fprintf(vvp_out, "    %%comb/register;\n");
	    pure_comb_top_wait_ = stmt;
      }

	/* Draw the contents of the thread. */
      rc += show_statement(stmt, scope);
      if (pure_comb_flag)
	    pure_comb_top_wait_ = 0;


	/* Terminate the thread with either an %end instruction (initial
	   statements) or a %jmp back to the beginning of the thread. */

      switch (ivl_process_type(net)) {

	  case IVL_PR_INITIAL:
	  case IVL_PR_FINAL:
	    fprintf(vvp_out, "    %%end;\n");
	    break;

	  case IVL_PR_ALWAYS:
	  case IVL_PR_ALWAYS_COMB:
	  case IVL_PR_ALWAYS_FF:
	  case IVL_PR_ALWAYS_LATCH:
	    fprintf(vvp_out, "    %%jmp T_%u;\n", thread_count);
	    break;
      }

	/* Now write out the directive that tells vvp where the thread
	   starts. */
      switch (ivl_process_type(net)) {

	  case IVL_PR_INITIAL:
	  case IVL_PR_ALWAYS:
	  case IVL_PR_ALWAYS_COMB:
	  case IVL_PR_ALWAYS_FF:
	  case IVL_PR_ALWAYS_LATCH:
	    {
		  const char*thread_flag = 0;
	    if (init_flag) {
		  thread_flag = "$init";
	    } else if (push_flag) {
		  thread_flag = "$push";
	    } else if (clocking_sync_flag) {
		  thread_flag = "$clocking";
	    } else if (ivl_process_type(net) == IVL_PR_INITIAL
		       && ivl_scope_program(scope) && !clocking_bg_flag) {
		    /* M6B: a program-block INITIAL procedure. Mark it so the
		       runtime can end the simulation when the last program
		       initial completes (IEEE 1800-2017 24.7). Concurrent
		       assertions/clocking in the program are ALWAYS-type and
		       are not marked, so they do not keep the sim alive. */
		  thread_flag = "$prog";
	    }
	    if (function_background_ok) {
		  if (thread_flag)
			fprintf(vvp_out, "    .thread T_%u, %s, $function_background_ok;\n",
				thread_count, thread_flag);
		  else
			fprintf(vvp_out, "    .thread T_%u, $function_background_ok;\n",
				thread_count);
	    } else if (thread_flag) {
		  fprintf(vvp_out, "    .thread T_%u, %s;\n",
			  thread_count, thread_flag);
	    } else {
		  fprintf(vvp_out, "    .thread T_%u;\n", thread_count);
	    }
	    }
	    break;

	  case IVL_PR_FINAL:
	    fprintf(vvp_out, "    .thread T_%u, $final;\n", thread_count);
	    break;
      }

      thread_count += 1;
      return rc;
}

static void draw_dpi_func_body(ivl_scope_t scope, int is_task);

int draw_task_definition(ivl_scope_t scope)
{
      int rc = 0;
      ivl_statement_t def = ivl_scope_def(scope);
      const char*label = vvp_mangle_id(ivl_scope_name(scope));

	/* A DPI import task has no pform body; synthesize the
	   marshaling body instead. */
      if (ivl_scope_is_dpi_import(scope)) {
	    fprintf(vvp_out, "TD_%s ;\n", label);
	    note_td_definition(label);
	    draw_dpi_func_body(scope, 1);
	    fprintf(vvp_out, "    %%end;\n");
	    thread_count += 1;
	    return 0;
      }

      if (def == 0)
	    return 0;

      fprintf(vvp_out, "TD_%s ;\n", label);
      note_td_definition(label);

      rc += show_statement(def, scope);

      fprintf(vvp_out, "    %%end;\n");

      thread_count += 1;
      return rc;
}

/*
 * M10: emit the synthesized body of a DPI import function: load each
 * argument onto its stack, then a %dpi/call opcode carrying the
 * per-argument signature string the runtime marshaler consumes. Each
 * signature token is [+][u]<letter>: '+' output/inout copyback direction,
 * 'u' unsigned, letter 'b'/'h'/'i'/'l' by width for 2-state integer
 * atoms (byte/shortint/int/longint), 'p' chandle (void*), 'V'/'W'
 * canonical packed bit/logic vectors, 'g' 4-state scalar (svLogic),
 * 'f' shortreal, 'r' real, 's' string, 'x'/'y' dynamic/open arrays of packed bit/logic
 * vectors, 'X'/'Y' their fixed-array counterparts, 'B'/'G' fixed arrays
 * of true scalar svBit/svLogic elements, and 'q'/'Q' shortreal open/fixed
 * arrays. The distinctions let the runtime
 * expose the exact Annex H C representation, including canonical packed
 * element storage when the actual is a non-contiguous queue.
 *
 * Unsupported argument shapes are diagnosed loudly (never silent) and
 * the call is not emitted — the body pushes a zero/empty result so
 * simulation can proceed deterministically.
 */
static void draw_dpi_func_body(ivl_scope_t scope, int is_task)
{
      const char*c_name = ivl_scope_dpi_c_name(scope);
      unsigned nports = ivl_scope_ports(scope);
	/* Function port 0 is the return value; task ports are all
	   arguments. */
      unsigned first_port = is_task ? 0 : 1;
      unsigned ncp = (nports >= first_port) ? (nports - first_port) : 0;
      ivl_variable_type_t rtype = is_task ? IVL_VT_VOID
                                          : ivl_scope_func_type(scope);
      ivl_signal_t return_port = (!is_task && nports > 0)
	                       ? ivl_scope_port(scope, 0) : 0;
      ivl_type_t return_nt = return_port
	                  ? ivl_signal_net_type(return_port) : 0;
      int return_is_chandle = ivl_type_is_chandle(return_nt);
      int return_is_shortreal = ivl_type_is_shortreal(return_nt);
      int return_is_packed = return_nt
	                  && ivl_type_is_packed_vector(return_nt);
      unsigned rwid = (rtype == IVL_VT_LOGIC || rtype == IVL_VT_BOOL)
                    ? ivl_scope_func_width(scope) : 0;
      char return_letter = (rwid > 32) ? 'l' : 'i';
      int unsupported = 0;

	/* Preserve the exact Annex H C return type through the textual VVP
	   instruction. In particular, byte/svBit/svLogic are C byte returns,
	   not int32_t returns. Upper-case integer letters are the unsigned
	   counterparts of the lower-case letters; 'g' is an svLogic scalar so
	   the runtime can restore X/Z instead of truncating its encoding. */
      if (!is_task && (rtype == IVL_VT_LOGIC || rtype == IVL_VT_BOOL)) {
	    if (rwid == 1)
		  return_letter = (rtype == IVL_VT_LOGIC) ? 'g' : 'B';
	    else if (rwid <= 8)
		  return_letter = ivl_scope_func_signed(scope) ? 'b' : 'B';
	    else if (rwid <= 16)
		  return_letter = ivl_scope_func_signed(scope) ? 'h' : 'H';
	    else if (rwid <= 32)
		  return_letter = ivl_scope_func_signed(scope) ? 'i' : 'I';
	    else
		  return_letter = ivl_scope_func_signed(scope) ? 'l' : 'L';
      }

      char arg_types[256];
      unsigned types_pos = 0;

      if (ncp > 64) {
	    fprintf(stderr, "%s:%u: sorry: DPI import '%s' has %u "
		    "arguments; more than 64 are not supported.\n",
		    ivl_scope_def_file(scope), ivl_scope_def_lineno(scope),
		    c_name, ncp);
	    unsupported = 1;
      }
      if (!is_task && return_is_packed
	  && (rtype == IVL_VT_LOGIC || rtype == IVL_VT_BOOL)) {
	    fprintf(stderr, "%s:%u: error: DPI import '%s': packed bit/logic "
		    "function result is not permitted by IEEE 1800 Annex H; "
		    "use an integer atom or scalar bit/logic result.\n",
		    ivl_scope_def_file(scope), ivl_scope_def_lineno(scope),
		    c_name);
	    unsupported = 1;
	    vvp_errors += 1;
      } else if (!is_task && rtype != IVL_VT_VOID
		 && rtype != IVL_VT_REAL && rtype != IVL_VT_STRING
		 && !return_is_chandle
		 && !((rtype == IVL_VT_LOGIC || rtype == IVL_VT_BOOL)
		      && (rwid == 1 || rwid == 8 || rwid == 16
			  || rwid == 32 || rwid == 64))) {
	    fprintf(stderr, "%s:%u: error: DPI import '%s': function result "
		    "type is not permitted by IEEE 1800 Annex H.8.9.\n",
		    ivl_scope_def_file(scope), ivl_scope_def_lineno(scope),
		    c_name);
	    unsupported = 1;
	    vvp_errors += 1;
      } else if (rwid > 64) {
	    fprintf(stderr, "%s:%u: sorry: DPI import '%s' returns a "
		    "%u-bit vector; by-value DPI returns are limited to "
		    "64 bits.\n",
		    ivl_scope_def_file(scope), ivl_scope_def_lineno(scope),
		    c_name, rwid);
	    unsupported = 1;
      }

	/* Output/inout arguments collected for the post-call stores:
	   the runtime pushes their callee-written values (above the
	   return value), and the body stores them into the port
	   variables in reverse order. The standard call machinery
	   then copies them out to the caller's actual lvalues. */
      ivl_signal_t out_ports[64];
      char out_kinds[64];
      unsigned out_wids[64];
      unsigned nout = 0;

      for (unsigned ii = first_port; !unsupported && ii < nports; ii += 1) {
	    ivl_signal_t port = ivl_scope_port(scope, ii);
	    ivl_variable_type_t ptype = ivl_signal_data_type(port);
	    unsigned pwid = ivl_signal_width(port);
	    int is_out = (ivl_signal_port(port) != IVL_SIP_INPUT);
	    char letter = 0;

	    if (ivl_signal_dimensions(port) > 0) {
	    /* Fixed unpacked arrays use the Annex H direct C-pointer ABI.
	       Materialize the inline word array before the call and copy it
	       back below for output/inout directions. */
		  ivl_type_t nt = ivl_signal_net_type(port);
		  int elem_ok = (ptype == IVL_VT_REAL)
			|| ((ptype == IVL_VT_BOOL || ptype == IVL_VT_LOGIC)
			    && pwid > 0);
		  if (!elem_ok) {
			fprintf(stderr, "%s:%u: sorry: DPI import '%s': "
				"fixed unpacked array argument '%s' must have "
				"packed bit/logic or real elements; the call is "
				"skipped.\n",
				ivl_scope_def_file(scope),
				ivl_scope_def_lineno(scope), c_name,
				ivl_signal_basename(port));
			unsupported = 1;
			break;
		  }
		  if (nt && ivl_type_is_packed_vector(nt)) {
			letter = (ptype == IVL_VT_LOGIC) ? 'Y' : 'X';
		  } else if (ptype == IVL_VT_REAL
			     && ivl_type_is_shortreal(nt)) {
			letter = 'Q';
		  } else if (pwid == 1 && ptype == IVL_VT_BOOL) {
			letter = 'B';
		  } else if (pwid == 1 && ptype == IVL_VT_LOGIC) {
			letter = 'G';
		  } else {
			letter = 'O';
		  }
	    } else if (ptype == IVL_VT_REAL) {
		  ivl_type_t nt = ivl_signal_net_type(port);
		  letter = ivl_type_is_shortreal(nt) ? 'f' : 'r';
	    } else if (ptype == IVL_VT_STRING) {
		  letter = 's';
	    } else if (ptype == IVL_VT_DARRAY) {
		    /* Open array (35.5.6.1): pass an svOpenArrayHandle.
		       Atom/real elements may expose direct storage through
		       svGetArrElemPtr; arbitrary packed bit/logic elements use
		       the canonical svGet/Put*ArrElem*VecVal copy API. */
		  ivl_type_t nt = ivl_signal_net_type(port);
		  ivl_type_t et = nt ? ivl_type_element(nt) : 0;
		    /* M10B-md: a MULTI-dimensional open array is a
		       darray of darrays. Walk to the leaf element
		       type; the runtime walks the same object tree
		       (svGetArrElemPtr2/3), only the innermost
		       storage must be contiguous atoms. */
		  while (et && ivl_type_base(et) == IVL_VT_DARRAY)
			et = ivl_type_element(et);
		  ivl_variable_type_t ebase = et ? ivl_type_base(et)
			                         : IVL_VT_NO_TYPE;
		  unsigned ewid = et ? ivl_type_packed_width(et) : 0;
		  int elem_ok = (ebase == IVL_VT_REAL)
			|| ((ebase == IVL_VT_BOOL || ebase == IVL_VT_LOGIC)
			    && ewid > 0);
		  if (! elem_ok) {
			fprintf(stderr, "%s:%u: sorry: DPI import '%s': "
				"open array argument '%s' must have packed "
				"bit/logic or real elements; the "
				"call is skipped.\n",
				ivl_scope_def_file(scope),
				ivl_scope_def_lineno(scope),
				c_name, ivl_signal_basename(port));
			unsupported = 1;
			break;
		  }
		  if (ebase == IVL_VT_REAL && ivl_type_is_shortreal(et))
			letter = 'q';
		  else if (et && ivl_type_is_packed_vector(et))
			letter = (ebase == IVL_VT_LOGIC) ? 'y' : 'x';
		  else
			letter = 'o';
	    } else if (ptype == IVL_VT_LOGIC || ptype == IVL_VT_BOOL) {
		  ivl_type_t nt = ivl_signal_net_type(port);
		  if (nt && ivl_type_is_chandle(nt)) {
			/* IEEE 1800 Annex H maps chandle to void*. */
			letter = 'p';
		  } else if (nt && ivl_type_is_packed_vector(nt)) {
			  /* Explicit vectors, integer/time, enums with vector
			     bases, and packed aggregates use the canonical
			     svBitVecVal/svLogicVecVal pointer ABI. */
			letter = (ptype == IVL_VT_LOGIC) ? 'W' : 'V';
		  } else if (pwid == 1) {
			  /* svBit/svLogic scalar: unsigned char both
			     ways, 4-state encoding for logic. */
			letter = 'g';
		  } else if (is_out
			     && pwid != 8 && pwid != 16
			     && pwid != 32 && pwid != 64) {
			fprintf(stderr, "%s:%u: sorry: DPI import '%s': "
				"output argument '%s' is %u bits wide; "
				"output integers must be an atom width "
				"(8/16/32/64 bits or a 1-bit scalar).\n",
				ivl_scope_def_file(scope),
				ivl_scope_def_lineno(scope),
				c_name, ivl_signal_basename(port), pwid);
			unsupported = 1;
			break;
		  } else {
			if (ptype == IVL_VT_LOGIC && pwid > 1) {
			      fprintf(stderr, "%s:%u: warning: DPI import "
				      "'%s': 4-state vector argument '%s' is "
				      "passed as a 2-state integer (X/Z bits "
				      "coerce to 0); declare the C parameter "
				      "as a plain integer type.\n",
				      ivl_scope_def_file(scope),
				      ivl_scope_def_lineno(scope),
				      c_name, ivl_signal_basename(port));
			}
			if (pwid <= 8)       letter = 'b';
			else if (pwid <= 16) letter = 'h';
			else if (pwid <= 32) letter = 'i';
			else                 letter = 'l';
		  }
	    } else {
		  fprintf(stderr, "%s:%u: sorry: DPI import '%s': argument "
			  "'%s' has a type not yet marshaled for DPI; the "
			  "call is skipped.\n",
			  ivl_scope_def_file(scope),
			  ivl_scope_def_lineno(scope),
			  c_name, ivl_signal_basename(port));
		  unsupported = 1;
		  break;
	    }

	      /* Load the incoming value (for outputs this seeds the
		 pointer buffer — exact for inout, harmless for pure
		 output whose entry value is undefined per 35.5.6.1). */
	    if (letter == 'r' || letter == 'f')
		  fprintf(vvp_out, "    %%load/real v%p_0;\n", (void*)port);
	    else if (letter == 's')
		  fprintf(vvp_out, "    %%load/str v%p_0;\n", (void*)port);
	    else if (letter == 'o' || letter == 'O'
		     || letter == 'q' || letter == 'Q'
		     || letter == 'B' || letter == 'G'
		     || letter == 'x' || letter == 'X'
		     || letter == 'y' || letter == 'Y') {
		  if (ivl_signal_dimensions(port) > 0) {
			unsigned kind;
			if (!uarray_container_kind_(port, &kind,
						 ivl_scope_def_file(scope),
						 ivl_scope_def_lineno(scope))) {
			      unsupported = 1;
			      break;
			}
			emit_load_arr_dar_dpi_(port, kind);
		  } else {
			fprintf(vvp_out, "    %%load/obj v%p_0;\n", (void*)port);
		  }
	    }
	    else
		  fprintf(vvp_out, "    %%load/vec4 v%p_0;\n", (void*)port);

	      /* Return output/inout open-array objects as well: dynamic
		 formals simply retain their shared object, while fixed formals
		 unmarshal the temporary back into their inline words. */
	    if (is_out)
		  arg_types[types_pos++] = '+';
	    if ((letter == 'b' || letter == 'h' || letter == 'i'
		 || letter == 'l') && ! ivl_signal_signed(port))
		  arg_types[types_pos++] = 'u';
	    arg_types[types_pos++] = letter;

	    if (is_out) {
		  out_ports[nout] = port;
		  out_kinds[nout] = letter;
		  out_wids[nout] = pwid;
		  nout += 1;
	    }
      }
      arg_types[types_pos] = 0;

      if (unsupported) {
	      // Loudly diagnosed above: push a deterministic default
	      // result instead of a broken call.
	    if (rtype == IVL_VT_REAL) {
		  fprintf(vvp_out, "    %%pushi/real 0, 0;\n");
		  fprintf(vvp_out, "    %%ret/real 0;\n");
	    } else if (rtype == IVL_VT_STRING) {
		  fprintf(vvp_out, "    %%pushi/str \"\";\n");
		  fprintf(vvp_out, "    %%ret/str 0;\n");
	    } else if (rtype != IVL_VT_VOID) {
		  fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", rwid);
		  fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", rwid);
	    }
	    return;
      }

      // Use '|' as the name/types separator: it's not legal in C function
      // names, and the vvp lexer's strdup_and_demangle passes it through
      // as a regular character (it only unescapes \" and \\).
      if (rtype == IVL_VT_REAL) {
	    fprintf(vvp_out, "    %%dpi/call/%s \"%s|%s\", %u;\n",
		    return_is_shortreal ? "shortreal" : "real",
		    c_name, arg_types, ncp);
      } else if (rtype == IVL_VT_STRING) {
	    fprintf(vvp_out, "    %%dpi/call/str \"%s|%s\", %u;\n",
		    c_name, arg_types, ncp);
      } else if (return_is_chandle) {
	    fprintf(vvp_out, "    %%dpi/call/ptr \"%s|%s\", %u;\n",
		    c_name, arg_types, ncp);
      } else if (rtype == IVL_VT_VOID) {
	      /* A DPI import *task* (35.5) may be time-consuming and has an
		 int status ABI (35.9), so /task/ack runs C on a coroutine and
		 validates its acknowledgement. Keep %dpi/call/task in the VVP
		 runtime only as the old-image void-ABI compatibility path. A
		 void *function* stays on synchronous %dpi/call/void. */
	    fprintf(vvp_out, "    %%dpi/call/%s \"%s|%s\", %u;\n",
		    is_task ? "task/ack" : "void", c_name, arg_types, ncp);
      } else {
	      /* '^<letter>' is a return-ABI prefix, followed by the existing
		 argument signature. A new runtime still accepts old images without
		 this prefix and falls back to their historical width-only rule. */
	    fprintf(vvp_out, "    %%dpi/call/vec4 \"%s|^%c%s\", %u, %u;\n",
		    c_name, return_letter, arg_types, ncp, rwid);
      }

	/* Store the callee-written output values (pushed above the
	   return value, in argument order) back into the port
	   variables — reverse order pops them correctly and leaves
	   the return value on top for %ret. */
      for (unsigned ii = nout; ii > 0; ii -= 1) {
	    ivl_signal_t port = out_ports[ii-1];
	    switch (out_kinds[ii-1]) {
		case 'f':
		case 'r':
		  fprintf(vvp_out, "    %%store/real v%p_0;\n", (void*)port);
		  break;
		case 's':
		  fprintf(vvp_out, "    %%store/str v%p_0;\n", (void*)port);
		  break;
		case 'o':
		case 'O':
		case 'q':
		case 'Q':
		case 'B':
		case 'G':
		case 'x':
		case 'X':
		case 'y':
		case 'Y':
		  if (ivl_signal_dimensions(port) > 0) {
			unsigned kind;
			if (uarray_container_kind_(port, &kind,
						 ivl_scope_def_file(scope),
						 ivl_scope_def_lineno(scope)))
			      emit_store_arr_dar_dpi_(port, kind);
		  } else {
			fprintf(vvp_out, "    %%store/obj v%p_0;\n", (void*)port);
		  }
		  break;
		case 'g':
		  fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, 1;\n",
			  (void*)port);
		  break;
		default:
		  fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
			  (void*)port, out_wids[ii-1]);
		  break;
	    }
      }

      if (rtype == IVL_VT_REAL) {
	    fprintf(vvp_out, "    %%ret/real 0;\n");
      } else if (rtype == IVL_VT_STRING) {
	    fprintf(vvp_out, "    %%ret/str 0;\n");
      } else if (rtype != IVL_VT_VOID) {
	    fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", rwid);
      }
}

int draw_func_definition(ivl_scope_t scope)
{
      int rc = 0;
      ivl_statement_t def = ivl_scope_def(scope);
      const char*label = vvp_mangle_id(ivl_scope_name(scope));

      if (def == 0)
	    return 0;

      fprintf(vvp_out, "TD_%s ;\n", label);
      note_td_definition(label);

      if (ivl_scope_is_dpi_import(scope)) {
	    draw_dpi_func_body(scope, 0);
      } else {
	    rc += show_statement(def, scope);
	    publish_materialized_return(scope);
      }

      fprintf(vvp_out, "    %%end;\n");

      thread_count += 1;
      return rc;
}
