/*
 * Copyright (c) 2001-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "vvp_priv.h"
# include  <stdlib.h>
# include  <math.h>
# include  <string.h>
# include  <inttypes.h>
# include  <assert.h>
# include  "ivl_alloc.h"

struct deferred_array_decl_s {
      ivl_signal_t sig;
      unsigned needed : 1;
      unsigned emitted : 1;
      struct deferred_array_decl_s*next;
};

static struct deferred_array_decl_s*deferred_array_decls = 0;

static struct deferred_array_decl_s*find_deferred_array_decl_(ivl_signal_t sig)
{
      struct deferred_array_decl_s*cur;

      for (cur = deferred_array_decls ; cur ; cur = cur->next)
	    if (cur->sig == sig)
		  return cur;

      cur = calloc(1, sizeof(*cur));
      cur->sig = sig;
      cur->next = deferred_array_decls;
      deferred_array_decls = cur;
      return cur;
}

static void note_array_signal_emitted_(ivl_signal_t sig)
{
      if (!sig || ivl_signal_dimensions(sig) == 0)
	    return;

      find_deferred_array_decl_(sig)->emitted = 1;
}

void note_array_signal_use(ivl_signal_t sig)
{
      if (!sig || ivl_signal_dimensions(sig) == 0)
	    return;

      find_deferred_array_decl_(sig)->needed = 1;
}

/*
 *  Escape non-symbol characters in ids, and quotes in strings.
 */

__inline__ static char hex_digit(unsigned i)
{
      i &= 0xf;
      return i>=10 ? i-10+'A' : i+'0';
}

const char *vvp_mangle_id(const char *id)
{
      static char *out = 0x0;
      static size_t out_len;

      int nesc = 0;
      int iout = 0;
      const char *inp = id;

      const char nosym[] = "!\"#%&'()*+,-/:;<=>?@[\\]^`{|}~";

      const char *se = strpbrk(inp, nosym);
      if (!se)
	    return id;

      do {
	    int n = se - inp;
	    unsigned int nlen = strlen(id) + 4*(++nesc) + 1;
	    if (out_len < nlen) {
		  out = realloc(out, nlen);
		  out_len = nlen;
	    }
	    if (n) {
		  strncpy(out+iout, inp, n);
		  iout += n;
	    }
	    inp += n+1;
	    out[iout++] = '\\';
	    switch (*se) {
		case '\\':
		case '/':
		case '<':
		case '>':
		  out[iout++] = *se;
		  break;
		default:
		  out[iout++] = 'x';
		  out[iout++] = hex_digit(*se >> 4);
		  out[iout++] = hex_digit(*se);
		  break;
	    }

	    se = strpbrk(inp, nosym);
      } while (se);

      strcpy(out+iout, inp);
      return out;
}

const char *vvp_mangle_name(const char *id)
{
      static char *out = 0x0;
      static size_t out_len;

      int nesc = 0;
      int iout = 0;
      const char *inp = id;

      const char nosym[] = "\"\\";

      const char *se = strpbrk(inp, nosym);
      if (!se)
	    return id;

      do {
	    int n = se - inp;
	    unsigned int nlen = strlen(id) + 2*(++nesc) + 1;
	    if (out_len < nlen) {
		  out = realloc(out, nlen);
		  out_len = nlen;
	    }
	    if (n) {
		  strncpy(out+iout, inp, n);
		  iout += n;
	    }
	    inp += n+1;
	    out[iout++] = '\\';
	    out[iout++] = *se;

	    se = strpbrk(inp, nosym);
      } while (se);

      strcpy(out+iout, inp);
      return out;
}

static ivl_signal_t signal_of_nexus(ivl_nexus_t nex, unsigned*word)
{
      unsigned idx;
      ivl_signal_t match = 0;
      for (idx = 0 ;  idx < ivl_nexus_ptrs(nex) ;  idx += 1) {
            ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
            ivl_signal_t sig = ivl_nexus_ptr_sig(ptr);
            if (sig == 0)
                  continue;
            if (ivl_signal_local(sig))
                  continue;
            *word = ivl_nexus_ptr_pin(ptr);
            match = sig;
      }

      return match;
}

static ivl_signal_t signal_of_nexus_in_scope(ivl_nexus_t nex, ivl_scope_t scope,
                                             unsigned*word, ivl_variable_type_t data_type)
{
      unsigned idx;
      ivl_signal_t match = 0;
      for (idx = 0 ; idx < ivl_nexus_ptrs(nex) ; idx += 1) {
            ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
            ivl_signal_t sig = ivl_nexus_ptr_sig(ptr);
            if (sig == 0)
                  continue;
            if (ivl_signal_scope(sig) != scope)
                  continue;
            if ((data_type != IVL_VT_NO_TYPE) && (ivl_signal_data_type(sig) != data_type))
                  continue;
            *word = ivl_nexus_ptr_pin(ptr);
            match = sig;
      }

      return match;
}

unsigned width_of_nexus(ivl_nexus_t nex)
{
      unsigned idx;

      for (idx = 0 ;  idx < ivl_nexus_ptrs(nex) ;  idx += 1) {
	    ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
	    ivl_signal_t sig = ivl_nexus_ptr_sig(ptr);
	    if (sig != 0)
		  return ivl_signal_width(sig);
      }

      return 0;
}

ivl_variable_type_t data_type_of_nexus(ivl_nexus_t nex)
{
      unsigned idx;
      for (idx = 0 ;  idx < ivl_nexus_ptrs(nex) ;  idx += 1) {
	    ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
	    ivl_signal_t sig = ivl_nexus_ptr_sig(ptr);
	    if (sig != 0)
		  return ivl_signal_data_type(sig);
      }

	/* shouldn't happen! */
      return IVL_VT_NO_TYPE;
}


static ivl_nexus_ptr_t ivl_logic_pin_ptr(ivl_net_logic_t net, unsigned pin)
{
      ivl_nexus_t nex = ivl_logic_pin(net, pin);
      unsigned idx;

      for (idx = 0 ;  idx < ivl_nexus_ptrs(nex) ;  idx += 1) {
	    ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
	    ivl_net_logic_t tmp = ivl_nexus_ptr_log(ptr);
	    if (tmp == 0)
		  continue;
	    if (tmp != net)
		  continue;
	    if (ivl_nexus_ptr_pin(ptr) != pin)
		  continue;

	    return ptr;
      }
      assert(0);
      return 0;
}

#if 0
const char*drive_string(ivl_drive_t drive)
{
      switch (drive) {
	  case IVL_DR_HiZ:
	    return "";
	  case IVL_DR_SMALL:
	    return "sm";
	  case IVL_DR_MEDIUM:
	    return "me";
	  case IVL_DR_WEAK:
	    return "we";
	  case IVL_DR_LARGE:
	    return "la";
	  case IVL_DR_PULL:
	    return "pu";
	  case IVL_DR_STRONG:
	    return "";
	  case IVL_DR_SUPPLY:
	    return "su";
      }

      return "";
}
#endif


/*
 * The draw_scope function draws the major functional items within a
 * scope. This includes the scopes themselves, of course. All the
 * other functions in this file are in support of that task.
 */


/*
 * NEXUS
 * ivl builds up the netlist into objects connected together by
 * ivl_nexus_t objects. The nexus receives all the drivers of the
 * point in the net and resolves the value. The result is then sent to
 * all the nets that are connected to the nexus. The nets, then, are
 * read to get the value of the nexus.
 *
 * NETS
 * Nets are interesting and special, because a nexus may be connected
 * to several of them at once. This can happen, for example, as an
 * artifact of module port connects, where the inside and the outside
 * of the module are connected through an in-out port. (In fact, ivl
 * will simply connect signals that are bound through a port, because
 * the input/output/inout properties are enforced as compile time.)
 *
 * This case is handled by choosing one to receive the value of the
 * nexus. This one then feeds to another net at the nexus, and so
 * on. The last net is selected as the output of the nexus.
 */

/*
 * When checking if we can elide a buffer we need to keep the buffer
 * if both the input and output for the buffer are connected only
 * to netlist signals. This routine performs this check on the
 * given nexus.
 */
static unsigned is_netlist_signal(const ivl_net_logic_t net, ivl_nexus_t nex)
{
      unsigned idx, rtn;

	/* Assume that this is a netlist signal. */
      rtn = 1;

      for (idx = 0; idx < ivl_nexus_ptrs(nex); idx += 1) {
	    ivl_nexus_ptr_t nptr;
	    ivl_signal_t sptr;

	    nptr = ivl_nexus_ptr(nex, idx);

	      /* Skip a pointer to the buffer we're checking. */
            if (ivl_nexus_ptr_log(nptr) == net) continue;

	      /* Check to see if this is a netlist signal. */
	    sptr = ivl_nexus_ptr_sig(nptr);
	    if (sptr && !ivl_signal_local(sptr)) continue;

	      /* If we get here then this is not just a netlist signal. */
	    rtn = 0;
	    break;
      }

      return rtn;
}

int signal_is_materialized_return(ivl_signal_t sig)
{
      if (!sig) return 0;
      ivl_scope_t scope = ivl_signal_scope(sig);
      return ivl_scope_type(scope) == IVL_SCT_FUNCTION
	  && strcmp(ivl_signal_basename(sig), ivl_scope_basename(scope)) == 0
	  && ivl_signal_dimensions(sig) == 0
	  && (ivl_signal_data_type(sig) == IVL_VT_BOOL
	      || ivl_signal_data_type(sig) == IVL_VT_LOGIC)
	  && ivl_signal_attr(sig, "_ivl_materialize_return") != 0;
}

/* Return variables backed by the call stack can omit ordinary signal storage. */
int signal_is_return_value(ivl_signal_t sig)
{
      if (signal_is_materialized_return(sig))
	    return 0;
      ivl_scope_t sig_scope = ivl_signal_scope(sig);
      if (ivl_scope_type(sig_scope) != IVL_SCT_FUNCTION)
	    return 0;
      if (strcmp(ivl_signal_basename(sig), ivl_scope_basename(sig_scope)) == 0)
	    return 1;
      return 0;
}

/*
 * This tests a bufz device against an output receiver, and determines
 * if the device can be skipped. If this function returns false, then a
 * gate will be generated for this node. Otherwise, the code generator
 * will connect its input to its output and skip the gate.
 */
int can_elide_bufz(ivl_net_logic_t net, ivl_nexus_ptr_t nptr)
{
	// If bufz is a module input/output buffer do not elide
      if (ivl_logic_port_buffer(net)) return 0;

      ivl_nexus_t in_n, out_n;
      unsigned idx;

	/* These are the drives we expect. */
      ivl_drive_t dr0 = ivl_nexus_ptr_drive0(nptr);
      ivl_drive_t dr1 = ivl_nexus_ptr_drive1(nptr);
      int drive_count = 0;

	/* If the gate carries a delay, it must remain. */
      if (ivl_logic_delay(net, 0) != 0)
	    return 0;

	/* If the input is connected to the output, then do not elide
	   the gate. This is some sort of cycle. */
      if (ivl_logic_pin(net, 0) == ivl_logic_pin(net, 1))
	    return 0;

      in_n = ivl_logic_pin(net, 1);
      for (idx = 0 ;  idx < ivl_nexus_ptrs(in_n) ;  idx += 1) {
	    ivl_nexus_ptr_t in_np = ivl_nexus_ptr(in_n, idx);
	    if (ivl_nexus_ptr_log(in_np) == net)
		  continue;

	      /* If the driver for the source does not match the
		 expected drive, then we need to keep the bufz. This
		 test also catches the case that the input device is
		 really also an input, as that device will have a
		 drive of HiZ. We need to keep BUFZ devices in that
		 case in order to prevent back-flow of data. */
	    if (ivl_nexus_ptr_drive0(in_np) != dr0)
		  return 0;
	    if (ivl_nexus_ptr_drive1(in_np) != dr1)
		  return 0;

	    drive_count += 1;
      }

	/* If the BUFZ input has multiple drivers on its input, then
	   we need to keep this device in order to hide the
	   resolution. */
      if (drive_count != 1)
	    return 0;

	/* If the BUFZ output is connected to a net that is subject
	   to a force statement, we need to keep the BUFZ to prevent
	   back-flow of the forced value. */
      out_n = ivl_logic_pin(net, 0);
      for (idx = 0 ;  idx < ivl_nexus_ptrs(out_n) ;  idx += 1) {
	    ivl_nexus_ptr_t out_np = ivl_nexus_ptr(out_n, idx);
	    ivl_signal_t out_sig = ivl_nexus_ptr_sig(out_np);
	    if (out_sig && ivl_signal_forced_net(out_sig))
		  return 0;
      }

	/* If both the input and output are netlist signal then we cannot
	   elide a BUFZ since it represents a continuous assignment. */
      if (is_netlist_signal(net, ivl_logic_pin(net, 0)) &&
          is_netlist_signal(net, ivl_logic_pin(net, 1)) &&
          (ivl_logic_type(net) == IVL_LO_BUFZ)) {
	     return 0;
      }

      return 1;
}

char* draw_Cr_to_string(double value)
{
      char tmp[256];

      uint64_t mant = 0;
      int sign, expo, vexp;
      double fract;

      if (isinf(value)) {
	    if (value > 0)
		  snprintf(tmp, sizeof(tmp), "Cr<m0g3fff>");
	    else
		  snprintf(tmp, sizeof(tmp), "Cr<m0g7fff>");
	    return strdup(tmp);
      }
      if (value != value) {
	    snprintf(tmp, sizeof(tmp), "Cr<m1g3fff>");
	    return strdup(tmp);
      }

      sign = 0;
      if (value < 0.0 || (value == 0.0 && 1.0/value < 0.0)) {
	    sign = 0x4000;
	    value *= -1;
      }

      fract = frexp(value, &expo);
      fract = ldexp(fract, 63);
      mant = fract;
      expo -= 63;

      vexp = expo + 0x1000;
      assert(vexp >= 0);
      assert(vexp < 0x2000);
      vexp += sign;

      snprintf(tmp, sizeof(tmp), "Cr<m%" PRIx64 "g%x>", mant, vexp);
      return strdup(tmp);
}

const char*draw_input_from_net(ivl_nexus_t nex, ivl_scope_t scope)
{
      static char result[32];
      static int trace_event_input = -1;
      unsigned word;
      ivl_signal_t sig = 0;
      unsigned idx;
      if (trace_event_input < 0) {
            const char*env = getenv("IVL_EVENT_INPUT_TRACE");
            trace_event_input = (env && *env && strcmp(env, "0") != 0) ? 1 : 0;
      }
      if (trace_event_input) {
            fprintf(stderr, "trace event-input nex=%p ptrs=%u\n",
                    (void*)nex, ivl_nexus_ptrs(nex));
            for (idx = 0 ; idx < ivl_nexus_ptrs(nex) ; idx += 1) {
                  ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
                  ivl_signal_t trace_sig = ivl_nexus_ptr_sig(ptr);
                  fprintf(stderr,
                          "  ptr[%u] sig=%p name=%s scope=%s local=%d dtype=%d pin=%u log=%p\n",
                          idx,
                          (void*)trace_sig,
                          trace_sig ? ivl_signal_basename(trace_sig) : "-",
                          trace_sig ? ivl_scope_name(ivl_signal_scope(trace_sig)) : "-",
                          trace_sig ? ivl_signal_local(trace_sig) : -1,
                          trace_sig ? ivl_signal_data_type(trace_sig) : -1,
                          ivl_nexus_ptr_pin(ptr),
                          (void*)ivl_nexus_ptr_log(ptr));
            }
      }
      if (scope != 0) {
            ivl_scope_t cur;
            for (cur = scope ; (sig == 0) && cur ; cur = ivl_scope_parent(cur))
                  sig = signal_of_nexus_in_scope(nex, cur, &word, IVL_VT_CLASS);
            for (cur = scope ; (sig == 0) && cur ; cur = ivl_scope_parent(cur))
                  sig = signal_of_nexus_in_scope(nex, cur, &word, IVL_VT_NO_TYPE);
      }
      for (idx = 0 ; (sig == 0) && (idx < ivl_nexus_ptrs(nex)) ; idx += 1) {
            ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
            ivl_signal_t local_sig = ivl_nexus_ptr_sig(ptr);
            if (local_sig == 0)
                  continue;
            if (!ivl_signal_local(local_sig))
                  continue;
            if (ivl_signal_data_type(local_sig) != IVL_VT_CLASS)
                  continue;
            word = ivl_nexus_ptr_pin(ptr);
            sig = local_sig;
            break;
      }
      if (sig == 0)
            sig = signal_of_nexus(nex, &word);
      if (sig == 0)
	    return draw_net_input(nex);
      if (ivl_signal_type(sig)==IVL_SIT_REG && ivl_signal_dimensions(sig)>0)
	    return draw_net_input(nex);

	/* A local/automatic net is elided when the scope is drawn (see the
	   "Elide local/automatic net" case in draw_scope's net emission),
	   so nothing defines its "v%p_%u" label. An event that senses such a
	   net (e.g. a bit-select of an automatic vector, @(posedge x[i]),
	   which lowers to a synthesized local .part net) must therefore
	   reference the nexus driver (the .part functor) instead of the
	   absent net, matching the reference behaviour. Class/object signals
	   are exempt: value-change and virtual-interface events load them as
	   objects by their net name. */
      if (ivl_signal_local(sig) && ivl_scope_is_auto(ivl_signal_scope(sig))
	  && ivl_signal_data_type(sig) != IVL_VT_CLASS)
	    return draw_net_input(nex);

      snprintf(result, sizeof result, "v%p_%u", sig, word);
      return result;
}

void draw_object_from_net(ivl_nexus_t nex, ivl_scope_t scope)
{
      ivl_signal_t sig = 0;
      unsigned word = 0;
      unsigned idx;

      /* Prefer the class signal in the lexical scope (or one of its
         parents), matching draw_input_from_net(). This matters when a port
         nexus also contains the actual interface instance handle. */
      if (scope != 0) {
            ivl_scope_t cur;
            for (cur = scope ; (sig == 0) && cur ; cur = ivl_scope_parent(cur))
                  sig = signal_of_nexus_in_scope(nex, cur, &word, IVL_VT_CLASS);
      }
      for (idx = 0 ; (sig == 0) && (idx < ivl_nexus_ptrs(nex)) ; idx += 1) {
            ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
            ivl_signal_t candidate = ivl_nexus_ptr_sig(ptr);
            if (!candidate || ivl_signal_data_type(candidate) != IVL_VT_CLASS)
                  continue;
            sig = candidate;
            word = ivl_nexus_ptr_pin(ptr);
      }

      if (sig && ivl_signal_dimensions(sig) > 0) {
            int index_reg = allocate_word();
              /* A nexus pin is already the canonical zero-based array word.
               * %load/obja uses that same storage address; adding the declared
               * base made nonzero-bound interface-port arrays read a nil slot. */
            fprintf(vvp_out, "    %%ix/load %d, %u, 0; vif array word\n",
                    index_reg, word);
            note_array_signal_use(sig);
            fprintf(vvp_out, "    %%load/obja v%p, %d;\n", sig, index_reg);
            clr_word(index_reg);
            return;
      }

      fprintf(vvp_out, "    %%load/obj %s;\n",
              draw_input_from_net(nex, scope));
}


static const char *local_flag_str( ivl_signal_t sig )
{
    return ivl_signal_local(sig)? "*" : "";
}

static const char *storage_flag_str(ivl_signal_t sig)
{
      switch (ivl_signal_lifetime(sig)) {
	  case IVL_VLT_STATIC:
	    return "!";
	  case IVL_VLT_AUTOMATIC:
	    return "^";
	  default:
	    return "";
      }
}

static void emit_packed_dims_(ivl_signal_t sig, const char*suffix)
{
      unsigned dims = ivl_signal_packed_dimensions(sig);
      if (dims < 2)
            return;
      fprintf(vvp_out, " .packed_dims v%p%s, \"", sig, suffix);
      for (unsigned idx = 0; idx < dims; idx += 1) {
            if (idx) fputc(',', vvp_out);
            fprintf(vvp_out, "%d:%d", ivl_signal_packed_msb(sig, idx),
                    ivl_signal_packed_lsb(sig, idx));
      }
      fprintf(vvp_out, "\";\n");
}

static void emit_signal_source_location_(ivl_signal_t sig, const char*suffix)
{
      const char*file = ivl_signal_file(sig);
      unsigned line = ivl_signal_lineno(sig);
      if (!file || !*file)
	    return;
      fprintf(vvp_out, "v%p%s .vpi_source_location %u %u;\n", sig, suffix,
	      ivl_file_table_index(file), line);
}

static const char *event_storage_flag_str(ivl_event_t event)
{
      switch (ivl_event_lifetime(event)) {
	  case IVL_VLT_STATIC:
	    return "!";
	  case IVL_VLT_AUTOMATIC:
	    return "^";
	  default:
	    return "";
      }
}

/*
 * This function draws a reg/int/variable in the scope. This is a very
 * simple device to draw as there are no inputs to connect so no need
 * to scan the nexus. We do have to account for the possibility that
 * the device is arrayed, though, by making a node for each array element.
 */
static void draw_reg_in_scope(ivl_signal_t sig)
{
      int msb;
      int lsb;
      switch (ivl_signal_packed_dimensions(sig)) {
	  case 0:
	    msb = 0;
	    lsb = 0;
	    break;
	  case 1:
	    msb = ivl_signal_packed_msb(sig, 0);
	    lsb = ivl_signal_packed_lsb(sig, 0);
	    break;
	  default:
	    msb = ivl_signal_width(sig) - 1;
	    lsb = 0;
	    break;
      }

	/* Special Case: If this variable is the return value of a function,
	   then it need not exist as an actual variable — the value is
	   delivered through the %ret machinery. EXCEPT when the return type
	   is an unpacked array: %ret has no array representation, so the
	   return signal must be emitted as a real array below; the function
	   body stores the elements into it and the caller copies them out
	   after the call (while the callee frame is still allocated). */
      if ((ivl_signal_data_type(sig)==IVL_VT_REAL)
	  && ivl_signal_dimensions(sig) == 0
	  && signal_is_return_value(sig)) {
	    fprintf(vvp_out, "; Variable %s is REAL return value of scope S_%p\n",
		    ivl_signal_basename(sig), ivl_signal_scope(sig));
	    return;
      }
      if ((ivl_signal_data_type(sig)==IVL_VT_STRING)
	  && ivl_signal_dimensions(sig) == 0
	  && signal_is_return_value(sig)) {
	    fprintf(vvp_out, "; Variable %s is string return value of scope S_%p\n",
		    ivl_signal_basename(sig), ivl_signal_scope(sig));
	    return;
      }
      if ((ivl_signal_data_type(sig)==IVL_VT_LOGIC)
	  && ivl_signal_dimensions(sig) == 0
	  && signal_is_return_value(sig)) {
	    fprintf(vvp_out, "; Variable %s is vec4 return value of scope S_%p\n",
		    ivl_signal_basename(sig), ivl_signal_scope(sig));
	    return;
      }
      if ((ivl_signal_data_type(sig)==IVL_VT_BOOL)
	  && ivl_signal_dimensions(sig) == 0
	  && signal_is_return_value(sig)) {
	    fprintf(vvp_out, "; Variable %s is bool return value of scope S_%p\n",
		    ivl_signal_basename(sig), ivl_signal_scope(sig));
	    return;
      }

	/* A `ref' formal (IEEE 1800-2017 13.5.2) is a name, not storage:
	   %ref/bind points it at the caller's variable and every access
	   is forwarded there. The core only marks a port IVL_SIP_REF
	   when it also emits the bind, so an unbound .ref cannot occur.

	   REAL and STRING formals need declaration keywords (.ref/real and
	   .ref/str,
	   R25 stretch): a real functor never implements the int/vec4
	   accessors (there is no meaningful width or bit for a real), only
	   real_value()/get_signal_value(), so the VPI handle vvp attaches
	   to it must be the real-flavored one (__vpiRealVar) rather than
	   the integer one plain .ref always requested -- see
	   compile_ref_variable_real() in vvp/words.cc. */
      if (ivl_signal_port(sig) == IVL_SIP_REF
	  && ivl_signal_data_type(sig) == IVL_VT_REAL) {
	    fprintf(vvp_out, "v%p_0 .ref/real %s\"%s\", %d %d;\n",
		    sig, local_flag_str(sig),
		    vvp_mangle_name(ivl_signal_basename(sig)), msb, lsb);
	    return;
      }
      if (ivl_signal_port(sig) == IVL_SIP_REF
	  && ivl_signal_data_type(sig) == IVL_VT_STRING) {
	    fprintf(vvp_out, "v%p_0 .ref/str %s\"%s\", %d %d;\n",
		    sig, local_flag_str(sig),
		    vvp_mangle_name(ivl_signal_basename(sig)), msb, lsb);
	    return;
      }
      if (ivl_signal_port(sig) == IVL_SIP_REF) {
	    fprintf(vvp_out, "v%p_0 .ref %s\"%s\", %d %d;\n",
		    sig, local_flag_str(sig),
		    vvp_mangle_name(ivl_signal_basename(sig)), msb, lsb);
	      /* A companion word in the same frame, for a call whose
		 actual cannot be named -- an array element, a class
		 property, a part select. Such a call copies the actual
		 into the companion, binds the formal to it, and copies
		 it back, which is the copy-in/copy-out those shapes had
		 before. It is per-frame like everything else here, so
		 recursion and concurrent calls each get their own.

		 A class-handle formal's companion has to be an object
		 variable (.var/cobj), not a vector reg: vvp_ref_signal_aa
		 answers the object accessor interface (get_object() and
		 friends), not the vec4 one, for a class-typed binding, and
		 a .var/2s companion would not carry the type the runtime's
		 class-cast/property opcodes expect. Every other type here
		 keeps the original vector companion. */
	    if (ivl_signal_data_type(sig) == IVL_VT_CLASS) {
		  ivl_type_t ref_type = ivl_signal_net_type(sig);
		  if (ref_type && ivl_type_base(ref_type) == IVL_VT_CLASS) {
			draw_class_in_scope(ref_type);
			fprintf(vvp_out, "v%p_R .var/cobj *%s\"%s$ref\", TC%p;\n",
				sig, storage_flag_str(sig),
				vvp_mangle_name(ivl_signal_basename(sig)),
				ref_type);
		  } else {
			fprintf(vvp_out, "v%p_R .var/cobj *%s\"%s$ref\";\n",
				sig, storage_flag_str(sig),
				vvp_mangle_name(ivl_signal_basename(sig)));
		  }
	    } else {
		  fprintf(vvp_out, "v%p_R .var/2s *%s\"%s$ref\", %d %d;\n",
			  sig, storage_flag_str(sig),
			  vvp_mangle_name(ivl_signal_basename(sig)), msb, lsb);
	    }
	    return;
      }

      const char *datatype_flag = ivl_signal_integer(sig) ? "/i" :
			       ivl_signal_signed(sig)? "/s" : "";
      const char *local_flag = local_flag_str(sig);
      const char *storage_flag = storage_flag_str(sig);
      int vector_dims = 1;

      if (ivl_signal_dimensions(sig) > 0)
	    note_array_signal_emitted_(sig);

      switch (ivl_signal_data_type(sig)) {
	  case IVL_VT_BOOL:
	    if (ivl_signal_signed(sig))
		  datatype_flag = "/2s";
	    else
		  datatype_flag = "/2u";
	    break;
	  case IVL_VT_REAL:
	    datatype_flag = "/real";
	    vector_dims = 0;
	    break;
	  case IVL_VT_STRING:
	    datatype_flag = "/str";
	    vector_dims = 0;
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_NO_TYPE:
	    datatype_flag = "/obj";
	    vector_dims = 0;
	    break;
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	      /* A fixed unpacked prefix around a dynamic container is an
	       * array of independent object values, not a vector array whose
	       * packed width happens to be one. Scalar darray/queue declarations
	       * still take their dedicated branches below; this flag matters only
	       * when ivl_signal_dimensions(sig) is nonzero. */
	    datatype_flag = "/obj";
	    vector_dims = 0;
	    break;
	  default:
	    break;
      }

	/* If the reg objects are collected into an array, then first
	   write out the .array record to declare the array indices. */
      if (ivl_signal_dimensions(sig) > 0 && vector_dims==0) {

              /* Some types cannot be placed in packed dimensions, so
		 do not include packed dimensions. */
	    unsigned word_count = ivl_signal_array_count(sig);
	    unsigned swapped = ivl_signal_array_addr_swapped(sig);
	    int last = ivl_signal_array_base(sig)+word_count-1;
	    int first = ivl_signal_array_base(sig);

	      /* A static unpacked array of an object-backed UNPACKED struct
		 (element data type IVL_VT_NO_TYPE with properties) carries its
		 element class type on the .array/obj record so the runtime can
		 default-construct each element lazily — otherwise a member
		 write `arr[i].field = ...` to a never-whole-assigned element
		 would store through a nil handle and be dropped. A class-handle
		 array (element base IVL_VT_CLASS) emits no type: its elements
		 correctly default to null. */
	    ivl_type_t arr_elem_type = ivl_signal_net_type(sig);
	    int struct_obj_elem =
		  (ivl_signal_data_type(sig) == IVL_VT_NO_TYPE)
		  && arr_elem_type
		  && ivl_type_base(arr_elem_type) == IVL_VT_NO_TYPE
		  && ivl_type_properties(arr_elem_type) > 0;
	    if (struct_obj_elem)
		  draw_class_in_scope(arr_elem_type);
	    int container_obj_elem =
		  (ivl_signal_data_type(sig) == IVL_VT_QUEUE
		   || ivl_signal_data_type(sig) == IVL_VT_DARRAY)
		  && arr_elem_type;
	    fprintf(vvp_out, "v%p .array%s %s\"%s\", %d %d",
		    sig, datatype_flag, storage_flag,
		    vvp_mangle_name(ivl_signal_basename(sig)),
		    swapped ? first: last, swapped ? last : first);
	    if (struct_obj_elem)
		  fprintf(vvp_out, ", C%p", arr_elem_type);
	    else if (container_obj_elem) {
		  fputs(", \"", vvp_out);
		  if (ivl_type_base(arr_elem_type) == IVL_VT_DARRAY)
			fputc('D', vvp_out);
		  else if (ivl_type_queue_assoc_compat(arr_elem_type))
			fputc('A', vvp_out);
		  else
			fputc('Q', vvp_out);
		  emit_container_layout_suffix_(arr_elem_type);
		  fputc('"', vvp_out);
	    }
	    fprintf(vvp_out, ";\n");

      } else if (ivl_signal_dimensions(sig) > 0) {
	    unsigned word_count = ivl_signal_array_count(sig);
	    unsigned swapped = ivl_signal_array_addr_swapped(sig);
	    int last = ivl_signal_array_base(sig)+word_count-1;
	    int first = ivl_signal_array_base(sig);
	    fprintf(vvp_out, "v%p .array%s %s\"%s\", %d %d, %d %d;\n",
		    sig, datatype_flag, storage_flag,
		    vvp_mangle_name(ivl_signal_basename(sig)),
		    swapped ? first: last, swapped ? last : first, msb, lsb);

      } else if (ivl_signal_data_type(sig) == IVL_VT_DARRAY) {
	    ivl_type_t var_type = ivl_signal_net_type(sig);
	    ivl_type_t element_type = ivl_type_element(var_type);

	      /* A dynamic array of an object-backed UNPACKED struct (element
		 base IVL_VT_NO_TYPE with properties) carries its element class
		 type on the .var/darray record so the runtime can lazily
		 default-construct a nil element on first member access —
		 otherwise `da[i].field = ...` on a `new[]`-allocated (nil)
		 element would store through a null handle and be dropped. A
		 class-handle darray emits no type: its elements correctly
		 default to null. */
	    int struct_obj_elem =
		  element_type
		  && ivl_type_base(element_type) == IVL_VT_NO_TYPE
		  && ivl_type_properties(element_type) > 0;
	    if (struct_obj_elem)
		  draw_class_in_scope(element_type);

	    fprintf(vvp_out, "v%p_0 .var/darray %s\"%s\", %u%s", sig,
		    storage_flag,
		    vvp_mangle_name(ivl_signal_basename(sig)),
		    ivl_type_packed_width(element_type),
		      /* '+' marks a signed integral element so %p and
		         vpiDecStrVal render negatives correctly. */
		    (element_type && ivl_type_signed(element_type)) ? "+" : "");
	    fprintf(vvp_out, ", \"D");
	    emit_container_layout_suffix_(var_type);
	    fputc('"', vvp_out);
	    if (struct_obj_elem)
		  fprintf(vvp_out, ", C%p", element_type);
	    fprintf(vvp_out, ";%s\n",
		    ivl_signal_local(sig)? " Local signal" : "");

      } else if (ivl_signal_data_type(sig) == IVL_VT_QUEUE) {
	    ivl_type_t var_type = ivl_signal_net_type(sig);
	    ivl_type_t element_type = ivl_type_element(var_type);
            const char*queue_kind = 0;
            int assoc_compat = ivl_type_queue_assoc_compat(var_type);

            if (type_is_fixed_uarray_property_(element_type)) {
                  queue_kind = assoc_compat ? "Mo" : "Qo";
            } else switch (ivl_type_base(element_type)) {
                case IVL_VT_REAL:
                  queue_kind = assoc_compat ? "Mr" : "Qr";
                  break;
                case IVL_VT_STRING:
                  queue_kind = assoc_compat ? "MS" : "QS";
                  break;
                case IVL_VT_CLASS:
                case IVL_VT_NO_TYPE:
                case IVL_VT_DARRAY:
                case IVL_VT_QUEUE:
                  // C3 (Phase 62n): queue-of-queue and queue-of-darray
                  // are object-like at runtime (each entry is a
                  // class-like vvp_queue/vvp_darray handle).  Without
                  // these cases, `T[$] foo[KEY]` (a typedef'd
                  // queue-of-class used as the value type of an assoc
                  // array, e.g. UVM's
                  // `uvm_resource_types::rsrc_sv_q_t all[int]`) was
                  // emitted with `Mv` and runtime peeks expecting
                  // `vvp_assoc_object` saw `vvp_assoc_vec4` instead.
                  queue_kind = assoc_compat ? "Mo" : "Qo";
                  break;
                default:
                  queue_kind = assoc_compat ? "Mv" : "Qv";
                  break;
            }

	      /* Like .var/darray: an object-backed UNPACKED struct element
		 (base IVL_VT_NO_TYPE with properties) records its element class
		 type so the runtime can lazily default-construct a nil/absent
		 element on first member access. This is what makes a member
		 write into a not-yet-present associative-array entry
		 (`a[key].field = ...`) address a live, inserted element instead
		 of a discarded default. Class-handle queues emit no type (their
		 elements correctly default to null). */
	    int struct_obj_elem =
		  element_type
		  && ivl_type_base(element_type) == IVL_VT_NO_TYPE
		  && ivl_type_properties(element_type) > 0;
	    if (struct_obj_elem)
		  draw_class_in_scope(element_type);

	    fprintf(vvp_out, "v%p_0 .var/queue %s\"%s\", %u%s, \"%s", sig,
		    storage_flag,
		    vvp_mangle_name(ivl_signal_basename(sig)),
		    ivl_type_packed_width(element_type),
		      /* '+' marks a signed integral element (see .var/darray). */
		    (element_type && ivl_type_signed(element_type)) ? "+" : "",
		    queue_kind);
	    emit_container_layout_suffix_(var_type);
	    fprintf(vvp_out, "\"");
	    if (struct_obj_elem)
		  fprintf(vvp_out, ", C%p", element_type);
	    fprintf(vvp_out, ";%s\n",
		    ivl_signal_local(sig)? " Local signal" : "");

      } else if (ivl_signal_data_type(sig) == IVL_VT_STRING) {
	    fprintf(vvp_out, "v%p_0 .var/str %s\"%s\";%s\n", sig,
		    storage_flag,
		    vvp_mangle_name(ivl_signal_basename(sig)),
		    ivl_signal_local(sig)? " Local signal" : "");

      } else if (ivl_signal_data_type(sig) == IVL_VT_CLASS
	         || ivl_signal_data_type(sig) == IVL_VT_NO_TYPE) {
	    ivl_type_t var_type = ivl_signal_net_type(sig);
	    if (var_type && ivl_type_base(var_type) == IVL_VT_CLASS) {
		  draw_class_in_scope(var_type);
		  fprintf(vvp_out, "v%p_0 .var/cobj %s\"%s\", TC%p;%s\n", sig,
			  storage_flag,
			  vvp_mangle_name(ivl_signal_basename(sig)),
			  var_type,
			  ivl_signal_local(sig)? " Local signal" : "");
	    } else if (var_type && ivl_type_base(var_type) == IVL_VT_NO_TYPE
		       && ivl_type_properties(var_type) > 0) {
		  draw_class_in_scope(var_type);
		  fprintf(vvp_out, "v%p_0 .var/cobj %s\"%s\", C%p;%s\n", sig,
			  storage_flag,
			  vvp_mangle_name(ivl_signal_basename(sig)),
			  var_type,
			  ivl_signal_local(sig)? " Local signal" : "");
	    } else {
		  fprintf(vvp_out, "v%p_0 .var/cobj %s\"%s\";%s\n", sig,
			  storage_flag,
			  vvp_mangle_name(ivl_signal_basename(sig)),
			  ivl_signal_local(sig)? " Local signal" : "");
	    }

      } else {

	    fprintf(vvp_out, "v%p_0 .var%s %s%s\"%s\", %d %d;%s\n",
		    sig, datatype_flag, local_flag, storage_flag,
		    vvp_mangle_name(ivl_signal_basename(sig)), msb, lsb,
		    ivl_signal_local(sig)? " Local signal" : "" );
      }

      if (ivl_signal_data_type(sig) == IVL_VT_BOOL ||
          ivl_signal_data_type(sig) == IVL_VT_LOGIC) {
            emit_packed_dims_(sig,
                  ivl_signal_dimensions(sig) > 0 ? "" : "_0");
      }

      if (ivl_signal_dimensions(sig) == 0
	  && (ivl_signal_data_type(sig) == IVL_VT_BOOL
	      || ivl_signal_data_type(sig) == IVL_VT_LOGIC
	      || ivl_signal_data_type(sig) == IVL_VT_CLASS
	      || ivl_signal_data_type(sig) == IVL_VT_NO_TYPE))
	    emit_signal_source_location_(sig, "_0");
}


/*
 * This function draws a net. This is a bit more complicated as we
 * have to find an appropriate functor to connect to the input.
 */
static void draw_net_in_scope(ivl_signal_t sig)
{
      int msb;
      int lsb;
      switch (ivl_signal_packed_dimensions(sig)) {
	  case 0:
	    msb = 0;
	    lsb = 0;
	    break;
	  case 1:
	    msb = ivl_signal_packed_msb(sig, 0);
	    lsb = ivl_signal_packed_lsb(sig, 0);
	    break;
	  default:
	    msb = ivl_signal_width(sig) - 1;
	    lsb = 0;
	    break;
      }

      const char*datatype_flag = ivl_signal_signed(sig)? "/s" : "";
      const char *local_flag = local_flag_str(sig);

      unsigned iword;

      if (ivl_signal_dimensions(sig) > 0)
	    note_array_signal_emitted_(sig);

      switch (ivl_signal_data_type(sig)) {
	  case IVL_VT_BOOL:
	    if (ivl_signal_signed(sig))
		  datatype_flag = "/2s";
	    else
		  datatype_flag = "/2u";
	    break;
	  case IVL_VT_REAL:
	    datatype_flag = "/real";
	    break;
	  default:
	    break;
      }

      for (iword = 0 ;  iword < ivl_signal_array_count(sig); iword += 1) {

	    unsigned word_count = ivl_signal_array_count(sig);
	    unsigned dimensions = ivl_signal_dimensions(sig);
	    struct vvp_nexus_data*nex_data;

	      /* Connect the pin of the signal to something. */
	    ivl_nexus_t nex = ivl_signal_nex(sig, iword);
	    const char*driver = draw_net_input(nex);

	    nex_data = (struct vvp_nexus_data*)ivl_nexus_get_private(nex);
	    assert(nex_data);

	    if (nex_data->net == 0) {
		  int strength_aware_flag = 0;
		  const char*vec8 = "";
		  if (nex_data->flags&VVP_NEXUS_DATA_STR)
			strength_aware_flag = 1;
		  if (nex_data->drivers_count > 1)
			vec8 = "8";
		  if (strength_aware_flag)
			vec8 = "8";

		  if (iword == 0 && dimensions > 0) {
			unsigned swapped = ivl_signal_array_addr_swapped(sig);
			int last = ivl_signal_array_base(sig) + word_count-1;
			int first = ivl_signal_array_base(sig);
			fprintf(vvp_out, "v%p .array \"%s\", %d %d;\n",
				sig, vvp_mangle_name(ivl_signal_basename(sig)),
				swapped ? first : last, swapped ? last : first);
		  }
		  if (dimensions > 0) {
			/* If this is a word of an array, then use an
			   array reference in place of the net name. */
			fprintf(vvp_out, "v%p_%u .net%s%s v%p %u, %d %d, %s;"
				" %u drivers%s\n",
				sig, iword, vec8, datatype_flag, sig,
				iword, msb, lsb, driver,
				nex_data->drivers_count,
				strength_aware_flag?", strength-aware":"" );

		  } else if (ivl_signal_local(sig) && ivl_scope_is_auto(ivl_signal_scope(sig))) {
			assert(word_count == 1);
			fprintf(vvp_out, "; Elide local/automatic net v%p_%u name=%s\n",
				sig, iword, ivl_signal_basename(sig));

		  } else if (ivl_signal_local(sig) && nex_data->drivers_count==0) {
			assert(word_count == 1);
			fprintf(vvp_out, "; Elide local net with no drivers, v%p_%u name=%s\n",
				sig, iword, ivl_signal_basename(sig));

		  } else {
			/* If this is an isolated word, it uses its
			   own name. */
			assert(word_count == 1);
			fprintf(vvp_out, "v%p_%u .net%s%s %s\"%s\", %d %d, %s; "
				" %u drivers%s\n",
				sig, iword, vec8, datatype_flag, local_flag,
				vvp_mangle_name(ivl_signal_basename(sig)),
				msb, lsb, driver,
				nex_data->drivers_count,
				strength_aware_flag?", strength-aware":"" );
		  }
		  nex_data->net = sig;
		  nex_data->net_word = iword;

	    } else if (dimensions > 0) {

		    /* In this case, we have an alias to an existing
		       signal array. this typically is an instance of
		       port collapsing that the elaborator combined to
		       discover that the entire array can be collapsed,
		       so the word count for the signal and the alias
		       *must* match. */
		  if (iword == 0 && ivl_signal_dimensions(nex_data->net) > 0 &&
                      word_count == ivl_signal_array_count(nex_data->net)) {

			fprintf(vvp_out, "v%p .array \"%s\", v%p; Alias to %s \n",
			        sig, vvp_mangle_name(ivl_signal_basename(sig)),
			        nex_data->net,
			        ivl_signal_basename(nex_data->net));
			emit_packed_dims_(sig, "");
			break;

		    /* An alias for an individual word. */
		  } else {
			if (iword == 0) {
			      unsigned swapped = ivl_signal_array_addr_swapped(sig);
			      int first = ivl_signal_array_base(sig);
			      int last = first + word_count-1;
			      fprintf(vvp_out, "v%p .array \"%s\", %d %d;\n",
				      sig,
				      vvp_mangle_name(ivl_signal_basename(sig)),
				      swapped ? first : last,
				      swapped ? last : first );
			}

			fprintf(vvp_out, "v%p_%u .net%s v%p %u, %d %d, "
			        "v%p_%u; Alias to %s[%u]\n", sig, iword,
			        datatype_flag, sig, iword, msb, lsb,
			        nex_data->net, nex_data->net_word,
			        ivl_signal_basename(nex_data->net),
				nex_data->net_word);
		  }
	    } else {
		    /* Finally, we may have an alias that is a word
		       connected to another word. Again, this is a
		       case of port collapsing. */
		  int strength_aware_flag = 0;
		  const char*vec8 = "";
		  if (nex_data->flags&VVP_NEXUS_DATA_STR)
			strength_aware_flag = 1;
		  if (nex_data->drivers_count > 1)
			vec8 = "8";
		  if (strength_aware_flag)
			vec8 = "8";

		  fprintf(vvp_out, "v%p_%u .net%s%s %s\"%s\", %d %d, %s; "
				" alias, %u drivers%s\n",
				sig, iword, vec8, datatype_flag, local_flag,
				vvp_mangle_name(ivl_signal_basename(sig)),
				msb, lsb, driver,
				nex_data->drivers_count,
				strength_aware_flag?", strength-aware":"");
	    }

          /* Standalone local nets have no VPI handle. Array words and
             variables retain handles even when compiler-generated. */
          if ((!ivl_signal_local(sig) || dimensions > 0)
              && (ivl_signal_data_type(sig) == IVL_VT_BOOL
                  || ivl_signal_data_type(sig) == IVL_VT_LOGIC)) {
                char suffix[32];
                snprintf(suffix, sizeof suffix, "_%u", iword);
                emit_packed_dims_(sig, suffix);
                if (dimensions > 0 && iword == 0)
                      emit_packed_dims_(sig, "");
          }
      }

      if (ivl_signal_dimensions(sig) == 0 && !ivl_signal_local(sig)
	  && (ivl_signal_data_type(sig) == IVL_VT_BOOL
	      || ivl_signal_data_type(sig) == IVL_VT_LOGIC))
	    emit_signal_source_location_(sig, "_0");
}

void emit_deferred_array_decls(void)
{
      struct deferred_array_decl_s*cur;
      ivl_scope_t current_scope = 0;

      for (cur = deferred_array_decls ; cur ; cur = cur->next) {
	    ivl_signal_t sig = cur->sig;
	    ivl_scope_t scope;

	    if (!(cur->needed && !cur->emitted))
		  continue;
	    if (!sig)
		  continue;

	    scope = ivl_signal_scope(sig);
	    if (scope && scope != current_scope) {
		  fprintf(vvp_out, "    .scope S_%p;\n", scope);
		  current_scope = scope;
	    }

	    switch (ivl_signal_type(sig)) {
		case IVL_SIT_REG:
		  draw_reg_in_scope(sig);
		  break;
		default:
		  draw_net_in_scope(sig);
		  break;
	    }
      }
}

/*
 * Check to see if we need a delay.
 */
static unsigned need_delay(ivl_net_logic_t lptr)
{
	/* If we have no rising delay then we do not have any delays. */
      if (ivl_logic_delay(lptr, 0) == 0) {
	    assert(ivl_logic_delay(lptr, 1) == 0);
	    assert(ivl_logic_delay(lptr, 2) == 0);
	    return 0;
      }

      return 1;
}

/*
 * Draw the appropriate delay statement. Returns zero if there is not a delay.
 */
static void draw_logic_delay(ivl_net_logic_t lptr)
{
      ivl_expr_t rise_exp = ivl_logic_delay(lptr, 0);
      ivl_expr_t fall_exp = ivl_logic_delay(lptr, 1);
      ivl_expr_t decay_exp = ivl_logic_delay(lptr, 2);

	/* Calculate the width of the delay. We also use a BUFZ for real
	 * values so we need to resize if the first input is real. */
      unsigned delay_wid = width_of_nexus(ivl_logic_pin(lptr, 0));
      if (data_type_of_nexus(ivl_logic_pin(lptr, 0)) == IVL_VT_REAL) {
	    delay_wid = 0;
      }

      draw_delay(lptr, delay_wid, 0, rise_exp, fall_exp, decay_exp,
		 ivl_logic_delay_is_per_bit(lptr),
		 ivl_logic_delay_is_whole_vector(lptr));
}

static void draw_udp_def(ivl_udp_t udp)
{
  unsigned init;
  unsigned i;

  switch (ivl_udp_init(udp))
    {
    case '0':
      init = 0;
      break;
    case '1':
      init = 1;
      break;
    default:
      init = 2;
      break;
    }

  if (ivl_udp_sequ(udp))
	fprintf(vvp_out,
		"UDP_%s .udp/sequ \"%s\", %u, %u",
		vvp_mangle_id(ivl_udp_name(udp)),
		vvp_mangle_name(ivl_udp_name(udp)),
		ivl_udp_nin(udp),
		init );
  else
	fprintf(vvp_out,
		"UDP_%s .udp/comb \"%s\", %u",
		vvp_mangle_id(ivl_udp_name(udp)),
		vvp_mangle_name(ivl_udp_name(udp)),
		ivl_udp_nin(udp));

  for (i=0; i<ivl_udp_rows(udp); i++)
    fprintf(vvp_out, "\n ,\"%s\"", ivl_udp_row(udp, i) );

  fprintf(vvp_out, ";\n");
}

/* Check to see if the output of the UDP is connected with a modpath. */
static int udp_has_modpath_output(ivl_net_logic_t lptr)
{
	/* The first pin is the output connection (nexus). */
      ivl_nexus_t nex = ivl_logic_pin(lptr, 0);
      ivl_scope_t scope = ivl_logic_scope(lptr);
      unsigned idx;

	/* Check to see if there is a signal connected to the output. */
      for (idx = 0 ;  idx < ivl_nexus_ptrs(nex) ;  idx += 1) {
	    ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
	    ivl_signal_t sig = ivl_nexus_ptr_sig(ptr);
	    if (sig == 0) continue;
	      /* The modpath will be connected to the UDP output. */
	    if ((ivl_signal_scope(sig) == scope) &&
	        (ivl_signal_port(sig) == IVL_SIP_OUTPUT) &&
	        (ivl_signal_npath(sig))) return 1;
      }

      return 0;
}

static void draw_udp_in_scope(ivl_net_logic_t lptr)
{
      unsigned pdx;

      ivl_udp_t udp = ivl_logic_udp(lptr);

      static ivl_udp_t *udps = 0x0;
      static int nudps = 0;
      int i;
      unsigned ninp;
      const char **input_strings;

	/* Do we need a delay? */
      unsigned need_delay_flag = need_delay(lptr);

      for (i=0; i<nudps; i++) {
	    if (udps[i] == udp) break;
      }

      if (i >= nudps) {
	    udps = realloc(udps, (nudps+1)*sizeof(ivl_udp_t));
	    udps[nudps++] = udp;
	    draw_udp_def(udp);
      }

	/*
	 * We need to process the arguments first so any evaluation code
	 * (.resolv, etc.) can be built before we build the .udp call.
	 * This matches what is done for the other primitives.
	 */
      assert(ivl_logic_pins(lptr) > 0);
      ninp = ivl_logic_pins(lptr) - 1;
      input_strings = calloc(ninp, sizeof(char*));
      for (pdx = 0 ;  pdx < ninp ;  pdx += 1) {
	    ivl_nexus_t nex = ivl_logic_pin(lptr, pdx+1);

	      /* Unlike other logic gates, primitives may have unconnected
	       * inputs. The proper behavior is to attach a HiZ to the
	       * port. */
	    if (nex == 0) {
		  assert(ivl_logic_width(lptr) == 1);
		  input_strings[pdx] = "C4<z>";
	    } else {
		  input_strings[pdx] = draw_net_input(nex);
	    }
      }

	/* Because vvp uses a wide functor for the output of a UDP we need
	 * to define the output delay net when needed, otherwise it will
	 * not be cleaned up correctly (gives a valgrind warning). */
      if (need_delay_flag) {
	    fprintf(vvp_out, "v%p_0 .net *\"_d%p\", 0 0, L_%p/d;\n", lptr,
	            lptr, lptr);
      }
	/* The same situation exists if a modpath is used to connect the UDP
	 * output to the true output signal. For this case the modpath is
	 * the only thing connected to the UDP output. */
      if (udp_has_modpath_output(lptr)) {
	    fprintf(vvp_out, "v%p_0 .net *\"_m%p\", 0 0, L_%p;\n", lptr,
	            lptr, lptr);
      }

	/* Generate the UDP call. */
      fprintf(vvp_out, "L_%p%s .udp UDP_%s", lptr, need_delay_flag ? "/d" : "",
                       vvp_mangle_id(ivl_udp_name(udp)));

      for (pdx = 0 ;  pdx < ninp ;  pdx += 1) {
	    fprintf(vvp_out, ", %s", input_strings[pdx]);
      }
      free(input_strings);

      fprintf(vvp_out, ";\n");

	/* Generate a delay when needed. */
      if (need_delay_flag) draw_logic_delay(lptr);
}

static void draw_equiv_impl_in_scope(ivl_net_logic_t lptr)
{
      unsigned ninp;
      const char *lval;
      const char *rval;
      const char*ltype = "?";

      assert(width_of_nexus(ivl_logic_pin(lptr, 0)) == 1);

      assert(ivl_logic_pins(lptr) > 0);
      ninp = ivl_logic_pins(lptr) - 1;
      assert(ninp == 2);

      lval = draw_net_input(ivl_logic_pin(lptr, 1));
      rval = draw_net_input(ivl_logic_pin(lptr, 2));

      if (ivl_logic_type(lptr) == IVL_LO_EQUIV) {
	    ltype = "EQUIV";
      } else {
	    assert(ivl_logic_type(lptr) == IVL_LO_IMPL);
	    ltype = "IMPL";
      }

      fprintf(vvp_out, "L_%p .functor %s%s 1, %s, %s, C4<0>, C4<0>;\n", lptr, ltype, ivl_logic_event_synchronous(lptr) ? "/event" : "", lval, rval);
}

static void draw_logic_in_scope(ivl_net_logic_t lptr)
{
      unsigned pdx;
      const char*ltype = "?";
      const char*lcasc = 0;
      char identity_val = '0';

	/* Do we need a delay? */
      unsigned need_delay_flag = need_delay(lptr);

      unsigned vector_width = width_of_nexus(ivl_logic_pin(lptr, 0));

      ivl_drive_t str0 = ivl_logic_drive0(lptr);
      ivl_drive_t str1 = ivl_logic_drive1(lptr);

      int level;
      unsigned ninp;
      const char **input_strings;

      switch (ivl_logic_type(lptr)) {

          case IVL_LO_UDP:
	    draw_udp_in_scope(lptr);
	    return;

          case IVL_LO_BUFZ: {
		  /* Draw bufz objects, but only if the gate cannot
		     be elided. If I can elide it, then the
		     draw_nex_input will take care of it for me. */
		ivl_nexus_ptr_t nptr = ivl_logic_pin_ptr(lptr,0);

		ltype = "BUFZ";

		if (can_elide_bufz(lptr, nptr))
		      return;

		  /* A variable port connection is a continuous assignment
		     that delivers the settled value (see bufz_input_is_var). */
		if (ivl_logic_port_buffer(lptr) && ivl_logic_delay(lptr, 0) == 0
		    && bufz_input_is_var(lptr)) {
		      fprintf(vvp_out, "L_%p .sample %s;\n", lptr,
			      draw_net_input(ivl_logic_pin(lptr, 1)));
		      return;
		}

		break;
	  }

	  case IVL_LO_BUFT: {
		  /* Draw bufz objects, but only if the gate cannot
		     be elided. If I can elide it, then the
		     draw_nex_input will take care of it for me. */
		ivl_nexus_ptr_t nptr = ivl_logic_pin_ptr(lptr,0);

		ltype = "BUFT";

		if (can_elide_bufz(lptr, nptr))
		      return;

		break;
	  }

	  case IVL_LO_PULLDOWN:
	  case IVL_LO_PULLUP:
	      /* Skip pullup and pulldown objects. Things that have
		 pull objects as inputs will instead generate the
		 appropriate C<?> symbol. */
	    return;

	  case IVL_LO_AND:
	    ltype = "AND";
	    identity_val = '1';
	    break;

	  case IVL_LO_BUF:
	    ltype = "BUF";
	    break;

	  case IVL_LO_BUFIF0:
	    ltype = "BUFIF0";
	    break;

	  case IVL_LO_BUFIF1:
	    ltype = "BUFIF1";
	    break;

	  case IVL_LO_EQUIV:
	  case IVL_LO_IMPL:
	    draw_equiv_impl_in_scope(lptr);
	    return;

	  case IVL_LO_NAND:
	    ltype = "NAND";
	    lcasc = "AND";
	    identity_val = '1';
	    break;

	  case IVL_LO_NOR:
	    ltype = "NOR";
	    lcasc = "OR";
	    break;

	  case IVL_LO_NOT:
	    ltype = "NOT";
	    break;

	  case IVL_LO_OR:
	    ltype = "OR";
	    break;

	  case IVL_LO_XNOR:
	    ltype = "XNOR";
	    lcasc = "XOR";
	    break;

	  case IVL_LO_XOR:
	    ltype = "XOR";
	    break;

	  case IVL_LO_CMOS:
	    ltype = "CMOS";
	    break;

	  case IVL_LO_PMOS:
	    ltype = "PMOS";
	    break;

	  case IVL_LO_NMOS:
	    ltype = "NMOS";
	    break;

	  case IVL_LO_RCMOS:
	    ltype = "RCMOS";
	    break;

	  case IVL_LO_RPMOS:
	    ltype = "RPMOS";
	    break;

	  case IVL_LO_RNMOS:
	    ltype = "RNMOS";
	    break;

	  case IVL_LO_NOTIF0:
	    ltype = "NOTIF0";
	    break;

	  case IVL_LO_NOTIF1:
	    ltype = "NOTIF1";
	    break;

	  default:
	    fprintf(stderr, "vvp.tgt: error: Unhandled logic type: %d\n",
		    ivl_logic_type(lptr));
	    ltype = "?";
	    break;
      }

      if (!lcasc)
	lcasc = ltype;
      char event_type[32], event_cascade[32];
      if (ivl_logic_event_synchronous(lptr)) {
            snprintf(event_type, sizeof event_type, "%s/event", ltype);
            snprintf(event_cascade, sizeof event_cascade, "%s/event", lcasc);
            ltype = event_type;
            lcasc = event_cascade;
      }


	/* Get all the input label that I will use for parameters to
	   the functor that I create later. */
      assert(ivl_logic_pins(lptr) > 0);
      ninp = ivl_logic_pins(lptr) - 1;
      input_strings = calloc(ninp, sizeof(char*));
      for (pdx = 0 ;  pdx < (unsigned)ninp ;  pdx += 1)
	    input_strings[pdx] = draw_net_input(ivl_logic_pin(lptr, pdx+1));

      level = 0;
      while (ninp) {
	    unsigned inst;
	    for (inst = 0; inst < (unsigned)ninp; inst += 4) {
		  if (ninp > 4)
			fprintf(vvp_out, "L_%p/%d/%u .functor %s %u",
				lptr, level, inst, lcasc, vector_width);
		  else {
			fprintf(vvp_out, "L_%p%s .functor %s %u",
				lptr, need_delay_flag? "/d" : "",
				ltype, vector_width);

			if (str0 != IVL_DR_STRONG || str1 != IVL_DR_STRONG)
			      fprintf(vvp_out, " [%d %d]", str0, str1);

		  }
		  for (pdx = inst; pdx < (unsigned)ninp && pdx < inst+4 ; pdx += 1) {
			if (level) {
			      fprintf(vvp_out, ", L_%p/%d/%u",
				      lptr, level - 1, pdx*4);
			} else {
			      fprintf(vvp_out, ", %s", input_strings[pdx]);
			}
		  }
		  for ( ;  pdx < inst+4 ;  pdx += 1) {
			unsigned wdx;
			fprintf(vvp_out, ", C4<");
			for (wdx = 0 ; wdx < vector_width ;  wdx += 1)
			      fprintf(vvp_out, "%c", identity_val);
			fprintf(vvp_out, ">");
		  }

		  fprintf(vvp_out, ";\n");
	    }
	    if (ninp > 4)
		  ninp = (ninp+3) / 4;
	    else
		  ninp = 0;
	    level += 1;
      }

	/* Free the array of char*. The strings themselves are
	   persistent, held by the ivl_nexus_t objects. */
      free(input_strings);

	/* Generate a delay when needed. */
      if (need_delay_flag) draw_logic_delay(lptr);
}

/* ANYEDGE inputs normally wake on every object delivery because class
 * property mutation aliases intentionally re-deliver their root handle.
 * Direct object-handle controls instead compare handle identity. Keep runs of
 * those two semantics in separate (at most four-input) VVP functors. */
static unsigned anyedge_group_end_(ivl_event_t obj, unsigned first,
                                   unsigned nany, unsigned limit)
{
      int handle_change = ivl_event_any_is_obj_handle_change(obj, first);
      unsigned top = first + 1;
      while (top < nany && top - first < limit
             && ivl_event_any_is_obj_handle_change(obj, top) == handle_change)
            top += 1;
      return top;
}

static unsigned anyedge_group_count_(ivl_event_t obj, unsigned nany,
                                     unsigned limit)
{
      unsigned count = 0;
      for (unsigned idx = 0; idx < nany; count += 1)
            idx = anyedge_group_end_(obj, idx, nany, limit);
      return count;
}

static void draw_event_in_scope(ivl_event_t obj)
{
      char tmp[4][32];

      const unsigned ntmp = sizeof(tmp) / sizeof(tmp[0]);

	/* A virtual-interface edge event (@(edge vif.sig) / a direct
	   interface-port member) is serviced at run time by the
	   %wait/vif/<edge> opcode, which resolves the signal's edge functor
	   from the vif object dynamically — it never waits on this E_ record.
	   Emitting the usual edge-probe functors here would wire a
	   posedge/negedge/anyedge functor onto the vif HANDLE net (an object
	   net); when the handle is assigned its object at binding, that
	   functor's recv_object fires and asserts (posedge/negedge are not
	   implemented for object values). Emit a plain named-event record
	   instead so the label resolves but no spurious functor is created. */
      if (ivl_event_is_vif_posedge(obj) || ivl_event_is_vif_negedge(obj)
	  || ivl_event_is_vif_anyedge(obj)) {
	    fprintf(vvp_out, "E_%p .event \"%s\";\n", obj,
		    vvp_mangle_name(ivl_event_basename(obj)));
	    return;
      }

      unsigned nany = ivl_event_nany(obj);
      unsigned nneg = ivl_event_nneg(obj);
      unsigned npos = ivl_event_npos(obj);
      unsigned nedg = ivl_event_nedg(obj);

      unsigned cnt = 0;

      /* Figure out how many probe functors are needed. */
      if (nany > 0)
	    cnt += anyedge_group_count_(obj, nany, ntmp);

      if (nneg > 0)
	    cnt += (nneg+ntmp-1) / ntmp;

      if (npos > 0)
	    cnt += (npos+ntmp-1) / ntmp;

      if (nedg > 0)
	    cnt += (nedg+ntmp-1) / ntmp;

      if (cnt == 0) {
	      /* If none are needed, then this is a named event. The
		 code needed is easy. */
	    fprintf(vvp_out, "E_%p .event %s\"%s\";\n", obj,
		    event_storage_flag_str(obj),
		    vvp_mangle_name(ivl_event_basename(obj)));

      } else if (cnt > 1) {
	      /* There are a bunch of events that need to be event/or
		 combined. */
	    unsigned idx;
	    unsigned ecnt = 0;

	    for (idx = 0 ;  idx < nany ;  ecnt += 1) {
		  unsigned sub, top;

		  top = anyedge_group_end_(obj, idx, nany, ntmp);
		  for (sub = idx ;  sub < top ;  sub += 1) {
			ivl_nexus_t nex = ivl_event_any(obj, sub);
			strncpy(tmp[sub-idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }

		  fprintf(vvp_out, "E_%p/%u .event %s", obj, ecnt,
			  ivl_event_any_is_obj_handle_change(obj, idx)
				? "handleedge" : "anyedge");
		  for (sub = idx ;  sub < top ;  sub += 1)
			fprintf(vvp_out, ", %s", tmp[sub-idx]);

		  fprintf(vvp_out, ";\n");
		  idx = top;
	    }

	    for (idx = 0 ;  idx < nneg ;  idx += ntmp, ecnt += 1) {
		  unsigned sub, top;

		  top = idx + ntmp;
		  if (nneg < top)
			top = nneg;
		  for (sub = idx ;  sub < top ;  sub += 1) {
			ivl_nexus_t nex = ivl_event_neg(obj, sub);
			strncpy(tmp[sub-idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }

		  fprintf(vvp_out, "E_%p/%u .event negedge", obj, ecnt);
		  for (sub = idx ;  sub < top ;  sub += 1)
			fprintf(vvp_out, ", %s", tmp[sub-idx]);

		  fprintf(vvp_out, ";\n");
	    }

	    for (idx = 0 ;  idx < npos ;  idx += ntmp, ecnt += 1) {
		  unsigned sub, top;

		  top = idx + ntmp;
		  if (npos < top)
			top = npos;
		  for (sub = idx ;  sub < top ;  sub += 1) {
			ivl_nexus_t nex = ivl_event_pos(obj, sub);
			strncpy(tmp[sub-idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }

		  fprintf(vvp_out, "E_%p/%u .event posedge", obj, ecnt);
		  for (sub = idx ;  sub < top ;  sub += 1)
			fprintf(vvp_out, ", %s", tmp[sub-idx]);

		  fprintf(vvp_out, ";\n");
	    }

	    for (idx = 0 ;  idx < nedg ;  idx += ntmp, ecnt += 1) {
		  unsigned sub, top;

		  top = idx + ntmp;
		  if (nedg < top)
			top = nedg;
		  for (sub = idx ;  sub < top ;  sub += 1) {
			ivl_nexus_t nex = ivl_event_edg(obj, sub);
			strncpy(tmp[sub-idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }

		  fprintf(vvp_out, "E_%p/%u .event edge", obj, ecnt);
		  for (sub = idx ;  sub < top ;  sub += 1)
			fprintf(vvp_out, ", %s", tmp[sub-idx]);

		  fprintf(vvp_out, ";\n");
	    }

	    assert(ecnt == cnt);

	    fprintf(vvp_out, "E_%p .event/or", obj);
	    fprintf(vvp_out, " E_%p/0",  obj);

	    for (idx = 1 ;  idx < cnt ;  idx += 1)
		  fprintf(vvp_out, ", E_%p/%u", obj, idx);

	    fprintf(vvp_out, ";\n");

      } else {
	    unsigned num_input_strings = nany + nneg + npos + nedg;
	    unsigned idx;
	    const char*edge = 0;

	    assert(num_input_strings <= ntmp);

	    if (nany > 0) {
		  assert((nneg + npos + nedg) == 0);
		  assert(anyedge_group_end_(obj, 0, nany, ntmp) == nany);
		  edge = ivl_event_any_is_obj_handle_change(obj, 0)
		       ? "handleedge" : "anyedge";

		  for (idx = 0 ;  idx < nany ;  idx += 1) {
			ivl_nexus_t nex = ivl_event_any(obj, idx);
			strncpy(tmp[idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }

	    } else if (nneg > 0) {
		  assert((nany + npos + nedg) == 0);
		  edge = "negedge";

		  for (idx = 0 ;  idx < nneg ;  idx += 1) {
			ivl_nexus_t nex = ivl_event_neg(obj, idx);
			strncpy(tmp[idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }

	    } else if (npos > 0) {
		  assert((nany + nneg + nedg) == 0);
		  edge = "posedge";

		  for (idx = 0 ;  idx < npos ;  idx += 1) {
			ivl_nexus_t nex = ivl_event_pos(obj, idx);
			strncpy(tmp[idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }
	    } else {
		  assert((nany + nneg + npos) == 0);
		  edge = "edge";

		  for (idx = 0 ;  idx < nedg ;  idx += 1) {
			ivl_nexus_t nex = ivl_event_edg(obj, idx);
			strncpy(tmp[idx], draw_input_from_net(nex, ivl_event_scope(obj)), sizeof(tmp[0]));
		  }
	    }

	    fprintf(vvp_out, "E_%p .event %s", obj, edge);
	    for (idx = 0 ;  idx < num_input_strings ;  idx += 1) {
		  fprintf(vvp_out, ", %s", tmp[idx]);
	    }
	    fprintf(vvp_out, ";\n");
      }
}

/*
 * This function draws any functors needed to calculate the input to
 * this nexus, and leaves in the data array strings that can be used
 * as functor arguments. The strings are from the draw_net_input
 * function, which in turn returns nexus names, so the strings are
 * safe to pass around.
 */
static void draw_lpm_data_inputs(ivl_lpm_t net, unsigned base,
				 unsigned ndata, const char**src_table)
{
      unsigned idx;
      for (idx = 0 ;  idx < ndata ;  idx += 1) {
	    ivl_nexus_t nex = ivl_lpm_data(net, base+idx);
	    src_table[idx] = draw_net_input(nex);
      }
}

/*
 * If needed, draw a .delay node to delay the output from the LPM
 * device. Return the "/d" string if we drew this .delay node, or the
 * "" string if the node was not needed. The caller uses that string
 * to modify labels that are generated.
 */
static const char* draw_lpm_output_delay(ivl_lpm_t net, ivl_variable_type_t dt)
{
      ivl_expr_t d_rise = ivl_lpm_delay(net, 0);
      ivl_expr_t d_fall = ivl_lpm_delay(net, 1);
      ivl_expr_t d_decay = ivl_lpm_delay(net, 2);
      unsigned width = ivl_lpm_width(net);

	/* The comparison and reduction operators only have a single output
	 * bit to delay. */
      switch (ivl_lpm_type(net)) {
	  case IVL_LPM_CMP_EEQ:
	  case IVL_LPM_CMP_EQ:
	  case IVL_LPM_CMP_EQX:
	  case IVL_LPM_CMP_EQZ:
	  case IVL_LPM_CMP_GE:
	  case IVL_LPM_CMP_GT:
	  case IVL_LPM_CMP_NE:
	  case IVL_LPM_CMP_NEE:
	  case IVL_LPM_RE_AND:
	  case IVL_LPM_RE_OR:
	  case IVL_LPM_RE_XOR:
	  case IVL_LPM_RE_NAND:
	  case IVL_LPM_RE_NOR:
	  case IVL_LPM_RE_XNOR:
            width = 1;
	  default:
            break;
      }

      if (dt == IVL_VT_REAL) width = 0;

      const char*dly = "";
      if (d_rise != 0) {
	    draw_delay(net, width, 0, d_rise, d_fall, d_decay, 0, 0);
	    dly = "/d";
      }

      return dly;
}

static void draw_lpm_abs(ivl_lpm_t net)
{
      const char*src_table[1];
      ivl_variable_type_t dt = data_type_of_nexus(ivl_lpm_data(net,0));
      const char*dly;

      draw_lpm_data_inputs(net, 0, 1, src_table);

      dly = draw_lpm_output_delay(net, dt);

      fprintf(vvp_out, "L_%p%s .abs %s;\n",
	      net, dly, src_table[0]);
}

static void draw_lpm_cast_int2(ivl_lpm_t net)
{
      const char*src_table[1];
      const char*dly;

      draw_lpm_data_inputs(net, 0, 1, src_table);

      dly = draw_lpm_output_delay(net, IVL_VT_BOOL);

      fprintf(vvp_out, "L_%p%s .cast/2 %u, %s;\n",
	      net, dly, ivl_lpm_width(net), src_table[0]);
}

static void draw_lpm_cast_int(ivl_lpm_t net)
{
      const char*src_table[1];
      const char*dly;

      draw_lpm_data_inputs(net, 0, 1, src_table);

      dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      fprintf(vvp_out, "L_%p%s .cast/int %u, %s;\n",
	      net, dly, ivl_lpm_width(net), src_table[0]);
}

static void draw_lpm_cast_real(ivl_lpm_t net)
{
      const char*src_table[1];
      const char*dly;
      const char*is_signed = "";

      draw_lpm_data_inputs(net, 0, 1, src_table);

      dly = draw_lpm_output_delay(net, IVL_VT_REAL);

      if (ivl_lpm_signed(net)) is_signed = ".s";

      fprintf(vvp_out, "L_%p%s .cast/real%s %s;\n",
	      net, dly, is_signed, src_table[0]);
}

static void draw_lpm_add(ivl_lpm_t net)
{
      const char*src_table[2];
      unsigned width;
      const char*type = "";
      ivl_variable_type_t dta = data_type_of_nexus(ivl_lpm_data(net,0));
      ivl_variable_type_t dtb = data_type_of_nexus(ivl_lpm_data(net,1));
      ivl_variable_type_t dto = IVL_VT_LOGIC;
      const char*dly;

      if (dta == IVL_VT_REAL || dtb == IVL_VT_REAL)
	    dto = IVL_VT_REAL;

      width = ivl_lpm_width(net);

      switch (ivl_lpm_type(net)) {
	  case IVL_LPM_ADD:
	    if (dto == IVL_VT_REAL)
		  type = "sum.r";
	    else
		  type = "sum";
	    break;
	  case IVL_LPM_SUB:
	    if (dto == IVL_VT_REAL)
		  type = "sub.r";
	    else
		  type = "sub";
	    break;
	  case IVL_LPM_MULT:
	    if (dto == IVL_VT_REAL)
		  type = "mult.r";
	    else
		  type = "mult";
	    break;
	  case IVL_LPM_DIVIDE:
	    if (dto == IVL_VT_REAL)
		  type = "div.r";
	    else if (ivl_lpm_signed(net))
		  type = "div.s";
	    else
		  type = "div";
	    break;
	  case IVL_LPM_MOD:
	    if (dto == IVL_VT_REAL)
		  type = "mod.r";
	    else if (ivl_lpm_signed(net))
		  type = "mod.s";
	    else
		  type = "mod";
	    break;
	  case IVL_LPM_POW:
	    if (dto == IVL_VT_REAL)
		  type = "pow.r";
	    else if (ivl_lpm_signed(net))
		  type = "pow.s";
	    else
		  type = "pow";
	    break;
	  default:
	    assert(0);
      }

      draw_lpm_data_inputs(net, 0, 2, src_table);

      dly = draw_lpm_output_delay(net, dto);

      fprintf(vvp_out, "L_%p%s .arith/%s %u, %s, %s;\n",
	      net, dly, type, width, src_table[0], src_table[1]);
}

/*
* The read port to an array is generated as a single record that takes
* the address as an input.
*/
static void draw_lpm_array(ivl_lpm_t net)
{
      ivl_nexus_t nex;
      ivl_signal_t mem = ivl_lpm_array(net);
      const char*tmp;

      nex = ivl_lpm_select(net);
      tmp = draw_net_input(nex);

      if (ivl_lpm_clk(net)) {
	    const char*address = tmp;
	    const char*clock = draw_net_input(ivl_lpm_clk(net));
	    const char*enable = draw_net_input(ivl_lpm_enable(net));
	    const char*data = draw_net_input(ivl_lpm_data(net, 0));
	    fprintf(vvp_out,
		    "L_%p .array/port v%p, %s, %s, %s, %s, %u;\n",
		    net, mem, address, clock, enable, data,
		    ivl_lpm_negedge(net));
      } else {
	    fprintf(vvp_out, "L_%p .array/port v%p, %s;\n", net, mem, tmp);
      }
}

static void draw_lpm_cmp(ivl_lpm_t net)
{
      const char*src_table[2];
      unsigned width;
      const char*type = "";
      const char*signed_string = ivl_lpm_signed(net)? ".s" : "";
      ivl_variable_type_t dta = data_type_of_nexus(ivl_lpm_data(net,0));
      ivl_variable_type_t dtb = data_type_of_nexus(ivl_lpm_data(net,1));
      ivl_variable_type_t dtc = IVL_VT_LOGIC;
      const char*dly;

      if (dta == IVL_VT_REAL || dtb == IVL_VT_REAL)
	    dtc = IVL_VT_REAL;

      width = ivl_lpm_width(net);

      switch (ivl_lpm_type(net)) {
	  case IVL_LPM_CMP_EEQ:
	    assert(dtc != IVL_VT_REAL); /* Should never get here! */
	    type = "eeq";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_EQ:
	    if (dtc == IVL_VT_REAL)
		  type = "eq.r";
	    else
		  type = "eq";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_EQX:
	    assert(dtc != IVL_VT_REAL);
	    type = "eqx";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_EQZ:
	    assert(dtc != IVL_VT_REAL);
	    type = "eqz";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_GE:
	    if (dtc == IVL_VT_REAL) {
		  type = "ge.r";
		  signed_string = "";
	    } else
		  type = "ge";
	    break;
	  case IVL_LPM_CMP_GT:
	    if (dtc == IVL_VT_REAL) {
		  type = "gt.r";
		  signed_string = "";
	    } else
		  type = "gt";
	    break;
	  case IVL_LPM_CMP_NE:
	    if (dtc == IVL_VT_REAL)
		  type = "ne.r";
	    else
		  type = "ne";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_NEE:
	    assert(dtc != IVL_VT_REAL); /* Should never get here! */
	    type = "nee";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_WEQ:
	    assert(dtc != IVL_VT_REAL); /* Should never get here! */
	    type = "weq";
	    signed_string = "";
	    break;
	  case IVL_LPM_CMP_WNE:
	    assert(dtc != IVL_VT_REAL); /* Should never get here! */
	    type = "wne";
	    signed_string = "";
	    break;
	  default:
	    assert(0);
      }

      draw_lpm_data_inputs(net, 0, 2, src_table);

	/* The output of a compare is always logical. */
      dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      fprintf(vvp_out, "L_%p%s .cmp/%s%s %u, %s, %s;\n",
	      net, dly, type, signed_string, width,
	      src_table[0], src_table[1]);
}

/*
 * This function draws the arguments to a .const node using the
 * lpm inputs starting at "start" and for "cnt" inputs. This input
 * count must be <= 4. It is up to the caller to write the header part
 * of the statement, and to organize the data into multiple
 * statements.
 *
 * Return the width of the final concatenation.
 */
static unsigned lpm_concat_inputs(ivl_lpm_t net, unsigned start,
				  unsigned cnt, const char*src_table[])
{
      unsigned idx;
      unsigned wid = 0;

      assert(cnt <= 4);

	/* First, draw the [L M N O] part of the statement, the list
	   of widths for the .concat statement. */
      fprintf(vvp_out, "[");

      for (idx = 0 ;  idx < cnt ;  idx += 1) {
	    ivl_nexus_t nex = ivl_lpm_data(net, start+idx);
	    unsigned nexus_width = width_of_nexus(nex);
	    fprintf(vvp_out, " %u", nexus_width);
	    wid += nexus_width;
      }

      for ( ; idx < 4 ;  idx += 1)
	    fprintf(vvp_out, " 0");

      fprintf(vvp_out, "]");


      for (idx = 0 ;  idx < cnt ;  idx += 1) {
	    fprintf(vvp_out, ", %s", src_table[idx]);
      }

      fprintf(vvp_out, ";\n");
      return wid;
}

/*
 * Implement the general IVL_LPM_CONCAT using .concat nodes. Use as
 * many nested nodes as necessary to support the desired number of
 * input vectors.
 */
static void draw_lpm_concat(ivl_lpm_t net)
{
      const char*src_table[4];
      unsigned icnt = ivl_lpm_size(net);
      const char*dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);
      const char*z = ivl_lpm_type(net)==IVL_LPM_CONCATZ? "8" : "";

      if (icnt <= 4) {
	      /* This is the easiest case. There are 4 or fewer input
		 vectors, so the entire IVL_LPM_CONCAT can be
		 implemented with a single .concat node. */
	    draw_lpm_data_inputs(net, 0, icnt, src_table);
	    fprintf(vvp_out, "L_%p%s .concat%s ", net, dly, z);
	    lpm_concat_inputs(net, 0, icnt, src_table);

      } else {
	      /* If there are more than 4 inputs, things get more
		 complicated. We need to generate a balanced tree of
		 .concat nodes to blend the inputs down to a single
		 root node, that becomes the output from the
		 concatenation. */
	    unsigned idx, depth;
	    struct concat_tree {
		  unsigned base;
		  unsigned wid;
	    } *tree;

	    tree = malloc((icnt + 3)/4 * sizeof(struct concat_tree));

	      /* First, fill in all the leaves with the initial inputs
		 to the tree. After this loop, there are (icnt+3)/4
		 .concat nodes drawn, that together take all the
		 inputs. */
	    for (idx = 0 ;  idx < icnt ;  idx += 4) {
		  unsigned wid = 0;
		  unsigned trans = 4;
		  if ((idx + trans) > icnt)
			trans = icnt - idx;

		  draw_lpm_data_inputs(net, idx, trans, src_table);
		  fprintf(vvp_out, "LS_%p_0_%u .concat%s ", net, idx, z);
		  wid = lpm_concat_inputs(net, idx, trans, src_table);

		  tree[idx/4].base = idx;
		  tree[idx/4].wid  = wid;
	    }

	      /* icnt is the input count for the level. It is the
		 number of .concats of the previous level that have to
		 be concatenated at the current level. (This is not
		 the same as the bit width.) */
	    icnt = (icnt + 3)/4;

	      /* Tree now has icnt nodes that are depth=0 concat nodes
		 which take in the leaf inputs. The while loop below
		 starts and ends with a tree of icnt nodes. Each time
		 through, there are 1/4 the nodes we started
		 with. Thus, we eventually get down to <=4 nodes, and
		 that is when we fall out of the loop. */

	    depth = 1;
	    while (icnt > 4) {
		  for (idx = 0 ;  idx < icnt ;  idx += 4) {
			unsigned tdx;
			unsigned wid = 0;
			unsigned trans = 4;
			if ((idx+trans) > icnt)
			      trans = icnt - idx;

			fprintf(vvp_out, "LS_%p_%u_%u .concat%s [",
				net, depth, idx, z);

			for (tdx = 0 ;  tdx < trans ;  tdx += 1) {
			      fprintf(vvp_out, " %u", tree[idx+tdx].wid);
			      wid += tree[idx+tdx].wid;
			}

			for ( ;  tdx < 4 ;  tdx += 1)
			      fprintf(vvp_out, " 0");

			fprintf(vvp_out, "]");

			for (tdx = 0; tdx < trans ;  tdx += 1) {
			      fprintf(vvp_out, ", LS_%p_%u_%u", net,
				      depth-1, tree[idx+tdx].base);
			}

			fprintf(vvp_out, ";\n");
			tree[idx/4].base = idx;
			tree[idx/4].wid = wid;
		  }

		  depth += 1;
		  icnt = (icnt + 3)/4;
	    }

	      /* Finally, draw the root node that takes in the final
		 row of tree nodes and generates a single output. */
	    fprintf(vvp_out, "L_%p%s .concat%s [", net, dly, z);
	    for (idx = 0 ;  idx < icnt ;  idx += 1)
		  fprintf(vvp_out, " %u", tree[idx].wid);
	    for ( ;  idx < 4 ;  idx += 1)
		  fprintf(vvp_out, " 0");
	    fprintf(vvp_out, "]");

	    for (idx = 0 ;  idx < icnt ;  idx += 1)
		  fprintf(vvp_out, ", LS_%p_%u_%u",
			  net, depth-1, tree[idx].base);

	    fprintf(vvp_out, ";\n");
	    free(tree);
      }
}

/*
 * Emit a DFF primitive. This uses the following syntax:
 *
 * .dff<variant> <width> <data>, <clock>, <enable>
 *     [, <async-clear>[, <async-set>[, <async-set-value>]]];
 */
static void draw_lpm_ff(ivl_lpm_t net)
{
      ivl_nexus_t nex;
      const char*clk_in;
      const char*d_in;
      const char*e_in;
      const char*clr_in;
      const char*set_in;

	/* Sync set/clear control is not currently supported. This is not
	 * a problem, as synthesis can incorporate this in the D input
	 * expression. All modern synthesis tools do this as a matter of
	 * course, as most cell libraries don't contain flip-flops with
	 * sync set/clear.
	 */
      assert(ivl_lpm_sync_clr(net) == 0);
      assert(ivl_lpm_sync_set(net) == 0);

      unsigned width = ivl_lpm_width(net);
      const char*edge = ivl_lpm_negedge(net) ? "n" : "p";

      nex = ivl_lpm_clk(net);
      assert(nex);
      assert(width_of_nexus(nex) == 1);
      clk_in = draw_net_input(nex);

      nex = ivl_lpm_data(net,0);
      assert(nex);
      assert(width_of_nexus(nex) == width);
      d_in = draw_net_input(nex);

      nex = ivl_lpm_enable(net);
      if (nex) {
	    assert(width_of_nexus(nex) == 1);
	    e_in = draw_net_input(nex);
      } else {
	    e_in = "C4<1>";
      }

      nex = ivl_lpm_async_clr(net);
      if (nex) {
	    assert(width_of_nexus(nex) == 1);
	    clr_in = draw_net_input(nex);
      } else {
	    clr_in = 0;
      }

      nex = ivl_lpm_async_set(net);
      if (nex) {
	    assert(width_of_nexus(nex) == 1);
	    set_in = draw_net_input(nex);
      } else {
	    set_in = 0;
      }

      if (clr_in && set_in) {
	    const char*async_order = ivl_lpm_async_set_priority(net)
				    ? "aset/aclr" : "aclr/aset";
	    fprintf(vvp_out, "L_%p .dff/%s/%s %u ", net, edge,
		    async_order, width);
      } else if (clr_in) {
	    fprintf(vvp_out, "L_%p .dff/%s/aclr %u ", net, edge, width);
      } else if (set_in) {
	    fprintf(vvp_out, "L_%p .dff/%s/aset %u ", net, edge, width);
      } else {
	    fprintf(vvp_out, "L_%p .dff/%s %u ", net, edge, width);
      }

      fprintf(vvp_out, "%s, %s, %s", d_in, clk_in, e_in);

      if (clr_in) {
	    fprintf(vvp_out, ", %s", clr_in);
      }

      if (set_in) {
	    ivl_expr_t val = ivl_lpm_aset_value(net);
	    fprintf(vvp_out, ", %s", set_in);
	    if (val) {
		  unsigned nbits = ivl_expr_width(val);
		  const char*bits = ivl_expr_bits(val);
		  unsigned bb;
		  assert(nbits == width);
		  fprintf(vvp_out, ", C4<");
		  for (bb = 0 ;  bb < nbits;  bb += 1)
			fprintf(vvp_out, "%c", bits[nbits-bb-1]);
		  fprintf(vvp_out, ">");
	    }
      }

      fprintf(vvp_out, ";\n");
}

/*
 * Emit a LATCH primitive. This uses the following syntax:
 *
 * .latch <width> <data>, <enable>;
 */
static void draw_lpm_latch(ivl_lpm_t net)
{
      ivl_nexus_t nex;
      const char*d_in;
      const char*e_in;

      unsigned width = ivl_lpm_width(net);

      nex = ivl_lpm_data(net,0);
      assert(nex);
      assert(width_of_nexus(nex) == width);
      d_in = draw_net_input(nex);

      nex = ivl_lpm_enable(net);
      assert(nex);
      assert(width_of_nexus(nex) == 1);
      e_in = draw_net_input(nex);

      fprintf(vvp_out, "L_%p .latch %u %s, %s;\n", net, width, d_in, e_in);
}

static void draw_lpm_shiftl(ivl_lpm_t net)
{
      unsigned width = ivl_lpm_width(net);
      const char* signed_flag = ivl_lpm_signed(net)? "s" : "";
      const char*dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      const char *lval = draw_net_input(ivl_lpm_data(net, 0));
      const char *rval = draw_net_input(ivl_lpm_data(net, 1));

      if (ivl_lpm_type(net) == IVL_LPM_SHIFTR)
	    fprintf(vvp_out, "L_%p%s .shift/r%s %u", net, dly, signed_flag,
	            width);
      else
	    fprintf(vvp_out, "L_%p%s .shift/l %u", net, dly, width);

      fprintf(vvp_out, ", %s, %s;\n", lval, rval);
}

static void draw_type_string_of_nex(ivl_nexus_t nex)
{
      switch (data_type_of_nexus(nex)) {
	  case IVL_VT_REAL:
	    fprintf(vvp_out, "r");
	    break;
	  case IVL_VT_LOGIC:
          case IVL_VT_BOOL:
	    fprintf(vvp_out, "v%u", width_of_nexus(nex));
	    break;
	  default:
	    assert(0);
	    break;
      }
}

/* Check to see if the output of the system function is connected with
 * a modpath. */
static int sfunc_has_modpath_output(ivl_lpm_t lptr)
{
	/* The q port is the output connection (nexus). */
      ivl_nexus_t nex = ivl_lpm_q(lptr);
      ivl_scope_t scope = ivl_lpm_scope(lptr);
      unsigned idx;

	/* Check to see if there is a signal connected to the output. */
      for (idx = 0 ;  idx < ivl_nexus_ptrs(nex) ;  idx += 1) {
	    ivl_nexus_ptr_t ptr = ivl_nexus_ptr(nex, idx);
	    ivl_signal_t sig = ivl_nexus_ptr_sig(ptr);
	    if (sig == 0) continue;
	      /* The modpath will be connected to the system function
	       * output. */
	    if ((ivl_signal_scope(sig) == scope) &&
	        (ivl_signal_port(sig) == IVL_SIP_OUTPUT) &&
	        (ivl_signal_npath(sig))) return 1;
      }

      return 0;
}

/* Emit a definition for a net that has a delay or modpath. */
static void draw_sfunc_output_def(ivl_lpm_t net, char type)
{
      ivl_nexus_t nex = ivl_lpm_q(net);
      const char *suf = (type == 'd') ? "/d" : "";

      switch (data_type_of_nexus(nex)) {
	case IVL_VT_REAL:
	    fprintf(vvp_out, "v%p_0 .net/real *\"_%c%p\", 0 0, L_%p%s;\n",
	            net, type, net, net, suf);
	    break;
	case IVL_VT_LOGIC:
	case IVL_VT_BOOL:
	    fprintf(vvp_out, "v%p_0 .net *\"_%c%p\", %u 0, L_%p%s;\n",
	            net, type, net, width_of_nexus(nex)-1, net, suf);
	    break;
	default:
	    assert(0);
	    break;
      }
}

static void draw_lpm_sfunc(ivl_lpm_t net)
{
      unsigned idx;

      ivl_variable_type_t dt = data_type_of_nexus(ivl_lpm_q(net));
      const char*dly = draw_lpm_output_delay(net, dt);

	/* Get all the input labels that I will use for net signals that
	   connect to the inputs of the function. */
      unsigned ninp = ivl_lpm_size(net);
      const char**input_strings = calloc(ninp, sizeof(char*));
      for (idx = 0 ;  idx < ninp ;  idx += 1)
	    input_strings[idx] = draw_net_input(ivl_lpm_data(net, idx));

	/* Because vvp uses a wide functor for the output of a system
	 * function we need to define the output delay net when needed,
	 * otherwise it will not be cleaned up correctly (gives a
	 * valgrind warning). */
      if (*dly != 0) {
	    draw_sfunc_output_def(net, 'd');
      }
	/* The same situation exists if a modpath is used to connect the
	 * system function output to the true output signal. For this case
	 * the modpath is the only thing connected to the UDP output. */
      if (sfunc_has_modpath_output(net)) {
	    draw_sfunc_output_def(net, 'm');
      }

      if (ivl_lpm_trigger(net))
            fprintf(vvp_out, "L_%p%s .sfunc/e %u %u \"%s\", E_%p", net, dly,
                    ivl_file_table_index(ivl_lpm_file(net)),
                    ivl_lpm_lineno(net), ivl_lpm_string(net),
                    ivl_lpm_trigger(net));
      else
            fprintf(vvp_out, "L_%p%s .sfunc %u %u \"%s\"", net, dly,
                    ivl_file_table_index(ivl_lpm_file(net)),
                    ivl_lpm_lineno(net), ivl_lpm_string(net));

	/* Print the function type descriptor string. */
      fprintf(vvp_out, ", \"");

      draw_type_string_of_nex(ivl_lpm_q(net));

      for (idx = 0 ;  idx < ivl_lpm_size(net) ;  idx += 1)
	    draw_type_string_of_nex(ivl_lpm_data(net,idx));

      fprintf(vvp_out, "\"");

      for (idx = 0 ;  idx < ivl_lpm_size(net) ;  idx += 1) {
	    fprintf(vvp_out, ", %s", input_strings[idx]);
      }

      fprintf(vvp_out, ";\n");
}

static void draw_lpm_ufunc(ivl_lpm_t net)
{
      unsigned idx;
      unsigned ninp;
      const char**input_strings;
      ivl_scope_t def = ivl_lpm_define(net);

      ivl_variable_type_t dt = data_type_of_nexus(ivl_lpm_q(net));
      const char*dly = draw_lpm_output_delay(net, dt);

      const char*type_string = "";
      const char*mangled = vvp_mangle_id(ivl_scope_name(def));
      note_td_reference(mangled);
      switch (dt) {
	  case IVL_VT_REAL:
		type_string = "/real";
		break;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
		type_string = "/vec4";
		break;
	  default:
		break;
      }

	/* Get all the input labels that I will use for net signals that
	   connect to the inputs of the function. */
      ninp = ivl_lpm_size(net);
      input_strings = calloc(ninp, sizeof(char*));
      for (idx = 0 ;  idx < ninp ;  idx += 1)
	    input_strings[idx] = draw_net_input(ivl_lpm_data(net, idx));

	/* A fixed unpacked-array formal is stored as an array variable, not as
	   independently named vector variables. Create a constant read port for
	   every word so that the .ufunc input copier can address each destination
	   through the same kind of functor label used for scalar formals. The
	   function scope (and therefore the array declaration) is emitted later;
	   the VVP array loader intentionally supports these forward references. */
      {
	    unsigned formal;
	    unsigned formal_count = ivl_scope_ports(def);
	    for (formal = 1 ; formal < formal_count ; formal += 1) {
		  ivl_signal_t psig = ivl_scope_port(def, formal);
		  if (ivl_signal_dimensions(psig) == 0)
			continue;

		  unsigned word_count = ivl_signal_array_count(psig);
		  unsigned word;
		  for (word = 0 ; word < word_count ; word += 1) {
			fprintf(vvp_out,
			        "v%p_%u .array/port v%p, %u;\n",
			        psig, word, psig, word);
		  }
	    }
      }

      if (ivl_lpm_trigger(net)) {
	    assert(ninp > 0);
	    fprintf(vvp_out, "L_%p%s .ufunc/e TD_%s, %u, E_%p", net, dly,
	            mangled,
	            ivl_lpm_width(net), ivl_lpm_trigger(net));
      } else
	    fprintf(vvp_out, "L_%p%s .ufunc%s TD_%s, %u", net, dly, type_string,
	            mangled,
	            ivl_lpm_width(net));

	/* Print all the net signals that connect to the input of the
	   function. */
      for (idx = 0 ;  idx < ninp ;  idx += 1) {
	    fprintf(vvp_out, ", %s", input_strings[idx]);
      }
      free(input_strings);

	/* Now print all the variables in the function scope that
	   receive the input values given in the previous list. Fixed
	   unpacked-array formals are represented by one LPM input and one
	   function-scope variable per array word. */
      {
	    unsigned flat_port = 0;
	    unsigned formal;
	    unsigned formal_count = ivl_scope_ports(def);

	    assert(formal_count > 0);
	    for (formal = 1 ; formal < formal_count ; formal += 1) {
		  ivl_signal_t psig = ivl_scope_port(def, formal);
		  unsigned word_count = ivl_signal_dimensions(psig)
		        ? ivl_signal_array_count(psig) : 1;
		  unsigned word;

		  for (word = 0 ; word < word_count ; word += 1) {
			if (flat_port == 0)
			      fprintf(vvp_out, " (");
			else
			      fprintf(vvp_out, ", ");
			fprintf(vvp_out, "v%p_%u", psig, word);
			flat_port += 1;
		  }
	    }
	    assert(flat_port == ninp);
      }

      if (ninp == 0)
	    fprintf(vvp_out, ",");
      else
	    fprintf(vvp_out, ")");
#if 0
	/* Now print the reference to the signal from which the
	   result is collected. */
      { ivl_signal_t psig = ivl_scope_port(def, 0);
        assert(ivl_lpm_width(net) == ivl_signal_width(psig));
	assert(ivl_signal_dimensions(psig) == 0);

	fprintf(vvp_out, " v%p_0", psig);
      }
#endif
        /* Finally, print the scope identifier. */
      fprintf(vvp_out, " S_%p;\n", def);
}

/*
 * Handle a PART SELECT device. This has a single input and output,
 * plus an optional extra input that is a non-constant base.
 */
static void draw_lpm_part(ivl_lpm_t net)
{
      unsigned width, base;
      ivl_nexus_t sel;

      const char*input = draw_net_input(ivl_lpm_data(net, 0));
      const char*dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      width = ivl_lpm_width(net);
      base = ivl_lpm_base(net);
      sel = ivl_lpm_data(net,1);

      if (sel == 0) {
	    fprintf(vvp_out, "L_%p%s .part%s %s", net, dly,
                    ivl_lpm_event_synchronous(net) ? "/event" : "", input);
	    fprintf(vvp_out, ", %u, %u;\n", base, width);
      } else {
	    const char*sel_symbol = draw_net_input(sel);
	    fprintf(vvp_out, "L_%p%s .part/v%s %s", net, dly,
	                     (ivl_lpm_signed(net) ? ".s" : ""),
	                     input);
	    fprintf(vvp_out, ", %s", sel_symbol);
	    fprintf(vvp_out, ", %u;\n", width);
      }
}

/*
 * Handle a PART SELECT PV device. Generate a .part/pv node that
 * includes the part input, and the geometry of the part.
 */
static void draw_lpm_part_pv(ivl_lpm_t net)
{
      unsigned width = ivl_lpm_width(net);
      unsigned base  = ivl_lpm_base(net);
      unsigned signal_width = width_of_nexus(ivl_lpm_q(net));

      const char*input = draw_net_input(ivl_lpm_data(net, 0));

      fprintf(vvp_out, "L_%p .part/pv %s", net, input);
      fprintf(vvp_out, ", %u, %u, %u;\n", base, width, signal_width);
}

/*
 * Draw unary reduction devices.
 */
static void draw_lpm_re(ivl_lpm_t net, const char*type)
{
      const char*input = draw_net_input(ivl_lpm_data(net, 0));
      const char*dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      fprintf(vvp_out, "L_%p%s .reduce/%s %s;\n", net, dly, type, input);
}

static void draw_lpm_repeat(ivl_lpm_t net)
{
      const char*input = draw_net_input(ivl_lpm_data(net, 0));
      const char*dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      fprintf(vvp_out, "L_%p%s .repeat %u, %u, %s;\n", net, dly,
	      ivl_lpm_width(net), ivl_lpm_size(net), input);
}

static void draw_lpm_sign_ext(ivl_lpm_t net)
{
      const char*input = draw_net_input(ivl_lpm_data(net, 0));
      const char*dly = draw_lpm_output_delay(net, IVL_VT_LOGIC);

      fprintf(vvp_out, "L_%p%s .extend/s %u, %s;\n",
	      net, dly, ivl_lpm_width(net), input);
}

static void draw_lpm_vif_proxy(ivl_lpm_t net)
{
      const char*root = draw_net_input(ivl_lpm_data(net, 0));
      unsigned idx;
      fprintf(vvp_out, "L_%p .vifproxy L_%p/valid, %u, %s, %u, %u, %u",
              net, net, ivl_lpm_width(net), root, ivl_lpm_vif_root_word(net),
              ivl_lpm_vif_member(net), ivl_lpm_vif_word(net));
      for (idx = 0; idx < ivl_lpm_vif_path_count(net); idx += 1)
            fprintf(vvp_out, ", %u", ivl_lpm_vif_path(net, idx));
      fprintf(vvp_out, ";\n");
}

static void draw_lpm_in_scope(ivl_lpm_t net)
{
      switch (ivl_lpm_type(net)) {
          case IVL_LPM_VIF_PROXY:
            draw_lpm_vif_proxy(net);
            return;

	  case IVL_LPM_ABS:
	    draw_lpm_abs(net);
	    return;

	  case IVL_LPM_CAST_INT:
	    draw_lpm_cast_int(net);
	    return;

	  case IVL_LPM_CAST_INT2:
	    draw_lpm_cast_int2(net);
	    return;

	  case IVL_LPM_CAST_REAL:
	    draw_lpm_cast_real(net);
	    return;

	  case IVL_LPM_ADD:
	  case IVL_LPM_SUB:
	  case IVL_LPM_MULT:
	  case IVL_LPM_DIVIDE:
	  case IVL_LPM_MOD:
	  case IVL_LPM_POW:
	    draw_lpm_add(net);
	    return;

	  case IVL_LPM_ARRAY:
	    draw_lpm_array(net);
	    return;

	  case IVL_LPM_PART_VP:
	    draw_lpm_part(net);
	    return;

	  case IVL_LPM_PART_PV:
	    draw_lpm_part_pv(net);
	    return;

	  case IVL_LPM_CONCAT:
	  case IVL_LPM_CONCATZ:
	    draw_lpm_concat(net);
	    return;

	  case IVL_LPM_FF:
	    draw_lpm_ff(net);
	    return;

	  case IVL_LPM_LATCH:
	    draw_lpm_latch(net);
	    return;

	  case IVL_LPM_CMP_EEQ:
	  case IVL_LPM_CMP_EQ:
	  case IVL_LPM_CMP_EQX:
	  case IVL_LPM_CMP_EQZ:
	  case IVL_LPM_CMP_GE:
	  case IVL_LPM_CMP_GT:
	  case IVL_LPM_CMP_NE:
	  case IVL_LPM_CMP_NEE:
	  case IVL_LPM_CMP_WEQ:
	  case IVL_LPM_CMP_WNE:
	    draw_lpm_cmp(net);
	    return;

	  case IVL_LPM_MUX:
	    draw_lpm_mux(net);
	    return;

	  case IVL_LPM_RE_AND:
	    draw_lpm_re(net, "and");
	    return;
	  case IVL_LPM_RE_OR:
	    draw_lpm_re(net, "or");
	    return;
	  case IVL_LPM_RE_XOR:
	    draw_lpm_re(net, "xor");
	    return;
	  case IVL_LPM_RE_NAND:
	    draw_lpm_re(net, "nand");
	    return;
	  case IVL_LPM_RE_NOR:
	    draw_lpm_re(net, "nor");
	    return;
	  case IVL_LPM_RE_XNOR:
	    draw_lpm_re(net, "xnor");
	    return;

	  case IVL_LPM_REPEAT:
	    draw_lpm_repeat(net);
	    return;

	  case IVL_LPM_SHIFTL:
	  case IVL_LPM_SHIFTR:
	    draw_lpm_shiftl(net);
	    return;

	  case IVL_LPM_SIGN_EXT:
	    draw_lpm_sign_ext(net);
	    return;

	  case IVL_LPM_SFUNC:
	    draw_lpm_sfunc(net);
	    return;

	  case IVL_LPM_SUBSTITUTE:
	    draw_lpm_substitute(net);
	    return;

	  case IVL_LPM_UFUNC:
	    draw_lpm_ufunc(net);
	    return;

	  default:
	    fprintf(stderr, "XXXX LPM not supported: %s.%s\n",
		    ivl_scope_name(ivl_lpm_scope(net)), ivl_lpm_basename(net));
      }
}


static const char *vvp_port_info_type_str(ivl_signal_port_t ptype)
{
      switch( ptype )
      {
      case IVL_SIP_INPUT :  return "/INPUT";
      case IVL_SIP_OUTPUT : return "/OUTPUT";
      case IVL_SIP_INOUT :  return "/INOUT";
      case IVL_SIP_NONE :   return "/NODIR";
      default :
        abort(); // NO SUPPORT FOR ANYTHING ELSE YET...
      }
}

static ivl_signal_t evcd_signal_on_nexus(ivl_scope_t scope,
                                         ivl_nexus_t nexus,
                                         int allow_local)
{
      ivl_signal_t fallback = 0;
      unsigned idx;

      for (idx = 0; idx < ivl_nexus_ptrs(nexus); idx += 1) {
            ivl_signal_t sig = ivl_nexus_ptr_sig(ivl_nexus_ptr(nexus, idx));
            if (!sig || ivl_signal_scope(sig) != scope) continue;
            if (!fallback) fallback = sig;
            if (!ivl_signal_local(sig) &&
                ivl_signal_port(sig) != IVL_SIP_NONE)
                  return sig;
      }
      return allow_local ? fallback : 0;
}

static ivl_signal_t evcd_port_component_signal(ivl_scope_t scope,
                                                ivl_nexus_t nexus,
                                                unsigned *component_width,
                                                int *left, int *right)
{
      ivl_signal_t port_sig = evcd_signal_on_nexus(scope, nexus, 1);
      ivl_nexus_t value_nexus = port_sig
                             ? ivl_signal_nex(port_sig, 0) : nexus;
      ivl_signal_t sig;
      unsigned idx;

      /* A selected non-ANSI port component is represented by a local
       * temporary on this nexus and either a PART_{VP,PV} node or one input
       * of a CONCAT leading to the declared full signal. Recover that signal
       * and the selected range so EVCD emits one component instead of
       * duplicating the whole bus. Do this before accepting a signal on the
       * component nexus: elaboration can mark its generated _ivl temporary
       * as a port signal as well. */
      for (idx = 0; idx < ivl_nexus_ptrs(value_nexus); idx += 1) {
            ivl_lpm_t lpm =
                  ivl_nexus_ptr_lpm(ivl_nexus_ptr(value_nexus, idx));
            ivl_nexus_t full_nexus;
            unsigned base;
            int signal_left, signal_right;

            if (!lpm) continue;
            if (ivl_lpm_type(lpm) == IVL_LPM_PART_VP)
                  full_nexus = ivl_lpm_data(lpm, 0);
            else if (ivl_lpm_type(lpm) == IVL_LPM_PART_PV)
                  full_nexus = ivl_lpm_q(lpm);
            else if (ivl_lpm_type(lpm) == IVL_LPM_CONCAT ||
                     ivl_lpm_type(lpm) == IVL_LPM_CONCATZ) {
                  unsigned data, count = ivl_lpm_size(lpm);
                  base = 0;
                  for (data = 0; data < count; data += 1) {
                        ivl_nexus_t input = ivl_lpm_data(lpm, data);
                        if (input == value_nexus) break;
                        base += width_of_nexus(input);
                  }
                  if (data == count) continue;
                  full_nexus = ivl_lpm_q(lpm);
            } else continue;
            sig = evcd_signal_on_nexus(scope, full_nexus, 0);
            if (!sig) continue;

            if (ivl_lpm_type(lpm) == IVL_LPM_CONCAT ||
                ivl_lpm_type(lpm) == IVL_LPM_CONCATZ)
                  *component_width = width_of_nexus(value_nexus);
            else {
                  *component_width = ivl_lpm_width(lpm);
                  base = ivl_lpm_base(lpm);
            }
            signal_left = ivl_signal_packed_dimensions(sig)
                        ? ivl_signal_packed_msb(sig, 0) : 0;
            signal_right = ivl_signal_packed_dimensions(sig)
                         ? ivl_signal_packed_lsb(sig, 0) : 0;
            if (signal_left >= signal_right) {
                  *right = signal_right + (int)base;
                  *left = *right + (int)*component_width - 1;
            } else {
                  *right = signal_right - (int)base;
                  *left = *right - (int)*component_width + 1;
            }
            return sig;
      }

      sig = port_sig;
      if (sig) {
            *component_width = ivl_signal_width(sig);
            *left = ivl_signal_packed_dimensions(sig)
                  ? ivl_signal_packed_msb(sig, 0) : 0;
            *right = ivl_signal_packed_dimensions(sig)
                   ? ivl_signal_packed_lsb(sig, 0) : 0;
      }
      return sig;
}

static ivl_switch_t evcd_port_component_switch(ivl_scope_t scope,
                                                unsigned port_index,
                                                unsigned component_index)
{
      unsigned idx;
      for (idx = 0; idx < ivl_scope_switches(scope); idx += 1) {
            ivl_switch_t sw = ivl_scope_switch(scope, idx);
            if (ivl_switch_port_index(sw) == (int)port_index &&
                ivl_switch_port_component(sw) == (int)component_index)
                  return sw;
      }
      return 0;
}

#define EVCD_METADATA_MAX_RECORDS 4096U
#define EVCD_METADATA_MAX_BITS (4ULL * 1024ULL * 1024ULL)
static unsigned evcd_metadata_records;
static unsigned long long evcd_metadata_bits;
static unsigned long long evcd_proxy_bits;
static int evcd_metadata_budget_failed;

void reset_evcd_metadata_budget(void)
{
      evcd_metadata_records = 0;
      evcd_metadata_bits = 0;
      evcd_proxy_bits = 0;
      evcd_metadata_budget_failed = 0;
}

int scope_needs_call_frame(ivl_scope_t net)
{
      unsigned idx;
      ivl_scope_type_t type = ivl_scope_type(net);

      if (ivl_scope_is_auto(net))
	    return 1;
      if (type != IVL_SCT_TASK && type != IVL_SCT_FUNCTION
	  && type != IVL_SCT_BEGIN && type != IVL_SCT_FORK)
	    return 0;

      for (idx = 0 ; idx < ivl_scope_sigs(net) ; idx += 1)
	    if (ivl_signal_lifetime(ivl_scope_sig(net, idx))
		== IVL_VLT_AUTOMATIC)
		  return 1;
      return 0;
}

int draw_scope(ivl_scope_t net, ivl_scope_t parent)
{
      unsigned idx;
      const char *dumpports_flag =
            ivl_design_flag(vvp_get_saved_design(), "DUMPPORTS");
      int emit_evcd_metadata = dumpports_flag && *dumpports_flag;
      const char *type;

      const char*prefix = ivl_scope_is_auto(net) ? "auto" : "";
      char suffix[32];

      suffix[0] = 0;

        /* A static subroutine or named block can own a call frame solely for
	   declarations that carry an explicit automatic lifetime. Keep the
	   scope static for VPI and inherited declarations, but tell vvp that
	   its ^-marked items have a context to register in. */
      int mixed_lifetime_scope = !ivl_scope_is_auto(net)
	    && scope_needs_call_frame(net);

      switch (ivl_scope_type(net)) {
      case IVL_SCT_MODULE:
	    /* Program blocks elaborate as module scopes with the
	       program flag; the runtime schedules their processes in
	       the Reactive region set (IEEE 1800-2017 4.4.2.5, 24.3).
	       M12: interface instances get their own scope type so
	       VPI reports vpiInterface. */
	    type = ivl_scope_program(net) ? "program"
		 : ivl_scope_is_interface(net) ? "interface"
		 : "module";
	    break;
      case IVL_SCT_FUNCTION:
	    type = mixed_lifetime_scope ? "function.ctx" : "function";
	    break;
      case IVL_SCT_TASK:
	    type = mixed_lifetime_scope ? "task.ctx" : "task";
	    break;
	/* An automatic begin/fork scope that is collapsed into the
	   enclosing activation frame is marked ".shared": the runtime
	   places its automatic locals in the frame-owning ancestor
	   scope and expects no %alloc/%free for it. */
      case IVL_SCT_BEGIN:
	    type = mixed_lifetime_scope ? "begin.ctx" : "begin";
	    if (ivl_scope_is_auto(net) && !ivl_scope_auto_frame(net))
		  snprintf(suffix, sizeof suffix, ".shared");
	    break;
      case IVL_SCT_FORK:
	    type = mixed_lifetime_scope ? "fork.ctx" : "fork";
	    if (ivl_scope_is_auto(net) && !ivl_scope_auto_frame(net))
		  snprintf(suffix, sizeof suffix, ".shared");
	    break;
      case IVL_SCT_GENERATE: type = "generate"; break;
      case IVL_SCT_PACKAGE:  type = "package";  break;
      case IVL_SCT_CLASS:    type = "class";    break;
      default:               type = "?";        assert(0);
      }

      if (ivl_scope_type(net)==IVL_SCT_FUNCTION) {
	    switch (ivl_scope_func_type(net)) {
		case IVL_VT_LOGIC:
		  snprintf(suffix, sizeof suffix, ".vec4.%c%u",
			   ivl_scope_func_signed(net)? 'u' : 's',
			   ivl_scope_func_width(net));
		  break;
		case IVL_VT_BOOL:
		  snprintf(suffix, sizeof suffix, ".vec2.%c%u",
			   ivl_scope_func_signed(net)? 'u' : 's',
			   ivl_scope_func_width(net));
		  break;
		case IVL_VT_REAL:
		  snprintf(suffix, sizeof suffix, ".real");
		  break;
		case IVL_VT_STRING:
		  snprintf(suffix, sizeof suffix, ".str");
		  break;
		case IVL_VT_CLASS:
		case IVL_VT_DARRAY:
		case IVL_VT_QUEUE:
		case IVL_VT_NO_TYPE:
		  snprintf(suffix, sizeof suffix, ".obj");
		  break;
		case IVL_VT_VOID:
		  snprintf(suffix, sizeof suffix, ".void");
		  break;
		default:
		  fprintf(stderr, "draw_scope: unexpected function type %d for %s.%s\n",
			  (int)ivl_scope_func_type(net),
			  ivl_scope_tname(net), ivl_scope_basename(net));
		  assert(0);
		  break;
	    }
      }

      fprintf(vvp_out, "S_%p .scope %s%s%s, \"%s\" \"%s\" %u %u",
	      net, prefix, type, suffix,
	      vvp_mangle_name(ivl_scope_basename(net)),
              vvp_mangle_name(ivl_scope_tname(net)),
	      ivl_file_table_index(ivl_scope_file(net)),
              ivl_scope_lineno(net));

      if (parent) {
	    fprintf(vvp_out, ", %u %u %u, S_%p;\n",
	            ivl_file_table_index(ivl_scope_def_file(net)),
	            ivl_scope_def_lineno(net), ivl_scope_is_cell(net), parent);
      } else {

	    fprintf(vvp_out, ";\n");
      }

      fprintf(vvp_out, " .timescale %d %d;\n", ivl_scope_time_units(net),
                                               ivl_scope_time_precision(net));

	/* M12: modport declarations of an interface, for VPI —
	   M12-6 appends each port as "name" direction pairs. */
      if (ivl_scope_is_interface(net)) {
	    for (idx = 0; idx < ivl_scope_modports(net); idx += 1) {
		  unsigned pidx;
		  fprintf(vvp_out, " .modport \"%s\"",
			  vvp_mangle_name(ivl_scope_modport_name(net, idx)));
		  for (pidx = 0; pidx < ivl_scope_modport_ports(net, idx); pidx += 1)
			fprintf(vvp_out, " \"%s\" %d",
				vvp_mangle_name(ivl_scope_modport_port_name(net, idx, pidx)),
				ivl_scope_modport_port_dir(net, idx, pidx));
		  fprintf(vvp_out, ";\n");
	    }
      }

      if( ivl_scope_type(net) == IVL_SCT_MODULE ) {
	    unsigned flat_port = 0;

	      // Port data for VPI: needed for vpiPorts property of vpiModule
	    for( idx = 0; idx < ivl_scope_mod_module_ports(net); ++idx ) {
		  const char *name =  ivl_scope_mod_module_port_name(net,idx);
		  ivl_signal_port_t ptype = ivl_scope_mod_module_port_type(net,idx);
		  unsigned width = ivl_scope_mod_module_port_width(net,idx);
		  ivl_net_logic_t buffer = ivl_scope_mod_module_port_buffer(net,idx);
		  if( name == 0 )
			name = "";
		  fprintf( vvp_out, "    .port_info %u %s %u \"%s\"",
		           idx, vvp_port_info_type_str(ptype), width,
		           vvp_mangle_name(name) );
		  if (buffer) fprintf( vvp_out, " L_%p;\n", buffer);
		  else fprintf( vvp_out, ";\n");

		  /* Preserve the flattened declaration components for EVCD.  A
		   * concatenated module port is one vpiPort signature but each
		   * named component is a separate $var port entry. */
		  if (emit_evcd_metadata && !evcd_metadata_budget_failed) {
			unsigned consumed = 0;
			unsigned component = 0;
			while (consumed < width && flat_port < ivl_scope_ports(net)) {
			      ivl_nexus_t nexus = ivl_scope_mod_port(net, flat_port++);
			      ivl_signal_t sig;
			      unsigned component_width;
			      int left, right;
			      const char *component_name;

			      sig = evcd_port_component_signal(net, nexus,
			                                       &component_width,
			                                       &left, &right);

			      if (!sig) {
				    fprintf(stderr,
				      "vvp.tgt error: module port %u has no EVCD value signal.\n",
				      idx);
				    vvp_errors += 1;
				    break;
			      }
			      if (!component_width || component_width > width-consumed) {
				    fprintf(stderr,
				      "vvp.tgt error: module port %u has inconsistent EVCD component width.\n",
				      idx);
				    vvp_errors += 1;
				    break;
			      }
			      if (evcd_metadata_records >=
			                                      EVCD_METADATA_MAX_RECORDS ||
			          component_width > EVCD_METADATA_MAX_BITS-
			                            evcd_metadata_bits) {
				    fprintf(stderr,
				      "vvp.tgt error: EVCD metadata exceeds the safe aggregate record/width budget.\n");
				    vvp_errors += 1;
				    evcd_metadata_budget_failed = 1;
				    break;
			      }
			      evcd_metadata_records += 1;
			      evcd_metadata_bits += component_width;
			      component_name = ivl_signal_basename(sig);

			      if (ptype == IVL_SIP_INOUT) {
				    ivl_switch_t sw = evcd_port_component_switch(net,
				                                                   idx,
				                                                   component);
				    if (sw) {
					  ivl_nexus_t fixture_nexus = ivl_switch_a(sw);
					  ivl_nexus_t dut_nexus = ivl_switch_b(sw);
					  ivl_island_t island = ivl_switch_island(sw);
					  const char *fixture =
					        draw_island_local_input(island,
					                                fixture_nexus);
					  const char *dut =
					        draw_island_local_input(island, dut_nexus);
					  unsigned fixture_width =
					        ivl_switch_type(sw) == IVL_SW_TRAN_VP
					        ? ivl_switch_width(sw) : component_width;
					  unsigned fixture_base =
					        ivl_switch_type(sw) == IVL_SW_TRAN_VP
					        ? ivl_switch_offset(sw) : 0;
					  unsigned long long proxy_bits;
					  char fixture_probe[64];
					  char dut_probe[64];
					  if (!fixture_width ||
					      fixture_width > EVCD_METADATA_MAX_BITS ||
					      component_width > EVCD_METADATA_MAX_BITS-
					                        fixture_width) {
						fprintf(stderr,
						  "vvp.tgt error: EVCD proxy width exceeds the safe aggregate width budget.\n");
						vvp_errors += 1;
						evcd_metadata_budget_failed = 1;
						break;
					  }
					  proxy_bits = (unsigned long long)fixture_width +
					               component_width;
					  if (proxy_bits > EVCD_METADATA_MAX_BITS-
					                   evcd_proxy_bits) {
						fprintf(stderr,
						  "vvp.tgt error: EVCD proxies exceed the safe aggregate width budget.\n");
						vvp_errors += 1;
						evcd_metadata_budget_failed = 1;
						break;
					  }
					  evcd_proxy_bits += proxy_bits;
					  snprintf(fixture_probe, sizeof fixture_probe,
					           "EVF_%p", sw);
					  snprintf(dut_probe, sizeof dut_probe,
					           "EVD_%p", sw);
					  /* Put a private strength-aware filter on each local
					   * driver stream.  The filters make strength-only
					   * changes observable to VPI callbacks without
					   * exposing extra user-visible nets. */
					  fprintf(vvp_out,
					    "EVF_%p .net8 * \"$ivl_evcd_fixture\", %u 0, %s;\n",
					    sw, fixture_width-1, fixture);
					  fprintf(vvp_out,
					    "EVD_%p .net8 * \"$ivl_evcd_dut\", %u 0, %s;\n",
					    sw, component_width-1, dut);
					  fprintf(vvp_out,
					    "    .port_info/evcd %u %u %u \"%s\" \"%d\" \"%d\" %u %u %u %s %u %u %s;\n",
					    idx, component, component_width,
					    vvp_mangle_name(component_name), left, right,
					    fixture_width, fixture_base,
					    draw_island_local_drivers(island,
					                              fixture_nexus),
					    fixture_probe,
					    component_width,
					    draw_island_local_drivers(island,
					                              dut_nexus),
					    dut_probe);
				    } else {
					  fprintf(vvp_out,
					    "    .port_info/evcd %u %u %u \"%s\" \"%d\" \"%d\";\n",
					    idx, component, component_width,
					    vvp_mangle_name(component_name), left, right);
				    }
			      } else {
				    fprintf(vvp_out,
				      "    .port_info/evcd %u %u %u \"%s\" \"%d\" \"%d\";\n",
				      idx, component, component_width,
				      vvp_mangle_name(component_name), left, right);
			      }
			      consumed += component_width;
			      component += 1;
			}
		  }
	    }
      }

      for (idx = 0 ;  idx < ivl_scope_params(net) ;  idx += 1) {
	    ivl_parameter_t par = ivl_scope_param(net, idx);

	      // Skip type parameters for now. Support for type parameters
	      // should be added together with support for quering types through
	      // VPI.
	    if (ivl_parameter_is_type(par))
		  continue;

	    ivl_expr_t pex = ivl_parameter_expr(par);
	    switch (ivl_expr_type(pex)) {
		case IVL_EX_STRING:
		  fprintf(vvp_out, "P_%p .param/str \"%s\" %d %u %u, \"%s\";\n",
			  par, vvp_mangle_name(ivl_parameter_basename(par)),
			  ivl_parameter_local(par),
			  ivl_file_table_index(ivl_parameter_file(par)),
			  ivl_parameter_lineno(par),
			  ivl_expr_string(pex));
		  break;
		case IVL_EX_NUMBER:
		  fprintf(vvp_out, "P_%p .param/l \"%s\" %d %u %u, %sC4<",
			  par, vvp_mangle_name(ivl_parameter_basename(par)),
                          ivl_parameter_local(par),
			  ivl_file_table_index(ivl_parameter_file(par)),
			  ivl_parameter_lineno(par),
			  ivl_expr_signed(pex)? "+":"");
		  { const char*bits = ivl_expr_bits(pex);
		    unsigned nbits = ivl_expr_width(pex);
		    unsigned bb;
		    for (bb = 0 ;  bb < nbits;  bb += 1)
			  fprintf(vvp_out, "%c", bits[nbits-bb-1]);
		  }
		  fprintf(vvp_out, ">;\n");
		  break;
		case IVL_EX_REALNUM:
		  { char *res = draw_Cr_to_string(ivl_expr_dvalue(pex));
		    fprintf(vvp_out, "P_%p .param/real \"%s\" %d %u %u, %s; "
		            "value=%#g\n", par,
			    vvp_mangle_name(ivl_parameter_basename(par)),
	                    ivl_parameter_local(par),
			    ivl_file_table_index(ivl_parameter_file(par)),
			    ivl_parameter_lineno(par), res,
			    ivl_expr_dvalue(pex));
		    free(res);
		  }
		  break;
		default:
		  fprintf(vvp_out, "; parameter type %d unsupported\n",
			  ivl_expr_type(pex));
		  break;
	    }
      }

      for (idx = 0 ; idx < ivl_scope_classes(net) ; idx += 1) {
	    ivl_type_t class_type = ivl_scope_class(net,idx);
	    draw_class_in_scope(class_type);
      }

	/* Scan the scope for enumeration types, and write out
	   enumeration typespecs. */

      for (idx = 0 ; idx < ivl_scope_enumerates(net) ; idx += 1) {
	    ivl_enumtype_t enumtype = ivl_scope_enumerate(net, idx);
	    draw_enumeration_in_scope(enumtype);
      }

	/* Scan the scope for logic devices. For each device, draw out
	   a functor that connects pin 0 to the output, and the
	   remaining pins to inputs. */

      for (idx = 0 ;  idx < ivl_scope_logs(net) ;  idx += 1) {
	    ivl_net_logic_t lptr = ivl_scope_log(net, idx);
	    draw_logic_in_scope(lptr);
      }


	/* Scan the signals (reg and net) and draw the appropriate
	   statements to make the signal function. */

      for (idx = 0 ;  idx < ivl_scope_sigs(net) ;  idx += 1) {
	    ivl_signal_t sig = ivl_scope_sig(net, idx);

	    switch (ivl_signal_type(sig)) {
		case IVL_SIT_REG:
		  draw_reg_in_scope(sig);
		  break;
		default:
		  draw_net_in_scope(sig);
		  break;
	    }
      }

      for (idx = 0 ;  idx < ivl_scope_events(net) ;  idx += 1) {
	    ivl_event_t event = ivl_scope_event(net, idx);
	    draw_event_in_scope(event);
            if (ivl_event_vif_validity(event))
                  fprintf(vvp_out, " .eventvalid E_%p, %s;\n", event,
                          draw_net_input(ivl_event_vif_validity(event)));
      }

      for (idx = 0 ;  idx < ivl_scope_lpms(net) ;  idx += 1) {
	    ivl_lpm_t lpm = ivl_scope_lpm(net, idx);
	    draw_lpm_in_scope(lpm);
      }

      for (idx = 0 ; idx < ivl_scope_switches(net) ; idx += 1) {
	    ivl_switch_t sw = ivl_scope_switch(net, idx);
	    draw_switch_in_scope(sw);
      }

      if (ivl_scope_type(net) == IVL_SCT_TASK)
	    vvp_errors += draw_task_definition(net);

      if (ivl_scope_type(net) == IVL_SCT_FUNCTION)
	    vvp_errors += draw_func_definition(net);

	/* DPI export (35.5): record any subroutine marked exported so the
	   runtime :export_dpi directives and the C stub file can be emitted
	   once every scope (hence every TD_ label and port net) exists. */
      if ((ivl_scope_type(net) == IVL_SCT_FUNCTION
	   || ivl_scope_type(net) == IVL_SCT_TASK)
	  && ivl_scope_is_dpi_export(net))
	    note_dpi_export(net);

      ivl_scope_children(net, (ivl_scope_f*) draw_scope, net);
      return 0;
}

/*
 * DPI export (IEEE 1800-2017 35.5) support.
 *
 * Collect every SV subroutine that carried an `export "DPI-C"'
 * declaration (marked on the scope via ivl_scope_is_dpi_export), then at
 * end of code generation emit:
 *
 *   1. a `:export_dpi' runtime directive per export, giving the exported
 *      C name, the function's TD_ thread-definition label, its return and
 *      argument type signatures, and the vvp net labels of its return and
 *      argument port signals; and
 *
 *   2. a companion C stub file `<out>.dpiexport.c' containing, for each
 *      export, the C entry point the user's DPI object links against. The
 *      stub packs its C arguments into a generic argument buffer and calls
 *      the vvp-exported dispatcher __ivl_dpi_export_call_*.
 *
 * The runtime supports scalar formals and fixed unpacked arrays of Annex H
 * atom or packed bit/logic elements. Exported open arrays are prohibited by
 * Annex H.8.2; unsupported shapes are diagnosed and their C symbol is not
 * generated.
 */

struct dpi_export_entry_s {
      ivl_scope_t scope;
      int abi_conflict;
      struct dpi_export_entry_s*next;
};

static struct dpi_export_entry_s*dpi_exports = 0;
static struct dpi_export_entry_s*dpi_exports_tail = 0;

void note_dpi_export(ivl_scope_t scope)
{
      struct dpi_export_entry_s*ent = calloc(1, sizeof *ent);
      ent->scope = scope;
      ent->next = 0;
      if (dpi_exports_tail)
	    dpi_exports_tail->next = ent;
      else
	    dpi_exports = ent;
      dpi_exports_tail = ent;
}

/* Classify a port (or the return signal) for DPI export. Returns 1 if the
   shape is supported. On success writes the runtime signature letter
   (*sig_letter) and the C type spelling (*c_type). Signature letters:
     'i' unsigned integer atom, 'I' signed integer atom,
     'B' scalar bit return/fixed bit array, 't' scalar bit argument,
     'g' scalar logic, 'p' chandle, 'f' shortreal,
     'r' real (double), 's' string, 'V' packed bit vector,
     'W' packed logic vector, 'v' void (return only). */
static int dpi_export_classify(ivl_scope_t scope, ivl_signal_t port,
			       const char*c_name, char*sig_letter,
			       const char**c_type, int quiet)
{
      ivl_variable_type_t ptype = ivl_signal_data_type(port);
      unsigned pwid = ivl_signal_width(port);
      int is_signed = ivl_signal_signed(port);
      ivl_type_t net_type = ivl_signal_net_type(port);
      int is_return = ivl_scope_type(scope) == IVL_SCT_FUNCTION
		   && ivl_scope_ports(scope) > 0
		   && port == ivl_scope_port(scope, 0);

      if (ivl_signal_dimensions(port) > 0) {
	    if (is_return)
		  goto unsupported;
	    if (ptype == IVL_VT_REAL) {
		  int is_shortreal = ivl_type_is_shortreal(net_type);
		  *sig_letter = is_shortreal ? 'Q' : 'R';
		  *c_type = is_shortreal ? "float" : "double";
		  return 1;
	    }
	    if (ptype == IVL_VT_LOGIC || ptype == IVL_VT_BOOL) {
		  if (ivl_type_is_packed_vector(net_type)) {
			*sig_letter = ptype == IVL_VT_BOOL ? 'X' : 'Y';
			*c_type = ptype == IVL_VT_BOOL
			      ? "svBitVecVal" : "svLogicVecVal";
			return 1;
		  }
		  if (pwid == 1) {
			*sig_letter = ptype == IVL_VT_BOOL ? 'B' : 'G';
			*c_type = ptype == IVL_VT_BOOL ? "svBit" : "svLogic";
			return 1;
		  }
		  if (pwid == 8 || pwid == 16 || pwid == 32 || pwid == 64) {
			*sig_letter = 'O';
			switch (pwid) {
			    case 8:  *c_type = is_signed ? "char" : "unsigned char"; break;
			    case 16: *c_type = is_signed ? "short int" : "unsigned short int"; break;
			    case 32: *c_type = is_signed ? "int" : "unsigned int"; break;
			    default: *c_type = is_signed ? "long long int" : "unsigned long long int"; break;
			}
			return 1;
		  }
	    }
	    if (!quiet) {
		  fprintf(stderr, "%s:%u: sorry: export \"DPI-C\" '%s': fixed "
			  "unpacked array argument '%s' has an element type not "
			  "supported for DPI export; the export is dropped.\n",
			  ivl_scope_def_file(scope), ivl_scope_def_lineno(scope),
			  c_name, ivl_signal_basename(port));
	    }
	    return 0;
      }

      if (ptype == IVL_VT_REAL) {
	    int is_shortreal = ivl_type_is_shortreal(net_type);
	    *sig_letter = is_shortreal ? 'f' : 'r';
	    *c_type = is_shortreal ? "float" : "double";
	    return 1;
      }
      if (ptype == IVL_VT_STRING) {
	    *sig_letter = 's';
	    *c_type = "const char*";
	    return 1;
      }
      if ((ptype == IVL_VT_LOGIC || ptype == IVL_VT_BOOL)
          && ivl_type_is_chandle(net_type)) {
	    *sig_letter = 'p';
	    *c_type = "void*";
	    return 1;
      }
      if ((ptype == IVL_VT_LOGIC || ptype == IVL_VT_BOOL)
	  && ivl_type_is_packed_vector(net_type)) {
	    if (is_return)
		  goto unsupported;
	    *sig_letter = ptype == IVL_VT_BOOL ? 'V' : 'W';
	    *c_type = ptype == IVL_VT_BOOL
		  ? "svBitVecVal" : "svLogicVecVal";
	    return 1;
      }
      if ((ptype == IVL_VT_LOGIC || ptype == IVL_VT_BOOL) && pwid == 1) {
	    *sig_letter = ptype == IVL_VT_BOOL
		  ? (is_return ? 'B' : 't') : 'g';
	    *c_type = ptype == IVL_VT_BOOL ? "svBit" : "svLogic";
	    return 1;
      }
      if ((ptype == IVL_VT_LOGIC || ptype == IVL_VT_BOOL)
	  && (pwid == 8 || pwid == 16 || pwid == 32 || pwid == 64)) {
	    *sig_letter = is_signed ? 'I' : 'i';
	    switch (pwid) {
		case 8:  *c_type = is_signed ? "char"          : "unsigned char";      break;
		case 16: *c_type = is_signed ? "short int"     : "unsigned short int"; break;
		case 32: *c_type = is_signed ? "int"           : "unsigned int";       break;
		default: *c_type = is_signed ? "long long int" : "unsigned long long int"; break;
	    }
	    return 1;
      }
unsupported:
      if (!quiet)
	    fprintf(stderr, "%s:%u: sorry: export \"DPI-C\" '%s': %s '%s' has a "
		    "type not supported for export (integer atoms, scalar bit/logic, "
		    "chandle, strings, shortreal, and real are supported; packed "
		    "bit/logic vectors are supported only as formals, not results). "
		    "The export is dropped; calls from C will not link.\n",
		    ivl_scope_def_file(scope), ivl_scope_def_lineno(scope), c_name,
		    (port == ivl_scope_port(scope, 0)
		     && ivl_scope_type(scope) == IVL_SCT_FUNCTION)
		    ? "return" : "argument",
		    ivl_signal_basename(port));
      return 0;
}

/* Build the return/arg signatures and validate. Returns 1 if the whole
   export is supported. Fills ret_sig (single letter; 'v' remains the
   bytecode signature for both a task and a void function so existing
   :export_dpi images stay compatible),
   arg_sig (TYPE,DIRECTION pairs per argument; direction is i/o/b for
   input/output/inout), and c-type spellings for the stub. */
static int dpi_export_build_sig(ivl_scope_t scope, const char*c_name,
				int is_task, char*ret_sig,
				const char**ret_ctype, char*arg_sig,
				const char**arg_ctypes, unsigned max_args,
				unsigned*nargs_out, int quiet)
{
      unsigned nports = ivl_scope_ports(scope);
      unsigned first = is_task ? 0 : 1;
      unsigned nargs = (nports >= first) ? (nports - first) : 0;
      unsigned idx;

      if (nargs > max_args) {
	    if (!quiet)
		  fprintf(stderr, "%s:%u: sorry: export \"DPI-C\" '%s' has %u "
			  "arguments; more than %u are not supported.\n",
			  ivl_scope_def_file(scope), ivl_scope_def_lineno(scope),
			  c_name, nargs, max_args);
	    return 0;
      }

      if (is_task) {
	    *ret_sig = 'v';
	      /* IEEE 1800-2017/2023 H.8.2: an exported task is represented
		 as an int-returning C function. The value is the 35.9(a)
		 disable status, not a SystemVerilog task result. */
	    *ret_ctype = "int";
      } else {
	    ivl_signal_t rport = ivl_scope_port(scope, 0);
	    if (ivl_scope_func_type(scope) == IVL_VT_VOID) {
		  *ret_sig = 'v';
		  *ret_ctype = "void";
	    } else if (!dpi_export_classify(scope, rport, c_name,
					    ret_sig, ret_ctype, quiet)) {
		  return 0;
	    }
      }

      for (idx = 0 ; idx < nargs ; idx += 1) {
	    ivl_signal_t port = ivl_scope_port(scope, first + idx);
	    if (!dpi_export_classify(scope, port, c_name,
				     &arg_sig[2*idx], &arg_ctypes[idx], quiet))
		  return 0;
	    switch (ivl_signal_port(port)) {
		case IVL_SIP_INPUT:  arg_sig[2*idx+1] = 'i'; break;
		case IVL_SIP_OUTPUT: arg_sig[2*idx+1] = 'o'; break;
		case IVL_SIP_INOUT:  arg_sig[2*idx+1] = 'b'; break;
		default:
		  if (!quiet)
			fprintf(stderr, "%s:%u: sorry: export \"DPI-C\" '%s': "
				"argument '%s' has no DPI direction. The export "
				"is dropped.\n", ivl_scope_def_file(scope),
				ivl_scope_def_lineno(scope), c_name,
				ivl_signal_basename(port));
		  return 0;
	    }
      }
      arg_sig[2*nargs] = 0;
      *nargs_out = nargs;
      return 1;
}

struct dpi_export_abi_s {
      int is_task;
      char ret_sig;
      const char*ret_ctype;
      char arg_sig[129];
      const char*arg_ctypes[64];
      unsigned nargs;
};

static int dpi_export_get_abi(ivl_scope_t scope, const char*c_name,
                              struct dpi_export_abi_s*abi, int quiet)
{
      abi->is_task = ivl_scope_type(scope) == IVL_SCT_TASK;
      abi->ret_sig = 'v';
      abi->ret_ctype = "void";
      abi->nargs = 0;
      return dpi_export_build_sig(scope, c_name, abi->is_task,
                                  &abi->ret_sig, &abi->ret_ctype,
                                  abi->arg_sig, abi->arg_ctypes, 64,
                                  &abi->nargs, quiet);
}

static int dpi_export_abis_equal(ivl_scope_t a_scope,
                                 const struct dpi_export_abi_s*a,
                                 ivl_scope_t b_scope,
                                 const struct dpi_export_abi_s*b)
{
      unsigned idx;
      if (a->is_task != b->is_task || a->ret_sig != b->ret_sig
          || strcmp(a->ret_ctype, b->ret_ctype) != 0
          || a->nargs != b->nargs
          || strcmp(a->arg_sig, b->arg_sig) != 0)
            return 0;

      for (idx = 0 ; idx < a->nargs ; idx += 1) {
            ivl_signal_t a_port;
            ivl_signal_t b_port;
            unsigned a_first = a->is_task ? 0 : 1;
            unsigned b_first = b->is_task ? 0 : 1;
            unsigned dim;

            if (strcmp(a->arg_ctypes[idx], b->arg_ctypes[idx]) != 0)
                  return 0;

              /* V/W use the same C pointer spelling for every packed
                 vector. Their declared packed dimensions and bounds are
                 nevertheless part of the DPI type signature and control
                 how the selected SV instance interprets that storage. */
            char letter = a->arg_sig[2*idx];
            int array = letter == 'O' || letter == 'Q' || letter == 'R'
		 || letter == 'B' || letter == 'G'
		 || letter == 'X' || letter == 'Y';
            if (!array && letter != 'V' && letter != 'W')
                  continue;
            a_port = ivl_scope_port(a_scope, a_first + idx);
            b_port = ivl_scope_port(b_scope, b_first + idx);
            if (ivl_signal_signed(a_port) != ivl_signal_signed(b_port)
                || ivl_signal_width(a_port) != ivl_signal_width(b_port)
                || ivl_signal_dimensions(a_port)
                   != ivl_signal_dimensions(b_port)
                || ivl_signal_packed_dimensions(a_port)
                   != ivl_signal_packed_dimensions(b_port))
                  return 0;
            for (dim = 0 ; dim < ivl_signal_dimensions(a_port) ; dim += 1)
                  if (ivl_signal_array_dim_msb(a_port, dim)
                        != ivl_signal_array_dim_msb(b_port, dim)
                      || ivl_signal_array_dim_lsb(a_port, dim)
                        != ivl_signal_array_dim_lsb(b_port, dim))
                        return 0;
            for (dim = 0 ; dim < ivl_signal_packed_dimensions(a_port) ;
                 dim += 1)
                  if (ivl_signal_packed_msb(a_port, dim)
                        != ivl_signal_packed_msb(b_port, dim)
                      || ivl_signal_packed_lsb(a_port, dim)
                        != ivl_signal_packed_lsb(b_port, dim))
                        return 0;
      }
      return 1;
}

/* Multiple instances may legally register the same exported C name, but
   every registration must describe the same C entry point. In particular,
   an exported task and a void function both use the historical 'v' runtime
   return signature while requiring incompatible Annex H C return types
   (int versus void). Never let list order silently select that ABI. */
static void validate_dpi_export_abis(void)
{
      struct dpi_export_entry_s*base;
      for (base = dpi_exports ; base ; base = base->next) {
            const char*c_name = ivl_scope_dpi_export_c_name(base->scope);
            struct dpi_export_abi_s base_abi;
            struct dpi_export_entry_s*scan;
            int has_previous = 0;

            if (!dpi_export_get_abi(base->scope, c_name, &base_abi, 1))
                  continue;

              /* Only the first supported declaration for a C name reports
                 a conflict. Unsupported declarations are diagnosed by the
                 normal emission pass and must not hide a later valid one. */
            for (scan = dpi_exports ; scan != base ; scan = scan->next) {
                  struct dpi_export_abi_s scan_abi;
                  if (strcmp(ivl_scope_dpi_export_c_name(scan->scope),
                             c_name) == 0
                      && dpi_export_get_abi(scan->scope, c_name,
                                            &scan_abi, 1)) {
                        has_previous = 1;
                        break;
                  }
            }
            if (has_previous)
                  continue;

            for (scan = base->next ; scan ; scan = scan->next) {
                  struct dpi_export_abi_s scan_abi;
                  if (strcmp(ivl_scope_dpi_export_c_name(scan->scope),
                             c_name) != 0
                      || !dpi_export_get_abi(scan->scope, c_name,
                                             &scan_abi, 1))
                        continue;
                  if (dpi_export_abis_equal(base->scope, &base_abi,
                                            scan->scope, &scan_abi))
                        continue;

                  fprintf(stderr, "%s:%u: error: export \"DPI-C\" C name "
                          "'%s' has incompatible declarations; the "
                          "declaration at %s:%u uses a different "
                          "task/function kind or C ABI. Exports sharing a "
                          "C name must have identical Annex H signatures.\n",
                          ivl_scope_def_file(scan->scope),
                          ivl_scope_def_lineno(scan->scope), c_name,
                          ivl_scope_def_file(base->scope),
                          ivl_scope_def_lineno(base->scope));
                  vvp_errors += 1;

                  for (scan = dpi_exports ; scan ; scan = scan->next) {
                        struct dpi_export_abi_s ignored;
                        if (strcmp(ivl_scope_dpi_export_c_name(scan->scope),
                                   c_name) == 0
                            && dpi_export_get_abi(scan->scope, c_name,
                                                  &ignored, 1))
                              scan->abi_conflict = 1;
                  }
                  break;
            }
      }
}

void emit_dpi_export_directives(void)
{
      struct dpi_export_entry_s*ent;
      validate_dpi_export_abis();
      for (ent = dpi_exports ; ent ; ent = ent->next) {
	    ivl_scope_t scope = ent->scope;
	    int is_task = ivl_scope_type(scope) == IVL_SCT_TASK;
	    const char*c_name = ivl_scope_dpi_export_c_name(scope);
	    char ret_sig = 'v';
	    const char*ret_ctype = "void";
	    char arg_sig[129];
	    const char*arg_ctypes[64];
	    unsigned nargs = 0;
	    unsigned idx;

	      /* The diagnostic above says the export is dropped, so C callers
		 cannot link; that loss must fail code generation. */
	    if (!dpi_export_build_sig(scope, c_name, is_task, &ret_sig,
				      &ret_ctype, arg_sig, arg_ctypes,
				      64, &nargs, 0)) {
		  vvp_errors += 1;
		  continue;
	    }
	    if (ent->abi_conflict)
		  continue;

	    const char*td = vvp_mangle_id(ivl_scope_name(scope));

	      /* :export_dpi "cname" "TD_label" "retsig" "argsig"
			     "retnet" "argnet0 argnet1 ..." ;
	       A function's return value is delivered through the caller's
	       stack (the %ret protocol), not a persistent net, so the return
	       operand is always empty; it is retained for directive-format
	       stability. */
	    fprintf(vvp_out, ":export_dpi \"%s\" \"TD_%s\" \"%c\" \"%s\" \"\" ",
		    c_name, td, ret_sig, arg_sig);

	      /* Space-separated argument net labels. */
	    fprintf(vvp_out, "\"");
	    unsigned first = is_task ? 0 : 1;
	    for (idx = 0 ; idx < nargs ; idx += 1) {
		  ivl_signal_t port = ivl_scope_port(scope, first + idx);
		  fprintf(vvp_out, "%sv%p%s", idx ? " " : "", (void*)port,
			  ivl_signal_dimensions(port) ? "" : "_0");
	    }
	    fprintf(vvp_out, "\";\n");
      }
}

void emit_dpi_export_stub_file(const char*vvp_path)
{
      if (dpi_exports == 0)
	    return;

	/* Derive <out>.dpiexport.c next to the vvp output. */
      size_t plen = strlen(vvp_path);
      char*cpath = malloc(plen + 16);
      strcpy(cpath, vvp_path);
	/* Drop a trailing .vvp if present, else just append. */
      if (plen > 4 && strcmp(cpath + plen - 4, ".vvp") == 0)
	    cpath[plen - 4] = 0;
      strcat(cpath, ".dpiexport.c");

      FILE*out = fopen(cpath, "w");
      if (out == 0) {
	    fprintf(stderr, "error: cannot open DPI export stub file %s: ",
		    cpath);
	    perror(0);
	    free(cpath);
	    vvp_errors += 1;
	    return;
      }

      fprintf(out,
	      "/* Automatically generated by iverilog for DPI export\n"
	      " * (IEEE 1800-2017 35.5). Compile this file into your DPI\n"
	      " * shared object so calls from C resolve to the exported SV\n"
	      " * subroutines, e.g.:\n"
	      " *   gcc -shared -fPIC -o my_dpi.so my_dpi.c %s\n"
	      " * The dispatcher __ivl_dpi_export_call_* is provided by vvp\n"
	      " * and resolved via RTLD_GLOBAL at run time. */\n\n",
	      cpath);
      fprintf(out,
	      "#include <stdint.h>\n\n"
	      "typedef unsigned char svBit;\n"
	      "typedef unsigned char svLogic;\n"
	      "typedef uint32_t svBitVecVal;\n"
	      "typedef struct { uint32_t aval, bval; } svLogicVecVal;\n\n"
	      "typedef union ivl_dpi_arg_u {\n"
	      "      int64_t     i;\n"
	      "      double      r;\n"
	      "      const char* s;\n"
	      "      void*       p;\n"
	      "      uint32_t*   v;\n"
	      "      void*       a;\n"
	      "} ivl_dpi_arg_t;\n\n"
	      "extern int64_t     __ivl_dpi_export_call_i(const char*cname, int nargs, ivl_dpi_arg_t*args);\n"
	      "extern double      __ivl_dpi_export_call_r(const char*cname, int nargs, ivl_dpi_arg_t*args);\n"
	      "extern const char* __ivl_dpi_export_call_s(const char*cname, int nargs, ivl_dpi_arg_t*args);\n"
	      "extern void        __ivl_dpi_export_call_v(const char*cname, int nargs, ivl_dpi_arg_t*args);\n\n");

      struct dpi_export_entry_s*ent;
      for (ent = dpi_exports ; ent ; ent = ent->next) {
	    ivl_scope_t scope = ent->scope;
	    int is_task = ivl_scope_type(scope) == IVL_SCT_TASK;
	    const char*c_name = ivl_scope_dpi_export_c_name(scope);
	    char ret_sig = 'v';
	    const char*ret_ctype = "void";
	    char arg_sig[129];
	    const char*arg_ctypes[64];
	    unsigned nargs = 0;
	    unsigned idx;

	    if (!dpi_export_build_sig(scope, c_name, is_task, &ret_sig,
				      &ret_ctype, arg_sig, arg_ctypes,
				      64, &nargs, 1))
		  continue;
	    if (ent->abi_conflict)
		  continue;

	      /* One C stub per exported C name: a multiply-instantiated
		 module registers one export entry per instance, but the C
		 entry point is instance-agnostic (the runtime selects the
		 instance by svScope). Skip a supported name already emitted.
		 An unsupported earlier declaration must not hide this one. */
	    int already = 0;
	    struct dpi_export_entry_s*prev;
	    for (prev = dpi_exports ; prev != ent ; prev = prev->next) {
		  struct dpi_export_abi_s prev_abi;
		  if (!prev->abi_conflict
		      && strcmp(ivl_scope_dpi_export_c_name(prev->scope),
			        c_name) == 0
		      && dpi_export_get_abi(prev->scope, c_name,
					&prev_abi, 1)) {
			already = 1;
			break;
		  }
	    }
	    if (already)
		  continue;

	      /* Prototype line. */
	    fprintf(out, "%s %s(", ret_ctype, c_name);
	    if (nargs == 0) {
		  fprintf(out, "void");
	    } else {
		  for (idx = 0 ; idx < nargs ; idx += 1) {
		  char typ = arg_sig[2*idx];
		  char dir = arg_sig[2*idx+1];
		  int packed = typ == 'V' || typ == 'W';
		  int array = typ == 'O' || typ == 'Q' || typ == 'R'
			   || typ == 'B' || typ == 'G' || typ == 'X' || typ == 'Y';
		  fprintf(out, "%s%s%s%s a%u", idx ? ", " : "",
			  ((packed || array) && dir == 'i') ? "const " : "",
			  arg_ctypes[idx],
			  (packed || array || dir != 'i') ? "*" : "", idx);
		  }
	    }
	    fprintf(out, ")\n{\n");

	      /* Pack the arguments. */
	    if (nargs > 0)
		  fprintf(out, "      ivl_dpi_arg_t _a[%u];\n", nargs);
	    for (idx = 0 ; idx < nargs ; idx += 1) {
		  char typ = arg_sig[2*idx];
		  char dir = arg_sig[2*idx+1];
		  if (typ == 'V' || typ == 'W')
			fprintf(out, "      _a[%u].v = (uint32_t*)a%u;\n",
				idx, idx);
		  else if (typ == 'O' || typ == 'Q' || typ == 'R'
			   || typ == 'B' || typ == 'G' || typ == 'X' || typ == 'Y')
			fprintf(out, "      _a[%u].a = (void*)a%u;\n", idx, idx);
		  else if (typ == 'f' || typ == 'r') {
			if (dir == 'i')
			      fprintf(out, "      _a[%u].r = (double)a%u;\n",
				      idx, idx);
			else if (dir == 'b')
			      fprintf(out, "      _a[%u].r = a%u ? (double)*a%u : 0.0;\n",
				      idx, idx, idx);
			else
			      fprintf(out, "      _a[%u].r = 0.0;\n", idx);
		  } else if (typ == 'p') {
			if (dir == 'i')
			      fprintf(out, "      _a[%u].p = a%u;\n", idx, idx);
			else if (dir == 'b')
			      fprintf(out, "      _a[%u].p = a%u ? *a%u : 0;\n",
				      idx, idx, idx);
			else
			      fprintf(out, "      _a[%u].p = 0;\n", idx);
		  }
		  else if (typ == 's') {
			if (dir == 'i')
			      fprintf(out, "      _a[%u].s = a%u ? a%u : 0;\n",
				      idx, idx, idx);
			else if (dir == 'b')
			      fprintf(out, "      _a[%u].s = a%u ? *a%u : 0;\n",
				      idx, idx, idx);
			else
			      fprintf(out, "      _a[%u].s = 0;\n", idx);
		  }
		  else if (dir == 'i')
			fprintf(out, "      _a[%u].i = (int64_t)a%u;\n",
				idx, idx);
		  else if (dir == 'b')
			fprintf(out, "      _a[%u].i = a%u ? (int64_t)*a%u : 0;\n",
				idx, idx, idx);
		  else
			fprintf(out, "      _a[%u].i = 0;\n", idx);
	    }

	    const char*argptr = nargs ? "_a" : "0";
	    if (is_task) {
		  /* Reuse the integer dispatcher: for a ret_sig='v' task it
		     returns the 35.9(a) status (0 normal, 1 disabled). */
		  fprintf(out, "      int _rv = (int)__ivl_dpi_export_call_i(\"%s\", %u, %s);\n",
			  c_name, nargs, argptr);
	    } else switch (ret_sig) {
		case 'v':
		  fprintf(out, "      __ivl_dpi_export_call_v(\"%s\", %u, %s);\n",
			  c_name, nargs, argptr);
		  break;
		case 'f':
		case 'r':
		  fprintf(out, "      %s _rv = (%s)__ivl_dpi_export_call_r(\"%s\", %u, %s);\n",
			  ret_ctype,
			  ret_ctype, c_name, nargs, argptr);
		  break;
		case 's':
		  fprintf(out, "      const char* _rv = __ivl_dpi_export_call_s(\"%s\", %u, %s);\n",
			  c_name, nargs, argptr);
		  break;
		case 'p':
		  fprintf(out, "      void* _rv = (void*)(uintptr_t)__ivl_dpi_export_call_i(\"%s\", %u, %s);\n",
			  c_name, nargs, argptr);
		  break;
		default: /* integer atom or scalar bit/logic */
		  fprintf(out, "      %s _rv = (%s)__ivl_dpi_export_call_i(\"%s\", %u, %s);\n",
			  ret_ctype,
			  ret_ctype, c_name, nargs, argptr);
		  break;
	    }
	    for (idx = 0 ; idx < nargs ; idx += 1) {
	      char typ = arg_sig[2*idx];
	      char dir = arg_sig[2*idx+1];
	      int array = typ == 'O' || typ == 'Q' || typ == 'R'
		   || typ == 'B' || typ == 'G' || typ == 'X' || typ == 'Y';
	      if (dir == 'i' || array || typ == 'V' || typ == 'W') continue;
		  if (typ == 'f' || typ == 'r')
			fprintf(out, "      if (a%u) *a%u = (%s)_a[%u].r;\n",
				idx, idx, arg_ctypes[idx], idx);
		  else if (typ == 'p')
			fprintf(out, "      if (a%u) *a%u = _a[%u].p;\n",
				idx, idx, idx);
		  else if (typ == 's')
			fprintf(out, "      if (a%u) *a%u = _a[%u].s;\n",
				idx, idx, idx);
		  else
			fprintf(out, "      if (a%u) *a%u = (%s)_a[%u].i;\n",
				idx, idx, arg_ctypes[idx], idx);
	    }
	    if (is_task || ret_sig != 'v')
		  fprintf(out, "      return _rv;\n");
	    fprintf(out, "}\n\n");
      }

      fclose(out);
      fprintf(stderr, "iverilog: note: wrote DPI export C stubs to %s "
	      "(compile it into your DPI object).\n", cpath);
      free(cpath);
}
