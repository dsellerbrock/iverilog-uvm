/*
 * Copyright (c) 2005-2016 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "vvp_priv.h"
# include  <string.h>
# include  <stdlib.h>
# include  <assert.h>

static void function_argument_logic(ivl_signal_t port, ivl_expr_t expr)
{
      unsigned ewidth, pwidth;

	/* ports cannot be arrays. */
      assert(ivl_signal_dimensions(port) == 0);

      ewidth = ivl_expr_width(expr);
      pwidth = ivl_signal_width(port);

      draw_eval_vec4(expr);
      if (ewidth < pwidth)
	    fprintf(vvp_out, "    %%pad/u %u;\n", pwidth);

}

static void function_argument_real(ivl_signal_t port, ivl_expr_t expr)
{
	/* ports cannot be arrays. */
      assert(ivl_signal_dimensions(port) == 0);

      draw_eval_real(expr);
}

static int port_is_unsupported_aggregate_formal_(ivl_signal_t port)
{
      ivl_type_t net_type;

      if (!port)
            return 0;

      if (ivl_signal_data_type(port) != IVL_VT_NO_TYPE)
            return 0;

      net_type = ivl_signal_net_type(port);
      if (net_type && ivl_type_properties(net_type) > 0)
            return 0;

      {
	    unsigned wid = ivl_signal_width(port);
	    return (wid == 0) || (wid == ~0U);
      }
}

/* True when a `ref' actual can be named directly by %ref/bind: a whole
   variable, not a word of an array or a part of one. */
static int ref_actual_is_nameable_(ivl_expr_t expr)
{
      if (!expr) return 0;
      if (ivl_expr_type(expr) != IVL_EX_SIGNAL) return 0;
      if (ivl_expr_oper1(expr)) return 0;          /* word select */
      if (!ivl_expr_signal(expr)) return 0;
      if (ivl_signal_dimensions(ivl_expr_signal(expr)) > 0) return 0;
      return 1;
}

static int ref_actual_is_static_array_word_(ivl_signal_t port,
                                            ivl_expr_t expr)
{
      if (!port || !ivl_signal_ref_static(port) || !expr
	  || ivl_expr_type(expr) != IVL_EX_SIGNAL)
	    return 0;
      ivl_signal_t sig = ivl_expr_signal(expr);
      return sig && ivl_signal_dimensions(sig) > 0
	  && ivl_expr_oper1(expr);
}

/* True when a `ref' actual is a whole class property of a type the runtime can
   bind as a true reference (%ref/bind/pr, IEEE 1800-2017/2023 13.5.2): the
   callee then sees and makes every write at once, so a write to the property
   by its own name inside the call is not undone by a stale copy-out. */
static int ref_actual_is_bound_property_(ivl_signal_t port, ivl_expr_t expr)
{
      if (!expr || ivl_expr_type(expr) != IVL_EX_PROPERTY) return 0;
      if (ivl_expr_oper1(expr)) return 0;                 /* element of it */
      if (!ivl_expr_signal(expr) && !ivl_expr_oper2(expr)) return 0;
      switch (ivl_signal_data_type(port)) {
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	  case IVL_VT_REAL:
	  case IVL_VT_STRING:
	  case IVL_VT_CLASS:
	    return 1;
	  default:
	    return 0;
      }
}

static int function_port_is_native_output_(ivl_signal_t port)
{
      ivl_type_t type;

      if (!port || ivl_signal_port(port) != IVL_SIP_OUTPUT)
	    return 0;

	/* A DPI open array is a handle onto the caller's existing storage, even
	 * when its direction is output (IEEE 1800-2017/2023 35.5.6.1). Its size
	 * and backing object must therefore be sent to C; treating it as an
	 * ordinary copy-out-only dynamic-array value replaces the handle with a
	 * null static formal and makes every output open array appear empty. */
      if (ivl_scope_is_dpi_import(ivl_signal_scope(port)))
	    return 0;

	/* A native fixed-array output is copy-out only just like a native
	 * dynamic array or queue. Its automatic frame storage is already
	 * default-initialized; a static function's storage deliberately retains
	 * its prior value (IEEE 1800-2017/2023 13.4.2, 13.5). */
      if (ivl_signal_dimensions(port) > 0)
	    return 1;

      type = ivl_signal_net_type(port);
      return type && (ivl_type_base(type) == IVL_VT_DARRAY
	  || ivl_type_base(type) == IVL_VT_QUEUE
	  || ivl_type_base(type) == IVL_VT_BOOL
	  || ivl_type_base(type) == IVL_VT_LOGIC
	  || ivl_type_base(type) == IVL_VT_REAL
	  || ivl_type_base(type) == IVL_VT_STRING
	  || ivl_type_base(type) == IVL_VT_CLASS);
}

/* Bind one `ref' formal (IEEE 1800-2017 13.5.2). An actual that cannot
   be named is copied into the formal's per-frame companion word, which
   is what the formal is then bound to; draw_copy_out_function_arguments
   copies it back through the same binding. */
static void draw_bind_function_ref_argument(ivl_signal_t port, ivl_expr_t expr)
{
      if (ref_actual_is_static_array_word_(port, expr)) {
	    draw_eval_vec4(ivl_expr_oper1(expr));
	    fprintf(vvp_out, "    %%ref/bind/w v%p, v%p_0;\n",
		    ivl_expr_signal(expr), port);
	    return;
      }
      if (ref_actual_is_nameable_(expr)) {
	    fprintf(vvp_out, "    %%ref/bind v%p_0, v%p_0;\n",
		    port, ivl_expr_signal(expr));
	    return;
      }
      if (ref_actual_is_bound_property_(port, expr)) {
	    ivl_expr_t base_expr = ivl_expr_oper2(expr);
	    if (base_expr)
		  draw_eval_object(base_expr);
	    else
		  fprintf(vvp_out, "    %%load/obj v%p_0;\n", ivl_expr_signal(expr));
	    fprintf(vvp_out, "    %%ref/bind/pr v%p_0, %d;\n",
		    port, ivl_expr_property_idx(expr));
	    return;
      }

	/* The companion of a class-handle formal is an object variable (see
	   vvp_scope.c); the handle is copied in as an object, never as the
	   vector image of its null test. */
      if (ivl_signal_data_type(port) == IVL_VT_CLASS) {
	    draw_eval_object(expr);
	    fprintf(vvp_out, "    %%store/obj v%p_R;\n", port);
      } else {
	    draw_eval_vec4(expr);
	    fprintf(vvp_out, "    %%store/vec4 v%p_R, 0, %u;\n",
		    port, ivl_signal_width(port));
      }
      fprintf(vvp_out, "    %%ref/bind/f v%p_0, v%p_R;\n", port, port);
}

static void draw_eval_function_argument(ivl_signal_t port, ivl_expr_t expr)
{
      static int warned_unsupported_arg_type = 0;
      static int warned_aggregate_arg_skip = 0;
      ivl_variable_type_t dtype = ivl_signal_data_type(port);
      ivl_type_t port_type = ivl_signal_net_type(port);

	/* A ref formal is bound, not copied. The bind is emitted in its
	   own pass (it must land after every argument has been
	   evaluated, since evaluating one may call another function). */
      if (ivl_signal_port(port) == IVL_SIP_REF)
	    return;

	/* An output argument is copy-out only (IEEE 1800-2017/2023 13.5).
	 * Evaluating the caller here would copy in a value that is not an input and
	 * would evaluate an indexed actual twice. Automatic scalar storage receives
	 * its default from context allocation/reset; the send pass initializes
	 * containers. Static output storage retains its value. */
      if (function_port_is_native_output_(port))
	    return;

	/* An unpacked fixed-array formal can retain its element data type
	 * (notably an implicitly typed `input a[3:0]') while still having
	 * signal dimensions. It is passed through the same temporary open-array
	 * object used by explicitly typed fixed-array formals. Treating it as a
	 * scalar reaches function_argument_logic's no-dimensions invariant and
	 * aborts the target. */
      if (ivl_signal_dimensions(port) > 0) {
	    vvp_errors += draw_eval_object(expr);
	    return;
      }
      if (port_is_unsupported_aggregate_formal_(port)) {
	    if (!warned_aggregate_arg_skip) {
		  fprintf(stderr,
		          "Warning: Skipping unsupported aggregate function argument %s"
		          " (further similar warnings suppressed)\n",
		          ivl_signal_basename(port));
		  warned_aggregate_arg_skip = 1;
	    }
	    return;
      }

      switch (dtype) {
	  case IVL_VT_BOOL:
	      /* For now, treat bit2 variables as bit4 variables. */
	  case IVL_VT_LOGIC:
	    function_argument_logic(port, expr);
	    break;
	  case IVL_VT_REAL:
	    function_argument_real(port, expr);
	    break;
	  case IVL_VT_CLASS:
	    vvp_errors += draw_eval_object(expr);
	    break;
	  case IVL_VT_STRING:
	    draw_eval_string(expr);
	    break;
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	    vvp_errors += draw_eval_object(expr);
	    draw_convert_container_value_for_target(
		  receiver_container_type_(expr), port_type);
	    break;
	  case IVL_VT_NO_TYPE:
	    vvp_errors += draw_eval_object(expr);
	    break;
	  default:
	    if (!warned_unsupported_arg_type) {
		  fprintf(stderr, "Warning: Unsupported function argument type %d for %s; treating as object"
			  " (further similar warnings suppressed)\n",
			  dtype, ivl_signal_basename(port));
		  warned_unsupported_arg_type = 1;
	    }
	    vvp_errors += draw_eval_object(expr);
	    break;
      }
}

static int fixed_array_open_actual_(ivl_signal_t port, ivl_expr_t expr)
{
      return port && ivl_scope_is_dpi_import(ivl_signal_scope(port))
	  && vvp_expr_is_fixed_uarray_value(expr);
}

static void draw_send_function_argument(ivl_signal_t port, ivl_expr_t actual)
{
      static int warned_unsupported_send_type = 0;
      static int warned_aggregate_send_skip = 0;
      ivl_variable_type_t dtype = ivl_signal_data_type(port);

      if (ivl_signal_port(port) == IVL_SIP_REF)
	    return;

	/* IEEE 1800-2017/2023 13.4.2 gives static functions persistent formal
	 * storage. Do not reset a static output between calls. Automatic output
	 * storage is initialized on each entry; materialize its declared container
	 * default here because the ordinary argument stack has no copy-in value. */
      if (function_port_is_native_output_(port)) {
	    ivl_type_t port_type = ivl_signal_net_type(port);

	    if (ivl_signal_dimensions(port) > 0)
		  return;

	    if (!ivl_scope_is_auto(ivl_signal_scope(port)))
		  return;

	    /* Scalar automatic storage is initialized by the existing context
	       alloc/reset hooks. Do not overwrite it with the caller's value. */
	    if (dtype != IVL_VT_DARRAY && dtype != IVL_VT_QUEUE)
		  return;

	    if (ivl_type_base(port_type) == IVL_VT_QUEUE
		&& !ivl_type_queue_assoc_compat(port_type)) {
		  ivl_type_t element_type = ivl_type_element(port_type);
		  char element_text[32];
		  stream_elem_type_text(element_type, element_text,
					sizeof element_text);
		  fprintf(vvp_out,
			  "    %%new/queue \"%s\"; default value for output queue\n",
			  element_text);
		  if (element_type
		      && ivl_type_base(element_type) == IVL_VT_NO_TYPE
		      && ivl_type_properties(element_type) > 0) {
			ensure_class_type_emitted(element_type);
			fprintf(vvp_out,
				"    %%new/cobj C%p; output queue element prototype\n",
				element_type);
			fprintf(vvp_out, "    %%dar/elem/proto;\n");
		  }
	    } else {
		  fprintf(vvp_out,
			  "    %%null; ; default value for output container\n");
	    }
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", port);
	    return;
      }

      if (ivl_signal_dimensions(port) > 0) {
	    unsigned kind;
	    if (uarray_container_kind_(port, &kind,
				       ivl_signal_file(port),
				       ivl_signal_lineno(port)))
		  emit_store_arr_dar_(port, kind);
	    else
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    return;
      }

      if (port_is_unsupported_aggregate_formal_(port)) {
	    if (!warned_aggregate_send_skip) {
		  fprintf(stderr,
		          "Warning: Skipping unsupported aggregate function send %s"
		          " (further similar warnings suppressed)\n",
		          ivl_signal_basename(port));
		  warned_aggregate_send_skip = 1;
	    }
	    return;
      }

      switch (dtype) {
	  case IVL_VT_BOOL:
	      /* For now, treat bit2 variables as bit4 variables. */
	  case IVL_VT_LOGIC:
	    fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
				      port, ivl_signal_width(port));
	    break;
	  case IVL_VT_REAL:
	    fprintf(vvp_out, "    %%store/real v%p_0;\n", port);
	    break;
	  case IVL_VT_CLASS:
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", port);
	    break;
	  case IVL_VT_STRING:
	    fprintf(vvp_out, "    %%store/str v%p_0;\n", port);
	    break;
	  case IVL_VT_DARRAY:
	      /* IEEE 1800-2017 13.5.1: a non-`ref' argument is passed BY
		 VALUE, and a dynamic array or queue is a value container
		 (7.4, 7.5) -- not a handle like a class, which is a
		 reference and is deliberately left aliasing above.

		 The eval pass pushed the caller's container and this
		 stored it straight into the formal, so formal and actual
		 were the SAME object: a callee writing its own input
		 formal wrote through to the caller. `f(q)' with a callee
		 doing `m[0] = 32'hff' left the caller's q[0] at ff, at
		 exit 0 with no diagnostic.

		 Copy exactly the way plain assignment already does --
		 %dup/obj, %store/obj, %pop/obj. %dup/obj deep-copies
		 (of_DUP_OBJ calls src.duplicate(); the aliasing variant
		 is a separate opcode, %dup/obj/ref). The pop matters:
		 %store/obj pops ONE object, so storing the duplicate
		 would strand the original on the object stack and the
		 runtime's CLEANUP-leak check would fire.

		 A `ref' formal must alias and never gets here -- both
		 passes return early on IVL_SIP_REF. */
	    fprintf(vvp_out, "    %%dup/obj; pass by value (IEEE 13.5.1)\n");
	    fprintf(vvp_out, "    %%store/obj%s v%p_0;\n",
		    fixed_array_open_actual_(port, actual) ? "/open" : "", port);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    break;
	  case IVL_VT_QUEUE:
	    fprintf(vvp_out, "    %%dup/obj; pass by value (IEEE 13.5.1)\n");
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", port);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    break;
	  case IVL_VT_NO_TYPE:
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", port);
	    break;
	  default:
	    if (!warned_unsupported_send_type) {
		  fprintf(stderr, "Warning: Unsupported function send argument type %d for %s; treating as object"
			  " (further similar warnings suppressed)\n",
			  dtype, ivl_signal_basename(port));
		  warned_unsupported_send_type = 1;
	    }
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", port);
	    break;
      }
}

static void draw_copy_out_function_argument(ivl_signal_t port,
					     ivl_expr_t actual);

/* Marshal ordinary task/function arguments. Static subroutines retain the
 * historical evaluate-all/then-send ordering: changing it here would also
 * change void functions, DPI exports and output/ref paths that are outside
 * dynamic virtual-interface dispatch. Automatic subroutines have a private
 * frame and can install each argument immediately. */
static int draw_function_input_arguments_(ivl_scope_t scope,
                                          unsigned port_base,
                                          unsigned argc,
                                          ivl_expr_t const*argv,
                                          int allow_sparse,
					  int vif_copyback)
{
      unsigned idx;
      int errors = 0;

      if (!scope || (argc && !argv)
          || port_base > ivl_scope_ports(scope)
          || argc > ivl_scope_ports(scope) - port_base) {
            fprintf(stderr, "vvp.tgt error: malformed argument list for %s\n",
                    scope && ivl_scope_name(scope)
                          ? ivl_scope_name(scope) : "<unknown subroutine>");
            return 1;
      }

      for (idx = 0 ; idx < argc ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(scope, port_base + idx);
            if (!port || (!argv[idx] && !allow_sparse)) {
                  fprintf(stderr,
                          "vvp.tgt error: missing argument %u or formal port "
                          "for %s\n",
                          idx, ivl_scope_name(scope));
                  errors += 1;
            }
      }
      if (errors)
            return errors;

      if (ivl_scope_is_auto(scope)) {
            for (idx = 0 ; idx < argc ; idx += 1) {
                  ivl_signal_t port = ivl_scope_port(scope, port_base + idx);
	                  if (!argv[idx])
	                        continue;
	                  if (vif_copyback
			      && ivl_signal_port(port) == IVL_SIP_OUTPUT
			      && !function_port_is_native_output_(port))
				continue;
	                  if (ivl_signal_port(port) == IVL_SIP_REF) {
                        draw_bind_function_ref_argument(port, argv[idx]);
                  } else {
                        draw_eval_function_argument(port, argv[idx]);
                        draw_send_function_argument(port, argv[idx]);
                  }
            }
            return 0;
      }

      for (idx = 0 ; idx < argc ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(scope, port_base + idx);
	            if (!argv[idx])
	                  continue;
	            if (vif_copyback
			&& ivl_signal_port(port) == IVL_SIP_OUTPUT
			&& !function_port_is_native_output_(port))
			  continue;
	            draw_eval_function_argument(port, argv[idx]);
      }
      for (idx = argc ; idx > 0 ; idx -= 1) {
            ivl_signal_t port = ivl_scope_port(
                  scope, port_base + idx - 1);
	            if (!argv[idx - 1])
	                  continue;
	            if (vif_copyback
			&& ivl_signal_port(port) == IVL_SIP_OUTPUT
			&& !function_port_is_native_output_(port))
			  continue;
	            draw_send_function_argument(port, argv[idx - 1]);
      }
      for (idx = 0 ; idx < argc ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(scope, port_base + idx);
            if (!argv[idx])
                  continue;
            if (ivl_signal_port(port) == IVL_SIP_REF)
                  draw_bind_function_ref_argument(port, argv[idx]);
      }

      return 0;
}

int draw_function_input_arguments(ivl_scope_t scope, unsigned port_base,
                                  unsigned argc, ivl_expr_t const*argv)
{
      return draw_function_input_arguments_(
	    scope, port_base, argc, argv, 0, 0);
}

/* A statement-position virtual-interface call can retain a null input after
 * the frontend has issued a compile-progress warning. Keep that historical
 * sparse-input behavior local to statement rows. Pure scalar outputs are not
 * evaluated or copied in; automatic queue/darray outputs still run the
 * existing declaration-default initializer before the selected call. */
int draw_vif_statement_input_arguments(ivl_scope_t scope,
                                       unsigned port_base,
                                       unsigned argc,
                                       ivl_expr_t const*argv)
{
      return draw_function_input_arguments_(
	    scope, port_base, argc, argv, 1, 1);
}

static int formal_effectively_static_(ivl_scope_t scope, ivl_signal_t port)
{
      ivl_lifetime_t lifetime = ivl_signal_lifetime(port);
      return lifetime == IVL_VLT_STATIC
          || (lifetime == IVL_VLT_INHERITED && !ivl_scope_is_auto(scope));
}

static int static_function_setup_enabled_(ivl_scope_t scope)
{
      if (!scope || ivl_scope_type(scope) != IVL_SCT_FUNCTION)
            return 0;
      for (unsigned idx = 1 ; idx < ivl_scope_ports(scope) ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(scope, idx);
            if (port && ivl_signal_port(port) == IVL_SIP_INPUT
                && formal_effectively_static_(scope, port))
                  return 1;
      }
      return 0;
}

/* Begin one static function's argument-setup interval. The runtime stages a
 * private row until every actual/default has been evaluated, then commits it
 * immediately before %callf. This protocol is emitted only for
 * value-returning dynamic virtual-interface calls, whose frontend signature
 * is input-only. Recursion from the executing body retains IEEE 13.4.2
 * shared-static behavior. */
void draw_static_function_setup_begin(ivl_scope_t scope)
{
      if (!static_function_setup_enabled_(scope))
            return;

      fprintf(vvp_out, "    %%static/call/enter S_%p;\n", scope);
      for (unsigned idx = 1 ; idx < ivl_scope_ports(scope) ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(scope, idx);
            ivl_variable_type_t dtype;

            if (!port || ivl_signal_port(port) != IVL_SIP_INPUT
                || !formal_effectively_static_(scope, port))
                  continue;
            assert(ivl_signal_dimensions(port) == 0);
            dtype = ivl_signal_data_type(port);
            switch (dtype) {
                case IVL_VT_BOOL:
                case IVL_VT_LOGIC:
                  fprintf(vvp_out, "    %%static/save/vec4 v%p_0;\n", port);
                  break;
                case IVL_VT_REAL:
                  fprintf(vvp_out,
                          "    %%static/save/real v%p_0, v%p_0;\n",
                          port, port);
                  break;
                case IVL_VT_STRING:
                  fprintf(vvp_out, "    %%static/save/str v%p_0;\n", port);
                  break;
                case IVL_VT_CLASS:
                case IVL_VT_DARRAY:
                case IVL_VT_QUEUE:
                case IVL_VT_NO_TYPE:
                default:
                  fprintf(vvp_out, "    %%static/save/obj v%p_0;\n", port);
                  break;
            }
      }
}

void draw_static_function_setup_exec(ivl_scope_t scope)
{
      if (static_function_setup_enabled_(scope))
            fprintf(vvp_out, "    %%static/call/exec S_%p;\n", scope);
}

void draw_static_function_arg_mode(ivl_scope_t scope, unsigned mode)
{
      if (static_function_setup_enabled_(scope))
            fprintf(vvp_out, "    %%static/call/arg S_%p, %u;\n",
                    scope, mode);
}

void draw_static_function_setup_leave(ivl_scope_t scope)
{
      if (static_function_setup_enabled_(scope))
            fprintf(vvp_out, "    %%static/call/leave S_%p;\n", scope);
}

/* Dynamic VIF functions are input-only, so their static formals can be
 * installed sequentially. That is required for a declaration-scoped default
 * to observe an earlier formal. The mode markers let the runtime distinguish
 * caller-expression side effects from the marshaller's own stores while a
 * nested invocation temporarily preserves the outer setup. */
int draw_vif_function_input_arguments(ivl_scope_t scope, unsigned port_base,
                                      unsigned argc,
                                      ivl_expr_t const*argv,
                                      const unsigned char*is_default)
{
      int errors = 0;
      if (!scope || (argc && (!argv || !is_default))
          || port_base > ivl_scope_ports(scope)
          || argc > ivl_scope_ports(scope) - port_base)
            return 1;

      for (unsigned idx = 0 ; idx < argc ; idx += 1) {
            ivl_signal_t port = ivl_scope_port(scope, port_base + idx);
            if (!port || !argv[idx]
                || ivl_signal_port(port) != IVL_SIP_INPUT) {
                  errors += 1;
                  continue;
            }
            /* 1=explicit caller expression, 2=declaration default,
             * 3=marshaller store, 0=idle. */
            draw_static_function_arg_mode(scope, is_default[idx] ? 2 : 1);
            draw_eval_function_argument(port, argv[idx]);
            draw_static_function_arg_mode(scope, 3);
            draw_send_function_argument(port, argv[idx]);
            draw_static_function_arg_mode(scope, 0);
      }
      return errors;
}

static int function_argument_actual_signal_(ivl_expr_t expr,
					    ivl_signal_t*sig,
					    ivl_expr_t*word)
{
      if (sig)
	    *sig = 0;
      if (word)
	    *word = 0;

      if (!expr || ivl_expr_type(expr) != IVL_EX_SIGNAL)
	    return 0;

      if (sig)
	    *sig = ivl_expr_signal(expr);
      if (word)
	    *word = ivl_expr_oper1(expr);

      return sig && *sig;
}

/* The formal value is already on the object stack. A queue/dynamic-array
   output or inout is copied by value (13.5), so leave one independent value
   for the actual's store. Cross-kind copies materialize the actual's declared
   container kind; same-kind copies duplicate the formal and discard its live
   storage alias. Class handles and other object kinds remain references. */
static void draw_copy_out_container_value_(ivl_signal_t port,
                                            ivl_expr_t actual)
{
      ivl_type_t port_type = ivl_signal_net_type(port);
      ivl_type_t actual_type = receiver_container_type_(actual);

      if (!type_is_runtime_container_(port_type))
	    return;

      if (draw_convert_container_value_for_target(port_type, actual_type))
	    return;

      fprintf(vvp_out, "    %%dup/obj; container copy-out value\n");
      fprintf(vvp_out,
	      "    %%pop/obj 1, 1; discard output formal storage alias\n");
}

/* Output addresses belong to the caller; the copied value belongs to the
 * returned callee. Keep these roles explicit even in same-scope recursion. */
static void draw_copy_out_context(ivl_signal_t port, unsigned source)
{
      if (ivl_scope_is_auto(ivl_signal_scope(port)))
            fprintf(vvp_out, "    %%copyout/context %u;\n", source);
}

static void draw_copy_out_load(ivl_signal_t port, const char*kind)
{
      draw_copy_out_context(port, 1);
      fprintf(vvp_out, "    %%load/%s v%p_0;\n", kind, port);
      draw_copy_out_context(port, 0);
}

static void draw_copy_out_load_array(ivl_signal_t port, unsigned kind)
{
      draw_copy_out_context(port, 1);
      emit_load_arr_dar_(port, kind);
      draw_copy_out_context(port, 0);
}

static void draw_copy_out_function_argument_impl(ivl_signal_t port, ivl_expr_t actual)
{
      static int warned_unsupported_copy_out = 0;
      ivl_signal_t sig = 0;
      ivl_expr_t word = 0;
      ivl_variable_type_t dtype;

      if (port_is_unsupported_aggregate_formal_(port))
	    return;

	/* A direct fixed-array slice actual retains its backing signal and
	   canonical storage window in IVL_EX_ARRAY_SLICE. Materialize the formal
	   value, then atomically copy exactly that window back in the actual's
	   selected direction. Active DPI open-array objects are already in
	   numeric-canonical order; passive native values remain left-to-right. */
      if (ivl_expr_type(actual) == IVL_EX_ARRAY_SLICE) {
	    ivl_signal_t asig = ivl_expr_signal(actual);
	    unsigned akind;
	    if (!asig || !uarray_container_kind_(
		  asig, &akind, ivl_expr_file(actual), ivl_expr_lineno(actual)))
		  return;

	    if (ivl_signal_dimensions(port) > 0) {
		  unsigned pkind;
		  if (!uarray_container_kind_(port, &pkind,
			ivl_expr_file(actual), ivl_expr_lineno(actual)))
			return;
		  draw_copy_out_load_array(port, pkind);
	    } else {
		  draw_copy_out_load(port, "obj");
	    }

	    emit_store_arr_dar_slice_(
		  asig, akind,
		  (unsigned)ivl_expr_array_slice_base(actual),
		  (unsigned)ivl_expr_array_slice_count(actual),
		  (int)ivl_expr_array_slice_left(actual),
		  (int)ivl_expr_array_slice_right(actual));
	    return;
      }

	/* Whole fixed-array output/inout copy-back. Both sides use inline
	   word storage, so marshal the formal through the same temporary
	   container used by fixed<->dynamic assignment. This also covers a
	   fixed unpacked-array DPI formal called from an SV wrapper. */
      if (ivl_signal_dimensions(port) > 0
	  && ivl_expr_type(actual) == IVL_EX_ARRAY
	  && ivl_expr_signal(actual)
	  && ivl_signal_dimensions(ivl_expr_signal(actual)) > 0) {
	    ivl_signal_t asig = ivl_expr_signal(actual);
	    unsigned pkind, akind;
	    if (uarray_container_kind_(port, &pkind,
				       ivl_expr_file(actual),
				       ivl_expr_lineno(actual))
		&& uarray_container_kind_(asig, &akind,
					 ivl_expr_file(actual),
					 ivl_expr_lineno(actual))) {
		  draw_copy_out_load_array(port, pkind);
		  emit_store_arr_dar_(asig, akind);
	    }
	    return;
      }

      /* Phase 63b/B6 (gap close): unwrap a single-level IVL_EX_SELECT
         that's just a width/sign cast wrapping an IVL_EX_PROPERTY.
         iverilog emits this when `uvm_config_db#(T)::get(this, "",
         "name", this.m_field)` casts the formal type to the actual
         field's width.  After unwrap, the existing IVL_EX_PROPERTY
         handler below copies out via %store/prop/<v>.  Don't unwrap
         the assoc-array form (SELECT with both oper1=PROPERTY and
         oper2=key) — that's handled by its own dedicated branch. */
      if (ivl_expr_type(actual) == IVL_EX_SELECT
	  && !ivl_expr_oper2(actual)
	  && ivl_expr_oper1(actual)
	  && ivl_expr_type(ivl_expr_oper1(actual)) == IVL_EX_PROPERTY) {
	    actual = ivl_expr_oper1(actual);
      }

      /* An output actual such as item.key[slot][word] is a packed select
	 of one fixed-array property slot. Copy the returned formal into that
	 bit window, leaving the rest of the property element intact. */
      if (ivl_expr_type(actual) == IVL_EX_SELECT) {
	    ivl_expr_t prop = ivl_expr_oper1(actual);
	    ivl_expr_t offset = ivl_expr_oper2(actual);
	    ivl_type_t element = prop && ivl_expr_type(prop) == IVL_EX_PROPERTY
		? property_expr_value_type_(prop) : 0;
	    ivl_variable_type_t leaf = element
		? ivl_type_base(element) : IVL_VT_NO_TYPE;
	    if (prop && offset && property_selects_fixed_uarray_slot_(prop)
		&& (leaf == IVL_VT_BOOL || leaf == IVL_VT_LOGIC)
		&& ivl_signal_dimensions(port) == 0
		&& (ivl_signal_data_type(port) == IVL_VT_BOOL
		    || ivl_signal_data_type(port) == IVL_VT_LOGIC)
		&& ivl_expr_width(actual) > 0) {
		ivl_signal_t base_sig = ivl_expr_signal(prop);
		ivl_expr_t base_expr = ivl_expr_oper2(prop);
		if (base_sig || base_expr) {
		    int slot_word = allocate_word();
		    int offset_word = allocate_word();
		    int slot_x_flag = -1, slot_in_range_flag = -1;
		    int offset_flag = allocate_flag();
		    unsigned bad_slot = local_count++;
		    unsigned null_receiver = local_count++;
		    unsigned done = local_count++;
		    unsigned width = ivl_expr_width(actual);
		    int pidx = (int)ivl_expr_property_idx(prop);
		    if (base_sig)
			fprintf(vvp_out, "    %%load/obj v%p_0;\n", base_sig);
		    else
			draw_eval_object(base_expr);
		    fprintf(vvp_out, "    %%test_nul/obj;\n");
		    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
			    thread_count, null_receiver);
		    draw_fixed_uarray_slot_index_(ivl_expr_oper1(prop),
			property_expr_type_(prop), slot_word,
			&slot_x_flag, &slot_in_range_flag);
		    fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d;\n",
			    thread_count, bad_slot, slot_x_flag);
		    if (slot_in_range_flag >= 0)
			fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d;\n",
			    thread_count, bad_slot, slot_in_range_flag);
		    draw_eval_expr_into_integer(offset, offset_word);
		    fprintf(vvp_out, "    %%flag_mov %d, 4;\n", offset_flag);
		    draw_copy_out_load(port, "vec4");
		    fprintf(vvp_out, "    %%pad/%s %u;\n",
			ivl_signal_signed(port) ? "s" : "u", width);
		    if (leaf == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		    fprintf(vvp_out, "    %%flag_mov 4, %d;\n", offset_flag);
		    fprintf(vvp_out, "    %%store/prop/v/i/bits/%s %d, %d, %d;\n",
			ivl_expr_signed(offset) ? "x" : "ux",
			pidx, slot_word, offset_word);
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, bad_slot);
		    fprintf(vvp_out,
			"    %%vpi_call/w %u %u \"$warning\", "
			"\"fixed unpacked-array property index is undefined or "
			"out of range; function copy-out was ignored\" {0 0 0 0};\n",
			ivl_file_table_index(ivl_expr_file(actual)),
			ivl_expr_lineno(actual));
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
		    fprintf(vvp_out, "T_%u.%u;\n",
			thread_count, null_receiver);
		    fprintf(vvp_out,
			"    %%vpi_call/w %u %u \"$warning\", "
			"\"null class receiver; function copy-out was ignored\" "
			"{0 0 0 0};\n",
			ivl_file_table_index(ivl_expr_file(actual)),
			ivl_expr_lineno(actual));
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, done);
		    clr_word(slot_word);
		    clr_word(offset_word);
		    clr_flag(slot_x_flag);
		    if (slot_in_range_flag >= 0)
			clr_flag(slot_in_range_flag);
		    clr_flag(offset_flag);
		    return;
		}
	    }
      }

      /* A fixed-array element inside an associative class property is
	 represented as SELECT(SELECT(PROPERTY, key), slot). In particular,
	 uvm_config_db::get may copy a class handle into cfg.mem[key][slot].
	 Materialize the associative child only after validating the fixed slot:
	 an invalid copy-out must not create a new associative entry. */
      if (ivl_expr_type(actual) == IVL_EX_SELECT) {
	    ivl_expr_t child = ivl_expr_oper1(actual);
	    ivl_expr_t slot = ivl_expr_oper2(actual);
	    ivl_expr_t prop = child && ivl_expr_type(child) == IVL_EX_SELECT
		? ivl_expr_oper1(child) : 0;
	    ivl_expr_t key = child && ivl_expr_type(child) == IVL_EX_SELECT
		? ivl_expr_oper2(child) : 0;
	    ivl_type_t assoc_type = prop && ivl_expr_type(prop) == IVL_EX_PROPERTY
		? property_expr_type_(prop) : 0;
	    ivl_type_t fixed_type = assoc_type
		? ivl_type_element(assoc_type) : 0;
	    ivl_type_t leaf_type = fixed_type
		? ivl_type_element(fixed_type) : 0;
	    if (prop && key && slot && !ivl_expr_oper1(prop)
		&& assoc_type && ivl_type_base(assoc_type) == IVL_VT_QUEUE
		&& ivl_type_queue_assoc_compat(assoc_type)
		&& type_is_fixed_uarray_property_(fixed_type)
		&& leaf_type && ivl_type_base(leaf_type) == IVL_VT_CLASS
		&& ivl_signal_data_type(port) == IVL_VT_CLASS
		/* Keep %ix/vec4 within 64 bits so its flag only reports X/Z,
		   never integer overflow. Wider keys retain the fallback warning. */
		&& ivl_expr_width(key) > 0 && ivl_expr_width(key) <= 64
		&& (ivl_expr_value(key) == IVL_VT_BOOL
		    || ivl_expr_value(key) == IVL_VT_LOGIC)
		&& !expr_is_string_assoc_key_(key)
		&& !expr_is_object_assoc_key_(key)) {
		ivl_signal_t base_sig = ivl_expr_signal(prop);
		ivl_expr_t base_expr = ivl_expr_oper2(prop);
		if (base_sig || base_expr) {
		    int slot_word = allocate_word();
		    int key_word = allocate_word();
		    int x_flag = -1, range_flag = -1;
		    int key_x_flag = allocate_flag();
		    unsigned bad_slot = local_count++;
		    unsigned bad_key = local_count++;
		    unsigned null_receiver = local_count++;
		    unsigned done = local_count++;
		    int pidx = (int)ivl_expr_property_idx(prop);
		    if (base_sig)
			fprintf(vvp_out, "    %%load/obj v%p_0;\n", base_sig);
		    else
			draw_eval_object(base_expr);
		    fprintf(vvp_out, "    %%test_nul/obj;\n");
		    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
			thread_count, null_receiver);
		    fprintf(vvp_out, "    %%prop/obj %d, 0; output associative property\n",
			pidx);
		    fprintf(vvp_out, "    %%pop/obj 1, 1; keep associative property\n");
		    draw_fixed_uarray_slot_index_(slot, fixed_type, slot_word,
			&x_flag, &range_flag);
		    fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d;\n",
			thread_count, bad_slot, x_flag);
		    if (range_flag >= 0)
			fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d;\n",
			    thread_count, bad_slot, range_flag);
		    draw_eval_assoc_key_(key, 0);
		    fprintf(vvp_out, "    %%dup/vec4; preserve output associative key\n");
		    fprintf(vvp_out, "    %%ix/vec4 %d; check key for X/Z\n",
			key_word);
		    fprintf(vvp_out, "    %%flag_mov %d, 4; associative key X/Z\n",
			key_x_flag);
		    fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d;\n",
			thread_count, bad_key, key_x_flag);
		    fprintf(vvp_out, "    %%aa/viv/o/v 17; materialize fixed child\n");
		    draw_copy_out_load(port, "obj");
		    fprintf(vvp_out, "    %%set/dar/obj/obj %d; output fixed child slot\n",
			slot_word);
		    fprintf(vvp_out, "    %%pop/obj 1, 0; discard fixed child\n");
		    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, bad_key);
		    fprintf(vvp_out,
			"    %%vpi_call/w %u %u \"$warning\", "
			"\"associative array key contains X/Z; function copy-out "
			"was ignored\" {0 0 0 0};\n",
			ivl_file_table_index(ivl_expr_file(key)),
			ivl_expr_lineno(key));
		    fprintf(vvp_out, "    %%pop/vec4 1; discard invalid key\n");
		    fprintf(vvp_out, "    %%pop/obj 1, 0; discard associative property\n");
		    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, bad_slot);
		    fprintf(vvp_out,
			"    %%vpi_call/w %u %u \"$warning\", "
			"\"fixed unpacked-array property index is undefined or "
			"out of range; function copy-out was ignored\" {0 0 0 0};\n",
			ivl_file_table_index(ivl_expr_file(slot)),
			ivl_expr_lineno(slot));
		    fprintf(vvp_out, "    %%pop/obj 1, 0; discard associative property\n");
		    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, null_receiver);
		    fprintf(vvp_out,
			"    %%vpi_call/w %u %u \"$warning\", "
			"\"null class receiver; function copy-out was ignored\" "
			"{0 0 0 0};\n",
			ivl_file_table_index(ivl_expr_file(actual)),
			ivl_expr_lineno(actual));
		    fprintf(vvp_out, "    %%pop/obj 1, 0; discard null receiver\n");
		    fprintf(vvp_out, "T_%u.%u;\n", thread_count, done);
		    clr_word(slot_word);
		    clr_word(key_word);
		    clr_flag(x_flag);
		    clr_flag(key_x_flag);
		    if (range_flag >= 0)
			clr_flag(range_flag);
		    return;
		}
	    }
      }

      /* An output actual such as item.addr[i] or item.addr[7:4] is a bit or
	 part select of a packed class property (IEEE 1800-2017/2023 13.5,
	 11.5.1): copy the returned formal into that window and leave the other
	 bits alone. It is not an associative-array entry, which the branch
	 below handles for container-typed properties only. */
      if (ivl_expr_type(actual) == IVL_EX_SELECT) {
	    ivl_expr_t prop = ivl_expr_oper1(actual);
	    ivl_expr_t offset = ivl_expr_oper2(actual);
	    ivl_type_t ptype = prop && ivl_expr_type(prop) == IVL_EX_PROPERTY
		? property_expr_type_(prop) : 0;
	    ivl_variable_type_t leaf = ptype
		? ivl_type_base(ptype) : IVL_VT_NO_TYPE;
	    if (prop && offset && !ivl_expr_oper1(prop)
		&& ptype && ivl_type_is_packed_vector(ptype)
		&& (leaf == IVL_VT_BOOL || leaf == IVL_VT_LOGIC)
		&& ivl_signal_dimensions(port) == 0
		&& (ivl_signal_data_type(port) == IVL_VT_BOOL
		    || ivl_signal_data_type(port) == IVL_VT_LOGIC)
		&& ivl_expr_width(actual) > 0
		&& (ivl_expr_signal(prop) || ivl_expr_oper2(prop))) {
		  ivl_signal_t base_sig = ivl_expr_signal(prop);
		  ivl_expr_t base_expr = ivl_expr_oper2(prop);
		  int slot_word = allocate_word();
		  int offset_word = allocate_word();
		  int offset_flag = allocate_flag();
		  unsigned null_receiver = local_count++;
		  unsigned done = local_count++;
		  unsigned width = ivl_expr_width(actual);
		  int pidx = (int)ivl_expr_property_idx(prop);
		  if (base_sig)
			fprintf(vvp_out, "    %%load/obj v%p_0;\n", base_sig);
		  else
			draw_eval_object(base_expr);
		  fprintf(vvp_out, "    %%test_nul/obj;\n");
		  fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n",
			  thread_count, null_receiver);
		  fprintf(vvp_out, "    %%ix/load %d, 0, 0;\n", slot_word);
		  draw_eval_expr_into_integer(offset, offset_word);
		  fprintf(vvp_out, "    %%flag_mov %d, 4;\n", offset_flag);
		  draw_copy_out_load(port, "vec4");
		  fprintf(vvp_out, "    %%pad/%s %u;\n",
			  ivl_signal_signed(port) ? "s" : "u", width);
		  if (leaf == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		  fprintf(vvp_out, "    %%flag_mov 4, %d;\n", offset_flag);
		  fprintf(vvp_out, "    %%store/prop/v/i/bits/%s %d, %d, %d;\n",
			  ivl_expr_signed(offset) ? "x" : "ux",
			  pidx, slot_word, offset_word);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, done);
		  fprintf(vvp_out, "T_%u.%u;\n", thread_count, null_receiver);
		  fprintf(vvp_out,
			  "    %%vpi_call/w %u %u \"$warning\", "
			  "\"null class receiver; copy-out was ignored\" "
			  "{0 0 0 0};\n",
			  ivl_file_table_index(ivl_expr_file(actual)),
			  ivl_expr_lineno(actual));
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  fprintf(vvp_out, "T_%u.%u;\n", thread_count, done);
		  clr_word(slot_word);
		  clr_word(offset_word);
		  clr_flag(offset_flag);
		  return;
	    }
      }

      /* Handle copy-out to an indexed assoc-array entry of a class
         property (e.g. cfg.vifs[key]). Iverilog represents this as
         IVL_EX_SELECT(arr, key) where `arr` is the IVL_EX_PROPERTY for
         cfg.vifs. Emit the containing cobj load + %prop/obj to push
         the assoc-array, then the key, then the port value, then
         %aa/store/<v>/<k>. */
      (void)warned_unsupported_copy_out;
      if (ivl_expr_type(actual) == IVL_EX_SELECT) {
	    ivl_expr_t arr_expr = ivl_expr_oper1(actual);
	    ivl_expr_t key_expr = ivl_expr_oper2(actual);
	    if (arr_expr && key_expr
		&& ivl_expr_type(arr_expr) == IVL_EX_PROPERTY
		&& !ivl_expr_oper1(arr_expr)) {
		  ivl_signal_t base_sig = ivl_expr_signal(arr_expr);
		  int aa_pidx = (int)ivl_expr_property_idx(arr_expr);
		  dtype = ivl_signal_data_type(port);

		  /* Push containing cobj */
		  if (base_sig) {
			fprintf(vvp_out, "    %%load/obj v%p_0;\n", base_sig);
		  } else {
			ivl_expr_t base_expr = ivl_expr_oper2(arr_expr);
			if (!base_expr) {
			      if (!warned_unsupported_copy_out) {
				    fprintf(stderr,
				            "Warning: Skipping nested-base assoc"
					    " copy-out for %s (further similar"
					    " warnings suppressed)\n",
					    ivl_signal_basename(port));
				    warned_unsupported_copy_out = 1;
			      }
			      return;
			}
			draw_eval_object(base_expr);
		  }
		  /* Load the assoc array (as obj) on top */
		  fprintf(vvp_out, "    %%prop/obj %d, 0;\n", aa_pidx);
		  fprintf(vvp_out, "    %%pop/obj 1, 1;\n"); /* drop cobj keep aa */

		  /* Push the key with the right type for the assoc store.
		     draw_eval_assoc_key_ uses iverilog's notion of which
		     key type the assoc array expects (str/obj/v). */
		  const char*key_kind = draw_eval_assoc_key_(key_expr, 0);
		  /* Push the port value, emit aa/store */
		  switch (dtype) {
		      case IVL_VT_BOOL:
		      case IVL_VT_LOGIC:
			draw_copy_out_load(port, "vec4");
			fprintf(vvp_out, "    %%aa/store/v/%s %u;\n", key_kind,
				ivl_signal_width(port));
			break;
		      case IVL_VT_REAL:
			draw_copy_out_load(port, "real");
			fprintf(vvp_out, "    %%aa/store/r/%s;\n", key_kind);
			break;
		      case IVL_VT_STRING:
			draw_copy_out_load(port, "str");
			fprintf(vvp_out, "    %%aa/store/str/%s;\n", key_kind);
			break;
		      case IVL_VT_CLASS:
		      case IVL_VT_DARRAY:
		      case IVL_VT_QUEUE:
		      case IVL_VT_NO_TYPE:
		      default:
			draw_copy_out_load(port, "obj");
			draw_copy_out_container_value_(port, actual);
			fprintf(vvp_out, "    %%aa/store/obj/%s;\n", key_kind);
			break;
		  }
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n"); /* drop aa */
		  return;
	    }
      }

      if (ivl_expr_type(actual) == IVL_EX_PROPERTY) {
	    ivl_signal_t base_sig = ivl_expr_signal(actual);
	    ivl_expr_t base_expr = ivl_expr_oper2(actual);
	    /* The target API exports an associative/positional container-property
	       element or fixed-uarray property slot directly as
	       PROPERTY(oper1=index), not as SELECT(PROPERTY,index). These actuals
	       are legal output/inout lvalues. Evaluate their key/index here, during
	       the return copy-out required by IEEE 1800-2017/2023 13.5, and exactly
	       once for this copy operation. Pure output actuals were deliberately
	       not evaluated in the preamble. */
	    if (ivl_expr_oper1(actual)) {
		  ivl_expr_t idx_expr = ivl_expr_oper1(actual);
		  ivl_type_t prop_type = property_expr_type_(actual);
		  ivl_type_t actual_type = receiver_container_type_(actual);
		  int assoc_container_value = prop_type
			&& ivl_type_base(prop_type) == IVL_VT_QUEUE
			&& ivl_type_queue_assoc_compat(prop_type)
			&& type_is_runtime_container_(actual_type);
		  int positional_container_value = prop_type
			&& (ivl_type_base(prop_type) == IVL_VT_DARRAY
			    || (ivl_type_base(prop_type) == IVL_VT_QUEUE
				&& !ivl_type_queue_assoc_compat(prop_type)))
			&& type_is_runtime_container_(actual_type);
		  int fixed_property_slot =
			type_is_fixed_uarray_property_(prop_type);

		  /* A returned formal is a variable, not a string literal. String
		     and non-string assignments require an explicit cast (6.16). */
		  if (fixed_property_slot
		      && ((ivl_type_base(ivl_type_element(prop_type)) == IVL_VT_STRING)
			  != (ivl_signal_data_type(port) == IVL_VT_STRING))) {
			fprintf(stderr, "%s:%u: error: fixed property output %s "
				"requires matching string types; use an explicit cast "
				"through a temporary.\n",
				ivl_expr_file(actual), ivl_expr_lineno(actual),
				ivl_signal_basename(port));
			vvp_errors += 1;
			return;
		  }

		  if (assoc_container_value || positional_container_value
		      || fixed_property_slot) {
			int pidx = (int)ivl_expr_property_idx(actual);

			if (base_sig) {
			      fprintf(vvp_out, "    %%load/obj v%p_0;\n", base_sig);
			} else if (base_expr) {
			      draw_eval_object(base_expr);
			} else {
			      if (!warned_unsupported_copy_out) {
				    fprintf(stderr,
					    "Warning: Skipping indexed property copy-out"
					    " for %s: no receiver (further similar"
					    " warnings suppressed)\n",
					    ivl_signal_basename(port));
				    warned_unsupported_copy_out = 1;
			      }
			      return;
			}

			if (assoc_container_value) {
			      const char*key_kind;

			      fprintf(vvp_out, "    %%prop/obj %d, 0; output associative property\n",
				      pidx);
			      fprintf(vvp_out, "    %%pop/obj 1, 1;\n");
			      key_kind = draw_eval_assoc_key_(idx_expr, 0);
			      draw_copy_out_load(port, "obj");
			      draw_copy_out_container_value_(port, actual);
			      fprintf(vvp_out, "    %%aa/store/obj/%s;\n", key_kind);
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			      return;
			}

			if (positional_container_value) {
			      int element_word = allocate_word();

			      draw_eval_expr_into_integer(idx_expr, element_word);
			      fprintf(vvp_out,
				      "    %%prop/obj %d, 0; output positional container property\n",
				      pidx);
			      fprintf(vvp_out, "    %%pop/obj 1, 1; keep output container property\n");
			      draw_copy_out_load(port, "obj");
			      draw_copy_out_container_value_(port, actual);
			      fprintf(vvp_out,
				      "    %%set/dar/obj/obj %d; output positional container element\n",
				      element_word);
			      fprintf(vvp_out, "    %%pop/obj 1, 0; discard output container property\n");
			      clr_word(element_word);
			      return;
			}

			{
			      int slot_word = allocate_word();
			      int slot_x_flag = -1;
			      int slot_in_range_flag = -1;
			      unsigned lab_bad_slot = local_count++;
			      unsigned lab_slot_done = local_count++;

			      draw_fixed_uarray_slot_index_(idx_expr, prop_type,
						   slot_word, &slot_x_flag,
						   &slot_in_range_flag);
			      fprintf(vvp_out,
				      "    %%jmp/1xz T_%u.%u, %d; output fixed property slot X/Z\n",
				      thread_count, lab_bad_slot, slot_x_flag);
			      if (slot_in_range_flag >= 0)
				    fprintf(vvp_out,
					    "    %%jmp/0xz T_%u.%u, %d; output fixed property slot OOB\n",
					    thread_count, lab_bad_slot,
					    slot_in_range_flag);
			      ivl_type_t leaf_type = ivl_type_element(prop_type);
			      switch (ivl_type_base(leaf_type)) {
				case IVL_VT_BOOL:
				case IVL_VT_LOGIC: {
				  unsigned width = ivl_type_packed_width(leaf_type);
				  if (ivl_signal_data_type(port) == IVL_VT_REAL) {
					draw_copy_out_load(port, "real");
					fprintf(vvp_out, "    %%cvt/vr %u;\n", width);
				  } else {
					draw_copy_out_load(port, "vec4");
					fprintf(vvp_out, "    %%pad/%s %u;\n",
						ivl_signal_signed(port) ? "s" : "u", width);
				  }
				  if (ivl_type_base(leaf_type) == IVL_VT_BOOL)
					fprintf(vvp_out, "    %%cast2;\n");
				  fprintf(vvp_out,
					  "    %%store/prop/v/i %d, %d, %u;\n",
					  pidx, slot_word, width);
				  break;
				}
				case IVL_VT_REAL:
				  if (ivl_signal_data_type(port) == IVL_VT_REAL) {
					draw_copy_out_load(port, "real");
				  } else {
					draw_copy_out_load(port, "vec4");
					fprintf(vvp_out, "    %%cvt/rv%s;\n",
						ivl_signal_signed(port) ? "/s" : "");
				  }
				  fprintf(vvp_out, "    %%store/prop/r/i %d, %d;\n",
					  pidx, slot_word);
				  break;
				case IVL_VT_STRING:
				  draw_copy_out_load(port, "str");
				  fprintf(vvp_out, "    %%store/prop/str/i %d, %d;\n",
					  pidx, slot_word);
				  break;
				default:
				  draw_copy_out_load(port, "obj");
				  draw_copy_out_container_value_(port, actual);
				  fprintf(vvp_out,
					  "    %%store/prop/obj %d, %d; output fixed property slot\n",
					  pidx, slot_word);
				  break;
			      }
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			      fprintf(vvp_out, "    %%jmp T_%u.%u;\n",
				      thread_count, lab_slot_done);
			      fprintf(vvp_out, "T_%u.%u;\n",
				      thread_count, lab_bad_slot);
			      fprintf(vvp_out,
				      "    %%vpi_call/w %u %u \"$warning\", "
				      "\"fixed unpacked-array property index is undefined or out of range; "
				      "function copy-out was ignored\" {0 0 0 0};\n",
				      ivl_file_table_index(ivl_expr_file(idx_expr)),
				      ivl_expr_lineno(idx_expr));
			      fprintf(vvp_out,
				      "    %%pop/obj 1, 0; invalid output fixed container slot\n");
			      fprintf(vvp_out, "T_%u.%u;\n",
				      thread_count, lab_slot_done);
			      clr_word(slot_word);
			      clr_flag(slot_x_flag);
			      if (slot_in_range_flag >= 0)
				    clr_flag(slot_in_range_flag);
			      return;
			}
		  }

		  if (!warned_unsupported_copy_out) {
			fprintf(stderr,
				"Warning: Skipping indexed property copy-out for"
				" %s (further similar warnings suppressed)\n",
				ivl_signal_basename(port));
			warned_unsupported_copy_out = 1;
		  }
		  return;
	    }
	    int pidx = (int)ivl_expr_property_idx(actual);
	    dtype = ivl_signal_data_type(port);
	    int fixed_array_property =
		  vvp_expr_is_whole_fixed_array_property(actual);

	    /* Push the containing cobj. If base_sig is set, use a direct
	       load; otherwise oper2 holds the nested-base property expression
	       (e.g. env.cfg in env.cfg.o). draw_eval_object pushes that
	       cobj's value onto the obj stack. */
	    if (base_sig) {
		  fprintf(vvp_out, "    %%load/obj v%p_0;\n", base_sig);
	    } else {
		  if (!base_expr) {
			if (!warned_unsupported_copy_out) {
			      fprintf(stderr,
				      "Warning: Skipping nested-base property copy-out"
				      " for %s — no base expr"
				      " (further similar warnings suppressed)\n",
				      ivl_signal_basename(port));
			      warned_unsupported_copy_out = 1;
			}
			return;
		  }
		  draw_eval_object(base_expr);
	    }

	    if (fixed_array_property) {
		  if (ivl_signal_dimensions(port) > 0) {
			unsigned kind;
			if (!uarray_container_kind_(port, &kind,
			      ivl_expr_file(actual), ivl_expr_lineno(actual))) {
			      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			      return;
			}
			draw_copy_out_load_array(port, kind);
		  } else {
			draw_copy_out_load(port, "obj");
			draw_copy_out_container_value_(port, actual);
		  }
		  fprintf(vvp_out, "    %%store/prop/arr/dar %d;\n", pidx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  return;
	    }

	    switch (dtype) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  draw_copy_out_load(port, "vec4");
		  {
			ivl_type_t actual_type = property_expr_value_type_(actual);
			unsigned actual_width = actual_type
			      ? ivl_type_packed_width(actual_type)
			      : ivl_signal_width(port);
			if (actual_width != ivl_signal_width(port))
			      fprintf(vvp_out, "    %%pad/%s %u;\n",
				      ivl_signal_signed(port) ? "s" : "u", actual_width);
			if (actual_type && ivl_type_base(actual_type) == IVL_VT_BOOL)
			      fprintf(vvp_out, "    %%cast2;\n");
			fprintf(vvp_out, "    %%store/prop/v %d, %u;\n", pidx,
			      actual_width);
		  }
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  break;
		case IVL_VT_REAL:
		  draw_copy_out_load(port, "real");
		  fprintf(vvp_out, "    %%store/prop/r %d;\n", pidx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  break;
		case IVL_VT_STRING:
		  draw_copy_out_load(port, "str");
		  fprintf(vvp_out, "    %%store/prop/str %d;\n", pidx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  break;
	    case IVL_VT_DARRAY:
		  /* fall through */
	    case IVL_VT_CLASS:
	    case IVL_VT_QUEUE:
		case IVL_VT_NO_TYPE:
		default:
		  draw_copy_out_load(port, "obj");
		  draw_copy_out_container_value_(port, actual);
		  fprintf(vvp_out, "    %%store/prop/obj %d, 0;\n", pidx);
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  break;
	    }
	    return;
      }

      /* Phase 63b/B6 (real impl): handle IVL_EX_SELECT-wrapped
	 signal actuals that arise from width-cast / sign-cast
	 normalization at the call site.  When the SELECT has no
	 base (oper2 nil) and oper1 is a signal of vectorable type,
	 the SELECT is a width pad/truncate of the underlying
	 signal — we copy out from the port directly into the
	 underlying signal, padding/truncating as needed.  This
	 covers the common UVM pattern
	   uvm_config_int::get(... , tmp);
	 where iverilog wraps `tmp` in a SELECT for type
	 normalization. */
      if (ivl_expr_type(actual) == IVL_EX_SELECT
	  && !ivl_expr_oper2(actual)
	  && ivl_expr_oper1(actual)
	  && ivl_expr_type(ivl_expr_oper1(actual)) == IVL_EX_SIGNAL) {
	    ivl_expr_t op1 = ivl_expr_oper1(actual);
	    ivl_signal_t under_sig = ivl_expr_signal(op1);
	    if (under_sig && ivl_signal_dimensions(under_sig) == 0) {
		  ivl_variable_type_t udtype = ivl_signal_data_type(under_sig);
		  unsigned port_wid = ivl_signal_width(port);
		  unsigned sig_wid  = ivl_signal_width(under_sig);
		  if (udtype == IVL_VT_BOOL || udtype == IVL_VT_LOGIC) {
			draw_copy_out_load(port, "vec4");
			if (sig_wid != port_wid) {
			      const char*pad = ivl_signal_signed(under_sig)
				    ? "%pad/s" : "%pad/u";
			      fprintf(vvp_out, "    %s %u;\n", pad, sig_wid);
			}
			if (udtype == IVL_VT_BOOL)
			      fprintf(vvp_out, "    %%cast2;\n");
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
				under_sig, sig_wid);
			return;
		  }
	    }
      }

      /* An output/inout actual that is a bit or part select of a vector
	 variable (`cur_val[i]', `word[7:0]'): load the formal, resize it to
	 the selected width, and store it back at the select's offset. A
	 narrower select than the formal truncates exactly as an assignment
	 does (13.5, 11.8.2). An unknown offset leaves the variable alone
	 through the store's undefined-offset flag. */
      ivl_expr_t sel_actual = actual;
	/* The call site wraps the select in a base-less pad/truncate select
	   when the formal and the selected widths differ. */
      if (ivl_expr_type(sel_actual) == IVL_EX_SELECT
	  && !ivl_expr_oper2(sel_actual)
	  && ivl_expr_oper1(sel_actual)
	  && ivl_expr_type(ivl_expr_oper1(sel_actual)) == IVL_EX_SELECT)
	    sel_actual = ivl_expr_oper1(sel_actual);
      if (ivl_expr_type(sel_actual) == IVL_EX_SELECT
	  && ivl_expr_oper2(sel_actual)
	  && ivl_expr_oper1(sel_actual)
	  && ivl_expr_type(ivl_expr_oper1(sel_actual)) == IVL_EX_SIGNAL
	  && !ivl_expr_oper1(ivl_expr_oper1(sel_actual))) {
	    ivl_signal_t under_sig = ivl_expr_signal(ivl_expr_oper1(sel_actual));
	    ivl_variable_type_t udtype = under_sig
		  ? ivl_signal_data_type(under_sig) : IVL_VT_NO_TYPE;
	    ivl_variable_type_t pdtype = ivl_signal_data_type(port);
	    if (under_sig && ivl_signal_dimensions(under_sig) == 0
		&& (udtype == IVL_VT_BOOL || udtype == IVL_VT_LOGIC)
		&& (pdtype == IVL_VT_BOOL || pdtype == IVL_VT_LOGIC)
		&& ivl_signal_type(under_sig) != IVL_SIT_UWIRE
		&& !signal_is_return_value(under_sig)) {
		  unsigned sel_wid = ivl_expr_width(sel_actual);
		  unsigned port_wid = ivl_signal_width(port);
		  int offset_ix = allocate_word();
		  draw_eval_expr_into_integer(ivl_expr_oper2(sel_actual), offset_ix);
		  draw_copy_out_load(port, "vec4");
		  if (port_wid != sel_wid)
			fprintf(vvp_out, "    %%pad/%s %u;\n",
				ivl_signal_signed(port) ? "s" : "u", sel_wid);
		  if (udtype == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		  fprintf(vvp_out, "    %%store/vec4 v%p_0, %d, %u;\n",
			  under_sig, offset_ix, sel_wid);
		  clr_word(offset_ix);
		  return;
	    }
      }

	/* A `ref'/`output'/`inout' open-array formal whose actual is a
	   WHOLE fixed unpacked array. The formal holds a container and
	   the actual holds inline words, so the copy back out is the
	   same container -> fixed-array copy the 7.6 assignment makes;
	   it goes through the same %store/arr/dar.

	   Without this the actual was not an IVL_EX_SIGNAL, so the
	   generic path below skipped the copy-out and warned once --
	   after which every further such call was silent. A function
	   that wrote through its open-array formal simply had no effect
	   on the caller's array, which is what `sv_open_array_copy_back'
	   pins for both the task and the function spelling. */
      if (ivl_expr_type(actual) == IVL_EX_ARRAY
	  && ivl_expr_signal(actual)
	  && ivl_signal_dimensions(ivl_expr_signal(actual)) > 0
	  && (ivl_signal_data_type(port) == IVL_VT_DARRAY
	      || ivl_signal_data_type(port) == IVL_VT_QUEUE)) {
	    ivl_signal_t asig = ivl_expr_signal(actual);
	    unsigned kind;
	    if (uarray_container_kind_(asig, &kind, ivl_expr_file(actual),
				       ivl_expr_lineno(actual))) {
		  draw_copy_out_load(port, "obj");
		  note_array_signal_use(asig);
		  emit_store_arr_dar_(asig, kind);
	    }
	    return;
      }

      /* A bit formal passed a whole logic variable is wrapped in a
	 two-state conversion for copy-in. The wrapper is not the copy-out
	 destination: copy back to its original variable. */
      if (ivl_expr_type(actual) == IVL_EX_UNARY
	  && ivl_expr_opcode(actual) == '2'
	  && ivl_signal_data_type(port) == IVL_VT_BOOL
	  && ivl_expr_width(actual) == ivl_signal_width(port)) {
	ivl_expr_t source = ivl_expr_oper1(actual);
	ivl_signal_t source_sig = source
	  && ivl_expr_type(source) == IVL_EX_SIGNAL
	  ? ivl_expr_signal(source) : 0;
	if (source_sig && ivl_signal_dimensions(source_sig) == 0
	    && !ivl_expr_oper1(source)
	    && ivl_expr_width(source) == ivl_expr_width(actual)
	    && (ivl_signal_data_type(source_sig) == IVL_VT_LOGIC
	        || ivl_signal_data_type(source_sig) == IVL_VT_BOOL)
	    && ivl_signal_width(source_sig) == ivl_signal_width(port))
	  actual = source;
      }

      if (!function_argument_actual_signal_(actual, &sig, &word)) {
	    /* Phase 63b/B6: surface the file:line of the call site so
	       users can find and rewrite affected callers.  The runtime
	       behavior is unchanged — the copy-out is still silently
	       skipped — but the diagnostic is now actionable. */
	    if (!warned_unsupported_copy_out) {
		  const char*f = ivl_expr_file(actual);
		  unsigned ln = ivl_expr_lineno(actual);
		  fprintf(stderr,
		          "%s:%u: warning: Skipping unsupported function copy-out"
		          " argument for `%s' (further similar warnings"
		          " suppressed)\n",
		          f ? f : "<unknown>", ln,
		          ivl_signal_basename(port));
		  warned_unsupported_copy_out = 1;
	    }
	    return;
      }

      dtype = ivl_signal_data_type(port);

      if (word && (ivl_signal_dimensions(sig) == 0)) {
	    if (!warned_unsupported_copy_out) {
		  fprintf(stderr,
		          "Warning: Skipping unsupported function copy-out select for %s"
		          " (further similar warnings suppressed)\n",
		          ivl_signal_basename(port));
		  warned_unsupported_copy_out = 1;
	    }
	    return;
      }

      if (word) {
	    unsigned ix = allocate_word();
	    draw_eval_expr_into_integer(word, ix);
	    note_array_signal_use(sig);
	    switch (dtype) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  draw_copy_out_load(port, "vec4");
		  if (ivl_signal_width(sig) != ivl_signal_width(port))
			fprintf(vvp_out, "    %%pad/%s %u;\n",
				ivl_signal_signed(port) ? "s" : "u",
				ivl_signal_width(sig));
		  if (ivl_signal_data_type(sig) == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		  fprintf(vvp_out, "    %%store/vec4a v%p, %u, 0;\n", sig, ix);
		  break;
		case IVL_VT_REAL:
		  draw_copy_out_load(port, "real");
		  fprintf(vvp_out, "    %%store/reala v%p, %u;\n", sig, ix);
		  break;
		case IVL_VT_STRING:
		  draw_copy_out_load(port, "str");
		  fprintf(vvp_out, "    %%store/stra v%p, %u;\n", sig, ix);
		  break;
		case IVL_VT_CLASS:
		case IVL_VT_DARRAY:
		case IVL_VT_QUEUE:
		case IVL_VT_NO_TYPE:
		  draw_copy_out_load(port, "obj");
		  draw_copy_out_container_value_(port, actual);
		  fprintf(vvp_out, "    %%store/obja v%p, %u;\n", sig, ix);
		  break;
		default:
		  if (!warned_unsupported_copy_out) {
			fprintf(stderr,
			        "Warning: Unsupported function copy-out type %d for %s"
			        " (further similar warnings suppressed)\n",
			        dtype, ivl_signal_basename(port));
			warned_unsupported_copy_out = 1;
		  }
		  break;
	    }
	    clr_word(ix);
	    return;
      }

      switch (dtype) {
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    draw_copy_out_load(port, "vec4");
	    if (ivl_signal_width(sig) != ivl_signal_width(port))
		  fprintf(vvp_out, "    %%pad/%s %u;\n",
			  ivl_signal_signed(port) ? "s" : "u",
			  ivl_signal_width(sig));
	    if (ivl_signal_data_type(sig) == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    if (signal_is_return_value(sig))
		  fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n",
			  ivl_signal_width(sig));
	    else
		  fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
			  sig, ivl_signal_width(sig));
	    break;
	  case IVL_VT_REAL:
	    draw_copy_out_load(port, "real");
	    if (signal_is_return_value(sig))
		  fprintf(vvp_out, "    %%ret/real 0;\n");
	    else
		  fprintf(vvp_out, "    %%store/real v%p_0;\n", sig);
	    break;
	  case IVL_VT_STRING:
	    draw_copy_out_load(port, "str");
	    if (signal_is_return_value(sig))
		  fprintf(vvp_out, "    %%ret/str 0;\n");
	    else
		  fprintf(vvp_out, "    %%store/str v%p_0;\n", sig);
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    draw_copy_out_load(port, "obj");
	    draw_copy_out_container_value_(port, actual);
	    fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
	    break;
	  default:
	    if (!warned_unsupported_copy_out) {
		  fprintf(stderr,
		          "Warning: Unsupported function copy-out type %d for %s"
		          " (further similar warnings suppressed)\n",
		          dtype, ivl_signal_basename(port));
		  warned_unsupported_copy_out = 1;
	    }
	    break;
      }
}

static void draw_copy_out_function_argument(ivl_signal_t port, ivl_expr_t actual)
{
      ivl_scope_t scope = ivl_signal_scope(port);
      if (ivl_scope_is_auto(scope))
            fprintf(vvp_out, "    %%copyout/enter S_%p;\n", scope);
      draw_copy_out_function_argument_impl(port, actual);
      if (ivl_scope_is_auto(scope))
            fprintf(vvp_out, "    %%copyout/leave;\n");
}

/* Finish one receiver-selected virtual-interface task branch.  The frontend
 * keeps each caller actual in the candidate row, so output/inout values are
 * copied from the concrete physical method's formal only after that method
 * returns. A directly nameable ref actual was bound before the call and needs
 * no copy; a ref companion uses the ordinary copy-out path. */
int draw_vif_statement_output_arguments(ivl_scope_t scope,
					unsigned port_base,
					unsigned argc,
					ivl_expr_t const*argv)
{
      int errors = 0;

      if (!scope || (argc && !argv)
	  || port_base > ivl_scope_ports(scope)
	  || argc > ivl_scope_ports(scope) - port_base)
	    return 1;

      for (unsigned idx = 0 ; idx < argc ; idx += 1) {
	    ivl_signal_t port = ivl_scope_port(scope, port_base + idx);
	    ivl_signal_port_t direction = port
		  ? ivl_signal_port(port) : IVL_SIP_NONE;
	    if (!port) {
		  errors += 1;
		  continue;
	    }
	    if (!argv[idx]) {
		  if (direction == IVL_SIP_OUTPUT
		      || direction == IVL_SIP_INOUT
		      || direction == IVL_SIP_REF)
			errors += 1;
		  continue;
	    }
	    if (direction == IVL_SIP_REF) {
		  /* A selected const-ref actual may use a companion because the
		     reference ABI cannot name the subobject directly. It is copied
		     in by the preamble, but const ref is input-only and must never
		     publish the companion back to the caller. */
		  if (ivl_signal_const(port))
			continue;
		  if (ref_actual_is_nameable_(argv[idx])
		      || ref_actual_is_bound_property_(port, argv[idx]))
			continue;
	    } else if (direction != IVL_SIP_OUTPUT
		       && direction != IVL_SIP_INOUT) {
		  continue;
	    }
	    draw_copy_out_function_argument(port, argv[idx]);
      }

      return errors;
}

static void draw_copy_out_function_arguments(ivl_expr_t expr)
{
      ivl_scope_t def = ivl_expr_def(expr);
      unsigned idx;

      assert(ivl_expr_parms(expr) == (ivl_scope_ports(def)-1));
      for (idx = 0 ; idx < ivl_expr_parms(expr) ; idx += 1) {
	    ivl_signal_t port = ivl_scope_port(def, idx+1);
	    ivl_signal_port_t port_type = ivl_signal_port(port);

	      /* A bound ref formal needs no copy-out -- writes through it
		 already landed in the caller's variable. One bound to a
		 companion does: reading the formal reads the companion,
		 so the ordinary copy-out is what puts it back. */
	    if (port_type == IVL_SIP_REF) {
	  if (ivl_signal_const(port))
		continue;
	  if (ref_actual_is_nameable_(ivl_expr_parm(expr, idx))
	      || ref_actual_is_bound_property_(port, ivl_expr_parm(expr, idx))
	      || ref_actual_is_static_array_word_(port,
						   ivl_expr_parm(expr, idx)))
		continue;
	    } else if ((port_type != IVL_SIP_OUTPUT) &&
		       (port_type != IVL_SIP_INOUT)) {
		  continue;
	    }

	    draw_copy_out_function_argument(port, ivl_expr_parm(expr, idx));
      }
}

static void draw_ufunc_preamble(ivl_expr_t expr, int retained_receiver)
{
      ivl_scope_t def = ivl_expr_def(expr);
      unsigned first_unbound_parm = 0;

        /* Allocate storage for an automatic function, or for only the
           explicitly automatic declarations in a static function. */
      if (scope_needs_call_frame(def)) {
            fprintf(vvp_out, "    %%alloc S_%p;\n", def);
      }

	/* A class method's first actual is its implicit `this' handle.  Bind
	 * that handle before evaluating user arguments.  A default argument is
	 * elaborated in the method's scope and may call another method or read a
	 * property through `this' (IEEE 1800-2017 13.5.3).  The old generic
	 * two-pass sequence evaluated every argument first and did not store
	 * `this' until afterwards, so such a default read a stale/null object
	 * from the callee frame.  Automatic class-method frames make this early
	 * store safe from nested calls; explicit actuals retain their existing
	 * left-to-right evaluation order. */
      if (ivl_expr_parms(expr) > 0 && ivl_scope_ports(def) > 1) {
	    ivl_signal_t this_port = ivl_scope_port(def, 1);
	    const char*name = this_port ? ivl_signal_basename(this_port) : 0;
	    if (name && strcmp(name, "@") == 0) {
		  if (retained_receiver)
			fprintf(vvp_out, "    %%dup/obj/ref; retained function receiver\n");
		  else draw_eval_function_argument(this_port, ivl_expr_parm(expr, 0));
		  draw_send_function_argument(this_port, ivl_expr_parm(expr, 0));
		  first_unbound_parm = 1;
	    }
      }

      assert(ivl_expr_parms(expr) == (ivl_scope_ports(def)-1));
      {
            unsigned argc = ivl_expr_parms(expr) - first_unbound_parm;
            ivl_expr_t*argv = argc
                  ? calloc(argc, sizeof(ivl_expr_t)) : 0;
            unsigned idx;
            if (argc && !argv) {
                  fprintf(stderr,
                          "vvp.tgt error: unable to allocate argument list "
                          "for %s\n",
                          ivl_scope_name(def));
                  vvp_errors += 1;
            } else {
                  for (idx = 0 ; idx < argc ; idx += 1)
                        argv[idx] = ivl_expr_parm(
                              expr, first_unbound_parm + idx);
                  vvp_errors += draw_function_input_arguments(
                        def, first_unbound_parm + 1, argc, argv);
            }
            free(argv);
      }

	/* Call the function */
      const char* scope_name = ivl_scope_name(def);
      if (!scope_name) {
	    fprintf(stderr, "Error: NULL scope name in draw_ufunc_preamble\n");
	    return;
      }
      const char* mangled = vvp_mangle_id(scope_name);
      if (!mangled) {
	    fprintf(stderr, "Error: NULL mangled name for scope %s\n", scope_name);
	    return;
      }
      note_td_reference(mangled);
      unsigned super_call = ivl_expr_is_super_call(expr);
      /* Only dispatch virtually for methods declared with "virtual" keyword. */
      unsigned use_virtual = !super_call && ivl_scope_is_virtual_method(def);

      /* Use the function scope's return type as the authoritative opcode
       * selector. The call-site expression type (ivl_expr_value) can be
       * stale when the called function is in a parameterized class whose
       * type parameter wasn't resolved at the time the default-argument
       * NetEUFunc was elaborated (e.g. trigger(T data=get_default_data())
       * compiled before T was bound to uvm_object). The scope's func_type
       * is set from the return-signal data_type() at dll_target export time,
       * which always reflects the finally-resolved type. */
      ivl_variable_type_t call_type = ivl_expr_value(expr);
      ivl_variable_type_t scope_type = ivl_scope_func_type(def);
      if ((call_type == IVL_VT_LOGIC || call_type == IVL_VT_BOOL)
          && (scope_type == IVL_VT_CLASS || scope_type == IVL_VT_DARRAY
              || scope_type == IVL_VT_QUEUE || scope_type == IVL_VT_NO_TYPE
              || scope_type == IVL_VT_STRING || scope_type == IVL_VT_REAL)) {
	    call_type = scope_type;
      }

	/* A function whose return type is an unpacked array delivers its
	   result through the emitted return-array signal, not through the
	   %ret machinery (which has no array representation). Call it like a
	   void function; the caller copies the words out of the return array
	   after the call, before the callee frame is freed. */
      {
	    ivl_signal_t retsig = ivl_scope_port(def, 0);
	    if (retsig && ivl_signal_dimensions(retsig) > 0)
		  call_type = IVL_VT_VOID;
      }

      switch (call_type) {
	  case IVL_VT_VOID:
	    fprintf(vvp_out, "    %%callf/void%s TD_%s",
		    use_virtual ? "/v" : "", mangled);
	    fprintf(vvp_out, ", S_%p;\n", def);
	    fflush(vvp_out);
	    break;
	  case IVL_VT_REAL:
	    fprintf(vvp_out, "    %%callf/real%s TD_%s",
		    use_virtual ? "/v" : "", mangled);
	    fprintf(vvp_out, ", S_%p;\n", def);
	    fflush(vvp_out);
	    break;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    fprintf(vvp_out, "    %%callf/vec4%s TD_%s",
		    use_virtual ? "/v" : "", mangled);
	    fprintf(vvp_out, ", S_%p;\n", def);
	    fflush(vvp_out);
	    break;
	  case IVL_VT_STRING:
	    fprintf(vvp_out, "    %%callf/str%s TD_%s",
		    use_virtual ? "/v" : "", mangled);
	    fprintf(vvp_out, ", S_%p;\n", def);
	    fflush(vvp_out);
	    break;
	  case IVL_VT_CLASS:
	  case IVL_VT_DARRAY:
	  case IVL_VT_QUEUE:
	  case IVL_VT_NO_TYPE:
	    fprintf(vvp_out, "    %%callf/obj%s TD_%s",
		    use_virtual ? "/v" : "", mangled);
	    fflush(vvp_out); // Flush immediately in case of crash
	    fprintf(vvp_out, ", S_%p;\n", def);
	    fflush(vvp_out); // Flush immediately in case of crash
	    break;
	  default:
	    fprintf(vvp_out, "    %%fork%s TD_%s",
		    use_virtual ? "/v" : "", mangled);
	    fprintf(vvp_out, ", S_%p;\n", def);
	    fprintf(vvp_out, "    %%join;\n");
	    fflush(vvp_out);
	    break;
      }
}

static void draw_ufunc_epilogue(ivl_expr_t expr)
{
      ivl_scope_t def = ivl_expr_def(expr);

      draw_copy_out_function_arguments(expr);

        /* Release this invocation's automatic declarations. */
      if (scope_needs_call_frame(def)) {
            fprintf(vvp_out, "    %%free S_%p;\n", def);
            fflush(vvp_out);
      }
}

/*
 * A call to a user defined function generates a result that is the
 * result of this expression.
 *
 * The result of the function is placed by the function execution into
 * a signal within the scope of the function that also has a basename
 * the same as the function. The ivl_target API handled the result
 * mapping already, and we get the name of the result signal as
 * parameter 0 of the function definition.
 */

void draw_ufunc_vec4(ivl_expr_t expr)
{

	/* Take in arguments to function and call function code. */
      draw_ufunc_preamble(expr, 0);

      draw_ufunc_epilogue(expr);
}

void draw_ufunc_vec4_retained_receiver(ivl_expr_t expr)
{
      draw_ufunc_preamble(expr, 1);
      draw_ufunc_epilogue(expr);
}

void draw_ufunc_real(ivl_expr_t expr)
{

	/* Take in arguments to function and call the function code. */
      draw_ufunc_preamble(expr, 0);

	/* The %callf/real function emitted by the preamble leaves
	   the result in the stack for us. */

      draw_ufunc_epilogue(expr);
}

void draw_ufunc_string(ivl_expr_t expr)
{

	/* Take in arguments to function and call the function code. */
      draw_ufunc_preamble(expr, 0);

	/* The %callf/str function emitted by the preamble leaves
	   the result in the stack for us. */

      draw_ufunc_epilogue(expr);
}

void draw_ufunc_object(ivl_expr_t expr)
{
      ivl_scope_t def = ivl_expr_def(expr);
      ivl_signal_t retval = ivl_scope_port(def, 0);
      ivl_variable_type_t ret_type = ivl_signal_data_type(retval);
      ivl_variable_type_t want_type = ivl_expr_value(expr);
      const char*def_name = ivl_scope_name(def);
      int force_object_return = 0;
      if (def_name && strstr(def_name, "uvm_queue.get"))
            force_object_return = 1;

	/* Take in arguments to function and call the function code. */
      draw_ufunc_preamble(expr, 0);

      if (ret_type == IVL_VT_CLASS ||
          ret_type == IVL_VT_DARRAY ||
          ret_type == IVL_VT_QUEUE ||
          ret_type == IVL_VT_NO_TYPE ||
          want_type == IVL_VT_CLASS ||
          want_type == IVL_VT_DARRAY ||
          want_type == IVL_VT_QUEUE ||
          want_type == IVL_VT_NO_TYPE ||
          force_object_return) {
	      /* Load object-like return values into the object stack. */
	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", retval);
      } else {
	    /* draw_eval_object() was asked to evaluate a non-object
	     * function result. Drain any leftover call result from
	     * the type stack, then push null-object fallback. */
	    switch (ivl_expr_value(expr)) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  fprintf(vvp_out, "    %%pop/vec4 1;\n");
		  break;
		case IVL_VT_REAL:
		  fprintf(vvp_out, "    %%pop/real 1;\n");
		  break;
		case IVL_VT_STRING:
		  fprintf(vvp_out, "    %%pop/str 1;\n");
		  break;
		default:
		  break;
	    }
	    fprintf(stderr,
		    "Warning: draw_ufunc_object: function %s returns non-object type %d; using null fallback\n",
		    ivl_scope_name(def), ret_type);
	    fprintf(vvp_out, "    %%null; ; non-object ufunc fallback\n");
      }

      draw_ufunc_epilogue(expr);
}

/* Find the rightmost destination-dimension suffix that contains exactly
 * word_count words. An unpacked-array function result can be assigned to a
 * whole array or to a fixed-prefix slice, and the latter is represented by
 * the original signal plus a flat base word. */
static unsigned uarray_suffix_first_dim_(ivl_signal_t sig,
                                         unsigned word_count)
{
      unsigned dims = ivl_signal_dimensions(sig);
      unsigned long long count = 1;
      unsigned dim = dims;

      while (dim > 0) {
            int msb;
            int lsb;
            unsigned long long width;

            dim -= 1;
            msb = ivl_signal_array_dim_msb(sig, dim);
            lsb = ivl_signal_array_dim_lsb(sig, dim);
            width = (msb >= lsb) ? (unsigned long long)(msb-lsb+1)
                                 : (unsigned long long)(lsb-msb+1);
            count *= width;
            if (count == word_count)
                  return dim;
            if (count > word_count)
                  break;
      }

      return dims;
}

/* Convert a left-to-right (declared-order) flat position within a dimension
 * suffix to the canonical low-bound-based word offset used by vvp storage.
 * Decompose from the rightmost dimension because that is the fastest-moving
 * dimension in both orderings. */
static unsigned uarray_decl_to_canonical_(ivl_signal_t sig,
                                          unsigned first_dim,
                                          unsigned declared_pos)
{
      unsigned dim = ivl_signal_dimensions(sig);
      unsigned canonical = 0;
      unsigned stride = 1;

      while (dim > first_dim) {
            int msb;
            int lsb;
            unsigned width;
            unsigned declared_coord;
            unsigned canonical_coord;

            dim -= 1;
            msb = ivl_signal_array_dim_msb(sig, dim);
            lsb = ivl_signal_array_dim_lsb(sig, dim);
            width = (msb >= lsb) ? (unsigned)(msb-lsb+1)
                                 : (unsigned)(lsb-msb+1);
            declared_coord = declared_pos % width;
            declared_pos /= width;
            canonical_coord = (msb > lsb)
                  ? width-1-declared_coord : declared_coord;
            canonical += canonical_coord * stride;
            stride *= width;
      }

      assert(declared_pos == 0);
      return canonical;
}

/*
 * Call a function whose return type is an unpacked array and copy the
 * result into dst_sig starting at flat word dst_base (0 for a whole-array
 * target; a slice target's flat base word otherwise). The preamble calls
 * the function like a void function (see draw_ufunc_preamble); the function
 * body has stored the result words into its emitted return-array signal,
 * which remains readable here because the callee frame is not freed until
 * the epilogue below. Source and destination words are mapped independently
 * through declared order, as required when equivalent-sized ranges have
 * opposite directions (IEEE 1800-2017 7.6).
 */
void draw_ufunc_uarray(ivl_expr_t expr, ivl_signal_t dst_sig,
		       unsigned dst_base)
{
      ivl_scope_t def = ivl_expr_def(expr);
      ivl_signal_t retval = ivl_scope_port(def, 0);
      unsigned word_count = ivl_signal_array_count(retval);
      unsigned dst_first = uarray_suffix_first_dim_(dst_sig, word_count);
      unsigned idx;

      if (dst_first == ivl_signal_dimensions(dst_sig)) {
            fprintf(stderr, "draw_ufunc_uarray: error: return array of %s "
                    "does not match the destination array shape\n",
                    ivl_scope_name(def));
            vvp_errors += 1;
            return;
      }

      draw_ufunc_preamble(expr, 0);

      int ix = allocate_word();
      for (idx = 0 ; idx < word_count ; idx += 1) {
	    /* A function call may leave flag 4 set. Constant source words are
	     * valid independently of that prior conversion state. */
	    fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
	    unsigned src_word = uarray_decl_to_canonical_(retval, 0, idx);
	    unsigned dst_word = uarray_decl_to_canonical_(dst_sig,
						     dst_first, idx);
	    switch (ivl_signal_data_type(retval)) {
		case IVL_VT_BOOL:
		case IVL_VT_LOGIC:
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", ix,
			  src_word);
		  fprintf(vvp_out, "    %%load/vec4a v%p, %d;\n", retval, ix);
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n",
			  ix, dst_base + dst_word);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  fprintf(vvp_out, "    %%store/vec4a v%p, %d, 0;\n",
			  dst_sig, ix);
		  break;
		case IVL_VT_REAL:
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", ix,
			  src_word);
		  fprintf(vvp_out, "    %%load/ar v%p, %d;\n", retval, ix);
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n",
			  ix, dst_base + dst_word);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  fprintf(vvp_out, "    %%store/reala v%p, %d;\n",
			  dst_sig, ix);
		  break;
		case IVL_VT_STRING:
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n", ix,
			  src_word);
		  fprintf(vvp_out, "    %%load/stra v%p, %d;\n", retval, ix);
		  fprintf(vvp_out, "    %%ix/load %d, %u, 0;\n",
			  ix, dst_base + dst_word);
		  fprintf(vvp_out, "    %%flag_set/imm 4, 0;\n");
		  fprintf(vvp_out, "    %%store/stra v%p, %d;\n",
			  dst_sig, ix);
		  break;
		default:
		  fprintf(stderr, "draw_ufunc_uarray: sorry: unsupported "
			  "element type %d for unpacked-array return of %s\n",
			  ivl_signal_data_type(retval), ivl_scope_name(def));
		  break;
	    }
      }
      clr_word(ix);

      draw_ufunc_epilogue(expr);
}

/*
 * Call a function whose result is a fixed unpacked array and materialize
 * that result as dynamic-array storage on the object stack. Array methods on
 * arbitrary expressions and DPI open-array actuals use this form: the
 * function's automatic frame must remain live until the flat return storage
 * has been copied, so the ordinary object-return path cannot be used.
 */
void draw_ufunc_uarray_object(ivl_expr_t expr, int as_queue,
			      uint64_t queue_max_size)
{
      ivl_scope_t def = ivl_expr_def(expr);
      ivl_signal_t retval = ivl_scope_port(def, 0);
      ivl_variable_type_t dt = ivl_signal_data_type(retval);
      unsigned wid = ivl_signal_width(retval);
      unsigned kind;
      unsigned count;
      int base;
      int left;

      assert(retval);
      assert(ivl_signal_dimensions(retval) > 0);

      draw_ufunc_preamble(expr, 0);

      switch (dt) {
	  case IVL_VT_REAL:
	    kind = 0;
	    break;
	  case IVL_VT_STRING:
	    kind = VVP_ARRDAR_STRING;
	    break;
	  case IVL_VT_BOOL:
	  case IVL_VT_LOGIC:
	    if (wid == 0) wid = 1;
	    if (wid > VVP_ARRDAR_WIDTH_MAX) {
		  fprintf(stderr, "%s:%u: sorry: fixed-array materialization "
			  "supports integral widths up to %u bits\n",
			  ivl_expr_file(expr), ivl_expr_lineno(expr),
			  VVP_ARRDAR_WIDTH_MAX);
		  vvp_errors += 1;
		  fprintf(vvp_out, "    %%null; ; wide ufunc array\n");
		  draw_ufunc_epilogue(expr);
		  return;
	    }
	    kind = VVP_ARRDAR_WIDTH_KIND(wid)
		 | (ivl_signal_signed(retval) ? VVP_ARRDAR_SIGNED : 0u)
		 | ((dt == IVL_VT_LOGIC) ? VVP_ARRDAR_FOUR : 0u);
	    break;
	  case IVL_VT_CLASS:
	    kind = VVP_ARRDAR_OBJ;
	    break;
	  default:
	    fprintf(stderr, "%s:%u: sorry: unsupported element type %d in "
		    "an unpacked-array function result\n",
		    ivl_expr_file(expr), ivl_expr_lineno(expr), (int)dt);
	    vvp_errors += 1;
	    fprintf(vvp_out, "    %%null; ; unsupported ufunc array\n");
	    draw_ufunc_epilogue(expr);
	    return;
      }

      count = ivl_signal_array_count(retval);
      base = ivl_signal_array_base(retval);
      if (ivl_signal_array_addr_swapped(retval)) {
	    left = base + (int)count - 1;
	    kind |= VVP_ARRDAR_DESC;
      } else {
	    left = base;
      }
	/* A whole queue class property has no signal-backed destination for the
	 * ordinary %store/qobj copy path. Ask the marshaller for a real queue
	 * object so later queue-only mutations remain valid. Other object
	 * contexts intentionally retain dynamic-array storage. */
      if (ivl_signal_dimensions(retval) > 1) {
	    if (as_queue) {
		  fprintf(stderr, "%s:%u: sorry: a multidimensional fixed-array "
			  "function result cannot yet be materialized as a queue\n",
			  ivl_expr_file(expr), ivl_expr_lineno(expr));
		  vvp_errors += 1;
		  fprintf(vvp_out,
			  "    %%null; ; multidimensional ufunc queue\n");
	    } else {
		  emit_load_arr_dar_(retval, kind);
	    }
	    draw_ufunc_epilogue(expr);
	    return;
      }

      if (as_queue)
	    kind |= VVP_ARRDAR_QUEUE;

      note_array_signal_use(retval);
      if (as_queue) {
	    const unsigned marshal_max = queue_max_size > UINT32_MAX
		  ? 0 : (unsigned)queue_max_size;
	    fprintf(vvp_out, "    %%load/arr/dar v%p, %u, %u;\n",
		    retval, kind, marshal_max);
	    fprintf(vvp_out, "    %%container/layout/q %" PRIu64
		    "; exact fixed-array return queue layout\n",
		    queue_max_size);
      } else {
	    fprintf(vvp_out, "    %%load/arr/dar v%p, %u, %u;\n",
		    retval, kind, (unsigned)left);
      }
      draw_ufunc_epilogue(expr);
}
