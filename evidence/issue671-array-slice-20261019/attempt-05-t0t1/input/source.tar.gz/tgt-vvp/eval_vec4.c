/*
 * Copyright (c) 2013-2020 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

/*
 * This file includes functions for evaluating VECTOR expressions.
 */
# include  "vvp_priv.h"
# include  <string.h>
# include  <stdlib.h>
# include  <math.h>
# include  <assert.h>
# include  <stdbool.h>
# include  <inttypes.h>

static int number_trace_enabled_(void)
{
      static int enabled = -1;
      if (enabled < 0) {
            const char*env = getenv("IVL_VVP_NUM_TRACE");
            enabled = (env && *env && strcmp(env, "0") != 0) ? 1 : 0;
      }
      return enabled;
}

/* Size an unsigned result of known pushed width to the expression width. */
static void resize_vec4_wid_from_(unsigned pushed, unsigned wid)
{
      if (pushed != wid)
	    fprintf(vvp_out, "    %%pad/u %u;\n", wid);
}

void resize_vec4_wid(ivl_expr_t expr, unsigned wid)
{
      if (ivl_expr_width(expr) == wid)
	    return;

      if (ivl_expr_signed(expr))
	    fprintf(vvp_out, "    %%pad/s %u;\n", wid);
      else
	    fprintf(vvp_out, "    %%pad/u %u;\n", wid);
}

/*
 * Test if the draw_immediate_vec4 instruction can be used.
 */
int test_immediate_vec4_ok(ivl_expr_t re)
{
      const char*bits;
      unsigned idx;

      if (ivl_expr_type(re) != IVL_EX_NUMBER)
	    return 0;

      if (ivl_expr_width(re) <= 32)
	    return 1;

      bits = ivl_expr_bits(re);

      for (idx = 32 ; idx < ivl_expr_width(re) ; idx += 1) {
	    if (bits[idx] != '0')
		  return 0;
      }

      return 1;
}

static void make_immediate_vec4_words(ivl_expr_t re, unsigned long*val0p, unsigned long*valxp, unsigned*widp)
{
      unsigned long val0 = 0;
      unsigned long valx = 0;
      unsigned wid = ivl_expr_width(re);
      const char*bits = ivl_expr_bits(re);

      unsigned idx;

      for (idx = 0 ; idx < wid ; idx += 1) {
	    assert( ((val0|valx)&0x80000000UL) == 0UL );
	    val0 <<= 1;
	    valx <<= 1;
	    switch (bits[wid-idx-1]) {
		case '0':
		  break;
		case '1':
		  val0 |= 1;
		  break;
		case 'x':
		  val0 |= 1;
		  valx |= 1;
		  break;
		case 'z':
		  val0 |= 0;
		  valx |= 1;
		  break;
		default:
		  assert(0);
		  break;
	    }
      }

      *val0p = val0;
      *valxp = valx;
      *widp = wid;
}

void draw_immediate_vec4(ivl_expr_t re, const char*opcode)
{
      unsigned long val0, valx;
      unsigned wid;
      make_immediate_vec4_words(re, &val0, &valx, &wid);
      fprintf(vvp_out, "    %s %lu, %lu, %u;\n", opcode, val0, valx, wid);
}

static void draw_binary_vec4_arith(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      unsigned lwid = ivl_expr_width(le);
      unsigned rwid = ivl_expr_width(re);
      unsigned ewid = ivl_expr_width(expr);

      int is_power_op = ivl_expr_opcode(expr) == 'p' ? 1 : 0;

	/* The power operation differs from the other arithmetic operations
	   in that we only use the signed version of the operation if the
	   right hand operand (the exponent) is signed. */
      int signed_flag = (ivl_expr_signed(le) || is_power_op) && ivl_expr_signed(re) ? 1 : 0;
      const char*signed_string = signed_flag? "/s" : "";

	/* All the arithmetic operations handled here (except for the power
	   operation) require that the operands (and the result) be the same
	   width. We further assume that the core has not given us an operand
	   wider then the expression width. So pad operands as needed. */
      draw_eval_vec4(le);
      if (lwid != ewid) {
	    fprintf(vvp_out, "    %%pad/%c %u;\n", ivl_expr_signed(le)? 's' : 'u', ewid);
      }

	/* Special case: If the re expression can be collected into an
	   immediate operand, and the instruction supports it, then
	   generate an immediate instruction instead of the generic
	   version. */
      if (rwid==ewid && test_immediate_vec4_ok(re)) {
	    switch (ivl_expr_opcode(expr)) {
		case '+':
		  draw_immediate_vec4(re, "%addi");
		  return;
		case '-':
		  draw_immediate_vec4(re, "%subi");
		  return;
		case '*':
		  draw_immediate_vec4(re, "%muli");
		  return;
		default:
		  break;
	    }
      }

      draw_eval_vec4(re);
      if ((rwid != ewid) && !is_power_op) {
	    fprintf(vvp_out, "    %%pad/%c %u;\n", ivl_expr_signed(re)? 's' : 'u', ewid);
      }

      switch (ivl_expr_opcode(expr)) {
	  case '+':
	    fprintf(vvp_out, "    %%add;\n");
	    break;
	  case '-':
	    fprintf(vvp_out, "    %%sub;\n");
	    break;
	  case '*':
	    fprintf(vvp_out, "    %%mul;\n");
	    break;
	  case '/':
	    fprintf(vvp_out, "    %%div%s;\n", signed_string);
	    break;
	  case '%':
	    fprintf(vvp_out, "    %%mod%s;\n", signed_string);
	    break;
	  case 'p':
	    fprintf(vvp_out, "    %%pow%s;\n", signed_string);
	    break;

	  default:
	    assert(0);
	    break;
      }
}

static void draw_binary_vec4_bitwise(ivl_expr_t expr)
{
      draw_eval_vec4(ivl_expr_oper1(expr));
      draw_eval_vec4(ivl_expr_oper2(expr));

      switch (ivl_expr_opcode(expr)) {
	  case '&':
	    fprintf(vvp_out, "    %%and;\n");
	    break;
	  case '|':
	    fprintf(vvp_out, "    %%or;\n");
	    break;
	  case '^':
	    fprintf(vvp_out, "    %%xor;\n");
	    break;
	  case 'A': /* ~& */
	    fprintf(vvp_out, "    %%nand;\n");
	    break;
	  case 'O': /* ~| */
	    fprintf(vvp_out, "    %%nor;\n");
	    break;
	  case 'X': /* ~^ */
	    fprintf(vvp_out, "    %%xnor;\n");
	    break;
	  default:
	    assert(0);
	    break;
      }
}

static void draw_binary_vec4_compare_real(ivl_expr_t expr)
{
      draw_eval_real(ivl_expr_oper1(expr));
      draw_eval_real(ivl_expr_oper2(expr));

      switch (ivl_expr_opcode(expr)) {
	  case 'e': /* == */
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'n': /* != */
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%flag_inv 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  default:
	    assert(0);
      }
}

static int expr_is_string_like_(ivl_expr_t expr)
{
      if (ivl_expr_type(expr) == IVL_EX_SIGNAL) {
            ivl_signal_t sig = ivl_expr_signal(expr);
            return sig && (ivl_signal_data_type(sig) == IVL_VT_STRING);
      }

      return (ivl_expr_value(expr) == IVL_VT_STRING)
          || (ivl_expr_type(expr) == IVL_EX_STRING);
}

static void draw_binary_vec4_compare_string(ivl_expr_t expr)
{
      draw_eval_string(ivl_expr_oper1(expr));
      draw_eval_string(ivl_expr_oper2(expr));

      switch (ivl_expr_opcode(expr)) {
	  case 'e': /* == */
	    fprintf(vvp_out, "    %%cmp/str;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'n': /* != */
	    fprintf(vvp_out, "    %%cmp/str;\n");
	    fprintf(vvp_out, "    %%flag_inv 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  default:
	    assert(0);
      }
}

static void draw_binary_vec4_compare_class(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      if (ivl_expr_type(le) == IVL_EX_NULL) {
	    ivl_expr_t tmp = le;
	    le = re;
	    re = tmp;
      }

	/* Special case: If both operands are null, then the
	   expression has a constant value. */
      if (ivl_expr_type(le)==IVL_EX_NULL && ivl_expr_type(re)==IVL_EX_NULL) {
	    switch (ivl_expr_opcode(expr)) {
		case 'e': /* == */
		case 'E': /* === (IEEE 1800-2017/2023 8.4, 11.4.5) */
		  fprintf(vvp_out, "    %%pushi/vec4 1, 0, 1;\n");
		  break;
		case 'n': /* != */
		case 'N': /* !== */
		  fprintf(vvp_out, "    %%pushi/vec4 0, 0, 1;\n");
		  break;
		default:
		  assert(0);
		  break;
	    }
	    return;
      }

	/* A signal/variable is compared to null. Implement this with
	   the %test_nul statement, which peeks at the variable
	   contents directly. */
      if (ivl_expr_type(re)==IVL_EX_NULL && ivl_expr_type(le)==IVL_EX_SIGNAL) {
	    ivl_signal_t sig= ivl_expr_signal(le);

	    if (ivl_signal_dimensions(sig) == 0) {
		  fprintf(vvp_out, "    %%test_nul v%p_0;\n", sig);
	    } else {
		  ivl_expr_t word_ex = ivl_expr_oper1(le);
		  int word_ix = allocate_word();
		  draw_eval_expr_into_integer(word_ex, word_ix);
		  fprintf(vvp_out, "    %%test_nul/a v%p, %d;\n", sig, word_ix);
		  clr_word(word_ix);
	    }
	    if (ivl_expr_opcode(expr) == 'n'
	        || ivl_expr_opcode(expr) == 'N')
		  fprintf(vvp_out, "    %%flag_inv 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    return;
      }

      if (ivl_expr_type(re)==IVL_EX_NULL && ivl_expr_type(le)==IVL_EX_PROPERTY) {
	    ivl_signal_t sig = ivl_expr_signal(le);
	    unsigned pidx = ivl_expr_property_idx(le);
	    ivl_expr_t idx_expr = ivl_expr_oper1(le);
	    int idx = 0;
	    unsigned wid = ivl_expr_width(expr) ? ivl_expr_width(expr) : 1;

	      /* An ELEMENT of a container property is not the property
		 slot: the slot holds the container object, and
		 %test_nul/prop reads the slot. Testing `obj.arr[i] ==
		 null' that way reported the CONTAINER's nullness for
		 index 0 -- so a null element read as non-null and every
		 lazy-allocation guard silently failed open -- and
		 asserted in the runtime for index >= 1. Fall through to
		 the general object compare, which evaluates the element
		 properly. A fixed-size unpacked array property is
		 unaffected: there the index really is a slot index. */
	    if (property_is_indexed_container_expr_(le))
		  goto general_object_compare;

	    if (!property_is_object_expr_(le)) {
		  draw_eval_vec4(le);
		  fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", wid);
		  fprintf(vvp_out, "    %%cmp/u;\n");
		  if (ivl_expr_opcode(expr) == 'n'
                      || ivl_expr_opcode(expr) == 'N')
			fprintf(vvp_out, "    %%flag_inv 4;\n");
		  fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
		  return;
	    }

	      /* If the property has an array index, then evaluate it
		 into an index register. */
	    if ( idx_expr ) {
		  idx = allocate_word();
		  draw_eval_expr_into_integer(idx_expr, idx);
	    }

	    if (sig) {
		  fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
	    } else {
		  ivl_expr_t base_expr = ivl_expr_oper2(le);
		  draw_eval_object(base_expr);
	    }
	    fprintf(vvp_out, "    %%test_nul/prop %u, %d;\n", pidx, idx);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    if (ivl_expr_opcode(expr) == 'n'
                || ivl_expr_opcode(expr) == 'N')
		  fprintf(vvp_out, "    %%flag_inv 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");

	    if (idx != 0) clr_word(idx);
	    return;
      }

      /* General case: compare two class handle expressions by pushing
         both onto the object stack and using %cmp/obj for pointer identity. */
general_object_compare:
      draw_eval_object(le);
      draw_eval_object(re);
      fprintf(vvp_out, "    %%cmp/obj;\n");
      if (ivl_expr_opcode(expr) == 'n'
          || ivl_expr_opcode(expr) == 'N')
	    fprintf(vvp_out, "    %%flag_inv 4;\n");
      fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
}

static int container_value_(ivl_expr_t expr)
{
      return ivl_expr_value(expr) == IVL_VT_DARRAY
	  || ivl_expr_value(expr) == IVL_VT_QUEUE;
}

/* Both sides are dynamic arrays or queues; a `null' side keeps the legacy
 * handle comparison. */
static int container_equality_operands_(ivl_expr_t le, ivl_expr_t re)
{
      return (container_value_(le) || container_value_(re))
	  && ivl_expr_type(le) != IVL_EX_NULL
	  && ivl_expr_type(re) != IVL_EX_NULL;
}

static void draw_binary_vec4_compare(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      if ((ivl_expr_value(le) == IVL_VT_REAL)
	  || (ivl_expr_value(re) == IVL_VT_REAL)) {
	    draw_binary_vec4_compare_real(expr);
	    return;
      }

      if ((ivl_expr_value(le)==IVL_VT_STRING)
	  && (ivl_expr_value(re)==IVL_VT_STRING)) {
	    draw_binary_vec4_compare_string(expr);
	    return;
      }

      if ((ivl_expr_value(le)==IVL_VT_STRING)
	  && (ivl_expr_type(re)==IVL_EX_STRING)) {
	    draw_binary_vec4_compare_string(expr);
	    return;
      }

      if ((ivl_expr_type(le)==IVL_EX_STRING)
	  && (ivl_expr_value(re)==IVL_VT_STRING)) {
	    draw_binary_vec4_compare_string(expr);
	    return;
      }

      if ((ivl_expr_value(le)==IVL_VT_CLASS)
	  && (ivl_expr_value(re)==IVL_VT_CLASS)) {
	    draw_binary_vec4_compare_class(expr);
	    return;
      }

	/* Dynamic arrays and queues compare element-wise (IEEE 1800-2017/2023
	 * 11.4.5). The generic path below would cast each operand to
	 * "handle is non-null", so a == b was true for any two non-empty
	 * arrays. */
      if (container_equality_operands_(le, re)) {
	    char op = ivl_expr_opcode(expr);
	    if (op != 'e' && op != 'n' && op != 'E' && op != 'N') {
		  fprintf(stderr, "%s:%u: error: operator is not defined for "
			  "unpacked array operands.\n",
			  ivl_expr_file(expr), ivl_expr_lineno(expr));
		  vvp_errors += 1;
		  fprintf(vvp_out, "    %%pushi/vec4 1, 1, 1;\n");
		  return;
	    }
	    draw_eval_object(le);
	    draw_eval_object(re);
	    fprintf(vvp_out, "    %%cmp/cont;\n");
	    unsigned flag = (op == 'E' || op == 'N') ? 6 : 4;
	    if (op == 'n' || op == 'N')
		  fprintf(vvp_out, "    %%flag_inv %u;\n", flag);
	    fprintf(vvp_out, "    %%flag_get/vec4 %u;\n", flag);
	    return;
      }

      unsigned use_wid = ivl_expr_width(le);
      if (ivl_expr_width(re) > use_wid)
	    use_wid = ivl_expr_width(re);

      draw_eval_vec4(le);
      resize_vec4_wid(le, use_wid);

      draw_eval_vec4(re);
      resize_vec4_wid(re, use_wid);

      switch (ivl_expr_opcode(expr)) {
	  case 'e': /* == */
	    fprintf(vvp_out, "    %%cmp/e;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'n': /* != */
	    fprintf(vvp_out, "    %%cmp/ne;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'E': /* === */
	    fprintf(vvp_out, "    %%cmp/e;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 6;\n");
	    break;
	  case 'N': /* !== */
	    fprintf(vvp_out, "    %%cmp/ne;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 6;\n");
	    break;
	  case 'w': /* ==? */
	    fprintf(vvp_out, "    %%cmp/we;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'x': /* casex pattern comparison */
	    fprintf(vvp_out, "    %%cmp/x;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'z': /* casez pattern comparison */
	    fprintf(vvp_out, "    %%cmp/z;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  case 'W': /* !=? */
	    fprintf(vvp_out, "    %%cmp/wne;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    break;
	  default:
	    assert(0);
      }
}

/*
 * Handle the logical implication:
 *    <le> -> <re>
 * which is the same as the expression
 *    !<le> || <re>
 *
 */
static void draw_binary_vec4_limpl(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      /* The arguments should have alreacy been reduced. */
      assert(ivl_expr_width(le) == 1);
      assert(ivl_expr_width(re) == 1);

      draw_eval_vec4(le);
      fprintf(vvp_out, "    %%inv;\n");
      draw_eval_vec4(re);
      fprintf(vvp_out, "    %%or;\n");
}

static void draw_binary_vec4_lequiv(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

	/* The arguments should have already been reduced. */
      assert(ivl_expr_width(le) == 1);
      draw_eval_vec4(le);
      assert(ivl_expr_width(re) == 1);
      draw_eval_vec4(re);

      fprintf(vvp_out, "    %%xnor;\n");

      assert(ivl_expr_width(expr) == 1);
}

static void draw_binary_vec4_logical(ivl_expr_t expr, char op)
{
      const char *opcode;
      const char *jmp_type;

      switch (op) {
	  case 'a':
	    opcode = "and";
	    jmp_type = "0";
	    break;
	  case 'o':
	    opcode = "or";
	    jmp_type = "1";
	    break;
	  default:
	    assert(0);
	    break;
      }

      unsigned label_out = local_count++;

      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      /* Evaluate the left expression as a conditon and skip the right expression
       * if the left is false. */
      int flag = draw_eval_condition(le);
      fprintf(vvp_out, "    %%flag_get/vec4 %d;\n", flag);
      fprintf(vvp_out, "    %%jmp/%s T_%u.%u, %d;\n", jmp_type, thread_count,
	      label_out, flag);
      clr_flag(flag);
      /* Now push the right expression. Reduce to a single bit if necessary. */
      draw_eval_vec4(re);
      if (ivl_expr_width(re) > 1)
	    fprintf(vvp_out, "    %%or/r;\n");

      fprintf(vvp_out, "    %%%s;\n", opcode);

      fprintf(vvp_out, "T_%u.%u;\n", thread_count, label_out);
      if (ivl_expr_width(expr) > 1)
	    fprintf(vvp_out, "    %%pad/u %u;\n", ivl_expr_width(expr));
}

static void draw_binary_vec4_le_real(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      switch (ivl_expr_opcode(expr)) {
	  case '<':
	    draw_eval_real(le);
	    draw_eval_real(re);
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    break;

	  case 'L': /* <= */
	    draw_eval_real(le);
	    draw_eval_real(re);
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    fprintf(vvp_out, "    %%or;\n");
	    break;

	  case '>':
	    draw_eval_real(re);
	    draw_eval_real(le);
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    break;

	  case 'G': /* >= */
	    draw_eval_real(re);
	    draw_eval_real(le);
	    fprintf(vvp_out, "    %%cmp/wr;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    fprintf(vvp_out, "    %%or;\n");
	    break;

	  default:
	    assert(0);
	    break;
      }
}

static void draw_binary_vec4_le_string(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

      switch (ivl_expr_opcode(expr)) {
	  case '<':
	    draw_eval_string(le);
	    draw_eval_string(re);
	    fprintf(vvp_out, "    %%cmp/str;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    break;

	  case 'L': /* <= */
	    draw_eval_string(le);
	    draw_eval_string(re);
	    fprintf(vvp_out, "    %%cmp/str;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    fprintf(vvp_out, "    %%or;\n");
	    break;

	  case '>':
	    draw_eval_string(re);
	    draw_eval_string(le);
	    fprintf(vvp_out, "    %%cmp/str;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    break;

	  case 'G': /* >= */
	    draw_eval_string(re);
	    draw_eval_string(le);
	    fprintf(vvp_out, "    %%cmp/str;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    fprintf(vvp_out, "    %%or;\n");
	    break;

	  default:
	    assert(0);
	    break;
      }
}

static void draw_binary_vec4_le(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);
      ivl_expr_t tmp;

      if ((ivl_expr_value(le) == IVL_VT_REAL)
	  || (ivl_expr_value(re) == IVL_VT_REAL)) {
	    draw_binary_vec4_le_real(expr);
	    return;
      }

      char use_opcode = ivl_expr_opcode(expr);
      char s_flag = (ivl_expr_signed(le) && ivl_expr_signed(re)) ? 's' : 'u';

	/* If this is a > or >=, then convert it to < or <= by
	   swapping the operands. Adjust the opcode to match. */
      switch (use_opcode) {
	  case 'G':
	    tmp = le;
	    le = re;
	    re = tmp;
	    use_opcode = 'L';
	    break;
	  case '>':
	    tmp = le;
	    le = re;
	    re = tmp;
	    use_opcode = '<';
	    break;
      }

      if ((ivl_expr_value(le)==IVL_VT_STRING)
	  && (ivl_expr_value(re)==IVL_VT_STRING)) {
	    draw_binary_vec4_le_string(expr);
	    return;
      }

      if ((ivl_expr_value(le)==IVL_VT_STRING)
	  && (ivl_expr_type(re)==IVL_EX_STRING)) {
	    draw_binary_vec4_le_string(expr);
	    return;
      }

      if ((ivl_expr_type(le)==IVL_EX_STRING)
	  && (ivl_expr_value(re)==IVL_VT_STRING)) {
	    draw_binary_vec4_le_string(expr);
	    return;
      }

	/* NOTE: I think I would rather the elaborator handle the
	   operand widths. When that happens, take this code out. */

      unsigned use_wid = ivl_expr_width(le);
      if (ivl_expr_width(re) > use_wid)
	    use_wid = ivl_expr_width(re);

      draw_eval_vec4(le);
      resize_vec4_wid(le, use_wid);

      if (ivl_expr_width(re)==use_wid && test_immediate_vec4_ok(re)) {
	      /* Special case: If the right operand can be handled as
		 an immediate operand, then use that instead. */
	    char opcode[8];
	    snprintf(opcode, sizeof opcode, "%%cmpi/%c", s_flag);
	    draw_immediate_vec4(re, opcode);

      } else {
	    draw_eval_vec4(re);
	    resize_vec4_wid(re, use_wid);

	    fprintf(vvp_out, "    %%cmp/%c;\n", s_flag);
      }

      switch (use_opcode) {
	  case 'L':
	    fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    fprintf(vvp_out, "    %%or;\n");
	    break;
	  case '<':
	    fprintf(vvp_out, "    %%flag_get/vec4 5;\n");
	    break;
	  default:
	    assert(0);
	    break;
      }
}

static void draw_binary_vec4_lrs(ivl_expr_t expr)
{
      ivl_expr_t le = ivl_expr_oper1(expr);
      ivl_expr_t re = ivl_expr_oper2(expr);

	// Push the left expression onto the stack.
      draw_eval_vec4(le);

	// Calculate the shift amount into an index register.
      int use_index_reg = allocate_word();
      assert(use_index_reg >= 0);
      draw_eval_expr_into_integer(re, use_index_reg);

	// Emit the actual shift instruction. This will pop the top of
	// the stack and replace it with the result of the shift.
      switch (ivl_expr_opcode(expr)) {
	  case 'l': /* << */
	    fprintf(vvp_out, "    %%shiftl %d;\n", use_index_reg);
	    break;
	  case 'r': /* >> */
	    fprintf(vvp_out, "    %%shiftr %d;\n", use_index_reg);
	    break;
	  case 'R': /* >>> */
	    if (ivl_expr_signed(le))
		  fprintf(vvp_out, "    %%shiftr/s %d;\n", use_index_reg);
	    else
		  fprintf(vvp_out, "    %%shiftr %d;\n", use_index_reg);
	    break;
	  default:
	    assert(0);
	    break;
      }

      clr_word(use_index_reg);
}

static void draw_binary_vec4(ivl_expr_t expr)
{
      switch (ivl_expr_opcode(expr)) {
	  case 'a': /* Logical && */
	  case 'o': /* || (logical or) */
	    draw_binary_vec4_logical(expr, ivl_expr_opcode(expr));
	    break;

	  case '+':
	  case '-':
	  case '*':
	  case '/':
	  case '%':
	  case 'p': /* ** (power) */
	    draw_binary_vec4_arith(expr);
	    break;

	  case '&':
	  case '|':
	  case '^':
	  case 'A': /* NAND (~&) */
	  case 'O': /* NOR  (~|) */
	  case 'X': /* exclusive nor (~^) */
	    draw_binary_vec4_bitwise(expr);
	    break;

	  case 'e': /* == */
	  case 'E': /* === */
	  case 'n': /* != */
	  case 'N': /* !== */
	  case 'w': /* ==? */
	  case 'W': /* !=? */
	  case 'x': /* casex pattern comparison */
	  case 'z': /* casez pattern comparison */
	    draw_binary_vec4_compare(expr);
	    break;

	  case 'G': /* >= */
	  case 'L': /* <= */
	  case '>':
	  case '<':
	    draw_binary_vec4_le(expr);
	    break;

	  case 'l': /* << */
	  case 'r': /* >> */
	  case 'R': /* >>> */
	    draw_binary_vec4_lrs(expr);
	    break;

	  case 'q': /* -> (logical implication) */
	    draw_binary_vec4_limpl(expr);
	    break;

	  case 'Q': /* <-> (logical equivalence) */
	    draw_binary_vec4_lequiv(expr);
	    break;

	  default:
	    fprintf(stderr, "vvp.tgt error: unsupported binary (%c)\n",
		    ivl_expr_opcode(expr));
	    assert(0);
      }
}

/*
 * This handles two special cases:
 *   1) Making a large IVL_EX_NUMBER as an immediate value. In this
 *   case, start with a %pushi/vec4 to get the stack started, then
 *   continue with %concati/vec4 instructions to build that number
 *   up.
 *
 *   2) Concatenating a large IVL_EX_NUMBER to the current top of the
 *   stack. In this case, start with %concati/vec4 and continue
 *   generating %concati/vec4 instructions to finish up the large number.
 */
/* Push an all-X vec4 of the given width (chunked for wid > 32). Used by
   null-receiver property fallbacks for 4-state properties: reading a member
   of a nonexistent/nil object-backed element must yield the 4-state default
   value x, not 0 (IEEE 1800-2017 7.8.6/6.8). */
static void draw_pushi_all_x(unsigned wid)
{
      unsigned remaining = wid;
      int first = 1;
      while (remaining > 0) {
	    unsigned chunk = remaining > 32 ? 32 : remaining;
	    unsigned long mask = (chunk >= 32)
		  ? 0xffffffffUL : ((1UL << chunk) - 1);
	    if (first) {
		  fprintf(vvp_out, "    %%pushi/vec4 %lu, %lu, %u;\n",
			  mask, mask, chunk);
		  first = 0;
	    } else {
		  fprintf(vvp_out, "    %%concati/vec4 %lu, %lu, %u;\n",
			  mask, mask, chunk);
	    }
	    remaining -= chunk;
      }
}

static void draw_concat_number_vec4(ivl_expr_t expr, int as_concati)
{
      unsigned long val0 = 0;
      unsigned long valx = 0;
      unsigned wid = ivl_expr_width(expr);
      const char*bits = ivl_expr_bits(expr);

      if (number_trace_enabled_()) {
            fprintf(stderr,
                    "trace num: file=%s line=%u expr_type=%d expr_value=%d width=%u bits=",
                    ivl_expr_file(expr), ivl_expr_lineno(expr),
                    ivl_expr_type(expr), ivl_expr_value(expr), wid);
            if (bits && wid)
                  fwrite(bits, 1, wid, stderr);
            fprintf(stderr, " as_concati=%d\n", as_concati);
      }

      unsigned idx;
      int accum = 0;
      int count_pushi = as_concati? 1 : 0;

	/* Scan the literal bits, MSB first. */
      for (idx = 0 ; idx < wid ; idx += 1) {
	    val0 <<= 1;
	    valx <<= 1;
	    switch (bits[wid-idx-1]) {
		case '0':
		  break;
		case '1':
		  val0 |= 1;
		  break;
		case 'x':
		  val0 |= 1;
		  valx |= 1;
		  break;
		case 'z':
		  val0 |= 0;
		  valx |= 1;
		  break;
		default:
		  assert(0);
		  break;
	    }
	    accum += 1;

	      /* Collect as many bits as can be written by a single
		 %pushi/vec4 instruction. This may be more than 32 if
		 the higher bits are zero, but if the currently
		 accumulated value fills what a %pushi/vec4 can do,
		 then write it out, generate a %concat/vec4, and set
		 up to handle more bits. */
	    if ( (val0|valx) & 0x80000000UL ) {
		  if (count_pushi) {
			fprintf(vvp_out, "    %%concati/vec4 %lu, %lu, %d;\n",
				val0, valx, accum);

		  } else {
			fprintf(vvp_out, "    %%pushi/vec4 %lu, %lu, %d;\n",
				val0, valx, accum);
		  }

		  accum = 0;
		  val0 = 0;
		  valx = 0;

		  count_pushi += 1;
	    }
      }

      if (accum) {
	    if (count_pushi) {
		  fprintf(vvp_out, "    %%concati/vec4 %lu, %lu, %d;\n",
			  val0, valx, accum);
	    } else {
		  fprintf(vvp_out, "    %%pushi/vec4 %lu, %lu, %d;\n",
			  val0, valx, accum);
	    }
      }
}

static void draw_concat_vec4(ivl_expr_t expr)
{
	/* Repeat the concatenation this many times to make a
	   super-concatenation. */
      unsigned repeat = ivl_expr_repeat(expr);
	/* This is the number of expressions that go into the
	   concatenation. */
      unsigned num_sube = ivl_expr_parms(expr);
      unsigned sub_idx = 0;
      ivl_expr_t sube;

      assert(num_sube > 0);

	/* Start with the most-significant bits. */
      sube = ivl_expr_parm(expr, sub_idx);
      draw_eval_vec4(sube);
	/* Evaluate, but skip any zero replication expressions at the
	 * head of this concatenation. */
      while ((ivl_expr_type(sube) == IVL_EX_CONCAT) &&
             (ivl_expr_repeat(sube) == 0)) {
	    fprintf(vvp_out, "    %%pop/vec4 1; skip zero replication\n");
	    sub_idx += 1;
	    sube = ivl_expr_parm(expr, sub_idx);
	    draw_eval_vec4(sube);
      }

      for ( sub_idx += 1 ; sub_idx < num_sube ; sub_idx += 1) {
	      /* Concatenate progressively lower parts. */
	    sube = ivl_expr_parm(expr, sub_idx);

	      /* Special case: The next expression is a NUMBER that
		 can be concatenated using %concati/vec4
		 instructions. */
	    if (ivl_expr_type(sube) == IVL_EX_NUMBER) {
		  draw_concat_number_vec4(sube, 1);
		  continue;
	    }

	    draw_eval_vec4(sube);
	      /* Evaluate, but skip any zero replication expressions in the
	       * rest of this concatenation. */
	    if ((ivl_expr_type(sube) == IVL_EX_CONCAT) &&
	        (ivl_expr_repeat(sube) == 0)) {
		  fprintf(vvp_out, "    %%pop/vec4 1; skip zero replication\n");
		  continue;
	    }
	    fprintf(vvp_out, "    %%concat/vec4; draw_concat_vec4\n");
      }

      if (repeat > 1) {
	    fprintf(vvp_out, "    %%replicate %u;\n", repeat);
      }
}

/*
 * Push a number into the vec4 stack using %pushi/vec4
 * instructions. The %pushi/vec4 instruction can only handle up to 32
 * non-zero bits, so if there are more than that, then generate
 * multiple %pushi/vec4 statements, and use %concat/vec4 statements to
 * concatenate the vectors into the desired result.
 */
static void draw_number_vec4(ivl_expr_t expr)
{
      draw_concat_number_vec4(expr, 0);
}

static void draw_property_vec4(ivl_expr_t expr)
{
      ivl_signal_t sig = ivl_expr_signal(expr);
      ivl_expr_t idx_expr = ivl_expr_oper1(expr);
      ivl_expr_t base_expr = ivl_expr_oper2(expr);
      unsigned lab_null = local_count++;
      unsigned lab_out = local_count++;
      int idx_word = 0;
      int idx_x_flag = -1;
      int idx_in_range_flag = -1;
      int queue_indexed = property_is_indexed_queue_expr_(expr);
      int assoc_indexed = property_is_assoc_indexed_expr_(expr);
      int darray_indexed = property_is_indexed_darray_expr_(expr);
      unsigned pidx = ivl_expr_property_idx(expr);
      ivl_type_t declared_prop_type = property_expr_type_(expr);

      if (idx_expr && !queue_indexed && !assoc_indexed) {
	    idx_word = allocate_word();
	    if (property_selects_fixed_uarray_slot_(expr))
		  draw_fixed_uarray_slot_index_(idx_expr, declared_prop_type,
					       idx_word, &idx_x_flag,
					       &idx_in_range_flag);
	    else
		  draw_eval_expr_into_integer(idx_expr, idx_word);
      }

      if (sig) {
	    fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
      } else if (base_expr && ivl_expr_type(base_expr) == IVL_EX_NULL
                 && !event_expr_recipe_active()) {
	      /* Compile-progress fallback: null receiver property access
	         yields all-zero vector value. */
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", ivl_expr_width(expr));
	    if (idx_word) clr_word(idx_word);
	    if (idx_x_flag >= 0) clr_flag(idx_x_flag);
	    if (idx_in_range_flag >= 0) clr_flag(idx_in_range_flag);
	    return;
      } else {
	    draw_eval_object(base_expr);
      }
      /* Unlike a null comparison, this guard precedes a property read.
         Diagnose it inside observer recipes, including called functions. */
      fprintf(vvp_out, "    %%test_nul/obj/prop;\n");
      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
      if (idx_x_flag >= 0) {
	    fprintf(vvp_out,
		    "    %%jmp/1xz T_%u.%u, %d; invalid fixed property slot\n",
		    thread_count, lab_null, idx_x_flag);
	    fprintf(vvp_out,
		    "    %%jmp/0xz T_%u.%u, %d; fixed property slot out of range\n",
		    thread_count, lab_null, idx_in_range_flag);
      }
      if (assoc_indexed) {
            const char*key_kind;
	    fprintf(vvp_out, "    %%prop/obj %u, 0; eval_assoc_property\n", pidx);
            key_kind = draw_eval_assoc_key_(idx_expr, 0);
	    fprintf(vvp_out, "    %%aa/load/v/%s %u;\n", key_kind, ivl_expr_width(expr));
	    if (ivl_expr_value(expr) == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    fprintf(vvp_out, "    %%pop/obj 2, 0;\n");
	      } else if (queue_indexed) {
		    if (!emit_property_queue_last_index_(expr, pidx, 3))
			  draw_eval_expr_into_integer(idx_expr, 3);
		    fprintf(vvp_out, "    %%prop/obj %u, 0; eval_queue_property\n", pidx);
		    fprintf(vvp_out, "    %%load/qo/v %u;\n", ivl_expr_width(expr));
		    if (ivl_expr_value(expr) == IVL_VT_BOOL)
			  fprintf(vvp_out, "    %%cast2;\n");
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	      } else if (darray_indexed && idx_word) {
		    /* darray property element read: push darray as object, load element.
		     * A darray PROPERTY that has never been sized/`new[]`-ed is nil --
		     * not merely an empty vvp_darray -- so %load/dar/obj/vec4 has no
		     * element width to fall back on and leaves a 0-width value on the
		     * stack. Every other read path in this function (assoc/queue/the
		     * null-receiver fallback below) always yields a value already
		     * padded to ivl_expr_width(expr); pad this one the same way so a
		     * nil/out-of-range element read reads as a defined X/0 of the
		     * right width instead of crashing %store/vec4 downstream. */
		    fprintf(vvp_out, "    %%prop/obj %u, 0;\n", pidx);
		    fprintf(vvp_out, "    %%load/dar/obj/vec4 %d;\n", idx_word);
		    fprintf(vvp_out, "    %%pad/u %u;\n", ivl_expr_width(expr));
		    fprintf(vvp_out, "    %%pop/obj 1, 0;\n"); /* pop darray */
	      } else if (idx_word)
	    fprintf(vvp_out, "    %%prop/v/i %u, %d;\n", pidx, idx_word);
      else
	    fprintf(vvp_out, "    %%prop/v %u;\n", pidx);
      if (!assoc_indexed && !queue_indexed)
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n"); /* pop cobject */
      fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
      fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
      if (ivl_expr_value(expr) == IVL_VT_LOGIC)
	    draw_pushi_all_x(ivl_expr_width(expr));
      else
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", ivl_expr_width(expr));
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
      if (idx_word)
	    clr_word(idx_word);
      if (idx_x_flag >= 0)
	    clr_flag(idx_x_flag);
      if (idx_in_range_flag >= 0)
	    clr_flag(idx_in_range_flag);
}

/*
 * True when evaluating EXPR can neither write a variable nor call
 * anything. Such an expression may be evaluated before a load that it
 * would otherwise follow without changing either value. This is a
 * conservative whitelist: any expression kind or operator it does not
 * name is treated as possibly effectful.
 */
static int expr_is_effect_free_(ivl_expr_t expr)
{
      if (expr == 0)
	    return 1;

      switch (ivl_expr_type(expr)) {
	  case IVL_EX_NUMBER:
	  case IVL_EX_ULONG:
	    return 1;

	  case IVL_EX_SIGNAL:
	    if (ivl_expr_value(expr) != IVL_VT_LOGIC
		&& ivl_expr_value(expr) != IVL_VT_BOOL)
		  return 0;
	    return expr_is_effect_free_(ivl_expr_oper1(expr));

	  case IVL_EX_SELECT:
	    if (ivl_expr_value(expr) != IVL_VT_LOGIC
		&& ivl_expr_value(expr) != IVL_VT_BOOL)
		  return 0;
	    return expr_is_effect_free_(ivl_expr_oper1(expr))
		&& expr_is_effect_free_(ivl_expr_oper2(expr));

	  case IVL_EX_BINARY:
	    switch (ivl_expr_opcode(expr)) {
		case 'a': case 'o': case '+': case '-': case '*': case '/':
		case '%': case 'p': case '&': case '|': case '^': case 'A':
		case 'O': case 'X': case 'e': case 'E': case 'n': case 'N':
		case 'w': case 'W': case 'G': case 'L': case '>': case '<':
		case 'l': case 'r': case 'R':
		  break;
		default:
		  return 0;
	    }
	    return expr_is_effect_free_(ivl_expr_oper1(expr))
		&& expr_is_effect_free_(ivl_expr_oper2(expr));

	  case IVL_EX_UNARY:
	    switch (ivl_expr_opcode(expr)) {
		case '-': case '~': case '!': case '&': case '|': case '^':
		case 'A': case 'N': case 'X':
		  break;
		default:
		  return 0;
	    }
	    return expr_is_effect_free_(ivl_expr_oper1(expr));

	  case IVL_EX_TERNARY:
	    return expr_is_effect_free_(ivl_expr_oper1(expr))
		&& expr_is_effect_free_(ivl_expr_oper2(expr))
		&& expr_is_effect_free_(ivl_expr_oper3(expr));

	  default:
	    return 0;
      }
}

/*
 * A part select of a whole, dimensionless vec4 variable can be read with
 * %load/vec4/part*, which copies only the selected bits instead of loading
 * the entire variable and then selecting from it. That reorders the load
 * after the base evaluation, so the base must be effect free. An event
 * expression recipe may need the loaded subexpression itself saved, so it
 * keeps the general form.
 */
static int select_loads_part_(ivl_expr_t subexpr, ivl_expr_t base)
{
      if (event_expr_recipe_active())
	    return 0;
      if (ivl_expr_type(subexpr) != IVL_EX_SIGNAL || ivl_expr_oper1(subexpr))
	    return 0;
      if (ivl_expr_value(subexpr) != IVL_VT_LOGIC
	  && ivl_expr_value(subexpr) != IVL_VT_BOOL)
	    return 0;

      ivl_signal_t sig = ivl_expr_signal(subexpr);
      if (ivl_signal_dimensions(sig) != 0 || signal_is_return_value(sig))
	    return 0;
      if (ivl_signal_data_type(sig) != IVL_VT_LOGIC
	  && ivl_signal_data_type(sig) != IVL_VT_BOOL)
	    return 0;
      if (ivl_signal_width(sig) != ivl_expr_width(subexpr))
	    return 0;

      return expr_is_effect_free_(base);
}

static int select_needs_bool_cast_(ivl_expr_t expr, ivl_expr_t base)
{
      if (ivl_expr_value(expr) != IVL_VT_BOOL)
	    return 0;
      if (!test_immediate_vec4_ok(base))
	    return 1;

      unsigned long val0, valx;
      unsigned base_wid;
      make_immediate_vec4_words(base, &val0, &valx, &base_wid);
      int negative = ivl_expr_signed(base) && base_wid > 0
	    && base_wid <= 32 && (val0 & (1UL << (base_wid-1)));
      unsigned source_wid = ivl_expr_width(ivl_expr_oper1(expr));
      /* Only invalid or unknown indices can synthesize X for a 2-state select. */
      return valx || negative || val0 > source_wid
	    || ivl_expr_width(expr) > source_wid - val0;
}

static void draw_select_vec4(ivl_expr_t expr)
{
	// This is the sub-expression to part-select.
      ivl_expr_t subexpr = ivl_expr_oper1(expr);
	// This is the base of the part select
      ivl_expr_t base = ivl_expr_oper2(expr);
	// This is the part select width
      unsigned wid = ivl_expr_width(expr);
	// Is the select base expression signed or unsigned?
      char sign_suff = ivl_expr_signed(base)? 's' : 'u';

	// Special Case: If the sub-expression is a STRING, then this
	// is a select from that string.
      if (ivl_expr_value(subexpr)==IVL_VT_STRING) {
	    assert(base);
	    assert(wid==8);
	    draw_eval_string(subexpr);
	    int base_idx = allocate_word();
	    draw_eval_expr_into_integer(base, base_idx);
	    fprintf(vvp_out, "    %%substr/vec4 %d, %u;\n", base_idx, wid);
	    fprintf(vvp_out, "    %%pop/str 1;\n");
	    clr_word(base_idx);
	    return;
      }

	/* Queue OR plain-darray container that is not a bare signal
	 * (class property, chained select, ...): load the container
	 * object and index within it. Plain darrays used to fall into
	 * the signal-only branch below, where ivl_expr_signal() of a
	 * property select yields the CLASS-typed handle signal and the
	 * data-type assertion aborts. */
      if ((expr_is_dynarray_container_(subexpr)
           || fixed_uarray_expr_type_(subexpr)) &&
          ivl_expr_type(subexpr) != IVL_EX_SIGNAL) {
	    assert(base);
	      /* Phase 50f: when the queue container is actually an
	       * associative array (Mv/Mr/MS), the index is a key (string
	       * or class-typed), not an integer.  Treating "key" as a
	       * numeric queue index reads garbage; emit %aa/load/v/* with
	       * the proper key type instead. */
	    ivl_type_t sub_type = receiver_container_type_(subexpr);
	    ivl_type_t fixed_type = fixed_uarray_expr_type_(subexpr);
	    if (sub_type && ivl_type_queue_assoc_compat(sub_type)) {
		  if (expr_is_string_assoc_key_(base)) {
			draw_eval_object(subexpr);
			draw_eval_string(base);
			fprintf(vvp_out, "    %%aa/load/v/str %u;\n", wid);
			if (ivl_expr_value(expr) == IVL_VT_BOOL)
			      fprintf(vvp_out, "    %%cast2;\n");
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			return;
		  }
		  if (expr_is_object_assoc_key_(base)) {
			draw_eval_object(subexpr);
			draw_eval_object(base);
			fprintf(vvp_out, "    %%aa/load/v/obj %u;\n", wid);
			if (ivl_expr_value(expr) == IVL_VT_BOOL)
			      fprintf(vvp_out, "    %%cast2;\n");
			fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
			return;
		  }
		    /* Integral (vec4) key: still a keyed lookup, not a
		       positional queue read. */
		  draw_eval_object(subexpr);
		  draw_eval_vec4(base);
		  fprintf(vvp_out, "    %%aa/load/v/v %u;\n", wid);
		  if (ivl_expr_value(expr) == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  return;
	    }
	    draw_eval_object(subexpr);
	    draw_eval_expr_into_integer(base, 3);
	    unsigned load_wid = fixed_type
		  ? ivl_type_packed_width(ivl_type_element(fixed_type)) : wid;
	    fprintf(vvp_out, "    %%load/qo/v %u;\n", load_wid);
	    if (ivl_expr_value(expr) == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    return;
      }

      if (ivl_expr_value(subexpr)==IVL_VT_DARRAY) {
	    ivl_signal_t sig = ivl_expr_signal(subexpr);
            ivl_type_t net_type;
	    assert(sig);
            net_type = ivl_signal_net_type(sig);
	    assert( (ivl_signal_data_type(sig)==IVL_VT_DARRAY)
		    || (ivl_signal_data_type(sig)==IVL_VT_QUEUE) );

	    assert(base);
	      /* For `maps[outer][key]', SUBEXPR is the selected word of a
	       * fixed object array. Use that word as the associative receiver;
	       * the scalar fast paths below address vSIG_0 and therefore cannot
	       * retain the fixed-prefix selection. */
            if (net_type && ivl_type_queue_assoc_compat(net_type)
		&& ivl_signal_dimensions(sig) > 0
		&& ivl_expr_type(subexpr) == IVL_EX_SIGNAL
		&& ivl_expr_oper1(subexpr)) {
		  const char*key_kind;
		  draw_eval_object(subexpr);
		  key_kind = draw_eval_assoc_key_(base, 0);
		  fprintf(vvp_out, "    %%aa/load/v/%s %u;\n", key_kind, wid);
		  if (ivl_expr_value(expr) == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		  fprintf(vvp_out,
			  "    %%pop/obj 1, 0; fixed outer map receiver\n");
		  return;
	    }
	      /* A positional queue/darray selected from a fixed object array has
	       * the same IVL_EX_SIGNAL shape as a scalar dynamic container, but no
	       * vSIG_0 functor exists. Evaluate the fixed word exactly once and use
	       * the object-stack positional load for its trailing runtime index. */
            if (expr_selects_fixed_container_slot_(subexpr)) {
		  draw_eval_object(subexpr);
		  draw_eval_expr_into_integer(base, 3);
		  fprintf(vvp_out, "    %%load/qo/v %u; fixed container slot element\n",
		          wid);
		  if (ivl_expr_value(expr) == IVL_VT_BOOL)
			fprintf(vvp_out, "    %%cast2;\n");
		  return;
	    }
            if (net_type && ivl_type_queue_assoc_compat(net_type)
                && expr_is_object_assoc_key_(base)) {
                  draw_eval_object(base);
                  fprintf(vvp_out, "    %%aa/load/sig/v/obj v%p_0, %u;\n", sig, wid);
                  if (ivl_expr_value(expr) == IVL_VT_BOOL)
                        fprintf(vvp_out, "    %%cast2;\n");
                  return;
            }
	    if (net_type && ivl_type_queue_assoc_compat(net_type)
                && expr_is_string_assoc_key_(base)) {
                  /* String-keyed assoc array read: push str key, push obj, %aa/load/v/str */
                  draw_eval_string(base);
                  fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
                  fprintf(vvp_out, "    %%aa/load/v/str %u;\n", wid);
                  if (ivl_expr_value(expr) == IVL_VT_BOOL)
                        fprintf(vvp_out, "    %%cast2;\n");
                  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
                  return;
            }
            /* M14: integer(vec4)-keyed associative array read. This bare-
               signal branch previously handled only string and object
               keys and fell through to the POSITIONAL darray load below
               for integral keys, so a module-static `int m[int]` (which
               is a bare signal, unlike a class-member assoc) stored its
               values via %aa/store but read them via %load/dar/vec4 and
               always read the default — a silent value loss. An
               assoc-compat container whose key is neither string nor
               object is keyed by an integral value: load it as such. */
            if (net_type && ivl_type_queue_assoc_compat(net_type)) {
                  draw_eval_vec4(base);
                  fprintf(vvp_out, "    %%load/obj v%p_0;\n", sig);
                  fprintf(vvp_out, "    %%aa/load/v/v %u;\n", wid);
                  if (ivl_expr_value(expr) == IVL_VT_BOOL)
                        fprintf(vvp_out, "    %%cast2;\n");
                  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
                  return;
            }
	    draw_eval_expr_into_integer(base, 3);
	    fprintf(vvp_out, "    %%load/dar/vec4 v%p_0;\n", sig);
	    if (ivl_expr_value(expr) == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");

	    return;
      }

      if (select_loads_part_(subexpr, base)) {
	    ivl_signal_t sig = ivl_expr_signal(subexpr);
	    if (test_immediate_vec4_ok(base)) {
		  unsigned long val0, valx;
		  unsigned base_wid;
		  make_immediate_vec4_words(base, &val0, &valx, &base_wid);
		  int negative = ivl_expr_signed(base)
			&& base_wid > 0 && base_wid <= 32
			&& (val0 & (1UL << (base_wid-1)));
		  if (valx == 0 && !negative && val0 <= 0xffffffffUL) {
			fprintf(vvp_out, "    %%load/vec4/parti v%p_0, %u, %lu;\n",
				sig, wid, val0);
			if (select_needs_bool_cast_(expr, base))
			      fprintf(vvp_out, "    %%cast2;\n");
			return;
		  }
	    }
	    draw_eval_vec4(base);
	    fprintf(vvp_out, "    %%load/vec4/part/%c v%p_0, %u;\n",
		    sign_suff, sig, wid);
	    if (select_needs_bool_cast_(expr, base))
		  fprintf(vvp_out, "    %%cast2;\n");
	    return;
      }

      if (test_immediate_vec4_ok(base)) {
	    unsigned long val0, valx;
	    unsigned base_wid;
	    make_immediate_vec4_words(base, &val0, &valx, &base_wid);
	    if (valx == 0) {
		  draw_eval_vec4(subexpr);
		  fprintf(vvp_out, "    %%parti/%c %u, %lu, %u;\n",
			  sign_suff, wid, val0, base_wid);
	    } else {
		  draw_eval_vec4(subexpr);
		  draw_eval_vec4(base);
		  fprintf(vvp_out, "    %%part/%c %u;\n", sign_suff, wid);
	    }

      } else {
	    draw_eval_vec4(subexpr);
	    draw_eval_vec4(base);
	    fprintf(vvp_out, "    %%part/%c %u;\n", sign_suff, wid);
      }

      if (select_needs_bool_cast_(expr, base))
	    fprintf(vvp_out, "    %%cast2;\n");

}

static void draw_select_pad_vec4(ivl_expr_t expr)
{
	// This is the sub-expression to pad/truncate
      ivl_expr_t subexpr = ivl_expr_oper1(expr);
	// This is the target width of the expression
      unsigned wid = ivl_expr_width(expr);

	// Push the sub-expression onto the stack.
      draw_eval_vec4(subexpr);

	// Special case: The expression is already the correct width,
	// so there is nothing to be done.
      if (wid == ivl_expr_width(subexpr))
	    return;

      if (ivl_expr_signed(expr))
	    fprintf(vvp_out, "    %%pad/s %u;\n", wid);
      else
	    fprintf(vvp_out, "    %%pad/u %u;\n", wid);
}

/*
 * This function handles the special case of a call to the internal
 * functions $ivl_queue_method$pop_back et al. The first (and only)
 * argument is the signal that represents a dynamic queue. Generate a
 * %qpop instruction to pop a value and push it to the vec4 stack.
 */
static void draw_darray_pop(ivl_expr_t expr)
{
      static int warned_non_signal_pop = 0;
      const char*fb;

      if (strcmp(ivl_expr_name(expr), "$ivl_queue_method$pop_back")==0)
	    fb = "b";
      else
	    fb = "f";

      ivl_expr_t arg = ivl_expr_parm(expr, 0);
	    if (ivl_expr_type(arg) != IVL_EX_SIGNAL
		|| expr_selects_fixed_container_slot_(arg)) {
	    if (expr_is_queue_container_(arg)) {
		  draw_eval_object(arg);
		  fprintf(vvp_out, "    %%qpop/o/%s/v %u;\n",
		          fb, ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
		  return;
	    }
	      /* A pop with nothing to pop from. The zero used to be a
		 warning: the queue was left untouched and the caller
		 got a fabricated value. Fail instead. */
	    if (!warned_non_signal_pop) {
		  fprintf(stderr, "error: %s requires a signal operand, got "
			  "expression kind %d (further occurrences are not "
			  "reported).\n",
			  ivl_expr_name(expr), ivl_expr_type(arg));
		  warned_non_signal_pop = 1;
	    }
	    vvp_errors += 1;
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;"
		    " ; pop fallback\n", ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
	    return;
      }

      fprintf(vvp_out, "    %%qpop/%s/v v%p_0, %u;\n", fb, ivl_expr_signal(arg),
                       ivl_expr_width(expr));
}

static int draw_assoc_exists_vec4(ivl_expr_t expr)
{
      ivl_expr_t recv;
      ivl_expr_t key;
      ivl_signal_t sig;
      unsigned wid = ivl_expr_width(expr) ? ivl_expr_width(expr) : 1;

      if (ivl_expr_parms(expr) != 2)
	    return 0;

      recv = ivl_expr_parm(expr, 0);
      key = ivl_expr_parm(expr, 1);
      if (!recv || !key)
	    return 0;

      sig = signal_assoc_queue_receiver_(recv);
      if (sig) {
            const char*key_kind = draw_eval_assoc_key_(key, 0);
	    fprintf(vvp_out, "    %%aa/exists/sig/%s v%p_0, %u;\n", key_kind, sig, wid);
      } else {
            const char*key_kind;
	    draw_eval_object(recv);
            key_kind = draw_eval_assoc_key_(key, 0);
	    fprintf(vvp_out, "    %%aa/exists/%s %u;\n", key_kind, wid);
      }
      return 1;
}

static int draw_assoc_traversal_vec4(ivl_expr_t expr)
{
      ivl_expr_t recv;
      ivl_expr_t key;
      ivl_signal_t recv_sig;
      ivl_signal_t key_sig;
      const char*key_kind;
      const char*method_name;
      unsigned wid = ivl_expr_width(expr) ? ivl_expr_width(expr) : 1;
      static int warned_bad_key = 0;

      if (ivl_expr_parms(expr) != 2)
	    return 0;

      recv = ivl_expr_parm(expr, 0);
      key = ivl_expr_parm(expr, 1);
      if (!recv || !key)
	    return 0;

      if ((ivl_expr_type(key) != IVL_EX_SIGNAL && ivl_expr_type(key) != IVL_EX_ARRAY)
          || !(key_sig = ivl_expr_signal(key))) {
	      /* first/last/next/prev with no key variable to write back
		 to. The zero return said "no more elements", which ends
		 the caller's traversal early and silently. */
	    if (!warned_bad_key) {
		  fprintf(stderr,
		          "error: an associative-array traversal method requires "
		          "a signal as its key argument (further occurrences are "
		          "not reported).\n");
		  warned_bad_key = 1;
	    }
	    vvp_errors += 1;
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", wid);
	    return 1;
      }

      if (strcmp(ivl_expr_name(expr), "$ivl_assoc_method$first") == 0)
	    method_name = "first";
      else if (strcmp(ivl_expr_name(expr), "$ivl_assoc_method$last") == 0)
	    method_name = "last";
      else if (strcmp(ivl_expr_name(expr), "$ivl_assoc_method$next") == 0)
	    method_name = "next";
      else if (strcmp(ivl_expr_name(expr), "$ivl_assoc_method$prev") == 0)
	    method_name = "prev";
      else
	    return 0;

      if (expr_is_string_assoc_key_(key))
            key_kind = "str";
      else if (expr_is_object_assoc_key_(key))
            key_kind = "obj";
      else {
            ivl_type_t key_type = ivl_signal_net_type(key_sig);
              /* first/last/next/prev order integral indices according to the
                 declared key variable's exact signedness.  Use a distinct
                 opcode because the /sig/ form already consumes both vvp_code
                 pointer slots (receiver and key signal), leaving no storage
                 for an additional flag. */
            key_kind = key_type && ivl_type_signed(key_type) ? "sv" : "v";
      }

      recv_sig = signal_assoc_queue_receiver_(recv);
      if (recv_sig) {
	    fprintf(vvp_out, "    %%aa/%s/sig/%s v%p_0, v%p_0;\n",
	            method_name, key_kind, recv_sig, key_sig);
	    /* The /sig/ opcode pushes a 1-bit success flag. Caller expects
	       `wid` bits (typically 32 for the int return of .first(key)),
	       so zero-extend to match. */
	    if (wid > 1)
	          fprintf(vvp_out, "    %%pad/u %u;\n", wid);
      } else {
	    draw_eval_object(recv);
	    fprintf(vvp_out, "    %%aa/%s/%s v%p_0, %u;\n",
	            method_name, key_kind, key_sig, wid);
      }

      return 1;
}

static void draw_assign_expr_vec4(ivl_expr_t expr)
{
      static const char prefix[] = "$ivl_assign_expr$";
      const char*name = ivl_expr_name(expr);
      ivl_expr_t lhs = ivl_expr_parm(expr, 0);
      ivl_expr_t rhs = ivl_expr_parm(expr, 1);
      char op = name[sizeof prefix - 1];

      assert(ivl_expr_parms(expr) == 2);
      assert(lhs && rhs);
      assert(ivl_expr_type(lhs) == IVL_EX_SIGNAL);
      assert(ivl_expr_oper1(lhs) == 0);

      ivl_signal_t sig = ivl_expr_signal(lhs);
      unsigned wid = ivl_expr_width(lhs);

      if (op == '=') {
            draw_eval_vec4(rhs);
      } else if (op == 'l' || op == 'r' || op == 'R') {
            draw_eval_vec4(lhs);
            int use_index_reg = allocate_word();
            assert(use_index_reg >= 0);
            draw_eval_expr_into_integer(rhs, use_index_reg);
            if (op == 'l')
                  fprintf(vvp_out, "    %%shiftl %d;\n", use_index_reg);
            else if (op == 'R' && ivl_expr_signed(lhs))
                  fprintf(vvp_out, "    %%shiftr/s %d;\n", use_index_reg);
            else
                  fprintf(vvp_out, "    %%shiftr %d;\n", use_index_reg);
            clr_word(use_index_reg);
      } else {
            draw_eval_vec4(lhs);
            draw_eval_vec4(rhs);
            switch (op) {
                case '+': fprintf(vvp_out, "    %%add;\n"); break;
                case '-': fprintf(vvp_out, "    %%sub;\n"); break;
                case '*': fprintf(vvp_out, "    %%mul;\n"); break;
                case '/': fprintf(vvp_out, "    %%div%s;\n",
                                  ivl_expr_signed(lhs)? "/s" : ""); break;
                case '%': fprintf(vvp_out, "    %%mod%s;\n",
                                  ivl_expr_signed(lhs)? "/s" : ""); break;
                case '&': fprintf(vvp_out, "    %%and;\n"); break;
                case '|': fprintf(vvp_out, "    %%or;\n"); break;
                case '^': fprintf(vvp_out, "    %%xor;\n"); break;
                default: assert(0);
            }
      }

      if (ivl_signal_data_type(sig) == IVL_VT_BOOL)
            fprintf(vvp_out, "    %%cast2; assignment expression destination\n");
      fprintf(vvp_out, "    %%dup/vec4;\n");
      fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n", sig, wid);
}

static void draw_sfunc_vec4(ivl_expr_t expr)
{
      unsigned parm_count = ivl_expr_parms(expr);

      if (strncmp(ivl_expr_name(expr), "$ivl_vif_func$", 14) == 0) {
            vvp_errors += draw_vif_function_call(expr);
            return;
      }

      if (strncmp(ivl_expr_name(expr), "$ivl_assign_expr$", 17) == 0) {
            draw_assign_expr_vec4(expr);
            return;
      }

      /* Atomic canonicalization for a multidimensional fixed class-property
       * index. Raw index expressions occupy parms 0,4,8,... and are evaluated
       * exactly once, left-to-right. The remaining parms are constant
       * low/width/stride metadata and intentionally have no runtime
       * evaluation. One runtime opcode checks every already-evaluated raw
       * value before returning either the flat 64-bit index or X64. */
      if (strcmp(ivl_expr_name(expr), "$ivl_checked_property_index") == 0) {
            unsigned dims = parm_count / 4;
            unsigned dim;
            int malformed = (parm_count == 0 || (parm_count % 4) != 0);

            for (dim = 0 ; dim < dims ; dim += 1) {
                  ivl_expr_t raw = ivl_expr_parm(expr, 4 * dim);
                  if (raw) {
                        draw_eval_vec4(raw);
                  } else {
                        malformed = 1;
                        fprintf(vvp_out, "    %%pushi/vec4 0, 0, 64; malformed checked index\n");
                  }
            }

            for (dim = 0 ; dim < dims ; dim += 1) {
                  unsigned field;
                  for (field = 1 ; field < 4 ; field += 1) {
                        ivl_expr_t meta = ivl_expr_parm(expr, 4 * dim + field);
                        if (!meta
                            || (ivl_expr_type(meta) != IVL_EX_NUMBER
                                && ivl_expr_type(meta) != IVL_EX_ULONG)
                            || number_is_unknown(meta)
                            || ivl_expr_width(meta) > 64)
                              malformed = 1;
                  }
            }

            if (malformed) {
                  fprintf(stderr, "%s:%u: internal error: malformed "
                          "$ivl_checked_property_index metadata.\n",
                          ivl_expr_file(expr), ivl_expr_lineno(expr));
                  vvp_errors += 1;
                  fprintf(vvp_out, "    %%prop/index/check \"%u|!\";\n", dims);
                  return;
            }

            fprintf(vvp_out, "    %%prop/index/check \"%u|", dims);
            for (dim = 0 ; dim < dims ; dim += 1) {
                  ivl_expr_t raw = ivl_expr_parm(expr, 4 * dim);
                  int64_t low = (int64_t)get_number_immediate64(
                        ivl_expr_parm(expr, 4 * dim + 1));
                  uint64_t width = get_number_immediate64(
                        ivl_expr_parm(expr, 4 * dim + 2));
                  uint64_t stride = get_number_immediate64(
                        ivl_expr_parm(expr, 4 * dim + 3));

                  if (dim != 0)
                        fputc(';', vvp_out);
                  fprintf(vvp_out, "%c:%" PRId64 ":%" PRIu64 ":%" PRIu64,
                          ivl_expr_signed(raw) ? 's' : 'u', low,
                          width, stride);
            }
            fprintf(vvp_out, "\";\n");
            return;
      }

	/* Special case: If there are no arguments to print, then the
	   %vpi_call statement is easy to draw. */
      if (parm_count == 0) {
	    assert(ivl_expr_value(expr)==IVL_VT_LOGIC
		   || ivl_expr_value(expr)==IVL_VT_BOOL);

	    fprintf(vvp_out, "    %%vpi_func %u %u \"%s\" %u {0 0 0 0};\n",
		    ivl_file_table_index(ivl_expr_file(expr)),
		    ivl_expr_lineno(expr), ivl_expr_name(expr),
		    ivl_expr_width(expr));
	    return;
      }

      if (strcmp(ivl_expr_name(expr), "$ivl_queue_method$pop_back")==0) {
	    draw_darray_pop(expr);
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_queue_method$pop_front")==0) {
	    draw_darray_pop(expr);
	    return;
      }
      if (strcmp(ivl_expr_name(expr), "$ivl_queue$last") == 0) {
	    assert(parm_count == 1);
	    draw_eval_object(ivl_expr_parm(expr, 0));
	    fprintf(vvp_out, "    %%dup/obj/ref; queue-last receiver alias\n");
	    fprintf(vvp_out, "    %%qsize/o;\n");
	    fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    fprintf(vvp_out, "    %%sub;\n");
	    fprintf(vvp_out, "    %%ix/vec4 3;\n");
	    fprintf(vvp_out, "    %%load/qo/v %u;\n", ivl_expr_width(expr));
	    if (ivl_expr_value(expr) == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2;\n");
	    return;
      }
      if (strncmp(ivl_expr_name(expr),"$ivl_stream$",12)==0) {
	      /* Streaming concatenation with dynamically sized operands
	         packed into a fixed-width context (IEEE 1800-2017
	         11.4.14): the runtime aligns the stream into the
	         expression width (left-aligned, zero-filled right;
	         error if the stream is wider). */
	    draw_stream_pack_pieces(expr, ivl_expr_width(expr));
	    return;
      }
      if (strncmp(ivl_expr_name(expr),"$ivl_darray_method$reduce|",26)==0) {
	      /* IEEE 1800-2017 7.12.3 array reduction methods: inline
	         loop leaving the accumulated value on the vec4 stack. */
	    draw_array_reduce_vec4(expr);
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_process$status")==0) {
	      /* IEEE 1800-2017 9.7: query the live process state. */
	    ivl_expr_t parg = ivl_expr_parm(expr, 0);
	    assert(parg);
	    draw_eval_object(parg);
	    fprintf(vvp_out, "    %%process/status;\n");
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_event_method$triggered")==0) {
	      /* IEEE 1800-2017 15.5.3: read the named event's
	         triggered-this-time-step state. */
	    ivl_expr_t earg = ivl_expr_parm(expr, 0);
	    assert(earg && ivl_expr_type(earg) == IVL_EX_EVENT);
	    fprintf(vvp_out, "    %%evtest E_%p;\n", ivl_expr_event(earg));
	    return;
      }
      if (strcmp(ivl_expr_name(expr),
		 "$ivl_class_event_method$triggered")==0) {
	      /* IEEE 1800-2017/2023 15.5.3: query the selected object's
	         private event slot for this time step. */
	    ivl_expr_t obj_arg = ivl_expr_parm(expr, 0);
	    ivl_expr_t slot_arg = ivl_expr_parm(expr, 1);
	    assert(obj_arg && slot_arg && ivl_expr_type(slot_arg) == IVL_EX_NUMBER);
	    draw_eval_object(obj_arg);
	    fprintf(vvp_out, "    %%evtest/obj %" PRIu64 ";\n",
		    (uint64_t)ivl_expr_uvalue(slot_arg));
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_event_method$triggered_arr")==0) {
	      /* IEEE 1800-2017 15.5.3 / 6.20: read one named-event array
	         element's triggered-this-time-step state. parm(0) carries
	         the array's group event (for its base slot/count), parm(1)
	         is the run-time element index. */
	    ivl_expr_t earg = ivl_expr_parm(expr, 0);
	    assert(earg && ivl_expr_type(earg) == IVL_EX_EVENT);
	    ivl_event_t ev = ivl_expr_event(earg);
	    uint64_t packed = ((uint64_t)ivl_event_array_base(ev) << 32)
	                    | (uint64_t)ivl_event_array_count(ev);

	    ivl_expr_t iarg = ivl_expr_parm(expr, 1);
	    int use_idx = allocate_word();
	    draw_expr_into_idx(iarg, use_idx);
	    fprintf(vvp_out, "    %%evtest/arr %" PRIu64 ", %d;\n",
		    packed, use_idx);
	    clr_word(use_idx);
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_class_method$rand_mode_get")==0
	  || strcmp(ivl_expr_name(expr),
		    "$ivl_class_method$rand_mode_get_assoc") == 0
	  || strcmp(ivl_expr_name(expr),
		    "$ivl_class_method$rand_mode_get_last") == 0) {
	    int assoc_index = strcmp(ivl_expr_name(expr),
			     "$ivl_class_method$rand_mode_get_assoc") == 0;
	    int last_index = strcmp(ivl_expr_name(expr),
			     "$ivl_class_method$rand_mode_get_last") == 0;
	      /* M3B-12 (IEEE 1800-2017 18.8): parm[0] = object,
	       * parm[1] = property id. Reads the variable's active state. */
	    ivl_expr_t obj_arg = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    ivl_expr_t pid_arg = (parm_count > 1) ? ivl_expr_parm(expr, 1) : 0;
	    long pid = pid_arg ? get_number_immediate(pid_arg) : 0;
	    if (obj_arg) draw_eval_object(obj_arg);
	    if (last_index) {
		  fprintf(vvp_out, "    %%rand_mode/get/last %ld;\n", pid);
		  return;
	    }
	    if (parm_count >= 4) {
		  ivl_expr_t leaf_arg = ivl_expr_parm(expr, 2);
		  ivl_expr_t count_arg = ivl_expr_parm(expr, 3);
		  if (assoc_index) {
			const char*key_kind = draw_eval_assoc_key_(leaf_arg, 0);
			fprintf(vvp_out, "    %%rand_mode/get/a/%s %ld;\n",
				key_kind, pid);
			return;
		  }
		  int leaf_word = allocate_word();
		  int count_word = allocate_word();
		  draw_expr_into_idx(leaf_arg, leaf_word);
		  draw_expr_into_idx(count_arg, count_word);
		  fprintf(vvp_out, "    %%rand_mode/get/i %ld, %d, %d;\n",
			  pid, leaf_word, count_word);
		  clr_word(count_word);
		  clr_word(leaf_word);
	    } else {
		  fprintf(vvp_out, "    %%rand_mode/get %ld;\n", pid);
	    }
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_class_method$constraint_mode_get")==0) {
	      /* IEEE 1800-2017 18.8: parm[0] = object,
	       * parm[1] = named constraint id. */
	    ivl_expr_t obj_arg = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    ivl_expr_t cid_arg = (parm_count > 1) ? ivl_expr_parm(expr, 1) : 0;
	    long cid = cid_arg ? get_number_immediate(cid_arg) : 0;
	    if (obj_arg) draw_eval_object(obj_arg);
	    fprintf(vvp_out, "    %%constraint_mode/get %ld;\n", cid);
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_class_method$randomize")==0
	  || strncmp(ivl_expr_name(expr),"$ivl_class_method$randomize|",28)==0) {
	    ivl_expr_t arg = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	      /* M3B-13: the 18.11 argument selector, when the call had an
	       * argument list. NULL here means the plain form. */
	    const char*sel = strchr(ivl_expr_name(expr), '|');
	    if (sel) sel += 1;
	      /* Evaluate the method receiver exactly once. Keep this original
	       * handle on the object stack; hooks consume aliasing duplicates
	       * and %randomize consumes one final aliasing duplicate. */
	    if (arg)
		  draw_eval_object(arg);
	    /* IEEE 1800-2017/2023 18.6.2: the virtual built-in randomize
	     * selects callbacks from the receiver's dynamic class. This also
	     * applies to randomize(null), whose selector only affects solving. */
	    if (arg)
		  fprintf(vvp_out, "    %%randomize/pre \"%s\";\n",
                          sel ? sel : "*");
	    if (sel)
		  fprintf(vvp_out, "    %%rand/active \"%s\";\n", sel);
	    if (arg)
		  fprintf(vvp_out, "    %%dup/obj/ref; randomize solve receiver\n");
	      /* %randomize peeks at the object stack and pops it, then
	       * pushes 1 (success) onto the vec4 stack. */
	    fprintf(vvp_out, "    %%randomize;\n");
	    if (arg)
		  fprintf(vvp_out, "    %%randomize/hook 1;\n");
	    if (arg)
		  fprintf(vvp_out, "    %%pop/obj 1, 0; randomize receiver\n");
	      /* The opcode's result is 32 bits; size it to the expression. */
	    resize_vec4_wid_from_(32, ivl_expr_width(expr));
	    return;
      }
      if (strncmp(ivl_expr_name(expr),"$ivl_class_method$randomize_with|",33)==0
	  || strncmp(ivl_expr_name(expr),
		     "$ivl_class_method$scope_randomize_with|",39)==0) {
	      /* Mangled name:
	       *   "$ivl_class_method$randomize_with|N_vals|sel|ir_string"
	       * parm[0] = object, parm[1..N_vals] = runtime slot values.
	       * `sel` is the 18.11 argument selector: "*" for the plain
	       * form, "" for randomize(null), else a property-id list. */
	    int scope_form = strncmp(ivl_expr_name(expr),
		     "$ivl_class_method$scope_randomize_with|",39) == 0;
	    const char*rest = ivl_expr_name(expr) + (scope_form ? 39 : 33);
	    unsigned n_vals = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    const char*sel_beg = rest;
	    while (*rest && *rest != '|') rest++;
	    size_t sel_len = (size_t)(rest - sel_beg);
	    if (*rest == '|') rest++;
	    const char*ir = rest;
	    int have_sel = !(sel_len == 1 && sel_beg[0] == '*');
	    ivl_expr_t obj_arg = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	      /* As for plain randomize(), retain one evaluation of the receiver
	       * across hooks, runtime with-clause slot evaluation, and solving. */
	    if (obj_arg)
		  draw_eval_object(obj_arg);
	    if (obj_arg && !scope_form)
		  fprintf(vvp_out, "    %%randomize/pre \"%.*s\";\n",
                          (int)sel_len, sel_beg);
	      /* Push runtime slot values (vec4 stack) first so they're
	       * under the result when %randomize/with pops them. */
	    for (unsigned i = 0 ; i < n_vals ; i++) {
		  ivl_expr_t slot = ivl_expr_parm(expr, 1 + i);
		  if (slot && ivl_expr_type(slot) == IVL_EX_SFUNC
		      && strcmp(ivl_expr_name(slot),
			"$ivl_inline_target_capture") == 0
		      && ivl_expr_parms(slot) == 1
		      && ivl_expr_type(ivl_expr_parm(slot, 0)) == IVL_EX_UFUNC)
			draw_ufunc_vec4_retained_receiver(ivl_expr_parm(slot, 0));
		  else if (slot) draw_eval_vec4(slot);
		  else fprintf(vvp_out, "    %%pushi/vec4 0, 0, 32;\n");
	    }
	      /* %randomize/with consumes its object, so give it an aliasing
	       * duplicate and retain the original for conditional post hooks. */
	    if (obj_arg)
		  fprintf(vvp_out, "    %%dup/obj/ref; randomize/with solve receiver\n");
            assert(parm_count > n_vals);
            unsigned n_objs = parm_count - 1 - n_vals;
            for (unsigned i = 0; i < n_objs; ++i)
                  draw_eval_object(ivl_expr_parm(expr, 1 + n_vals + i));
            /* Capture selected state queues after pre_randomize and keep
             * them above the solve receiver. Arm its selector last. */
            if (have_sel)
                  fprintf(vvp_out, "    %%rand/active \"%.*s\";\n",
                          (int)sel_len, sel_beg);
            if (n_objs)
                  fprintf(vvp_out, "    %%randomize/with/objects \"%s\", %u, %u;\n",
                          ir, n_vals | (scope_form ? 0x80000000u : 0u), n_objs);
            else
                  fprintf(vvp_out, "    %%randomize/with \"%s\", %u;\n", ir,
                          n_vals | (scope_form ? 0x80000000u : 0u));
	    if (obj_arg && !scope_form)
		  fprintf(vvp_out, "    %%randomize/hook 1;\n");
	    if (obj_arg)
		  fprintf(vvp_out, "    %%pop/obj 1, 0; randomize/with receiver\n");
	    resize_vec4_wid_from_(32, ivl_expr_width(expr));
	    return;
      }
      if (strncmp(ivl_expr_name(expr), "$ivl_std_randomize_with|", 24) == 0) {
	      /* IEEE 1800-2017 18.12 scope randomization.
	       * Mangled name:
	       *   "$ivl_std_randomize_with|N_rand|N_vals|N_objs|ir"
	       * parms[0..N_rand-1] are both model inputs and destinations;
	       * remaining parms are caller-scope state values. */
	    const char*rest = ivl_expr_name(expr) + 24;
	    unsigned n_rand = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    unsigned n_vals = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    unsigned n_objs = (unsigned)strtoul(rest, NULL, 10);
	    while (*rest && *rest != '|') rest++;
	    if (*rest == '|') rest++;
	    const char*ir = rest;
	    ivl_expr_t first = n_rand ? ivl_expr_parm(expr, 0) : 0;
	    ivl_type_t dest_type = first ? ivl_expr_net_type(first) : 0;
	    if (!dest_type && first && ivl_expr_signal(first))
		  dest_type = ivl_signal_net_type(ivl_expr_signal(first));
	      /* A dynamic array uses the same container solver as a
	       * queue, with no declared maximum (IEEE 1800-2017 18.12). */
	    int queue_dest = dest_type
		&& ((ivl_type_base(dest_type) == IVL_VT_QUEUE
		     && !ivl_type_queue_assoc_compat(dest_type))
		    || ivl_type_base(dest_type) == IVL_VT_DARRAY);
	    ivl_type_t elem_type = queue_dest
		? ivl_type_element(dest_type) : 0;

	    for (unsigned i = 0 ; i < n_rand ; i++) {
		  ivl_expr_t var = ivl_expr_parm(expr, i);
		  if (queue_dest) draw_eval_object(var);
		  else draw_eval_vec4(var);
	    }
	    for (unsigned i = 0 ; i < n_vals ; i++) {
		  ivl_expr_t slot = ivl_expr_parm(expr, n_rand + i);
		  draw_eval_vec4(slot);
	    }
	    for (unsigned i = 0 ; i < n_objs ; i++) {
		  ivl_expr_t slot = ivl_expr_parm(expr, n_rand + n_vals + i);
		  draw_eval_object(slot);
	    }
	    unsigned packed_slots = (n_objs << 16) | (n_vals & 0xffffu);
	    if (queue_dest)
		  fprintf(vvp_out,
		    "    %%std/randomize/queue/with \"%u|%llu|%s\", %u, %u;\n",
		    ivl_type_packed_width(elem_type),
		    (unsigned long long)(ivl_type_base(dest_type) == IVL_VT_QUEUE
					 ? ivl_type_queue_max_size(dest_type) : 0),
		    ir, n_vals, n_objs);
	    else
		  fprintf(vvp_out, "    %%std/randomize/with \"%s\", %u, %u;\n",
		    ir, n_rand, packed_slots);

	      /* The opcode leaves the success result on the vec4 stack and
	       * keeps model values in thread-local storage. Loading/storing a
	       * model value therefore preserves the expression result below
	       * it. UNSAT produces no stores. */
	    unsigned lab_done = local_count++;
	    int success_flag = allocate_flag();
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    fprintf(vvp_out, "    %%flag_set/vec4 %d;\n", success_flag);
	    fprintf(vvp_out, "    %%jmp/0 T_%u.%u, %d;\n",
		    thread_count, lab_done, success_flag);
	    for (unsigned i = 0 ; i < n_rand ; i++) {
		  ivl_expr_t var = ivl_expr_parm(expr, i);
		  ivl_signal_t sig = var ? ivl_expr_signal(var) : 0;
		  unsigned wid = var ? ivl_expr_width(var) : 0;
		  if (!sig || ivl_expr_type(var) != IVL_EX_SIGNAL) {
			fprintf(stderr, "%s:%u: vvp.tgt error: unsupported "
				"std::randomize destination; solver result not "
				"stored.\\n",
				ivl_expr_file(expr), ivl_expr_lineno(expr));
			continue;
		  }
		  fprintf(vvp_out, queue_dest
		    ? "    %%std/randomize/load/obj %u;\n"
		    : "    %%std/randomize/load %u;\n", i);
		  if (queue_dest)
		    fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
		  else if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", wid);
		  else
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n",
				sig, wid);
	    }
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_done);
	    clr_flag(success_flag);
	    return;
      }
      if (strcmp(ivl_expr_name(expr), "$ivl_inside_arr")==0) {
	    /* parm 0: array signal (receiver), parm 1: value to check */
	    ivl_expr_t arr_arg = (ivl_expr_parms(expr) > 0) ? ivl_expr_parm(expr, 0) : 0;
	    ivl_expr_t val_arg = (ivl_expr_parms(expr) > 1) ? ivl_expr_parm(expr, 1) : 0;
	    ivl_type_t arr_type = arr_arg ? ivl_expr_net_type(arr_arg) : 0;
	    if (arr_arg && ivl_expr_type(arr_arg) == IVL_EX_SIGNAL
		&& ivl_expr_signal(arr_arg))
		  arr_type = ivl_signal_net_type(ivl_expr_signal(arr_arg));
	    ivl_type_t elem_type = arr_type ? ivl_type_element(arr_type) : 0;
	    int string_value = (val_arg && ivl_expr_value(val_arg) == IVL_VT_STRING)
		|| (elem_type && ivl_type_base(elem_type) == IVL_VT_STRING);
	    if (arr_arg && val_arg
		&& ivl_expr_type(arr_arg) == IVL_EX_SIGNAL
		&& ivl_expr_signal(arr_arg)) {
		  if (string_value) {
			draw_eval_string(val_arg);
			fprintf(vvp_out, "    %%inside/arr/str v%p_0;\n",
				ivl_expr_signal(arr_arg));
		  } else {
			draw_eval_vec4(val_arg);
			fprintf(vvp_out, "    %%inside/arr v%p_0;\n",
				ivl_expr_signal(arr_arg));
		  }
		  return;
	    }
	    /* Queue/darray held in an expression (e.g. a class property, or
	     * a non-signal expression such as a function call result): push
	     * the value then the container object and use the object-stack
	     * form of the opcode. L38: the comment already said "Queue/
	     * darray" but the check only tested IVL_VT_DARRAY -- a QUEUE-
	     * valued expression that is not itself a property (e.g.
	     * `x inside {some_func_returning_a_queue()}') fell through to
	     * the "unsupported container operand" fallback below and forced
	     * the result to 0, even though the identical queue as a class
	     * property already worked via the IVL_EX_PROPERTY arm of this
	     * same condition. */
	    if (arr_arg && val_arg
		&& (ivl_expr_type(arr_arg) == IVL_EX_PROPERTY
		    || ivl_expr_value(arr_arg) == IVL_VT_DARRAY
		    || ivl_expr_value(arr_arg) == IVL_VT_QUEUE)) {
		  if (string_value)
			draw_eval_string(val_arg);
		  else
			draw_eval_vec4(val_arg);
		  draw_eval_object(arr_arg);
		  fprintf(vvp_out, string_value
			  ? "    %%inside/arr/o/str;\n"
			  : "    %%inside/arr/o;\n");
		  return;
	    }
	    /* Fallback: push 0 (no match) — and say so, loudly. */
	    fprintf(stderr, "vvp.tgt error: unsupported container operand "
		    "for the inside operator; membership result forced to 0.\n");
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, 1;\n");
	    return;
      }
	/* Clocking drive through a virtual interface (14.16): 1-bit
	 * "did the M-th property signal (the sampler tick) of the
	 * bound instance change during this time step". */
      if (strcmp(ivl_expr_name(expr), "$ivl_vif_tick_changed")==0) {
	    ivl_expr_t obj = (ivl_expr_parms(expr) > 0) ? ivl_expr_parm(expr, 0) : 0;
	    ivl_expr_t midx = (ivl_expr_parms(expr) > 1) ? ivl_expr_parm(expr, 1) : 0;
	    if (obj && midx && ivl_expr_type(midx) == IVL_EX_NUMBER) {
		  draw_eval_object(obj);
		  fprintf(vvp_out, "    %%vif/tickchg %lu;\n",
			  ivl_expr_uvalue(midx));
		  return;
	    }
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, 1;\n");
	    return;
      }

	/* Clocking input sample read (14.13): the Preponed-region value
	 * of the raw signal. Requires a $ivl_clocking_hist_on prologue;
	 * degrades to the current value without one. */
      if (strcmp(ivl_expr_name(expr), "$ivl_clocking_sample")==0) {
	    ivl_expr_t arg = (ivl_expr_parms(expr) > 0) ? ivl_expr_parm(expr, 0) : 0;
	    if (arg && ivl_expr_type(arg) == IVL_EX_SIGNAL && ivl_expr_signal(arg)) {
		  ivl_signal_t asig = ivl_expr_signal(arg);
		    /* R11: an unpacked-array WORD needs the word-indexed
		       load -- %load/preponed takes a signal and would
		       ignore the index, reading word 0. */
		  if (ivl_signal_dimensions(asig) > 0) {
			int addr_index = allocate_word();
			draw_eval_expr_into_integer(ivl_expr_oper1(arg),
						    addr_index);
			note_array_signal_use(asig);
			fprintf(vvp_out,
				"    %%load/preponed/av v%p, %d;\n",
				asig, addr_index);
			clr_word(addr_index);
			return;
		  }
		  fprintf(vvp_out, "    %%load/preponed v%p_0;\n", asig);
		  return;
	    }
	    /* Unexpected shape: fall back to the plain (alias) read. */
	    if (arg) {
		  draw_eval_vec4(arg);
		  return;
	    }
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n",
		    ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
	    return;
      }
      if (strncmp(ivl_expr_name(expr), "$ivl_array_query$", 17) == 0) {
	    ivl_expr_t arg = ivl_expr_parm(expr, 0);
	    ivl_expr_t dim = ivl_expr_parm(expr, 1);
	    unsigned query = 0;
	    const char*name = ivl_expr_name(expr) + 17;

	    if (strcmp(name, "size") == 0) query = 0;
	    else if (strcmp(name, "left") == 0) query = 1;
	    else if (strcmp(name, "right") == 0) query = 2;
	    else if (strcmp(name, "low") == 0) query = 3;
	    else if (strcmp(name, "high") == 0) query = 4;
	    else if (strcmp(name, "increment") == 0) query = 5;

	    draw_eval_object(arg);
	    draw_eval_expr_into_integer(dim, 3);
	    fprintf(vvp_out, "    %%qrange/o %u;\n", query);
	    return;
      }
      if (strcmp(ivl_expr_name(expr),"$ivl_queue_method$size")==0) {
	    ivl_expr_t arg = ivl_expr_parm(expr, 0);
	    if (arg && ivl_expr_type(arg) == IVL_EX_SIGNAL && ivl_expr_signal(arg)) {
		  /* A selected word of an object-backed fixed array is the
		   * queue/map receiver.  There is no scalar v<sig>_0 functor for
		   * such an array; evaluate the indexed object and query it through
		   * the object stack. */
		  if (ivl_signal_dimensions(ivl_expr_signal(arg)) > 0
		      && ivl_expr_oper1(arg)) {
			draw_eval_object(arg);
			fprintf(vvp_out, "    %%qsize/o;\n");
			return;
		  }
		  fprintf(vvp_out, "    %%qsize v%p_0;\n", ivl_expr_signal(arg));
		  return;
	    }
	    if (expr_is_queue_container_(arg)) {
		  draw_eval_object(arg);
		  fprintf(vvp_out, "    %%qsize/o;\n");
		  return;
	    }
	    /* Handle darray objects (e.g. this.value.size() where value is a
	     * darray class property). %qsize/o supports both queues and darrays. */
	    if (arg && (ivl_expr_value(arg) == IVL_VT_DARRAY
		        || ivl_expr_type(arg) == IVL_EX_PROPERTY)) {
		  draw_eval_object(arg);
		  fprintf(vvp_out, "    %%qsize/o;\n");
		  return;
	    }
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n",
	            ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
	    return;
      }
      if (strcmp(ivl_expr_name(expr), "$ivl_assoc_method$exists")==0) {
	    if (draw_assoc_exists_vec4(expr))
		  return;
      }
      /* AA .num() — load the array as an object then use %qsize/o which
       * calls dynamic_collection_size_() supporting vvp_assoc_base,
       * vvp_darray, and vvp_queue objects. */
      if (strcmp(ivl_expr_name(expr), "$ivl_assoc_method$num") == 0) {
	    ivl_expr_t arg = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    unsigned wid = ivl_expr_width(expr) ? ivl_expr_width(expr) : 32;
	    if (arg) {
		  draw_eval_object(arg);
		  fprintf(vvp_out, "    %%qsize/o;\n");
	    } else {
		  fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", wid);
	    }
	    return;
      }
      if (strncmp(ivl_expr_name(expr), "$ivl_assoc_method$", 18) == 0) {
	    if (draw_assoc_traversal_vec4(expr))
		  return;
      }

      /* Semaphore try_get: $ivl_semaphore$try_get(sem, [n]) -> bit on vec4 */
      if (strcmp(ivl_expr_name(expr), "$ivl_semaphore$try_get") == 0) {
	    ivl_expr_t sem_e = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    if (sem_e) draw_eval_object(sem_e);
	    if (parm_count > 1) {
		  draw_eval_vec4(ivl_expr_parm(expr, 1));
	    } else {
		  fprintf(vvp_out, "    %%pushi/vec4 1, 0, 32;\n");
	    }
	    fprintf(vvp_out, "    %%sem/try_get;\n");
	    /* widen result to match expression width */
	    if (ivl_expr_width(expr) > 1)
		  fprintf(vvp_out, "    %%pad/u %u;\n", ivl_expr_width(expr));
	    return;
      }

      /* Mailbox num: $ivl_mailbox$num(mbx) -> int on vec4 */
      if (strcmp(ivl_expr_name(expr), "$ivl_mailbox$num") == 0) {
	    ivl_expr_t mbx_e = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    if (mbx_e) draw_eval_object(mbx_e);
	    fprintf(vvp_out, "    %%mbx/num;\n");
	    if (ivl_expr_width(expr) > 1)
		  fprintf(vvp_out, "    %%pad/u %u;\n", ivl_expr_width(expr));
	    return;
      }

      /* Mailbox try_put: $ivl_mailbox$try_put(mbx, item) -> bit on vec4 */
      if (strcmp(ivl_expr_name(expr), "$ivl_mailbox$try_put") == 0) {
	    ivl_expr_t mbx_e  = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    ivl_expr_t item_e = (parm_count > 1) ? ivl_expr_parm(expr, 1) : 0;
	    if (mbx_e)  draw_eval_object(mbx_e);
	    if (item_e) {
		  if (ivl_expr_value(item_e) == IVL_VT_CLASS
		      || ivl_expr_value(item_e) == IVL_VT_DARRAY
		      || ivl_expr_value(item_e) == IVL_VT_QUEUE
		      || ivl_expr_value(item_e) == IVL_VT_NO_TYPE) {
			draw_eval_object(item_e);
		  } else if (ivl_expr_value(item_e) == IVL_VT_STRING
			     || ivl_expr_type(item_e) == IVL_EX_STRING) {
			draw_eval_string(item_e);
			fprintf(vvp_out, "    %%box/str;\n");
		  } else if (ivl_expr_value(item_e) == IVL_VT_REAL) {
			draw_eval_real(item_e);
			fprintf(vvp_out, "    %%box/real;\n");
		  } else {
			unsigned wid = ivl_expr_width(item_e);
			if (!wid) wid = 32;
			draw_eval_vec4(item_e);
			fprintf(vvp_out, "    %%box/vec4 %u;\n", wid);
		  }
	    } else {
		  fprintf(vvp_out, "    %%null;\n");
	    }
	    fprintf(vvp_out, "    %%mbx/try_put;\n");
	    if (ivl_expr_width(expr) > 1)
		  fprintf(vvp_out, "    %%pad/u %u;\n", ivl_expr_width(expr));
	    return;
      }

      /* Mailbox try_get/try_peek: $ivl_mailbox$try_get/peek(mbx[, item]) -> bit */
      if (strcmp(ivl_expr_name(expr), "$ivl_mailbox$try_get") == 0 ||
          strcmp(ivl_expr_name(expr), "$ivl_mailbox$try_peek") == 0) {
	    int is_peek = (strcmp(ivl_expr_name(expr), "$ivl_mailbox$try_peek") == 0);
	    ivl_expr_t mbx_e  = (parm_count > 0) ? ivl_expr_parm(expr, 0) : 0;
	    ivl_expr_t item_e = (parm_count > 1) ? ivl_expr_parm(expr, 1) : 0;
	    ivl_lval_t ref_lval = ivl_expr_ref_lval(expr);
	    int success_flag = allocate_flag();
	    unsigned lab_fail = local_count++;
	    unsigned lab_done = local_count++;
	    if (mbx_e) draw_eval_object(mbx_e);
	    if (ref_lval) {
		  draw_capture_lval_ref(ref_lval);
		  fprintf(vvp_out, "    %%swap/obj; mailbox receiver above captured output\n");
	    }
	    fprintf(vvp_out, "    %s;\n", is_peek ? "%mbx/try_peek" : "%mbx/try_get");
	    /* Preserve the expression result while using a duplicate to gate
	       ref-output writeback. A failed try leaves the actual unchanged. */
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    fprintf(vvp_out, "    %%flag_set/vec4 %d; test mailbox result\n",
		    success_flag);
	    fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; failed mailbox try\n",
		    thread_count, lab_fail, success_flag);
	    if (ref_lval) {
		  fprintf(vvp_out, "    %%ref/store/mbx;\n");
	    /* Legacy target input: if there's a signal output arg, store it. */
	    } else if (item_e && ivl_expr_type(item_e) == IVL_EX_SIGNAL
		&& ivl_expr_signal(item_e)) {
		  ivl_signal_t sig = ivl_expr_signal(item_e);
		  if (ivl_signal_data_type(sig) == IVL_VT_CLASS) {
			fprintf(vvp_out, "    %%store/obj v%p_0;\n", sig);
		  } else if (ivl_signal_data_type(sig) == IVL_VT_STRING) {
			fprintf(vvp_out, "    %%unbox/str;\n");
			fprintf(vvp_out, "    %%store/str v%p_0;\n", sig);
		  } else if (ivl_signal_data_type(sig) == IVL_VT_REAL) {
			fprintf(vvp_out, "    %%unbox/real;\n");
			fprintf(vvp_out, "    %%store/real v%p_0;\n", sig);
		  } else {
			unsigned wid = ivl_signal_width(sig);
			if (!wid) wid = 32;
			fprintf(vvp_out, "    %%unbox/vec4 %u;\n", wid);
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n", sig, wid);
		  }
	    } else {
		  /* No output var — discard item off obj stack */
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    }
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_done);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_fail);
	    fprintf(vvp_out, "    %%pop/obj %u, 0; discard failed mailbox item%s\n",
		    ref_lval ? 2U : 1U, ref_lval ? " and captured output" : "");
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_done);
	    clr_flag(success_flag);
	    if (ivl_expr_width(expr) > 1)
		  fprintf(vvp_out, "    %%pad/u %u;\n", ivl_expr_width(expr));
	    return;
      }

      draw_vpi_func_call(expr);
}

/* A signal-reference expression may be narrowed or widened by its enclosing
 * context even though the signal itself keeps its declared storage width.
 * The load opcodes return that storage width, so make the emitted stack value
 * match the expression width recorded by the elaborator. */
static void resize_loaded_signal_vec4_(ivl_expr_t expr, ivl_signal_t sig)
{
      unsigned signal_wid = ivl_signal_width(sig);
      unsigned expr_wid = ivl_expr_width(expr);
      if (signal_wid == expr_wid)
            return;

      fprintf(vvp_out, ivl_expr_signed(expr)
            ? "    %%pad/s %u;\n" : "    %%pad/u %u;\n", expr_wid);
}

static void draw_signal_vec4(ivl_expr_t expr)
{
      ivl_signal_t sig = ivl_expr_signal(expr);

	/* Special Case: If the signal is the return value of the function,
	   then use a different opcode to get the value. */
      if (signal_is_return_value(sig)) {
	    assert(ivl_signal_dimensions(sig) == 0);
	    fprintf(vvp_out, "    %%retload/vec4 0; Load %s (draw_signal_vec4)\n",
		    ivl_signal_basename(sig));
	    resize_loaded_signal_vec4_(expr, sig);
	    return;
      }

	/* Handle the simple case, a signal expression that is a
	   simple vector, no array dimensions. */
      if (ivl_signal_dimensions(sig) == 0) {
	    fprintf(vvp_out, "    %%load/vec4 v%p_0;\n", sig);
	    resize_loaded_signal_vec4_(expr, sig);
	    return;
      }

	/* calculate the array index... */
      int addr_index = allocate_word();
      draw_eval_expr_into_integer(ivl_expr_oper1(expr), addr_index);

      note_array_signal_use(sig);
      fprintf(vvp_out, "    %%load/vec4a v%p, %d;\n", sig, addr_index);
	/* An invalid fixed-array index loads X from the generic vec4 array
	   opcode. Apply the declared two-state element conversion here. */
      if (ivl_signal_data_type(sig) == IVL_VT_BOOL)
	    fprintf(vvp_out, "    %%cast2; fixed array element read\n");
      resize_loaded_signal_vec4_(expr, sig);
      clr_word(addr_index);
}

static void draw_string_vec4(ivl_expr_t expr)
{
      unsigned wid = ivl_expr_width(expr);
      char*fp = process_octal_codes(ivl_expr_string(expr), wid);
      char*p = fp;

      unsigned long tmp = 0;
      unsigned tmp_wid = 0;
      int push_flag = 0;

      for (unsigned idx = 0 ; idx < wid ; idx += 8) {
	    tmp <<= 8;
	    tmp |= (unsigned long)*p;
	    p += 1;
	    tmp_wid += 8;
	    if (tmp_wid == 32) {
		  fprintf(vvp_out, "    %%pushi/vec4 %lu, 0, 32; draw_string_vec4\n", tmp);
		  tmp = 0;
		  tmp_wid = 0;
		  if (push_flag == 0)
			push_flag += 1;
		  else
			fprintf(vvp_out, "    %%concat/vec4; draw_string_vec4\n");
	    }
      }

      if (tmp_wid > 0) {
	    fprintf(vvp_out, "    %%pushi/vec4 %lu, 0, %u; draw_string_vec4\n", tmp, tmp_wid);
	    if (push_flag != 0)
		  fprintf(vvp_out, "    %%concat/vec4; draw_string_vec4\n");
      }

      free(fp);
}

static void draw_ternary_vec4(ivl_expr_t expr)
{
      ivl_expr_t cond = ivl_expr_oper1(expr);
      ivl_expr_t true_ex = ivl_expr_oper2(expr);
      ivl_expr_t false_ex = ivl_expr_oper3(expr);

      unsigned lab_true  = local_count++;
      unsigned lab_out   = local_count++;

      int use_flag = draw_eval_condition(cond);

	/* The condition flag is used after possibly other statements,
	   so we need to put it into a non-common place. Allocate a
	   safe flag bit and move the condition to the flag position. */
      if (use_flag < 8) {
	    int tmp_flag = allocate_flag();
	    assert(tmp_flag >= 8);
	    fprintf(vvp_out, "    %%flag_mov %d, %d;\n", tmp_flag, use_flag);
	    use_flag = tmp_flag;
      }

      fprintf(vvp_out, "    %%jmp/0 T_%u.%u, %d;\n", thread_count, lab_true, use_flag);

	/* If the condition is true or xz (not false), we need the true
	   expression. If the condition is true, then we ONLY need the
	   true expression. */
      draw_eval_vec4(true_ex);
      fprintf(vvp_out, "    %%jmp/1 T_%u.%u, %d;\n", thread_count, lab_out, use_flag);
      fprintf(vvp_out, "T_%u.%u ; End of true expr.\n", thread_count, lab_true);

	/* If the condition is false or xz (not true), we need the false
	   expression. If the condition is false, then we ONLY need
	   the false expression. */
      draw_eval_vec4(false_ex);
      fprintf(vvp_out, "    %%jmp/0 T_%u.%u, %d;\n", thread_count, lab_out, use_flag);
      fprintf(vvp_out, " ; End of false expr.\n");

	/* Here, the condition is not true or false, it is xz. Both
	   the true and false expressions have been pushed onto the
	   stack, we just need to blend the bits. */
      fprintf(vvp_out, "    %%blend;\n");
      fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);

      clr_flag(use_flag);
}

static void draw_unary_inc_dec(ivl_expr_t sub, bool incr, bool pre)
{
      ivl_variable_type_t destination_type = ivl_expr_value(sub);

      /* A two-state selected l-value may carry a width-preserving bool cast
       * around the writable expression. The increment still targets the
       * underlying selection; draw_unary_expr applies the yielded-value
       * context after this routine returns. */
      if (ivl_expr_type(sub) == IVL_EX_UNARY
	  && ivl_expr_opcode(sub) == '2'
	  && destination_type == IVL_VT_BOOL
	  && ivl_expr_oper1(sub)
	  && ivl_expr_width(ivl_expr_oper1(sub)) == ivl_expr_width(sub))
	    sub = ivl_expr_oper1(sub);

      ivl_signal_t sig = 0;
      unsigned wid = 0;
      unsigned pidx = 0;
      ivl_signal_t prop_sig = 0;
      ivl_expr_t prop_base = 0;
      ivl_expr_t prop_word = 0;
      ivl_type_t prop_type = 0;
      bool is_property = false;
      bool is_property_select = false;
      bool is_array_word = false;
      bool is_signal_select = false;
      bool is_string_character = false;
      bool is_nested_signal_select = false;
      bool is_nested_property_select = false;
      bool is_array_word_select = false;
      bool is_array_string_character = false;
      ivl_expr_t array_word = 0;
      ivl_expr_t select_base = 0;
      int select_index = -1;
      int select_flag = -1;
      unsigned carrier_count = 0;
      int*carrier_index = 0;
      int*carrier_flag = 0;
      unsigned*carrier_width = 0;
      ivl_expr_t*carrier_base = 0;
      int array_index = -1;
      int array_flag = -1;
      int prop_index = 0;
      int prop_x_flag = -1;
      int prop_range_flag = -1;
      unsigned prop_carrier_width = 0;
      unsigned lab_null = 0;
      unsigned lab_out = 0;
      unsigned lab_invalid = 0;
      unsigned lab_value = 0;
      unsigned lab_skip_store = 0;
      unsigned lab_after_store = 0;

	      switch (ivl_expr_type(sub)) {
	  case IVL_EX_SELECT: {
		ivl_expr_t e1 = ivl_expr_oper1(sub);
		select_base = ivl_expr_oper2(sub);
		if (!e1 || !select_base
		    || (ivl_expr_type(e1) != IVL_EX_SIGNAL
		        && ivl_expr_type(e1) != IVL_EX_PROPERTY
		        && ivl_expr_type(e1) != IVL_EX_SELECT)) {
		      fprintf(stderr, "%s:%u: vvp.tgt error: unsupported packed "
		              "++/-- destination.\n",
		              ivl_expr_file(sub), ivl_expr_lineno(sub));
		      vvp_errors += 1;
		      draw_eval_vec4(sub);
		      return;
		}
		if (ivl_expr_type(e1) == IVL_EX_PROPERTY) {
		      pidx = ivl_expr_property_idx(e1);
		      prop_sig = ivl_expr_signal(e1);
		      prop_base = ivl_expr_oper2(e1);
		      prop_word = ivl_expr_oper1(e1);
		      prop_type = property_expr_type_(e1);
		      if (pidx == (unsigned)-1 || (!prop_sig && !prop_base)
		          || (prop_word && !property_selects_fixed_uarray_slot_(e1))
		          || (ivl_expr_value(e1) != IVL_VT_LOGIC
		              && ivl_expr_value(e1) != IVL_VT_BOOL)) {
			    fprintf(stderr, "%s:%u: vvp.tgt error: unsupported packed "
			            "property ++/-- destination.\n",
			            ivl_expr_file(sub), ivl_expr_lineno(sub));
			    vvp_errors += 1;
			    draw_eval_vec4(sub);
			    return;
		      }
		      is_property = true;
		      is_property_select = true;
		      lab_null = local_count++;
		      lab_out = local_count++;
		      if (prop_word) {
			    prop_carrier_width = ivl_expr_width(e1);
			    if (!prop_carrier_width) {
			          fprintf(stderr, "%s:%u: vvp.tgt error: unsupported packed "
			                  "property array element type.\n",
			                  ivl_expr_file(sub), ivl_expr_lineno(sub));
			          vvp_errors += 1;
			          draw_eval_vec4(sub);
			          return;
			    }
			    lab_invalid = local_count++;
			    lab_value = local_count++;
			    lab_skip_store = local_count++;
			    lab_after_store = local_count++;
		      }
		      wid = ivl_expr_width(sub);
		      break;
		}
		if (ivl_expr_type(e1) == IVL_EX_SELECT) {
		      ivl_expr_t root = e1;
		      while (root && ivl_expr_type(root) == IVL_EX_SELECT) {
			    carrier_count += 1;
			    root = ivl_expr_oper1(root);
		      }
		      ivl_type_t root_prop_type = root && ivl_expr_type(root) == IVL_EX_PROPERTY
		            ? property_expr_type_(root) : 0;
		      if (root_prop_type
		          && carrier_count == 1
		          && ivl_expr_oper1(root) == 0
		          && (ivl_type_base(root_prop_type) == IVL_VT_QUEUE
		              || ivl_type_base(root_prop_type) == IVL_VT_DARRAY)) {
			    pidx = ivl_expr_property_idx(root);
			    prop_sig = ivl_expr_signal(root);
			    prop_base = ivl_expr_oper2(root);
			    if (pidx == (unsigned)-1 || (!prop_sig && !prop_base)) {
			          fprintf(stderr, "%s:%u: vvp.tgt error: unsupported nested packed "
			                  "property ++/-- destination.\n", ivl_expr_file(sub),
			                  ivl_expr_lineno(sub));
			          vvp_errors += 1; draw_eval_vec4(sub); return;
			    }
			    carrier_base = calloc(1, sizeof *carrier_base);
			    carrier_width = calloc(1, sizeof *carrier_width);
			    carrier_base[0] = ivl_expr_oper2(e1);
			    carrier_width[0] = ivl_expr_width(e1);
			    if (!carrier_base[0] || !carrier_width[0]) {
			          free(carrier_base); free(carrier_width);
			          fprintf(stderr, "%s:%u: vvp.tgt error: unsupported nested packed "
			                  "property ++/-- destination.\n", ivl_expr_file(sub),
			                  ivl_expr_lineno(sub));
			          vvp_errors += 1; draw_eval_vec4(sub); return;
			    }
			    wid = ivl_expr_width(sub);
			    is_nested_property_select = true;
			    lab_null = local_count++;
			    lab_out = local_count++;
			    break;
		      }
		      if (!root || ivl_expr_type(root) != IVL_EX_SIGNAL
		          || !ivl_expr_signal(root)
		          || ivl_signal_dimensions(ivl_expr_signal(root)) != 0) {
			    fprintf(stderr, "%s:%u: vvp.tgt error: unsupported nested packed "
			            "++/-- destination.\n", ivl_expr_file(sub),
			            ivl_expr_lineno(sub));
			    vvp_errors += 1; draw_eval_vec4(sub); return;
		      }
		      sig = ivl_expr_signal(root);
		      carrier_index = calloc(carrier_count, sizeof *carrier_index);
		      carrier_flag = calloc(carrier_count, sizeof *carrier_flag);
		      carrier_width = calloc(carrier_count, sizeof *carrier_width);
		      carrier_base = calloc(carrier_count, sizeof *carrier_base);
		      root = e1;
		      for (unsigned idx = 0; idx < carrier_count; idx += 1) {
			    carrier_base[idx] = ivl_expr_oper2(root);
			    carrier_width[idx] = ivl_expr_width(root);
			    if (!carrier_base[idx] || !carrier_width[idx]) {
			          fprintf(stderr, "%s:%u: vvp.tgt error: unsupported nested packed "
			                  "++/-- destination.\n", ivl_expr_file(sub),
			                  ivl_expr_lineno(sub));
			          vvp_errors += 1;
			          free(carrier_index); free(carrier_flag);
			          free(carrier_width); free(carrier_base);
			          draw_eval_vec4(sub); return;
			    }
			    root = ivl_expr_oper1(root);
		      }
		      wid = ivl_expr_width(sub);
		      is_nested_signal_select = true;
		      break;
		}
		sig = ivl_expr_signal(e1);
		if (!sig) {
		      fprintf(stderr, "%s:%u: vvp.tgt error: unsupported packed "
		              "++/-- destination.\n",
		              ivl_expr_file(sub), ivl_expr_lineno(sub));
		      vvp_errors += 1;
		      draw_eval_vec4(sub);
		      return;
		}
		if (ivl_signal_dimensions(sig) > 0) {
		      array_word = ivl_expr_oper1(e1);
		      if (!array_word) {
			    fprintf(stderr, "%s:%u: vvp.tgt error: unsupported packed "
			            "++/-- array destination.\n",
			            ivl_expr_file(sub), ivl_expr_lineno(sub));
			    vvp_errors += 1;
			    draw_eval_vec4(sub);
			    return;
		      }
		      if (ivl_signal_data_type(sig) == IVL_VT_STRING) {
			    if (signal_is_return_value(sig)) {
			          fprintf(stderr, "%s:%u: vvp.tgt error: unsupported string "
			                  "array return CHARACTER ++/-- destination.\n",
			                  ivl_expr_file(sub), ivl_expr_lineno(sub));
			          vvp_errors += 1;
			          draw_eval_vec4(sub);
			          return;
			    }
			    is_array_string_character = true;
			    wid = 8;
			    break;
		      }
		      is_array_word_select = true;
		}
		if (ivl_signal_dimensions(sig) == 0
		    && ivl_signal_data_type(sig) == IVL_VT_STRING) {
		      is_string_character = true;
		      wid = 8;
		      break;
		}
		wid = ivl_expr_width(sub);
		is_signal_select = true;
		break;
	  }

	  case IVL_EX_SIGNAL:
	    sig = ivl_expr_signal(sub);
	    wid = ivl_expr_width(sub);
	    is_array_word = ivl_signal_dimensions(sig) > 0;
	    break;

	  case IVL_EX_PROPERTY:
	    pidx = ivl_expr_property_idx(sub);
	    prop_sig = ivl_expr_signal(sub);
	    prop_base = ivl_expr_oper2(sub);
	    prop_word = ivl_expr_oper1(sub);
	    prop_type = property_expr_type_(sub);
	    wid = ivl_expr_width(sub);
	    if ((pidx == (unsigned)-1) || (!prop_sig && !prop_base)
		|| (prop_word && !property_selects_fixed_uarray_slot_(sub))) {
		  fprintf(stderr, "%s:%u: vvp.tgt error: unsupported integral "
		          "property ++/-- destination.\n",
		          ivl_expr_file(sub), ivl_expr_lineno(sub));
		  vvp_errors += 1;
		  draw_eval_vec4(sub);
		  return;
	    }
	    is_property = true;
	    lab_null = local_count++;
	    lab_out = local_count++;
	    if (prop_word) {
		  lab_invalid = local_count++;
		  lab_value = local_count++;
		  lab_skip_store = local_count++;
		  lab_after_store = local_count++;
	    }
	    break;

		  default:
		    fprintf(stderr, "%s:%u: vvp.tgt sorry: ++/-- on expression type %d "
		                    "not fully supported; using read-only fallback.\n",
			    ivl_expr_file(sub), ivl_expr_lineno(sub), ivl_expr_type(sub));
		    draw_eval_vec4(sub);
		    return;
	      }

      if (is_property) {
	    /* Capture the receiver before evaluating an array index: the index
	       expression may itself rebind the variable that supplied it. */
	    if (prop_sig)
		  fprintf(vvp_out, "    %%load/obj v%p_0; property increment receiver\n",
		          prop_sig);
	    else
		  draw_eval_object(prop_base);
	    fprintf(vvp_out, "    %%test_nul/obj;\n");
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
	    if (prop_word) {
		  prop_index = allocate_word();
		  draw_fixed_uarray_slot_index_(prop_word, prop_type, prop_index,
					       &prop_x_flag, &prop_range_flag);
		  fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; invalid property slot\n",
		          thread_count, lab_invalid, prop_x_flag);
		  fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; property slot out of range\n",
		          thread_count, lab_invalid, prop_range_flag);
		  fprintf(vvp_out, "    %%prop/v/i %u, %d;\n", pidx, prop_index);
		  fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_value);
		  fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_invalid);
		  if (destination_type == IVL_VT_LOGIC)
			draw_pushi_all_x(is_property_select
			      ? prop_carrier_width : wid);
		  else
			fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n",
			        is_property_select ? prop_carrier_width : wid);
		  fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_value);
	    } else {
		  fprintf(vvp_out, "    %%prop/v %u;\n", pidx);
	    }
	    if (is_property_select) {
		  select_index = allocate_word();
		  select_flag = allocate_flag();
		  draw_eval_vec4(select_base);
		  fprintf(vvp_out, "    %%dup/vec4; preserve packed property select base\n");
		  fprintf(vvp_out, ivl_expr_signed(select_base)
		        ? "    %%ix/vec4/s %d; packed property select base\n"
		        : "    %%ix/vec4 %d; packed property select base\n",
		        select_index);
		  fprintf(vvp_out, "    %%flag_mov %d, 4; preserve packed property select validity\n",
		          select_flag);
		  fprintf(vvp_out, ivl_expr_signed(select_base)
		        ? "    %%part/s %u; increment selected property value\n"
		        : "    %%part/u %u; increment selected property value\n", wid);
	    }
	  } else if (is_nested_property_select) {
	    carrier_index = calloc(1, sizeof *carrier_index);
	    carrier_flag = calloc(1, sizeof *carrier_flag);
	    carrier_index[0] = allocate_word();
	    carrier_flag[0] = allocate_flag();
	    select_index = allocate_word(); select_flag = allocate_flag();
	    if (prop_sig)
	          fprintf(vvp_out, "    %%load/obj v%p_0; nested property receiver\n", prop_sig);
	    else
	          draw_eval_object(prop_base);
	    fprintf(vvp_out, "    %%test_nul/obj;\n");
	    fprintf(vvp_out, "    %%jmp/1 T_%u.%u, 4;\n", thread_count, lab_null);
	    fprintf(vvp_out, "    %%prop/obj %u, 0; nested packed container\n", pidx);
	    fprintf(vvp_out, "    %%pop/obj 1, 1; discard class owner\n");
	    draw_eval_expr_into_integer(carrier_base[0], carrier_index[0]);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve container word validity\n",
	            carrier_flag[0]);
	    fprintf(vvp_out, "    %%ix/mov 3, %d; container word\n", carrier_index[0]);
	    fprintf(vvp_out, "    %%dup/obj/ref; preserve packed container receiver\n");
	    fprintf(vvp_out, "    %%load/qo/v %u; nested packed container word\n",
	            carrier_width[0]);
	    draw_eval_vec4(select_base);
	    fprintf(vvp_out, "    %%dup/vec4; preserve nested property select base\n");
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	          ? "    %%ix/vec4/s %d; nested property select base\n"
	          : "    %%ix/vec4 %d; nested property select base\n", select_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve nested property select validity\n",
	            select_flag);
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	          ? "    %%part/s %u; nested property selected value\n"
	          : "    %%part/u %u; nested property selected value\n", wid);
	  } else if (is_nested_signal_select) {
	    select_index = allocate_word(); select_flag = allocate_flag();
	    for (unsigned idx = 0; idx < carrier_count; idx += 1) {
	          carrier_index[idx] = allocate_word();
	          carrier_flag[idx] = allocate_flag();
	    }
	    if (signal_is_return_value(sig))
	          fprintf(vvp_out, "    %%retload/vec4 0; nested packed return carrier\n");
	    else
	          fprintf(vvp_out, "    %%load/vec4 v%p_0; nested packed carrier\n", sig);
	    for (unsigned pos = carrier_count; pos > 0; pos -= 1) {
	          unsigned idx = pos - 1;
	          draw_eval_vec4(carrier_base[idx]);
	          fprintf(vvp_out, "    %%dup/vec4; preserve carrier base\n");
	          if (!ivl_expr_signed(carrier_base[idx])) {
			unsigned bwid = ivl_expr_width(carrier_base[idx]);
			fprintf(vvp_out, "    %%pad/u %u; validate unsigned carrier base\n",
			        bwid < 65 ? 65 : bwid);
	          }
	          fprintf(vvp_out, "    %%ix/vec4/s %d; carrier base\n", carrier_index[idx]);
	          fprintf(vvp_out, "    %%flag_mov %d, 4; preserve carrier validity\n", carrier_flag[idx]);
	          fprintf(vvp_out, ivl_expr_signed(carrier_base[idx])
	                ? "    %%part/s %u; nested carrier\n"
	                : "    %%part/u %u; nested carrier\n", carrier_width[idx]);
	    }
	    draw_eval_vec4(select_base);
	    fprintf(vvp_out, "    %%dup/vec4; preserve nested select base\n");
	    if (!ivl_expr_signed(select_base)) {
	          unsigned bwid = ivl_expr_width(select_base);
	          fprintf(vvp_out, "    %%pad/u %u; validate unsigned nested select base\n",
	                  bwid < 65 ? 65 : bwid);
	    }
	    fprintf(vvp_out, "    %%ix/vec4/s %d; nested select base\n", select_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve nested select validity\n", select_flag);
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	          ? "    %%part/s %u; nested selected value\n"
	          : "    %%part/u %u; nested selected value\n", wid);
	  } else if (is_string_character) {
	    select_index = allocate_word();
	    select_flag = allocate_flag();
	    draw_eval_vec4(select_base);
	    resize_vec4_wid(select_base, 32);
	    fprintf(vvp_out, "    %%cast2; string character selector to int\n");
	    fprintf(vvp_out, "    %%ix/vec4/s %d; capture string character selector\n",
	            select_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve string character selector\n",
	            select_flag);
	    if (signal_is_return_value(sig))
	          fprintf(vvp_out, "    %%retload/str 0; increment string return character\n");
	    else
	          fprintf(vvp_out, "    %%load/str v%p_0; increment string character\n", sig);
	    fprintf(vvp_out, "    %%substr/vec4 %d, 8; selected string character\n",
	            select_index);
	    fprintf(vvp_out, "    %%pop/str 1; discard captured string\n");
	  } else if (is_array_string_character) {
	    array_index = allocate_word();
	    array_flag = allocate_flag();
	    select_index = allocate_word();
	    draw_eval_expr_into_integer(array_word, array_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve string array word selector\n",
	            array_flag);
	    draw_eval_vec4(select_base);
	    resize_vec4_wid(select_base, 32);
	    fprintf(vvp_out, "    %%cast2; string array character selector to int\n");
	    fprintf(vvp_out, "    %%ix/vec4/s %d; capture string array character selector\n",
	            select_index);
	    fprintf(vvp_out, "    %%flag_mov 4, %d; restore string array word selector for read\n",
	            array_flag);
	    fprintf(vvp_out, "    %%load/stra v%p, %d; increment string array character\n",
	            sig, array_index);
	    fprintf(vvp_out, "    %%substr/vec4 %d, 8; selected string array character\n",
	            select_index);
	    fprintf(vvp_out, "    %%pop/str 1; discard captured string array word\n");
	  } else if (is_array_word_select) {
	    array_index = allocate_word();
	    array_flag = allocate_flag();
	    select_index = allocate_word();
	    select_flag = allocate_flag();
	    draw_eval_expr_into_integer(array_word, array_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve array index validity\n",
	            array_flag);
	    note_array_signal_use(sig);
	    fprintf(vvp_out, "    %%load/vec4a v%p, %d; increment packed array word\n",
	            sig, array_index);
	    draw_eval_vec4(select_base);
	    fprintf(vvp_out, "    %%dup/vec4; preserve packed select base\n");
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	            ? "    %%ix/vec4/s %d; packed select base\n"
	            : "    %%ix/vec4 %d; packed select base\n", select_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve packed select validity\n",
	            select_flag);
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	            ? "    %%part/s %u; increment selected value\n"
	            : "    %%part/u %u; increment selected value\n", wid);
	  } else if (is_array_word) {
	    array_index = allocate_word();
	    array_flag = allocate_flag();
	    draw_eval_expr_into_integer(ivl_expr_oper1(sub), array_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve array index validity\n",
	            array_flag);
	    note_array_signal_use(sig);
	    fprintf(vvp_out, "    %%load/vec4a v%p, %d;\n", sig, array_index);
	  } else if (is_signal_select) {
	    select_index = allocate_word();
	    select_flag = allocate_flag();
	    if (signal_is_return_value(sig))
	          fprintf(vvp_out, "    %%retload/vec4 0; increment packed return carrier\n");
	    else
	          fprintf(vvp_out, "    %%load/vec4 v%p_0; increment packed carrier\n",
	                  sig);
	    draw_eval_vec4(select_base);
	    fprintf(vvp_out, "    %%dup/vec4; preserve packed select base\n");
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	            ? "    %%ix/vec4/s %d; packed select base\n"
	            : "    %%ix/vec4 %d; packed select base\n", select_index);
	    fprintf(vvp_out, "    %%flag_mov %d, 4; preserve packed select validity\n",
	            select_flag);
	    fprintf(vvp_out, ivl_expr_signed(select_base)
	            ? "    %%part/s %u; increment selected value\n"
	            : "    %%part/u %u; increment selected value\n", wid);
	  } else {
	    draw_eval_vec4(sub);
      }

      const char*cmd = incr? "%add" : "%sub";

      if (destination_type == IVL_VT_BOOL)
	    fprintf(vvp_out, "    %%cast2; increment destination\n");

      if (pre) {
	      /* prefix means we add the result first, and store the
		 result, as well as leaving a copy on the stack. */
	    fprintf(vvp_out, "    %si 1, 0, %u;\n", cmd, wid);
	    if (destination_type == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2; increment result\n");
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    if (is_property) {
		  if (prop_word) {
			fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; suppress invalid property store\n",
			        thread_count, lab_skip_store, prop_x_flag);
			fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; suppress out-of-range property store\n",
			        thread_count, lab_skip_store, prop_range_flag);
		  }
		  if (is_property_select) {
			fprintf(vvp_out, "    %%flag_mov 4, %d; restore packed property select validity\n",
			        select_flag);
			if (prop_word) {
			      fprintf(vvp_out, ivl_expr_signed(select_base)
			            ? "    %%store/prop/v/i/bits/x %u, %d, %d;\n"
			            : "    %%store/prop/v/i/bits/ux %u, %d, %d;\n",
			            pidx, prop_index, select_index);
			} else {
			      fprintf(vvp_out, ivl_expr_signed(select_base)
			            ? "    %%store/prop/v/bits/x %u, %d, %u;\n"
			            : "    %%store/prop/v/bits/ux %u, %d, %u;\n",
			            pidx, select_index, wid);
			}
		  } else if (prop_word)
			fprintf(vvp_out, "    %%store/prop/v/i %u, %d, %u;\n",
			        pidx, prop_index, wid);
		  else
			fprintf(vvp_out, "    %%store/prop/v %u, %u;\n", pidx, wid);
		  if (prop_word) {
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_after_store);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_skip_store);
			fprintf(vvp_out, "    %%pop/vec4 1; discard invalid property update\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_after_store);
		  }
	    } else if (is_nested_property_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore nested property select validity\n",
		          select_flag);
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine container word validity\n",
		          carrier_flag[0]);
		  fprintf(vvp_out, "    %%set/dar/obj/vec4/off %d, %d, %u;\n",
		          carrier_index[0], select_index, wid);
	    } else if (is_nested_signal_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore nested select validity\n", select_flag);
		  for (unsigned idx = 0; idx < carrier_count; idx += 1) {
			fprintf(vvp_out, "    %%flag_or 4, %d; combine carrier validity\n",
			        carrier_flag[idx]);
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			        carrier_width[idx]);
			fprintf(vvp_out, "    %%clip/vec4/d %d, %d; bounded nested store\n",
			        select_index, carrier_index[idx]);
		  }
		  if (signal_is_return_value(sig)) fprintf(vvp_out, "    %%ret/vec4/v 0, %d;\n", select_index);
		  else fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n", sig, select_index);
	    } else if (is_string_character) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string character selector\n",
		          select_flag);
		  if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%putc/ret/vec4 0, %d; increment string return character\n",
			        select_index);
		  else
			fprintf(vvp_out, "    %%putc/str/vec4 v%p_0, %d; increment string character\n",
			        sig, select_index);
	    } else if (is_array_string_character) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string array word selector\n",
		          array_flag);
		  fprintf(vvp_out, "    %%putc/stra/vec4 v%p, %d, %d; increment string array character\n",
		          sig, array_index, select_index);
	    } else if (is_array_word_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore packed select validity\n",
		          select_flag);
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine array index validity\n",
		          array_flag);
		  fprintf(vvp_out, "    %%store/vec4a v%p, %d, %d;\n",
		          sig, array_index, select_index);
	    } else if (is_array_word) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore array index validity\n",
		          array_flag);
		  fprintf(vvp_out, "    %%store/vec4a v%p, %d, 0;\n", sig, array_index);
	    } else if (is_signal_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore packed select validity\n",
		          select_flag);
		  if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%ret/vec4/v 0, %d;\n", select_index);
		  else
			fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n", sig,
			        select_index);
	    } else {
		  if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", wid);
		  else
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n", sig, wid);
	    }

      } else {
	      /* The post-fix decrement returns the non-decremented
		 version, so there is a slight re-arrange. */
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    fprintf(vvp_out, "    %si 1, 0, %u;\n", cmd, wid);
	    if (destination_type == IVL_VT_BOOL)
		  fprintf(vvp_out, "    %%cast2; increment result\n");
	    if (is_property) {
		  if (prop_word) {
			fprintf(vvp_out, "    %%jmp/1xz T_%u.%u, %d; suppress invalid property store\n",
			        thread_count, lab_skip_store, prop_x_flag);
			fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, %d; suppress out-of-range property store\n",
			        thread_count, lab_skip_store, prop_range_flag);
		  }
		  if (is_property_select) {
			fprintf(vvp_out, "    %%flag_mov 4, %d; restore packed property select validity\n",
			        select_flag);
			if (prop_word) {
			      fprintf(vvp_out, ivl_expr_signed(select_base)
			            ? "    %%store/prop/v/i/bits/x %u, %d, %d;\n"
			            : "    %%store/prop/v/i/bits/ux %u, %d, %d;\n",
			            pidx, prop_index, select_index);
			} else {
			      fprintf(vvp_out, ivl_expr_signed(select_base)
			            ? "    %%store/prop/v/bits/x %u, %d, %u;\n"
			            : "    %%store/prop/v/bits/ux %u, %d, %u;\n",
			            pidx, select_index, wid);
			}
		  } else if (prop_word)
			fprintf(vvp_out, "    %%store/prop/v/i %u, %d, %u;\n",
			        pidx, prop_index, wid);
		  else
			fprintf(vvp_out, "    %%store/prop/v %u, %u;\n", pidx, wid);
		  if (prop_word) {
			fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_after_store);
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_skip_store);
			fprintf(vvp_out, "    %%pop/vec4 1; discard invalid property update\n");
			fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_after_store);
		  }
	    } else if (is_nested_property_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore nested property select validity\n",
		          select_flag);
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine container word validity\n",
		          carrier_flag[0]);
		  fprintf(vvp_out, "    %%set/dar/obj/vec4/off %d, %d, %u;\n",
		          carrier_index[0], select_index, wid);
	    } else if (is_nested_signal_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore nested select validity\n", select_flag);
		  for (unsigned idx = 0; idx < carrier_count; idx += 1) {
			fprintf(vvp_out, "    %%flag_or 4, %d; combine carrier validity\n",
			        carrier_flag[idx]);
			fprintf(vvp_out, "    %%pushi/vec4 %u, 0, 32; carrier width\n",
			        carrier_width[idx]);
			fprintf(vvp_out, "    %%clip/vec4/d %d, %d; bounded nested store\n",
			        select_index, carrier_index[idx]);
		  }
		  if (signal_is_return_value(sig)) fprintf(vvp_out, "    %%ret/vec4/v 0, %d;\n", select_index);
		  else fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n", sig, select_index);
	    } else if (is_string_character) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string character selector\n",
		          select_flag);
		  if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%putc/ret/vec4 0, %d; decrement string return character\n",
			        select_index);
		  else
			fprintf(vvp_out, "    %%putc/str/vec4 v%p_0, %d; decrement string character\n",
			        sig, select_index);
	    } else if (is_array_string_character) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore string array word selector\n",
		          array_flag);
		  fprintf(vvp_out, "    %%putc/stra/vec4 v%p, %d, %d; decrement string array character\n",
		          sig, array_index, select_index);
	    } else if (is_array_word_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore packed select validity\n",
		          select_flag);
		  fprintf(vvp_out, "    %%flag_or 4, %d; combine array index validity\n",
		          array_flag);
		  fprintf(vvp_out, "    %%store/vec4a v%p, %d, %d;\n",
		          sig, array_index, select_index);
	    } else if (is_array_word) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore array index validity\n",
		          array_flag);
		  fprintf(vvp_out, "    %%store/vec4a v%p, %d, 0;\n", sig, array_index);
	    } else if (is_signal_select) {
		  fprintf(vvp_out, "    %%flag_mov 4, %d; restore packed select validity\n",
		          select_flag);
		  if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%ret/vec4/v 0, %d;\n", select_index);
		  else
			fprintf(vvp_out, "    %%store/vec4/v v%p_0, %d;\n", sig,
			        select_index);
	    } else {
		  if (signal_is_return_value(sig))
			fprintf(vvp_out, "    %%ret/vec4 0, 0, %u;\n", wid);
		  else
			fprintf(vvp_out, "    %%store/vec4 v%p_0, 0, %u;\n", sig, wid);
	    }
      }

      if (is_property) {
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
	    fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", wid);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
	    if (prop_index) clr_word(prop_index);
	    if (prop_x_flag >= 0) clr_flag(prop_x_flag);
	    if (prop_range_flag >= 0) clr_flag(prop_range_flag);
	    if (is_property_select) {
		  clr_word(select_index);
		  clr_flag(select_flag);
	    }
	  } else if (is_nested_property_select) {
	    fprintf(vvp_out, "    %%pop/obj 1, 0; discard packed container receiver\n");
	    fprintf(vvp_out, "    %%jmp T_%u.%u;\n", thread_count, lab_out);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_null);
	    fprintf(vvp_out, "    %%pop/obj 1, 0; discard null class receiver\n");
	    if (destination_type == IVL_VT_LOGIC)
	          draw_pushi_all_x(wid);
	    else
	          fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u;\n", wid);
	    fprintf(vvp_out, "T_%u.%u;\n", thread_count, lab_out);
	    clr_word(carrier_index[0]); clr_flag(carrier_flag[0]);
	    clr_word(select_index); clr_flag(select_flag);
	    free(carrier_index); free(carrier_flag);
	    free(carrier_width); free(carrier_base);
	  } else if (is_nested_signal_select) {
	    for (unsigned idx = 0; idx < carrier_count; idx += 1) {
	          clr_word(carrier_index[idx]); clr_flag(carrier_flag[idx]);
	    }
	    free(carrier_index); free(carrier_flag);
	    free(carrier_width); free(carrier_base);
	    clr_word(select_index); clr_flag(select_flag);
	  } else if (is_string_character) {
	    clr_word(select_index); clr_flag(select_flag);
	  } else if (is_array_string_character) {
	    clr_word(array_index); clr_flag(array_flag);
	    clr_word(select_index);
	  } else if (is_array_word_select) {
	    clr_word(array_index);
	    clr_flag(array_flag);
	    clr_word(select_index);
	    clr_flag(select_flag);
	  } else if (is_array_word) {
	    clr_word(array_index);
	    clr_flag(array_flag);
      } else if (is_signal_select) {
	    clr_word(select_index);
	    clr_flag(select_flag);
      }
}

static void draw_unary_vec4(ivl_expr_t expr)
{
      ivl_expr_t sub = ivl_expr_oper1(expr);

      if (debug_draw) {
	    fprintf(vvp_out, " ; %s:%u:draw_unary_vec4: opcode=%c\n",
		    ivl_expr_file(expr), ivl_expr_lineno(expr),
		    ivl_expr_opcode(expr));
      }

      switch (ivl_expr_opcode(expr)) {
	  case '&':
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%and/r;\n");
	    break;

	  case '|':
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%or/r;\n");
	    break;

	  case '^':
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%xor/r;\n");
	    break;

	  case '~':
	    draw_eval_vec4(sub);
	      /* Unary integral operands are context determined. The
	         elaborator records that context on the unary expression,
	         but the operand can retain its original width. Apply the
	         expression width before the operation so the bytecode stack
	         contains the width promised by ivl_expr_width(expr). */
	    resize_vec4_wid(sub, ivl_expr_width(expr));
	    fprintf(vvp_out, "    %%inv;\n");
	    break;

	  case '!':
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%nor/r;\n");
	    break;

	  case '-':
	    draw_eval_vec4(sub);
	    resize_vec4_wid(sub, ivl_expr_width(expr));
	    fprintf(vvp_out, "    %%inv;\n");
	    fprintf(vvp_out, "    %%addi 1, 0, %u;\n", ivl_expr_width(expr));
	    break;

	  case 'A': /* nand (~&) */
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%nand/r;\n");
	    break;

	  case 'D': /* pre-decrement (--x) */
	    draw_unary_inc_dec(sub, false, true);
	    resize_vec4_wid(sub, ivl_expr_width(expr));
	    break;

	  case 'd': /* post_decrement (x--) */
	    draw_unary_inc_dec(sub, false, false);
	    resize_vec4_wid(sub, ivl_expr_width(expr));
	    break;

	  case 'I': /* pre-increment (++x) */
	    draw_unary_inc_dec(sub, true, true);
	    resize_vec4_wid(sub, ivl_expr_width(expr));
	    break;

	  case 'i': /* post-increment (x++) */
	    draw_unary_inc_dec(sub, true, false);
	    resize_vec4_wid(sub, ivl_expr_width(expr));
	    break;

	  case 'N': /* nor (~|) */
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%nor/r;\n");
	    break;

	  case 'X': /* xnor (~^) */
	    draw_eval_vec4(sub);
	    fprintf(vvp_out, "    %%xnor/r;\n");
	    break;

	  case 'm': /* abs(m) */
	    draw_eval_vec4(sub);
	    if (! ivl_expr_signed(sub))
		  break;

	      /* Test if (m) < 0 */
	    fprintf(vvp_out, "    %%dup/vec4;\n");
	    fprintf(vvp_out, "    %%cmpi/s 0, 0, %u;\n", ivl_expr_width(sub));
	    fprintf(vvp_out, "    %%jmp/0xz T_%u.%u, 5;\n", thread_count, local_count);
	      /* If so, calculate -(m) */
	    fprintf(vvp_out, "    %%inv;\n");
	    fprintf(vvp_out, "    %%addi 1, 0, %u;\n", ivl_expr_width(sub));
	    fprintf(vvp_out, "T_%u.%u ;\n", thread_count, local_count);
	    local_count += 1;
	    break;

	  case 'v': /* Cast expression to vec4 */
	    switch (ivl_expr_value(sub)) {
		case IVL_VT_REAL:
		  draw_eval_real(sub);
		  fprintf(vvp_out, "    %%cvt/vr %u;\n", ivl_expr_width(expr));
		  break;
		case IVL_VT_STRING:
		  draw_eval_string(sub);
		  fprintf(vvp_out, "    %%cast/vec4/str %u;\n", ivl_expr_width(expr));
		  break;
		case IVL_VT_DARRAY:
		  draw_eval_object(sub);
		  fprintf(vvp_out, "    %%cast/vec4/dar %u;\n", ivl_expr_width(expr));
		  break;
		default:
		  assert(0);
		  break;
	    }
	    break;

	  case '2': /* Cast expression to bool */
	    switch (ivl_expr_value(sub)) {
		case IVL_VT_LOGIC:
		  draw_eval_vec4(sub);
		  fprintf(vvp_out, "    %%cast2;\n");
		  resize_vec4_wid(sub, ivl_expr_width(expr));
		  break;
		case IVL_VT_BOOL:
		  draw_eval_vec4(sub);
		  resize_vec4_wid(sub, ivl_expr_width(expr));
		  break;
		case IVL_VT_REAL:
		  draw_eval_real(sub);
		  fprintf(vvp_out, "    %%cvt/vr %u;\n", ivl_expr_width(expr));
		  break;
		case IVL_VT_STRING:
		  draw_eval_string(sub);
		  fprintf(vvp_out, "    %%cast/vec4/str %u;\n", ivl_expr_width(expr));
		  break;
		case IVL_VT_DARRAY:
		  draw_eval_object(sub);
		  fprintf(vvp_out, "    %%cast/vec2/dar %u;\n", ivl_expr_width(expr));
		  break;
		case IVL_VT_CLASS:
		  /* Cast class handle to bool: non-null handle is true. */
		  draw_eval_object(sub);
		  fprintf(vvp_out, "    %%test_nul/obj;\n");
		  fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
		  fprintf(vvp_out, "    %%flag_inv 4;\n");
		  fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
		  break;
		default:
		  fprintf(stderr, "Warning: draw_unary_vec4 '2' (cast-to-bool):"
			  " unhandled sub-expression type %d; emitting 0\n",
			  ivl_expr_value(sub));
		  fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u; ; cast-to-bool fallback\n",
			  ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
		  break;
	    }
	    break;

	  default:
	    fprintf(stderr, "XXXX Unary operator %c not implemented\n", ivl_expr_opcode(expr));
	    break;
      }
}

static void draw_eval_vec4_core_(ivl_expr_t expr)
{
      static unsigned char warned_unexpected_vec4_type[32];
      static int warned_unexpected_vec4_type_oob = 0;

      if (number_trace_enabled_()) {
            fprintf(stderr,
                    "trace vec4: file=%s line=%u expr_type=%d expr_value=%d width=%u signed=%d\n",
                    ivl_expr_file(expr), ivl_expr_lineno(expr),
                    ivl_expr_type(expr), ivl_expr_value(expr),
                    ivl_expr_width(expr), ivl_expr_signed(expr));
      }

      if (debug_draw) {
	    fprintf(vvp_out, " ; %s:%u:draw_eval_vec4: expr_type=%d\n",
		    ivl_expr_file(expr), ivl_expr_lineno(expr),
		    ivl_expr_type(expr));
      }

      /* Handle object-like values in vec4 contexts as handle-bool casts:
         non-null handle -> 1, null handle -> 0. */
      if (ivl_expr_value(expr) == IVL_VT_CLASS ||
          ivl_expr_value(expr) == IVL_VT_QUEUE ||
          ivl_expr_value(expr) == IVL_VT_DARRAY ||
          ivl_expr_value(expr) == IVL_VT_NO_TYPE) {
            unsigned wid = ivl_expr_width(expr) ? ivl_expr_width(expr) : 1;
            draw_eval_object(expr);
            fprintf(vvp_out, "    %%test_nul/obj;\n");
            fprintf(vvp_out, "    %%pop/obj 1, 0;\n");
            fprintf(vvp_out, "    %%flag_inv 4;\n");
            fprintf(vvp_out, "    %%flag_get/vec4 4;\n");
            if (wid > 1)
                  fprintf(vvp_out, "    %%pad/u %u;\n", wid);
            return;
      }

      /* Explicit scalarization for non-vec4 scalar domains. */
      if (ivl_expr_value(expr) == IVL_VT_REAL) {
            unsigned wid = ivl_expr_width(expr) ? ivl_expr_width(expr) : 1;
            draw_eval_real(expr);
            fprintf(vvp_out, "    %%cvt/vr %u;\n", wid);
            return;
      }
      if (ivl_expr_type(expr) == IVL_EX_BINARY) {
            ivl_expr_t le = ivl_expr_oper1(expr);
            ivl_expr_t re = ivl_expr_oper2(expr);

            if (expr_is_string_like_(le) || expr_is_string_like_(re)) {
                  switch (ivl_expr_opcode(expr)) {
                      case 'e': /* == */
                      case 'E': /* === */
                      case 'n': /* != */
                      case 'N': /* !== */
                      case 'w': /* ==? */
                      case 'W': /* !=? */
                      case 'G': /* >= */
                      case 'L': /* <= */
                      case '>':
                      case '<':
                        draw_binary_vec4(expr);
                        return;
                      default:
                        break;
                  }
            }
      }
      if (ivl_expr_value(expr) == IVL_VT_STRING) {
              /* A string's compile-time width is nominal. Convert it at its
                 natural (runtime) width -- operand 0 -- and let the
                 consumer pad or select as its context requires. An explicit
                 cast node carries a real width instead. */
            unsigned wid = 0;
            switch (ivl_expr_type(expr)) {
                case IVL_EX_STRING:
                case IVL_EX_SIGNAL:
                case IVL_EX_CONCAT:
                case IVL_EX_PROPERTY:
                case IVL_EX_SELECT:
                case IVL_EX_SFUNC:
                case IVL_EX_UFUNC:
                case IVL_EX_TERNARY:
                  draw_eval_string(expr);
                  break;
                default:
                  /* Avoid draw_eval_string->fallback_eval recursion for
                     unsupported string expression node kinds. */
                  fprintf(vvp_out, "    %%pushi/str \"\";\n");
                  break;
            }
            fprintf(vvp_out, "    %%cast/vec4/str %u;\n", wid);
            return;
      }

      /* Numeric literals can arrive here before the core has assigned a
         stable vec4 expression value type. Handle them explicitly before
         the generic zero-fallback gate. */
      if (ivl_expr_type(expr) == IVL_EX_NUMBER) {
            draw_number_vec4(expr);
            return;
      }
      if (ivl_expr_type(expr) == IVL_EX_ULONG
          || ivl_expr_type(expr) == IVL_EX_DELAY) {
            uint64_t imm = (ivl_expr_type(expr) == IVL_EX_ULONG)
                         ? ivl_expr_uvalue(expr) : ivl_expr_delay_val(expr);
            unsigned wid = ivl_expr_width(expr);
            if (number_trace_enabled_()) {
                  fprintf(stderr,
                          "trace num: file=%s line=%u expr_type=%d expr_value=%d width=%u imm=%llu\n",
                          ivl_expr_file(expr), ivl_expr_lineno(expr),
                          ivl_expr_type(expr), ivl_expr_value(expr),
                          wid, (unsigned long long)imm);
            }
            if (wid == 0)
                  wid = (ivl_expr_type(expr) == IVL_EX_ULONG)
                      ? 8 * sizeof(unsigned long) : 64;
            fprintf(vvp_out, "    %%pushi/vec4 %lu, %lu, %u;\n",
                    (unsigned long)(imm & 0xffffffffUL),
                    (unsigned long)((imm >> 32) & 0xffffffffUL),
                    wid);
            return;
      }

      // Compile-progress fallback: Some UVM expressions may have unresolved
      // types from macro expansions. Emit a zero vec4.
      //
      // ...which is a silent wrong result: the compile SUCCEEDS and the
      // simulation reads zero where the expression's value belonged. It
      // was worse than it looks -- IVL_VT_NO_TYPE was excluded from the
      // warning entirely, so that case substituted a zero with no output
      // at all. It is an error now. Message suppression is kept (one per
      // value type, so a template instantiated a thousand times does not
      // print a thousand lines) but every occurrence counts, because the
      // compile must not produce an executable either way.
      if (ivl_expr_value(expr) != IVL_VT_BOOL &&
          ivl_expr_value(expr) != IVL_VT_VECTOR) {
	    int vt = ivl_expr_value(expr);
	    int should_warn = 1;
	    if (vt >= 0 && vt < (int)(sizeof warned_unexpected_vec4_type)) {
		  if (warned_unexpected_vec4_type[vt]) {
			should_warn = 0;
		  } else {
			warned_unexpected_vec4_type[vt] = 1;
		  }
	    } else if (warned_unexpected_vec4_type_oob) {
		  should_warn = 0;
	    } else {
		  warned_unexpected_vec4_type_oob = 1;
	    }

	    if (should_warn) {
		  fprintf(stderr, "%s:%u: error: a value of type %d cannot be "
			  "used in a vector context (further occurrences of "
			  "this type are not reported).\n",
			  ivl_expr_file(expr), ivl_expr_lineno(expr), vt);
		    }
		    vvp_errors += 1;
		    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u; ; zero fallback\n",
			    ivl_expr_width(expr));
		    return;
	      }

      switch (ivl_expr_type(expr)) {
	  case IVL_EX_BINARY:
	    draw_binary_vec4(expr);
	    return;

	  case IVL_EX_CONCAT:
	    draw_concat_vec4(expr);
	    return;

	  case IVL_EX_ARRAY_PATTERN: {
	    ivl_type_t type = ivl_expr_net_type(expr);
	    if (type && ivl_type_is_packed_vector(type)) {
		  unsigned idx;
		  unsigned count = ivl_expr_parms(expr);
		  if (count == 0)
			goto unsupported_vec4_expr;
		  draw_eval_vec4(ivl_expr_parm(expr, 0));
		  for (idx = 1; idx < count; idx += 1) {
			  draw_eval_vec4(ivl_expr_parm(expr, idx));
			  fprintf(vvp_out, "    %%concat/vec4; draw_array_pattern_vec4\n");
		  }
		  return;
	    }
	    goto unsupported_vec4_expr;
	  }

	  case IVL_EX_NUMBER:
	  case IVL_EX_SELECT:
	    if (ivl_expr_oper2(expr)==0)
		  draw_select_pad_vec4(expr);
	    else
		  draw_select_vec4(expr);
	    return;

	  case IVL_EX_SFUNC:
	    draw_sfunc_vec4(expr);
	    return;

	  case IVL_EX_SIGNAL:
	    draw_signal_vec4(expr);
	    return;

	  case IVL_EX_STRING:
	    draw_string_vec4(expr);
	    return;

	  case IVL_EX_TERNARY:
	    draw_ternary_vec4(expr);
	    return;

	  case IVL_EX_UFUNC:
	    draw_ufunc_vec4(expr);
	    return;

	  case IVL_EX_UNARY:
	    draw_unary_vec4(expr);
	    return;

	  case IVL_EX_PROPERTY:
	    draw_property_vec4(expr);
	    return;

	  case IVL_EX_NULL:
	    /* Null/unsupported nested property in vec4 context.
	     * Emit zero as a safe fallback (from nested property fallback). */
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u; ; null/nested-prop fallback\n",
	                    ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
	    return;

	  default:
	unsupported_vec4_expr:
	      /* No case for this expression kind. Substituting a zero
		 and letting the compile succeed is a silent wrong
		 result: the simulation runs and reads zero where the
		 expression's value belonged. IVL_EX_ARRAY_PATTERN used
		 to arrive here from `q <= '{...}' and did exactly that
		 (see PAssignNB::elaborate, which now lowers it). The
		 zero is still emitted so the rest of code generation
		 stays well-formed, but the error count makes the
		 compile fail. */
	    fprintf(stderr, "%s:%u: error: this expression (kind %d) cannot be "
		            "evaluated in a vector context.\n",
	                    ivl_expr_file(expr), ivl_expr_lineno(expr),
	                    ivl_expr_type(expr));
	    vvp_errors += 1;
	    fprintf(vvp_out, "    %%pushi/vec4 0, 0, %u; ; vec4 fallback\n",
	                    ivl_expr_width(expr) ? ivl_expr_width(expr) : 1);
	    return;
      }
}

void draw_eval_vec4(ivl_expr_t expr)
{
      draw_eval_vec4_core_(expr);
      event_expr_capture_vec4_result(expr);
}
