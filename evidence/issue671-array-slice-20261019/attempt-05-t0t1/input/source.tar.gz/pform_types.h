#ifndef IVL_pform_types_H
#define IVL_pform_types_H
/*
 * Copyright (c) 2007-2026 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

// This for the perm_string type.
# include  "StringHeap.h"
# include  "PNamedItem.h"
# include  "verinum.h"
# include  "named.h"
# include  "netstruct.h"
# include  "property_qual.h"
# include  "ivl_target.h"
# include  <iostream>
# include  <map>
# include  <vector>

class PExpr;
class PEEvent;
# include  <list>
# include  <vector>
# include  <map>
# include  <memory>

/*
 * parse-form types.
 */

class Design;
class NetScope;
class Definitions;
class PExpr;
class PEEvent;
class PClass;
class PScope;
class PPackage;
class PWire;
class Statement;
class netclass_t;
class netenum_t;
typedef named<PExpr*> named_pexpr_t;

/*
 * The pform_ident_t holds the identifier name and its lexical position
 * (the lexical_pos supplied by the scanner).
 */
typedef std::pair<perm_string, unsigned> pform_ident_t;

/*
 * The pform_range_t holds variable dimensions for type
 * declarations. The two expressions are interpreted as the first and
 * last values of the range. For example:
 *
 *   [<expr1> : <expr2>]  -- Normal array range
 *       first == <expr1>
 *       second = <expr2>
 *
 *   [<expr>] -- SystemVerilog canonical range
 *       first = PENumber(0)
 *       second = <expr> - 1;
 *
 *   [ ] -- Dynamic array
 *       first = 0
 *       second = 0
 *
 *   [ $ ] -- Queue type
 *       first = PENull
 *       second = 0
 */
typedef std::pair<PExpr*,PExpr*> pform_range_t;

/*
 * A named event declared with an unpacked-array bound (IEEE 1800-2017
 * 6.20, e.g. `event arr[3];`). array_dims is the declared range list,
 * or null for an ordinary scalar event. Multi-dimensional event arrays
 * are rejected at parse time, so array_dims never holds more than one
 * pform_range_t.
 */
struct pform_event_ident_t {
      pform_ident_t ident;
      std::list<pform_range_t>*array_dims;
};

/* The lgate is gate instantiation information. */
struct lgate : public LineInfo {
      explicit lgate() : parms(0), parms_by_name(0), ranges(0), decl_init(0) { }

      std::string name;
      std::list<PExpr*>*parms;
      std::list<named_pexpr_t>*parms_by_name;

      std::list<pform_range_t>*ranges;

	/* A declaration initializer (`type_t v = expr;`). The no-port
	   instantiation shape doubles as a user-type variable declaration
	   (resolved in pform_make_modgates); this carries the declarator's
	   `= expr` so such declarations can be initialized. A real module
	   instantiation can never have one. */
      PExpr*decl_init;
};

/*
 * The pform_port_t holds the name and optional unpacked dimensions
 * and initialization expression for a single port in a list of port
 * declarations.
 */
struct pform_port_t {
      pform_port_t(pform_ident_t n, std::list<pform_range_t>*ud, PExpr*e)
	: name(n), udims(ud), expr(e) { }
      ~pform_port_t() { }

      pform_ident_t name;
      std::list<pform_range_t>*udims;
      PExpr*expr;
};

/*
 * Semantic NOTES:
 * - The SEL_BIT is a single expression. This might me a bit select
 * of a vector, or a word select of an array.
 *
 * - The SEL_BIT_LAST index component is an array/queue [$] index,
 * that is the last item in the variable.
 */
struct index_component_t {
      enum ctype_t { SEL_NONE, SEL_BIT, SEL_BIT_LAST, SEL_PART, SEL_IDX_UP, SEL_IDX_DO,
		     SEL_PART_LAST, /* [lo:$] or [lo:$-offset] queue slice */
		     SEL_PART_LEFT_LAST /* [$:hi] queue slice */ };

      index_component_t() : sel(SEL_NONE), msb(0), lsb(0) { };
      ~index_component_t() { }

      ctype_t sel;
      class PExpr*msb;
      class PExpr*lsb;
};

/* IEEE 1800-2017 14.4: a clocking skew — an optional edge qualifier
   and/or a delay. one_step marks the #1step form. Built by the
   parser's clocking_skew rules; the delay PExpr ownership transfers
   to Module::PClocking. */
class PExpr;
class PEEvent;
struct pform_clocking_skew_t {
      char edge = 0;          // 0 (none), 'p'osedge, 'n'egedge, 'e'dge
      PExpr*delay = nullptr;
      bool one_step = false;
};

struct name_component_t {
      inline name_component_t() : local_scope(false) { }
      inline explicit name_component_t(perm_string n)
      : name(n), local_scope(false) { }
      ~name_component_t() { }

      // Return true if this component is nil.
      inline bool empty() const { return name.nil(); }

      perm_string name;
      std::list<index_component_t>index;

      // IEEE 1800-2017 18.7.1: local:: selects a name in the scope
      // containing randomize(), rather than a property of the object
      // being randomized. Preserve the qualifier through parsing so the
      // constraint IR can distinguish otherwise-identical names.
      bool local_scope;
};

struct decl_assignment_t {
      pform_ident_t name;
      std::list<pform_range_t>index;
      std::unique_ptr<PExpr> expr;
};

struct pform_tf_port_t {
      PWire*port;
      PExpr*defe;

      inline pform_tf_port_t() : port(0), defe(0) { }
      inline explicit pform_tf_port_t(PWire*p) : port(p), defe(0) { }
};

/*
 * This is the base class for data types that are matched by the
 * "data_type" rule in the parse rule. We make the type virtual so
 * that dynamic types will work.
 */
class data_type_t : public PNamedItem {
    public:
      inline explicit data_type_t() { }
      virtual ~data_type_t() override = 0;
      // This method is used by the pform dumper to diagnostic dump. The
      //  pform_dump dumps type type in pform format, and the debug_dump
      // prints the output in a linear form.
      virtual void pform_dump(std::ostream&out, unsigned indent) const;
      virtual std::ostream& debug_dump(std::ostream&out) const;

      ivl_type_t elaborate_type(Design*des, NetScope*scope);

      virtual SymbolType symbol_type() const override;

    private:
	// Elaborate the type to an ivl_type_s type.
      virtual ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const;
      virtual NetScope *find_scope(Design* des, NetScope *scope) const;

      bool elaborating = false;

	// Keep per-scope elaboration results cached.
      std::map<Definitions*,ivl_type_t> cache_type_elaborate_;
};

struct typedef_t : public PNamedItem {
      explicit typedef_t(perm_string n)
      : basic_type(ANY), unresolved_reported(false), name(n) { };
	// M11: the pform is process-lifetime and data_type_t objects
	// are freely shared (comma declarations, typedef aliases, base
	// types), so exit-time teardown must NOT delete through this
	// handle — double ownership was corrupting the heap during
	// Module destruction. Release instead (deliberate exit leak).
      ~typedef_t() override { data_type.release(); }

      ivl_type_t elaborate_type(Design*des, NetScope*scope);

      enum basic_type {
	    ANY,
	    ENUM,
	    STRUCT,
	    UNION,
	    CLASS
      };

      bool set_data_type(data_type_t *t);
      const data_type_t *get_data_type() const { return data_type.get(); }

      bool set_basic_type(basic_type bt);
      enum basic_type get_basic_type() const { return basic_type; }

      // A forward typedef that never receives its definition can be reached
      // from several elaboration paths (and from every specialization of a
      // containing class). The declaration owes one diagnostic, not one per
      // lookup. Return true exactly once so callers can retain compile-
      // progress recovery without multiplying the error count.
      bool report_unresolved_once()
	    { if (unresolved_reported) return false;
	      unresolved_reported = true; return true; }

protected:
      enum basic_type basic_type;
      bool unresolved_reported;
      std::unique_ptr<data_type_t> data_type;
public:
      perm_string name;
};

struct parmvalue_t;

struct typeref_t : public data_type_t {
      explicit typeref_t(typedef_t *t, PScope *s = 0, parmvalue_t*o = 0)
      : scope(s), type(t), overrides(o) {}
      ~typeref_t() override;

      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
      NetScope *find_scope(Design* des, NetScope *scope) const override;

      std::ostream& debug_dump(std::ostream&out) const override;

      inline typedef_t* typedef_ref() const { return type; }
      inline PScope* scope_ref() const { return scope; }
      inline const parmvalue_t* parameter_values() const { return overrides; }
      inline void set_parameter_values(parmvalue_t*o) { overrides = o; }

private:
      PScope *scope;
      typedef_t *type;
      parmvalue_t* overrides;
};

/* A typedef selected from a class scope whose left-hand class may itself be
   specialized, for example C#(byte)::word_t or pkg::C#(.T(int))::T.

   The ordinary typeref_t override list specializes its own typedef. Keep the
   class qualifier as a separate owned type node so its arguments elaborate
   the enclosing class, then elaborate the selected member typedef in that
   concrete class scope. Deriving from typeref_t preserves existing typedef
   alias and aggregate-shape handling for the selected member. */
struct class_scoped_typeref_t : public typeref_t {
      class_scoped_typeref_t(typedef_t*member, PScope*fallback_scope,
                             data_type_t*qualifier)
      : typeref_t(member, fallback_scope), qualifier_(qualifier) { }

      NetScope* find_scope(Design*des, NetScope*scope) const override;
      std::ostream& debug_dump(std::ostream&out) const override;

      const data_type_t* qualifier() const { return qualifier_.get(); }

private:
      std::unique_ptr<data_type_t> qualifier_;
};

/*
 * type_reference_t is the pform representation of the IEEE 1800-2017
 * 6.23 `type()` operator: `type(expression)` or `type(data_type)`. The
 * 2023 `type(this)` form (6.23, 8.11) uses its expression slot and resolves
 * directly to the enclosing class type without evaluating `this`.
 * Exactly one of "expr" or "named_type" is non-null.
 *
 *  - named_type set (the `type(data_type)` form, e.g. `type(int)`):
 *    elaborate_type_raw() simply resolves that named type -- `type(X)`
 *    names X directly.
 *
 *  - expr set (the `type(expression)` form, e.g. `type(a)`,
 *    `type(a+b)`): elaborate_type_raw() resolves the SELF-DETERMINED
 *    type of the expression WITHOUT evaluating it (6.23: "the
 *    expression shall not be evaluated"). For a plain identifier
 *    (including indexed/hierarchical/member references) this looks up
 *    the exact declared type via symbol search. For any other
 *    expression shape it falls back to the same evaluation-free
 *    test_width() self-determined-width/type inference that
 *    $bits()/$sizeof() already use for their type-name-or-expression
 *    argument, so a side-effecting function call in e.g. `type(f(x))`
 *    is never invoked.
 *
 * This node is carried into expression contexts (so `type(a)==type(b)` and
 * `case (type(a))` can parse and elaborate) by wrapping it in a PETypename --
 * see the `K_type '(' expression ')'` alternative of expr_primary in parse.y
 * and the type_reference_t checks added to PETypename/PEBComp/PCase
 * elaboration.
 */
struct type_reference_t : public data_type_t {
      explicit type_reference_t(PExpr*e) : expr(e), named_type(0) { }
      explicit type_reference_t(data_type_t*t) : expr(0), named_type(t) { }

      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
      std::ostream& debug_dump(std::ostream&out) const override;

      PExpr*expr;
      data_type_t*named_type;
};

enum class type_parameter_restriction_t {
      NONE,
      ENUM,
      STRUCT,
      UNION,
      CLASS,
      INTERFACE_CLASS
};

struct type_parameter_t : data_type_t {
      explicit type_parameter_t(perm_string n,
			        type_parameter_restriction_t r =
					    type_parameter_restriction_t::NONE)
      : unresolved_interface_reported(false), name(n), restriction(r) { }
      ivl_type_t elaborate_type_raw(Design *des, NetScope *scope) const override;

      mutable bool unresolved_interface_reported;
      perm_string name;
      type_parameter_restriction_t restriction;
};

struct void_type_t : public data_type_t {
      virtual void pform_dump(std::ostream&out, unsigned indent) const override;

	// R20: a `void` member of a `union tagged` (IEEE 1800-2017
	// 7.3.2) elaborates to a zero-payload marker type so the
	// existing struct/union machinery in struct_type_t can carry
	// it as a tag-only member. Used only as a struct_union_member
	// type; `void` used as a function return type never reaches
	// this (functions use data_type_or_implicit_or_void instead).
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
};

/*
 * The enum_type_t holds the parsed declaration to represent an
 * enumeration. Since this is in the pform, it represents the type
 * before elaboration so the range, for example, may not be complete
 * until it is elaborated in a scope.
 */
struct enum_type_t : public data_type_t {
      explicit enum_type_t(data_type_t *btype) : base_type(btype) { }

	// Return the elaborated version of the type.
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      SymbolType symbol_type() const override;

      std::unique_ptr<data_type_t> base_type;
      std::unique_ptr< std::list<named_pexpr_t> > names;
};

struct struct_member_t : public LineInfo {
      property_qualifier_t qualifier = property_qualifier_t::make_none();
      std::unique_ptr<data_type_t> type;
      std::unique_ptr< std::list<decl_assignment_t*> > names;
      void pform_dump(std::ostream&out, unsigned indent) const;
};

struct struct_type_t : public data_type_t {
      virtual void pform_dump(std::ostream&out, unsigned indent) const override;
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      bool packed_flag;
      bool union_flag;
      bool signed_flag;
      bool soft_flag = false;
      // Phase 63b/B7: marks a `union tagged` (vs plain union).  Tag
      // semantics are not yet enforced — this flag exists so the
      // declaration site can emit a one-time warning and so future
      // enforcement passes have a stable place to look.
      bool tagged_flag = false;
      std::unique_ptr< std::list<struct_member_t*> > members;
};

struct atom_type_t : public data_type_t {
      enum type_code {
	    INTEGER,
	    TIME,
	    BYTE,
	    SHORTINT,
	    INT,
	    LONGINT,
	      // `chandle` is storage-compatible with a 64-bit 2-state atom
	      // (it lowered straight to LONGINT before this), but $typename
	      // (IEEE 1800-2017 20.6.1) must print "chandle", not "longint",
	      // so it gets its own type_code/singleton ivl_type_t.
	    CHANDLE
      };

      explicit atom_type_t(enum type_code tc, bool flag) : type_code(tc),
							   signed_flag(flag) { }

      enum type_code type_code;
      bool signed_flag;

      virtual std::ostream& debug_dump(std::ostream&out) const override;

      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
};

extern atom_type_t size_type;

/*
 * The vector_type_t class represents types in the old Verilog
 * way. Some typical examples:
 *
 *   logic signed [7:0] foo
 *   bit unsigned foo
 *   reg foo
 *
 * There is one special case:
 *
 * If there are no reg/logic/bit/bool keywords, then Verilog will
 * assume the type is logic, but the context may need to know about
 * this case, so the implicit_flag member is set to true in that case.
 */
struct vector_type_t : public data_type_t {
      inline explicit vector_type_t(ivl_variable_type_t bt, bool sf,
				    std::list<pform_range_t>*pd)
      : base_type(bt), signed_flag(sf), integer_flag(false), implicit_flag(false), pdims(pd) { }
      virtual void pform_dump(std::ostream&out, unsigned indent) const override;
      virtual std::ostream& debug_dump(std::ostream&out) const override;
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      ivl_variable_type_t base_type;
      bool signed_flag;
      bool integer_flag; // True if "integer" was used
      bool implicit_flag; // True if this type is implicitly logic/reg
      std::unique_ptr< std::list<pform_range_t> > pdims;
};

struct array_base_t : public data_type_t {
    public:
      inline explicit array_base_t(data_type_t*btype, std::list<pform_range_t>*pd)
      : base_type(btype), dims(pd) { }

      std::unique_ptr<data_type_t> base_type;
      std::unique_ptr< std::list<pform_range_t> > dims;
};

/*
 * The parray_type_t is a generalization of the vector_type_t in that
 * the base type is another general data type. Ultimately, the subtype
 * must also be packed (as this is a packed array) but that may be
 * worked out during elaboration.
 */
struct parray_type_t : public array_base_t {
      inline explicit parray_type_t(data_type_t*btype, std::list<pform_range_t>*pd)
      : array_base_t(btype, pd) { }

      virtual void pform_dump(std::ostream&out, unsigned indent) const override;
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
};

/*
 * The uarray_type_t represents unpacked array types.
 */
struct uarray_type_t : public array_base_t {
      inline explicit uarray_type_t(data_type_t*btype, std::list<pform_range_t>*pd)
      : array_base_t(btype, pd) { }

    public:
      virtual void pform_dump(std::ostream&out, unsigned indent) const override;
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
};

struct real_type_t : public data_type_t {
 public:
      enum type_t { REAL, SHORTREAL };
      inline explicit real_type_t(type_t tc) : type_code_(tc) { }
      virtual std::ostream& debug_dump(std::ostream&out) const override;

      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      inline type_t type_code() const { return type_code_; }

 private:
      type_t type_code_;
};

struct string_type_t : public data_type_t {
      inline explicit string_type_t() { }
      ~string_type_t() override;

      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;
};

struct interface_type_t : public data_type_t {
      inline explicit interface_type_t(perm_string n, bool is_virtual = false)
      : name(n), virtual_type(is_virtual) { }
      ~interface_type_t() override;

      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      inline const parmvalue_t* parameter_values() const
            { return parameter_values_; }
      inline void set_parameter_values(parmvalue_t*values)
            { parameter_values_ = values; }

      perm_string name;
      // interface_type_t also represents ordinary interface ports. Preserve
      // whether the source type was introduced by the `virtual` data_type
      // production so IEEE 1800-2017/2023 25.9 context restrictions do not
      // accidentally reject real interface ports.
      bool virtual_type = false;
      // IEEE 1800-2017/2023 25.9 makes the complete effective parameter list
      // part of a virtual-interface type. Retain the source actuals until
      // elaboration so ordered/named/default spellings can be evaluated in
      // the declaration's lexical scope and interned by semantic identity.
      // This node owns the parse expressions, exactly like typeref_t.
      parmvalue_t* parameter_values_ = nullptr;
      // IEEE 1800-2017 6.20.3 permits a type-parameter default to carry a
      // virtual-interface type that is never selected/used. Keep that narrow
      // declaration context lazy; every ordinary virtual-interface use still
      // requires a real interface declaration.
      bool allow_unresolved = false;
      // Parse-form types are process-lifetime objects and their elaborated
      // results are cached per scope. Reuse one opaque unresolved handle
      // across those scope caches so an unused default does not allocate one
      // placeholder for every class specialization.
      mutable netclass_t* unresolved_type = nullptr;
      // Phase 63a/A1: optional modport name from `if.modport` port header.
      // When set, restricts which interface members are accessible
      // through this port reference.  Currently captured but not yet
      // enforced — modport direction-checking is a follow-up.
      perm_string modport;
};

/* Return the modport carried by a virtual-interface parse type. Arrays and
   typedefs preserve the qualifier of their underlying interface type. */
perm_string pform_interface_modport(const data_type_t*type);

/* True when the parse-form type is, or aliases/arrays, a source-level
   `virtual interface` type. This is deliberately distinct from an ordinary
   interface port type, although both elaborate to an interface netclass. */
bool pform_is_virtual_interface_type(const data_type_t*type);

/* Resolve the same provenance through a concrete type parameter actual. */
bool pform_is_virtual_interface_type(Design*des, NetScope*scope,
				     const data_type_t*type);

/* Resolve the same qualifier in an elaborated scope. This additionally
   follows concrete type-parameter actuals, retaining the lexical scope in
   which each actual was supplied. */
perm_string pform_interface_modport(Design*des, NetScope*scope,
				    const data_type_t*type);

struct class_type_t : public data_type_t {

      enum constraint_override_specifier_t {
	    CONSTRAINT_OVERRIDE_INITIAL = 1,
	    CONSTRAINT_OVERRIDE_EXTENDS = 2,
	    CONSTRAINT_OVERRIDE_FINAL = 4
      };

      inline explicit class_type_t(perm_string n) : name(n) { virtual_class = false; final_class = false; interface_class = false; is_covergroup_stub = false; is_covergroup_standalone = false; base_default = false; }

      void pform_dump(std::ostream&out, unsigned indent) const override;
      void pform_dump_init(std::ostream&out, unsigned indent) const;

	// This is the named type that is supposed to be the base
	// class that we are extending. This is nil if there is no
	// hierarchy. If there are arguments to the base class, then
	// put them in the base_args vector.
      std::unique_ptr<data_type_t> base_type;
      std::vector<named_pexpr_t> base_args;
      bool base_default;

	// IEEE 1800-2017 8.26: interface classes form a separate,
	// potentially multiple-inheritance graph. A concrete class may have
	// one ordinary base_type and implement any number of these types; an
	// interface class may extend any number of them and has no ordinary
	// base class. Keep the two graphs distinct so interface inheritance
	// never changes object layout or superclass property numbering.
      std::vector<std::unique_ptr<data_type_t> > interface_types;

      bool virtual_class;
      bool final_class;
      bool interface_class;
      bool is_covergroup_stub; // true when created as a package-level CG stub
	// M11-1/2: standalone (module/package-scope) covergroup type —
	// the elaborated netclass IS the covergroup class itself (bins
	// as its own properties), instantiable with plain `new`.
      bool is_covergroup_standalone;

	// This is a map of the properties. Map the name to the type.
      struct prop_info_t : public LineInfo {
	    inline prop_info_t()
	    : qual(property_qualifier_t::make_none()), has_decl_initializer(false) { }
	    inline prop_info_t(property_qualifier_t q, data_type_t*t,
			       bool has_initializer = false)
	    : qual(q), type(t), has_decl_initializer(has_initializer) { }
	    prop_info_t(prop_info_t&&) = default;
	    prop_info_t& operator=(prop_info_t&&) = default;
	      // M11: one data_type_t is shared by every declarator of
	      // a comma property list (`int a, b;`) and may also be
	      // owned by a typedef — exit-time deletion through this
	      // handle double-freed. Release instead (deliberate exit
	      // leak; the pform lives for the whole process anyway).
	    ~prop_info_t() { type.release(); }
	    property_qualifier_t qual;
	    std::unique_ptr<data_type_t> type;
	      // IEEE 1800-2017 8.19 distinguishes a global constant from an
	      // instance constant by the presence of a declaration initializer,
	      // not by the static qualifier. Keep that syntactic provenance after
	      // the initializer is lowered into the synthetic constructor.
	    bool has_decl_initializer;
      };
      std::map<perm_string, struct prop_info_t> properties;
      std::vector<perm_string> property_order;

	// This is an ordered list of property initializers. The name
	// is the name of the property to be assigned, and the val is
	// the expression that is assigned.
      std::vector<Statement*> initialize;

	// This is an ordered list of property initializers for static
	// properties. These are run in a synthetic "initial" block
	// without waiting for any constructor.
      std::vector<Statement*> initialize_static;

      // Named constraint blocks: map from constraint name to list of
      // constraint expressions (PEInside, comparisons, etc.).
      std::map<perm_string, std::vector<PExpr*>> constraints;
      // IEEE 1800-2017 18.5.14.1 / 1800-2023 18.5.13.1: declaration
      // order (the prototype for external blocks) determines soft priority.
      std::vector<perm_string> constraint_order;

	// Source and qualifier metadata for each concrete constraint block.
	// The solver IR does not distinguish static constraints, but declaration
	// matching (extern and inherited pure prototypes) must retain the exact
	// qualifier and diagnostic location.
      struct constraint_decl_info_t : public LineInfo {
	    bool is_static = false;
	    bool is_prototype = false;
	    unsigned override_specifiers = 0;
      };
      std::map<perm_string, constraint_decl_info_t> constraint_declarations;

	// IEEE 1800-2017 18.5.2 pure constraint prototypes. A concrete
	// descendant must replace every inherited entry with a constraint
	// declaration of the same name before it can be instantiated.
      struct pure_constraint_info_t : public LineInfo {
	    unsigned override_specifiers = 0;
      };
      std::map<perm_string, pure_constraint_info_t> pure_constraints;

	// IEEE 1800-2017 18.5.1 explicit external constraint prototypes.
	// A matching out-of-body definition removes the entry. Keep source
	// provenance so a missing definition is diagnosed once during class
	// elaboration, including when the class has multiple specializations.
      struct extern_constraint_info_t : public LineInfo {
	    bool is_static = false;
	    unsigned override_specifiers = 0;
	    bool reported = false;
      };
      std::map<perm_string, extern_constraint_info_t> extern_constraints;

	// Coverage group definitions (class-embedded covergroups).
      struct pform_cov_trans_term_t {
	    enum repeat_kind_t {
		  TRANS_ONCE,
		  TRANS_CONSECUTIVE,
		  TRANS_GOTO,
		  TRANS_NONCONSECUTIVE
	    };
	      // One trans_item is a set of values/ranges. Repetition applies to
	      // that complete set, so keep the alternatives together instead of
	      // prematurely expanding them into one fixed value per repetition.
	    std::vector<std::pair<PExpr*, PExpr*>> ranges;
	    repeat_kind_t repeat_kind = TRANS_ONCE;
	    PExpr* repeat_lo = nullptr;
	    PExpr* repeat_hi = nullptr;
      };

      struct pform_cov_bins_t {
	    enum kind_t { BIN_NORMAL, BIN_IGNORE, BIN_ILLEGAL,
			  BIN_DEFAULT };
	    perm_string name;
	    std::vector<std::pair<PExpr*, PExpr*>> ranges; // [lo, hi] pairs
	    kind_t kind = BIN_NORMAL;
	    const PClass* decl_class = nullptr;
	      // M11: wildcard bins — range values with x/z/? bits match
	      // by mask; composes with any kind.
	    bool wildcard = false;
	      // M11: arrayed bins (bins b[] / bins b[N]) — one bin per
	      // value (or N distributed bins) instead of one bin for
	      // the whole set.
	    bool arrayed = false;
	    PExpr* array_size = nullptr;
	      // M11: "with (expr)" filter — keep only values where the
	      // expression (over 'item') evaluates true.
	    PExpr* with_expr = nullptr;
	      // A bin iff is sampled dynamically and is distinct from the
	      // construction-time with-covergroup expression above.
	    PExpr* iff_expr = nullptr;
	    bool declared_by_extension = false;
	      // IEEE 1800-2017 19.5.1.1 set-covergroup expression.  The
	      // expression yields an unpacked array/queue whose elements form
	      // the value set for this declaration.
	    PExpr* set_expr = nullptr;
	      // IEEE 1800-2017 19.5.1.2 coverpoint-derived bin set:
	      //   bins b = source_cp with (item_predicate);
	    perm_string source_coverpoint;
	      // `default' composes with bins/ignore_bins/illegal_bins.  Keep it
	      // orthogonal to kind so illegal_bins x = default is not silently
	      // downgraded or dropped.
	    bool is_default = false;
	      // M11-2: transition sequences — each sequence is an
	      // ordered list of [lo:hi] steps; a bin may carry several
	      // (comma-separated) sequences.
	    std::vector<std::vector<pform_cov_trans_term_t>> trans_seqs;
      };
      struct pform_coverpoint_t {
	    perm_string label;  // coverpoint label (or same as expr name)
	    const PClass* decl_class = nullptr;
	    bool inherited_cross_only = false;
	    bool declared_by_extension = false;
	    PExpr* expr;        // expression being covered (e.g., val)
	    PExpr* iff_expr = nullptr; // M11: iff (guard) — sample gate
	    std::vector<pform_cov_bins_t> bins;
	      // M11: coverpoint options (option.name = const_expr)
	    std::map<perm_string, PExpr*> options;
      };
      // I1 (Phase 62g): captured cross declaration.  A cross combines
      // existing coverpoint labels into bins that count when ALL
      // contributing coverpoint bins are hit on the same sample.
      struct pform_cross_t {
	    struct matches_t {
		  PExpr* expr = nullptr;
		  bool all = false;
	    };
	    struct item_t {
		  perm_string label;
		  PExpr* expr = nullptr;
	    };
	      // M11-3: named cross bin with a binsof select expression.
	      // The select tree is a boolean combination of
	      // binsof(cp[.bin]) [intersect {ranges}] leaves.
	    struct select_t {
		  enum op_t { SEL_BINSOF, SEL_AND, SEL_OR, SEL_NOT, SEL_WITH } op;
		  perm_string cp_name;   // SEL_BINSOF: coverpoint label
		  perm_string bin_name;  // SEL_BINSOF: bin label (may be nil)
		  std::vector<std::pair<PExpr*, PExpr*>> intersect_ranges;
		  // SEL_WITH: predicate applied to child a's selected tuples.
		  PExpr* with_expr = nullptr;
		  PExpr* matches_expr = nullptr;
		  bool matches_all = false;
		  select_t* a = nullptr;
		  select_t* b = nullptr;
	    };
	    struct cross_bin_t {
		  enum kind_t { BIN_NORMAL, BIN_IGNORE, BIN_ILLEGAL };
		  perm_string name;
		  kind_t kind = BIN_NORMAL;
		  select_t* select = nullptr;
		  PExpr* set_expr = nullptr;
		  perm_string with_cross;
		  PExpr* with_expr = nullptr;
		  PExpr* matches_expr = nullptr;
		  bool matches_all = false;
	    };
	    perm_string label;                 // cross label (or auto)
	    const PClass* decl_class = nullptr;
	    std::vector<perm_string> cp_labels; // names of contributing coverpoints
	    std::vector<PExpr*> cp_exprs;       // implicit variable expressions
	    struct_type_t* value_type = nullptr; // implicit CrossValType, when needed
	    PExpr* iff_expr = nullptr;         // IEEE 19.6: cross iff sample gate
	    bool declared_by_extension = false;
	    std::vector<cross_bin_t> bins;      // M11-3: named cross bins
	      // M11: cross-level options (option.name = const_expr)
	    std::map<perm_string, PExpr*> options;
      };
      struct pform_covergroup_t {
	    perm_string name;   // covergroup instance name (e.g., "cg")
	    bool is_extension = false;
	      // Per-instance constructor formals (19.3), distinct from
	      // `with function sample` formals.
	    std::vector<perm_string> ctor_formals;
	    std::vector<data_type_t*> ctor_formal_types;
	    std::vector<bool> ctor_formal_is_ref;
	    std::vector<PExpr*> ctor_defaults;
	      // M11-2: the declaration's sampling event
	      // (`covergroup cg @(posedge clk);`) — instances get a
	      // synthesized `always @(ev) inst.sample();` process.
	    std::vector<PEEvent*> sample_events;
	      // M11-4: `with function sample(<formals>)` — coverpoint
	      // sources naming a formal bind to the matching sample()
	      // call argument at each call site. The parallel types
	      // vector (entries may be null) gives each formal's
	      // declared type, used to size automatic bins (M11-5).
	    std::vector<perm_string> sample_formals;
	    std::vector<PWire*> sample_formal_types;
	    std::vector<PExpr*> sample_formal_defaults;
	    std::vector<pform_coverpoint_t> coverpoints;
	    std::vector<pform_cross_t> crosses;  // I1: cross declarations
	      // M11: covergroup options (option.name = const_expr)
	    std::map<perm_string, PExpr*> options;
      };
      std::vector<pform_covergroup_t*> covergroups;

      ivl_type_t elaborate_type_raw(Design*, NetScope*) const override;

      perm_string name;

      virtual SymbolType symbol_type() const override;
};

ivl_type_t elaborate_array_type(Design *des, NetScope *scope,
			        const LineInfo &li, ivl_type_t base_type,
			        const std::list<pform_range_t> &dims);

/*
 * The pform_name_t is the general form for a hierarchical
 * identifier. It is an ordered list of name components. Each name
 * component is an identifier and an optional list of bit/part
 * selects. The simplest name component is a simple identifier:
 *
 *    foo
 *
 * The bit/part selects come from the source and are made part of the
 * name component. A bit select is a single number that may be a bit
 * select of a vector or a word select of an array:
 *
 *    foo[5]     -- a bit select/word index
 *    foo[6:4]   -- a part select
 *
 * The index components of a name component are collected into an
 * ordered list, so there may be many, for example:
 *
 *    foo[5][6:4] -- a part select of an array word
 *
 * The pform_name_t, then, is an ordered list of these name
 * components. The list of names comes from a hierarchical name in the
 * source, like this:
 *
 *    foo[5].bar[6:4]  -- a part select of a vector in sub-scope foo[5].
 */
typedef std::list<name_component_t> pform_name_t;

struct pform_scoped_name_t {
      pform_scoped_name_t() = default;
      pform_scoped_name_t(PPackage *p, const pform_name_t &n) : package(p),
							        name(n) {}
      explicit pform_scoped_name_t(const pform_name_t &n) : name(n) {}

      const name_component_t& back() const { return name.back(); }
      size_t size() const { return name.size(); }

      PPackage *package = nullptr;
      pform_name_t name;
};

/* A user-defined nettype is a declaration-scope symbol, independent of the
 * built-in NetNet::Type used for ordinary wire resolution. A declaration
 * either owns a direct data type or aliases an earlier nettype declaration.
 * The optional resolution function remains symbolic until elaboration. */
class nettype_t : public PNamedItem {
    public:
      nettype_t(perm_string name, data_type_t*type,
                const pform_scoped_name_t*resolution_function = nullptr);
      nettype_t(perm_string name, nettype_t*alias);
      ~nettype_t() override;

      SymbolType symbol_type() const override;

      perm_string name() const { return name_; }
      data_type_t* direct_type() { return direct_type_.get(); }
      const data_type_t* direct_type() const { return direct_type_.get(); }
      nettype_t* alias_type() const { return alias_type_; }

      /* Returns null if an invalid alias cycle is encountered. */
      nettype_t* canonical_type();
      const nettype_t* canonical_type() const;

      bool has_resolution_function() const
        { return resolution_function_.get() != nullptr; }
      const pform_scoped_name_t* resolution_function() const
        { return resolution_function_.get(); }

    private:
      perm_string name_;
      std::unique_ptr<data_type_t> direct_type_;
      nettype_t*alias_type_;
      std::unique_ptr<pform_scoped_name_t> resolution_function_;
};

/* IEEE 1800-2017 12.6 pattern-variable bindings are declared implicitly,
 * but their type is determined by the corresponding leaf of the matched
 * value.  Keep the route to that leaf symbolic until type elaboration: a
 * tagged-union member is named, while an ordered structure pattern selects a
 * member by declaration position. */
struct pform_pattern_path_component_t {
      enum kind_t { NAMED_MEMBER, POSITIONAL_MEMBER };

      explicit pform_pattern_path_component_t(perm_string n)
      : kind(NAMED_MEMBER), name(n), position(0) { }
      explicit pform_pattern_path_component_t(unsigned p)
      : kind(POSITIONAL_MEMBER), position(p) { }

      kind_t kind;
      perm_string name;
      unsigned position;
};

typedef std::vector<pform_pattern_path_component_t> pform_pattern_path_t;

class pattern_binding_type_t : public data_type_t {
    public:
      pattern_binding_type_t(const pform_scoped_name_t&subject,
                             unsigned lexical_pos,
                             const pform_pattern_path_t&path)
      : subject_(subject), lexical_pos_(lexical_pos), path_(path) { }

      std::ostream& debug_dump(std::ostream&out) const override;

    private:
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      pform_scoped_name_t subject_;
      unsigned lexical_pos_;
      pform_pattern_path_t path_;
};

inline perm_string peek_head_name(const pform_name_t&that)
{
      return that.front().name;
}

inline perm_string peek_tail_name(const pform_name_t&that)
{
      return that.back().name;
}

inline perm_string peek_head_name(const pform_scoped_name_t &that)
{
      return peek_head_name(that.name);
}

inline perm_string peek_tail_name(const pform_scoped_name_t &that)
{
      return peek_tail_name(that.name);
}

struct foreach_index_type_t : public data_type_t {
      explicit foreach_index_type_t(const pform_name_t&path,
				    size_t idx_depth,
				    unsigned lex_pos)
      : target_path(path), index_depth(idx_depth), lexical_pos(lex_pos) { }

      virtual std::ostream& debug_dump(std::ostream&out) const override;
      ivl_type_t elaborate_type_raw(Design*des, NetScope*scope) const override;

      pform_name_t target_path;
      size_t index_depth;
      unsigned lexical_pos;
};

/*
 * In pform names, the "super" and "this" keywords are converted to
 * These tokens so that they don't interfere with the namespace and
 * are handled specially.
 */
# define SUPER_TOKEN "#"
# define THIS_TOKEN  "@"

static inline std::ostream& operator<< (std::ostream&out, const data_type_t&that)
{
      return that.debug_dump(out);
}

extern std::ostream& operator<< (std::ostream&out, const pform_name_t&);
extern std::ostream& operator<< (std::ostream&out, const pform_scoped_name_t&);
extern std::ostream& operator<< (std::ostream&out, const name_component_t&that);
extern std::ostream& operator<< (std::ostream&out, const index_component_t&that);
extern std::ostream& operator<< (std::ostream&out, enum typedef_t::basic_type bt);

#endif /* IVL_pform_types_H */
