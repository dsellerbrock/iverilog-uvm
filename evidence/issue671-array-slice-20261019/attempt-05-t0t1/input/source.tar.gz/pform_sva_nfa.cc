/*
 * M9-NFA (Phase 2, stage A): automaton-based SVA engine — the
 * construction half. Design: docs/conformance/m9_nfa_design_2026-07-19.md
 *
 * This file builds and analyzes sequence NFAs from the legacy chain
 * IR. The stage-A synthesizer that lowers an automaton to a checker
 * process lives in pform.cc (pform_sva_nfa_try_assertion), where the
 * shared sva_* statement builders are.
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 */

# include  "config.h"
# include  "parse_misc.h"
# include  "pform.h"
# include  "pform_sva_nfa.h"
# include  "PExpr.h"
# include  <cstdlib>
# include  <cstring>
# include  <iostream>
# include  <vector>

using namespace std;

bool pform_sva_nfa_enabled()
{
      static int flag = -1;
      if (flag < 0) {
	      // M9-NFA flip (Phase 2 close): the automaton engine is now the
	      // DEFAULT SVA engine. It was validated at parity with (and a
	      // strict superset of) the legacy linear engine across the
	      // dual-run suite, the vendored ivtest sweep, the bundled VPI
	      // suite, and the UVM regression. The legacy engine stays
	      // available for one release as an escape hatch: set
	      // IVL_SVA_LEGACY=1 (or the historical IVL_SVA_NFA=0) to use it.
	    const char*legacy = getenv("IVL_SVA_LEGACY");
	    const char*nfa = getenv("IVL_SVA_NFA");
	      // Precedence: an explicit IVL_SVA_NFA=1 forces the automaton
	      // engine on (so a diagnostic pointing at it always works, even
	      // alongside IVL_SVA_LEGACY); IVL_SVA_LEGACY=1 (or IVL_SVA_NFA=0)
	      // forces the legacy engine; otherwise the automaton engine is
	      // the default.
	    if (nfa && *nfa && strcmp(nfa, "0") != 0)
		  flag = 1;                  // explicit automaton opt-in (wins)
	    else if (legacy && *legacy && strcmp(legacy, "0") != 0)
		  flag = 0;                  // explicit legacy opt-out
	    else if (nfa && strcmp(nfa, "0") == 0)
		  flag = 0;                  // historical IVL_SVA_NFA=0 opt-out
	    else
		  flag = 1;                  // default: automaton engine
      }
      return flag != 0;
}

bool pform_sva_nfa_dump_enabled()
{
      static int flag = -1;
      if (flag < 0) {
	    const char*env = getenv("IVL_SVA_NFA_DUMP");
	    flag = (env && *env && strcmp(env, "0") != 0) ? 1 : 0;
      }
      return flag != 0;
}

/*
 * ##0 fusion primitive: the incoming tick edges of `cur' (every tick
 * edge arriving anywhere in cur's backward epsilon closure) are
 * duplicated with `guard' added to the conjunction, targeting a fresh
 * join state, which is returned. The original arrival states keep
 * their edges (delayed-arrival branches still need them); if nothing
 * else uses them they die in accept-reachability pruning. Returns ~0u
 * when cur has no incoming tick edges to fuse onto.
 */
static unsigned nfa_fuse_arrival_(sva_nfa_t&nfa, unsigned cur, PExpr*guard,
                                  bool fm_exit = false)
{
      std::vector<bool> incl (nfa.nstates, false);
      incl[cur] = true;
      bool chg = true;
      while (chg) {
	    chg = false;
	    for (size_t i = 0; i < nfa.edges.size(); i += 1) {
		  const sva_nfa_edge_t&e = nfa.edges[i];
		  if (e.epsilon && incl[e.to] && !incl[e.from]) {
			incl[e.from] = true;
			chg = true;
		  }
	    }
      }
      unsigned join = nfa.new_state();
      size_t nedges = nfa.edges.size();
      bool any = false;
      for (size_t i = 0; i < nedges; i += 1) {
	    sva_nfa_edge_t e = nfa.edges[i];
	    if (e.epsilon || !incl[e.to]) continue;
	    e.to = join;
	    e.guards.push_back(guard);
	    if (fm_exit) {
		  e.first_match_exit = true;
		  e.first_match_guards = e.guards;
	    }
	    nfa.edges.push_back(e);
	    any = true;
      }
      if (!any) return ~0u;
      return join;
}

/*
 * Build the automaton fragment for one legacy chain step:
 *   ##[m:n] expr  followed by  expr[*1:1+rep_tail]  tail repetition.
 * m == -1 encodes ##[m0:$] (unbounded upper: loop on a true tick);
 * m == -2 / -3 are legacy sorry markers — construction fails and the
 * caller falls back. Returns the fragment's exit state or ~0u.
 */
static unsigned nfa_add_step_(sva_nfa_t&nfa, unsigned cur,
			      const sva_seq_step_t&st, bool first,
                              bool fm_exit = false)
{
      long lo = st.delay_lo;
      long hi = st.delay_hi;

      /* Parameter-valued consecutive repetition is intentionally lowered
	 outside the parse-time NFA: its state width must be resolved after
	 instance parameter overrides, not from a declaration default. */
      if (st.rep_kind == 4) return ~0u;
      if (lo < 0 || hi == -2 || hi == -3)
	    return ~0u;

	// Legacy encoding of ##[m:$]: delay_lo = m, delay_hi = -1.
	// (The parse_misc.h header comment describing the opposite is
	// stale; the parser rules at K_CYCLE_DELAY '[' e ':' '$' ']'
	// are the authority.)
      bool unbounded = (hi == -1);

	/* The parse-form SVA IR is currently constructed before module
	   parameter overrides are applied.  In particular, a checker whose
	   default bound is `2**32' can be instantiated with a small override,
	   but the early constant folder still sees the default.  Never let that
	   staging limitation turn into an unbounded compiler allocation while
	   building an NFA.  The synthesizer below already refuses automata whose
	   state/attempt product exceeds 1024, so no shape that it could formerly
	   commit is lost by declining an individual linear expansion beyond this
	   bound.  Parameter-valued repetitions need the symbolic/elaboration-time
	   lowering rather than allocating their default-sized automaton here. */
      static const long construction_limit = 1024;
      if (lo > construction_limit
	  || (!unbounded && hi > construction_limit)
	  || st.rep_tail > construction_limit
	  || (st.rep_kind != 0 && st.rep_hi > construction_limit))
	    return ~0u;

	// First step with no explicit delay consumes the anchor tick
	// itself: model as delay 0 -> the expr guards the very first
	// tick edge out of the anchor state. Encode delay d as d
	// unguarded ticks for d>=1 with the expression on the LAST
	// tick; delay 0 fuses the expression onto the incoming tick
	// (anchor consumption or same-tick ##0 continuation).
      long fixed = lo;
      if (fixed < 0) fixed = 0;

	// C5-2 (CL1-001): a goto/nonconsecutive repetition fed by a
	// WINDOWED arrival ##[m:n] is the union over the fixed arrivals
	// d in [m,n] -- distinct arrival splits yield distinct match
	// endpoints (with `##[1:2] b[->1]' and b true on two consecutive
	// ticks, BOTH ticks end a match), so this is a genuine branch,
	// not a collapsed wait. One exact-delay fragment per arrival,
	// exits epsilon-joined.
      if (st.rep_kind != 0 && !unbounded && hi != lo) {
	    unsigned exit = nfa.new_state();
	    for (long d = lo; d <= hi; d += 1) {
		  sva_seq_step_t one = st;
		  one.delay_lo = d;
		  one.delay_hi = d;
		  unsigned sub = nfa_add_step_(nfa, cur, one, first, fm_exit);
		  if (sub == ~0u) return ~0u;
		  nfa.eps(sub, exit);
	    }
	    return exit;
      }
	// C5-2: `##[0:$] rep' mid-chain splits into the ##0-fused
	// arrival plus an ordinary unbounded ##[1:$] arrival.
      if (st.rep_kind != 0 && unbounded && fixed == 0 && !first) {
	    unsigned exit = nfa.new_state();
	    sva_seq_step_t z = st;
	    z.delay_lo = 0;
	    z.delay_hi = 0;
	    unsigned s0 = nfa_add_step_(nfa, cur, z, false, fm_exit);
	    if (s0 == ~0u) return ~0u;
	    nfa.eps(s0, exit);
	    sva_seq_step_t r = st;
	    r.delay_lo = 1;
	    r.delay_hi = -1;
	    unsigned s1 = nfa_add_step_(nfa, cur, r, false, fm_exit);
	    if (s1 == ~0u) return ~0u;
	    nfa.eps(s1, exit);
	    return exit;
      }

	// The first step consumes the anchor tick before a positive delay.
	// Later steps already have a consumed arrival tick: fixed-1 waits.
      for (long k = first ? 0 : 1; k < fixed; k += 1) {
	    unsigned nxt = nfa.new_state();
	    nfa.tick(cur, nxt, nullptr);
	    cur = nxt;
      }

	// M9-NFA stage C.1: goto `b[->m:n]` (rep_kind 1) / nonconsecutive
	// `b[=m:n]` (rep_kind 2) repetition of a boolean (16.9.2). After the
	// leading delay, `cur` is positioned so the first occurrence-check
	// is the (fixed)-th tick out of it. Build a counting wait-loop.
      if (st.rep_kind != 0) {
	    long m = st.rep_lo;
	    long n = st.rep_hi;                 // -1 == unbounded upper
	    bool ub = (n < 0);
	      /* Consecutive repetition with an empty lower bound. A fresh
		 exit admits the zero-copy match. For a mid-chain ##0 arrival,
		 the first nonempty copy must be fused onto the incoming tick;
		 otherwise `[ *0:$] ##0 tail' skips checking the first copy and
		 can survive a terminating condition for one cycle too long. */
	    if (st.rep_kind == 3) {
		  if (m < 0 || (!ub && n < m) || st.rep_tail != 0)
			return ~0u;
		  /* The generic delay prefix above emitted fixed-1 ticks because
		     an ordinary nonempty step places its expression on the final
		     arrival tick. An empty repetition still owns that final tick;
		     emit it unguarded, then fuse the first nonempty alternative
		     back onto it. */
		  if (fixed > 0) {
			unsigned arrival = nfa.new_state();
			nfa.tick(cur, arrival, nullptr);
			cur = arrival;
		  }
		  unsigned exit = nfa.new_state();
		  if (m == 0) nfa.eps(cur, exit);
		  if (!ub && n == 0) return exit;
		  unsigned prev;
		  if (first && fixed == 0) {
			prev = nfa.new_state();
			nfa.tick(cur, prev, st.expr);
		  } else {
			prev = nfa_fuse_arrival_(nfa, cur, st.expr);
			if (prev == ~0u) return ~0u;
		  }
		  if (m <= 1) nfa.eps(prev, exit);
		  if (ub) {
			nfa.tick(prev, prev, st.expr);
		  } else {
			for (long i = 2; i <= n; i += 1) {
			      unsigned nxt = nfa.new_state();
			      nfa.tick(prev, nxt, st.expr);
			      if (i >= m) nfa.eps(nxt, exit);
			      prev = nxt;
			}
		  }
		  return exit;
	    }
	      // rep_lo < 1 ([->0]/[=0]) admits empty matches -- still
	      // declined here (falls back to the legacy loud sorry).
	    if (m < 1 || (!ub && n < m)) return ~0u;
	      // A tail repetition riding the SAME step -- `(b[->1])[*1:2]',
	      // attached after the fact by pform_sva_repeat -- was silently
	      // DROPPED: this branch returns before the `rep_tail_only'
	      // code, so the automaton came out identical to the tail-free
	      // sequence and legal matches went missing with no diagnostic.
	      // Decline, so the shape is loud rather than quietly wrong.
	    if (st.rep_tail != 0) return ~0u;
	    PExpr*nose = new PEUnary('!', st.expr);   // shared !e guard
	    nose->set_lineno(st.expr->get_lineno());
	    nose->set_file(st.expr->get_file());

	      // C5-2 (CL1-001): ##0-fused rep start `x ##0 b[->m:n]' --
	      // the level-1 occurrence check shares the arrival tick.
	      // Fuse BOTH outcomes onto the arrival edges: e counts as
	      // the first occurrence (a fused level-1 arrival, wired by
	      // epsilon into the fragment's level-1 state below); !e
	      // enters the wait loop. (Window and unbounded arrivals
	      // never reach here fused -- the splits above decompose
	      // them to exact delays first.)
	    unsigned a1f = ~0u;
	    if (fixed == 0 && !first) {
		  unsigned w0f = nfa_fuse_arrival_(nfa, cur, nose);
		  if (w0f == ~0u) return ~0u;
		  a1f = nfa_fuse_arrival_(nfa, cur, st.expr);
		  if (a1f == ~0u) return ~0u;
		  cur = w0f;
	    }
	      // C5-2 (CL1-001): unbounded arrival ##[m:$] -- idle any
	      // number of extra ticks before the wait loop. The union
	      // over all fixed arrivals d >= m collapses to an unguarded
	      // self-loop on the entry state: for the k-th-occurrence
	      // exit, choosing the arrival just after a skipped
	      // occurrence re-indexes the count, so every occurrence
	      // from the k-th onward ends a match -- exactly what the
	      // idle loop admits.
	    if (unbounded)
		  nfa.tick(cur, cur, nullptr);

	      // The wait loop must NEVER be stamped onto a state the CALLER
	      // owns. With an arrival of 0 or 1 the delay loop above emits no
	      // state, so `cur' would carry both this fragment's `!e'
	      // self-loop AND a sibling window split's unguarded delay tick:
	      // a thread could idle on `!e' and then take the sibling's tick,
	      // realizing an arrival past the window's upper bound and
	      // skipping occurrences the LRM requires it to count (16.9.4).
	      // That admitted matches the LRM forbids -- assertions PASSING
	      // on traces where the property cannot hold. A private entry
	      // (epsilon-reached, free after folding) keeps each fragment's
	      // outgoing structure to itself.
	    unsigned went = nfa.new_state();
	    nfa.eps(cur, went);
	    cur = went;
	    unsigned exit = nfa.new_state();

	    if (st.rep_kind == 1) {
		    // GOTO: split each count level into a wait state w[i-1]
		    // and an arrival state a[i], so exit happens ON the
		    // occurrence (a[i] has no self-loop; on the next tick the
		    // slot is already in w[i]). eps a[i]->exit for i in [m,n].
		  unsigned w = cur;
		  long K = ub ? m : n;
		  for (long i = 1; i <= K; i += 1) {
			nfa.tick(w, w, nose);              // stay on !e
			unsigned a = nfa.new_state();
			nfa.tick(w, a, st.expr);           // advance on e
			if (i == 1 && a1f != ~0u)
			      nfa.eps(a1f, a);             // fused occurrence 1
			if (i >= m) nfa.eps(a, exit);      // exit ON the i-th e
			if (i < K) {
			      unsigned wn = nfa.new_state();
			      nfa.eps(a, wn);
			      w = wn;
			} else if (ub) {
				// [->m:$]: perpetual +1 loop from a[m].
			      unsigned wm = nfa.new_state();
			      nfa.eps(a, wm);
			      nfa.tick(wm, wm, nose);
			      unsigned amore = nfa.new_state();
			      nfa.tick(wm, amore, st.expr);
			      nfa.eps(amore, exit);
			      nfa.eps(amore, wm);
			}
		  }
	    } else {
		    // NONCONSECUTIVE: single state per count level with a
		    // trailing !e self-loop (the match may extend past the
		    // last occurrence). eps s[i]->exit for i in [m,n].
		  long K = ub ? m : n;
		  std::vector<unsigned> s(K + 1);
		  s[0] = cur;
		  for (long i = 1; i <= K; i += 1) s[i] = nfa.new_state();
		  for (long i = 0; i < K; i += 1) {
			nfa.tick(s[i], s[i], nose);        // stay on !e
			nfa.tick(s[i], s[i+1], st.expr);   // advance on e
		  }
		  if (a1f != ~0u)
			nfa.eps(a1f, s[1]);                // fused occurrence 1
		  nfa.tick(s[K], s[K], nose);              // trailing !e
		  if (ub) nfa.tick(s[K], s[K], st.expr);  // [=m:$]: absorb more
		  for (long i = m; i <= K; i += 1) nfa.eps(s[i], exit);
	    }
	    return exit;
      }

      unsigned before_expr = cur;
      if (fixed == 0 && !first) {
	      // ##0 fusion: the step's boolean shares the arrival
	      // tick of the previous step (see nfa_fuse_arrival_).
	    unsigned join = nfa_fuse_arrival_(nfa, cur, st.expr, fm_exit);
	    if (join == ~0u) return ~0u;

	      // ##[0:n] / ##[0:$]: arrivals >= 1 are an ordinary
	      // ##[1:n]/##[1:$] fragment from the pre-fusion state,
	      // eps-joined with the fused arrival-0 state.
	    if (unbounded || hi > 0) {
		  sva_seq_step_t rest = st;
		  rest.delay_lo = 1;
		  rest.delay_hi = unbounded ? -1 : hi;
		  rest.rep_tail = 0;
		  unsigned sub = nfa_add_step_(nfa, before_expr, rest, false,
                                             fm_exit);
		  if (sub == ~0u) return ~0u;
		  unsigned j2 = nfa.new_state();
		  nfa.eps(join, j2);
		  nfa.eps(sub, j2);
		  cur = j2;
	    } else {
		  cur = join;
	    }

	      // Tail repetition still applies (shared code below);
	      // the delayed-arrival window is already handled.
	    goto rep_tail_only;
      } else if (fixed == 0) {
	      // Anchor tick: one guarded edge out of the start.
	    unsigned nxt = nfa.new_state();
	    nfa.tick(cur, nxt, st.expr, fm_exit);
	    cur = nxt;
      } else {
	    unsigned nxt = nfa.new_state();
	    nfa.tick(cur, nxt, st.expr, fm_exit);
	    cur = nxt;
      }

	// Optional window ticks for ##[m:n]: (n-m) more chances, each
	// one further tick out, all converging via epsilon.
      if (!unbounded && hi > lo) {
	    unsigned join = nfa.new_state();
	    nfa.eps(cur, join);
	    unsigned wait = before_expr;
	    for (long k = lo; k < hi; k += 1) {
		  unsigned w2 = nfa.new_state();
		  nfa.tick(wait, w2, nullptr);
		  unsigned hit = nfa.new_state();
		  nfa.tick(w2, hit, st.expr, fm_exit);
		  nfa.eps(hit, join);
		  wait = w2;
	    }
	    cur = join;
      } else if (unbounded) {
	      // ##[m:$]: loop a pure-delay tick on the wait state.
	    nfa.tick(before_expr, before_expr, nullptr);
      }

rep_tail_only:
	// Unbounded tail expr[*m:$] (rep_tail == -1): the mandatory m
	// copies are already in the chain, and any number of further
	// consecutive matches is allowed. That is a guarded SELF-LOOP,
	// not a finite fan-out -- stay in the join state as long as the
	// expression keeps holding, and leave whenever the rest of the
	// chain can take over.
      if (st.rep_tail < 0) {
	    unsigned join = nfa.new_state();
	    nfa.eps(cur, join);
	    nfa.tick(join, join, st.expr);
	    return join;
      }

	// Tail repetition expr[*1:1+rep_tail] (legacy last-step
	// encoding): optional extra guarded ticks.
      if (st.rep_tail > 0) {
	    unsigned join = nfa.new_state();
	    nfa.eps(cur, join);
	    unsigned prev = cur;
	    for (long k = 0; k < st.rep_tail; k += 1) {
		  unsigned nxt = nfa.new_state();
		  nfa.tick(prev, nxt, st.expr);
		  nfa.eps(nxt, join);
		  prev = nxt;
	    }
	    cur = join;
      }

      return cur;
}

/*
 * Eliminate epsilon edges by epsilon-closure (the textbook NFA
 * construction; the earlier predecessor-duplication pass silently
 * orphaned a state with two outgoing epsilons — e.g. an `or` fresh
 * start with eps to each branch — dropping every branch but the
 * first).
 *
 * Algorithm:
 *  1. E[s] = epsilon-closure of s (all states eps-reachable from s,
 *     including s), by transitive closure over the epsilon edges.
 *  2. For every state s and every tick edge t->u with t in E[s], emit
 *     a tick edge s->u (deduplicated). This lifts each state's
 *     reachable tick moves to the state itself.
 *  3. Accept: any state whose closure contains the old accept is an
 *     accepting state. To keep the synthesizer's single-accept model,
 *     add ONE fresh accept sink A and, for every emitted tick edge
 *     s->u whose target u eps-reaches the old accept, add a PARALLEL
 *     s->A with the same guards. A state that both accepts and
 *     continues (a window join) thus fires A (match) and u (continue)
 *     on the same tick.
 *  4. Drop all epsilon edges; accept := A. (If the start itself
 *     eps-reaches the old accept — a zero-length match, not produced
 *     by the current constructions — A stays unreachable and the
 *     caller's accept-reachability guard makes the assertion fall
 *     back, which is safe.)
 */
static void fold_epsilons_(sva_nfa_t&nfa)
{
      unsigned N = nfa.nstates;
      std::vector< std::vector<bool> > eps (N, std::vector<bool>(N, false));
      for (unsigned s = 0; s < N; s += 1) eps[s][s] = true;
      for (size_t i = 0; i < nfa.edges.size(); i += 1)
	    if (nfa.edges[i].epsilon)
		  eps[nfa.edges[i].from][nfa.edges[i].to] = true;
      for (unsigned k = 0; k < N; k += 1)
	    for (unsigned i = 0; i < N; i += 1)
		  if (eps[i][k])
			for (unsigned j = 0; j < N; j += 1)
			      if (eps[k][j]) eps[i][j] = true;

      std::vector<sva_nfa_edge_t> ticks;
      for (size_t i = 0; i < nfa.edges.size(); i += 1)
	    if (!nfa.edges[i].epsilon) ticks.push_back(nfa.edges[i]);

      unsigned old_accept = nfa.accept;
      unsigned A = nfa.new_state();
      N = nfa.nstates;

      std::vector<sva_nfa_edge_t> out;
      auto push_uniq = [&](const sva_nfa_edge_t&ne) {
	    for (size_t k = 0; k < out.size(); k += 1) {
		  sva_nfa_edge_t&o = out[k];
		  if (o.from == ne.from && o.to == ne.to
		      && o.guards == ne.guards
		      && o.first_match_exit == ne.first_match_exit
		      && o.first_match_guards == ne.first_match_guards) {
			return;
		  }
	    }
	    out.push_back(ne);
      };
      for (unsigned s = 0; s < N; s += 1) {
	    if (s == A) continue;
	    for (size_t i = 0; i < ticks.size(); i += 1) {
		  const sva_nfa_edge_t&te = ticks[i];
		  if (!eps[s][te.from]) continue;
		  sva_nfa_edge_t ne = te;
		  ne.from = s;
		  push_uniq(ne);
		  if (te.to < eps.size() && eps[te.to][old_accept]) {
			sva_nfa_edge_t ae = te;
			ae.from = s;
			ae.to = A;
			push_uniq(ae);
		  }
	    }
      }

      nfa.edges.swap(out);
      nfa.accept = A;
}

/*
 * Keep only states that are both reachable from start and can reach
 * accept. Folding leaves dead-end duplicates behind (pre-fold accept
 * copies); product construction also allocates the full Cartesian grid,
 * including pairs whose relative tick positions make them impossible to
 * enter. The former are FATAL for the synthesizer's emptiness test — a
 * thread sitting only in dead states must count as failed — and the latter
 * needlessly multiply every per-attempt state bit. Edges from/to either
 * kind go too.
 */
static void prune_dead_states_(sva_nfa_t&nfa,
			       std::vector<unsigned>*old_to_new = nullptr)
{
      std::vector<bool> can_accept (nfa.nstates, false);
      can_accept[nfa.accept] = true;
      bool changed = true;
      while (changed) {
	    changed = false;
	    for (size_t i = 0; i < nfa.edges.size(); i += 1) {
		  const sva_nfa_edge_t&e = nfa.edges[i];
		  if (can_accept[e.to] && !can_accept[e.from]) {
			can_accept[e.from] = true;
			changed = true;
		  }
	    }
      }

      std::vector<bool> reachable (nfa.nstates, false);
      reachable[nfa.start] = true;
      changed = true;
      while (changed) {
	    changed = false;
	    for (size_t i = 0; i < nfa.edges.size(); i += 1) {
		  const sva_nfa_edge_t&e = nfa.edges[i];
		  if (reachable[e.from] && !reachable[e.to]) {
			reachable[e.to] = true;
			changed = true;
		  }
	    }
      }

      std::vector<bool> live (nfa.nstates, false);
      for (unsigned s = 0; s < nfa.nstates; s += 1)
	    live[s] = reachable[s] && can_accept[s];
	// Keep both sentinels even for a vacuously dead automaton. The caller's
	// explicit accept-reachability guard will then decline the construction
	// cleanly instead of observing an invalid remap index.
      live[nfa.start] = true;
      live[nfa.accept] = true;

      std::vector<unsigned> remap (nfa.nstates, ~0u);
      unsigned next = 0;
      for (unsigned s = 0; s < nfa.nstates; s += 1)
	    if (live[s]) remap[s] = next++;

      std::vector<sva_nfa_edge_t> kept;
      for (size_t i = 0; i < nfa.edges.size(); i += 1) {
	    const sva_nfa_edge_t&e = nfa.edges[i];
	    if (!live[e.from] || !live[e.to]) continue;
	    sva_nfa_edge_t ne = e;
	    ne.from = remap[e.from];
	    ne.to = remap[e.to];
	    kept.push_back(ne);
      }
      nfa.edges.swap(kept);
      nfa.start = remap[nfa.start];
      nfa.accept = remap[nfa.accept];
      nfa.nstates = next;
      if (old_to_new) old_to_new->swap(remap);
}

static bool nfa_chain_suffix_(sva_nfa_t&nfa,
                              const std::vector<sva_seq_step_t>&steps,
                              size_t k, unsigned cur, bool first,
                              unsigned&exit)
{
      if (k == steps.size()) { exit = cur; return true; }
      bool tagged = !steps[k].group_repeat_opens.empty();
      if (!tagged && !steps[k].group_repeat_start) {
            if (steps[k].grouped_repeat) return false;
	    /* IEEE 1800-2017 16.9.2.1 requires a zero-inclusive
	       consecutive repetition to split before concatenation. The
	       empty branch has no ##0 match; for a positive delay, remove
	       the empty interval and shorten the combined delay by one.
	       The nonempty branch retains the ordinary repetition builder.

	       Besides implementing the empty-match rule generally, this
	       keeps `p[*0:$] ##1 bad' exact: empty checks bad on the
	       current tick, while every nonempty p prefix checks bad on its
	       following tick. */
	    const sva_seq_step_t&rep = steps[k];
	    if (rep.rep_kind == 3 && rep.rep_lo == 0) {
		  unsigned join = nfa.new_state();
		  bool any = false;

		  /* Nonempty alternatives: [*1:hi]. */
		  if (rep.rep_hi < 0 || rep.rep_hi >= 1) {
			std::vector<sva_seq_step_t>nonempty(steps.begin()+k,
							    steps.end());
			nonempty[0].rep_lo = 1;
			unsigned nonempty_exit = 0;
			if (!nfa_chain_suffix_(nfa, nonempty, 0, cur, first,
						       nonempty_exit)) return false;
			if (nonempty_exit != ~0u) {
			      nfa.eps(nonempty_exit, join);
			      any = true;
			}
		  }

		  /* A terminal empty alternative follows the companion rules in
		     16.9.2.1: ##0 is illegal after a nonempty prefix, while
		     ##d empty (d>0) ends one tick earlier than d. */
		  if (k + 1 == steps.size()) {
			static const long construction_limit = 1024;
			long lo = rep.delay_lo;
			long hi = rep.delay_hi;
			if (lo < 0 || hi < -1 || lo > construction_limit
			    || (hi >= 0 && hi > construction_limit)) return false;
			if (first && lo == 0) {
			      nfa.eps(cur, join);
			      any = true;
			}
			long d = std::max(lo, 1L);
			if (hi < 0 || d <= hi) {
			      /* Keep an unbounded loop off cur: cur may also feed a
			         sibling alternative in the caller. */
			      unsigned z = nfa.new_state();
			      nfa.eps(cur, z);
			      for (long tick = 1; tick < d; ++tick) {
			            unsigned zn = nfa.new_state();
			            nfa.tick(z, zn, nullptr);
			            z = zn;
			      }
			      nfa.eps(z, join);
			      any = true;
			      if (hi < 0) {
			            nfa.tick(z, z, nullptr);
			      } else {
			            for (long more = d + 1; more <= hi; ++more) {
			                  unsigned zn = nfa.new_state();
			                  nfa.tick(z, zn, nullptr);
			                  z = zn;
			                  nfa.eps(z, join);
			            }
			      }
			}
			exit = any ? join : ~0u;
			return true;
		  }

		  /* Empty alternative: use the same 16.9.2.1 algebra as the
		     grouped-repetition split below. Both concatenations adjacent
		     to empty must be positive, except the leading chain boundary;
		     their composed delay is d1+d2-1. */
		  std::vector<sva_seq_step_t>empty(steps.begin()+k+1,
						       steps.end());
		  long ol = std::max(rep.delay_lo, first ? 0L : 1L);
		  long nl = std::max(empty[0].delay_lo, 1L);
		  long oh = rep.delay_hi;
		  long nh = empty[0].delay_hi;
		  bool outer_ok = oh < 0 || oh >= ol;
		  bool next_ok = nh < 0 || nh >= nl;
		  if (outer_ok && next_ok) {
			empty[0].delay_lo = ol + nl - 1;
			empty[0].delay_hi = (oh < 0 || nh < 0)
			      ? -1 : oh + nh - 1;
			unsigned empty_exit = 0;
			if (!nfa_chain_suffix_(nfa, empty, 0, cur, first,
						       empty_exit)) return false;
			if (empty_exit != ~0u) {
			      nfa.eps(empty_exit, join);
			      any = true;
			}
		  }
		  exit = any ? join : ~0u;
		  return true;
	    }
            bool fm_exit = steps[k].fm
                          && (k + 1 == steps.size() || !steps[k+1].fm);
            unsigned next = nfa_add_step_(nfa, cur, steps[k], first,
                                          fm_exit);
            if (next == ~0u) return false;
            return nfa_chain_suffix_(nfa, steps, k+1, next, false, exit);
      }

      sva_group_repeat_t group;
      if (tagged) group = steps[k].group_repeat_opens.back();
      else {
            group.lo = steps[k].group_repeat_lo;
            group.hi = steps[k].group_repeat_hi;
            group.first_delay_lo = steps[k].group_repeat_first_delay_lo;
            group.first_delay_hi = steps[k].group_repeat_first_delay_hi;
      }
      size_t last = k;
      if (tagged) {
            while (last < steps.size()
                   && find(steps[last].group_repeat_closes.begin(),
                           steps[last].group_repeat_closes.end(), group.id)
                        == steps[last].group_repeat_closes.end()) ++last;
      } else {
            while (last < steps.size() && !steps[last].group_repeat_end) ++last;
      }
      if (last == steps.size()) return false;
      long lo = group.lo, hi = group.hi;
      if (lo < 0 || hi < lo) return false;
      unsigned join = nfa.new_state();
      bool any = false;

      /* Every nonempty copy count owns its own suffix. This is necessary
         because the zero-copy alternative obeys different concatenation
         delay algebra and cannot share one pre-suffix group exit. */
      unsigned copy_cur = cur;
      for (long r = 1; r <= hi; ++r) {
            std::vector<sva_seq_step_t>body;
            for (size_t j = k; j <= last; ++j) {
                  sva_seq_step_t st = steps[j];
                  if (tagged) {
                        st.group_repeat_members.erase(remove(
                              st.group_repeat_members.begin(),
                              st.group_repeat_members.end(), group.id),
                              st.group_repeat_members.end());
                        st.group_repeat_opens.erase(remove_if(
                              st.group_repeat_opens.begin(),
                              st.group_repeat_opens.end(),
                              [&](const sva_group_repeat_t&item) {
                                    return item.id == group.id;
                              }), st.group_repeat_opens.end());
                        st.group_repeat_closes.erase(remove(
                              st.group_repeat_closes.begin(),
                              st.group_repeat_closes.end(), group.id),
                              st.group_repeat_closes.end());
                        st.grouped_repeat = !st.group_repeat_members.empty();
                  } else st.grouped_repeat = false;
                  st.group_repeat_start = st.group_repeat_end = false;
                  if (r > 1 && j == k) {
                        long il = group.first_delay_lo;
                        long ih = group.first_delay_hi;
                        if (il < 0 || ih < il) return false;
                        st.delay_lo = il + 1;
                        st.delay_hi = ih + 1;
                  }
                  body.push_back(st);
            }
            unsigned body_exit = 0;
            if (!nfa_chain_suffix_(nfa, body, 0, copy_cur,
                                   first && r == 1, body_exit)) return false;
            copy_cur = body_exit;
            // A nested body can denote the empty language even though the
            // enclosing repetition has a legal zero-copy alternative.
            if (copy_cur == ~0u) break;
            if (r >= lo) {
                  unsigned tail = 0;
                  if (!nfa_chain_suffix_(nfa, steps, last+1, copy_cur,
                                         false, tail)) return false;
                  if (tail != ~0u) {
                        nfa.eps(tail, join);
                        any = true;
                  }
            }
      }

      if (lo == 0) {
            long outer_lo = steps[k].delay_lo
                          - group.first_delay_lo;
            long outer_hi = steps[k].delay_hi
                          - group.first_delay_hi;
            if (outer_lo < 0 || outer_hi < outer_lo) return false;
            if (last + 1 == steps.size()) {
                  /* `prefix ##d empty' has no match for d==0. For d>0
                     its empty endpoint is one tick earlier than d. A group
                     at the chain start is the canonical empty sequence. */
                  if (first && outer_lo == 0) {
                        nfa.eps(cur, join); any = true;
                  }
                  for (long d = std::max(outer_lo, 1L); d <= outer_hi; ++d) {
                        unsigned z = cur;
                        for (long tick = 1; tick < d; ++tick) {
                              unsigned zn = nfa.new_state();
                              nfa.tick(z, zn, nullptr); z = zn;
                        }
                        nfa.eps(z, join); any = true;
                  }
            } else {
                  /* Both concatenations around the empty fragment must use
                     positive delays. Their composed delay is d1+d2-1. */
                  const sva_seq_step_t&next = steps[last+1];
                  long ol = std::max(outer_lo, first ? 0L : 1L);
                  long nl = std::max(next.delay_lo, 1L);
                  if (next.delay_hi >= nl && outer_hi >= ol) {
                        std::vector<sva_seq_step_t>tail(
                              steps.begin()+last+1, steps.end());
                        tail[0].delay_lo = ol + nl - 1;
                        tail[0].delay_hi = outer_hi + next.delay_hi - 1;
                        unsigned ze = 0;
                        if (!nfa_chain_suffix_(nfa, tail, 0, cur, first, ze))
                              return false;
                        if (ze != ~0u) {
                              nfa.eps(ze, join); any = true;
                        }
                  }
            }
      }
      exit = any ? join : ~0u;
      return true;
}

static bool nfa_chain_fragment_(sva_nfa_t&nfa,
                                const std::vector<sva_seq_step_t>&steps,
                                unsigned&start, unsigned&exit)
{
      start = nfa.new_state();
      if (!nfa_chain_suffix_(nfa, steps, 0, start, true, exit))
            return false;
      /* Preserve the empty language inside sequence composition (for
         example an OR alternative). Property uses still require the
         nondegeneracy check in pform_sva_nfa_try_assertion. */
      if (exit == ~0u) exit = nfa.new_state();
      return true;
}

static bool nfa_accepts_empty_(const sva_nfa_t&nfa)
{
      if (nfa.start == nfa.accept) return true;
      std::vector<bool>seen(nfa.nstates, false);
      std::vector<unsigned>todo;
      todo.push_back(nfa.start);
      seen[nfa.start] = true;
      while (!todo.empty()) {
	    unsigned cur = todo.back();
	    todo.pop_back();
	    for (size_t i = 0; i < nfa.edges.size(); ++i) {
		  const sva_nfa_edge_t&edge = nfa.edges[i];
		  if (!edge.epsilon || edge.from != cur || seen[edge.to]) continue;
		  if (edge.to == nfa.accept) return true;
		  seen[edge.to] = true;
		  todo.push_back(edge.to);
	    }
      }
      return false;
}

bool pform_sva_nfa_build_from_chain(sva_nfa_t&nfa,
				    const std::vector<sva_seq_step_t>&steps)
{
      unsigned s = 0, e = 0;
      if (!nfa_chain_fragment_(nfa, steps, s, e))
	    return false;
      nfa.start = s;
      nfa.accept = e;
      nfa.accepts_empty = nfa_accepts_empty_(nfa);
      fold_epsilons_(nfa);
      prune_dead_states_(nfa);
      return true;
}

/*
 * Stage B: product construction for `intersect` (both sides advance
 * in lockstep, accept together — same-interval semantics, 16.9.6)
 * and `and` (both match, the match ends with the LATER side; the
 * earlier side idles in an absorbing `done` state). Sides arrive
 * fully folded+pruned (tick edges only); the product's epsilon exits
 * are folded by the caller's top-level pass.
 */
static bool nfa_product_fragment_(sva_nfa_t&nfa,
				  const sva_nfa_t&A, const sva_nfa_t&B,
				  bool and_mode,
				  unsigned&start, unsigned&exit)
{
      sva_nfa_t A2 = A, B2 = B;
      unsigned doneA = 0, doneB = 0;
      if (and_mode) {
	    doneA = A2.new_state();
	    A2.tick(A2.accept, doneA, nullptr);
	    A2.tick(doneA, doneA, nullptr);
	    doneB = B2.new_state();
	    B2.tick(B2.accept, doneB, nullptr);
	    B2.tick(doneB, doneB, nullptr);
      }
      unsigned n2 = B2.nstates;
      unsigned base = nfa.nstates;
      for (unsigned i = 0; i < A2.nstates * B2.nstates; i += 1)
	    nfa.new_state();
      for (size_t i1 = 0; i1 < A2.edges.size(); i1 += 1) {
	    const sva_nfa_edge_t&e1 = A2.edges[i1];
	    if (e1.epsilon) return false;   // sides must be folded
	    for (size_t i2 = 0; i2 < B2.edges.size(); i2 += 1) {
		  const sva_nfa_edge_t&e2 = B2.edges[i2];
		  if (e2.epsilon) return false;
		  sva_nfa_edge_t e;
		  e.from = base + e1.from * n2 + e2.from;
		  e.to   = base + e1.to   * n2 + e2.to;
		  e.guards = e1.guards;
		  e.guards.insert(e.guards.end(),
				  e2.guards.begin(), e2.guards.end());
		  nfa.edges.push_back(e);
	    }
      }
      start = base + A2.start * n2 + B2.start;
      exit = nfa.new_state();
      nfa.eps(base + A2.accept * n2 + B2.accept, exit);
      if (and_mode) {
	    nfa.eps(base + doneA * n2 + B2.accept, exit);
	    nfa.eps(base + A2.accept * n2 + doneB, exit);
      }
      return true;
}

/*
 * `within` padding (IEEE 1800-2017 16.9.6): s1 within s2 ==
 * (1[*0:$] ##1 s1 ##1 1[*0:$]) intersect s2. Wrap a folded automaton
 * Araw with an arbitrary true-tick prefix and suffix so it matches
 * "s1 occurs somewhere in the window": a fresh PRE with a true
 * self-loop that can enter Araw at any tick, and a fresh accepting
 * POST with a true self-loop entered once Araw accepts. The product
 * with s2 (intersect semantics) then ties the padded match to s2's
 * exact interval. Result is re-folded/pruned so the product sees only
 * tick edges.
 */
static void nfa_pad_(sva_nfa_t&M, const sva_nfa_t&Araw)
{
      M = Araw;
      unsigned PRE = M.new_state();
      unsigned POST = M.new_state();
      M.tick(PRE, PRE, nullptr);
      M.eps(PRE, Araw.start);
      M.eps(Araw.accept, POST);
      M.tick(POST, POST, nullptr);
      M.start = PRE;
      M.accept = POST;
      fold_epsilons_(M);
      prune_dead_states_(M);
}

static bool nfa_tree_fragment_(sva_nfa_t&nfa, const sva_stree_t*t,
			       unsigned&start, unsigned&exit)
{
      if (!t) return false;
      switch (t->kind) {
	  case sva_stree_t::LEAF:
	    if (!t->chain) return false;
	    return nfa_chain_fragment_(nfa, *t->chain, start, exit);
	  case sva_stree_t::SEQ_WITHIN: {
		  /* s1 within s2: pad s1, then intersect with s2. */
		sva_nfa_t Araw, B, M;
		if (!pform_sva_nfa_build_from_tree(Araw, t->a)) return false;
		if (!pform_sva_nfa_build_from_tree(B, t->b)) return false;
		nfa_pad_(M, Araw);
		return nfa_product_fragment_(nfa, M, B, false, start, exit);
	  }
	  case sva_stree_t::SEQ_THROUGHOUT: {
		  /* exp throughout seq (16.9.9): the invariant must hold at
		     EVERY cycle of seq. Build seq's folded automaton and
		     AND the invariant onto every tick edge — a pure-delay
		     window tick (empty guard) thus becomes the invariant
		     alone, checking it at the wait cycles too. */
		if (!t->gexpr) return false;
		sva_nfa_t A;
		if (!pform_sva_nfa_build_from_tree(A, t->a)) return false;
		for (size_t i = 0; i < A.edges.size(); i += 1)
		      A.edges[i].guards.push_back(t->gexpr);
		unsigned base = nfa.nstates;
		for (unsigned i = 0; i < A.nstates; i += 1) nfa.new_state();
		for (size_t i = 0; i < A.edges.size(); i += 1) {
		      sva_nfa_edge_t ne = A.edges[i];
		      ne.from = base + A.edges[i].from;
		      ne.to = base + A.edges[i].to;
		      nfa.edges.push_back(ne);
		}
		start = base + A.start;
		exit = base + A.accept;
		return true;
	  }
	  case sva_stree_t::SEQ_CONCAT: {
		  /* Concatenation is the same regular-language composition used
		     by an implication, without implication verdict bookkeeping.
		     ##0 fuses the prefix terminal guards with the suffix's first
		     tick; ##1-or-later starts the prepared suffix on a later tick. */
		sva_nfa_t M;
		std::vector<sva_nfa_boundary_t> ignored;
		if (!pform_sva_nfa_build_implication(
		      M, t->a, t->b, !t->concat_overlap, ignored))
		      return false;
		unsigned base = nfa.nstates;
		for (unsigned i = 0; i < M.nstates; i += 1) nfa.new_state();
		for (size_t i = 0; i < M.edges.size(); i += 1) {
		      sva_nfa_edge_t edge = M.edges[i];
		      edge.from += base;
		      edge.to += base;
		      nfa.edges.push_back(edge);
		}
		start = base + M.start;
		exit = base + M.accept;
		return true;
	  }
	  case sva_stree_t::SEQ_OR: {
		unsigned sa = 0, ea = 0, sb = 0, eb = 0;
		if (!nfa_tree_fragment_(nfa, t->a, sa, ea)) return false;
		if (!nfa_tree_fragment_(nfa, t->b, sb, eb)) return false;
		start = nfa.new_state();
		nfa.eps(start, sa);
		nfa.eps(start, sb);
		exit = nfa.new_state();
		nfa.eps(ea, exit);
		nfa.eps(eb, exit);
		return true;
	  }
	  case sva_stree_t::SEQ_AND:
	  case sva_stree_t::SEQ_INTERSECT: {
		  /* Each side normalizes to its own folded automaton
		     (recursion composes nested combinators), then the
		     product embeds in the parent. */
		sva_nfa_t A, B;
		if (!pform_sva_nfa_build_from_tree(A, t->a)) return false;
		if (!pform_sva_nfa_build_from_tree(B, t->b)) return false;
		return nfa_product_fragment_(nfa, A, B,
					     t->kind == sva_stree_t::SEQ_AND,
					     start, exit);
	  }
      }
      return false;
}

bool pform_sva_nfa_build_from_tree(sva_nfa_t&nfa, const sva_stree_t*tree)
{
      unsigned s = 0, e = 0;
      if (!nfa_tree_fragment_(nfa, tree, s, e))
	    return false;
      nfa.start = s;
      nfa.accept = e;
      nfa.accepts_empty = nfa_accepts_empty_(nfa);
      fold_epsilons_(nfa);
      prune_dead_states_(nfa);
      return true;
}

bool pform_sva_nfa_build_implication(
				sva_nfa_t&nfa, const sva_stree_t*ante,
				const sva_stree_t*conseq, bool nonoverlap,
				std::vector<sva_nfa_boundary_t>&boundary)
{
      sva_nfa_t A, B;
      if (!pform_sva_nfa_build_from_tree(A, ante)
	  || !pform_sva_nfa_build_from_tree(B, conseq))
	    return false;

      nfa = sva_nfa_t();
      boundary.clear();
      for (unsigned i = 0; i < A.nstates + B.nstates; i += 1)
	    nfa.new_state();
      const unsigned boff = A.nstates;

      std::vector<sva_nfa_edge_t> terminal;
      for (size_t i = 0; i < A.edges.size(); i += 1) {
	    const sva_nfa_edge_t&e = A.edges[i];
	    if (e.to == A.accept) {
		  terminal.push_back(e);
		  sva_nfa_boundary_t b;
		  b.from = e.from;
		  b.guards = e.guards;
		  boundary.push_back(b);
	    }
	    nfa.edges.push_back(e);
      }
      for (size_t i = 0; i < B.edges.size(); i += 1) {
	    sva_nfa_edge_t e = B.edges[i];
	    e.from += boff;
	    e.to += boff;
	    nfa.edges.push_back(e);
      }

      nfa.start = A.start;
      nfa.accept = boff + B.accept;
      if (nonoverlap) {
	    nfa.eps(A.accept, boff + B.start);
      } else {
	      /* |->: the consequent's first tick is the antecedent's
		 terminal tick. Pair every terminal antecedent edge with every
		 first consequent edge. The old terminal edges become dead and
		 are removed below; keeping them until pruning makes the
		 construction and its boundary probes straightforward. */
	    for (size_t ai = 0; ai < terminal.size(); ai += 1)
		  for (size_t bi = 0; bi < B.edges.size(); bi += 1) {
			const sva_nfa_edge_t&be = B.edges[bi];
			if (be.from != B.start) continue;
			sva_nfa_edge_t e;
			e.from = terminal[ai].from;
			e.to = boff + be.to;
			e.guards = terminal[ai].guards;
			e.guards.insert(e.guards.end(), be.guards.begin(),
					be.guards.end());
			nfa.edges.push_back(e);
		  }
      }

      fold_epsilons_(nfa);
      std::vector<unsigned> remap;
      prune_dead_states_(nfa, &remap);
      for (size_t i = 0; i < boundary.size(); i += 1) {
	    if (boundary[i].from >= remap.size()
		|| remap[boundary[i].from] == ~0u)
		  return false;
	    boundary[i].from = remap[boundary[i].from];
      }
      return !boundary.empty();
}

void pform_sva_nfa_dump(const struct vlltype&loc, const char*what,
			const sva_nfa_t&nfa)
{
      cerr << loc.get_fileline() << ": IVL_SVA_NFA_DUMP: " << what
	   << " states=" << nfa.nstates
	   << " start=S" << nfa.start
	   << " accept=S" << nfa.accept << endl;
      for (size_t i = 0; i < nfa.edges.size(); i += 1) {
	    const sva_nfa_edge_t&e = nfa.edges[i];
	    cerr << "    S" << e.from
		 << (e.epsilon ? " ..eps.. S" : " --tick(");
	    if (!e.epsilon) {
		  if (e.guards.empty()) cerr << "1";
		  for (size_t g = 0; g < e.guards.size(); g += 1)
			cerr << (g ? "&expr" : "expr");
	    }
	    cerr << (e.epsilon ? "" : ")--> S");
	    if (!e.epsilon) cerr << e.to;
	    else cerr << e.to;
	    cerr << endl;
      }
}

/*
 * Cycle detection (iterative DFS with colors). The construction only
 * creates self-loops (##[m:$] wait states), but folding can move
 * them, so detect generally.
 */
bool pform_sva_nfa_has_cycle(const sva_nfa_t&nfa)
{
      enum { WHITE, GREY, BLACK };
      std::vector<int> color (nfa.nstates, WHITE);
	// Adjacency once, to keep the DFS linear-ish.
      std::vector< std::vector<unsigned> > adj (nfa.nstates);
      for (size_t i = 0; i < nfa.edges.size(); i += 1)
	    adj[nfa.edges[i].from].push_back(nfa.edges[i].to);

      for (unsigned root = 0; root < nfa.nstates; root += 1) {
	    if (color[root] != WHITE) continue;
	    std::vector< std::pair<unsigned,size_t> > stack;
	    stack.push_back(std::make_pair(root, (size_t)0));
	    color[root] = GREY;
	    while (!stack.empty()) {
		  unsigned s = stack.back().first;
		  size_t&idx = stack.back().second;
		  if (idx < adj[s].size()) {
			unsigned t = adj[s][idx++];
			if (color[t] == GREY) return true;
			if (color[t] == WHITE) {
			      color[t] = GREY;
			      stack.push_back(std::make_pair(t, (size_t)0));
			}
		  } else {
			color[s] = BLACK;
			stack.pop_back();
		  }
	    }
      }
      return false;
}

/*
 * Longest path from the start state, skipping edges that close a
 * cycle (memoized DFS; on-stack targets are ignored). For loop-free
 * automata this is the exact maximum attempt lifetime in ticks.
 */
static long nfa_depth_rec_(const std::vector< std::vector<unsigned> >&adj,
			   std::vector<long>&memo, std::vector<bool>&onstack,
			   unsigned s)
{
      if (memo[s] >= 0) return memo[s];
      onstack[s] = true;
      long best = 0;
      for (size_t i = 0; i < adj[s].size(); i += 1) {
	    unsigned t = adj[s][i];
	    if (onstack[t]) continue;   // cycle edge: skip
	    long d = 1 + nfa_depth_rec_(adj, memo, onstack, t);
	    if (d > best) best = d;
      }
      onstack[s] = false;
      memo[s] = best;
      return best;
}

long pform_sva_nfa_depth(const sva_nfa_t&nfa)
{
      if (nfa.nstates == 0) return 0;
      std::vector< std::vector<unsigned> > adj (nfa.nstates);
      for (size_t i = 0; i < nfa.edges.size(); i += 1)
	    adj[nfa.edges[i].from].push_back(nfa.edges[i].to);
      std::vector<long> memo (nfa.nstates, -1);
      std::vector<bool> onstack (nfa.nstates, false);
      return nfa_depth_rec_(adj, memo, onstack, nfa.start);
}

/*
 * M12-2: the FIXED attempt latency — the number of tick edges from the
 * start state to the accept state when every start->accept path has the
 * SAME length (a fixed-##N chain / overlapping-or-non-overlapping
 * implication). Returns that unique length, or -1 when the latency is
 * variable (##[m:n], [*m:n], unbounded waits) or the automaton has a
 * cycle. A fixed latency lets the runtime recover a completing
 * attempt's real start time exactly (it started `latency` clock ticks
 * ago), even for pipelined attempts.
 */
long pform_sva_nfa_fixed_latency(const sva_nfa_t&nfa)
{
      if (nfa.nstates == 0) return -1;
      if (pform_sva_nfa_has_cycle(nfa)) return -1;
      std::vector< std::vector<unsigned> > adj (nfa.nstates);
      for (size_t i = 0; i < nfa.edges.size(); i += 1)
	    adj[nfa.edges[i].from].push_back(nfa.edges[i].to);
	// Min and max tick-distance from start to every state over the
	// DAG (topological DP via memoized DFS). LONG_MAX in dmin means
	// "unreached".
      std::vector<long> dmin (nfa.nstates, -1), dmax (nfa.nstates, -1);
	// Longest to each state is already the depth recursion; do both
	// with an explicit reverse-reachability DP from accept instead:
	// distances from start via forward DP.
      std::vector<bool> onstack (nfa.nstates, false);
      std::vector<long> memo_max (nfa.nstates, -2), memo_min (nfa.nstates, -2);
      struct rec {
	    static void go(const std::vector< std::vector<unsigned> >&adj,
			   std::vector<long>&mmax, std::vector<long>&mmin,
			   std::vector<bool>&onst, unsigned accept, unsigned s)
	    {
		  if (mmax[s] != -2) return;
		  onst[s] = true;
		  long bmax = (s == accept) ? 0 : -1;
		  long bmin = (s == accept) ? 0 : -1;
		  for (size_t i = 0 ; i < adj[s].size() ; i += 1) {
			unsigned t = adj[s][i];
			if (onst[t]) continue;
			go(adj, mmax, mmin, onst, accept, t);
			if (mmax[t] >= 0) {
			      long vmax = 1 + mmax[t];
			      if (vmax > bmax) bmax = vmax;
			}
			if (mmin[t] >= 0) {
			      long vmin = 1 + mmin[t];
			      if (bmin < 0 || vmin < bmin) bmin = vmin;
			}
		  }
		  onst[s] = false;
		  mmax[s] = bmax;
		  mmin[s] = bmin;
	    }
      };
      (void)dmin; (void)dmax;
      rec::go(adj, memo_max, memo_min, onstack, nfa.accept, nfa.start);
      long lo = memo_min[nfa.start];
      long hi = memo_max[nfa.start];
      if (lo < 0 || hi < 0 || lo != hi) return -1;
      return lo;
}
