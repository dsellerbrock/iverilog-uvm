# IEEE 1800-2017 Clause Conformance Matrix (paired with 1800-2023)

Canonical standards record. Read dated refinements alongside the initial
matrix: an older row is not a newer qualification claim. Operational blocker
status lives in [BLOCKERS](../BLOCKERS.md); latest compiler qualification is
linked from [CURRENT_WORK](../CURRENT_WORK.md). Preserve exact subset boundaries.

### October 18, 2026 — §19.7 constructor-captured `option.per_instance`

IEEE 1800-2017/2023 §19.7 says definition option assignments are evaluated at
covergroup instantiation and that `per_instance == 1` retains that instance's
coverage information for the report. IMPLEMENTED for constructor-formal
`option.per_instance` expressions: default false, explicit true/false, captured
readback after the actual changes, procedural-write rejection, and report rows
for enabled live and retired instances. The new hidden property is allocated
after existing bin and parent properties so their IDs and diagnostics remain
stable. Paired `-g2017`/`-g2023` tests pass in the legacy and JSON runners; the
report reducer also checks only enabled instances, percentages, and static-bin
counts. T0 smoke and T1 covergroup selections pass on Slurm job 2588: 250/250
legacy and 237/237 JSON T1 cases. Tool hashes and full logs are in the
[candidate evidence](../../../evidence/issue448-constructor-options-20261018/candidate-green/job-2588/).
Dynamic-bin contribution is included in the existing per-instance percentage
calculation, but this report format does not list dynamic-bin counts. This is
a bounded #448 qualification, not full §19 support; Windows CI and batch T2
remain pending.

### October 17, 2026 — coupled parent/child class constraints (#418)

IEEE 1800-2017/2023 §18.4 requires variables and constraints reached through a
`rand` class handle to be solved with the containing object, without changing
the handle. Section 18.5.2 requires inherited constraints and virtual
`randomize()` to honor the actual dynamic object type. Uniform selection over
legal combinations is specified by 2017 §18.5.10 and 2023 §18.5.9; §18.6.3
requires random variables to retain their old values when randomization fails.
The paired regression qualifies a finite direct parent/child class-handle
domain, inherited constraints through base-typed handles, failed-solve value
and `randc` rollback, and the boundary where a non-`rand` child remains fixed.
T0 and graph-selected T1 passed on Slurm job 2188; exact scope and logs are in
the [qualification evidence](../../../evidence/issue418-parent-child-class-joint-20261017/README.md).
Clause 18 remains PARTIAL: arbitrary handle graphs and broader container and
ordering combinations are not claimed by this bounded test.

### October 15, 2026 — §19.3 covergroup `ref` arguments

IEEE 1800-2017/2023 §19.3 says each covergroup `ref` argument tracks a
different actual as it changes, `input` arguments keep the constructor-time
value, and `ref` formals are read-only like `const ref`. IEEE 1800-2017/2023
§13.5.2 excludes nets and selects into nets from ref actuals. This is a
PARTIAL implementation: whole direct static packed integral variables are
supported; automatic and aggregate-member actuals are outside the qualified
subset and receive implementation-limit diagnostics. Read-only `ref` formals
are checked in both editions. IEEE
1800-2017 §19.3 leaves automatic actual behavior undefined, while 2023
automatic-lifetime behavior is not qualified here. Paired regressions cover
independent live bindings, X/Z and signed samples, input snapshots, type
equivalence, read-only rejection, net rejection, and both implementation
limits. The paired 2017/2023 `ref` regressions passed in the Oct 18 covergroup
T1 run on Slurm job 2588 (250/250 legacy and 237/237 JSON selected cases; see
the [candidate evidence](../../../evidence/issue448-constructor-options-20261018/candidate-green/job-2588/)).
Per-instance option expressions and other §19 behavior were still open on the
date of this record; see the Oct 18 §19.7 entry above. This §19.3 subset alone
did not close issue #448.

### October 14, 2026 — §8.20 method override specifiers

IEEE 1800-2017 §8.20 covers virtual method overrides but does not include the
2023 `:extends`, `:initial`, or `:final` method specifiers. The paired
`sv_method_override_specifiers_2017` fixture expects a compile error in strict
`-g2017`, while the 2023 fixtures exercise the new forms. Slurm job 931 passed
T0/T1 on `6a66355530fbb87fe6999f3b60db1f326660ca9b`: 15/15 legacy and 13/13
JSON/VVP focus cases, alongside the smoke set. Batch T2 remains pending; this
records the edition boundary, not full §8.20 qualification.

### October 14, 2026 — class-constructor default arguments

IEEE 1800-2023 §8.17 defines the constructor `default` formal, the matching
`super.new(default)` chain, and `extends Base(default)`. The 2017 §8.17 does
not define these `default` forms. Focused tests cover inherited implicit and
explicit constructors, automatic and explicit forwarding, inherited
directions and default values, specialized base-class argument types, 2017
rejection, duplicate inherited formals, a missing subclass formal, forbidden
explicit `super.new` with an `extends` argument, and local-member references
in a superclass argument default. Full class-constructor qualification remains
open. See [issue #454](https://github.com/dsellerbrock/iverilog-uvm/issues/454).

### October 9, 2026 — symbolic packed-array-of-struct constraint select

IEEE 1800-2017/2023 §§7.4.1 and 11.5.1 define packed-array elements and
expression-addressed packed selects; §18.3 demonstrates selected packed bits
in class constraints and requires a solution when one exists. The local copies
have materially equivalent wording for these rules. A bounded class-constraint
case now solves a symbolic index into a one-dimensional packed array of packed
structs, then constrains an unindexed packed member of the selected element.
Paired focused legacy tests pass 2/2 and JSON/VVP tests pass 4/4 in both
ordinary and strict-expression-width modes. Index 2 of a `[1:0]` array retains
the four-state invalid-read failure. Other nested packed-select shapes and
broad §18 qualification remain open. See the [focused evidence](../../../evidence/ieee-packed-symbolic-nested-select-20261009/README.md)
and [issue #421](https://github.com/dsellerbrock/iverilog-uvm/issues/421).

### October 8, 2026 — Chapter 7 array locators and associative min/max

IEEE 1800-2017/2023 §7.12.1 permits locator methods on unpacked arrays;
§10.9.1 covers assignment-pattern index and type keys. The current candidate
adds multidimensional fixed-array locator rows, preserves aggregate value-copy
semantics (and class-handle identity), and carries locator queue typing through
wrapper expressions. Associative `min`/`max` coverage now includes integer
values with integer or string keys, duplicate extrema, `with` expressions, and
empty arrays. Assignment-pattern regressions cover `(Pick + 1)` and a
user-defined type alias; that behavior was already implemented, so this part
adds qualification tests rather than a code fix.

The permanent 16-case focused suite passes in both legacy and JSON/VVP runners
on the local macOS build with `-g2012`; equivalent temporary lists also pass
16/16 in each runner under `-g2017` and `-g2023`. Exact-head CI is pending.
Remaining boundaries include broader associative locator support and untested
associative min/max value/key categories. See issues
[#422](https://github.com/dsellerbrock/iverilog-uvm/issues/422) through
[#426](https://github.com/dsellerbrock/iverilog-uvm/issues/426).

### October 8, 2026 — two-state packed-select read results

IEEE 1800-2017/2023 §11.5.1 requires invalid bit-selects of two-state packed
values to return 0 and four-state values to return X. A partially out-of-range
part-select returns X in missing positions; §6.11.2 converts X/Z to zero when
the result is assigned to a two-state destination. The paired reducer checks
constant and dynamic invalid bit indices, partial indexed selects in both
directions, a non-indexed partial select, fully out-of-range assignment, and
four-state/in-range controls. On the local macOS build, strict 2017/2023 direct
runs pass; focused legacy passes 3/3 and JSON/VVP passes 6/6. The implementation
is pending exact-head CI and is not yet qualified. See [issue #469](https://github.com/dsellerbrock/iverilog-uvm/issues/469).

### October 7, 2026 — unequal fixed-length sequence `intersect`

IEEE 1800-2017 §16.9.6 defines an `intersect` match only when both operands
match over the same interval. Unequal fixed-length operands therefore form a
legal sequence with no matches. The default NFA engine now preserves that
empty language through direct covers and implication antecedents/consequents;
the regression also checks equal-length `intersect` and unequal-length `and`.
Strict legacy passes 1/1, strict 2017/2023 JSON/VVP passes 2/2, and the SVA NFA
dual-run passes 64/64. The explicit legacy-engine opt-out still reports its
unsupported-shape diagnostic. Variable/ranged mismatches and broader nested
combinator trees remain unqualified. These are local results, not CI
qualification. See the [focused record](../../../evidence/sva-intersect-unequal-lengths-20261007/README.md).

### October 7, 2026 — nested implication with multi-cycle antecedents

IEEE 1800-2017 §16.12.7 starts the consequent at the endpoint of each
antecedent match, or at the following tick for nonoverlapped implication.
Nested implication lowering now concatenates the outer and nested antecedents
at that boundary, preserving multi-cycle matches. The paired runtime case
covers both outer overlap modes and both inner implication operators. Strict
2017/2023 NFA/VVP runtime checks pass 1/1 each. Other property-expression
consequents remain partial; see the [focused record](../../../evidence/sva-nested-multicycle-implication-20261007/README.md).

### October 7, 2026 — sequence combinator trees on both implication operands

IEEE 1800-2017 §§16.9.5–16.9.7 define sequence `or`, `and`, and `intersect`
combinators; A.2.10 permits a sequence expression on each side of an
implication. The parser and NFA handoff now retain grouped combinator trees on
both sides. The focused oracle checks parenthesized `or` trees for both `|->`
and `|=>`, with passing and failing branches. Strict legacy passes 1/1 and
strict 2017/2023 JSON/VVP passes 2/2. `and`/`intersect` runtime combinations
and broader sequence shapes remain unqualified; general property-expression
consequents remain open under G12. See the
[focused record](../../../evidence/sva-tree-implication-both-sides-20261007/README.md).

### October 7, 2026 — procedural `$past` Preponed sampling

IEEE 1800-2017 §§16.5.1 and 16.9.3 require static signal samples to use the
Preponed value. The procedural sampler now captures supported static operands
through the existing Preponed-read helper, so a same-edge Active blocking
writer cannot change `$past` history based on process order. The paired
writer-first reducer covers inferred-edge, explicit-event, and default-clocking
routes. Together with an automatic-local current-value control and existing
procedural sampled-value cases, the focus passes 5/5 legacy rows and 10/10
strict JSON/VVP checks across 2017 and 2023; the totals include expected
compile-error checks for unsupported clocking-input operands. Only simple
direct automatic-local forms are qualified; unsupported shapes diagnose or
fail elaboration. See the [DD-104 qualification record](../../../evidence/procedural-past-preponed-20261007/README.md).
Clause 16 remains partial.

### October 7, 2026 — nested unpacked-struct constraint leaves

IEEE 1800-2017/2023 §18.4 requires random members of a `rand` unpacked
structure to participate in the containing randomization. Finite nested member
paths rooted at a randomized class property now reach scalar integral and enum
leaves through the existing runtime state-path representation. The paired
regression verifies nested `rand` and `randc` qualifiers, enum membership,
state-derived values, failed-solve rollback, and a later successful solve.
Strict 2017/2023 JSON/VVP and legacy focus lists pass 2/2 each; adjacent class
and struct controls pass 14/14 JSON/VVP and 15/15 legacy. Indexed outer
records, array or aggregate-valued leaves, and class-handle members remain
outside this subset. See the
[qualification record](../../../evidence/nested-unpacked-struct-constraint-20261007/README.md).

### October 7, 2026 — `disable iff` on multi-boundary SVA chains

IEEE 1800-2017/2023 §16.13.1 permits multiclocked sequence chains, while
§16.15 defines the asynchronous `disable iff` abort. The N-domain lowering now
accepts an explicit disable condition for its supported fixed boolean-chain
subset: every clock domain gates new work, and a reset edge clears in-flight
handoffs and queued verdicts across the chain. Strict paired JSON/VVP and
legacy focus runs pass 22/22 each. The regression checks an inter-clock reset
pulse, a reset held across a source edge, and a later attempt after release.
Clause 16 remains partial; this does not qualify broader variable-length or
branching N-domain sequences. See the
[qualification evidence](../../../evidence/sva-disable-multiclock-chain-20261007/README.md).

### October 7, 2026 — associative `find_last_index()`

IEEE 1800-2017/2023 §7.12.1 requires the last matching associative key in key
ordering, returned with the declared key type. The implementation traverses
from `last()` through predecessor keys and returns the first predicate match;
empty and no-match inputs produce typed empty queues. Paired strict JSON/VVP
and legacy checks pass 8/8 each, covering signed integral and string keys,
existing locator neighbors, and wildcard-index rejection. Other associative
locator methods remain open. See the
[qualification record](../../../evidence/assoc-find-last-index-20261007/README.md).

### October 7, 2026 — associative `find_first_index()`

IEEE 1800-2017/2023 §7.12.1 requires associative index locators to return
the declared key type, and defines first/last using the associative key
ordering. `find_first_index()` now walks actual keys and returns one first
matching key, with a correctly typed empty queue for empty/no-match inputs.
Paired strict JSON/VVP and legacy checks pass 6/6 each, including signed
integral and string keys, `find_index` neighbors, and wildcard-index rejection.
Other associative locator methods remain open. See the
[qualification record](../../../evidence/assoc-find-first-index-20261007/README.md).

### October 7, 2026 — 2023 `dist default :/` item

IEEE 1800-2023 §18.5.3 adds `default :/ expression` as one weighted bucket
covering values outside every explicitly listed item. The implementation keeps
overlapping explicit bins separate and excludes all listed values from the
default complement, including zero-weight bins. Strict 2017 rejects the new
syntax. Paired focused JSON/VVP and legacy runs pass 5/5 each; adjacent exact
distribution lists pass 14/14 each. This closes the tested 2023 item, not all
of §18.5 or clause 18. See the [qualification record](../../../evidence/dist-default-2023-20261007/README.md).

### October 6, 2026 — uniform legal tuples with soft constraints

IEEE 1800-2017 §18.5.10 and 1800-2023 §18.5.9 uniformity now includes
satisfiable explicit soft preferences in
dependency discovery for eligible direct scalar and bounded dynamic-array
components. A soft-only
relation between two `rand bit` variables produced the three legal tuples at
`945,1012,1043/3000` under paired strict 2017 and 2023 runs; the prior
fallback was biased at `948,916,1136/3000`. A fixed-size two-element dynamic
array with a soft-only relation now produces `1004,1009,987/3000`, versus
`718,751,1531/3000` before the array eligibility repair. Broader
soft coverage now includes a `foreach` preference over a fixed two-element
array: its five preferred tuples produce `594,590,592,612,612/3000`; the
pre-fix image produced `476,513,543,508,960`. Container/member, ordered, and
weighted-`dist` combinations beyond these tested shapes remain unqualified.
See the
[regression evidence](../../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#soft-foreach-over-fixed-array-elements-fix-15).

Dynamic arrays have a separate implicit size-before-`foreach` ordering
(2017 §18.5.8.1; 2023 §18.5.7.1). A soft iterative constraint paired with two
size-correlated `mode` solutions now verifies this staged distribution:
`380,393,390,371,1466/3000` in both editions. The size-one mode is selected
half the time, followed by its soft-forced single payload value. See the
[paired evidence](../../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#soft-foreach-with-variable-dynamic-array-size-preserves-implicit-ordering-fix-16).

### September 27, 2026 — implication before distribution

IEEE 1800-2017 §§18.5.4 and 18.5.6 allow an unbraced implication whose
consequent is a weighted distribution. The local parser candidate now keeps
`guard -> subject dist {...};` as a guarded distribution, rather than applying
`dist` to the Boolean result of `guard -> subject`. Nested unbraced hard and soft
implications recurse onto the same distribution consequent. The saved AES-shaped
21-line reducer was RED in strict 2017 and 2023 and is GREEN with the
candidate. The [paired fixture](../../../ivtest/ivltests/sv_constraint_implication_dist.v)
checks inactive/active guards, conflicting hard values, both weight forms,
ordinary and braced implications, direct and nested soft preferences,
rollback, and chained hard-distribution implication association. A paired
compile-error fixture rejects an empty `dist {}` list; scratch checks cover
plain, direct, nested, direct-soft, and nested-soft forms in both editions.
The seven-case build-tree JSON focus passes 7/7. Bison's per-state conflict signature matches HEAD.
Parenthesized Boolean implication subjects remain a top-down dist-subject
diagnostic.
A single saved AES core compile clears the original parser error but stops on
four separate implicit-cast errors in `aes_wake_up_vseq.sv`; broad regression,
installation, and DV qualification remain pending.

### September 24, 2026 — nested packed-select assertion sampling

Concurrent assertion operands must be sampled in the Preponed region. A
paired 2017/2023 RED showed that nested constant selections of packed-struct
members were sampled live, producing false assertion results. The local
elaboration fix reconstructs constant nested selects and retains their type
metadata. [Paired focus and the dynamic-index boundary](../../../evidence/caliptra-packed-struct-preponed-20260924/README.md)
record the narrow result; the final installed Caliptra top emits zero of its
former 32 sampling warnings but still fails strict compilation on 46 mixed
drivers. Dynamic nested-index sampling and full assertion qualification remain
open. This is a PARTIAL Preponed-sampling improvement, not an L0 pass.

### September 24, 2026 — disjoint virtual-interface property writers

Strict variable-driver legality is PARTIAL for ordinary VIF members. The
pre-VIF-fix real-DPI UVM gate failed 356/358 because `vif_smoke` and
`vif_smoke_v2` reported a false `count` continuous/procedural overlap at line
96 in both strict and unsafe modes. Their procedural VIF write targets
`reset`, while the DUT output drives disjoint ordinary `PWire` member
`count`; paired 2017/2023 temporary REDs reproduce the error. The installed narrow `elaborate.cc` repair resolves the concrete
receiver/member for direct property writes. Same-member overlap, uncertain receiver, modport alias,
and same-member or uncertain port/ref aliases still require rejection; no broader unsafe waiver or complete conformance claim follows. A separate paired 2017/2023 review shows known-disjoint `write_ref(vif.reset)` with continuous `bus.count` remains falsely rejected in both modes, while direct `vif.reset` compiles and same-member `ref` correctly rejects. The unresolved `ref` actual loses `property_idx`; this [paired follow-on debt](../../../evidence/caliptra-vif-disjoint-property-writer-20260924/ref_member_identity_result.json) is outside the selected VIF repair and does not block Caliptra L0. The [failing real-DPI UVM gate](../../../evidence/caliptra-final-real-dpi-uvm-20260924.log)
is the application baseline. The shared installed elaborate.cc candidate passes [20/20 paired dedicated cases](../../../evidence/caliptra-vif-disjoint-property-writer-20260924/shared_new_focus.log) and [16/16 neighboring controls](../../../evidence/caliptra-vif-disjoint-property-writer-20260924/shared_neighbor_focus.log); both real-DPI VIF smokes privately compiled/ran with `PASS counter_test` and zero UVM error/fatal. The installed iverilog/ivl/vvp SHA-256 prefixes are 1590b064/ba1dda3d/e9b7a64a. The [full shared real-DPI UVM gate](../../../evidence/caliptra-vif-final-real-dpi-uvm-20260924.log) now passes 358/358 with zero failures/skips and both VIF smokes passing. The [fresh VIF-install L0 first case](../../../evidence/caliptra-icarus-l0-unsafe-vif-first-20260924/README.md) still fails nonstandard compatibility 0/1 on 17,863 diagnostics. The first broad legacy gate had one expected-warning gold mismatch; focused retest passes, but its rerun was intentionally stopped after a separate P1 unsafe virtual-dispatch called-task false waiver was found. Full JSON and PR qualification are on hold; the 358/358 UVM result proves no full clause conformance.

The [2026-09-29 focused interface-driver candidate](../session_logs/2026-09-29_ot_unsafe_interface_driver_alias_guard.json) retains strict §6.5 compile rejection in both editions. Under the explicit nonstandard unsafe flag, an ordinary runtime-selected VIF write compiles only when its property maps directly to the physical member; an actual alias then fails with an exact VVP diagnostic, while a disjoint receiver preserves both values. A statically resolved port write, named modport alias, or generated virtual clocking-output overlap remains a compile error. The historical full JSON result and application DV status are unchanged.

### September 24, 2026 — unsafe virtual-dispatch task reachability

Strict variable-driver rejection remains required by §§6.5 and 10.3.2. The
nonstandard `-gcommercial-unsafe` exception is sound only when task-body
writes are proven unreachable for a concrete interface instance. The [16-case paired 2017/2023 RED](../../../evidence/caliptra-interface-driver-reducer-20260923/virtual_override_reachability_result.json) found a called task reached through a concrete base
handle to virtual `Derived.go`; unsafe compilation accepts its overlap with a
continuous value-0 drive, and VVP drives value 1. This P1 called-case false
waiver is the selected blocker. The permitted implementation scope is
`elaborate.cc` plus dedicated paired tests/evidence, with called, genuinely
unused, uncertain-dispatch, and strict controls. A [private P1 candidate](../../../evidence/caliptra-unsafe-virtual-dispatch-20260924/README.md) passes 28/28 dedicated and 34/34 neighboring checks; shared installation and broad gates remain pending. Existing VIF direct-property focus and real-DPI UVM pass, but broad qualification and publication are on hold; no IEEE or Caliptra L0 pass follows from the unsafe run.

### September 24, 2026 — PIC dependent packed partial drivers

Continuous assignment to disjoint nested packed selections remains PARTIAL.
The [paired 2017/2023 PIC RED and controls](../../../evidence/caliptra-post-aes-runtime-fatal-triage-20260923/pic_priority_tree_reducer.sv)
show a known-zero 32-leaf priority tree producing `selected_priority=zzzz`,
while independent disjoint drivers and whole-array controls pass. The
selected root cause is a PV partial-driver blend into `NetConcat` in
`cprop.cc` despite a VP read of the destination, forming a self-cycle. The
expected result is known zero. The integrated narrow cprop.cc candidate
passes [paired focus 4/4](../../../evidence/caliptra-pic-integrated-focus-20260924.log),
and its [initial unsafe pinned compile](../../../evidence/caliptra-icarus-l0-unsafe-pic-first-20260924/summary.json)
crashed exit 139 on a null `Nexus::first_nlink()` in the new traversal. An
integrated cprop null guard now compiles the exact top to VVP. The
[completed first case](../../../evidence/caliptra-icarus-l0-unsafe-pic-nullguard-first-20260924/smoke_test_veer/result.json)
is nonstandard compatibility 0/1 with 51 unrun: firmware/simulation exit 0
and a pass marker appear after 633 retired instructions, but 17,863 bad
diagnostics violate the zero-error gate. The former terminal 43.865 us fatal
is absent. The prerequisite [real-DPI UVM gate](../../../evidence/caliptra-vif-final-real-dpi-uvm-20260924.log) now passes 358/358 after the separate VIF repair; PIC source work remains suspended while the selected P1 unsafe-dispatch breach blocks broad legacy/JSON qualification and remaining error-root triage. The RED and focus establish no L0 pass.

### September 23, 2026 — time-zero propagation and coupled distribution follow-on

The local PARTIAL §§4.5/4.9.1 scheduler candidate executes only the original
compiled initialization events before StartOfSim; fanout they generate joins
the time-zero active slot with procedural startup. This lets a packed-field
conditional tri-state feedback cone settle after its mode assignment instead
of starving that assignment. The faithful paired reducer, callback order,
initial delivery, and a true zero-time oscillator have focused evidence in
the [CSRNG scheduler record](../../../evidence/opentitan-csrng-timezero-scheduler-20260923/result.json).
The selected released CSRNG smoke advances to UVM but fails on a separate
joint-distribution restriction. Full scheduling and CSRNG DV remain open.
The paired [guarded-`dist` reducer](../../../evidence/opentitan-csrng-cfg-joint-dist-20260923/README.md)
originally showed that legal §18.5.7 conditional hard distributions in nested
joint randomization were rejected by the exact joint sampler. A later local
candidate proves hard-pinned or constant guards active or inactive before
sampling, with 22/22 paired focused weighted and rollback checks in each
legacy and JSON harness. Random guards whose truth
varies across feasible solutions still produce a focused error; the released
CSRNG UVM smoke reaches that boundary and fails. Sections 18.5.4 and 18.5.7
therefore remain PARTIAL, and the candidate is not broad qualification.

The local PARTIAL §§18.5.4/18.6.3 solver candidate projects a direct unsigned
coupled distribution subject over a bounded integral range and samples active
items by their declared weights, then uniformly samples feasible values of
the chosen item. Infeasible items are excluded only after a hard SAT proof;
sparse fallback enumerates the same selected item. [Focused evidence and the
remaining released SPI profile](../../../evidence/opentitan-spi-pass-large-dist-profile-20260923/followup.md)
bound this subset. The released flash sequence still stalls in a separate
wide-scalar feasible-domain enumeration before its distribution call; full
randomization and SPI DV remain open.

### September 23, 2026 — SPI queue concatenation, constraint membership, and mixed VIF waits

The PARTIAL §10.10/§7.10.4 subset now accepts a one-dimensional fixed-array
operand in a queue array concatenation, preserving declared order and a fresh
destination snapshot. The separate PARTIAL §11.4.13 constraint path
expands constant unpacked-array `inside` members for the tested SPI Device
form. At the preceding checkpoint the unchanged pinned SPI Device fileset compiles
under `-g2017 -gcommercial-unsafe` without the earlier kind-26 diagnostics,
while its configured flash-mode smoke fails at the JEDEC global-sampling
enumeration ceiling. The later [paired solver follow-up](../session_logs/2026-09-23_opentitan_spi_csrng_next.json)
advances past that ceiling but reaches a separate large-range exact-`dist`
failure. Compile exit 0 does not establish complete constraint or coverage
semantics.

The PARTIAL §§9.4.2/25.9 mixed virtual-interface event-list subset now arms
each selected member with its own posedge, negedge, or value-change mode and
cancels sibling registrations on the first wake. This clears the observed
AON timer `@(negedge cfg.aon_clk_rst_vif.rst_n or cfg.aon_intr_vif.pins)`
stall. One unchanged pinned AON smoke passes; the earlier bounded timeout
remains historical, and full AON DV is unqualified. The [revision-scoped
record](../session_logs/2026-09-23_opentitan_spi_aon_postfix.json) owns exact
paired totals, release provenance, replay logs, and remaining boundaries.

### September 23, 2026 — package `foreach`, queue size, and direct fill casts

The [paired candidate and local gates](../session_logs/2026-09-23_spi_adc_pr339_repair_focus.json)
cover lexical package-parameter array iteration in a class method under
§18.5.8.1, parenthesis-free `.size` on a packed-struct queue under §7.10.2.1,
and a direct typed cast of an unbased fill in constraint IR under §§5.7.1 and
6.24.1. Missing/nonarray targets, genuine missing struct members, and sized
one-bit casts retain their distinct behavior. Four-state X/Z constraint casts
and fills beyond the 64-bit IR remain explicit unsupported boundaries. These
are bounded PARTIAL subsets; OpenTitan SPI Device and ADC DV are not qualified.

### September 23, 2026 — nested outer resize and sparse-key constraint foreach

The [paired local candidate](../session_logs/2026-09-23_parallel_compiler_followon_focus.json)
preserves retained inner array values when a `rand` nested dynamic array's
outer dimension changes (§§7.5, 18.4). Indexed inner `.size` constraints remain
unsupported, so OpenTitan ADC DV is still blocked. For §18.5.8.1, a constraint
`foreach` over a caller-owned hierarchical associative array now visits its
actual unsigned integral keys up to 64 bits; the pinned-shaped SPI Device
reducer checks sparse keys, emptiness, contradiction, and invalid source.
Broader associative-array constraints and SPI Device DV remain open.

### September 23, 2026 — force/release callback statement identity

For §38.36.1, the [paired local candidate](../session_logs/2026-09-23_parallel_compiler_followon_focus.json)
reports typed force/release statement handles to callbacks, preserving distinct
source statements and one identity across a concatenated LHS. The earlier
variable bit-select registration boundary remains intact. Full statement-handle
API and VPI qualification remain open.

### September 23, 2026 — case selector cleanup on early body exit

For §§9.4, 12.5, and 12.8, a case selector is removed from VVP's evaluation
stack before its body can `break`, `continue`, `return`, or `disable` an
enclosing control flow. The [focused paired-edition record](../session_logs/2026-09-23_pwrmgr_case_exit_stack_balance.json)
covers plain, priority, unique/unique0, nested, and real-selector paths with
default/no-match boundaries. The released pwrmgr replay is a scoped application
check; the rest of clause 12 and full OpenTitan DV remain unqualified.

### September 23, 2026 — cast delimiters inside macro actual arguments

For §22.5.1, the [focused candidate](../session_logs/2026-09-23_opentitan_adc_macro_arg_focus.json)
keeps a cast's `(` or assignment-pattern `{` visible to the existing
macro-actual nesting scanner instead of swallowing it with the apostrophe.
Paired 2017/2023 runtime regressions cover nested arguments, commas, strings,
comments, ordinary unbased literals, and a malformed-call rejection. The
pinned OpenTitan ADC source list now compiles, but an ignored constraint and
another cast-width defect keep ADC DV unqualified. This is a bounded clause-22
subset. A separate matched-bracket correction follows.

### September 23, 2026 — matched delimiters inside macro actual arguments

For §22.5.1, the [integrated focus record](../session_logs/2026-09-23_vpi_macro_integrated_focus.json)
covers paired positive, negative, and boundary runs for `()`, `[]`, and `{}`
macro-actual nesting. The scanner now rejects mismatched closing delimiters;
strings, comments, and casted unbased literals retain their tested behavior.
This remains a bounded preprocessing subset, not full clause-22 qualification.

### September 23, 2026 — force/release VPI callback registration

For §38.36.1, legacy variable bit-select handles now reject `cbForce` and
`cbRelease` registration while tested whole-variable, part-select, and net-bit
handles retain their behavior. The [integrated VPI record](../session_logs/2026-09-23_vpi_macro_integrated_focus.json)
is paired across editions. The later statement-object candidate above is a
separate bounded refinement; this does not qualify all VPI callback behavior.

### September 23, 2026 — late module default clocking for assertions

Under §§14.12 and 16.14.6, a module default clocking declared after a
concurrent assertion supplies that assertion's clock in the tested subset.
The [revision-scoped candidate](../session_logs/2026-09-23_caliptra_late_default_clocking_focus.json)
executes direct, forward-named, generated, and `first_match` checks in both
selected editions and both engines, with the NFA path engaged; procedural enclosing-event inference retains its
own clock. No-default, invalid-reference, inactive-generate, and cross-module
boundaries are preserved. This is a focused clause-14/16 refinement within
PARTIAL support, not full SVA or Caliptra DV qualification.

### September 23, 2026 — selected-bit property NBA and target error accounting

The [revision-scoped candidate record](../session_logs/2026-09-23_opentitan_nba_codegen_focus.json)
adds paired 2017/2023 execution evidence for dynamic selected-bit NBA on a
packed class or virtual-interface property under §10.4.2: the receiver,
selector, and four-state RHS are captured at execution, and the selected bit
updates in the NBA region. A separate target-codegen repair makes unsupported
task-body forms fail compilation. This is a bounded simulation/codegen subset;
other property NBA forms and application DV remain open.

### September 23, 2026 — nonstandard `-gcommercial-unsafe` extension

IEEE 1800-2017 §7.6 array element type equivalence remains the strict default.
The explicit `-gcommercial-unsafe` option permits same-width, same-signedness
packed `bit`/`logic` value conversion for whole queue/dynamic-array assignments
and native task/function value copies. This is an implementation compatibility
extension, not IEEE behavior or a VCS-equivalence claim. The [revision-scoped
evidence](../session_logs/2026-09-23_commercial_unsafe_flag.json) records
focused checks only: no full suite ran on the flag revision. The OpenTitan SPI
compile still has five unsupported nonblocking property assignment codegen
errors with the flag, and no OpenTitan DV pass is claimed.

The same explicit flag also permits a separate Caliptra interface-driver
compatibility exception: only a concrete interface member whose conflicting
task-body writes are proven unreachable for that instance may pass. Strict
§§6.5 and 10.3.2 still reject the continuous/procedural overlap. Existing direct-called, exported, uncertain, and non-task writer controls reject; active writable same-member or uncertain `ref` actuals through direct or class-held virtual interfaces are rejected. An independent P1 RED shows a called task reached through a concrete-base virtual override is falsely waived in unsafe mode, so called-case rejection is not yet sound.
The [paired strict/unsafe controls](../../../evidence/caliptra-interface-driver-reducer-20260923/README.md)
and [integrated PIC strict pinned replay](../../../evidence/caliptra-icarus-l0-strict-pic-nullguard-20260924/summary.json)
bound the exception; pre-PIC installed driver and port/ref focus pass 34/34
and 28/28 respectively in each legacy and JSON harness. Strict compilation
still exits 46 on 46 overlaps, with 0/52 L0 runtimes attempted. Unsafe
compilation is nonstandard compatibility, not IEEE conformance or an L0
runtime pass. The [pre-PIC exact unsafe first-case replay](../../../evidence/caliptra-icarus-l0-unsafe-final-first-20260924/smoke_test_veer/result.json)
was nonstandard compatibility 0/1 with 51 unrun, 621 instruction-trace
entries, original assertion actions, and no pass marker. The pre-PIC full legacy
gate passes 6,551 total with zero unexpected failures; bundled VPI, negative,
and VVP invariant suites also pass. Pre-PIC JSON passes 3480/3480; the pre-PIC real-DPI
UVM gate loaded DPI but failed 356/358 on two VIF smoke `count` mixed-driver
compile diagnostics. These broad gates preceded PIC integration. The initial PIC unsafe compile
crash is fixed and the [completed first case](../../../evidence/caliptra-icarus-l0-unsafe-pic-nullguard-first-20260924/summary.json)
fails nonstandard compatibility 0/1 on 17,863 bad diagnostics despite firmware
and simulation exit 0 and one pass marker; no L0 pass is claimed. The narrow elaborate.cc disjoint-property repair passes [paired focus 20/20](../../../evidence/caliptra-vif-disjoint-property-writer-20260924/shared_new_focus.log), [neighbors 16/16](../../../evidence/caliptra-vif-disjoint-property-writer-20260924/shared_neighbor_focus.log), and [real-DPI UVM 358/358](../../../evidence/caliptra-vif-final-real-dpi-uvm-20260924.log). The [fresh VIF-install first case](../../../evidence/caliptra-icarus-l0-unsafe-vif-first-20260924/README.md) also fails 0/1 on 17,863 diagnostics. The first broad legacy gate failed one expected-warning gold mismatch, and its corrected focused retest passes; the broad rerun was intentionally stopped after the selected P1 unsafe virtual-dispatch defect. Full JSON and PR qualification are on hold.

Governing milestone: **M14B — exhaustive subclause campaign.** The table below
is the retained M14 simulation-led snapshot. It is useful evidence, but it is
**not** a full-compliance certificate. Former `FULL` rows are labeled
`PROVISIONAL (probed subset)` until M14B replaces them with the multidimensional
matrix described below.
IEEE 1800-2017 and IEEE 1800-2023 are both first-class selected editions; this
file is the 2017 baseline, while `../ieee1800_2023_delta.md` records shared and
changed 2023 rules. A result in one edition is never silently promoted to the
other.

Every disposition here is **empirical** — established by compiling and running
representative constructs against the installed simulator, not from
documentation or memory (manifesto principle 1/3). The original audit checked
computed values on representative constructs. It did not exhaust every
subclause or separately prove synthesis, SVA, UVM/DPI, diagnostic and bounded-
termination behavior. OpenTitan has since demonstrated why those dimensions
cannot be inferred from a small simulation probe.

## M14B replacement gate

Each subclause/grammar-production row will have separate evidence cells for:

| Dimension | Required evidence |
|---|---|
| Parse | legal forms accepted; illegal forms rejected at the right boundary |
| Elaborate | names, hierarchy, parameters and overload/specialization choices resolve correctly |
| Contextual type | width, sign, 2/4-state, enum and aggregate identity preserved in every legal context |
| Simulation | computed values and object/container effects match an explicit oracle |
| Scheduling | region, lifetime, race boundary and end-of-simulation traces match the standard |
| Synthesis | legal synthesizable forms lower without process fallback, crash or semantic debt |
| SVA | grammar, attempts, sampling, scheduling, actions and assertion VPI are verified |
| UVM/class runtime | class, constraint, coverage and reusable-library behavior executes, not merely compiles |
| DPI/VPI | ABI, directions, lifetime, concurrency, re-entry and data round trips are verified |
| Diagnostics | unsupported/illegal forms fail loudly and locally; no compile-progress stub or dropped construct |
| Termination | permanent probes and frozen corpora finish within a declared resource bound |
| Differential | pinned Slang and sv-tests results are recorded; disagreements are resolved against the selected IEEE 1800-2017 or IEEE 1800-2023 text |

`FULL` in the replacement matrix means every applicable cell has permanent
positive, negative, semantic and interaction evidence. `UNKNOWN` is not a pass,
and parser acceptance cannot stand in for lowering or runtime behavior. Slang
is used for parsing/elaboration/static-semantics comparison; it is not treated
as a simulator or as the definition of the standard.

Unmodified UVM, OpenTitan, and Caliptra are application evidence gates. VCS,
Questa, and Xcelium are the practical commercial-simulator interoperability
targets after the selected IEEE text; Verilator is diagnostic only. The
frontend, scheduler, SVA, and IR should remain suitable for a later formal
engine, but this matrix claims no proof engine. UPF/IEEE 1801 remains deferred
until the IEEE 1800 language and verification surfaces are substantially
closed.

## Legend

| Code | Meaning |
|------|---------|
| **PROVISIONAL (probed subset)** | The legacy M14 probe passed its sampled simulation constructs; complete subclause, context, diagnostic, and interaction coverage is not established. |
| **SUBSTANTIAL** | Broad executable evidence exists, with material recorded residuals. |
| **PARTIAL** | Core behaviour correct; specific sub-features are recorded corners (listed). |
| **DIAGNOSED** | Not implemented, but rejected with an explicit, loud diagnostic (error/sorry/one-time warning). No silent miscompile. |
| **N/A** | Clause is informative/organizational or not applicable to a simulation tool. |

Manifesto principle 4 forbids **silent** miscompiles: every unsupported
construct must be a loud diagnostic, a correct implementation, or a
deliberately-specified safe lowering. The dated M14 audit found six silent
gaps; those six were closed (four fixed, two converted to loud diagnostics),
but that historical result is not a current zero-silent-gap certificate — see
**§ M14 gap closures** below.

## Matrix

| Clause | Title | Disposition | Evidence / notes |
|--------|-------|-------------|------------------|
| 1 | Overview | N/A | Informative. |
| 2 | Normative references | N/A | Informative. |
| 3 | Design & verification building blocks | PROVISIONAL (probed subset) | modules, programs, interfaces, packages, checkers(diag), primitives, compilation unit ($unit) all parse and elaborate; SystemVerilog package/class-only and empty compilation units elaborate without a module root; see clauses 23–29. |
| 4 | Scheduling semantics | PROVISIONAL (probed subset) | Full stratified queue: Preponed, Active, Inactive, NBA, the post-NBA `cbNBASynch` point, Observed, the Reactive set (Reactive / Re-Inactive / Re-NBA), Pre-Postponed and Postponed, drained in 4.4.2 order with per-event region tags. Concurrent assertions sample Preponed, evaluate in Observed and run their actions in Reactive; program processes and their `#0`/NBA use the reactive set; `$finish` drains the remaining regions of its own slot. Whole-property and constant packed-field class/VIF NBAs use NBA or Re-NBA according to their executing process; field updates merge at event execution rather than applying an Active-region snapshot (M4C-8). Region trace and a reverse-insertion region self-test are built in (`IVL_REGION_TRACE`, `IVL_REGION_SELFTEST`), and a Postponed-region write is diagnosed. Evidence: m6_sched_litmus_test, m6_reactive_region_test, m6b_nba_sync (VPI), sv_nba_property_reactive, sv_assert_observed_region, sv_assert_reactive_action, sv_assert_reactive_drain. |
| 5 | Lexical conventions | PROVISIONAL (probed subset) | sized/based/underscored literals, including an underscore between the base specifier and first digit, real/time literals, unbased-unsized `'0/'1/'x/'z`, string escapes, `` `__FILE__ ``/`` `__LINE__ ``. The leading-underscore based-literal form is required by 5.7.1 and used by Caliptra; Slang 11 currently rejects it, so the permanent differential labels that oracle disagreement explicitly. **Fixed in M4B-27:** a string literal converts in assignment context to a one-dimensional signed 2-state unpacked byte array, left aligned in declared index order with null padding or right truncation; invalid element/rank targets are diagnosed instead of reaching a malformed scalar l-value. |
| 6 | Data types | PARTIAL | logic/bit/reg/byte/shortint/int/longint/integer/time, real/shortreal/realtime, chandle, string(+methods), event, enum(+methods), typedef, void, signed/unsigned casts, and builtin net types are supported in the evidenced subsets. **6.6.7/6.6.8 user-defined nettype/interconnect subset:** direct, alias, package/import, and parameter-instance-local nettype declarations preserve canonical identity and underlying integral/real/fixed-aggregate types. Ordinary SystemVerilog resolution functions with one matching dynamic-array input execute for one or multiple logic, bit, and real drivers; malformed resolver VVP metadata is rejected before symbol binding. No-resolver UDNTs enforce one whole-net driver, every UDNT rejects partial member/bit/part drives, and generic interconnects propagate scalar plus declared packed/unpacked shape across supported net-only port edges. Invalid underlying types, resolver signatures, variable/value references, unresolved components, and mixed UDNT components fail loudly. Class-method resolvers and selected/generic operands in interconnect concatenations remain explicit unsupported boundaries, so this is not a FULL claim. **Fixed 2026-08-14:** the 6.20.2.1 symbolic unbounded value `$` is preserved through integral value parameters, direct aliases, and ordered/named overrides; numeric uses, selects, nonintegral types, and value ranges are errors, and `$isunbounded` observes the marker exactly. **Fixed in M4B-17:** an explicit full-width select of an enum now has packed-vector l-value typing while an unselected enum still enforces 6.19.3 compatibility. **Fixed subset in M4C-17:** declaration-level `static`/`automatic` overrides control direct vec4 NBA-target and intra-assignment-control legality even when the containing function has the opposite lifetime; an automatic class/VIF handle does not make the persistent property it selects automatic. Dynamically sized array elements and aggregate-wrapped handle roots remain open. **Fixed 2026-08-14:** supported `type()` operands participate in compile-time `case` matching with ordinary first-match/default/quality behavior, and a `specparam` used in a general elaboration-time constant expression is an error instead of being frozen with a warning; annotation-eligible specparam expressions remain legal. **Fixed/verified 2026-08-27 subset (6.16, Table 6-9, 11.4.12.2):** concatenations in a string assignment context retain string literals and string expressions, including string-returning methods and parentheses-free static functions, preserve folded string identity and explicit integral-to-string casts, and reject a true string expression mixed with an uncast integral expression even beneath a conditional or whole string cast. Nested run-time literal replication remains string-typed through direct targets, whole string casts, and comparisons; string replication into an integral target is rejected; and zero/nonzero repeats evaluate their operand exactly once, with zero producing the empty string. Review hardening removes the arbitrary one-megabyte runtime cutoff, passes a legal 1,048,576-byte variable repeat, preserves multiplier signedness into VVP, and diagnoses negative, X/Z, or index-width-overflow counts. Built-in methods on data objects and constant string parameters carry their exact declared result types, accept a nested-concatenation receiver, reject a scalar selected-byte receiver, and enforce arity before lowering; constant methods preserve semantic empty, nonprinting, backslash, and quote bytes. Generic class templates defer concat legality only for a formal/local/property whose parse-form type parameter is still unresolved, then check each concrete specialization. Final validation passes 23/23 focused legacy, 24/24 focused JSON/VVP, 2,083/2,083 full legacy, 1,161 full JSON/VVP entries with 0 failures, 136/136 negatives, 103/103 VPI, 6/6 textual VVP compatibility, and 354/354 real-DPI UVM. Direct `string[index]` concatenation and the `br_gh800` literal-only mixed group are separately labeled compatibility extensions, not general integral acceptance or IEEE behavior. Bounded residuals include a wrong method value for a fixed-size unpacked signal-array string element, pre-existing acceptance of `s.compare(65)`, `{8'h41} == s`, and non-static `C::f`, plus rejection of a parentheses-free static call in a constant `localparam` concatenation. Corner: `$typename` returns the canonical base representation (e.g. `int`→`logic`), dropping ranges — a diagnosed-by-behaviour introspection limitation, not a value miscompile. |
| 7 | Aggregate data types | PARTIAL | Core forms of packed/unpacked aggregates, dynamic arrays, queues, associative arrays, assignment patterns, locator/reduction/ordering methods, streaming, `$cast`, and bitstream casts are supported in the evidenced subsets below. **Fixed in M14:** module-static integer-keyed assoc value read (was a silent value-loss). **Fixed in M4B-16:** parentheses-free associative-array `size`/`num` now report the live entry count and agree with `size()`/`num()`. **Fixed subset in M4B-21:** an in-range constant partial prefix of a fixed multidimensional unpacked array is a subarray in the supported procedural-copy and continuous-assignment contexts, with declared-direction mapping, strict type/shape equivalence, original-net sensitivity, and per-word driver accounting. **Fixed/verified subset in M4B-22:** queue concatenation assignment builds a complete temporary value before changing the destination, including self/slice operands and bounded-tail evaluation; a clean 923-test sv-tests replay changed exactly the three affected queue cases from semantic failure to verified runtime. **Fixed/verified 2026-08-15:** queue and dynamic-array elements captured by task `ref` formals retain element identity through insert/delete/pop, bounded-tail removal, ordering, whole-container replacement, and dynamic-array deletion. A removed element becomes an outdated private cell for the lifetime of every outstanding alias, across integral, real, string, and object element types. This element-ref binding currently requires a direct signal receiver; nested or class-property container elements and side-effecting object-aggregate capture remain open. **Fixed/verified subset in M4B-23:** direct-context `find_last`/`find_last_index` results contain exactly one last matching value/index or a concretely typed empty queue for queues, dynamic arrays, and direct-signal zero-minimum one-dimensional integral fixed arrays; supported fixed-array first/last respects declared direction, incompatible result contexts are errors, and a missing `with` or malformed iterator argument is diagnosed. At the M4B-23 qualification point, associative locator gaps beyond the supported `find_index` and `find_first_index` paths, nonzero-base/nonintegral direct fixed arrays, multidimensional fixed receivers, aggregate-element value copying, and wrapper result typing remained open or loud. The October 8 candidate (issues #422–#424) addresses the fixed-array shape, aggregate-copy, and wrapper-typing gaps; exact-head CI is pending. **Extended/verified 2026-08-24:** all six locator methods on one-dimensional fixed-array class properties evaluate the receiver once, preserve negative/nonzero declared indices and leftmost/rightmost `find_first*`/`find_last*` behavior, and return fresh queues for integral, real, string, and class-handle elements. General locator traversal/result order remains deliberately unspecified by 7.12.1; multidimensional property receivers remain loud. **Fixed/verified subset in M4B-24:** a terminal unindexed parentheses-free `min`/`max` on a direct integral dynamic-array or queue signal evaluates the method instead of returning the receiver, carries a concrete queue element type into direct assignment compatibility, and preserves the explicit-call result, empty-result, signedness, bound, and source-value semantics checked by permanent runtime tests. At the M4B-24 qualification point, non-integral and associative receivers were still loud, and fixed-array nominal queue typing, iterator/`with` forms, class/property/nested/indexed receivers, and call-result/wrapper contexts remained open. The October 8 candidate adds tested associative `min`/`max` for integral values with integer or string keys, plus wrapper typing for the covered locator forms; other receiver and value-type combinations remain unqualified. **Fixed/verified subset in M4C-24:** structure replication, member/type/default precedence, declared-index keys, and nested replicated unpacked structs with fixed-array members preserve their full aggregate shape through VVP lowering. The permanent positive and eight-site negative tests cover the implemented 10.9 subset; The October 8 regressions additionally cover the constant expression key `(Pick + 1)` and user-defined alias key `value_t`; other expression and type-key forms remain unqualified. **Fixed/verified subset in M4C-25:** constant explicit and indexed range slices of one-dimensional fixed unpacked arrays support blocking/NBA slice-to-slice and slice/whole copies, declared-direction mapping, overlap-safe blocking snapshots, and element-wise equality families. A native 1,027-test replay moved exactly the three Chapter 7 slice cases to runtime-verified. A run-time-variable indexed base, multidimensional range slice, and class/property slice value remain loud residuals. **Fixed in M1B-7:** result-type analysis for a class method reached through a direct unindexed unpacked-struct member follows that member instead of inventing an object result. **Fixed 2026-08-14:** wildcard associative dimensions preserve one wildcard-index type for `[*]`, `[* ]`, `[ *]`, and `[ * ]`. Indexed class-array members remain open. Run-time prefixes, out-of-range source-subarray values, procedural values with more than one residual dimension, class/property partial-prefix sources, and fixed-prefix sources assigned to class/aggregate-member destinations remain loud. Other corners: string/real-VALUED integer-keyed assoc (`string s[int]`) — narrow; `%p` on integral aggregates renders empty (has a stderr warning); member access on an element of an unpacked array of packed struct, and whole-array pattern assignment into such a class property, are fixed (were a crash and a silent zero-fill); **Fixed/verified 2026-08-23:** bounded scalar and fixed-property queue receiver `push_front`, `push_back`, and `insert` mutators preserve the declared maximum; class-property unpacked arrays of `real`/`string` still store every element to one slot (issue #100). |
| 8 | Classes | PARTIAL | new/ctor/this/super, single inheritance, virtual & pure-virtual dispatch, abstract classes, static members, parameterized `#(T)`, typedef fwd-ref, protected/local, `$cast`, and chained `C#(T)::m()` are supported in recorded subsets. **Fixed/verified 2026-09-01 subset (8.19):** non-static instance-constant assignment sites are authorized only in the corresponding constructor. Path-sensitive constructor-flow auditing plus a per-object runtime guard enforce at most one executed assignment across the recorded conditional, return, loop, and detached-fork paths; static constants remain declaration-initialized. **Interface classes / `implements` (2026-08-13):** interface classes form a separate multiple-inheritance graph, retain specialization identity, inherit type declarations only across interface `extends`, enforce pure-method signatures and concrete completion, and participate in assignment, virtual dispatch and `$cast` at run time. The complete related 28-case pinned sv-tests cluster and eight positive/negative dual-harness reducers cover direct/multiple/diamond relations, typedef access, conflicts, partial virtual implementations, illegal members/relations/qualifiers, missing/nonvirtual methods, specialization casts and required generic-class actuals. **Class declaration context (2026-08-14):** nested class declarations retain and restore the complete enclosing-class stack across deeper nesting; out-of-block constructor/function/task bodies are accepted in module scope as well as package/compilation-unit scope, while bodies outside the class's exact declaration scope are rejected without disturbing the caller scope; and each pure virtual method in a non-virtual class is rejected at declaration time. Dual-harness reducers and the corresponding pinned sv-tests cases cover all three boundaries. **Fixed 2026-08-14:** `static const` property order is accepted alongside `const static`; duplicate qualifiers and combined `local protected` are exact errors. An IEEE typedef named `bool` shadows the Icarus extension keyword throughout its visible class/type context, including extern prototypes and out-of-class bodies, without changing the extension when no typedef is visible. **Fixed 2026-08-23:** package-qualified calls through a class's nested typedef (`pkg::class::type_id::method(...)`) work in expression and discarded-return statement contexts, retain explicit class specialization, and preserve independent static storage; reduced arity failures remain loud. **Fixed 2026-08-24:** a derived class can use an inherited, concretely bound superclass type parameter as the root of nested typedef/static calls (`DRIVER_T::type_id::set_inst_override(...)`) in statement and expression contexts; reduced arity failures remain loud and OpenTitan factory overrides are no longer compiled away. **Fixed 2026-08-24 (8.25):** a class type actual that is itself value-parameterized retains the nested actual value in specialization-cache identity, including through dependent superclass substitution. The dual-harness `sv_param_class_dependent_super_value_identity` reducer pins successful width-10 inherited casts and rejected width-11 casts after eager default specialization, and pins positional/named/aliased symbolic `$` as one identity distinct from an ordinary same-width all-X value. Specialization identity uses variant-tagged effective constants: exact IEEE-754 bits for real values (including `-0.0` and the accepted `0.0/0.0` NaN form), complete post-conversion width/sign/four-state storage plus the symbolic-unbounded marker for integral values, and raw string storage. Diagnostic-free integral probing propagates a declared packed formal's assignment width and each arithmetic expression's common signedness through the supported nested unary/binary subset before arithmetic, resolves one constant packed parameter select, and applies four-state-to-two-state coercion for `bit` formals. The dual-harness `sv_param_class_dependent_super_real_identity` reducer pins the formerly colliding `1.0 + 1e-7` / `1.0 + 2e-7` values, integral division/overflow/unary/mixed-sign conversion, packed-formal carry and signed overflow across binary/unary/nested arithmetic, `-0.0`, NaN, a packed select, dependent `N + 1`, and logic/bit/string controls. For unpacked structs, the evidenced semantic subset is fully literal positional patterns and already-evaluated equivalent parameters; declared conversions are reapplied recursively through nested unpacked structs, fixed arrays, and string leaves. Omitted defaults, direct patterns, named/positional class actuals, and a package localparam unify in the reducer. Keyed, replicated, union, or unresolved identifier-bearing aggregate patterns retain scope-sensitive source identity and are not claimed as effective-value canonicalization. Cache-key probes remain diagnostic-free; `sv_param_class_cache_probe_diagnostic_fail` pins one ordinary diagnostic for each invalid real, string, and unpacked-struct actual. Unpacked-array value formals remain outside the parser-supported class-parameter forms. **Fixed in M14:** width-1 (`bit`/`logic`) class-property `$display` (was garbage; value was always correct). Corner: shallow-copy inline static initializer `C b = new a;` at module scope works as `C b; b = new a;`, and in automatic/class scope.  **U08 validated subset (both editions8.13/8.18/8.10/23.8.1):** inherited unqualified methods precede enclosing package homonyms; receiver/task/virtual and visibility controls are pinned by six dual-edition entries. General no-homonym and explicit-qualified local-method access remains DD029; class coverage stays PARTIAL. |
| 9 | Processes | SUBSTANTIAL | initial/always/always_comb/ff/latch, final, fork/join(/any/none), disable, disable fork, wait fork, static/automatic, `process::self`/`kill`/`await`, and `suspend`/`resume` with real `status()` states (M6B-1). A named begin/end shares the enclosing process identity; fork branches do not (9.3.1). Completed ordinary zero-time activations are reclaimed immediately instead of accumulating until Active-region quiescence; only callback-bearing threads and frames on a live recursive function/final execution chain are retained, with the latter unpinned on unwind or left to their already-queued owning delete after non-local disable. This also removes a double reap and post-reap comparison exposed by immediate reclamation. **Fixed in M1B-6:** lazily elaborating a separately declared task/function from a caller's fork no longer makes its ordinary `return` lexically part of that fork; a `return` actually written in a fork remains an exact-gold compile error. **Fixed in M4B-28:** the IEEE prefix parallel-block label form parses with matching-label and `disable` semantics, and conditional event-expression guards are evaluated per triggering leaf with re-wait, four-state nonmatch, event-or independence, cancellation isolation from unrelated detached children, and nonblocking intra-assignment snapshot preservation. (Verified 2026-08-14.) **Fixed/verified process self-kill unwind:** when `process::kill()` terminates the current logical process from a nested synchronous function, the default iterative call trampoline recognizes frames already reaped and unlinked by `do_disable()` and unwinds them without a second `do_join`; `sv_process_kill_join_reducer` is exact mainline-red coverage and `uvm_process_guard_join_test` pins the Accellera guard shape. **Synthesis boundary verified 2026-08-16:** one-bit asynchronous set/reset predicates written as logical equality or inequality against constant 0/1, in either operand order, are recognized when their truth polarity matches the corresponding `posedge`/`negedge` event. Unsized integer constants are handled without mistaking a mismatched polarity, nonconstant comparison, signed-one widening, or other comparator for a simple asynchronous control. **Fixed/verified 2026-08-24:** an implicit combinational process in a child remains asynchronous and synthesizable when its input formal is connected to a parent packed part-select or packed-struct field. Asynchronous classification keeps the elaborated event probe nexus instead of inferring dependency provenance from neighboring select topology; exact selected `always_comb` simulation sensitivity is independently observed by `sv_always_comb_precise_select_sens`. See the [Caliptra selected-input synthesis log](../session_logs/2026-08-24_caliptra_selected_input_async_synthesis.md). |
| 10 | Assignment statements | PARTIAL | Blocking/nonblocking, continuous assignment, assignment patterns, compound (`+=` etc.), `++`/`--`, and the listed aggregate-assignment subsets are supported. **Fixed/verified 2026-08-15 (10.3.3):** scalar and vector net declaration delays now use inertial rescheduling/cancellation, with rise/fall/turn-off selection and Table 28-9 minimum-delay transitions to X. A pure vector net delay schedules bits independently; a delayed declaration assignment or standalone continuous assignment schedules the vector value as one unit. One-/two-/three-delay forms, parameterized widths, drive-strength ordering, and invalid delay expressions have permanent positive/negative coverage. **M4C-24** expands structure replication and preserves member/type/default and declared-index assignment-pattern keys through contextual elaboration; its VVP path stores nested fixed-array members inside replicated unpacked-struct values without collapsing an array dimension. M4C-8 schedules whole vec4 class/VIF properties and constant packed fields with receiver/RHS capture and event-time field RMW; program-process forms use Re-NBA. M4C-17 preserves these and ordinary persistent-signal NBAs when scheduled by a procedurally called SystemVerilog function instead of rewriting them as blocking; direct automatic vec4 targets remain exact errors, explicit-static locals remain legal, and NBA-bearing functions are not constant functions. Dynamic/indexed/event-controlled property forms are loud rather than silently blocking. Full-width enum bit/part-select targets are preserved across both procedural and continuous assignment (M4B-17). Disjoint continuous/procedural terms on a multidimensional packed variable are checked in canonical flattened bit coordinates, while a true overlapping element remains an error (M4B-18). A run-time packed index after an unpacked-array word keeps both the word address and canonical packed offset (M4B-19). Fixed constant-prefix unpacked subarrays support blocking/NBA value copy and continuous l-values with left-to-left direction mapping, synthesis-safe lowering, and order-independent per-word overlap checks (M4B-21). M4B-22 evaluates a queue concatenation into fresh storage before its single destination update, so self-references cannot observe a partially overwritten queue and bounded tails are still evaluated; clean sv-tests runtime evidence pins that subset. Blocking unpacked-array function results also map declared left to declared left; the nonblocking form remains loud pending a per-word NBA snapshot. Residual M4B-20: driver conflict checking still treats packed terms inside one unpacked word as whole-word terms. Run-time unpacked-subarray prefixes and broader procedural residual shapes remain loud. Function-NBA call-context enforcement, dynamically sized array targets, and captured-handle aggregates remain residual M4C-17 work. Corner: net `alias` (syntax error). |
| 11 | Operators & expressions | PARTIAL | all arithmetic incl `**`, bitwise/logical/comparison/shift, `inside` (values AND ranges), `==?`/`!=?`, `?:` (incl 4-state), concat/replication, streaming, casts, string ops. **Fixed/verified in M4C-28:** ordinary and strength-aware VVP concatenations wait for one delivery from every connected input port before first publication, including all-Z and partial-vector deliveries; parsed input count, not bit coverage or four stored width slots, defines readiness. **Fixed immediate-blocking subset in M4C-18:** streaming targets retain fixed and dynamic-array/queue/string members, including nested class properties, and apply the 11.4.14.4 greedy rule. A streaming operand followed by `with [array_range_expression]` supports index, range, `+:`, and `-:` over any supported one-dimensional fixed/dynamic array or queue. Receiver and range operands evaluate once in standard order immediately before their field; fixed/dynamic selection, resizing, ascending/descending declared bounds, mixed ranged/greedy fields, fixed variable OOB clipping, bounded queues, 2-state coercion, and X/Z range diagnostics are value-pinned. Constant fixed OOB, nonintegral ranges, and an unconstrained field before a ranged field are exact errors. Flattened vectors and object-backed target element counts have separate runtime caps, every source/target range plan has a bounded per-operation element count, rejected target operations preserve the prior value, and fixed target index translation is O(N) overall. Delayed/event-controlled and NBA run-time-sized targets remain explicit compile-time residuals pending scheduled receiver/range/source/target snapshots; they do not fall through to blocking execution. **Fixed subset in M4C-23:** a concatenation expression can be followed directly by a bit, descending constant part, or indexed `+:`/`-:` select with self-determined packed-vector coordinates; other non-identifier primary shapes remain open. Full-width enum selects retain their unsigned packed-vector expression type instead of the enum's named type (M4B-17); exact computed enum elements after an unpacked word retain their declared type (M4B-19). A constant fixed-unpacked prefix is consumable as a subarray value only in M4B-21's supported assignment contexts; there is not yet a general aggregate expression node for run-time/property/deeper-residual forms. **Fixed in IEEE-PACKED-MULTIDIM-SELECT-OOB (#414; paired strict 2017/2023):** runtime bit-select chains in multidimensional packed values now retain each dimension’s bounds check before flattening the canonical offset; four-state OOB or X/Z indices return X instead of aliasing another slice, valid edge indices keep their declared mapping, non-integral indices are diagnosed, and a side-effecting index is evaluated once. Permanent reducers: `sv_packed_multidim_dynamic_select_bounds` and `sv_packed_multidim_real_index_fail`. **Residual (DD-112):** an out-of-bounds select of a two-state packed value still yields X rather than the §11.5.1-required 0, including the one-dimensional direct-select path; this is independent of the multidimensional alias fix. **Verified 2026-09-29 (§11.8.2):** a signed 8-bit input actual widens with sign extension while an unsigned actual zero-extends; paired strict 2017/2023 controls and adjacent legacy tests pass at compiler commit 0db31d850. Clause status remains PARTIAL. |
| 12 | Procedural programming statements | PARTIAL | if/else, `case`/`casex`/`casez`, `unique`/`unique0`/`priority` **case and if**, for/foreach/while/do-while/repeat/forever, and break/continue/return are supported in evidenced subsets. Qualified-if chains preserve if-expression truth, priority short-circuiting, unique all-condition evaluation, first-match execution, final-else suppression, and the required no-match/multiple-match warnings. **Fixed in M14/M4C-19:** `case (x) inside` performs range membership and accepts the full 12.5.4 comma-mixed open-value-range item grammar (values, wildcard values, bounded/unbounded ranges); malformed items recover without a compiler crash, and an ordinary case range is rejected rather than silently never matching. Corners: `if (x matches p)` and `case matches` tag binding (syntax errors / diagnosed). **Fixed/verified 2026-08-27 (12.7, 12.7.1, Syntax 12-5):** a `for_initialization` now accepts several comma-separated `for_variable_declaration`s, each with its own `data_type` and its own same-type declarator continuations, covering typedef-led, package-qualified, class-scoped, specialized-class-scoped, packed-dimensioned, and `var type(expr)` types, and declarator names lexed as TYPE_IDENTIFIER. The implicit block opens before the data type is parsed so inline anonymous enums register their literals in it, and declarators are installed before the condition and step are lexed. Control variables are automatic even in a static subroutine; a statement label names the implicit block for `%m` and `disable`. See the 2026-08-27 section below for the measured boundaries. |
| 13 | Tasks and functions | PARTIAL | Tasks/functions, automatic/static lifetime, ref/const-ref/input/output/inout, default and named arguments, void functions, `void'()`, class/struct/array returns, and recursion are supported across the listed tested forms. A `localparam` interspersed in an old-style task/function body is retained as a declaration rather than misparsed as an executable statement; the Caliptra untyped form is runtime-pinned and ordinary untyped-function controls remain green. **Fixed in M1B-6:** every task/function definition-body elaboration starts in its own lexical fork context, including lazy parameterized-class specialization reached from a forked caller; `sv_fork_lazy_param_typedef_return` pins both function and task bodies while `task_return_fail2` preserves the illegal lexical-fork boundary. **Fixed in M1B-7:** `void'(...)` can discard scalar or object method results reached through a direct unpacked-struct class-handle member with the actual return type and no object-fallback warning; void-casting a task remains an error. **Fixed 2026-08-15 (13.4.4):** function bodies accept the expressly permitted `fork...join_none`, while `fork...join` and `fork...join_any` are rejected across nested/named scopes and class methods; the corresponding task forms remain legal. **Fixed subset in M4C-17:** a procedurally called SystemVerilog function can schedule an NBA to a persistent ordinary signal or supported class/VIF packed target without suspending or applying an immediate store; declaration-level static/automatic lifetime is enforced for direct vec4 locals, and such a function is rejected in a constant expression. **Fixed in #433 (13.4.4):** runtime guards reject deferred side effects inside functions (nonblocking assignments, nonblocking event triggers, clocking drives, and fork...join_none) when the caller process is not rooted in an initial/always procedure; function calls and forked descendants inherit the caller context. Continuous-assignment, static-initializer, and final contexts error before later statements run; immediate event triggers remain allowed. Source attributes cannot forge the compiler-owned process-context marker, covered by final and initial negative tests `sv_function_deferred_guard_attr_final_fail` and `sv_function_deferred_guard_attr_initial_fail`. Paired 2017/2023 regressions cover final-context rejection and always-root permission. Remaining gaps: program-call and freshly allocated local-object runtime forms, dynamically sized array targets, and automatic aggregates containing captured handles remain open. A blocking unpacked-array function result can target a whole fixed array or fixed-prefix slice and preserves declared-order correspondence across opposite range directions. **Fixed 2026-08-15:** task string `ref` formals use the same bound-reference wrapper as integral, real, and class-handle task formals, including detached fork writes and queue/dynamic-array element cells; whole-container task formals and function string/real formals retain the documented copy path. **Fixed/verified in M4C-29 (6.21/13.3.1 recorded subset):** an otherwise static task or function preserves its static VPI identity and inherited static ports/locals while each call owns storage for explicitly automatic scalar, dynamic-array, and fixed-array declarations, including integral/logic/real/string/object elements and nested named-block overrides. Initializers execute before detached children consume the activation; virtual-interface dispatch, detached-frame retention, array-port context selection, explicit-static fixed-array force/release, and per-declaration VPI lifetime metadata use the declaration's actual context owner. Conversely, explicitly static locals in automatic tasks/functions retain shared one-shot storage. Residuals: the equivalent nonblocking assignment is rejected loudly until aggregate NBA snapshotting exists; indexed struct-member-array method receivers remain open; nested fixed-array assignment patterns accept compatible array-valued function items and reject incompatible result shapes during elaboration (issue #415; paired -g2017/-g2023 regression). |
| 14 | Clocking blocks | PARTIAL | **Fixed/verified 2026-08-24 subset; itemless public-event follow-up 2026-08-25.** Default/explicit/global clocking, `##N`, `#1step` Preponed sampling, numeric-skew sampling, output drives, and direct/class-held virtual interfaces are supported. Every valid clocking block, including one with no clockvars, has a public synchronization event that fires in Observed after NBA quiescence; static, hierarchical, global, default, VIF, and modport-VIF references use it. Its VIF representation is two-state, so initialization cannot manufacture a time-zero event. Numeric `#0`/`#N` samples are stored before both static and VIF `@(cb)` waiters wake. Same-scope, static-instance, alias, and VIF output drives preserve constant packed member/bit/part selection; run-time selectors are captured once for the buffered output and pending mask, and root/nested indexed class receivers are captured once. Current-event and buffered drives share the per-instance apply path and the defining scope's output skew. Output-skew declaration errors remain one diagnostic independent of drive count; exact modport provenance is preserved through additional carriers, and VPI property writes are loud instead of bypassing sampling or drive scheduling. **M7 follow-up (2026-10-18):** paired 2017/2023 probes verify one-dimensional fixed-unpacked variable output clockvars driven by cardinality-matched assignment patterns, constant packed part-select declaration-assignment targets, and a 13-bit output through a non-default parameterized interface; a wrong array-pattern element count is a compile error; unpacked net arrays still require per-word net drivers (`sv_clocking_unpacked_output_storage`, `sv_clocking_selected_decl_assign_target`, `sv_clocking_param_if_width`, `sv_clocking_unpacked_output_bad_pattern_fail`). Multidimensional/dynamic arrays and complex declaration-target expressions remain outside this patch's tested subset. A clockvar concatenation l-value is rejected as illegal under 14.16. Paired 2017/2023 runtime evidence: `sv_clocking_selected_output_dynamic_capture`, `sv_vif_clocking_selected_dynamic_capture`, `sv_clocking_indexed_class_receiver_fail`, and `sv_clocking_root_indexed_class_receiver_fail`. See the [selected-drive](../session_logs/2026-08-24_opentitan_vif_clocking_selected_drive.md), [static-skew/modport](../session_logs/2026-08-24_opentitan_clocking_static_skew_modports.md), and [HMAC frontier](../session_logs/2026-08-24_opentitan_hmac_boolean_dist_subject.md) session logs. |
| 15 | Interprocess synchronization & communication | PARTIAL | Named-event triggers, waits, and `.triggered` have tested static and per-instance subsets; the current [class-event candidate](#september-23-class-event-triggered-state) is focused-tested but not yet merged. Issue #439's explicit `triggered()` call subset has paired 2017/2023 tests in the [candidate evidence](#october-14-explicit-triggered-calls) and [PR #583](https://github.com/dsellerbrock/iverilog-uvm/pull/583), pending integration. Semaphores and mailboxes (including `#(T)`) retain their recorded subsets. Multi-object class-event lists have a focused-tested candidate pending PR/CI. A bounded named-event `wait_order` subset passes T0/T1 in both runners; see [October 15 evidence](#october-15-bounded-wait_order-subset). Event-variable assignment/merging (§15.5.5.1) remains a separate open limitation. |
| 16 | Assertions (SVA) | PARTIAL | Synthesized checkers, automaton (NFA) engine by default with the legacy linear engine behind `IVL_SVA_LEGACY=1` and a dual-run parity gate over both. `|->`/`|=>`, `##N`/`##[m:n]`/`##[m:$]` incl. mid-chain, `[*N]`/`[*m:n]`, goto/non-consecutive repetition, `and`/`or`/`intersect`/`within`/`throughout`, `not`/`first_match`, sequence local variables, `strong`/`weak`, `.triggered`/`.matched`, `expect`, procedural concurrent assertions with implicit clock inference, `disable iff`, sampled-value functions with real histories, named properties, defaults, pass/fail actions, cover, and the clause-40 VPI lifecycle. **Caliptra property-local subset (2026-08-16):** named properties and sequences accept plain formals followed by `int` and unsigned packed/scalar `logic` locals. Match-item assignments apply the declared width/sign conversion before later use, every overlapping attempt owns its complete local value, and multidimensional 256-bit captures survive fixed and unbounded implication paths. Broader assertion-variable types, declaration initializers, directions/defaults on formals, and complete branch flow analysis remain outside this bounded subset. **Single-clock NFA implication fan-out (M9-16):** every endpoint of a variable-length or combinator antecedent owns an independent multi-step/tree consequence record for `|->` and `|=>`; same-tick verdict counts retain one action and success/failure callback per record, while step callbacks remain once per checker per tick. An assignment made exactly once on a deterministic leaf prefix is snapshotted per obligation. Branch-local, post-branch, repeated, duplicate, interior-tree, and fused-`##0`-read assignments remain loud until per-live-path locals and assignment-before-read scheduling are available; empty consequences are also loud. Strong end-of-simulation failure actions and failure callbacks repeat once per live consequence record. Loop-free pools have an exact capacity bound and cyclic forms keep the finite-pool/loud-overflow contract. **Selective assertion control:** labeled and per-instance hierarchical `$assertoff`/`$asserton` stop and resume only new attempts for the selected directive, preserve attempts already executing at Off, and retain VPI identity as `(runtime scope, assertion index)`. Finite `always[m:n]` attempts preserved by Off expire at `n`, while unbounded attempts remain live. `$assertkill` reports disable/reset callbacks and aborts active attempts in the linear, NFA, parameter-bound, generated-delay, temporal, and two-/N-domain multiclock checkers. Per-identity generations survive immediate Kill/On pairs; generation-tagged multiclock handoffs cannot revive killed requests; identifier selectors are resolved in their lexical call context and canonicalized to a rooted per-instance identity, canonical generated selectors match `G[2]`, and final strong obligations are suppressed without requiring another assertion clock. The lexical canonicalization covers bare labels through nested procedural blocks, relative scope/child paths, explicit rooted paths, and chronological controls issued before checker registration; string-valued selectors and package/`local::`/`this`/`super` forms retain their existing exact runtime/source-spelling behavior. Queued deferred-immediate reports and pending procedural assertion instances remain the separate R29 cancellation gap. **Concurrent-assertion region placement is conformant (M6B-4):** whole signals, packed selects, direct packed-aggregate members, unpacked-array words, reals, hierarchical names, and direct members of statically bound interface/modport ports sample Preponed; evaluation runs in Observed and actions in Reactive. Runtime-selected interface-array members and package-qualified mutable operands remain loud live-read boundaries. **Parameter-valued bounds are PARTIAL (M9-15):** the focused instance-sized implication/cover paths preserve exact/range/unbounded repetition and bounded-consequence expressions through instance override, reject invalid values during elaboration, and keep unsupported standalone symbolic ranges loud. **Deferred immediate assertions remain PARTIAL (R29):** `#0` and `final` expressions evaluate synchronously; positional scalar, real, string, dynamic-container, and class-handle `$error`/`$display` arguments are value-captured in module, task, function, and class contexts; reports use process-local Observed/Reactive or Postponed queues with flush/cancellation behavior; deferred cover uses the same queues; module/generate items are implicit `always_comb`; labels preserve hierarchy/`%m`; and assertion control gates new reports. Passive zero-actual user tasks are supported for `final`. Illegal action blocks, malformed bytecode, source-final `#0`, and unsupported user-task/method/ref/fixed-unpacked-array action shapes fail loudly. Remaining gaps include general user-subroutine/ref/fixed-array argument capture, deferred-cover database/VPI accounting, assertion-label/outermost-disable cancellation, `$assertkill`/VPI-reset queue cancellation, deferred-immediate VPI assertion identity/result callbacks, variable-length multiclock antecedents, `disable iff` across variable-length or branching multi-boundary shapes beyond the fixed-chain subset qualified on October 7, and the separately recorded branch-flow/deferred-immediate gaps. |
| 17 | Checkers | PARTIAL | **M9-9.** `checker`/`endchecker` implemented on the module machinery: typed formals with directionless-defaults-to-input (17.4), default formal values, property/sequence declarations, `assert`/`assume`/`cover`, checker-local `default clocking`, internal variables and procedures, multiple independent instances, nested checker instantiation, `endchecker` labels, and `bind` of a checker. Loud residuals: untyped formals, event-typed formals, free (`rand`) variables (17.9), a checker DECLARED inside a module, procedural instantiation. sv_checker_basic, sv_checker_nested_instance, sv_checker_bind. (Verified 2026-07-25.) |
| 18 | Constrained random value generation | PARTIAL | The evidenced core includes rand/randc, class and bounded scope `randomize()` with/without inline `with`, constraint blocks, `inside`, `dist`, implication, if-else constraints, `solve...before`, soft priority, `disable soft`, `unique {}`, object/property variable control, hooks, foreach/container constraints, `randcase`, `randsequence`, and per-object/per-process RNG state. Inherited constraints are solved as one set and conflicting soft constraints follow declaration priority. **M3B-2 (expanded 2026-08-14):** `randsequence` covers acyclic production reuse, weighted alternatives, constant/default/named input actuals, production `if`/`case`/`repeat`, ordered code blocks, bounded `rand join` interleavings, whole-sequence `break`, and production-local `return`; each unsupported broader form fails loudly. **M3B-17 (expanded 2026-08-12):** fixed unpacked-array `rand_mode` accepts declared-direction and multidimensional element/subarray setters and singular indexed queries. Dynamic arrays and queues use live numeric element modes; associative arrays preserve integral, string, and object key identity. Whole-array setters control current and future members, queue membership and ordering changes carry mode state with existing members, associative delete/reinsert creates a fresh active member, failed solves restore modes, and static aliases converge on canonical storage. The IEEE singular-function rule rejects a whole dynamic/queue/associative query; the whole fixed-array query remains a documented Slang-compatible all-enabled extension. Fixed, dynamic, queue, and associative unpacked `randc` elements carry independent transactional histories. The dynamic/queue/associative subset includes unconstrained and constrained feasible-domain cycles, mode pause/resume, queue permutation and membership changes, associative delete/reinsert, failed-solve rollback, canonical static aliases, and class shallow-copy state. **M3B-18 (2026-08-10):** recursive direct/fixed/D/Q/M class-handle graphs use one alias/cycle-safe transaction; descendant failure restores graph values and instance/static cyclic history, and canonical-static tentative values remain invisible to scheduler/VPI observers until final commit. **Fixed 2026-08-14 (evidenced unpacked-struct-member subset), expanded 2026-08-24:** `rand`/`randc` qualifiers on unpacked-struct members survive parse, elaboration, target lowering, and VVP execution. An outer `rand` struct property activates only qualified members, leaves unqualified state unchanged, preserves per-member transactional `randc` cycles, and constrains sparse enum members to their declared domain (including randc cycling over that feasible set). A class constraint may name a one-level scalar integral or enum member up to 64 bits as an independent solver variable; paired 2017/2023 tests also cover finite nested unpacked-struct paths to scalar integral/enum leaves; the `(outer property, member)` identity survives `solve...before`, unqualified or disabled members are pinned state, direct member `rand_mode` setter/query controls activation, enum domains remain declared-literal domains, and model values plus constrained-randc history commit or roll back atomically. Member qualifiers on packed structs/unions and rand real/string members are eager declaration errors even for unused typedefs. A randc integral leaf wider than the 20-bit history cap emits a named warning, including through a nested struct. **Fix #419 slice (2026-10-09):** an active class-handle member reached through a `rand` unpacked struct joins the containing joint solve; object identity, aliased paths, child constraints/callbacks, and failed-solve value/`randc` rollback are locally verified under strict 2017/2023 with paired tests. Dynamic-array members remain fail-closed; other container/member shapes remain unqualified. Issue #419 remains open. **L64 (2026-09-14, paired 2017/2023):** the evidenced function-constraint subset evaluates pure calls with typed per-object results, stages active input/const-ref scalar/member/element/size dependencies, preserves static overlays and atomic rollback, and keeps no-argument body reads as pre-solve state without invented priority. Qualified/virtual calls, selected fixed-array operands, and conditional-member branch validity have permanent positive/negative coverage. Focused250 outcomes and206 permanent cases per harness pass; the seven-gate batch is recorded in `session_logs/2026-09-14_constraint_function_presolve_qualification.json`. Dynamic-foreach per-iteration calls, broader inline wide transport, active returned-member aliases, indexed conditional handles and multi-prefix reductions remain outside this qualified subset. **L65 (2026-09-14, paired editions, focused qualification):** fixed-array constraint reductions now accept multiple constant prefix indices leaving one integral dimension. Every prefix contributes its declared-bound-normalized row stride; sum/product/and/or/xor retain existing with-expression sizing, iterator index, active/state identities and rollback. Permanent8/8 and neighbors6/6 pass in each harness; broad batch qualification remains pending. Runtime-selected prefixes remain outside this change. **Still open:** recursive `randsequence` grammars, nonconstant production-actual capture, value-returning productions, non-input formals, nested-control joined lanes, packed-select randomization semantics beyond the compatibility boundary, general joint parent/child constraint solving beyond the bounded direct rand-handle domain qualified in #418, recursive child-hook dispatch beyond the verified rand-struct handle path, remaining class-handle/container struct-member shapes, indexed outer/aggregate unpacked-struct constraint paths, dynamic/associative member-lifecycle corners beyond the evidenced integral subset, and exact cycle completeness beyond the documented width bound. These prevent a FULL claim. Every thread and class object is seeded hierarchically at creation; `srandom`/`get_randstate()`/`set_randstate()` preserve the deterministic state contract. |
| 19 | Functional coverage | PARTIAL | The evidenced implementation includes value/range/default/ignore/illegal bins, `iff`, compact transitions, fixed and per-instance dynamic-family crosses, constructor and `with function sample` formals, recorded instance/type options and queries, and durable reports. The typed constructor subset preserves source/coverpoint width and sign, four-state rejection, 19.5.7 conversion, descending-range emptiness, and OpenTitan's exact `[0 : 2 << (valid_source_width - 1) - 1]` range. Integral open bins coalesce to distinct resolved values; fixed arrays preserve ordered occurrences, put the remainder in the last nonempty bin, and carve after distribution. Object-specific cross plans cover automatic products and the evidenced `binsof`/named-`binsof` `intersect` conjunctions, overlapping named bins, `iff`, `illegal` > `ignore` > normal precedence, and illegal-cross locality. For 2023, `option.cross_retain_auto_bins` defaults to 1; a covergroup value defaults its crosses, a cross-local value overrides it, and coverpoint/`type_option` placements are errors. Constant values and the 2017 edition rejection are implemented; the retention reducer covers inherited fixed/dynamic defaults, local disable/enable overrides, no-explicit-bin retention, and empty ignore/illegal declaration presence. Verified remaining gaps link to [#448](https://github.com/dsellerbrock/iverilog-uvm/issues/448) (constructor/per-instance coverage expressions), [#457](https://github.com/dsellerbrock/iverilog-uvm/issues/457) (covergroup inheritance), [#481](https://github.com/dsellerbrock/iverilog-uvm/issues/481) (four-state value matching), [#482](https://github.com/dsellerbrock/iverilog-uvm/issues/482) (virtual-interface sampling), [#507](https://github.com/dsellerbrock/iverilog-uvm/issues/507) (reject output/inout formals), [#508](https://github.com/dsellerbrock/iverilog-uvm/issues/508) (cross-bin matches thresholds), [#509](https://github.com/dsellerbrock/iverilog-uvm/issues/509) (wildcard-bin cross-with values), and [#510](https://github.com/dsellerbrock/iverilog-uvm/issues/510) (2023 real-valued coverpoint bins). Recursive cross-with predicates and signed static ranges crossing zero pass the paired clean-main local recheck; this is not CI evidence. Remaining cross residuals are mapped to [#511](https://github.com/dsellerbrock/iverilog-uvm/issues/511) (confirmed CrossQueueType set-expression rejection), [#512](https://github.com/dsellerbrock/iverilog-uvm/issues/512) (reproduced 65,536-bin cutoff; validation-only on whether the LRM permits the resource ceiling), and [#513](https://github.com/dsellerbrock/iverilog-uvm/issues/513) (validation-only merged transition-family cardinality; no wrong result reproduced). Named transition identity, denominator carving, and trailing empty-bin exclusion were checked against paired reducers and a clean-main probe; no current gap was found. IEEE 1800 does not define this implementation's VPI coverage introspection or textual report layout, so those are excluded as tool extensions; standardized bin identity behavior is covered separately. Tolerance range operators are tracked under clause 11 by [#462](https://github.com/dsellerbrock/iverilog-uvm/issues/462). Caliptra hierarchical member cross items remain application compatibility syntax, not standard §19.6 syntax. Complete clause-19 closure is not claimed. |
| 20 | Utility system tasks & functions | PARTIAL | `$clog2/$bits/$size/$dimensions/$left/$right/$low/$high/$increment`, `$isunknown/$onehot/$onehot0/$countones/$countbits`, `$info/$warning/$error/$fatal`, `$time/$realtime/$stime`, math funcs, `$random/$urandom/$urandom_range/$dist_*`. **Fixed 2026-08-14:** `$isunbounded` observes the symbolic 6.20.2.1 parameter value and folds ordinary expressions to false. **Fixed $system result subset (2026-09-25):** paired 2017/2023 reducers return the C system() int status, exercise system(NULL), and allow the legal task form without a false warning. Extra-argument rejection remains DD-062, so no complete 20.18.1 qualification is claimed. The 40.3 code-coverage macros and access routines have exact values, signatures, target/domain validation, and standards-defined `SV_COV_NOCOV`/`SV_COV_ERROR` results. Real code-coverage instrumentation and database load/save remain unavailable and are diagnosed, so the clause is PARTIAL. (`$typename` limitation recorded under clause 6.) |
| 21 | Input/output system tasks & functions | PROVISIONAL (probed subset) | full `$display/$write/$monitor/$strobe` format set (`%b/%h/%d/%o/%s/%c/%e/%f/%g/%t/%p/%m/%v`), file I/O (`$fopen…$fscanf/$sscanf/$fgets/$fread`), `$readmem[hb]`/`$writememh`, `$sformat[f]/$swrite`, `$value$plusargs/$test$plusargs`, `$dumpfile/$dumpvars`. (`%p` on integral aggregates recorded under clause 7.) **Verified in L32 (2026-09-11):** `%u`/`%z` of a string literal or string parameter now emit the same bytes as the equivalent packed vector (21.2.1.2, 5.9); the `swrite` endian probe was corrected accordingly. |
| 22 | Compiler directives | PROVISIONAL (probed subset) | `` `define `` (args), `` `ifdef/`ifndef/`elsif/`else/`endif ``, `` `include/`undef ``, stringize `` `" ``, paste `` `` ``, line-continuation, `` `line/`__FILE__/`__LINE__ ``, `` `timescale/`default_nettype/`begin_keywords/`end_keywords/`pragma/`resetall/`celldefine/`unconnected_drive ``. **Fixed/verified 2026-08-15:** macro replacement collection now respects ordinary-string, macro-quote, escaped-quote, token-paste, escaped-identifier and comment token contexts. A replacement cannot borrow a closing quote from its later expansion context; the malformed definition is rejected and not installed. Formal names inside ordinary strings are not substituted, while macro-quoted formals still are. Expansion depth is capped at 256 and aggregate expansions at 1,000,000, turning direct and mutual recursion into bounded errors. Evidence: sv_macro_definition_context, sv_macro_unterminated_string_fail, and sv_macro_recursion_limit_fail, plus the 22-case legacy and four-case JSON macro focus lists.  **L15 validated aa356ab4d:** function-like macro names finish double-backtick pasting before lookup even when an intermediate prefix names another function-like macro; existing object-like expansion precedence preserved. Both-edition positive/neighbor checks and required integrated gates passed. This is bounded22.5.1 support. |
| 23 | Modules and hierarchy | PROVISIONAL (probed subset) | instantiation (position/name/`.*`/`.name`), param overrides (order/name), `defparam`, ANSI/non-ANSI ports, hierarchical refs, `bind` (**M13**), empty/unconnected ports. **Fixed/verified 2026-08-16:** a bit- or part-selected actual on an output port remains a directional selected connection instead of being collapsed as its underlying whole net and reflected into the child as a false structural driver; nested output wrappers and genuine continuous/procedural overlap have permanent synthesis coverage. **Verified 2026-08-15 (23.3.3.7):** collapsed net ports apply every wire/tri, wand/triand, wor/trior, tri0, tri1, uwire, supply0 and supply1 dominance cell from Table 23-1, including its warning cells. The dominant delay domain and net type propagate through every collapsed alias; tri0/tri1 and supply pulls have one canonical carrier, so chained and order-reversed multi-instance connections cannot erase or duplicate the pull. Noncollapsed expression/variable connections retain their internal declaration delay. **Fixed/verified 2026-08-27 (23.11/Syntax 23-9 bounded subset):** bind paths retain structured absolute, explicit `$root`, and module/generate-relative identity; select one-dimensional generate/module-array elements; resolve conditional type/shape per active owner; and apply deferred directives to a source-order-independent fixed point. Final arrays require selection. Target lists, target-namespace collisions, module/interface/checker/program/primitive legality boundaries, and late `-y` target/path/compilation-unit-directive discovery are paired regressions. Invalid selections and paths fail loudly. Automatic roots are not rebuilt when a live contained bind discovers a compilation-unit bind after root selection; explicit `-s` selects the intended root in that case. See the dated section below for evidence and explicit residuals. `trireg` remains the frontend's pre-existing explicit unsupported net declaration rather than an unhandled matrix cell. Corner: `extern module`. **Verified 2026-09-29 (§23.3.3):** the variable-input BUFZ boundary retains source signedness before port width conversion; paired strict 2017/2023 controls and 23/23 equal named VCD event streams pass at compiler commit 0db31d850. Clause status remains PROVISIONAL. |
| 24 | Programs | PROVISIONAL (probed subset) | program block, ports, initial/final, multiple programs. Corners: anonymous program, `$exit` (diagnosed). |
| 25 | Interfaces | PARTIAL | interface + modport, parameters, arrays, `import`/`export` methods, clocking-in-interface, virtual interfaces in the evidenced Syntax 25-3 declaration contexts, and modport direction enforcement. **25.5 audit follow-up, verified 2026-08-24:** the selected modport view is retained by direct declarations, typedef/array carriers, class properties and inherited properties, defaulted or explicit class type parameters, unpacked-struct members, and compiler-generated clocking accesses. Retaining the source clocking-block name means independently listing its rewritten raw member does not expose an otherwise unexported clocking block. A VPI-backed output argument cannot write a modport input through the read handle; the put is a loud run-time error and leaves the interface unchanged. Continuous assignments depending on bare, constant-indexed, operator, multi/mixed, and type/size/sign-cast interface-member forms lower behaviorally and retrigger; virtual-interface any-change waits on packed signal members are initialized from and then observe the complete vector, and cast traversal fixes Caliptra's explicit interface-member-to-enum conversion (M5-2). Dynamic posedge, negedge, any-change, and compound event waits through initialized virtual interfaces are runtime-pinned. Using a null virtual interface for any of those waits terminates simulation with one process-global fatal diagnostic and a failing status instead of aborting the simulator process. **Fixed/verified 2026-08-16:** implicit `@*`, `always_comb`, and `always_latch` sensitivity follows packed selects and fixed-unpacked interface-member words, including descending nonzero ranges, multiple member dependencies, ordinary-net/member mixtures, and run-time selectors (the latter conservatively watches every member word). Explicit constant unpacked-word posedge/negedge waits carry the canonical word into VVP. **Fixed 2026-08-24:** a repeated parameterized-class specialization-cache hit defers its method bodies through the same post-root worklist as a cache miss, so scalar and associative-array virtual-interface receivers retain selected-instance dispatch and declaration-scoped default/explicit argument rows. **Fixed/verified 2026-08-30 (25.9/Syntax 25-3 bounded subset):** both `virtual iface` and `virtual interface iface` work directly and through typedefs in compilation-unit, package, module, block, declaring-for, unpacked-struct, qualified class-property, and subroutine argument/return contexts. Source provenance survives arrays, concrete type parameters, forward/package typedefs, and lexical `type(expression)`, so virtual-interface ports, interface items, and union members are errors while ordinary interface ports remain legal. `==`/`!=` compare null, equivalent unparameterized VIFs, and same-definition concrete instances in either order, including constant one-dimensional instance-array and same-type conditional forms; VVP uses bound-instance identity and ordinary classes keep pointer identity. Case/wildcard equality, scalars, different interface definitions, and two concrete instances are errors. A run-time-variable select from an unqualified one-dimensional interface-instance array is separately pinned as an intentional compatibility extension, not §25.9 conformance, because 23.6 requires the instance-array select in a hierarchical name to be constant. Remaining boundaries include parameter-specialization and modport-aware comparison identity, nondefault parameterized VIF member widths, hierarchical/multidimensional run-time dispatch, exact expression-result edge semantics for run-time-selected words, virtual-interface handle rebinding while a wait is armed, streaming/`inside`/assignment-pattern dependency shapes not reached by the standard input traversal, and non-signal VIF members. **Fixed in M14:** `$display` of a continuous-assign-driven interface member. |
| 26 | Packages | PROVISIONAL (probed subset) | decl, `import pkg::*`/`import pkg::item`, typedef/param/function/class members, `::` resolution, `std::`, chained refs, ambiguous-import detection. Corners: a wildcard-imported typedef used as a type name; `export pkg::*` re-export (diagnosed). |
| 27 | Generate constructs | PROVISIONAL (probed subset) | generate for (genvar), if/else, case, nested, named blocks + hierarchical access, module/assign/always instantiation, `generate`/`endgenerate`. Invalid or nonterminating constant generate loops preflight their genvar sequence before allocating any generated scope trees, preserving the duplicate-scope and 500001-iteration diagnostics with bounded memory. |
| 28 | Gate- & switch-level modeling | PROVISIONAL (probed subset) | all primitive gates, tristate (`bufif`/`notif`), MOS (`nmos/pmos/cmos` + resistive), `pullup`/`pulldown`, `tran`/`tranif`, drive strengths, gate delays, instance arrays. |
| 29 | User-defined primitives | PROVISIONAL (probed subset) | combinational & sequential (level+edge) UDPs, UDP `initial`, instantiation, table syntax. |
| 30 | Specify blocks | SUBSTANTIAL | **M13.** Module path delays (`=>`/`*>`), edge-sensitive/state-dependent paths, `specparam`, and the recorded `PATHPULSE$` subset are active with `-gspecify`. Pulse controls and exhaustive path-form coverage remain open or diagnosed. |
| 31 | Timing checks | SUBSTANTIAL | The recorded checker subset, including `$setup/$hold/$recovery/$removal/$skew/$period/$width/$setuphold/$recrem/$nochange/$timeskew/$fullskew`, is runtime-verified under `-gspecify`. Exhaustive edge-descriptor, timestamp/timecheck-condition, and interaction coverage remains open. |
| 32 | Backannotation (SDF) | PARTIAL | `$sdf_annotate` applies IOPATH delays with `-gspecify`; inert (loud warning) without it. Corner: only the first two arguments (file, scope) are used (diagnosed via warning). |
| 33 | Configuring the contents of a design | DIAGNOSED | `config`/`endconfig` (+ `design`/`liblist`/`instance`/`cell`) parse and are skipped with an explicit sorry; the design elaborates with default bindings. Library-map files are not parsed (syntax error). |
| 34 | Protected envelopes | PARTIAL | `` `pragma protect `` begin/end and `` `protect ``/`` `endprotect `` around **plaintext** compile and run (the envelope is transparent). Encrypted envelopes are not supported (no decryption). |
| 35 | Direct programming interface (DPI) | SUBSTANTIAL | libffi-exact `import "DPI-C"` task/function marshaling includes integer atoms, scalar bit/logic, scalar shortreal/real, chandle/string, output/inout, packed vectors, and the recorded fixed/open multidimensional arrays. Signed/unsigned byte/short-int and enum-base returns preserve the Annex H ABI; shortreal uses C `float` in every scalar direction/result, and scalar logic preserves 0/1/Z/X. H.8.9 result legality is checked before every import/export target. Export stubs use exact integer/scalar bit-logic/shortreal/real/chandle/string/void C types, packed bit/logic vector formals, and scalar copy directions; every exported task has the H.8.2 `int` C result. Identical cross-scope/multi-instance exports share one stub; duplicate local linkage names, repeated exports of one SV subroutine, and incompatible cross-scope signatures (including packed dimensions/bounds) are rejected. Its §35.9 status is 0 on normal completion and on a disable targeting only that export, and 1 when an ancestor disables the mixed-language call chain. The ancestor path resumes the parked C stack exactly once for cleanup: `svIsDisabledState()` reports 1, a checked imported task acknowledges by returning 1, or an imported function calls `svAckDisabledState()` before return; neither disabled SV tail executes. Protocol mismatches and a §35.9(d) post-disable export call are fatal. Newly compiled tasks use `%dpi/call/task/ack`; legacy `%dpi/call/task` retains its void ABI for normal old images and diagnoses a disabled call. Packed-vector function results remain illegal under H.8.9; output/inout string storage survives automatic-frame teardown. The sized import-array subset follows the commercial direct-pointer ABI used by VCS, Questa, and Xcelium; open formals retain `svOpenArrayHandle`, and those commercial simulators remain the ABI interoperability target rather than Verilator. Time-consuming task bridges use POSIX `<ucontext.h>` or Win32 Fibers. H.9 context imports publish the declaration instance through `svGetScope`, and `svGetNameFromScope` returns its fully qualified name; a paired 2017/2023 reducer covers synchronous functions and coroutine tasks. Open legal gaps are tracked by [#505](https://github.com/dsellerbrock/iverilog-uvm/issues/505) (imported fixed-size/open `shortreal` arrays) and [#506](https://github.com/dsellerbrock/iverilog-uvm/issues/506) (fixed-size unpacked export formals). Exported open arrays and class-handle formals remain correctly diagnosed as IEEE-illegal; the exhaustive signature/runtime cross-product remains M14B-9 qualification work. |
| 36 | Programming language interface (VPI) | SUBSTANTIAL | **M12 CLOSED for the recorded object-model scope.** Typed variables with value-change callbacks, dynamic arrays/queues/assoc with element access, class member navigation, interfaces/modports/packages as scopes, and live covergroup handles are supported. A property-aware handle may read an integral or string virtual-interface property. Its `vpi_put_value` path is deliberately read-only/write-loud: writing reports a run-time error, sets a failing status, and leaves the VIF property unchanged because a direct put would bypass 14.13 sampling, 14.16 clocking-output scheduling, or 25.5 modport direction. Ordinary class-property puts remain supported. The bundled VPI suite and dedicated VIF-write, class-event-lifetime, declaration-lifetime, and array-word-lifetime reducers pass. **Fixed in L32 (2026-09-11, 38.15):** `vpiVectorVal` of a string literal/parameter places the rightmost character in the least-significant byte of word0, never sign-extends high bytes, and initializes only required words (`string_literal_vector` 2017/2023). **U15 (2026-09-11):** a native `$ivl_uvm_record_attribute` systf (compiler-side infrastructure, not an IEEE1800 clause obligation) captures packed/real/string transaction attribute values losslessly for the native recording backend, dispatching on `vpiObjTypeVal` and reusing this literal fix for embedded-NUL string arguments. VPI temporary-string metadata and typed aggregate/enum/object schemas remain unqualified. |
| Annex A | Formal syntax | N/A | Reference grammar. |
| Annex B | Keywords | PROVISIONAL (probed subset) | keyword sets gated by generation (`` `begin_keywords ``). |
| Annex C–L | (packages, tasks, misc annexes) | PARTIAL | `std::` semaphore/mailbox/process supported; `std::mailbox#(T)` via the `std::` prefix is a syntax error (bare `mailbox#(T)` works). |

## 2026-08-26 clauses 7 and 10 associative-pattern refinement

Clauses 7 and 10 remain **PARTIAL**. For the directly evidenced 7.4, 7.9.11,
and 10.9.1 subset, a nonempty associative-array assignment pattern may contain
explicit constant string, integral, or enum keys and at most one `default`.
Keys are converted in the declared index context before duplicate detection;
duplicate keys/defaults, nonconstant or X/Z integral keys, and incompatible
key/value categories are errors. The default is fallback state rather than an
entry. Items evaluate once in lexical order into a fresh typed value, and the
destination changes only after the complete right-hand side exists. Whole
maps and value elements copy independently; class elements retain handle
identity.

Paired positive and negative reducers exercise declaration, procedural,
typed/cast-pattern, argument, return, and conditional contexts plus exact
OpenTitan enum-to-string, enum-to-queue, nested-map, and fixed-prefix forms.
The direct signal-backed fixed-unpacked subset, ending in integral/string/
real-valued associative leaves, preserves nonzero/descending and mixed
multidimensional ranges, independent slots, selected-map methods, and
invalid-outer-index no-op stores with once-only RHS evaluation. Every fixed
dimension is checked before flattening, so multidimensional OOB components
cannot alias valid siblings through whole-map or entry stores, entry reads, or
map methods. Explicit/default real reads, direct stores, sibling isolation,
and constant/variable outer selectors are paired. Packed bit/part/member and
other deeper or partial entry tails, property/member and struct-nested
receivers, fixed queue/dynamic-array leaves, fixed-prefix maps with
class-handle/container/struct values, broader receiver/value contexts, and
exhaustive clause closure remain open or loud.
This checkpoint supersedes only the earlier statement that arbitrary
associative constant-expression keys were wholly unimplemented; it does not
close the separate simple/user-defined type-key or general assignment-pattern
residuals.

## 2026-09-04 hierarchical state foreach (bounded increment)

The new inline class-constraint path covers a selected caller/package owner
whose queue/dynamic-array member holds class handles or unpacked structs,
with integral fields up to 64 bits. It preserves iterator type/scope and guard
errors (IEEE 1800-2017 18.5.8.1/18.5.13; IEEE 1800-2023 18.5.7.1/18.5.12),
including empty queues, null owners, typed ternary indices, and failed-solve
rollback. Independent rand-array foreach templates retain their original
size/element passes. Target-root/selectors requiring additional resolution,
nested hierarchical templates, and broader paths remain diagnosed. Clause 18
remains **PARTIAL**; application counts require the complete census diff.
See the [implementation, boundaries and validation record](../session_logs/2026-09-04_hierarchical_state_foreach.md).

## 2026-08-24 clause-18 signed fixed-array index repair

For the evidenced 18.5.8.2 subset, typed signed constants used to index a
fixed-array class property in a constraint are sign-extended before
declared-to-canonical index mapping. Negative declared indices therefore
retain every solver leaf and agree with `iterator.index()` reduction
semantics. `sv_constraint_fixed_array_reduction` pins the individual leaves
and their weighted reduction result.

## 2026-08-24 clause-18 expression-subject distributions

For the evidenced unguarded IEEE 1800-2017 18.5.4 subset (renumbered 18.5.3
in IEEE 1800-2023), the evidenced HMAC relational `dist` subject is converted
from Z3's Bool representation to its SystemVerilog one-bit integral value
before branch matching. Exact probability-proportional selection now also
applies to the recursively validated active expression subset, not only a bare
random property; the sampled expression value is pinned before ordinary model
diversity chooses the participating properties. Pin comparisons retain the
branch comparison width, while arithmetic subjects retain the wider physical
solver sort needed for carry/product headroom.

The accepted compared-expression subset includes typed terminals, packed bit
selects, constant part selects, ordinary packed concatenations, direct
`$countones(terminal)` and `$countones(~unsigned_terminal)`, terminal
comparisons, and conservatively typed `+`, `-`, and `*` trees. Unsigned
division and signed/unsigned modulus by a constant nonzero terminal are
accepted when the dividend is explicitly bounded to its SystemVerilog result
width. Direct add/multiply, signed subtraction, unsigned division, modulus,
and non-widened unsigned unary bitwise-not remain supported roots. Ground
comparison, ternary, add/subtract/multiply/divide/modulus, power, shift, and
XOR expressions fold at their SystemVerilog result width before shape
validation. Constant repeated concatenation folds when its complete result is
at most 64 bits. A compared bare fill literal and the OpenTitan
`'1 - integral_literal` endpoint shape are materialized at the subject's
comparison width when that width is at most 64 bits. Other context-dependent
unary, ternary, power, shift, and binary-bitwise trees remain loud rather than
being interpreted with an invented context. Signed constant occurrences use
fresh aliases, so Z3 numeral hash-consing cannot leak signedness between equal
raw numerals.

The emitted distribution IR distinguishes `:=` from `:/`, while accepting an
unmarked historical range branch as `:/`. Exact ranges up to 256 members are
sampled item first and feasible member second: `:=` retains
`weight * complete_source_span` after pruning, `:/` retains one aggregate item
weight, and overlapping items contribute additively. Typed and open bounds use
the same IEEE 11.8.1 comparison order for the hard predicate, normalized
coordinate, and exact pin, including signed ranges crossing zero. Each source
weight may be at most `UINT_MAX`; checked aggregate totals may exceed 32 bits
and are accumulated through `uint64_t`. Item selection uses an unbiased
two-word 64-bit rejection ticket, followed by an unbiased member-index draw.
An aggregate-total overflow, over-cap range, wider weight, nonground item, or
mixed comparison order emits a bounded warning and preserves the hard domain
through the documented weighted-soft fallback.

Exact branch coordinates and current-object scalar value storage remain
bounded to 64 bits. A source literal or resolved constant in a dist
subject/item/endpoint/weight with nonzero or unknown bits above bit 63 is a
compile-time error because the textual IR cannot preserve those bits; a wider
value whose high bits are all zero remains representable. A wide ground weight
that fits `uint64_t` evaluates normally, while a result above `uint64_t` warns,
remains nonzero, and saturates only the fallback objective. Guarded class
distributions, scope `std::randomize`, and multiple distributions over one
subject retain their documented approximations.

An exhaustive scan of the pinned OpenTitan source found 714 direct `.sv`
`dist` locations across 253 files. The current subset accepts 579 and leaves
135 loud/unlowered sites: 132 require indexed-member or package/aggregate-array
value lowering, and three Darjeeling alert-handler sites require 77-bit fill
literal/runtime-coordinate storage. The two additional supported `.svh` dist
macro bodies have ten source invocation sites; preprocessor configuration
makes a single corpus-wide elaborated-node total misleading. The 72 indexed
Flash weight expressions occur inside 36 of the already-counted 117 Flash
indexed-subject sites. `sv_constraint_dist_boolean_subject`,
`sv_constraint_dist_wide_literal_fail`, and `run_dist_ir_compat.sh` pin the
implemented boundary.

## 2026-08-24 clause-16 endpoint-local refinement

The M9-16 bounded local-variable subset now permits a deterministic-prefix
assignment RHS to read a local assigned earlier on that prefix. Nonlocal
operands are sampled Preponed, and the local holes are evaluated from the
current antecedent attempt or consequence-obligation record on the assigning
edge. Calls over locals, selected-local objects, self/future/unassigned
dependencies, and unknown expression shapes remain loud. The same conservative
assignment-before-read boundary applies to every zero-inclusive continuation:
`##0`, `##[0:n]`, and `##[0:$]`; lower-bound-one continuations remain
supported. Antecedent endpoint acceptance contributes the once-per-checker/tick
StepSuccess event even for `|=>`, while success/failure callbacks retain their
per-resolved-obligation multiplicity.

## 2026-08-26 clause-35 DPI disable-protocol refinement

| Clause | Boundary | Disposition / evidence |
|---|---|---|
| 35.8, 35.9(a), and H.8.2 | Exported-task C signature and simulator status | Generated task stubs are `int task_name(...)`, not `void`. They return 0 after ordinary completion and after a disable targeting the exported task itself; they return 1 when an ancestor disables the enclosing imported-subroutine chain. `run_dpi_disable_protocol.sh` asserts the generated C source as well as behavior. |
| 35.9(a)–(c) | Foreign cleanup and acknowledgment | A parked imported-task coroutine owns its call-state record across suspension. An ancestor disable resumes that C stack exactly once with `svIsDisabledState() == 1`, allowing cleanup before the task returns 1; a disabled imported function calls `svAckDisabledState()`. Direct-export disable leaves the import normal, and simultaneous normal/disabled stacks retain independent state. The scheduler retains the caller and completed child through resume so C may legally re-enter a synchronous export that disables the caller before the original resume frame unwinds; it also installs that caller as `running_thread` while C executes, preserving caller-specific automatic VPI context. `m10l_dpi_disable_protocol_test` checks all of these paths, including two concurrent resumed-C VPI writes and ancestor cleanup while the caller owns an outstanding branch that survived `join_any`, after outliving the killed SV delays. |
| 35.9(b)–(d) | Mandatory protocol enforcement | `%dpi/call/task/ack` invokes new imported-task C code with the integer ABI and validates 0 for normal or 1 for disabled return. A mismatched task return, a disabled imported function that omits `svAckDisabledState()`, and any further export call after the disabled state begins issue fatal simulation errors. `run_dpi_disable_protocol_negatives.sh` pins the four expected-fatal cases and verifies that no forbidden tail executes. |
| 35.9 and VVP image compatibility | Pre-protocol imported-task bytecode | `%dpi/call/task` remains the legacy void-call opcode rather than being reinterpreted as an integer return. `run_dpi_legacy_task_void_compat.sh` loads a hand-pinned old image and C void function normally, then derives a historical-opcode disabled image from current export metadata and requires the fatal no-ack-channel diagnostic instead of a guessed status. |

This closes the recorded disable-handshake submatrix, not clause 35 as a
whole. Imported shortreal arrays and legal fixed-size unpacked export formals
remain loud gaps, and M14B-9 still owns the exhaustive signature/runtime cross
product. VCS, Questa, and Xcelium remain the practical Annex-H interoperability
oracle after the IEEE text; Verilator was not used as an ABI oracle.

## 2026-08-25 OpenTitan event, Preponed, and packed-index refinement

| Clause | Boundary | Disposition / evidence |
|---|---|---|
| 4.4 and 16 | Preponed reads of resolved strength nets | `%hist/on` retains a full vec8 driven-value snapshot once per time slot and `%load/preponed` reduces that saved value on read. Force overlays remain outside driven history. The exact reducer plus 57/57 legacy and 16/16 JSON/VVP assertion focuses pass. |
| 7.4 and 11.5.2 | Run-time outer packed element index followed by an indexed part select | Every dimension's element index is normalized at width one before the residual packed width is applied as a stride. Singleton `[0:0]`, ascending, and descending outer dimensions with run-time `+:`/`-:` inner bases are permanent legacy and JSON/VVP regressions. |
| 9.4.2 and 9.4.3 | `@(object.property)` and `wait(object.property)` through a selected owner | The armed owner expression is evaluated once; mutation wakeup is filtered by property, fixed-array word, and optional packed bit, with same-value suppression, invalid-selector parking, retained owner lifetime, and cancellation-safe unlinking. Class-only compound waits re-evaluate. **Refined 2026-08-30:** an explicit `or`/comma event list may mix an independently prepared class-property or VIF-member leaf with ordinary signals, named events, run-time-selected event-array elements, and direct/default/global clocking events. Isolated join-any lowering resumes once and cancels every losing registration without killing an unrelated detached child; each leaf elaborates once and a rejected leaf diagnoses once. A single leaf whose expression itself combines VIF and class/ordinary dependencies remains loud. A class-only compound `@` filters scheduled wakeups against an arm-time snapshot, but a complete expression that changes and restores before that waiter runs can still be missed. Root/handle replacement, associative delete/rekey, and key/index mutation while armed remain unclaimed. |
| 13.5.2, 35.5.6.1, and Annex H | Sized fixed unpacked arrays across DPI | Sized formals use the commercial direct C-pointer ABI; open formals use `svOpenArrayHandle`. Scalar `svBit`/`svLogic` and packed `[0:0]` stay distinct, X/Z and output/inout copy back, multidimensional C storage is numeric-low-first/rightmost-fastest, and actual/formal copies map declared left to declared left per dimension. The backward-compatible 24-bit VVP element-width descriptor is tested at 256 and 384 bits. The exact OpenTitan SHA-384 ABI plus eleven controls pass 12/12 REAL DPI. Pure DPI is loaded with `vvp -d`; `-m` remains VPI-only. |

Full mechanism, boundary, OpenTitan replay, and Apple Silicon invocation
evidence are in the [session log](../session_logs/2026-08-25_opentitan_class_events_resolved_preponed_packed_index.md).

## 2026-08-24 clause-18 unpacked-struct constraint-leaf refinement

For the evidenced one-level scalar integral/enum subset, inline target-member
lookup precedes same-named caller state, including
`randomize() with (identifier_list)`. Explicit `this.record.member` and
`super.record.member` paths retain their inherited outer-property identity.
`disable soft record.member` disables only that leaf, while
`disable soft record` covers its descendants. Signed constant folding keeps
the declared width through unary and binary arithmetic before solver
write-back. A fixed- or dynamic-array index on the class receiver in
`items[index].record.member.rand_mode()` is distinct from an indexed outer
record: setter/query select that object exactly once, preserve adjacent-object
mode isolation, and retain Icarus's established disabled-query/setter-no-op
behavior for out-of-range or null receivers. Indexed outer records, deeper paths,
aggregates, and leaves wider than 64 bits remain focused compile-time
diagnostics rather than falling back to an unrelated terminal property name.

## 2026-08-24 clause-16 strong-action target correction

When an unbounded strong assertion needs a copied end-of-simulation action,
the supported task/void-function-call subset now retains package
qualification. `pkg::report(...)` remains that exact target rather than
becoming an unqualified lookup in the synthesized checker scope. The
self-checking package-action reducer is red against the prior compiler, and
the unmodified OpenTitan TL-UL checker loses all four corresponding
unknown-task warnings.

## 2026-08-24 clocking static-skew, modport, and VPI audit refinement

This refinement records the exact supported or loud boundary. For this dated
2026-08-24 refinement, the listed focus, broad, VPI, negative, UVM, OpenTitan,
and Caliptra reruns were completed; they are not the current corpus status.

| Clause | Boundary | Disposition / evidence |
|---|---|---|
| 14.3–14.5 / 14.16.2 | Clocking declarations, input/output skew, declaration-assignment aliases, and synchronous output drives | Static and VIF waiters observe numeric-skew samples only after their stores. Output skew is evaluated in the clocking block's defining scope by the shared apply process. A nonconstant output skew is one declaration error independent of the number of drives. The 2026-10-18 M7 follow-up adds a constant packed part-select declaration target with width-matched storage and bit-preserving writes, including a wire clockvar through a VIF (`sv_clocking_selected_decl_assign_target`, `sv_vif_clocking_selected_decl_assign_target`, 2017/2023). |
| 14.13 | Input sampling and VIF property reads | Packed integral/struct inputs use the sampled property; numeric `#0` and `#N` ordering is pinned. A read-only VPI consumer may fetch the property. Non-vector and unpacked inputs retain the documented loud alias boundary. |
| 14.16 | Clocking-output storage and scheduling | Constant packed member/bit/part selections retain one buffer and per-bit pending mask for same-scope, static-instance, alias, and VIF spellings. Current-event drives kick that instance's apply process. The 2026-10-18 M7 follow-up supports one-dimensional fixed-unpacked variable output arrays driven by a matching assignment pattern and a non-default parameterized-interface output width; a mismatched array-pattern element count is a compile error. Unpacked net arrays remain unsupported pending per-word drivers (issue #674; `sv_clocking_unpacked_net_output_fail`, 2017/2023, compile-error). Run-time selectors and root/nested indexed class receivers remain rejected before ordinary NBA lowering. A concatenation/pattern l-value containing a clockvar remains illegal. |
| 25.5 | Exact modport provenance | The qualifier and source clocking-block name survive direct, typedef/array, class-property/inheritance, class-type-parameter, unpacked-struct, and generated clocking-state carriers. Negative reducers require exact one-per-source visibility diagnostics. |
| 36 with 14.13/14.16/25.5 | VPI-backed system-call argument | Property reads remain supported. Any `vpi_put_value` to a virtual-interface property is a loud run-time error with unchanged state and nonzero status; this includes `$value$plusargs` directed at a sampled input, clocking output, or modport input. |

Historical 2026-08-24 post-audit results: both clocking focuses 36/36; clocking Slang differential
59/59; SystemVerilog manifest 1850/1850; JSON/VVP manifest 918/918; default
legacy manifest 4029 pass / 2 NI / 3 EF / 0 fail; VPI 97/97; negative
diagnostics 111/111; `make check` pass; real-DPI UVM 338/338; fresh
OpenTitan setup + compile 7/7 with six long runtimes advancing to the CPU
guard and ADC retaining its known testbench fatal; and Caliptra Icarus 53/105
versus Slang 54/105 with zero `ICARUS_GAP`.

The ignored local references are
`docs/standards/local/IEEE_Std_1800-2017.pdf` and
`docs/standards/local/IEEE_Std_1800-2023.pdf`; hashes and provenance belong in
the ignored local manifest. They are not part of the repository change. This
file remains the 2017 baseline, paired with the first-class 2023 survey and
tests.

## 2026-08-23 verified fixed-container property subclauses

These rows refine the coarse clause 7 and 8 entries above. They describe the
implemented and runtime-verified boundary; the deliberately loud residuals
mean neither parent clause nor this subset is upgraded to `FULL`.

| Clause | Title | Disposition | Evidence / notes |
|--------|-------|-------------|------------------|
| 7.4 | Fixed-size unpacked arrays above container leaves | PARTIAL | **Fixed/verified subset.** A direct non-static instance-class property may have one or more ascending, descending, nonzero-based or multidimensional fixed unpacked dimensions above a queue or associative-array leaf. The fixed prefix is atomically range-checked and canonicalized separately from trailing container indices, and each slot has independent storage. Whole-outer assignment decomposes in declared order and value-copies every selected container. Undefined, negative-after-canonicalization, wide-unsigned and out-of-range outer indices take the type-appropriate empty/default read path and make writes/mutators warned no-ops rather than aliasing slot zero; this includes scalar integral/bit, real, string, class-handle and unpacked-struct properties plus packed read-modify-write, with every dimension and RHS evaluated once. Direct dynamic-array leaves, signal-backed/static declarations, struct-nested fixed-container properties and whole-outer r-value materialization remain loud. The new 15/15 legacy and 15/15 split focuses, complete 1,792/1,792 and 860/860 manifests, Slang differential, and final OpenTitan blocker replay are recorded in the [session log](../session_logs/2026-08-23_opentitan_fixed_array_container_class_properties.md). |
| 7.8–7.10 | Associative arrays, methods and queues below a fixed property prefix | PARTIAL | **Fixed/verified subset.** A fully selected queue/map leaf supports whole-container value assignment, context-typed element/key reads and writes, queue/associative methods, r-value queue slices, `$` reads/method receivers, and packed element selects. Runtime lowering covers integral, real, string, class-handle, aggregate and nested-container values, preserves bounded inner-queue copy, and avoids duplicate evaluation of the selected queue receiver used for `$` and the fixed outer index. A bare fixed-array RHS is materialized in declared order as the destination queue kind and bound. Associative vivification inserts nil dynamic-array children without manufacturing queues, notifies the outer root on insertion, and preserves root provenance for later child mutation. Arbitrary trailing queue/associative/dynamic-array chains retain recursive receiver typing and value-copy behavior; selected nested dynamic arrays support `delete()`. Whole-outer r-value reads, fixed-property queue-slice l-values, `$` l-values, incomplete fixed prefixes, direct property selection from a function-call result, and packed/compound whole-container assignment remain loud. The final unmodified OpenTitan replay contains zero occurrences of the former array-of-queue rejection and reaches independent later blockers; it is not an OpenTitan pass claim. See the [session log](../session_logs/2026-08-23_opentitan_fixed_array_container_class_properties.md). |
| 8.5 | Object properties containing fixed arrays of queues/maps | PARTIAL | **Fixed/verified subset.** The admitted shape is a direct non-static data property: VVP class storage constructs one independent queue/map object per fixed slot in every class instance, and selected leaves retain container value semantics while class-handle elements retain handle identity. Scalar and selected fixed-slot queue properties accept a bare fixed-array RHS as an independent queue value, including declared-order conversion and bounded truncation. Positive runtime reducers, invalid-index oracles, exact negative diagnostics, both complete ivtest manifests, and the OpenTitan witness replay verify this boundary. Static class properties use signal-backed storage and remain a focused `sorry`; the same is true for a fixed queue/map array nested inside an unpacked-struct property. No randomization, `ref`, VPI, synthesis or OpenTitan-runtime closure is claimed. See the [session log](../session_logs/2026-08-23_opentitan_fixed_array_container_class_properties.md). |

## 2026-08-24 queue range expressions and dynamic-array result boundary

| Clause | Title | Disposition | Evidence / notes |
|--------|-------|-------------|------------------|
| 7.4.5, 7.4.6, 7.6 | Dynamic-array slice result and assignment typing | PARTIAL | **Fixed/verified direct blocking colon-assignment subset.** `dst = src[left:right]` now gives a direct one-dimensional plain dynamic-array signal slice its required fixed-size `netuarray_t` result when both fully defined constant bounds follow the implicit ascending direction and source/target element types are equivalent. Assignment maps elements left-to-right, resizes the dynamic target, preserves two-/four-state, real, string, class-handle, and unpacked-struct values (including nested dynamic members), returns the element default for OOB source indices, and snapshots a self-slice before replacing its destination. Source coordinates are exact signed 64-bit constants while the synthetic fixed result uses canonical `[0:count-1]`, preserving LP64 values without imposing them on LLP64 `netrange_t`. VVP reloads each destination index after evaluating its leaf, bounds-checks wide object reads before the unsigned storage API, and retains an unpacked-struct element prototype so partial/all-OOB defaults survive a class-property container copy; class handles retain identity and null defaults. Slang 11.0.448 accepts the shared positive source under 1800-2017 and 1800-2023; its signed-32-bit dynamic-index restriction is isolated behind the Icarus-only wide-index checks. Focused legacy and JSON gates pass 15/15 and 10/10; the unmodified OpenTitan HMAC graph moves from one hard line-82 error to compile exit 0. The reviewed 2026-09-24 direct one-dimensional indexed-variable candidate passes paired focus 16/16, full legacy/JSON and real-DPI UVM gates, and clears four SRAM compile diagnostics; neither pinned OpenTitan DV runtime starts. Its integral-base ceiling is 127 bits and its slice-width ceiling is 65,536 elements; exact scope and results are in the [blocker entry](../BLOCKERS.md#ot-sram-indexed-darray-slice--runtime-indexed-dynamic-array-slice-values). Indexed-variable forms outside that blocking subset, property/nested, fixed-target, standalone/type-query, multidimensional, delayed/NBA, compound, and unpacked-union-element forms remain loud or unclaimed. The union boundary is a focused `sorry` rather than exposing the current X initialization where Table 7-1 requires the first member's default, and does not claim broader union runtime semantics. Illegal bounds and inequivalent elements retain exact errors; associative ranges remain illegal. See the [HMAC session log](../session_logs/2026-08-24_opentitan_hmac_dynamic_array_slice_rvalues.md) and the earlier [queue boundary log](../session_logs/2026-08-24_opentitan_usbdev_variable_queue_slices.md). |
| 7.10.1 | Queue colon and indexed range expressions | PARTIAL | **Fixed/verified r-value subset.** `Q[a:b]`, `Q[base +: width]`, `Q[base -: width]`, and, as of 2026-08-30, `Q[$:hi]` accept the recorded integral run-time operands and evaluate the receiver and each explicit operand exactly once. The IEEE text explicitly grants arbitrary operands to queue colon bounds; applying that exception to indexed queue ranges is the Slang-compatible interpretation recorded here, not an unqualified 7.10.1 claim. Colon endpoints clamp to the live queue; reversed or X/Z ranges are empty. For `Q[$:hi]`, `$` is derived from the already-evaluated source's live last index: an exact or above-last `hi` returns the final item, while a lower/reversed or X/Z bound and an empty source return an empty queue. Indexed ranges normalize into ascending queue order, clamp without over-allocation, and return empty for an X/Z base or a nonpositive/X/Z width. Every slice has an **unbounded queue** result even when the receiver is bounded, remains container-valued through nested/property/static/method/untyped-display and streaming paths, and value-copies nested container elements while retaining class-handle identity. The earlier range focus gates and application evidence remain historical; the new left-`$` rows pass 6/6 in each paired legacy and JSON/VVP path and do not add an application replay. Queue-slice l-values, including `Q[$:hi]`, and an indexed `+:`/`-:` selector whose base is the `$` token remain separate loud parser/lowering boundaries. See the [2026-08-24 range log](../session_logs/2026-08-24_opentitan_usbdev_variable_queue_slices.md) and the [2026-08-30 follow-on](../session_logs/2026-08-30_virtual_interface_event_list_queue_slice.md). |

## 2026-08-24 fixed class-property unpacked-array slice l-values

This refinement makes the clause-7 matrix row's older “class/property slice
value” residual precise: property-slice **r-values** remain open, while the
direct blocking pattern-lvalue subset below is implemented.

| Clause | Title | Disposition | Evidence / notes |
|--------|-------|-------------|------------------|
| 7.4.5, 7.4.6, 7.6, 8.5, 10.4, 10.9.1 | Fixed class-property unpacked-array slice l-values | PARTIAL | **Fixed/verified direct blocking pattern subset.** A final in-range constant colon or constant-base `+:`/`-:` range on a direct non-static one-dimensional fixed unpacked-array property retains a fixed-size unpacked-array l-value type. A simple assignment pattern is context-typed by that selected range and maps elements left-to-left in declared order. The complete RHS is captured before any property word changes, so overlap has snapshot semantics and words outside the range remain unchanged. Permanent tests cover OpenTitan's `exp_digest[8:15]` and `[12:15] = '{default:0}`, ascending/descending and negative/nonzero ranges, indexed polarity, packed integral, real and string elements, receiver evaluation, and overlap. Slang 11.0.448+e222e7dc0 accepts the source under both IEEE 1800-2017 and 1800-2023 and gives the selection and contextual pattern the same fixed-array type. Runtime indexed bases, multidimensional or typedef-nested property slices, property-slice r-values, NBA and non-pattern/compound stores, and aggregate/object elements remain loud or unclaimed. Compile-time out-of-range rejection is a current strict implementation boundary, not an additional IEEE conformance claim. Parent clauses remain `PARTIAL`. See the [session log](../session_logs/2026-08-24_opentitan_dma_fixed_property_slice_lvalues.md). |

## 2026-08-24 implicit randomization hooks

| Clause | Title | Disposition | Evidence / notes |
|--------|-------|-------------|------------------|
| 18.6.2 | `pre_randomize()` and `post_randomize()` | PARTIAL | **Fixed/verified default-body subset.** Every completed class hierarchy now supplies the standard's implicit zero-argument empty hook when no declaration exists. Ordinary, implicit-`this`, explicit-`super`, and arbitrary receiver-expression calls are supported, and an empty hook still evaluates its receiver exactly once. Parsed user declarations retain normal method resolution; nonzero argument lists are errors. The dual-harness reducers, Slang differential, complete 1,796/1,796 and 864/864 manifests, and unmodified OpenTitan DMA replay are recorded in the [session log](../session_logs/2026-08-24_opentitan_implicit_randomization_hooks.md). Recursive child hook dispatch and the other clause-18 boundaries remain open, so clause 18 remains `PARTIAL`. |

## 2026-08-14 sv-tests class-type closure

- **Clause 6:** an unused typedef is now declaration-validated when its type
  graph contains explicit dimensions, and an unresolved forward typedef is
  diagnosed once even when never referenced. Resolved forward declarations
  and parameter-dependent module/class typedef widths remain legal. Evidence:
  `sv_typedef_eager_{valid,invalid_width_fail,unresolved_forward_fail}`.
- **Clauses 8 and 25:** class type-parameter defaults accept both
  `virtual iface` and `virtual interface iface`, including forward interface
  names, explicit modport suffixes, and unresolved defaults that are never
  selected. An explicit known non-interface name is rejected; an overridden
  missing default remains lazy, while a concrete property, signal, or return
  type that selects it is diagnosed exactly once. Evidence:
  `sv_typeparam_virtual_interface_{default,default_override,explicit_modport,
  known_noninterface_fail,default_use_fail}`.

## M14 gap closures

The audit found six remaining **silent** gaps (constructs that compiled
but produced a wrong result or no effect with no diagnostic). All are
closed:

**Fixed (real implementation):**
1. **`case (x) inside` range matching** (12.5.4) — range items collapsed
   to their lower bound; interior values never matched. Now lowered to
   the `inside` membership operator (ranges, comma-lists, singles, array
   membership). `parse.y` + `pform.cc` (`pform_make_case_inside`, guard
   duplicator).
2. **Module-static integer-keyed associative-array value read** (7.8) —
   a module-scope `int m[int]` stored via `%aa/store` but read via a
   positional darray load, always returning the default (class-member
   assoc was fine). Added the integer-key assoc read branch in
   `tgt-vvp/eval_vec4.c`.
3. **Width-1 class-property `$display`** (8) — a 1-bit `bit`/`logic`
   property took a pass-object-handle fast path (its width equalled the
   object-handle width) and printed garbage; the value itself was
   correct. Class data properties now always evaluate to a temp
   (`tgt-vvp/draw_vpi.c`). The same fix corrected `$display` of
   continuous-assign-driven interface members (clause 25).
4. **`checker`/`endchecker`** (17) — a bare "syntax error" that aborted
   the whole parse is now an explicit sorry with error recovery, so the
   rest of the source still compiles (`parse.y`).

**Converted to loud diagnostics (implementation deferred):**
5. **`randcase`** (18.16) — was a silent empty block (no branch ran);
   now a loud sorry.
6. **`std::randomize(var)` scope form** (18) — returned success while
   leaving the variable unchanged; now emits a loud one-time warning
   (kept non-fatal because UVM DV uses it as a success predicate).

## Recorded corners (M14 follow-up ledger)

- `$typename` canonical-form output; `%p` on integral aggregates.
- string/real-VALUED integer-keyed assoc reads; `int a[*]` wildcard-key
  declaration.
- Fixed-array function returns: direct whole-array assignments and
  compatible fixed-prefix slices are supported; nested fixed-array pattern
  items accept compatible array-valued function calls in positional and
  `default:` forms, while scalar defaults still recurse to leaf elements.
  Typedef-composed dimensions retain declaration order on signals and function
  returns, including a multi-dimensional function result used as a deeper
  pattern item (issue #415; `sv_uarray_nested_function_return{,_2023}`).
  Incompatible
  return shapes are diagnosed during elaboration. The nested-literal-into-
  array-of-packed-struct abort is
  resolved: module-scope literals work and the class-property whole-array
  pattern store no longer silently zero-fills (issue #97 family). A
  distinct, still-open defect: class-property unpacked arrays of
  `real`/`string` store every element to one slot (issue #100).
- net `alias`; `wait_order`; `randsequence`;
  `unique{}` constraint; `disable soft`;
  `if/case (x matches p)` binding.
- `virtual <iface> v;` as a bare module-scope variable; wildcard-imported
  typedef used as a type; `export pkg::*` re-export; `std::mailbox#(T)`.
- `rand_mode(0)` field freeze; `process.status()`/`suspend`/`resume`.
- shallow-copy inline static initializer `C b = new a;` at module scope.
- `$exit`, `extern module`, anonymous program, library-map files.
- timescale/timeunit conflict not diagnosed (3.14.3).

Each corner is a **loud diagnostic** (syntax error, sorry, warning, or —
for the two ICEs — an assertion abort) or a documented behavioural
limitation. None is a silent miscompile.

## 2026-08-27 clauses 6.16 and 11.4.12.2 typed string concatenation

The shared IEEE 1800-2017/2023 string-conversion and concatenation rules are
covered by paired `-g2017`/`-g2023` positive and negative regressions. This is
a bounded contextual-typing and runtime subset; clauses 6 and 11 remain
`PARTIAL`.

| Boundary | Disposition / evidence |
|---|---|
| String assignment context | FIXED. A concatenation assigned to a string parameter, fixed unpacked string-array element, procedural string variable, or equivalent typed consumer is elaborated with the complete destination type. The exact OpenTitan scalar and fixed-table path shapes are permanent runtime cases. |
| Operand categories from Table 6-9 | FIXED for the evidenced subset. String expressions and string literals compose as strings, including nested groups. An all-literal group is converted by its string context while the same source retains packed-integral meaning outside that context. An uncast integral-only concatenation is a focused error. A true string expression mixed with an uncast integral expression is rejected at the operator, including beneath a conditional or whole string cast; an explicit cast of that operand is the supported conversion request. In a generic class template, a direct formal/local/property whose parse-form type is an unresolved class type parameter defers this decision until specialization; `string` bindings pass and the paired concrete-`int` case remains a hard error. The retained `br_gh800` form is a narrow literal-only compatibility extension containing at least one string literal plus integral literals, not permission for an integral variable, select, call, or other expression. |
| String-producing calls and result types | FIXED for the pinned forms. Width/type probing retains the declared string result of a built-in method and of a zero-argument static function invoked without parentheses under 13.5.5. Direct and dependent `T::type_name` calls execute the declared function rather than substituting a synthetic class name. For data objects and constant string parameters, built-in results retain `int` for `len`/`compare`/`icompare`, `byte` for `getc`, `integer` for `atoi`/`atohex`/`atobin`/`atooct`, `real` for `atoreal`, and `string` for `toupper`/`tolower`/`substr`; a nested string concatenation can be a method receiver. Review hardening makes constant-parameter methods consume semantic bytes, preserving empty, nonprinting, backslash, and quote data instead of a rendered representation. A parentheses-free static class call in a constant `localparam` concatenation remains a current gap. Class-scoped invocation of a non-static method without an object remains a pre-existing wrong acceptance and is not included in the static-call claim. |
| Method receiver and arity checks | FIXED for the pinned data-object and constant-parameter paths. A selected character of a scalar string has `byte` type and cannot receive `.len()` or another string method, including through direct, struct, or class-property spelling; the diagnostic no longer dispatches on the unselected whole string. Built-ins require exactly 0 arguments for `len`/conversion/case methods, 1 for `compare`/`icompare`/`getc`, and 2 for `substr`. Missing or extra arguments are hard errors before call lowering rather than ignored/defaulted arguments or a post-diagnostic malformed call. Argument-type conversion remains separate: `s.compare(65)` is a pre-existing wrong acceptance. |
| Constant folding and explicit casts | FIXED. A contextually string-typed constant concatenation remains a string constant after folding, and integral-to-string conversion removes null bytes. A selected integral value evaluated through an explicit string cast reaches VVP's vector-to-string conversion and produces the selected character instead of an empty string. |
| Replication | FIXED for the evidenced shared 2017/2023 subset. Constant and run-time integral multipliers over string operands are runtime-pinned, including `{repeat_count{{"A", "B"}}}` in a direct string target, a whole string cast, and both comparison operand orders; a string-typed multiplier and a string replication assigned to an integral target are rejected. Zero and nonzero repeats evaluate their operand exactly once, and zero produces the empty string. Review hardening removes the arbitrary cutoff from new typed VVP images: a legal **1,048,576-byte** variable repeat passes, lowering preserves signedness, and negative, X/Z, or runtime-index-width failure is diagnosed. The unsuffixed opcode preserves its historical signed/copy-boundary behavior for old textual images and is pinned independently. Each repeat owns its VVP index word, so a bounded-queue RHS cannot corrupt its caller's live bound. Slang 11 rejects the standalone zero-repeat reducer because it permits zero only inside an enclosing concatenation; that narrow differential disagreement is recorded without changing the IEEE interpretation. |
| Direct `string[index]` operand | COMPATIBILITY EXTENSION only inside the documented concatenation. IEEE string indexing yields a byte, and Slang 11 rejects that byte directly inside the string concatenation. OpenTitan uses the spelling in commercial-simulator-targeted DV source, so Icarus admits only a final 8-bit select whose underlying object is string. An ordinary packed-vector byte select still requires `string'(...)`, and the byte cannot receive a string method. VCS, Questa, and Xcelium were not run for this increment. |
| Bounded residuals | PRE-EXISTING unless stated otherwise. A fixed-size unpacked signal-array string element retains its two-character value but direct `.len()` reports 1; dynamic arrays, queues, and a fixed array in a class property return 2 in the same probe. `s.compare(65)`, `{8'h41} == s`, and a non-static method called as `C::f` are accepted but rejected by Slang. The current branch still rejects a legal parentheses-free static call in a constant `localparam` concatenation; the baseline was already broken on that source by a different internal typed result. |
| Validation | Final gates pass **23/23 focused legacy**, **24/24 focused JSON/VVP**, **2,083/2,083 full legacy**, **1,161 full JSON/VVP entries with 0 failures** (1,144 executed/pass plus 17 NI), **136/136 negatives**, **103/103 VPI**, **6/6 textual VVP compatibility**, and **354/354 canonical real-DPI UVM** with 0 failures/skips. The clean canonical `origin/main` compiler at `6bfe64ce` reaches two internal typed-concatenation errors and then the `par_string` assertion on the expanded current positive reducer; the final compiler runs that exact source to `PASSED`. |
| OpenTitan application replay | Earlier same-branch authentic Darjeeling/Earlgrey top-chip replays, before final generic-class deferral hardening, move the internal typed-concatenation diagnostic counts from **10/18** to **0/0**. Both first report the independent queue-versus-dynamic-array context mismatch at `spi_agent_cfg.sv:139`, then traverse a much larger independent diagnostic graph before the compiler exits 139 without a VVP image. The final narrow deferral change has not been replayed across those tops. Neither top elaborates, and no new 61-target matrix has been run. |

Full mechanism and boundary detail is in the
[typed-string session log](../session_logs/2026-08-27_opentitan_typed_string_concatenation.md).


## 2026-08-27 clause-12 declaring for-loop refinement

IEEE 1800-2017 and IEEE 1800-2023 12.7 / 12.7.1, Syntax 12-5 including
footnote 14. Behavior is identical under `-g2017` and `-g2023`; every
regression below is registered as a 2017/2023 pair.

| Boundary | Disposition / evidence |
|---|---|
| Several `for_variable_declaration`s, each with its own `data_type` | FIXED. `for (enum_t e = e.first(), int i = 0, byte b = i + 1; ...)`. Previously only a single keyword-typed declaration parsed; a typedef-led list fell into error recovery, which warned and dropped the loop. `sv_for_decl_type_forms`. |
| Same-type declarator continuations | FIXED. `for (int i = 0, j = i + 3, k = j + 2; ...)`, with earlier declarations visible to later initializers. `sv_for_decl_type_forms`. |
| Package-qualified and class-scoped member types | FIXED. `p::regno_t`, `C::nibble_t [1:0]`, `p::C::word_t`, `C#(byte)::T`, `p::C#(byte)::word_t`. The class qualifier is retained as a separately owned type node, resolved and specialized before the member typedef elaborates in the resulting concrete class scope, so `p::C::word_t` keeps its 8 bits instead of widening to 32. |
| `var type(expr)`; bare `type(expr)` | FIXED / correctly rejected. Footnote 14 permits the type_reference form only under `var`. `sv_for_decl_bare_type_ref`. |
| Declarator name that shadows a visible typedef | FIXED. Declarators are installed at the first `;`, so the condition and step lex the name as IDENTIFIER. `for (int shadow = 0; shadow < 3; shadow++)` previously bound its condition to the type and never terminated. `sv_for_decl_scope_forms`. |
| Inline anonymous enum identity and non-leakage | FIXED. The implicit block opens before the data type is parsed. Sibling loops declaring `enum {A, B}` do not collide, and their literals do not reach the enclosing block. `sv_for_decl_scope_forms`. |
| Automatic control-variable lifetime in a static subroutine | FIXED. Two overlapping activations each record their own 0,1,2 sequence, while an explicitly static body local keeps its shared lifetime. `sv_for_decl_type_forms`, `sv_for_decl_scope_forms`. |
| Control-variable instance count | One automatic instance per loop entry, not per iteration, per 12.7.1. A detached child that outlives the loop reads the final value; a per-iteration body-local automatic keeps its own frame. Pinned by `sv_for_decl_scope_forms`. |
| Labeled implicit block | FIXED at module level: `loop2: for (int i = ...)` names the block, and `%m` and `disable loop2` resolve through it. This compiler reports no named block through `%m` from inside a subroutine (a plain `begin : name` behaves identically), so that is an unrelated pre-existing limitation, not a 12.7.1 boundary. |
| Duplicate declarators; unknown class member type; earlier initializer reading a later declarator | Correctly rejected with one focused diagnostic each and a non-signal exit. `sv_for_decl_dup_declarator`, `sv_for_decl_bad_member_type`, `sv_for_decl_after_use`. |
| Loop variable escaping after the loop | OPEN, and general rather than 12.7.1-specific. An assignment to a name that has left scope produces the SystemVerilog compile-progress warning and a zero exit, identically for a declaring for-loop, for a plain named block, and on the previous mainline. Non-escape is asserted semantically instead. |
| Synthesis of a declaring for-loop | A loop declaring exactly one control variable keeps the explicit index/initial-value pair and synthesizes as before. Several control variables have no single index; that is reported and rejected, and no longer segfaults. `sv_always_comb_for_null_index`. |

### Parser conflict state

535 shift/reduce and 1119 reduce/reduce, against 535/1115 on the merge base.
The four added reduce/reduce are the packed-dimension-versus-index decision in
the class-scoped initializer states; no other conflict state changed its item
signature. Conflict totals alone are insufficient evidence here: `'('` and
IDENTIFIER both carry declared precedence, so a decision between them is
resolved silently and is never counted. The acceptance criterion used was that
the state after `for (` contains exactly one item and reduces on `$default`.

## 2026-08-27 clause-23.11 bind target-instance paths

IEEE 1800-2017 23.11 and Syntax 23-9 permit a bind target instance to be a
hierarchical identifier with constant bit selections. The implemented and
permanently paired `-g2017`/`-g2023` subset is:

| Boundary | Disposition / evidence |
|---|---|
| Structured absolute and root-qualified paths | FIXED. Parsed components retain selections and lexical identity. Absolute paths, explicit `$root` entries, module/generate-relative dotted paths, and a package-localparam-selected loop-generate child resolve without a designwide terminal-name search. `sv_bind_indexed_relative_targets{,_2023}`, `sv_bind_explicit_root_target_list{,_2023}`. |
| One-dimensional generate and instance-array selection | FIXED. A descending `[3:1]` instance array and loop-generate scopes select exactly the requested elaborated element. Final as well as intermediate instance arrays require selection; an unselected final array is rejected. The bound actual observes the target's parameter, pinning target-viewpoint resolution. `sv_bind_indexed_relative_targets{,_2023}`, `sv_bind_target_unselected_array_fail{,_2023}`, `sv_bind_target_path_shape_fail{,_2023}`. |
| Conditional per-owner type and shape | FIXED. Same-named conditional/case alternatives resolve only through the active occurrence, including alternatives with different module/interface types and scalar-versus-array or generate-for-versus-scalar shapes. A missing select is diagnosed only for the active array occurrence. `sv_bind_conditional_different_types{,_2023}`, `sv_bind_conditional_{array_shape_fail,generate_shape,generate_scalar_shape}{,_2023}`, `sv_bind_interface_inactive_alternative{,_2023}`. |
| Declaration-scope activation, lexical identity, and per-owner expressions | FIXED. A contained directive exists only for each elaborated occurrence of its exact module/generate declaration. Inactive conditional/case arms, excluded roots, and uninstantiated owners neither attach nor report false misses. Nearest-generate lookup wins, and genvar/parameter-dependent selections are evaluated independently per owner. `sv_bind_owner_{generate_lexical,inactive_generate,inactive_invalid,excluded_absolute,loop_genvar_select,select_specialization_fail}{,_2023}`. |
| Deferred activation and source order | FIXED. Pending directives are reconsidered to a fixed point when owners or targets become available; direct and deferred ordering produces the same result. Active invalid owners diagnose, inactive ones do not. `sv_bind_owner_active_invalid_fail{,_2023}`, `sv_bind_fixed_point_owner_overlap_fail{,_2023}`, `sv_bind_fixed_point_target_{first,reversed}_fail{,_2023}`. |
| Bound-instance namespace and collisions | FIXED. The same introduced name is legal on disjoint concrete targets. Direct/direct, direct/list, multiple-owner, definition-name, and same-base array-instance overlaps on one target are focused errors. `sv_bind_same_name_{disjoint,target_overlap_fail,list_overlap_fail}{,_2023}`, `sv_bind_same_base_array_collision_fail{,_2023}`, `sv_bind_owner_{absolute_disjoint,absolute_overlap_fail,definition_collision_fail,duplicate_designwide_fail}{,_2023}`. |
| Declaration-scoped target-instance lists | FIXED for the evidenced structured subset. Absolute, explicit-root, declaration-relative, and selected one-dimensional entries use the same owner context and collision rules; invalid-first and invalid-last orders report consistently. `m13b_bind_instance_test`, `sv_bind_owner_scoped_target_list{,_2023}`, `sv_bind_explicit_root_target_list{,_2023}`, `sv_bind_target_list_invalid_{first,last}_fail{,_2023}`. |
| Target and origin legality | FIXED for the paired boundary matrix. Bind targets and target-list declarations are modules/interfaces, not checkers/programs. IEEE 23.11 permits only an interface or checker instantiation into an interface target; a module or UDP is rejected. UDP bound instantiations are rejected for module targets too, including a UDP type loaded only from `-y`; program/checker declaration origins are rejected, and checker declarations are not promoted to design roots. The internal M13 fixture was corrected module→interface to conform to the standard, not to preserve a compiler compatibility extension. `sv_bind_{interface_checker,interface_module_fail,interface_udp_fail,module_udp_fail,library_udp_kind_fail,checker_target_fail,program_instance_target_fail,target_list_scope_kind_fail,origin_scope_fail,checker_root_selection}{,_2023}`. |
| Library definitions and directives | FIXED with one documented root-selection policy. Pending binds are re-resolved when `-y` discovers a target definition or a container definition traversed by the target path. A loaded source may append a compilation-unit bind, whether reached during the initial compilation-unit closure or from a live contained bind; inactive/excluded owners never load or diagnose their dependency. Automatic roots account for the initial-closure case but are not retroactively rebuilt for the contained-owner case, which uses explicit `-s`. `sv_bind_library_{target,path,late_root,udp_kind_fail}{,_2023}`, `sv_bind_owner_{library_cu_closure,inactive_library}{,_2023}`. |
| Invalid selections and no-match | Correctly rejected. Dynamic, X/Z, host-overflow, out-of-range, scalar-selected, missing-selection, and absolute no-match forms are loud; the diagnostic outcome does not depend on invalid target-list entry order. `sv_bind_target_{dynamic_select,range_select,path_shape_fail,unselected_array_fail}{,_2023}`, `sv_bind_owner_nonroot_absolute_fail{,_2023}`. |
| Bind beneath a bound instance | Correctly rejected for direct/deferred target and owner creation in either source order; claiming or replaying a deferred directive cannot make the introduced hierarchy a legal target. `sv_bind_{owner_nested_first_fail,owner_nested_reversed_fail,nested_direct_first_fail,nested_direct_reversed_fail,nested_deferred_fail,fixed_point_target_first_fail,fixed_point_target_reversed_fail}{,_2023}`. |
| Direct nested generate collector | FIXED. A conditional-generate alternative that directly contains a generate-for contributes the selected lexical path. `sv_bind_conditional_{generate_shape,generate_scalar_shape}{,_2023}` permanently pin the two bind shapes; a plain non-bind nested-generate local smoke confirmed that the collector fix does not depend on bind side effects. |
| Bare target name | Resolved lexically from the containing generate/module, with a local instance taking precedence over a same-named module/interface type. The former designwide terminal-name compatibility search is removed. `sv_bind_target_instance`. |

The previous mainline rejects the positive selected paths in both editions.
The parser remains at 535 shift/reduce and 1119 reduce/reduce conflicts, with
no changed canonical conflicting item core relative to the post-declaring-loop
mainline.

The paired focused legacy and JSON/VVP harnesses each pass 110/110 on the final
native-ARM64 install. Full legacy passes 2063/2063, full JSON/VVP passes
1141/1141, negatives pass 136/136, VPI passes 103/103, and the real-DPI UVM
umbrella passes 354/354 with zero failures/skips.
No new full OpenTitan replay was made after the owner and fixed-point hardening;
the session log preserves the earlier replay only as historical frontier
evidence.

This is not clause-23 closure. Multidimensional module-instance arrays remain
outside the compiler's existing one-dimensional instance-array model.
Automatic roots are not retroactively recomputed for a compilation-unit bind
discovered only after a live contained bind loads a library; use explicit `-s`
for that exact-root case. An exhaustive clause-23 combination audit is still
required before a complete conformance claim.

## 2026-08-28 clauses 6.24, 7.6, 7.10.5, and 13.3–13.5 positional-container refinement

IEEE 1800-2017 and IEEE 1800-2023 have the same rules for this cluster. The
standard destination-typed copy and cast repairs and the separately labeled
OpenTitan interoperability extension share lowering without sharing a
conformance claim.

| Boundary | Status | Disposition / evidence |
|---|---|---|
| 7.6 positional unpacked-array assignment | FIXED for the evidenced value/copy contexts | Equivalent slowest-varying elements permit queue/dynamic-array cross-kind assignment. The target is resized from the source count and receives a fresh left-to-right element copy with its declared runtime kind. Only the slowest-varying dimension may differ in kind; paired task/function input/output/inout negatives reject `int[][]` versus `int[$][$]`, while a legal queue-of-dynamic-arrays control varies only the outer kind. Destination-typed collection splices apply compatibility again at their element boundary. Covered paths include direct signals, class properties, selected and nested properties, conditionals, function results, subroutine boundaries, queue methods, assignment patterns, object splices, nested containers, and unpacked-struct members. A real queue-to-dynamic assignment reaches atom-contiguous dynamic-array DPI storage instead of retaining a queue object. |
| 6.24.1 assignment-compatible explicit casts | FIXED for evidenced positional containers | An explicit queue/dynamic-array cast with equivalent elements materializes a typed temporary before an enclosing assignment or method can hide it. Same-kind and cross-kind real casts, a bounded destination, direct queue method use, conditional sources, value isolation, and complete nested-associative element equivalence (including key and wildcard metadata) are paired 2017/2023 regressions. A non-bit-stream real/integral mismatch is diagnosed once rather than inherited from an outer assignment context. |
| 6.24.3 non-assignment-compatible bit-stream casts | FIXED for the integral positional-container subset | Integral queue/dynamic-array elements may change width through a strict MSB-first pack/unpack when the complete source stream divides exactly into the destination element width. The byte-queue/word-dynamic-array round trip and independent destination kinds are pinned. A nondivisible source, a result larger than a bounded queue, or the existing bounded runtime-width guard returns a nonzero simulation status with a stable error and an empty result; strict casts do not borrow ordinary stream padding or bounded-assignment truncation. General recursive aggregate/class/structure bit-stream casts still use legacy paths and are not claimed by this row. |
| 7.10.5 bounded queues | FIXED for the evidenced assignment/copy/cast paths | Ordinary same-kind and cross-kind writes preserve the declared target bound, discard tail elements, and warn across assignment, function input/output/inout, aggregate, nested-container, and associative-value contexts. An assignment-compatible cast preserves a fitting bound, while an oversized strict cast fails instead of truncating. A direct strict cast carries a 64-bit bound and therefore handles the tested bound above `UINT_MAX` without wrap. Ordinary queue signal/method storage still has older unsigned-bound paths, so this is not general support for queue bounds above `UINT_MAX`. |
| 13.3.2, 13.4.2, and 13.5 native output lifetime/call semantics | FIXED for the evidenced queue/dynamic-array subset | Native output formals are copy-out only. Automatic task/function outputs begin at their declared empty default on every invocation; static task/function outputs retain private formal storage even when an explicitly automatic local requires a task call frame. Inout still copies in and out. Empty native bodies retain input side effects, frame/dispatch semantics, untouched output defaults, and copy-back. The caller-shape copy-in exception is confined to DPI imported open-array output formals; DPI queue/dynamic-array output acceptance remains an interoperability boundary. Task and nonvoid-function output/inout actuals are lvalue-checked and require equivalent positional-container elements; failed copy-in does not produce a second copy-back diagnostic. |
| 7.4.5, 7.6, 7.7, 13.5, and 35.5.6.1 fixed slice function actuals | FIXED for direct one-dimensional signal slices | A constant legal slice passed to a value-returning native or DPI function remains one aggregate value with its backing signal, exact storage window, element type, selected bounds, and direction. Native fixed and unsized formals copy input/output/inout elements left-to-right; automatic pure fixed outputs start from the element default, static outputs retain their formal words, and copyback changes only the selected actual range. Fixed formal/actual count and element mismatches and illegal reverse slices are elaboration errors. A DPI open formal reports the actual slice bounds, uses numeric declared indices in C, and copies output/inout writes back through the bounded window without inspecting the unspecified initial output contents. Missing descriptors, OOB windows, and source-size mismatches in textual VVP are non-asserting and stores are atomic. Focused evidence is 24/24 legacy, 21/21 JSON/VVP, 1/1 real DPI, and 7/7 malformed-IR invariants. Multidimensional, class/property-backed, and `ref` slice actuals remain outside this row. |
| 6.22.2 and 6.11.2 OpenTitan spelling | DIAGNOSED plus NONSTANDARD OPT-IN | This row records the August 28 interoperability experiment; the current implementation gates mixed-state `bit`/`logic` container value conversion behind `-gcommercial-unsafe` as described above. Strict §7.6 element equivalence remains the default. The option covers the evidenced equal-width, equal-signedness whole queue/dynamic-array assignments and native task/function value copies, with destination-typed X/Z-to-zero conversion. Ref binding, enums, nested associative metadata, width, and signedness remain strict. Slang 11.0.448 rejected the exact assignments in both editions and VCS compatibility mode; no VCS, Questa, or Xcelium executable was run. |
| VVP textual conversion/loader contract | FIXED and malformed-input-pinned | `%queue/to/darray` retains its legacy spelling, `%container/to/queue` adds the inverse typed copy, and typed object-splice opcodes carry an optional unpacked-struct prototype in an out-of-line descriptor. `vvp_code_s` remains 24 bytes on ARM64. The loader validates exact arity, element and stream encodings, queue bounds, and resolved prototype kind before scheduling; runtime backstops avoid assertions and preserve operand-stack balance. Direct fixtures cover ordinary conversion, truncation, malformed arity/encoding/prototype, and strict runtime-limit failure. |
| Validation and application evidence | PROVISIONAL checkpoint | The final container-focused gates pass 79/79 legacy and 72/72 JSON/VVP; the fixed-slice gates pass 24/24 legacy, 21/21 JSON/VVP, 1/1 focused real DPI, and 7/7 textual-IR recovery invariants. The post-slice broad replay passes 2,151/2,151 full legacy, 1,229/1,229 full JSON/VVP, 136/136 negatives, 103/103 VPI, and 354/354 canonical real-DPI UVM with no failures or skips. The current authentic OpenTitan replay has zero `spi_agent_cfg.sv:139`/`:143` mismatch occurrences in `spi_device_sim`, `spi_host_sim`, Darjeeling, and Earlgrey; recorded prior red counterparts prove removal only for the two top-chip closures. All four remain FAIL at independent later mechanisms. See the [session log](../session_logs/2026-08-28_opentitan_queue_darray_destination_conversion.md). |

This is not complete clause-6, clause-7, or clause-13 support. The mixed-state
opt-in ordinary-assignment extension still requires a bare direct-identifier RHS;
selected, scoped, property, nested, and function-return sources are not
widened by that extension. General recursive bit-stream casts and ordinary
queue bounds above `UINT_MAX` remain explicitly outside the fixed subset.

## 2026-08-30 clauses 7.10.1, 9.4.2, 23.6, and 25.9 refinement

IEEE 1800-2017 and IEEE 1800-2023 state the same rules used by this bounded
increment. The paired `-g2017`/`-g2023` tests distinguish the normative
language subset from one explicitly labeled compatibility extension.

| Clause | Boundary | Disposition / evidence |
|---|---|---|
| 7.10.1 | Left-`$` queue range r-value, `q[$:hi]` | FIXED for the evidenced r-value subset. The receiver is evaluated once, `$` is derived from that live queue's last index, and the integral `hi` is evaluated once. An exact or above-last `hi` returns the final item; a lower/reversed or X/Z bound and an empty source return an empty queue. The result is always an unbounded queue. Direct, selected class-property, static-property, method/type-query, integral, logic, real, string, class-handle, and nested-container paths are pinned; nested containers are copied and class handles retain identity. A nonqueue receiver or nonintegral explicit bound is an error. The corresponding l-value and `$` as an indexed `+:`/`-:` base remain loud boundaries. `sv_queue_slice_dollar_left{,_fail,_lvalue_fail}`. |
| 9.4.2, with 6.17, 14.10/14.12/14.14, and 15.5 leaf forms | Mixed explicit event lists | FIXED for an explicit `or`/comma list whose leaves can be lowered independently. Each leaf is prepared once and its retained expression is transferred to exactly one lowering path. A VIF-member or class-property leaf may coexist with ordinary signals, named events, a run-time-selected event-array element, and direct/default/global clocking events. Isolated join-any helpers resume the user statement once and cancel all losing registrations without killing an unrelated detached child. Simultaneous winners resume once; same-value and masked class-property writes do not wake. Rejected leaves diagnose once. A single leaf expression that itself combines VIF and class/ordinary dependencies remains loud, and the prior compound-snapshot and owner/key/index-mutation boundaries are unchanged. `sv_class_property_mixed_event_value_change`, `sv_event_list_vif_{mixed_once,preserved_leaves}`, and the prepare-once diagnostic pairs. |
| 25.9 and Syntax 25-3 | Virtual-interface declaration spelling, provenance, and forbidden contexts | FIXED for the evidenced declaration subset. `virtual iface` and `virtual interface iface` are accepted directly and through typedefs in compilation-unit, package, module, block, declaring-for, unpacked-struct, qualified class-property, and task/function/method argument and return contexts. Source provenance follows arrays, forward/package typedefs, concrete type parameters, and lexical `type(expression)`, so module/interface/program ports, interface items, and union members are rejected while ordinary interface ports remain legal. Parameter overrides still use default member widths and warn; this row does not claim complete specialization semantics. `sv_vif_explicit_interface_{class_property,data_type_contexts}` and the forbidden-context pairs. |
| 25.9 | Virtual-interface `==` and `!=` | FIXED for the unparameterized identity subset. A VIF may compare with null, an equivalent VIF, or a same-definition concrete interface instance in either operand order. VVP compares the bound scope plus interface definition, so two wrappers for one instance compare equal, different instances do not, and ordinary class objects retain pointer identity. Constant one-dimensional instance-array elements, same-type conditional VIFs, rebinding, null, lexical shadowing, and same-spelling instance/type names are pinned. Scalars, different interface definitions, two concrete instances, `===`/`!==`, and `==?`/`!=?` remain exact errors. Parameter specialization and modport selection are not yet complete parts of comparison type identity. `sv_vif_instance_comparison` and six negative sources. |
| 23.6 compatibility boundary | Run-time-variable interface-instance-array selection used as a 25.9 operand | INTENTIONAL EXTENSION, not IEEE conformance. Both editions require an instance-array select in a hierarchical name to be a constant expression. `sv_vif_instance_runtime_index_extension` separately pins the unqualified one-dimensional run-time dispatch needed by application flows. Slang 11 accepts the core 25.9 positive and rejects this extension in both editions. Hierarchical and multidimensional run-time dispatch are not claimed. Slang's separate acceptance of VIF case/wildcard operators is not used as evidence against 25.9's normative Icarus diagnostics. |
| Validation | PROVISIONAL checkpoint | The VIF context/comparison/extension lists pass 22/22 in each legacy and JSON/VVP path; the chapter-9 lists pass 14/14 in each path; and the new left-`$` queue rows pass 6/6 in each path. The broad replay passes 2,188/2,188 legacy, 1,266 JSON/VVP entries with 0 failures (1,249 pass and 17 unchanged NI), 149/149 negatives, 103/103 VPI, and 354/354 canonical real-DPI UVM. Homebrew Bison 3.8.2 reports 533 shift/reduce and 1119 reduce/reduce conflicts, versus 535/1119 on the merge base, with no unintended canonical conflicting-state terminal-action change. No OpenTitan or Caliptra application matrix was replayed. |

This is not complete clause-7, clause-9, clause-23, or clause-25 support. In
particular, parameter-specialized and modport-aware VIF comparison identity,
nondefault parameterized-interface member widths, hierarchical or
multidimensional run-time instance dispatch, mixed dependency families inside
one event-expression leaf, left-`$` queue-slice l-values, and `$` as an indexed
range base remain outside the conformance subset. See the
[session log](../session_logs/2026-08-30_virtual_interface_event_list_queue_slice.md).

## 2026-09-01 clauses 8.19 and 19.5 constructor-order subset

Paired 2017/2023 evidence covers a bounded class instance-constant and
embedded-covergroup constructor-order subset:

- Only a corresponding class constructor may initialize a non-static instance
  constant. Static constants remain declaration-initialized.
- A path-sensitive source audit authorizes the recorded assignment sites. A
  per-object VVP guard enforces the dynamic rule that at most one assignment
  executes, including distinct sites reached through conditional, loop,
  `continue`, return, and detached-fork paths.
- An embedded covergroup that refers to an enclosing-class instance constant
  requires definite initialization before construction. The initializer and
  referring constructor may not share one loop or `fork...join_none` region.
- A procedural `for` header initializer executes once outside its repeated
  region; its body and step share the repeated region. Flow distinguishes a
  literal-false zero trip, omitted/direct-nonzero-literal guaranteed entry,
  `continue` into the step, and `break`/return exits. Other constant-expression
  proofs remain conservative.
- Literal and already-evaluated class-parameter repeat counts distinguish zero,
  one, and runtime/repeated flow without speculative elaboration. Lexical
  formals, locals, and explicit or pinned wildcard imports shadow a class
  parameter. Unary minus retains the literal's width and signedness.

The focused legacy and JSON/VVP gates each pass **44/44**. The post-change
broad gates pass **2,212/2,212** SystemVerilog, **1,290 JSON/VVP entries with
0 failures**, **149/149** negatives, **103/103** VPI, **1/1** malformed-VVP
guard checks, and **354/354** real-DPI UVM with no failures or skips. Nine
positive synthesis loop reducers and one negative sentinel preserve the
ordinary `NetForLoop` fast path.

On clean, unmodified OpenTitan revision `7a3ad34b`, the focused
`lowrisc:dv:rv_timer_sim:0.1` UVM compile now has setup return 0, compile return
0, and **0 hard errors**. Its four former instance-constant range drops are
absent; the row improves from FAIL to **DEBT** and retains 17 unrelated loud
debt diagnostics, so this is not an application pass. The pinned ARM64 Python
3.13/FuseSoC flow was used, and `util/regtool.py` regenerated the UART register
RTL byte-for-byte identically to the checked-in sources.

This is bounded clause-8/19 support, not closure. Nonliteral constant-condition
proof, exhaustive constructor control flow, broader covergroup expressions,
and the previously recorded clause-19 gaps remain open. See the
[session log](../session_logs/2026-09-01_class_instance_constant_constructor_order.md).

## 2026-09-01 clauses 8.13, 9.2.2.2.1, 13.4, 13.5, and 25.9 virtual-interface functions

Every language regression in this section is paired under `-g2017` and
`-g2023`.

| Boundary | Disposition / evidence |
|---|---|
| 25.9 value-returning dynamic dispatch | FIXED for unparameterized virtual interfaces. The frontend records every compatible concrete interface-function scope and a scope-keyed argument row. VVP compares the receiver's bound instance, selects exactly one candidate, evaluates only its row, and enters that method. Rebinding and multiple concrete instances are runtime-pinned. |
| 13.5.1/13.5.3 arguments and defaults | FIXED for input-only scalar/container formals in the recorded subset. Named and positional actuals are assignment-contextualized against each candidate. An omitted argument clones that candidate's declaration-scoped default, including interface-member reads, earlier-formal references, and nested VIF-function calls. Missing required actuals and named-then-positional calls remain hard errors. |
| 13.4.1/13.4.2 automatic and static lifetime | FIXED for the recorded typed forms. Automatic functions allocate their own frame. Static-formal setup is staged in an invocation-local typed overlay and committed immediately before the body; recursion from the body still observes shared static storage. Nested setup and automatic/static recursion are checked. |
| Typed and discarded results | FIXED for packed scalar/wide, real, string, class-handle, queue, and dynamic-array results. A statement-position cast/discard executes the selected function and balances the corresponding VVP stack. The object stack grows on demand beyond the former 32-value limit. |
| Null receiver | FIXED. A null dynamic VIF function receiver terminates at runtime. The no-concrete-instance case still elaborates explicit actuals against the declaration signature before emitting the required null failure. |
| 9.2.2.2.1 `always_comb` sensitivity | FIXED for a function-body read through a constant element of an interface-port array. Dependency discovery includes the selected member while declaration-only interface scopes remain absent from target conversion. |
| 8.13 inherited value parameters | FIXED for unqualified lookup in a derived class method. After local lookup, specialized superclass scopes are searched nearest-first. `sv_inherited_class_parameter_vif_task` passes the inherited value 80 * 2 into an implicit-input VIF task formal; exact main warns and observes 0. |
| Statement-row compile-progress compatibility | PRESERVED and isolated. If frontend recovery has already produced a null actual for a VIF task statement, target lowering skips only that store as main did. This does not relax value-returning VIF expressions, ordinary subroutine calls, formal-direction checks, or legal-source diagnostics. |
| Unsupported boundaries | LOUD or documented. Output/inout/ref VIF-function arguments, fixed-unpacked arguments/returns, complete parameterized-interface and modport specialization, and synthesis lowering remain outside this subset. |
| Focused validation | The paired legacy and JSON/VVP lists each pass **31/31**. Final broad and application totals are recorded in the associated session log. |

This is a bounded cluster, not complete clause 8, 9, 13, or 25 support. See
the [session log](../session_logs/2026-09-01_virtual_interface_functions.md).

A later §9.2.2.2.1 correction excludes fully written automatic-function locals
from `always_comb` implicit sensitivity even when the local is written in bit
intervals and read as a whole vector. Unwritten read intervals remain inputs;
exact event-expression matching is unchanged. The
[paired 2017/2023 RED and 8/8 fix controls](../../../evidence/caliptra-aes-sensitivity-fix-20260923/README.md)
and synthesis neighbors establish this narrow boundary. The pinned Caliptra
diagnostic advances past time zero but fails separate assertions, so the clause
fix is not an L0 pass.

## 2026-09-02 clauses 6.22, 7.4-7.10, 13.5, 15.4.5-15.4.9, and 25.5/25.7/25.9 refinement

This increment preserves semantic type and l-value identity across
parameterized interfaces, recursive containers, and mailbox calls. It is a
bounded refinement, not closure of any parent clause.

| Boundary | Disposition / evidence |
|---|---|
| 6.22.1 and 25.7 modport prototypes | FIXED for the recorded declaration and call subset. Identifier-form imports use the interface declaration signature for ordinary positional calls. A full prototype is required where 25.7 requires it and is checked at elaboration even if never called. Argument count/direction, return type, significant formal names, fixed bounds, packed shape, array kind, associative index type, defaults, duplicate declarations, visibility, and missing exports retain focused diagnostics. Matching is deliberately stricter than equivalence: an equivalent-but-nonmatching packed representation does not satisfy a modport prototype. Parser recovery clears an incomplete item after an error and at a physical-file boundary. |
| 25.9 parameterized and modport-selected VIF dispatch | FIXED for the evidenced dynamic-call subset. Evaluated parameter values/types and the selected modport remain part of the semantic interface type. Each physical scope retains the carrier for its interface-local enum, unpacked-record, and class declarations. The current VIF binding chooses the compatible physical method candidate without executing an unrelated specialization. Scalar task `output`, `inout`, and `ref` formals select and write back through that same candidate. Output/inout/ref VIF **function** formals, arbitrary fixed-unpacked formals/returns, exhaustive specialization interactions, and synthesis closure are not claimed. The new nominal-result/task-copyback rows pass 8/8 in each legacy and JSON/VVP harness; the exact-main compiler is 0/8 in both harnesses. |
| 25.5 selected actual and physical interface arrays | FIXED for the recorded direct forms. A selected-modport actual connected to an unqualified physical interface formal retains the actual instance's evaluated parameter specialization. Member access, selected task copyback, and parameterized/forwarded interface-array paths pass 4/4 together. This does not claim arbitrary hierarchical or multidimensional runtime instance selection. |
| 7.4.2, 7.4.5, 7.5, 7.6, 7.8, and 7.10 recursive Q/D/A layout | FIXED for the recorded runtime carrier and fixed-word subset. VVP preserves each nested queue/dynamic/associative kind, queue-bound state, child layout, value-copy boundary, and mutation root. A fixed unpacked-array element may be a Q/D/A value or the tested D/Q and A/Q compositions; selecting the fixed word retains both ranks and evaluates its receiver index once. New recursive metadata is validated before scheduling while legacy images retain their legacy path. The repaired regression cluster passes 13/13 and the paired fixed-container reducer passes 2/2. General recursive aggregates, VPI/DPI closure for every shape, and broad bit-stream casts remain open. |
| 6.22.2 and 15.4.9 typed-mailbox methods | IMPLEMENTED; final focused validation pending. Statement and expression calls use the mailbox type's semantic equivalence relation for `put`, `get`, `peek`, `try_put`, `try_get`, and `try_peek`. A class typedef alias is admitted, nominally distinct classes are rejected, and distinct packed declarations that satisfy 6.22.2 remain legal even when they do not match under 6.22.1. Bare `mailbox` and `mailbox#()` retain the dynamic form. No passing mailbox count is claimed at this checkpoint. |
| 13.5 and 15.4.5-15.4.8 mailbox reference output | IMPLEMENTED; final focused validation pending. Retrieval calls retain an elaborated l-value rather than replacing it with an r-value. Target/runtime state captures the receiver and selector before a blocking operation and is intended to write direct scalar/string/real/object variables, packed selects, class properties, fixed words, and queue/dynamic-array elements. A successful try writes back; an empty try leaves its target unchanged. Associative-element reference lifetime and the coherent installed-tool reducer run remain pending. |
| Validation/application boundary | PROVISIONAL checkpoint. Proven focused results are VIF 8/8 in each harness with exact-main red proofs of 0/8 in both harnesses, parser recovery against exact golds, recursive containers 13/13, interface arrays 4/4, and fixed containers 2/2. Full legacy, JSON/VVP, negative, VPI, real-DPI UVM, OpenTitan, and Caliptra replays have not run for this increment. The recorded application baselines therefore remain OpenTitan 192 PASS of 530 classified rows and Caliptra Icarus 53/105 versus Slang 54/105 in its static census. |

The corresponding IEEE 1800-2023 rules are unchanged for the implemented
semantics. Its multidimensional-array text is numbered 7.4.4 rather than
2017's 7.4.5. See the
[session log](../session_logs/2026-09-02_parameterized_vif_recursive_containers_typed_mailbox.md)
and the paired-edition delta entry.

## 2026-09-04 dynamic root randomization callbacks

| Clause | Mechanism | Status | Evidence / remaining boundary |
|---|---|---|---|
| 18.6.2 / 18.6.3 / 18.11 | Dynamic root pre/post callbacks, including checker calls | PARTIAL | Runtime dispatch selects the actual class's independently nearest callbacks; direct nonvirtual calls stay static. Root pre runs before inline state capture; post runs only on successful solve. Paired 2017/2023 regressions cover sibling/inherited classes, parameterization, escaped identifiers (5.6.1), virtual method encoding (8.20), receiver identity, nested frames and null checker side effects. Enabled-member callbacks and simultaneous global constraints remain open; the real xbar now exposes the latter as a failing solve. See the [session record](../session_logs/2026-09-04_dynamic_root_randomize_hooks.md) for exact validation and limitations. |

## 2026-09-04 enabled random-member callback increment

IEEE 1800-2017 18.6.2/18.6.3, 18.8 and 18.11: enabled member pre callbacks
precede graph snapshots; posts use retained successful participants. Aliases,
cycles, callback-created edges, explicit selection, element modes and nested
automatic frames have paired regressions. Status remains **PARTIAL**, with
complete regression gates passing and both application classifications
unchanged (OT203 PASS, Caliptra52 PASS/GAP0). Simultaneous global constraints
remain open. See the [member callback record](../session_logs/2026-09-04_enabled_member_randomize_hooks.md).

## 2026-09-04 global constraint solver working increment

**PARTIAL; full repository gate and application comparisons complete.** IEEE 1800-2017
18.5.9/18.5.10 and IEEE 1800-2023 18.5.8/18.5.9 have an owner-aware joint
solver and bounded complete-tuple sampler. Declaration-order soft priority,
static identity, transaction rollback, and constrained randc stages have paired
regressions. Unsupported staged distributions and history/size bounds fail
explicitly on the new route. This does not complete these clauses or full DV.

Both editions 8.4/11.4.5/18.4: typed constraint handle identity and procedural
null-property case inequality. IEEE 2017 18.5.13 / 2023 18.5.12: guards retain
state/random/error classification under call selection. Both editions 18.3:
constraint case operators hard-error; associative state reads retain X/Z rejection.
State foreach shares the canonical active selection (2017 18.5.8.1/18.5.9;
2023 18.5.7.1/18.5.8), including static aliases and inactive ternary-arm typing
(both editions 11.6.1/11.8.2).

Build18 grounds inactive scalar storage before expression expansion while
retaining provenance, signedness, and X/Z errors. The existing nested-state UVM
test recovers from a 60s timeout to less than 0.3s. State distribution endpoints
now qualify for the existing exact sampler (2017 18.5.4; 2023 18.5.3); active
endpoint controls retain the documented fallback warning. All 58 direct checks,
the corrected legacy diagnostic case, and 166 JSON focus cases pass. Full gate5
passes: legacy 4621/4626 (0 failed, 2 NI, 3 EF), JSON 1515/0, VPI 103/103, negative
149/0, runtime invariants, and real-DPI UVM 355/0/0.

See the [session record](../session_logs/2026-09-04_global_constraint_solver.md)
for exact gates, review findings, explicit boundaries, and application baselines.

The final census diff retains all 203 OpenTitan PASS rows and summed compile
debt 2223; Caliptra remains 52 PASS / ICARUS_GAP 0 across all 105 unchanged rows.
Twenty already-failing OpenTitan runtime rows now reject joint dist/order earlier,
including all eight xbars at cfg.randomize. TL agent changes from timeout to
explicit failure. These are documented boundaries, not runtime completion gains.


**Independent-component follow-up, local gate and application comparison complete:** IEEE 1800-2017
18.5.9/18.5.10 and IEEE 1800-2023 18.5.8/18.5.9 now have complete projected
sampling per syntactically independent factor while retaining one global hard
problem. The 1024-tuple proof bound applies per factor. One unconditional hard
distribution on a canonical scalar/element is supported per factor, with
state-only weights and fully feasible ground ranges (2017 18.5.4; 2023 18.5.3).
Residual tuples are conditionally uniform. Unsupported soft/guarded/coupled
multiple distributions, active weights, partial range exclusion, and
solve-before fail explicitly. Three new paired families and 34 legacy focus
checks pass. Full gate: legacy4627/4632 (0failed,2NI,3EF), JSON1521/0,
VPI103/103, negative149/0, runtimeinvariants, real-DPI UVM355/0/0. The fresh
530-row OpenTitan comparison retains 203 PASS with no lost PASS; all eight xbar
runtime rows now time out after the earlier constraint boundary. There is no
completed application gain. The stored semantic_debt_count sum is 2221 versus
2223 solely because two pairs of diagnostics interleaved onto shared log lines;
warning/error tokens and compiler return codes match, so no semantic debt
improvement is claimed. Caliptra's 105 static rows are unchanged at52 PASS and
ICARUS_GAP0. The session record links the complete per-row/input/raw-log audit.

## Campaign process-execution increments (2026-09-08)

P03 targets only function-spawned `fork...join_none` child scheduling under
9.3.2/Table 9-1 and 13.4.4, in both IEEE 1800-2017 and IEEE 1800-2023.
Current status: IMPLEMENTED for this bounded scheduling fix; all required local
gates passed, with remote CI/merge still pending. The baseline executes
non-final children before parent suspension; the candidate retains the existing
queued process path for all genuine children while preserving synchronous call
continuations. Evidence and exact qualification status:
[2026-09-08 campaign](../session_logs/2026-09-08_continuous_campaign.md).
Empty-child preservation (P01), singleton process identity (P02), broader
process conformance, UVM qualification, application DV and formal remain
separate obligations.

P01: IMPLEMENTED for retaining direct null and empty parallel child statements
under 9.3.2/Table 9-1 (2017 and 2023). All required local gates passed at the
P01 campaign checkpoint; remote CI/merge pending. Join, join_any, join_none,
automatic/named/folded empty children and null assertion controls are covered.
Singleton identity (P02) remains separate and open. See campaign evidence.

P02: IMPLEMENTED for preserving singleton join/join_any process boundaries
in VVP (2017/2023 9.3.2, 9.6, 9.7, 18.14). All required local gates passed
at the P02 campaign checkpoint. Identity, RNG seeding, descendant controls and
suspend/resume/kill are covered. Non-VVP translation limitations remain;
remote CI/merge and broader process qualification are separate.


Z01A: IMPLEMENTED (bounded local scope; unmerged) for bounded canonical integral joint solve-before
stages (2017 18.5.9/18.5.10 and 2023 18.5.8/18.5.9). Exact component tables
support stage projection sampling within the existing 1024-tuple ceiling.
All required local gates and independent review passed; remote CI/merge
remain pending. Ordered dist, active randc, non-scalar stages, static-alias ordering
qualification, larger components and broader Z01 remain outside this claim.
See the campaign session log for separate edition evidence and limitations.


C01: IMPLEMENTED (bounded diagnostic correctness; unmerged) for rejecting untranslated inline constraint items
instead of accepting a partial randomize call (2017/2023 18.7). Both-edition
red runtime evidence confirms lost constraints on 8f298eefe. The candidate
passes paired focused rejection and supported/no-op controls. This is a
semantic-degradation fix, not implementation of the unsupported expressions.
All required local gates and review pass; remote CI/merge remain pending.
See campaign evidence.


L01: IMPLEMENTED (bounded local qualification; unmerged) for selected-prefix procedural member foreach
(2017/2023 12.7.3). The selected prefix is no longer redeclared and iterated;
only terminal loop variables are introduced. Both-edition lookup and traversal
controls pass, along with 53 legacy/34 JSON focused cases and unchanged Bison
automaton. All local semantic gates and review passed; fresh unmodified U01
replay confirms corrected routing and three checked responses. DD-002
associative string index typing is addressed by the later bounded L05 increment. U01 is
still open for the fourth-response stall; no application pass is established.

L02: IMPLEMENTED (bounded local scope, unmerged) for automatic block reentry and scalar event history
(2017/2023 6.21, 6.8 and 9.4.2). Candidate preserves distinct block frames
and ancestor-owned scalar history; all required local semantic gates and
review pass, including recursive event ownership. Unchanged U01 replay completes
115 requests and230 checked items; four sequence-parent warnings keep U01 open. General Boolean event-expression context
(DD-003) and silent-default edge initialization remain unqualified.

V01A: IMPLEMENTED (bounded local scope, unmerged), 2017/2023 19.11.3:
constructor-dependent unsized value bins contribute their exact registered
interval union to merged type coverage, including unsampled/retired instances.
Partial overlap/disjoint, threshold, signed and fixed/scalar controls pass all
required local gates. Parent V01 and general huge-total percentage calculations remain unqualified.
Default merge_instances averaging is separately qualified by V02 below.

V02: IMPLEMENTED (bounded local scope, unmerged), 2017/2023 19.7/19.11.3:
default type coverage averages eligible instances using option.weight, including
unsampled and retired objects; explicit merge mode and get_inst_coverage query
selection retain separate semantics. Native typed initializer assignments preserve
four-state conversion, lexical scope, parent methods and once-only constructor
actuals. Procedural get_inst writes are rejected per19.7; weight stays mutable.
All required local gates and review pass onac60732f3. Global type_option weights,
goals/strobe and remaining parentV01 obligations remain unqualified.

V03: IMPLEMENTED (bounded local scope, unmerged), 2017/2023 19.7.1 table19-3,
19.9 and19.11: declared covergroup type weights contribute to overall coverage
with existing eligibility exclusions; zero aggregate weight returns100. Typed
constant conversion and nonnegative domain are checked, and old VVP options
records remain compatible. All local gates/review pass on2be79b2c0. Coverpoint/
cross type weights and procedural static type-option updates remain unqualified.

S01 verification at `2be79b2c0`: the former blanket cross-clock overlapping
implication exclusion is superseded by fixed-chain support in `0ff77277c`.
Twelve focused runs cover both editions and both SVA modes, including coincident
edge order, later consequent ticks, sampling and nested flow. Broader multiclock
assertion qualification remains PARTIAL. Evidence: campaign-20260908/s01.

S03: IMPLEMENTED with reviewed local qualification (unmerged), IEEE1800-2017/
2023 16.12.7. Split NFA endpoint consequences aggregate truth per starting
implication attempt rather than dispatching each child verdict. Paired controls
cover mixed/forbidden consequences, vacuity, parent/child reuse, cancellation,
cover counts and strong EOS; required local suites pass including real-DPI
UVM355. Existing finite cyclic-pool limits remain; DD005 nonfanout vacuity and
S02 multiclock identity remain unqualified. Assertions as a whole stay PARTIAL.


S04: IMPLEMENTED with reviewed local qualification (unmerged),
IEEE1800-2017/2023 16.12.7 and16.14.1. NFA, fixed legacy, genvar delay,
symbolic repetition and fixed/OR/AND antecedents before parameter windows
execute previously omitted vacuous user pass actions. Shared Reactive dispatch
keeps them distinct from nonvacuous-success callbacks. Antecedent progress
and pre-match age counts avoid startup ghosts and repeated vacuity. Disable
level checks run in Observed; asynchronous cancellation recognizes integral
logical truth including nonunit values. Four paired reducers and callback
coverage pass with required full local gates: integrated4700/4695/0/2/3,
VPI104,negative149,runtime15,JSON1592 and real-DPI UVM355. Remote CI remains
required before merge.
Symbolic nonvacuous parent-verdict aggregation was separately tracked as DD-007
and is addressed by S05 below. Broader SVA, multiclock S02 and formal
qualification remain PARTIAL/open.


S05: IMPLEMENTED with reviewed local qualification (unmerged),
IEEE1800-2017/2023 16.12.7,16.12.22,16.14.1. Accepted parameter-valued
consecutive repetitions with fixed ##0/##1 Boolean consequences aggregate
one parent verdict: first failed child retires the parent; success waits for
antecedent closure and all pending children. Existing packed ages and mature
counts preserve overlapping starts and repetition-bound overrides without a
new attempt-pool cap. Direct empty nonoverlapped antecedents start their exact
consequence windows on the current tick; prefixed zero repeats retain their
nonempty endpoint timing. Empty-only overlap is rejected per instance; mixed
empty/nonempty overlap uses nonempty matches. Cover endpoint counting remains
separate. Four-state, Off/Kill, async/NBA cancellation, callback and delayed
Reactive action controls pass. All required local gates pass: focus14/14
legacy+JSON in both engines, NFA58/58, integrated4714/4709/0/2/3,VPI105,
negative149,runtime15,JSON1606,real-DPI UVM355, make check and independent review.
Remote CI remains required before merge. Symbolic consequent-delay overrides
DD-008, broader SVA/multiclock and the formal program remain unqualified.


S06: IMPLEMENTED with reviewed local qualification (unmerged),
IEEE1800-2017/2023 6.20.2,23.10.2,16.7 Syntax16-4,16.12.7 and16.14.1.
Single named parameter/localparam ##D preserves actual instance timing through
elaboration. Direct/prefixed symbolic bounded/unbounded repetition parents
use delayed sampled histories and one parent verdict; real-time unmatched
ages preserve vacuity. Overlap/nonoverlap empty timing, Off/Kill/disable
cancellation, fixed antecedent neighbors and cover endpoint counting have
paired controls. Native self-sizing retains signedness and width when a
preserved property operand receives a substituted actual. Invalid negative
original grouped operands and unknown bounds reject per instance.

Qualification: paired focus18/18 legacy+JSON in both engines; S05neighbors
14/14+14/14,S04neighbors17/17+8/8; NFA58/58; integrated4732total4727pass0fail
2NI3EF,VPI105/105,negative149/149,runtime15/15; JSON1624/0; real-DPIUVM355/0/0;
makecheck, unchanged Bison563SR/1122RR signature, final independent review.
Explicit reference controls check76assertion and76cover cases in each edition;
independent packed-vs-parent model checks9450traces/999810ticks.

This bounded qualification does not establish arbitrary delay-expression
syntax, broader formal lookup, composed/multiclock operators, maximal-width
delay arithmetic, application DV completion or formal-program completion.
Explicit unsupported-composition diagnostics are rejection coverage only.
Remote CI remains required before merge. Evidence: campaign-20260908/s06.


S07: IMPLEMENTED with reviewed local qualification (unmerged),
IEEE1800-2017/2023 16.8. Bare sequence aliases recursively expand copied
bodies rather than leaving nested parameterized calls for ordinary function
elaboration. Nested alias sequence names resolve in the alias declaration's
generate scope; substituted actuals preserve caller lookup. Active declaration
paths reject direct/indirect, branching and actual-self expansion cycles
before cloning further bodies. Repeated legal instances retain independent
copies and the existing depth safeguard remains.

Qualification: paired focus12/12 legacy+JSON in both engines; S06neighbors
18/18+18/18,S04neighbors17/17+8/8; NFA58/58; integrated4744total4739pass0fail
2NI3EF,VPI105/105,negative149/149,runtime15/15; JSON1636/0; real-DPIUVM355/0/0;
makecheck and final independent source/test review. Permanent controls cover
multi-level alias timing/cancellation/reuse, declaration shadowing, caller
actual scope, mutual/branching/actual-self cycles. Evidence: campaign-20260908/s07.

Complete global dependency-graph validation across separate instances,
pre-existing parameterized declaration-owned lookup and broader sequence
composition remain unqualified. Remote CI is required before merge.


L04: IMPLEMENTED with reviewed local qualification (unmerged),
IEEE1800-2017/2023 6.8 Table6-7,6.21,9.4.2. Automatic integral signal defaults
are published after all activation items exist, ownership is live and applicable
stack linkage is established, before argument/user writes. The optional
initialization hook covers ordinary allocations, virtual override calls,
DPI exports and continuous automatic function calls. Root frames remain roots.
Slot reset/default values are unchanged; native signal publication seeds
activation-specific event history, so unchanged partial zero writes no longer
manufacture negedges. Default X and real subsequent transitions are preserved.

Qualification: paired focus4/4 legacy+JSON; lifetime neighbors93/93+50/50,
mixedlifetime7/7+7/7,eventcontrols14/14+14/14; NFA58/58; integrated4748total
4743pass0fail2NI3EF,VPI105/105,negative149/149,runtime15/15; JSON1640/0;
real-DPIUVM355/0/0,makecheck and final independent review. Tests cover whole/
partial unchanged writes,0/X defaults,pos/negedges,concurrent/recursive frames
and reuse. Evidence: campaign-20260908/l04.

Derived Boolean activation state remains L03; other value types and broader
initialization obligations are not qualified here. Remote CI before merge.


L03: IMPLEMENTED with reviewed local qualification (unmerged),
IEEE1800-2017/2023 6.21,9.4.2. The shared Boolean functor family retains
per-activation operands and ancestor input history, combining parent and
child operands only within the correct activation. Post-link initialization
propagates derived baselines synchronously for the initializing frame;
ordinary evaluation remains queued Active with frame-owned pending flags.
No queued raw context survives frame reuse. Static truth functions are shared
without changing their scheduling.

Qualification: paired focus12/12legacy+JSON,L02neighbors93/50,L04neighbors4/4,
direct PART_PV pre-child history/untouched bits/live updates/frame reuse,
NFA58/58,integrated4760total4755pass0fail2NI3EF,VPI105/105,negative149/149,
runtime invariants,JSON1652/0,real-DPIUVM355/0/0,makecheck and final independent
review. Cases cover mixed parent/child operands,chained initialization,
concurrent/recursive activations,reuse and NBA coalescing. Evidence:
campaign-20260908/l03. BUF,NOT,mux and other expression families are unchanged
and remain unqualified by this increment; application/formal status remains
separate. Remote CI is required before merge.


L05: IMPLEMENTED (bounded local qualification, unmerged), IEEE 1800-2017
and 1800-2023 12.7.3: selected class-member foreach preserves the terminal
associative key type through both identifier and expression prefix paths.
Paired tests cover string order, signed narrow integral keys, class-handle keys,
inherited parameterized members, nested selection, outer-name preservation,
concurrent/reused automatic loops and terminal static dimensions. Existing
runtime selector binding is unchanged (12.7.1/12.7.3); invalid same-name header
selectors are recorded separately as DD-009. Selected-array non-member typing
and broader container obligations remain unqualified. All required local gates
and independent review pass; remote CI/review and merging remain outstanding.


V04: FIXED and verified on clean current main, IEEE1800-2017 and
IEEE1800-2023 19.11.3. Merged type-coverage ratios retain supported dynamic
family cardinalities and aggregate total/hit counts through128-bit arithmetic
before floating conversion. Distinct named wide families no longer inflate
coverage through64-bit saturation. Paired relative-error tests cover disjoint
unsampled/retired universes, unequal families, thresholds, static/dynamic bins,
weighted items and small/empty domains. All local gates and independent review
pass. The four V04–V07 registered reducers were re-run against clean
origin/main `af89cfc50be1084cc86c48865f3f6ba78d4512fa` and pass in both strict
editions (8/8 compile-and-run executions); this is local evidence, not CI.
Individual transition-family cardinality, broader cross/bin-universe
obligations and parent V01 remain separate.


V05: FIXED and verified on clean current main, IEEE1800-2017 and
IEEE1800-2023 19.6,19.11.3. Supported constructed automatic crosses contribute
the union of ordered component-bin names to merged type coverage. Shared hits
use canonical tuple identities rather than instance-local dense ordinals;
already-resolved active named properties also contribute. Paired regressions
cover overlapping/disjoint constructor domains, source-bin kinds and dimension
order, thresholds, named/ignore precedence, retirement, parent capture and
named/arrayed transition sources;2023-only retention is separately controlled.
Malformed plans publish no type denominator. All required local gates and
independent review pass. The 2026-10-08 clean-main recheck passes this reducer
in both strict editions; this is local evidence, not CI. Existing topology
limits, transition-family cardinality, unqualified type options and parent V01
remain separate.


V06: FIXED and verified on clean current main, IEEE1800-2017 and
IEEE1800-2023 19.7.1,19.10,19.11.3. Declaration-time coverpoint and cross
type_option.weight independently weights merged type coverage, with default1
and typed non-negative constant validation. Instance and merge_instances0
weighting remain independent. Group type weights do not become item defaults.
Typed formal aliases prevent outer-name capture while permitting constant
type queries and lexical outer constant functions. New tagged item metadata
preserves older VVP record interpretation and validates indices/weight bounds.
All required local gates and independent review pass. The 2026-10-08 clean-main
recheck passes this reducer in both strict editions; this is local evidence,
not CI. Procedural static option assignment and other type options remain
unqualified; DD-010 is addressed in V07 below. This does not close parent V01.


V07: FIXED and verified on clean current main, IEEE1800-2017 and
IEEE1800-2023 19.11,19.11.3. Never-instantiated covergroup types do not enter
cumulative coverage. The existing live registry and retired-options marker
preserve constructed populations independently of instance weights. Paired
no-instance, partial weighted scores, construction, static/dynamic cross and
transition sources, empty populations and retirement controls pass. All
required local gates and independent review pass. The 2026-10-08 clean-main
recheck passes this reducer in both strict editions; this is local evidence,
not CI. UVM evidence is actual-g2012 with real DPI; it does not qualify either
language edition or IEEE1800.2. Parent V01, remaining type options and broader
application/formal obligations remain open.


L09: IMPLEMENTED (bounded local qualification, unmerged), IEEE1800-2017 and
IEEE1800-2023 8.6 and13.5. Automatic function copy-out loads formal values
from the callee and evaluates actual destinations in the caller activation,
even while recursive calls stage other frames. Paired scalar,indexed,property
receiver,real,string,object,queue,fixed-array,inout/ref and virtual-call controls
pass; all required local gates pass at3c44fd13b. This does not qualify all
argument forms; scalar output into a fixed-array class-property element
remains DD019. UVM regression is actual-g2012 with real DPI, not IEEE1800.2
qualification. Required remote CI and merge permissions remain separate.


L11: IMPLEMENTED (bounded local qualification, unmerged), IEEE1800-2017 and
IEEE1800-2023 13.5,13.4.2 and default initialization rules. Native scalar
function output actuals are evaluated for return copying only. Automatic
formals use existing typed frame initialization/reset; static formals retain
their values. Return-time index side effects, repeated typed automatic defaults
and static retention pass in both editions. All required local gates pass at
b32df9a29. DPI import setup and input/inout/ref paths remain separate; this
does not qualify every argument form or the suspended L10 property-element case.


L10: IMPLEMENTED (bounded local qualification, unmerged), IEEE1800-2017 and
IEEE1800-2023 13.5,7.4.6,6.16 and6.22.3. Function output/inout values reach
fixed-array class-property elements using caller-context receiver/index
evaluation and typed stores. Numeric width/sign,two/four-state and real/integer
conversions, same-type strings/class handles, nonzero/multidimensional indices
and invalid-index effects are covered. Invalid writes are ignored with exact
diagnostics; string/non-string output variables require explicit casts through
temporaries and are rejected. All required local gates pass at051aeee8e after
L11. No general dynamic/associative element or complete argument qualification
is inferred; broader language/UVM/application/formal obligations remain open.


L13 at9baa5a9c3: IMPLEMENTED (bounded local qualification, unmerged).
IEEE1800-2017 and IEEE1800-2023 6.16,6.16.3 and6.11.3 require signed byte
results for character reads. The candidate preserves signed8bit results
through ordinary string and string-array indexing, assignment widening,
arithmetic and function inputs. Typed string parameter selection reads
left-to-right characters, including constant folding and runtime indices,
with zero for negative/after-end/empty reads. Untyped packed parameters and
packed bit/part selects retain unsigned bit semantics; unsigned contexts
still determine their expression conversions. Paired focused cases, neighbor tests and all required local gates pass.
The exact L13 blocker is closed; full string/edition qualification is not claimed. Class string-property index dispatch (DD025), constant-function
string evaluation (DD026) and the suspended struct-member blockerL12 remain
separate open scopes. No parent string/UVM/IEEE completion is inferred.


### L16 — Const class-handle member assignment (6.20.6)

Validated5ba60567f permits writes to existing mutable members through unindexed
scalar const class-handle variables, while retaining handle rebinding,
const-property and const value-aggregate diagnostics. Both-edition runtime
checks include aliases, identity, selected/compound/increment writes and
output/inout copy-out. Required local gates pass. Intermediate const
class-property traversal, const containers and general const qualification
remain separate; no full6.20.6 claim.

### L18 — Direct integral property compound signedness (11.4.1/11.8.1)

Validated9791e6411 preserves declared property signedness for division,
remainder and arithmetic right shifts in both2017/2023. Unsigned operands,
part selects and singleton scalar/property concatenations retain unsigned
semantics. Focused/neighbor tests, independent review and all required local
gates pass. This is bounded direct-property support; compound operand
width/state conversion (DD036), associative lowering and dynamic-array
property operations (L17) remain separately unqualified.

### L19 — Compound operand four-state preservation (11.4.1/6.11.2)

Validated72a97c038 retains RHS X/Z through integral compound operations before
converting the result for a two-state target. Both2017/2023 cover scalar and
direct class properties, arithmetic, bitwise known bits, unknown shift count,
RHS evaluation once, ordinary assignment and four-state destination controls.
The elaborator and direct-property target both had premature conversions. All
required local gates pass. Operand width remains DD036; full compound or
container qualification is not claimed.

### L20 — Compressed vector operation widths (11.4.1/11.6/11.8.2)

Validatedfe12166bd preserves natural/context operand width for integral
compound operations and uses self-determined shift counts. One target helper
sizes loaded operands before existing operations and truncates only the result.
Both editions test constants/runtime divisors and counts, signed/mixed
extension, context widening, unbased shift count, concatenations, direct
properties/parts, array index once and queue shifts. Required local gates pass.
Associative front-end expansion remains residual debt and L17 dynamic-array
property lowering remains separate; no blanket11.4.1 qualification.

### L21 — Captured class-root mutation preserves handle reassignment (8.4/11.4.1)

Validated1146d2187 checks current class-root identity immediately before
mutation notification delivery, after alias callbacks. A captured object's
mutation no longer writes its old handle back over RHS reassignment. Both
editions cover replacement/null, retained alias events, unrelated-property
filtering, unchanged root, plain container member and automatic-context cases.
Required local gates pass. Value aggregates/VIF roots are outside this bounded
change; no full alias/event or container qualification claim.

### L17 — Integral dynamic-array property compounds (11.4.1/11.6/11.8)

Validated d8e974913 captures array and index once, loads the integral element,
uses the validated shared compound-operation helper, and writes only a valid
index. Both editions cover arithmetic/bitwise/shifts, operand width/state/sign,
index side effects, negative/out-of-bounds/X/Z indices, neighbor preservation
and RHS handle rebinding. Array bounds references: 2017 7.4.6; 2023 7.4.5.
All required local gates and original UVM1.2 debug-crossbar smoke pass. This
qualifies the bounded tested whole-element cases, not full containers, real/
string compounds, IEEE1800.2 or the entire application suite.

### L22 — Built-in process state enum (9.7/6.19)

Validated4a102ee47 provides shared nominal process::state enum identity,
ordered FINISHED/RUNNING/WAITING/SUSPENDED/KILLED values, typed status()
and parenless status results. Both editions cover local/type-alias/function/
package/child-module use, enum name/iteration/count, signed width and explicit
casts; integer/unrelated-enum assignment rejection remains. Missing-root and
escaped-user-identifier regression controls pass. No runtime changes; all
required gates complete. Bare class-scoped module declaration grammar DD039
remains unqualified, as do full process control and legacy UVM applications.

### L23 — Blocking joins in function background children (13.4.4)

Validated58edf8034 uses existing isolated fork-depth context to permit join and
join_any within a function's join_none children. Both editions explicitly allow
task-legal statements there. Runtime tests verify immediate function return,
all-child and first-child completion, remaining-child cancellation and unrelated
sibling survival. Separate invalid functions called from a background child
still fail; all required gates pass. No scheduling/lifetime changes or full
background-process/UVM qualification claim.

### L24 — Void-function cast statements (13.5/A.6.9)

Validated795d9f360 permits the dedicated void'(function_call); form for a
resolved void function. Both2017/2023 grammar/prose interpretation was independently
reviewed; it is an inference, not an affirmative prose quote. Actual arguments,
output/ref copyback, empty-body argument effects and virtual dispatch are tested.
Task casts and void-function expressions remain illegal; all required gates pass.
Historical2005 acceptance and full subroutine/UVM qualification remain open.

### L25 — Function-name variable passed by reference (13.4.1/13.5.2)

Validatedc58035f49 materializes address-taken whole scalar integral return
variables in existing signal/context storage. Both2017/2023 tests verify aliases,
recursive automatic frames, static persistence, explicit return overrides,
four-state partial writes and detached-reference lifetime. All required gates pass.
No full subroutine/ref or nonintegral-return qualification; ordinary function
disable is prohibited by9.6.2 and remains outside this scoped correction.

### L26 — Independent nominal class defaults (8.25)

Validated e3666fd07 qualifies matching effective class-type parameters with
bare nominal class defaults across tested omitted/explicit/named/positional
and alias forms in both2017/2023. Tests verify object identity and shared static
state, with distinct actual/declaration owners and concrete forwarding controls.
Nested dependent defaults and arrays remain outside the new cache eligibility;
regression controls retain their existing elaboration behavior. All required
local gates pass. Explicit empty parameter slots, broader dependency graphs,
generic-seed initialization and full parameterization qualification remain open.

### L27 — Generic-master static initialization (8.25)

Validated8f2252dd3 prevents runtime static initialization of an unspecialized
generic master while retaining initializer analysis and const checks. Both
editions qualify unused generic/no side effect and exactly-once initialization
for tested concrete/default/static-only uses, ordinary classes and inherited
parameterized bases. All required local gates pass. Symbolically forwarded
seed-derived specializations remain unqualified; no fullclass/UVM claim.

### L28 — Direct forwarded type specialization initialization (8.25)

Validated77cce610b extends the static-initialization distinction to type actuals
whose bare formal lineage remains symbolic. Both editions test direct/multilevel
forwarding, bare dependent defaults, shadowed concrete typedefs, real cache reuse
and callback registration. All required local gates pass. Original1.0p1 runtime
smoke now passes; compile constraint/cast limitations remain. Nested type
expressions, forwarded value parameters and full class/UVM qualification remain
open; concrete identities and initializer analysis are preserved.

### L29 — Procedural block parser recovery (9.3.1/12.7.1 context)

Validated9229c24e7 restores abandoned procedural begin/fork scopes when error
recovery discards their parser carriers. Both editions retain syntax rejection,
with exact negative diagnostics and positive loop-local lifetime/label/foreach/
fork checks. All required local gates pass. This is bounded parser robustness,
not implementation of the malformed recording macro or a standards feature.
Foreach's own carrier recovery and complete parser recovery remain unqualified.

### L30 — Complete-class qualified module variables (6.18/8.23)

Validated34787868e permits direct member-type variable declarations at module
scope using existing class resolution. Both editions test nominal enum identity,
packed/unpacked shapes, comma initializers, inherited typedefs, concrete class
aliases and process::state beside module instantiation syntax. Invalid members
and incomplete/typeparameter prefixes remain rejected without a fallback type.
All required local gates pass; arbitrary nested/parameterized class syntax and
full class qualification remain open. Existing edition-specific restricted-prefix
contexts are not broadened by this increment.

### L31 — Associative compound expression typing (11.4.1/11.6/11.8)

Validated0a4e7d639 corrects associative element signedness and binary expression
width/state before final assignment conversion. Both editions cover signed
arithmetic, mixed unsigned operands, wide arithmetic, self-determined shifts,
four-state propagation, class properties and unsigned selections. All required
local gates pass. Key/receiver single-evaluation and full associative compound
qualification remain separate; this is not complete feature qualification.


### L43 — Procedural package imports (26.3, A.2.1.3, A.2.6-A.2.8)

IMPLEMENTED for the focused sequential-block/task/function/method declaration
subset: explicit and wildcard imports after local declarations resolve types
and values, including attributed imports. Late imports after executable or null
statements and direct conditional/loop imports are rejected. A legal import
produces no executable statement; an explicit null statement remains executable
for declaration-order checking. Both 2017 and 2023 modes pass focused semantic
checks. This is not full package qualification: the batch-level regression suite
remains pending under the user's approximately ten-feature cadence.

### L44 — Mixed-driver packed compound assignment (6.5, 11.4.1)

IMPLEMENTED for accepted static packed elements with disjoint procedural and
continuous drivers. Compound stores preserve other driven elements and subsequent
input changes in both 2017 and 2023 modes. Ordinary dynamic index and X-index
behavior remain covered. The legal mixed-driver dynamic-subpart elaboration gap
is OPEN as DD-021. Focused legacy 2/2 and JSON 4/4 pass; broad suites pending.

### L45 — Bare task name resolution failures (13.3, 23.8.1)

IMPLEMENTED diagnostic for a bare task call that remains unresolved after normal
lookup. Valid forward, upward, compilation-unit and implicit class calls are
covered separately in both editions. Qualified/class fallback paths remain OPEN;
this is not full subroutine or UVM qualification. Batch regression is pending.

### L46 — Indexed reads within a selected packed element (11.5.1)

IMPLEMENTED with focused validation for final indexed `+:`/`-:` reads with
valid fixed packed prefixes.
The selected element must remain the carrier for X padding at either boundary.
Legacy 1/1, JSON 2/2 and null/synthesis checks pass both editions. Write clipping,
invalid earlier prefixes, DD-023 and batch regression remain open.

### L47 — Wide indexed reads through system-task/function arguments (11.5.1)

IMPLEMENTED with focused validation in both editions: constant and dynamic wide
bases no longer alias low bits through VPI handles; partial reads retain X
padding, partial VPI writes preserve other bits, and monitor/callback behavior
on parent-value changes is checked. Legacy 3/3, JSON 6/6 and direct VPI tests
pass. Full VPI metadata and broad batch regression remain pending.

### L66 — Typed return-array element storage (13.4.1)

IMPLEMENTED for real/string fixed-array result element reads and writes and
real compound assignments. Scalar return opcodes are restricted to scalar
function-name variables; array results use emitted array storage. The paired
2017/2023 evidence includes automatic calls, invalid indices, result copies,
recursive frames and single index evaluation. Full Clause13 remains PARTIAL.
Focused evidence and pending broad qualification are recorded in the
[L66 session](../session_logs/2026-09-14_typed_array_return_elements.md); this
refinement does not extend the L64 broad qualification to the newer compiler.

### L67 — Packed-select increment/decrement expressions (11.3.6, 11.4.2)

IMPLEMENTED for the evidenced scalar packed-signal bit/part selections and
function-return storage. The update uses the selected type width, preserves
neighboring bits and selector identity, and sizes the yielded result afterward.
Both editions have focused evidence. Selected array/property receivers and
nested selections requiring an inner carrier boundary remain unsupported.
See the [L67 evidence](../session_logs/2026-09-14_packed_select_increment.md)
for exact scope and validation; full Clause11 and broad batch qualification
remain incomplete.

### L68 — Packed-select updates within fixed-array words

IMPLEMENTED for the evidenced fixed unpacked-array word bit/part increment
and decrement expressions. Array word and packed index identities survive
constant folding and are evaluated once; either invalid selector suppresses
the selected store. This supersedes L67's fixed-array receiver limitation.
Class-property and bounded inner-carrier cases remain open.
Array indexing references are 2017 7.4.6 and 2023 7.4.5; both editions use
11.4.2 and 11.5.1 for the update and packed select. See the
[L68 evidence](../session_logs/2026-09-14_array_packed_increment.md) for scope,
results and pending broad qualification.

### L69 — Packed-select updates within scalar class properties

IMPLEMENTED for the evidenced scalar integral class-property bit/part increment
and decrement expressions. The receiver is captured before the packed base is
evaluated, the base is evaluated once, and existing partial-property stores
preserve neighboring bits and typed invalid-selection behavior. Selected
unpacked-array properties remain unsupported. See the
[L69 evidence](../session_logs/2026-09-14_class_packed_increment.md); broad batch
qualification remains pending.

### L70 — Packed-select updates within fixed-array class-property words

IMPLEMENTED for fixed unpacked-array properties whose selected element is an
integral packed word. Receiver, canonical word index, and packed base are
evaluated once; the final atomic partial-word store preserves current neighbor
bits, declared ranges, typed invalid results, and signed/full-width unsigned
offset semantics. See the [L70 evidence](../session_logs/2026-09-14_class_array_packed_increment.md).
Broad batch qualification remains pending.

### L72 — Constant-function string character selection (6.16, 13.4.3)

IMPLEMENTED for the evidenced argument/local string character reads, with byte typing, getc(int) index conversion and preserved string values during evaluation. See the paired [L72 evidence](../session_logs/2026-09-14_constant_string_character.md); broad qualification remains pending.

### L71 — Nested scalar packed increment/decrement (11.4.2, 11.5.1)

IMPLEMENTED for retained nested selections rooted in scalar packed signals and function returns. Per-carrier bounds, single index evaluation and selected result typing are preserved. See [L71 evidence](../session_logs/2026-09-14_nested_packed_increment.md); broader receiver scope and batch qualification remain pending.

### L73 — Constant-function string character writes (6.16, 11.4.1, 13.4.3)

IMPLEMENTED for the evidenced local character writes, putc conversions, compound arithmetic, byte signedness and nonlocal-write rejection. See [L73 evidence](../session_logs/2026-09-14_constant_string_character_write.md); broad qualification remains pending.

### L74 — Runtime string character compound assignments (6.16, 11.4.1)

IMPLEMENTED for scalar string character compound arithmetic, with byte typing, captured int index conversion and existing putc bounds/zero-byte behavior. See [L74 evidence](../session_logs/2026-09-14_runtime_string_character_compound.md); broader receivers and batch qualification remain pending.

### L65–L74 qualification refinement — 2026-09-14

The bounded scopes above now have [joint local batch qualification](../session_logs/2026-09-14_compiler_batch_l65_l74_qualification.json). This supersedes their earlier pending-batch notes for the recorded candidate only; it does not expand receiver coverage or establish full-clause conformance.

### L75 — Scalar string-function-return character stores

IMPLEMENTED for plain and compound character assignments to scalar string return variables, with return-frame isolation and byte/index semantics. See [L75 evidence](../session_logs/2026-09-14_string_return_character.md); broader receiver forms and batch qualification remain pending.

### L76 — Constant-function string case conversion (6.16.4, 6.16.5)

IMPLEMENTED for toupper/tolower byte conversion and receiver preservation during constant evaluation. See [L76 evidence](../session_logs/2026-09-14_constant_string_case_conversion.md); other methods and broad qualification remain separate.

### L77 — Runtime scalar string-character increment/decrement

IMPLEMENTED for pre/post scalar and return-character updates. See [L77 evidence](../session_logs/2026-09-14_string_character_increment.md); other receivers and broad qualification remain separate.

### L78 — Constant-function string comparisons

IMPLEMENTED for compare/icompare ordering and operand preservation. See [L78 evidence](../session_logs/2026-09-14_constant_string_comparison.md); broad qualification remains pending.

### L79 — Fixed-array string-character stores

IMPLEMENTED within the [recorded scope](../session_logs/2026-09-14_array_string_character_store.md); broad batch qualification remains pending.

### L80 — Constant-function substr

IMPLEMENTED within the [recorded scope](../session_logs/2026-09-14_constant_string_substr.md); broad batch qualification remains pending.

### L81 — Fixed-array string-character compound stores

IMPLEMENTED within the [evidenced scope](../session_logs/2026-09-14_array_string_character_compound.md); array function returns and broad qualification remain separate.

### L82 — Constant string-to-integer conversions

IMPLEMENTED for the four methods using the [shared parser](../session_logs/2026-09-14_constant_string_integer.md); broad batch qualification remains pending.

### L83 — Fixed-array string-character increment/decrement

IMPLEMENTED within the [evidenced scope](../session_logs/2026-09-14_array_string_character_increment.md); other receiver kinds and broad qualification remain separate.

### L84 — Constant-function string-character increment/decrement

IMPLEMENTED within the [evidenced scope](../session_logs/2026-09-14_constant_string_character_increment.md); other receiver kinds and broad qualification remain separate.

### L75–L84 qualification refinement — 2026-09-14

The bounded implementations above now have [joint local batch qualification](../session_logs/2026-09-14_compiler_batch_l75_l84_qualification.json). This supersedes their earlier pending-batch notes for the recorded candidate without expanding receiver coverage or declaring full-clause conformance.

### L85 — Joint ordered distributions

IMPLEMENTED for the [recorded canonical scalar subset](../session_logs/2026-09-14_joint_ordered_distribution.md), with exact staged distributions and atomic graph rollback. Broader joint distribution families remain PARTIAL; local batch qualification is recorded below.

### L87 — Joint selected-element ordering

IMPLEMENTED within the [recorded fixed-array integral subset](../session_logs/2026-09-14_joint_element_ordering.md), including exact staged element identity and focused out-of-range diagnostics. Dynamic containers and other ordering families remain separate; local batch qualification is recorded below.

### L88 — Joint dynamic-array selected-element ordering

IMPLEMENTED within the [recorded constant integral dynamic-array subset](../session_logs/2026-09-15_joint_dynamic_element_ordering.md), with one proved size, canonical ordering, resize and index-identity checks. Other container/ordering families remain PARTIAL; local batch qualification is recorded below.

### L89 — Joint queue selected-element ordering

IMPLEMENTED for the [recorded constant integral/enum queue subset](../session_logs/2026-09-15_joint_queue_element_ordering.md), using proved bounded/unbounded queue sizes and canonical ordering stages. Other ordering families remain PARTIAL; local batch qualification is recorded below.

### L86 — Multiclock bounded delay-window antecedents

IMPLEMENTED for the [recorded finite delay-window subset](../session_logs/2026-09-15_multiclock_bounded_antecedents.md), retaining every endpoint and one verdict per parent across clock handoff, prefix evaluation and cancellation. Repetition and broader SVA remain PARTIAL; local batch qualification is recorded below.

### L91 — Finite Boolean multiclock repetition

IMPLEMENTED within the [recorded finite Boolean repetition subset](../session_logs/2026-09-15_multiclock_boolean_repetition.md), including legal empty alternatives and parent-level verdicts. Broader repetition and SVA remain PARTIAL; local batch qualification is recorded below.

### L90 — Enum container packed selects

IMPLEMENTED within the [recorded class-container selection subset](../session_logs/2026-09-15_enum_container_packed_selects.md), preserving enum nominal typing, selected vector state and captured partial updates. Broader receiver syntax remains PARTIAL; local batch qualification is recorded below.

### L92 — Fixed multiclock assertion control

IMPLEMENTED for the [recorded fixed-pipeline control subset](../session_logs/2026-09-15_fixed_multiclock_assertion_control.md), preserving pending attempts under Off and aborting them under Kill. Broader assertion control remains PARTIAL; local batch qualification is recorded below.

### L93 — Constant-function numeric string formatting

IMPLEMENTED within the [recorded scalar receiver subset](../session_logs/2026-09-15_constant_string_formatting.md). Other constant-function methods remain PARTIAL; local batch qualification is recorded below.

### L95 — Constant-function putc

IMPLEMENTED within the [recorded scalar local receiver subset](../session_logs/2026-09-15_constant_string_putc.md). Other method/receiver combinations remain PARTIAL; local batch qualification is recorded below.

### L94 — Finite grouped multiclock repetition

IMPLEMENTED within the [recorded flat finite-group subset](../session_logs/2026-09-15_multiclock_grouped_repetition.md), including empty composition and fixed-pipeline compatibility. Nested/unbounded groups and broader SVA remain PARTIAL; local batch qualification is recorded below.

### L85–L95 local qualification checkpoint

The [batch record](../session_logs/2026-09-15_compiler_batch_l85_l95_qualification.json) qualifies the eleven recorded subsets at `d45ee87ab`, including the [regression corrections](../session_logs/2026-09-15_batch_l85_l95_regression_repair.md). Broader clause and application scope remains open.

### L96 — Constant-function formal legality

IMPLEMENTED for the [recorded non-input formal checks](../session_logs/2026-09-15_constant_function_formal_legality.md), preserving runtime writable-formal semantics. Other constant-function requirements remain PARTIAL; broad qualification is pending.

### L98 — Generated constant-function legality

IMPLEMENTED for the [recorded declaration-scope checks](../session_logs/2026-09-15_generated_constant_function_legality.md). Runtime generated functions remain legal; broad qualification is pending.

### L97 — Nested finite grouped repetition

IMPLEMENTED for the [recorded nested multi-term group subset](../session_logs/2026-09-15_nested_finite_grouped_repetition.md). Nested ranged fixed consequents, unbounded groups and broader sequence operands remain PARTIAL; broad qualification is pending.

### L99 — Fixed string-array methods

IMPLEMENTED for the [recorded fixed-array receiver subset](../session_logs/2026-09-15_fixed_string_array_methods.md), including constant and runtime mutation. General container/VPI behavior remains PARTIAL; broad qualification is pending.

### L100 — Finite multiclock consequence alternatives

IMPLEMENTED for the [recorded acyclic consequence subset](../session_logs/2026-09-15_finite_multiclock_consequences.md), preserving existential consequence paths and universal antecedent children. Broader SVA remains PARTIAL; broad qualification is pending. This extends the L97 nested ranged consequence boundary.

### L102 — Plain multiclock finite consequences

IMPLEMENTED for the [fixed first-clock prefix subset](../session_logs/2026-09-15_plain_multiclock_consequences.md), extending L100 to sequence properties without implication vacuity. Ranged prefixes and broader SVA remain PARTIAL; broad qualification pending.

### L101 — Constant fixed-array string-character increment

IMPLEMENTED for the [recorded subset](../session_logs/2026-09-15_constant_array_character_increment.md). Broader clause coverage remains PARTIAL; broad qualification pending.

### L103 — Plain multiclock ranged first-clock prefixes

IMPLEMENTED for the [recorded subset](../session_logs/2026-09-15_plain_multiclock_ranged_prefix.md). Broader clause coverage remains PARTIAL; broad qualification pending.

### L104 — Constant mixed equality

IMPLEMENTED for the [recorded integral equality subset](../session_logs/2026-09-15_constant_mixed_equality.md). Broader expression coverage remains PARTIAL; broad qualification pending.

### L105 — Nonlocal constant-function values

IMPLEMENTED for the [recorded package/class-state rejection subset](../session_logs/2026-09-15_nonlocal_constant_function_values.md), preserving actual runtime state and legal constant inputs. Broader constant-function coverage remains PARTIAL; broad qualification pending.

### L96–L105 local qualification checkpoint

The ten recorded subsets have passed the [revision-scoped seven-gate checkpoint](../session_logs/2026-09-15_compiler_batch_l96_l105_qualification.json). This supersedes the pending broad-gate notes for those subsets above. Broader clause coverage and full IEEE1800/UVM/application qualification remain incomplete; remote CI for the new publication is separate.


### September 20 PR review refinement — partial, qualification pending

The [review/repair record](../session_logs/2026-09-20_pr_review_repairs.md)
reopens DD-040/042/043. Fixed-array foreach selector evaluation (§12.7.3),
constraint prefix resolution (§18.5.8.1), and static range-bin cross-with
value-tuple selection (§19.6.1.2) have local focused repair evidence.
The [restored candidate](../session_logs/2026-09-20_restored_baseline_qualification.json) passed local qualification.
The subsequent [recursive select-expression fix](../session_logs/2026-09-20_recursive_cross_with.md) has focused evidence pending batch qualification.
Explicit matches and arbitrary-sized value products remain outside that scope. The independent
2023 goal remains separate; paired generation-mode tests are recorded in
the linked evidence and do not establish full-edition support.

### September 20 grouped clocked implication consequent

Clause 16.13 / Annex A.2.10 remains PARTIAL overall. Grouping an explicitly
clocked sequence consequent now preserves the implication clock boundary; see
[paired focused evidence](../session_logs/2026-09-20_grouped_clocked_consequent.md).

### September 20 masked runtime memory synthesis

Synthesized simulation of runtime word selection with flat packed bit/part writes
now preserves unwritten bits and decoded word enables (7.4.6, 11.5, 10.4).
[Focused paired evidence](../session_logs/2026-09-20_masked_memory_synthesis.json)
covers constant/variable packed indices, masks and invalid addresses. Packed
multidimensional carrier subselects remain explicitly unsupported in this path;
synthesis support overall remains PARTIAL.

### September 20 variable fixed-array rows

The [paired row-assignment record](../session_logs/2026-09-20_variable_row_assignment.json)
adds procedural direct-signal row copies and patterns to the 7.4.6/7.6/10.4
PARTIAL implementation: selector and RHS snapshots, invalid-index behavior,
and NBA updates have runtime evidence. It does not qualify arbitrary
aggregate/function/delayed row assignments or the remaining synthesis reset path.

### September 21 state-selected fixed-array constraints

The [paired constraint record](../session_logs/2026-09-21_state_selected_fixed_array_constraints.json)
extends the PARTIAL 7.4.6/18.3/18.5 implementation to symbolic selections
of fixed integral class arrays. It records bounds, state errors, guard sifting,
wide state leaves, rollback, and negative solve-before evidence. Full batch
qualification remains pending; this is not general randomization qualification.

### September 21 reset-only synthesis

The [paired record](../session_logs/2026-09-21_reset_only_synthesis.json) adds runtime evidence for reset-only flip-flop hold behavior under9.2/10.4. Synthesis remains PARTIAL, including the separate asynchronous row-reset blocker.

### September 21 fixed-array row asynchronous reset

The [paired runtime evidence](../session_logs/2026-09-21_row_async_reset.json) covers generated row-index snapshots through asynchronous reset synthesis, including nested blocks and invalid selectors. Synthesis remains PARTIAL; batch qualification is pending.

### September 21 integral constraint casts and coupled distributions

Revision `969853350` extends the PARTIAL constraint implementation under
6.24, 11.6, 11.8.2 and clause 18 with integral cast IR and width/sign
evaluation through nested arithmetic, shifts, comparisons, fixed-array
indices and the tested inside expressions. Cast-context inside comparisons
use the common operand type; this is not a claim that all ordinary inside
contexts are repaired. Active X/Z queue elements fail with guarded state
validation and value/RNG rollback under 18.3; inactive guards remain legal.
Container elements wider than 64 bits are explicitly unsupported, and
queue-field state transport remains outside this repair.

The bounded coupled-distribution route extends the 18.5.4/18.5.10 subset
with exact staged projections, declared solve-before ordering and atomic
failure rollback. The projection bound remains 1024; requests beyond the
supported domain are rejected rather than sampled from a truncated prefix.
This does not establish all distribution, soft-constraint or probability
families. The [focused checkpoint](../session_logs/2026-09-21_constraint_cast_distribution_checkpoint.json)
owns paired-edition test evidence. Broad batch qualification is pending.

### September 21 procedural synthesis and full-width array indices

Revision `f5928785b` extends the PARTIAL procedural synthesis implementation
under clause 10.4: blocking assignments update the value seen by subsequent
expressions, while nonblocking assignments capture data and per-bit enables
for the later update. The exercised subset covers ordered assignments,
conditional/case paths, loops, partial writes, and asynchronous reset.
Dedicated memory-write ports preserve their write enables and old-value reads.
Untouched synthesized unpacked words preserve logic X and bit zero initial values.

Under 7.4.6, oversized constant fixed-array lvalue indices are checked at their
full width before canonical selection; invalid indices perform no write.
The existing checked-index helper consumes already-elaborated expressions.
The ordinary dynamic signal-index path remains unchanged.
The [focused checkpoint](../session_logs/2026-09-21_synthesis_and_wide_index_focus.json)
owns test scope and limitations. Required broad qualification remains pending;
this does not establish complete procedural synthesis or array support.

The [September 21 local batch qualification](../session_logs/2026-09-21_compiler_batch_qualification.json) records the completed regression gates for the documented batch subsets at `8ab943352`. Earlier pending-gate notes describe their dated checkpoints. Overall language and UVM support remain PARTIAL; publication CI is pending.

### September21 next-batch focused implementation

Clause18.12 scope randomization now rejects solver UNKNOWN without committing
values or process RNG state; see the [repair evidence](../session_logs/2026-09-21_scope_solver_unknown_fix.json).
Clause16.9.2 fixed antecedents use the existing age pipeline beyond the former
128-cycle restriction; see [runtime and cover evidence](../session_logs/2026-09-21_long_fixed_antecedent_fix.json).
These are implemented subsets with focused evidence, not broad qualification
or completion of either clause.

Clause18.5.12 class constraints now capture pure integral state-object method
calls, including nested receivers and virtual dispatch, with null/X rejection
and transactional failure. Indexed receivers remain unsupported. See the
[paired-edition focused evidence](../session_logs/2026-09-21_constraint_object_method_receiver.json); broad qualification remains pending.

Clauses5.13/6.19: enum `name` without parentheses now resolves to string in
concatenations through the shared type walker. See [paired focused evidence](../session_logs/2026-09-21_enum_bare_name_type.json); broad gates remain pending.

Clauses6.24.1/26 self-package type casts and19.5.1/19.5.7 signed static bin ranges now have focused implementation evidence. See the [cast record](../session_logs/2026-09-21_self_package_type_cast.json) and [coverage record](../session_logs/2026-09-21_signed_cover_range_resolution.json) for boundaries and pending qualification.

### 2026-09-21 packed VPI selection refinement

Clauses37/38.19/38.21/38.36.1 remain PARTIAL overall. Declared integral packed selections now have runtime-tested width, range, value and selected callback behavior; [paired evidence and explicit limits](../session_logs/2026-09-21_packed_vpi_integration.json). Full batch qualification is pending.

### September21 constraint arithmetic error refinement

Clauses11.3.4/11.3.5/18.3: division and remainder by zero now use guard-aware constraint error checks, preserving legal nonzero models and failure rollback. The [paired2017/2023 evidence](../session_logs/2026-09-21_constraint_divmod_zero.json) covers this implemented subset; broad qualification and overall clause completion remain pending.

### September21 joint cyclic ordering refinement

Clauses18.4.2/18.5.10: the joint solver supports implicit cyclic-variable priority followed by ordinary solve-before stages, including a single coupled ordinary distribution with prefix preflight. See [paired evidence and remaining limits](../session_logs/2026-09-21_joint_ordered_randc.json). The broader randomization requirements remain PARTIAL; batch qualification is pending.

## September 21 application foundation focused checkpoint

The [installed six-fix record](../session_logs/2026-09-21_shared_six_focus.json) records paired language-mode reducers for compound virtual-interface event expressions, continuous string assignments (6.5, 6.16, 10.3.2), directional variable output ports (23.2.2.3, 23.3.3.2), and ordered cyclic constraints with multiple distributions (18.4.2, 18.5.4, 18.5.10). These are focused implemented subsets with broad regression qualification pending; the surrounding requirements remain PARTIAL. String synthesis and solver support beyond the documented complete-enumeration boundary are not claimed. Runtime root-seed option spelling is vendor-defined; the strict-regex repair is pinned UVM API compatibility evidence, not a new IEEE language claim.

The [event runtime repair checkpoint](../session_logs/2026-09-21_event_runtime_regression_repair.json) adds focused evidence for automatic activation routing (6.21/9.4.2), NBA/Re-NBA expression settling (4.4/9.4.2), and initialized literal operands at the first event wait. Synthesis interactions and broad requalification remain open; no overall clause-status upgrade is made.

### September 21 fixed struct-member array constraints

The [focused implementation evidence](../session_logs/2026-09-21_spi_host_member_array_focus.json) covers one-dimensional fixed integral member-array leaves, declared-bound foreach (18.5.8.1), state and activation (18.3/18.8), and cyclic history/rollback (18.4.2). The enclosing requirements remain PARTIAL; broader qualification and unsupported aggregate paths remain open.

## September 21 descendant automatic VIF event initialization

2017 §§6.21,8.6,9.3.2: the evidenced descendant-event subset now reads the exact retained ancestor receiver during proxy initialization. Concurrent/recursive activations, rebinding, detached lifetime, reuse and true-null negatives have [paired focused evidence](../session_logs/2026-09-21_pwrmgr_descendant_vif_focus.json). Broader automatic/VIF semantics remain PARTIAL; required broad gates are pending.

#### 2026-09-21: §18.5.4 large integral distribution ranges

PARTIAL: exact weighted item and feasible-member sampling now has focused evidence for isolated ground integral subjects and provably singleton expressions. Coupled/non-singleton large expressions and wider arithmetic limits remain explicit boundaries. [Revision-scoped evidence and passing local gates](../session_logs/2026-09-21_exact_large_dist_focus.json). No full randomization qualification is claimed.

## September 21 synchronous mixed event dependencies

§9.4.2 remains PARTIAL overall. The automatic-local signal plus class-property event subset now has focused evidence for occurrence-time four-state expression comparison, transient pulses, selector/owner capture, equal-value rebinding, multiple mutation paths, cancellation, automatic contexts and Reactive arming. [Current revision-scoped evidence](../session_logs/2026-09-21_occurrence_event_focus.json) records paired editions and passing required local gates. The [earlier candidate](../session_logs/2026-09-21_mixed_event_focus.json) preserves the deferred-filter pulse failures. Existing mixed static/global and separate event-list diagnostics remain; compound VIF filtering is unchanged. This is not full-clause or full-application qualification.

### September 21 whole-function class event dependencies

IEEE 1800-2017 §9.4.2 remains PARTIAL overall. Integral event expressions using nonvirtual class methods now have [focused implementation evidence](../session_logs/2026-09-21_whole_function_event_focus.json) for member reads inside function bodies, nested receiver rebinding, container mutation and size changes, ordinary/static inputs, and class-valued factory receivers. Evaluation preserves value-change filtering and original selector/receiver evaluation order. This supersedes the earlier mixed static/global dependency limitation for the evidenced class observer path. Virtual-interface reads inside these methods remain explicitly unsupported; separate compound event lists and broader event-expression result types are not closed by this work. Required local qualification passes in the linked record; this does not close the full clause or application DV.

### September 21 compound class-property event lists

§9.4.2 remains PARTIAL. [Focused evidence](../session_logs/2026-09-21_spi_class_event_list_focus.json) covers atomic arming and value-change delivery for pure integral ANYEDGE lists containing class-property reads, including nested receivers and mixed ordinary operands. This extends the earlier separate-list boundary only for the recorded subset. Mapped UVM and permanent regression validation pass; broad qualification remains at the batch checkpoint. Other event families and full application DV remain open.

### Selected virtual-interface edge expressions — locally regression-tested

The 9.4.2/25.9 candidate implements selected packed VIF edge expressions through the synchronous observer, including live selector/rebinding dependencies, four-state edges and cancellation. Broader requirements remain PARTIAL; see the [revision-scoped evidence and completed local gates](../session_logs/2026-09-21_selected_vif_edge_focus.json).

### 2026-09-21 — implication until continuation candidate

The §16.6, §16.9.2.1 and §16.12.12 candidate corrects Boolean truth, zero-inclusive repetition concatenation, and continuing `until` obligations for the recorded implication subset. [Revision-scoped evidence](../session_logs/2026-09-21_until_continuation_focus.json) owns paired-edition checks, passing local gates and pending CI. Broader assertion support remains PARTIAL; this is not full clause qualification.

### 2026-09-22 — caller-owned integral collection constraints

§18.7 and §18.5.8.1 remain PARTIAL overall. Direct caller-owned integral queues and dynamic arrays now have focused paired-edition evidence for runtime foreach bounds, target-first lookup, explicit caller qualification, signed values, and failure without target writeback. [Revision-scoped evidence](../session_logs/2026-09-22_caller_queue_foreach_focus.json) owns the supported subset, diagnostics and completed local qualification. Compilation progress in pristine SPI does not qualify its DV suite.

### 2026-09-23 — inline constraint state-function calls

§18.5.12 remains PARTIAL. PR323 evaluates state-only caller, target, and self integral function calls after `pre_randomize`, retaining the target object and rejecting invalid four-state captures without writeback. Random-variable actual arguments require staged solving and remain unsupported; results wider than 64 bits also remain unsupported. [Focused evidence](../session_logs/2026-09-23_inline_state_function_focus.json) and the [later local qualification](../session_logs/2026-09-23_pr322_reconciliation.json) record the paired-edition scope; CI and complete clause qualification are separate.

### 2026-09-22 — caller-scope object methods in inline constraints

PR322's separate caller-only capture was removed during reconciliation because it bypassed null-receiver, X/Z, purity/direction and width checks. The guarded state-function path above handles the supported caller and target forms; indexed receivers remain unsupported. The retained caller tests pass on the [locally qualified follow-up source](../session_logs/2026-09-23_pr322_branch_reconciliation.json); CI is separate. [PR322's record](../session_logs/2026-09-22_inline_caller_object_method.json) preserves its historical results and narrower claims.

### September 23 scalar caller-state X/Z constraints

The PARTIAL 18.3 implementation now rejects active X/Z in ordinary scalar
caller-state slots for inline object and `std::randomize` constraints while
preserving inactive implication branches and previous rand values on failure.
The [paired-edition local evidence](../session_logs/2026-09-23_constraint_state_xz_port.json)
includes bit-64 X/Z and adjacent PR323 function-capture checks. Known
caller-state values wider than 64 bits remain a separate reproduced defect;
this does not qualify clause 18.3 as a whole.

### September 23 exact-size scope queue randomization

The PARTIAL §18.12 implementation now covers `std::randomize` on a local
one-dimensional integral queue when its inline constraints prove an exact
length, through 65536 elements. Declared queue maxima are honored; nonexact
and over-limit requests produce
an explicit diagnostic and preserve the original queue. Paired focused tests
and neighboring regressions are recorded in the
[revision-scoped evidence](../session_logs/2026-09-23_scope_queue_randomize_focus.json).
This does not qualify arbitrary queue sizing or clause 18.12 as a whole. The
pinned SPI Device compile advances past the queue diagnostic but still fails
on later vector-context diagnostics; no application compile or DV pass is
claimed.

### September 23 class-property queue pops

The PARTIAL §§5.13/7.10.2.4 subset now evaluates a terminal, unindexed
parenthesis-free `pop_front` or `pop_back` on a class-property queue using the
same typed result and mutation as an explicit call. Paired-edition tests cover
four-state elements, single removal, empty-queue default, and invalid arity.
The [revision-scoped evidence](../session_logs/2026-09-23_opentitan_queue_pop_focus.json)
records focused tests and the pinned SPI compile; broader gates and OpenTitan
DV remain open.
The [review boundary](../session_logs/2026-09-23_queue_pop_assoc_boundary.json)
also rejects queue pops on associative arrays (§7.9) in expression context
while preserving pops on queue-valued associative elements. The
[statement-method candidate](../session_logs/2026-09-23_assoc_queue_statement_methods_focus.json)
now rejects queue-only pop/push/insert methods on associative receivers while
positive queue controls retain their value and mutation checks in both editions.
Broad qualification remains open.

### September 23 parameter-valued SVA consequent repetition

The PARTIAL §§16.9.2.1/16.12.7 implementation now evaluates the focused
`start |=> keep[*W] ##1 finish` shape with each instance's exact parameter
bound. It preserves empty-repeat timing at W=0, a separate obligation per
antecedent match, four-state samples, vacuity, and `disable iff` cancellation.
The [revision-scoped evidence](../session_logs/2026-09-23_caliptra_param_consequent_repeat_focus.json)
owns the paired executable tests and pinned Caliptra formal-file compile.
Other symbolic consequent shapes, full SVA support, and Caliptra DV/formal
qualification remain open. The fixed-linear literal overlap correction is
scoped separately below.

The PARTIAL §§16.8/16.9.2.1/16.12.7 named-antecedent follow-up resolves a
declared one-step Boolean sequence before dispatching the same per-instance
symbolic-consequent checker. [Paired executable and pinned ECC formal-bind
evidence](../session_logs/2026-09-23_caliptra_named_sequence_antecedent.json)
passes locally. Multi-step named antecedents with symbolic consequents remain
loudly unsupported; broad gates, CI, and full Caliptra DV/formal qualification
remain open.

### September 23 fixed-linear SVA overlap verdicts and VPI identity

The PARTIAL §§16.12.7/16.14.1 subset now dispatches one failure action for
each distinct fixed non-negated consequent attempt, even when multiple
attempts fail on one sampled edge. X/Z sampled guards are definite nonmatches;
same-attempt checks do not duplicate a verdict. For this subset, §39.4.2
failure callbacks carry the actual raw-time start across irregular clock
intervals, Off gaps, Kill, and simultaneous failures. Paired 2017/2023
regressions and required local gates pass in the [revision-scoped record](../session_logs/2026-09-23_sva_literal_overlap_attempt_identity.json).
Window, unbounded, negated, and other checker families retain their previous
VPI metadata path; full assertion and formal qualification remain open.

### September 23 long finite SVA sequences

The PARTIAL §16.7 fixed-sequence checker now keeps its antecedent capture name
distinct from indexed consequent-step registers. [Paired executable
999/1000/1001-step evidence](../session_logs/2026-09-23_caliptra_long_sequence_register_focus.json)
checks sampled pass and failure actions in both selected editions. The clean
pinned Caliptra PM formal filelist [compiles on the locally integrated
tree](../session_logs/2026-09-23_caliptra_pm_integrated_compile.json) in both
editions; no formal proof, DV runtime, or general SVA qualification is claimed.

### September 23 class-event triggered state

The focused §15.5.3 candidate reads `.triggered` from each class instance's
own event, gives it one-bit type and current-time-step persistence, and
rechecks `wait` on either the event or its handle changing. [Paired local
evidence](../session_logs/2026-09-23_opentitan_class_event_triggered_focus.json)
covers trigger order, isolation, compound waits, cancellation, null-handle
rebinding, and invalid members. The pinned OpenTitan SPI compile advances but
still fails on other mechanisms. Explicit `triggered()` call forms have a
separate candidate below. Multi-object class-event lists have a separate
focused candidate below. Full clause 15 remains PARTIAL.

### October 14 explicit `triggered()` calls

IEEE 1800-2017 and 1800-2023 §15.5.3 both define `function bit triggered()`;
the null-event boundary is: “If the named event is null, then the triggered
method returns false.” [Paired T0/T1 evidence](../session_logs/2026-10-14_explicit_event_triggered_calls.json)
covers explicit calls on named events and an indexed event-array element,
static and per-instance class events, null named/class events, one-bit result
width, same-time-step waits, expiry after time advances, extra-argument errors,
and a non-event receiver error. The class-event focus passes 28/28 legacy and
28/28 JSON/VVP cases; the neighboring named-event focus passes 6/6 in each
harness. This candidate covers the explicit call syntax subset only; it does
not qualify the rest of §15 or clear the separate merged-event and `wait_order`
gaps. PR #583 is pending T2 integration.

### September 23 static and automatic named-event triggered sensitivity

The bounded §9.4.2/§15.5.3 update makes `.triggered` sensitivity work for
static and automatic named events. The [revision-scoped integration log]
(../session_logs/2026-09-23_inside_array_named_event_integration.json) records
paired checks and a successful released AON compile. Its smoke timed out after
60 seconds without a UVM verdict. A separate bounded time trace reached about
416 us, so the timeout is not evidence of a zero-time spin. The timed-out VVP
artifact predates the final variable-only rename in `vvp/vthread.cc`. No AON DV
result or full clause qualification is claimed.

### October 15 bounded `wait_order` subset

IEEE 1800-2017 and 1800-2023 §15.5.4 share the ordered-trigger, out-of-order
failure, repeatable preceding-event, and persistent-first-event rules. Paired
`sv_wait_order_2017`/`sv_wait_order_2023` tests cover same-slot order, repeated
preceding triggers, out-of-order `else`, first-event persistent state,
single-event persistent state, nonblocking triggers, automatic event contexts,
and cancellation. A separate paired
`sv_wait_order_duplicate_interpretation_{2017,2023}` test pins Icarus's current
handling of duplicate identifiers; §15.5.4 does not define that behavior, so
the fixture is explicitly an implementation interpretation. The pre-entry
fixtures apply §15.5.4's requirement that
subsequent events be untriggered: a later event whose trigger remains
persistent when `wait_order` begins causes failure, while the first event may
use its persistent state.
The default-failure fixtures cover both editions. Empty `else` is rejected in
2017 and accepted in 2023, matching the edition-specific grammar. Current-head
T0 Slurm job 1412 on `51ee4ff8bb745d87f243fa39b0550e27a160019d` passed all
6/6 legacy and 6/6 strict JSON/VVP cases plus smoke (compiler 56/56, VPI
131/131, negative tests 152/152); Slurm recorded `ExitCode=0:0`. Its GCC
15.2.0 build took 2:23.42 and peaked at 1,757,876 KiB RSS. Added coverage
checks automatic-event invocations with opposite expected outcomes, one trigger
that completes one waiter and fails another, and cancellation followed by a
fresh invocation. Graph-selected T1 Slurm job 1265 passed 10/10 legacy and
10/10 JSON/VVP cases on implementation commit
`15ca10f07500caae118ddd998d8b9351f7c1e8de`; implementation code is unchanged
since that run. Exact-head Fast Linux run 38817316300 passed. Windows lanes and
batch T2 remain pending; the `ivl.def` target API export requires Windows
validation before merge. Full logs and the source archive hash are retained in
`~/codex-supervisor/evidence/a3-m5-issue441-review-20261015/job1412/`. This is
focused `wait_order` evidence, not full §15 qualification.
Event-variable assignment/merging (§15.5.5.1), event arrays, and class-event
operands remain outside this implementation's scope.

### September 23 constant unpacked-array membership

The §11.4.13 ordinary-expression subset now expands constant unpacked parameter
arrays recursively to singular set members and compares integral values with
the existing asymmetric wildcard semantics. The shared 2017/2023 scope and
focused results are recorded in the
[revision-scoped integration log](../session_logs/2026-09-23_inside_array_named_event_integration.json);
no edition-specific difference was observed. Constraint-context array
membership remains unsupported at one pinned SPI Device site. The queue
unpacked-array concatenation compile errors are a distinct §10.10 backlog item,
not covered by this inside-set implementation.

### October 13 tolerance-range edition boundary

IEEE 1800-2017 §11.4.13 has no `[A +/- B]` or `[A +%- B]` forms; they are
introduced by IEEE 1800-2023 §11.4.13. The paired
`sv_tolerance_range_2017`/`sv_tolerance_range_2023` fixtures pin the older
edition's compile rejection and the 2023 absolute/relative bounds, signed and
unsigned behavior, real values, truncation, and a covergroup-bin range. This
is a focused syntax and range-semantics result, not full §11.4.13 qualification.

### September 23 associative find_index and multi-object class-event lists

The focused §7.12.1 candidate traverses an associative array's actual ordered
keys for `find_index`, returns a queue of the declared key type, and evaluates
the `with` predicate against each selected value. Integral and string keys,
including sparse, signed, high-bit, empty, and class-property receiver cases
have [paired local evidence](../session_logs/2026-09-23_opentitan_assoc_find_index_multi_object_focus.json).
Wildcard/object keys and other associative locators remain loud unsupported
boundaries. The §15.5 candidate gives each class-event leaf in an explicit
multi-object event list its own per-instance waiter and joins the one-shot
waits; first/second object, duplicate, repeated, and static-event controls
share the same evidence. Both fixes merged in PR341; broader clause and
application qualification remain open.

### September 23 CSRNG interface arrays and nested power-of-two constraint sampling

The parser now accepts the pinned CSRNG same-name interface-array declaration
and indexed interface reference shape under §§3.13 and 28.3.5. The focused
parser fix is locally committed at `6410b956c` and awaits publication; the
unchanged CSRNG source now advances past its
former `tb.sv:85` syntax error but still fails elaboration on a separate
hierarchical `BlkLen` indexed-part-select width use. A narrowly selected
[pinned-release overlay](../release_overlays/README.md) preserves the 128-bit
assertion width and compiles, but its configured smoke aborts at
`vvp/array.cc:483` before UVM. This is parser and compile evidence, not broad
interface or CSRNG qualification.

The PARTIAL §§18.5.10/18.6.3 solver subset samples isolated nested constraint domains
whose complete legal cardinality is a power of two, including a full 64-bit
domain. The [revision-scoped evidence](../session_logs/2026-09-23_opentitan_spi_csrng_next.json)
records the bounds, over-cap and irregular-domain controls, unsatisfiable
rollback, and pinned replays. The fix is locally committed at `df9f167f4` and
awaits publication. The SPI flash
smoke advances past its former JEDEC 1024-tuple cap but fails later on a
separate large-range exact-`dist` call; arbitrary uniform sampling and full
clause or OpenTitan DV qualification remain open.

### September 24 fixed-array virtual-interface task inputs

The PARTIAL §§7.6, 13.5.1, and 25.9 subset copies a compatible whole
one-dimensional packed-integral fixed unpacked array into the selected
virtual-interface input task. [Paired 2017/2023 evidence](../../../evidence/opentitan-otp-vif-fixed-input-20260924/README.md)
checks automatic and static tasks, instance selection, declared element order,
four-state values, caller isolation, mismatched actuals, and loud unsupported
directions/defaults/multidimensional forms. The pinned OTP top now compiles,
but its first released smoke fails a separate time-zero padded memory-path
check. This is neither OTP DV success nor full subroutine/interface
qualification.

### September 25 direct owner-held inline randomize receiver

The PARTIAL §§18.7, 18.7.1, 18.6.1, and 18.6.3 subset now resolves a direct,
unindexed owner-held receiver spelling such as `req.randomize() with {
req.clen == 12; }` to the randomized object's member when target-class name
lookup does not claim `req`. Paired strict 2017/2023 legal and invalid-member
tests pass 4/4 in both legacy and JSON runners; distinct caller state,
`local::` qualification, target-class shadowing, and failed-solve rollback
are checked. [PR #366](https://github.com/dsellerbrock/iverilog-uvm/pull/366)
and its [revision-scoped evidence](../../../evidence/opentitan-csrng-inline-receiver-20260925/README.md)
record the full gates and pinned replay. Same-object alias identity and an
explicit-`this` caller fallback still fail separate strict reducers (DD-059/60),
so neither edition's full inline lookup semantics are QUALIFIED. The pinned
CSRNG smoke remains 0/1 released nonstandard compatibility DV at a later AES
assertion.

### September 25 net-array Preponed history for whole-array assertions

The PARTIAL 2017 §§7.4.3, 16.5.1, 16.9.3, and 16.12.7 correction gives
net-backed integral fixed unpacked-array words their underlying wire's
first-write history when a concurrent assertion samples a whole array.
The paired 2023 boundary uses §7.4.6 and the same assertion clauses.
An input changing after the antecedent's Preponed sample no longer changes
its `$past` value; a scalar share, a second array word, a deliberate bad
update, a held force, and two strength-resolved net words are independent
controls. [Strict RED and final
evidence](../../../evidence/opentitan-csrng-aes-final-round-20260925/README.md)
also show the unchanged pinned CSRNG smoke reaching one checked nonstandard
compatibility pass. Other array kinds and a force transition within the
sampled slot are not qualified by this focused fix.

### September 25 §19.5 covergroup constructor method endpoints

The PARTIAL 2017/2023 §19.5 subset now captures an integral bin endpoint
returned by an automatic method on a direct non-ref constructor formal once
per covergroup instance, before resolving dynamic bins. Strict mode checks
the method body and effective default arguments for constant-state purity;
mutable and impure endpoints reject, while ref, unresolved, and invalid
forms remain loudly unsupported. Paired
positive and negative reducers pass 34/34 in each legacy and JSON harness.
Nested receiver paths remain unsupported in strict mode when their
const-state legality is unproven. The pinned OTP nested RAL path runs only
under explicit `-gcommercial-unsafe`, which warns and skips the purity proof;
its 1/1 released smoke result is nonstandard compatibility evidence, not
§19.5 conformance or proof of a functional coverage hit. See the
[revision-scoped record](../../../evidence/opentitan-otp-cover-bin-method-20260925/README.md).

### September 25 packed bitwise coverpoint expression shape

The PARTIAL IEEE 1800-2017/2023 §§11.6–11.8 and 19.5 subset now recovers
the self-determined width and signedness of a packed class-property bitwise
coverpoint expression at declaration time. Paired strict reducers retain
explicit zero and nonzero bins, distinguish masked-only and high-bit samples,
and check mixed operand widths and signedness; invalid `[$:$]` rejects and
over-64-bit bins remain loudly unsupported. [Revision-scoped
evidence](../../../evidence/opentitan-lc-packed-coverpoint-20260925/README.md)
records the tests and the pinned LC_CTRL unsafe replay. The pinned target still
has four independent hard compile errors, so this is not released DV progress
in the 49-row numerator. X/Z samples hitting ordinary bins are separate
unresolved debt (DD-063); no complete functional-coverage qualification is
claimed.

### September 27 complete string case comparison

The PARTIAL §§6.16 and 12.5 subset compares complete normalized string
values for homogeneous string `case` and `unique case` items at run time and
inside constant functions. The paired strict 2017/2023
`sv_string_cast_width_and_case` test distinguishes `write` from `xwrite`,
checks equal, empty, and zero-byte-normalized strings, and preserves an
explicit narrow integral cast. Mixed-type and `casex`/`casez` paths are
outside this correction. [Revision-scoped evidence](../session_logs/2026-09-27_string_case_and_ranged_size_focus.md)
records `51c424cf2` and the combined gate checkpoint; neither complete
string semantics nor every case form is qualified.

### September 27 fully feasible ranged scope queue sizes

The PARTIAL §§7.10.1, 18.5.8.1, and 18.12 subset of `std::randomize` on a
local one-dimensional integral queue now checks each candidate size after
expanding `foreach` and direct element constraints, then samples from the
proven feasible set. This supersedes only the September 23 nonexact-size
boundary above. A guarded read past the candidate size is accepted when the
hard constraint is proved independent of the absent element; a read whose
type-specific default could matter remains explicitly unsupported. Declared
queue bounds and exact fixed oversize diagnostics are preserved, and failed
calls leave the original queue and RNG state intact.

The ordinary candidate window is 0–1024. A complete sparse domain of at most
64 larger candidates may be checked if their total expansion is at most
16,384 elements; the allocation cap is 65,536 elements. These are Icarus
implementation limits, not IEEE bounds. Unproved larger ranges fail loudly
without sampling a narrowed distribution. The paired fixture retains an
earlier dynamic-array range control; `1838970aa` changes the local-queue
solver path only. [Revision-scoped evidence](../session_logs/2026-09-27_string_case_and_ranged_size_focus.md)
records the focus and completed gates. Real-DPI UVM passed 358/358 with zero failures or skips. Application
replay and general clause-18 qualification remain open at this checkpoint.

### September 27 exact packed indices in constraints

The PARTIAL IEEE 1800-2017 §§7.4.1, 7.4.6, 18.3, and 18.5 subset (2023
§7.4.5 for the invalid-read table) now interprets constant packed
constraint indices by their declared width and signedness. Signed narrow
negative indices select negative packed bounds, while unsigned high values
cannot wrap into those bounds. Ascending and descending ranges retain their
bit-offset orientation; reversed part-select endpoints reject explicitly.
A 29-case scratch corpus passes 29/29 in each strict edition on the
build-tree compiler. Paired strict 2017/2023 fixtures include exact
negative-index values, symbolic `[N:0]` bit selection, a valid
array-method iterator part, and six unsigned-high/reversed-range negative
controls across direct packed properties and a foreach index. All six
unsupported items produce source-line diagnostics. The VVP `(part)`
evaluator no longer leaves invalid or out-of-bounds selects as free solver
bits. A paired compile-error control pins an array-method iterator's
reversed packed select. Typed `bit4` IR guards symbolic four-state bit
reads against invalid indices; constant four-state OOB indices are
diagnosed in the frontend and fail randomization, while two-state bit
reads stay zero. A signed-width correction keeps narrow positive indices
valid. Paired logic/bit controls cover constant and symbolic OOB indices,
an underlying logic enum vector, narrow signed positive and negative
indices, failure rollback, and a guarded inactive read. Both constant
and symbolic OOB bit reads are checked against one to prove their zero
value. A paired typed-caller fixture checks unrolled/dynamic foreach
indices, typed associative keys, and packed-struct iterator/local
selects with valid and OOB logic/bit controls. A paired packed-array
member control selects constant elements exactly and diagnoses symbolic
nested selections. A scratch caller-state select also rejects a symbolic
OOB logic bit read. The focused JSON run, including nearby fixed-array
controls, passes 20/20. Slang independently
rejects the invalid constant fixtures, but is differential evidence rather than
standards authority. Symbolic nested packed selections remain explicitly
unsupported; item diagnostics name source lines rather than exact
index/range reasons. Broad gates and application replay remain pending
after this focused build-tree checkpoint.
General clauses 7 and 18 remain PARTIAL.

### September 29 typedef-only concrete class static initialization

The PARTIAL class subset now reaches a concrete parameterized specialization
named only by a typedef. Paired 2017/2023 controls cover explicit and bare
default actuals, class-scoped and nested aliases, package-qualified overrides
in distinct module instances, and later handle use. Each concrete registry
initializer runs once; generic masters and false-generate branches remain
lazy. IEEE 1800-2017/2023 §§8.25, 8.9, 6.8 and 10.5 govern the type identity
and static initialization. At `56f4bc756`, the [revision-scoped gate
record](../session_logs/2026-09-29_ot_otp_typedef_only_static_init.json)
reports JSON 4117/0, legacy 6875 total/0 failed, VPI 140/140, negative
154/154 and real-DPI UVM 361/361. The selected 282-source OTP compile emits
one concrete factory initializer without the explicit-registration overlay;
its DV runtime and the 49-target census remain unverified. Chapter 8 remains
PARTIAL.

## 2026-10-06 uniform legal-combination sampling

IEEE 1800-2017 §18.5.10 and IEEE 1800-2023 §18.5.9 remain **PARTIAL**. Paired
strict 2017/2023 regressions cover coupled direct scalar properties, fixed
unpacked bit arrays declared with two and 129 elements, a 2×2 fixed array, and
bounded variable-size direct integral/enum arrays, including size zero and two
correlated arrays. A sparse three-value enum array with size one or two now
samples the 3:9 complete-tuple ratio at 29/91 out of 120; before fix 6 its
short/long counts were 67/53 out of 120. Enum legality is enforced for synthesized active
elements, while inactive padding remains canonical zero.
The 129-element oracle constrains two leaves and projects five legal tuples;
the old fallback sampled mode one 155/500 times, while the new bins are
91, 119, 90, 98, and 102/500. The 2×2 oracle has 17 tuples; its old mode-one
bin was 267/1,000 and all new bins are 48–69/1,000. Direct fixed integral/enum
arrays sample referenced leaves without a declared-extent cap; unreferenced
leaves remain independently prefilled. The variable-size sampler enumerates feasible sizes and
canonicalizes inactive padding with a combined maximum of 512 elements. The
size-128/size-129 dynamic-array oracle yields 91/209 out of 300; before the cap
extension the size-128 mode appeared 139 times. The size-256/size-257 oracle
yields 44/76 out of 120, compared with 166/134 in the pre-fix probe. Connected wide scalars are included
for connected scalar properties wider than 64 bits. Complete feasible unary
domains up to 256 values are enumerated; larger connected domains use uniform
full-width proposals and hard-solver rejection. A 129-tuple 65-bit oracle's
128-value branch was sampled 520/1,000 times before the cap increase and
196/200 afterward in both editions. A dense 2⁶⁵-tuple oracle now selects the
larger mode 200/200 times, versus 150/200 before full-width rejection. The paired
65-tuple
64:1 oracle passes with a 90/100 minimum after failing at 49/100 with the former
64-value cap. Ordering, `dist`, soft constraints, static or unconstrained randc widths above
20 bits, graph-coupled wide randc forms without a reachable constraint reference
to the direct scalar property, sparse randc domains that exceed the proposal budget, aggregate
randc forms, larger aggregate domains, wide scalar cases that exceed the
boundary query budget or 4,096-bit width, fixed-array ranks above three and
other container shapes remain open. An isolated 33–4,096-bit scalar uses exact boundary searches
under a 131,072-query per-randomization budget; the paired contiguous 65-bit `[1:1024]` bins are 57, 54,
37, and 52/200. The unequal-range union test keeps four equal-cardinality bins
within 30–70/200 in both editions. The historical nine-run 33-bit scalar
oracle requires each equal-cardinality bin to stay within 12–48/270 in both
editions; a seeded standalone 270-draw run produced 31, 27, 33, 38, 23, 25,
29, 33, and 31. A focused standalone reducer matching the current 33-run
regression passes in both editions with all bins 1–22/300. Fix 12 adds up to
64 uniform full-domain proposals before interval counting and retries up to
65,536 times if exact boundary search becomes indeterminate; persistent
uncertainty fails explicitly instead of falling through to biased diversity
optimization. The dense periodic 33-bit regression gives three equal legal
classes counts 100, 89, and 111/300, versus 73, 74, and 153 on the old
fallback. The full registered uniformity suite and adjacent rollback and
solve-before controls pass in both editions on source-built ARM64 VVP
`2c1dfe0ad2e2a82d6033192712131bc965cb82d8c7e3d6ff0790730c464a6970`. See the
revision evidence for runtimes and the histogram.
A 2×2×2 fixed-array oracle samples nine
complete legal tuples within 12–55/300 in both editions.
See the [revision-scoped evidence](../../../evidence/solve-before-array/uniform-legal-combinations-20261006.md)
and the historical
[`dynamic_array_order.sv`](../../../evidence/solve-before-array/dynamic_array_order.sv)
result. The paired 2026-10-16 sparse-size follow-up checks six equal tuples
across sizes 1 and 3, a contradictory size request with rollback, and the
512/513 boundary; T0 passes the targeted legacy/JSON cases 2/2 each and T1
passes neighboring dynamic-array suites 10/10 in both runners. See the
[revision-scoped record](../session_logs/2026-10-16_dynamic_array_sparse_size_uniformity.md).
No broader clause-18 qualification is claimed.

Fix 13 adds an exact constrained-randc fallback for direct scalar properties
within the existing 20-bit history limit. It proposes values uniformly over
the bit-vector domain, accepts only values allowed by the hard solver and
cycle history, and uses a SAT check to prove cycle exhaustion before staging a
reset. The paired strict 2017/2023 regression completes two 128-value cycles
with an unsatisfiable randomize call between them to verify rollback. Adjacent
struct, solve-before, and failure-rollback controls pass. This focused result
uses source-built ARM64 VVP SHA-256
`94916a850cacd433ec7e2fc52306947eab0f2360ce4de7cb91f09ff9ef8cd8b6`; the full
registered suites were not rerun on this image. The sampler fails explicitly
if solver checks are indeterminate or 65,536 proposals do not find a value.
Widths above 20 bits, sparse proposal exhaustion, and aggregate randc shapes
remain open.

Fix 23 extends sparse wide-randc history to eligible graph-coupled direct scalar properties from 21 through 64 bits when an enabled owner constraint references the property and its complete feasible domain is exactly enumerable at no more than 1,024 values. The strict paired regression completes all 101 values, checks graph rollback on an unsatisfiable call, and verifies cycle reset. Graph domains above the cap, aggregate properties, and unconstrained properties retain explicit failure controls. Focused JSON and legacy harnesses pass 4/4 each; the full registered uniformity suites remain deferred to the ten-fix checkpoint. See the [revision evidence](../../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#owner-referenced-graph-coupled-wide-randc-fix-23).

Fix 24 covers a different graph constraint shape: a wide `randc` child with no local constraint is now recognized when its parent constrains the child through an `r:` object path. The paired strict 2017/2023 regression completes a 65-value cycle, verifies parent-and-child rollback, and checks cycle reset. Unreferenced, over-cap, and aggregate controls still fail closed. Focused JSON and legacy harnesses pass 4/4 each; the full registered uniformity suites remain deferred to the ten-fix checkpoint. See the [revision evidence](../../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#parent-referenced-graph-randc-property-paths-fix-24).

## 2026-10-09 sparse coupled direct-scalar sampling (#416)

IEEE 1800-2017 §18.5.10 and IEEE 1800-2023 §18.5.9 remain **PARTIAL**. The
local 2017 text and 2023 PDF require equal probability for legal value
combinations; the 2017 errata has no correction to §18.5.10. On refreshed main,
a three-tuple constraint with unequal branch sizes produced bins `64,26,30`
in 120 draws in both editions.

The current branch keeps rejection sampling for dense components. After 64
rejected proposals, it traverses every projected tuple in an eligible connected
direct-scalar component (all variables at most 64 bits, no pending soft
constraints) and reservoir-samples one tuple with the property-owned RNG. The
finite bit-vector product bounds traversal; solver blocking state and work
scale with the number of legal tuples. Draft [PR #526](https://github.com/dsellerbrock/iverilog-uvm/pull/526)
contains the local change. The paired sparse positive, UNSAT rollback, and
4,097-tuple boundary controls pass 2/2 in legacy and 2/2 in JSON/VVP; adjacent
`sv_randomize_global_sampling_fail` controls pass 2/2 in each runner. A
pre-patch 2017 run selected the singleton of the 4,097-tuple boundary 3/4
times; the current exact traversal passes. Widths above 64 bits and soft,
array, and member components remain outside this exact path. No full uniformity
suite or CI run was performed for this increment.
See the [revision-scoped evidence](../../../evidence/solve-before-array/sparse-coupled-uniform-sampling-20261009.md).

### 2026-10-16 wide sparse coupled follow-up (#416)

IEEE 1800-2017 §18.5.10 and 1800-2023 §18.5.9 use the same requirement:
sample uniformly across all legal value combinations. The paired regression
adds a 65-bit scalar constrained with a one-bit mode: the legal space has 257
tuples, one with mode zero and 256 with mode one. On baseline `7f508a8a`, the
mode-one branch appeared 20/32 times at seed 416, below the 28/32 minimum.
Eligible direct-scalar components wider than 64 bits now use complete-tuple
reservoir sampling after 64 rejected proposals, up to 1,024 legal tuples.
Both strict-edition legacy and JSON registrations also check unsatisfiable
failure rollback. A 1,025-tuple wide control checks fallback legality only;
uniformity is not claimed above the 1,024-tuple cap. Unsupported components
retain the documented fallback; broader §18.5 conformance remains partial. See the
[revision evidence](../../../evidence/solve-before-array/sparse-wide-coupled-20261016.md).

## 2026-10-08 IEEE 1800-2023 §22.5 parenthesized conditional expressions

IEEE 1800-2017 §22.5 Syntax 22-5 permits only a `text_macro_identifier`
condition. IEEE 1800-2023 §22.5 Syntax 22-5 adds a parenthesized
`ifdef_macro_expression`: simple or escaped identifiers (§5.6) become 1 when
defined and 0 otherwise, and `ifndef` negates the full expression. IEEE
1800-2023 §11.3.2 Table 11-2
puts `&&` above `||`, with `->` and `<->` at equal, lower precedence and
right-to-left associativity; §11.4.7 defines implication and equivalence.

Issue #460 adds this grammar to `ivlpp` behind an `iverilog`-forwarded `-g2023`
flag in both the top-level compiler path and lazy `-y` library-source path.
Plain identifier conditions retain their prior behavior. Per §22.5 token
separation, `(` may immediately follow `ifdef`, `ifndef`, or `elsif`; focused
cases cover adjacent and whitespace-separated forms, including a nested
conditional in a suppressed branch and 2017 rejection. Focused tests
cover simple and escaped identifiers, including a whitespace-terminated
escaped macro name containing operator punctuation; all four binary operators,
unary negation, precedence and associativity,
nested conditions, defined and undefined macros, `ifdef`/`ifndef`/`elsif`,
comments and line breaks, 2017 identifier compatibility, and 2017 rejection.
Malformed and unterminated expressions produce diagnostics rather than a
crash. The recursive parser has a 256-frame depth guard; deeper input is
rejected as malformed.

The three permanent cases pass 3/3 in the legacy and JSON runners after adding
the escaped-identifier and token-adjacent delimiter cases. Neighboring
macro-definition legacy tests pass 28/28, and macro-definition JSON tests pass
14/14. A mutation of implication
evaluation makes the positive expression case fail, then passes after the
source is restored. The full root `make -j2` passes with Bison 3.8.2. System
Bison 2.3 alone rejects the unchanged `parse.y:2236` `%destructor`; no parser
grammar file changed. Bison 3.8.2 reports the same conflict counts on clean
`origin/main` and this branch: 574 shift/reduce and 1,122 reduce/reduce. Exact-
head CI qualification remains pending. The implementation and tested boundary
are limited to this conditional-expression feature.

## 2026-10-08 IEEE 1800 §22.5 escaped conditional identifiers

IEEE 1800-2017 and 1800-2023 §22.5 Syntax 22-5 use `text_macro_identifier`
for plain `ifdef`, `ifndef`, and `elsif` conditions. Under §5.6.1, an escaped
identifier starts with a backslash, contains printable ASCII, and ends at
terminating whitespace; neither delimiter belongs to the identifier. The
clean-main reproducer for issue #468 defines `\foo` and then uses
`` `ifdef \foo``; it reports `` `ifdef without a macro name`` in both
strict editions.

The #468 candidate adds escaped-name recognition to the four plain conditional
lexer states, requires a whitespace terminator, and looks up the macro without
the leading backslash. Permanent tests cover defined and undefined `ifdef` /
`ifndef` conditions, a punctuation-bearing name used by `elsif`, newline and
space terminators, both editions, and an unterminated-name diagnostic. The new
focus passes 3/3 in both legacy and JSON runners after a forced ivlpp rebuild;
macro-definition neighbors pass 28/28 legacy and 8/8 JSON, and the separate
#460 expression focus passes 3/3 in both runners. Exact-head CI and full-suite
qualification remain pending. See [issue #468](https://github.com/dsellerbrock/iverilog-uvm/issues/468)
and [draft PR #467](https://github.com/dsellerbrock/iverilog-uvm/pull/467).

## October 8, 2026 — associative-array value parameters (IEEE 1800-2023)

IEEE 1800-2017 Annex A A.2.4 `param_assignment` uses
`{unpacked_dimension}`, so a direct associative dimension is rejected in
strict `-g2017`. IEEE 1800-2023 A.2.4 uses `{variable_dimension}`, and A.2.5
includes `associative_dimension` (`[data_type]` or `[*]`). Section 8.25(b)
defines class value-parameter specialization identity by matching value types
and equal values. The implementation adds the direct 2023 parameter form and
keeps the 2017 edition gate.

Paired reducers cover module parameters with string, integral, and wildcard
keys, explicit entries and defaults, module overrides, class parameter values,
constant-key reads, and class identity for reordered versus changed map values.
The four focused legacy/JSON cases pass 4/4 in each runner; neighboring tests pass 6/6
legacy and 8/8 JSON; full legacy passes 5,046/5,046; real-DPI UVM passes
363/363. Bison counts are unchanged at 574 shift/reduce and 1,122
reduce/reduce. Full JSON ran 4,503 cases and reported four failures: two
optional-FPGA-target setup failures passed after installing that target and
rerunning the two cases, while the two packed-struct constraint-state failures
remain recorded as [DD-116](../DISCOVERED_DEBT.md#dd-116--constraint-state-packed-struct-select-fails-in-full-json-sweep).

This is focused 2023 support, not full parameter closure. Dynamic-key reads
from associative parameter values remain unsupported; broader value contexts
and parameter forms are not qualified.

## October 9, 2026 — packed-subfield release offsets (IEEE 1800 §10.6)

IEEE 1800-2017 §10.6 release applies to the selected variable lvalue. On the
clean-main baseline, releasing a packed struct member selected through a
runtime offset aborted target generation because `show_stmt_release` required
an immediate offset. The candidate lowers runtime offsets through VVP release
instructions, preserving variable-release retention and restoring the driver
for net releases. Constant and runtime selections are covered by paired
2017/2023 regressions.

The DD-088 reducer failed before the patch with exit 134. After the patch,
focused legacy tests pass 6/6 and JSON/VVP tests 7/7; neighboring
force/release controls are included. A serial macOS build/install and `make
check` pass. The VVP parser conflict count is 14 shift/reduce and 5
reduce/reduce. Full-suite and CI qualification remain pending; see the
[session record](../session_logs/2026-10-09_ieee_packed_subfield_release.json)
and [issue #493](https://github.com/dsellerbrock/iverilog-uvm/issues/493).

## October 15, 2026 — multiclock `disable iff` with fixed OR antecedents

PARTIAL §§16.9.7, 16.12, 16.12.7, 16.13.1 and 16.13.3: explicit asynchronous
`disable iff` now applies to a same-clock, fixed-length OR antecedent feeding
a consequent across at least two clock-flow boundaries. Each OR branch has
independent pipeline state, and every match creates its own consequent
obligation, including multiple branches matching at one endpoint. A disable
transition clears branch state and pending cross-domain obligations.

The 2017/2023 clause wording is materially unchanged for these semantics.
Paired positive cases check simultaneous branch matches and reset coincident
with a later clock handoff; boundary cases check reset at the handoff edge and
pending work near end-of-simulation. The paired
`sv_assert_multiclock_disable_edge_boundaries` tests also drive asynchronous
reset low by NBA at the first antecedent sample and at the final consequent
evaluation edge. Their no-disable controls fail at both edges. This exercises
§16.12's inclusive attempt interval; §§4.4.2.4 and 4.4.2.5 place NBA updates
before Observed-region evaluation. Paired compile-error cases keep an
unsupported `and` antecedent tree explicit.

The exact-head T0/T1 Slurm job 1410 passed on
`14a0326d21248842044b64a9633cf78a75bf03c2`: issue cases 8/8 in each legacy
and strict JSON/VVP runner; smoke compiler/VVP 56/56, VPI 131/131, and
negative checks 152/152; fixed multiclock-control T1 30/30 in each runner;
and implication-tree neighbors 1/1 legacy and 2/2 JSON/VVP. The start-boundary
stimulus asserts disable by NBA at the first antecedent edge and releases it
before the next clock; the end-boundary stimulus asserts disable by NBA on the
final consequent edge. Both matching no-disable controls fail. The earlier
local start-boundary run used an unisolated reset pulse and is superseded.
[Exact Slurm logs, lists and build metadata](../../../evidence/sva-multiclock-disable-iff-or-antecedent-20261015/slurm-exact-14a0326/README.md)
record the verified head and limits.

This does not qualify variable-length branches, non-OR trees, `first_match`,
local variables, match-item calls, branch pass actions, two-domain OR
antecedents, or general clause-16 behavior. Issue #447 remains open for the
broader shapes; see the [evidence record](../../../evidence/sva-multiclock-disable-iff-or-antecedent-20261015/README.md).

## 2026-10-16 clauses 16.4 and 39.5 deferred assertion cancellation

The 2017 and 2023 wording was checked for §§16.4.2, 16.4.4, 20.12/20.11,
39.5.2, and 39.5.3. `sv_deferred_cancel0` covers cancellation by assertion
label, outermost-process disable (including reports queued in a called
function), non-flushing nested disable, sibling-process survival, and selective
`$assertkill` for observed and final reports. Its paired 2017/2023 runners use
the same boundary. `sv_deferred_vpi_reset0` verifies that deferred assertion
handles exist at `cbStartOfSimulation`, before any report is pending, and that
`vpiAssertionReset` cancels only the selected observed/final source across
process queues while same-scope assertions survive. Concurrent assertion
attempt reset remains unsupported and is diagnosed explicitly; this evidence
does not claim that part of §39.5.2.

## October 17, 2026 — §19.4.1 embedded covergroup inheritance (#457)

IEEE 1800-2023 §19.4.1 (pp. 580–581) adds `covergroup extends` for
class-embedded groups. It replaces the inherited group instance, retains
unoverridden components and options, suppresses an overridden base coverpoint
from the coverage computation while retaining its base cross, and keeps the
base sample interface. IEEE 1800-2017 §19.4 has no §19.4.1 or corresponding
inheritance syntax, so `covergroup extends` is rejected in `-g2017`.

The candidate implements the tested boundary: same-name embedded group
replacement through a base-class handle; inherited and overridden
coverpoints; inherited, replaced, and added crosses with named-bin resolution;
inherited and overridden options; independent base/derived instances; and an
unknown-base diagnostic. The three paired legacy/JSON cases are
`sv_covergroup_class_inheritance_2017`,
`sv_covergroup_class_inheritance_2023`, and
`sv_covergroup_class_inheritance_missing_base_2023`.

T0/T1 passed on DAN-DESKTOP Slurm job 2337 at base
`9b5fad2afb4104caa816b257d5bccc40f01b8c66`: build and install; 72/72 VVP
covergroup API exports; focused tests 3/3 in both runners; smoke; legacy T1
250/250; JSON T1 238 cases, zero failures. Exact result, run script, and raw
logs are in [attempt 03](../../../evidence/issue457-covergroup-inheritance-20261017/attempt-03/RESULT.md).
This is a focused §19.4.1 qualification, not full clause-19 closure; PR CI and
batch qualification are pending.
