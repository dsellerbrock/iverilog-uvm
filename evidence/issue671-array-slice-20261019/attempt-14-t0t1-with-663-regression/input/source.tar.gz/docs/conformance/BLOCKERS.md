# Blockers registry (Level 3 — operational backlog)

The live IEEE issue inventory and selection/CI rules are in the [conformance index](INDEX.md). This registry preserves operational blocker details.

### IEEE-1800-NESTED-ARRAY-FUNCTION-RETURN — issue #415 (PR #524)

- **State:** At the previous campaign checkpoint, #415 was suspended with qualification pending. A fresh metadata read after fetching `origin/main` shows [PR #524](https://github.com/dsellerbrock/iverilog-uvm/pull/524) merged on 2026-10-09 at its recorded head `7efc9ed10bde9476d69a31b25f676cf56c2223f1`, and issue #415 closed. The PR worktree is clean and retained. CI was not checked, so qualification is unverified here.
- **Requirement:** IEEE 1800-2017/2023 §§10.9.1 and 13.4.1 allow array-pattern items to be evaluated in the corresponding element assignment context, including nonvoid function results.
- **Failure and cause:** Nested fixed-array patterns rejected array-valued function calls although direct whole-array returns worked. Elaboration lacked a context-typed function-call path, and VVP pattern lowering handled only nested pattern nodes or scalar leaves. A deeper case showed that typedef-composed dimensions were flattened in reverse declaration order and function return signals retained only their outer dimension layer.
- **Validation:** The original reducer failed in both editions and the direct 1-D whole-array control printed `got=11,12`. The asymmetric typedef-composed 3-D regression failed before the follow-up and now passes, along with its direct 2-D function-return control, under -g2017/-g2023. macOS ARM64 `make -j2 && make install` passes; the array-return focus is 12/12 in legacy and JSON/VVP, and the neighboring const-local-array-pattern focus is 10/10 in both. Independent typedef-order and 3-D probes pass in both editions. Earlier temporary probes also pass for parenthesized calls, opposite source/target ranges, and real, string, and packed-struct elements. Bison conflict counts remain 574 shift/reduce and 1,122 reduce/reduce. The broad legacy gate has no aggregate result; full JSON/VVP and UVM sweeps have not run. CI qualification is pending on the new exact PR head.
- **Next:** No #415 work is active. Preserve the retained worktree; inspect CI only if a failure is reported.

### IEEE-1800-UNPACKED-ARRAY-OUTPUT-SLICE — issue #492 (locally focused-tested)

- **State:** Implemented as the fifth fix in [draft PR #520](https://github.com/dsellerbrock/iverilog-uvm/pull/520) to `main`; issue #492 remains open. All six CI jobs are queued; no CI qualification yet.
- **Requirement:** IEEE 1800-2017/2023 §§7.6 and 23.3.3.5 require compatible unpacked-array connections with matching dimension counts and sizes; element correspondence is left-to-right.
- **Cause and scope:** Output actuals used the array rvalue path, creating a read-side view instead of a selected lvalue connection. Identifier output actuals now use lvalue elaboration, with dimension-size and element-type checks; whole-array outputs keep the same path.
- **Validation:** The original DD-086 reducer passes in strict 2017/2023. Paired selected-row, direction-mapping, whole-array, isolation, and incompatible-shape tests pass 6/6 in legacy and JSON/VVP. Serial macOS build/install and `make check` pass. This is local evidence only.
- **Next:** Address any CI failures on PR #520's exact head; leave #492 open and do not merge until all required jobs are green.

### IEEE-1800-PACKED-SUBFIELD-RELEASE — issue #493 (locally focused-tested)

- **State:** Implemented on the existing IEEE batch branch; issue remains open. The DD-088 reducer aborted before the patch with exit 134 at `show_stmt_release` because the packed offset was non-immediate. Paired focused regressions now pass 6/6 legacy and 7/7 JSON/VVP; serial macOS build/install and `make check` pass. No full-suite or CI qualification is claimed.
- **Requirement:** IEEE 1800-2017/2023 §10.6 release behavior applies to the selected packed variable lvalue.
- **Cause and scope:** VVP target lowering required immediate packed offsets, and release opcodes lacked register-backed offsets. The fix adds that path while preserving variable-release retention and net-driver restoration. Scope is packed release lowering, related VVP instructions, paired tests, and records.
- **Next:** Commit and push to the four-of-five IEEE batch branch; open one PR to `main` after the fifth fix is verified. See [DD-088](DISCOVERED_DEBT.md#dd-088--packed-subfield-release-asserts-on-non-immediate-lhs-offset) and the [session record](session_logs/2026-10-09_ieee_packed_subfield_release.json).

### IEEE-1800-ASSOC-ARRAY-TYPED-PARAMETERS — issue #450 (root-caused)

- **State:** PR [#466](https://github.com/dsellerbrock/iverilog-uvm/pull/466) merged into `main` on 2026-10-09 at merge commit `127b887dfdc09283ab0187a2e618421dee3d5dcc`; refreshed `origin/main` contains that commit. GitHub showed all six platform checks pending when rechecked, so CI qualification is not established. A macOS build/install and paired focused legacy/JSON tests passed (4/4 each) on the PR branch. Prior local evidence on the pre-merge branch includes neighboring checks 6/6 legacy and 8/8 JSON, full legacy 5,046/5,046, and UVM 363/363 with real DPI. The full JSON run had four failures: two optional FPGA target cases passed after target installation; the two constraint-state failures remain triage-pending as DD-116.
- **Requirement:** IEEE 1800-2017 Annex A A.2.4 `param_assignment` uses
  `{unpacked_dimension}`. IEEE 1800-2023 A.2.4 uses `{variable_dimension}`;
  A.2.5 includes `associative_dimension` (`[data_type]` or `[*]`) in that
  grammar. IEEE 1800-2023 §8.25(b) defines class value-parameter
  specialization identity using matching value types and equal values. The
  issue's §8 reference is relevant to specialization; the grammar change is in
  Annex A. A typedef-based associative type parameter is already supported in
  both editions.
- **Baseline:** Exact-source Icarus fails a self-authored module parameter
  `int Values[string]` under `-g2017` and `-g2023` during elaboration
  (`Dimension size must be greater than zero` on `PEAssocType`). A class
  parameter with the same associative dimension syntax-errors in Icarus under
  both editions; Slang accepts the class form in 1800-2023. The typedef type
  parameter control compiles and prints `PASS 23` under both editions.
- **Cause:** Class parameter grammar omitted dimensions following the
  parameter identifier. Module parameter elaboration sent associative
  dimensions to finite unpacked-bound evaluation and element expansion. The
  parameter model and specialization signature represented finite
  bounds/elements, not associative keys/map values, and direct syntax lacked
  the 2023 feature gate. The target API also exposes only scalar parameter
  metadata; keyed-map patterns must stay out of that interface. Class map
  identity then failed because the cache rejected keyed patterns based on
  their legacy `parm_names`, and value selection was typed as a string
  character/packed bit select instead of an associative key.
- **Next:** Let the existing six checks complete; if a required check fails, address it in a follow-up PR. Bison conflict counts on the merged local build are unchanged at 574 shift/reduce and 1,122 reduce/reduce. Keep scope to 2023 associative value-parameter forms, specialization/value uses, strict 2017 rejection, and paired tests. OpenTitan and Caliptra application work are outside this issue.

### IEEE-1800-ESCAPED-IFDEF-IDENTIFIERS — issue #468 (reproduced)

- **State:** Focused implementation and permanent regressions are pushed to existing draft [PR #467](https://github.com/dsellerbrock/iverilog-uvm/pull/467), which targets `main` and also carries #460. The two issues stay separately tracked; no additional PR is opened.
- **Requirement:** IEEE 1800-2017/2023 §22.5 Syntax 22-5 uses `text_macro_identifier`; §5.6.1 defines escaped identifiers as a leading backslash followed by printable ASCII and terminated by whitespace. The backslash and terminator are not part of the macro name.
- **Failure:** A self-authored `\foo` macro definition and `` `ifdef \foo`` condition reports `` `ifdef without a macro name`` and selects no branch under strict `-g2017` and `-g2023`. Punctuation-bearing escaped names must remain one identifier through the terminator.
- **Root cause:** The plain-name `IFDEF_NAME`, `IFNDEF_NAME`, `ELSIF_NAME`, and `ELSIF_SUPR` lexer states accept simple identifiers only. Their fallback treats `\` as a missing name, even though definitions and 2023 parenthesized expressions already process escaped names.
- **Scope:** Add plain escaped-name handling for `ifdef`, `ifndef`, and `elsif`; paired edition tests for defined, undefined, punctuation, terminator, and malformed cases. Parenthesized-expression semantics remain #460.
- **Validation:** Baseline reducer fails in both editions. After a forced ivlpp rebuild/install, the new legacy focus passes 3/3 and JSON focus 3/3; neighboring macro-definition tests pass 28/28 legacy and 8/8 JSON; #460 expression tests pass 3/3 in each runner. These are local results. Consult PR #467 for current exact-head CI status; no CI pass is claimed here.

### IEEE-1800-PARENTHESIZED-IFDEF-EXPRESSIONS — issue #460 (locally validated)

- **State:** Implementation and focused tests pass on
  `agent/ieee-ifdef-parenthesized-20261008`, based on clean `origin/main`
  `af89cfc50be1084cc86c48865f3f6ba78d4512fa`. Draft [PR #467](https://github.com/dsellerbrock/iverilog-uvm/pull/467)
  targets `main`; its stale negative-suite fixture is corrected locally and the
  updated exact-head CI qualification remains pending.
- **Requirement:** IEEE 1800-2017 §22.5 Syntax 22-5 allows only a
  `text_macro_identifier` condition. IEEE 1800-2023 §22.5 Syntax 22-5 adds a
  parenthesized `ifdef_macro_expression` with identifiers, logical operators,
  and parentheses; §5.6 identifiers may be simple or escaped. Defined
  identifiers evaluate to 1 and undefined identifiers to 0. `ifndef` negates
  the expression. §22.5 requires no extra whitespace
  when punctuation such as `(` already separates tokens.
- **Failure:** A self-authored `ifdef (A && (!B || C))` and `ifndef (A && B)`
  probe reports `` `ifdef without a macro name`` under both `-g2017` and
  `-g2023`. The plain identifier control passes in both editions.
- **Root cause:** `ivlpp/lexor.lex` initially accepted only simple identifiers
  in parenthesized expressions, and the driver did not pass the selected
  generation to `ivlpp`. The driver now forwards `-g2023` both for top-level
  sources and lazy `-y` library sources; the expression lexer preserves
  whitespace-terminated escaped identifiers, and the parser looks up their
  normalized macro names. Expressions remain enabled only in 2023. The lexer
  also hands off `ifdef(`/`ifndef(`/`elsif(` without requiring whitespace.
- **Scope:** Boolean conditional-expression parsing/evaluation for `ifdef`,
  `ifndef`, and `elsif`; strict 2017 behavior; paired regression coverage.
- **Validation:** Permanent legacy and JSON fixtures pass 3/3 each, including
  simple and operator-punctuated escaped identifiers, adjacent
  directive/parenthesis tokens, and the 2017 rejection case. Neighboring macro
  legacy tests pass 28/28; neighboring macro JSON tests pass 14/14. The focused
  implementation uses the precedence in IEEE 1800-2023
  §11.3.2 Table 11-2 and semantics in §11.4.7. The full root build passes with
  Bison 3.8.2; system Bison 2.3 alone rejects the unchanged
  `parse.y:2236` `%destructor`. Bison 3.8.2 reports 574 shift/reduce and 1,122
  reduce/reduce conflicts on both `origin/main` and this branch. See the
  [clause record](matrices/ieee1800_2017_clause_matrix.md#2026-10-08-ieee-1800-2023-225-parenthesized-conditional-expressions).
- **Next:** Issue #460 and the DD-107 repair remain in PR #467. Consult the
  PR for the current exact-head CI status. Do not call CI qualified or merge
  until every required platform passes.

### IEEE-VPI-SOURCE-OBJECT-LOCATIONS — issue #501

- **State:** Implemented and focused-tested locally; broad validation is in
  progress. No CI qualification is claimed.
- **Requirement:** IEEE 1800-2017/2023 §37.3.3 applies `vpiFile` and
  `vpiLineNo` to VPI handles for source objects, including the signal, select,
  and class-variable kinds covered here. Respect the `line` directive.
- **Failure:** Before the fix, a scalar signal declared under
  `` `line 100 "mapped_source.sv" 0`` returned no file and line 0.
- **Fix and scope:** The VVP target emits the existing elaborated file-table
  index and declaration line for scalar integral signals/nets and class
  variables. The loader applies the metadata to the corresponding VPI handle;
  bit and part-select handles delegate to their parent. Generated-scope
  signals are covered. Other VPI object kinds are outside this fix.
- **Validation:** The VPI plugin regression passes under `-g2017` and
  `-g2023`, checking both properties for scalar variable, net, bit-select,
  part-select, class variable, and generated-scope signal. Bison remains at
  14 shift/reduce and 5 reduce/reduce conflicts. Full legacy/JSON and UVM
  validation are still pending; these are local checks, not CI results.
- **Delivery:** PR #466 targets `main`. The user will make the merge decision;
  do not enable auto-merge or claim CI green until exact-head checks finish.

### IEEE-TWO-STATE-PACKED-SELECT — issue #469 parameter-select follow-up

- **State:** The original two-state packed-select behavior is merged in PR #464. The parameter-type regression fix and the obsolete unequal-length `intersect` negative removal are in PR #515, included in `origin/main` at `9443fffb69fa304cbc4e9604153ad4040583d419`. Its pre-merge head had Ubuntu 22.04/24.04 and MINGW64/UCRT64/CLANG64 successful; macOS was queued. No fresh qualification claim is made for the current main head.
- **Requirement:** IEEE 1800-2017/2023 §11.5.1 returns 0 for an invalid bit-select from a two-state value and X for a four-state value. A partially out-of-range part-select returns X in missing positions; §6.11.2 converts those X bits to 0 when assigned to a two-state destination.
- **Original failure:** Before PR #464, invalid bit-selects from two-state values returned X and partial part-select X fill was not converted for two-state destinations. PR #464 added the paired reducer for constant and dynamic bit-selects and part-selects.
- **Regression cause and repair:** `NetScope::evaluate_parameter_logic_` read the parse expression type before `test_width()` populated it, then inferred an untyped parameter type from the folded constant. Fully-defined values appeared BOOL, changing invalid four-state parameter selects. The follow-up preserves source type after width testing and carries parameter type through select nodes; the paired fixture also checks explicit `bit` and `logic` parameters.
- **Validation:** The follow-up passes the ten affected legacy parameter-select cases and the paired 2017/2023 JSON/VVP packed-select test locally. These are local results. Exact-head CI after the merge is pending.
- **Related negative-suite correction:** The removed `m9b_intersect_unequal_len` fixture asserted that unequal fixed-length `intersect` operands must be rejected. IEEE 1800-2017/2023 §16.9.6 permits unequal sequence lengths; they simply have no match. The fixture was therefore obsolete, not a required compiler diagnostic.
- **Delivery:** PR #515 targets `main`. Merge only after all required checks pass on the current exact head.

### SV-PACKAGE-CLASS-STATIC-CALL — package-qualified class static subroutine call

- **State:** Implemented and merged by the user in [PR #413](https://github.com/dsellerbrock/iverilog-uvm/pull/413). At the latest CI snapshot, all six platform checks were pending; do not claim the merged head CI-green.
- **Requirement:** IEEE 1800-2017 §8.23 allows access to static class methods
  and properties and says scoped expressions can be used in subroutine calls;
  §26.3 describes package-qualified references. IEEE 1800-2023 §8.23 rewords
  this as access to static public methods and properties from outside the
  class hierarchy; §26.3 retains the same package-reference wording.
- **Failure:** A self-authored `p::c::set(5);` statement reports `syntax error`
  and `Malformed statement`. The imported `c::set(5)` control compiles and
  prints the expected value.
- **Root-cause hypothesis and scope:** Direct package/class/member call
  continuations are missing from the parser even though deeper nested static
  calls and scoped identifiers have grammar paths. Keep the correction local
  to the requested static function/task call path and its focused negative.
- **Validation:** Focused legacy 7/7 and JSON 8/8 pass. Full legacy reports
  7,243 total, 7,238 passed, 0 failed, 2 not implemented, and 3 expected
  failures. Full JSON reports 4,499 tests with 4 unrelated failures (DD-109 and
  DD-110); the package-call cases pass. UVM regression passes 363/363 with no
  skips. The read-only axi-vip probe passes the fixed call site and next reports
  the impure `get_width` constraint call (DD-111); later diagnostics were not
  triaged. Bison counts are unchanged at 574 shift/reduce and 1,122
  reduce/reduce conflicts.
- **Delivery:** Open one draft PR to `main`, follow exact-head CI, and do not
  merge this ticket's PR.

### SV-PACKAGE-CLASS-STATIC-CALL-EXPRESSION (#497)

- **State:** The implementation and paired focus are locally complete on
  `agent/ieee-batch-499-495-20261009`. It remains in the five-fix main-based
  batch; the batch PR has not been opened and no CI result is claimed.
- **Failure:** `value = p::c::get();` reports a syntax error in strict 2017 and
  2023; the package-qualified statement call and `void'(p::c::get())` controls
  compile.
- **Requirement:** IEEE 1800-2017/2023 §8.23 permits `::` access to static
  class methods; §26.3 describes package-qualified references. The 2023
  wording retains the relevant behavior for fully defined package classes.
- **Root cause and scope:** `parse.y` has a package-scoped statement-call
  carrier and expression rules for package functions and deeper nested class
  scopes, but lacks the direct `package::class::method(args)` expression
  production. Keep the repair limited to that expression form and its paired
  positive/negative regressions.
- **Validation:** After merging `origin/main` at `127b887`, a guarded serial
  ARM64 build and install pass. Bison 3.8.2 reports 574 shift/reduce and 1,122
  reduce/reduce conflicts, unchanged from the recorded baseline. The paired
  focus passes legacy 11/11 and JSON/VVP 12/12, including the strict 2017 and
  2023 positive call forms and non-static statement/expression diagnostics.
  The `void'(...)`, parameterized, nested, and statement-control cases are in
  the positive reducer. Earlier full-suite totals in the prior candidate are
  historical and were not rerun after this merge. No CI qualification is
  claimed.

### SV-CLASS-PACKED-PARTIAL-RANGE-CLIPPING (#495)

- **State:** Implementation and paired tests are locally focused-tested on
  `agent/ieee-batch-499-495-20261009`, after merging latest `origin/main` at
  `4b3f342`. No full-suite or CI qualification is claimed.
- **Requirement:** IEEE 1800-2017/2023 §11.5.1 requires partially out-of-range
  reads to fill only missing bits with X and writes to update only in-range
  bits. Cover blocking, compound, and nonblocking writes, one index evaluation,
  and ascending/descending ranges in both editions.
- **Root cause and scope:** Flattening a dynamic class-property select loses
  the selected inner packed carrier, so clipping can reject a legal overlap or
  alias an adjacent element. Keep the repair and paired tests limited to
  dynamic packed class-property ranges. See [DD-103](DISCOVERED_DEBT.md#dd-103--exact-clipping-for-a-dynamic-inner-packed-class-property-range)
  and [issue #495](https://github.com/dsellerbrock/iverilog-uvm/issues/495).
- **Validation:** Guarded serial macOS build (60 s) and install (5 s) passed;
  free RAM stayed at 67–68%. Paired focused legacy and JSON/VVP suites pass
  18/18 each in strict 2017/2023, covering partial and wholly out-of-range
  reads/writes, X indices, truncation, both directions, blocking/compound/NBA
  writes, and single-evaluation checks for reads and all three write forms.
  Linux Docker full-build attempts did not complete because the out-of-tree
  build encountered host-object/VPATH and read-only-source setup errors; no
  Linux pass is claimed.
- **Next:** Commit the verified #495 change and continue the five-fix IEEE
  batch. Do not open its main-based PR before five fixes are verified.

### SV23-REF-STATIC-TF-ARGUMENTS — IEEE 1800-2023 `ref static` arguments

- **State:** Implemented in PR batch #464, based on refreshed `origin/main`
  `af89cfc50`. The paired seven-case legacy and JSON/VVP focus passes 7/7 in
  each runner; the adjusted storage tests plus UVM package compile pass 3/3.
  UVM passes 363/363 with real DPI. The full legacy snapshot had 5 failures:
  the two storage fixtures were updated to use ordinary `ref` with blocking
  joins and `ref static` only with static actuals, and the UVM-dependent
  package test passes after initializing UVM. These three pass in focused
  reruns; two unrelated VIF diagnostic gold mismatches remain (DD-113). The
  full JSON runner stopped at the unrelated zero-time
  `sv_always_comb_fixed_point` loop (DD-114) and has no aggregate result. The
  Ubuntu hard-gate run on the superseded PR head also failed because the
  negative suite still expects rejection of legal unequal-length `intersect`
  (DD-115). Exact pre-integration run 37806441317 failed both Ubuntu jobs at
  152/153 and left four platform jobs pending. Stop this ticket on the unrelated CI failures without editing
  those cases; do not claim qualification. The uncapped census in draft PR #504
  indexes 94 open IEEE issues; #449 is one issue in the existing #464 batch.
- **Requirement:** IEEE 1800-2023 A.2.7 permits `[const] ref [static]`;
  §13.5.2 restricts actuals to static-lifetime storage or another `ref static`
  formal; §9.3.2 exempts `ref static` from the detached-fork reference ban.
  2017 A.2.7, §13.5.2, and §9.3.2 have no corresponding qualifier/exception.
  Checked against the local 2017 and 2023 IEEE PDFs.
- **Pre-fix failure:** The image at PR-batch head `e22741743` rejected
  `ref static` in both editions and accepted an ordinary `ref` formal
  referenced from `fork...join_none`. The controls cover automatic actuals,
  2017 rejection, a fork-local initializer, and blocking `join`.
- **Scope:** Carry the 2023 qualifier through formal metadata, validate actual
  lifetime, enforce the detached-fork rule, and bind fixed-array-word function
  actuals directly so nested reads observe writes immediately. Preserve
  ordinary ref behavior and fork scheduling.
- **Next:** DD-113/115 are recorded in `DISCOVERED_DEBT.md`; update the existing
  draft PR #464 with the CI evidence, then return to coordinator selection from
  refreshed `origin/main`. Do not merge or claim this ticket CI-qualified.

### SVA-INTERSECT-UNEQUAL-LENGTHS — merged; CI qualification incomplete

- **Requirement:** IEEE 1800-2017/2023 §16.9.6 permits unequal fixed-length
  operands; they produce no `intersect` match. Implication follows §16.12.7.
- **Change and evidence:** The default NFA engine preserves the empty language.
  `tests/sva_nfa/run.sh` passes 64/64; strict legacy passes 1/1; paired strict
  2017/2023 JSON/VVP passes 2/2. The explicit legacy-engine diagnostic remains.
  See [focused evidence](../../evidence/sva-intersect-unequal-lengths-20261007/README.md).
- **State:** Merged to `main` in [PR #412](https://github.com/dsellerbrock/iverilog-uvm/pull/412).
  The Ubuntu 22.04 and 24.04 ivtest gates have failed; CLANG64 and MINGW64 are
  still running; macOS and UCRT64 are queued. Do not claim the merged head is
  green. Variable/ranged mismatches and broader nested combinator trees remain
  open.

### SV-TIMEUNIT-TIMEPRECISION-SYSTEM-FUNCTIONS — locally focused-tested

- **Requirement:** IEEE 1800-2023 §20.4.1 and Syntax 20-3 add integer
  exponent results for the current design element or an optional hierarchical
  module/package scope; `$unit` selects the compilation unit and `$root` returns
  the simulation time unit for both functions. Strict IEEE 1800-2017 rejects
  these functions.
- **Failure and fix:** Bare and empty-parentheses calls previously compiled but
  failed at VVP as undefined functions. Package scope arguments also need their
  `PPackage` identity retained by the parser. The frontend now resolves immutable
  design-scope time metadata during elaboration.
- **Validation:** A macOS ARM64 build and install succeeded. The paired focus
  passes 3/3 in both legacy and JSON/VVP runners: strict 2017 rejection, 2023
  exact values for bare, `()`, selected module and nested module, package,
  `$unit`, `$root`, and rejection of a non-scope argument. This is local
  evidence; no CI result is claimed.
- **Boundary:** No timescale declaration parsing, `$time` scaling, `$printtimescale`,
  or `$timeformat` behavior changed. See [focused evidence](../../evidence/timeunit-functions-20261007/README.md).

### OpenTitan 49-target post-fix census — 2026-09-29

- **Frozen-image result:** **23 PASS / 49** on the pinned OpenTitan source with selected exact-hash overlays and native DPI, up from 18 PASS in the previous raw census. The other 26 are 3 DEBT, 4 compile FAIL, 9 RUNTIME_FAIL, 7 RUNTIME_MEMORY_LIMIT, 2 RUNTIME_TIMEOUT, and 1 MATRIX_ERROR. The [complete 49-row evidence](../../evidence/opentitan-49-post-fixes-20260929/README.md) includes source/compiler hashes and logs.
- **Parallel execution:** The merged interpreter speedups were active. The runner used three concurrent single-core VVP jobs, a 4 GiB limit per runtime, and a 1,800-second timeout on a 10-logical-core, 24 GiB host. Memory and host load constrained target concurrency; JSON regression used four shards separately. Both raw censuses used the speedups, so this is not an A/B speed measurement.
- **Separate follow-ups:** A same-image Pwrmgr replay resolves the raw `EPERM` infrastructure row to `EscClkStopEscTimeout_A` DV failure; a later copied-source edge-counter checker replay [passes](../../evidence/opentitan-pwrmgr-clock-edge-count-20260929/README.md). A real-ELF OTBN replay reaches 25,733,094 ps but fails `noOutstandingReqsAtEndOfSim_A` and times out at 180 seconds. These selected replays do not change the immutable raw 49 rows. Caliptra was not run.

### OT-SPID-JEDEC-DIRECTED-RESULT-CLASSIFIER — checked directed completion

- **State:** DONE locally. The frozen JEDEC row exited zero after checking five continuation bytes and `24'hBEA55A`, but was labeled `RUNTIME_FAIL` because its directed bench prints `SPI Flash Read JEDEC ID Tested!!:` instead of a UVM pass banner. The runner now accepts that exact marker for this core only and recognizes directed timeout text, including `$fatal` output. Its self-test passes, and a fresh one-core matrix run **passes** with zero hard/semantic/runtime debt in 1.025 seconds under a 2 GiB/60-second guard. See [selected evidence](../../evidence/opentitan-spid-jedec-classifier-20260929/README.md).
- **Boundary:** The frozen 23 PASS / 49 result remains unchanged. Other SPI directed tests need their own checked completion criteria; upload has no qualifying checker yet.

### OT-SPID-PASSTHROUGH-SMOKE-RUN-OPTS — official directed test selection

- **State:** DONE locally for metadata selection. The frozen passthrough row exited without a case because the runner dropped smoke tests lacking `uvm_test_seq`; the pinned regression's first test declares `+TESTNAME=readbasic`. The runner now selects that test. Its self-test passes, and all other 48 frozen rows retain their test and runtime metadata. The selected 2 GiB/120-second replay reaches `compare_storage` and one pass banner in 4.073 seconds with zero hard/runtime errors. See [selected evidence](../../evidence/opentitan-spid-passthrough-smoke-selection-20260929/README.md).
- **Boundary:** Its verdict remains **DEBT** from nine compile semantic notices and two runtime `$value$plusargs()` task-call warnings. The source and frozen 23 PASS / 49 census are unchanged; the debt needs separate review.

### OT-SPID-PASSTHROUGH-TESTBENCH-CHECKED-CALLS — guarded source correction

- **State:** Selected copied-source `readbasic` **PASS** with a [named patch](release_overlays/opentitan/spid_passthrough_checked_calls.patch) that checks all eight `randomize()` results, both `+TESTNAME` lookups, unknown selectors, and the transaction's local lifetime. The exact-hash patch preserves successful draws and checks; paired strict 2017/2023 controls pass 12/12. One-core compile has zero semantic notices, and guarded VVP exits zero in 4.090 seconds with one pass banner and zero runtime errors/debt. Missing and unknown selectors each fail nonzero; neighboring `addr_4b` and `wel` smoke controls also pass. See [raw evidence](../../evidence/opentitan-spid-passthrough-checked-calls-20260929/README.md).
- **Boundary:** The patch is applied only to a new disposable copy of the already overlaid pinned source, with `-gcommercial-unsafe`. It does not change the frozen 23 PASS / 49 census or qualify the other passthrough test modes.

### OT-SPID-UPLOAD-TRANSACTION-CHECKER — checked directed completion

- **State:** Selected copied-source SPI Upload **PASS** with a [named patch](release_overlays/opentitan/spid_upload_checked_transactions.patch) that checks every command FIFO word, six addresses, no-payload metadata, five program payloads including wrap, and empty final FIFOs. A fresh one-core compile has zero hard/semantic debt; guarded VVP exits zero in 4.077 seconds with one pass banner and zero errors/debt. Five focused negative variants fail nonzero with the expected fatal and no banner. See [raw evidence](../../evidence/opentitan-spid-upload-checked-transactions-20260929/README.md).
- **Boundary:** Exact-hash patch on a disposable copy after existing upload compatibility overlays and `-gcommercial-unsafe`. Pinned source and frozen 23 PASS / 49 census are unchanged.

### OT-KEYMGR-RAL-TYPE-PARAM-FALLBACK — inherited foreach property scope

- **State:** The compiler repair passes paired strict 2017/2023 red/green checks, the selected Keymgr UVM smoke, and full local gates. The pre-fix compiler warned four times that `RAL_T` could not be found; the paired reducer also iterated its string-keyed associative array zero times. The installed repaired compiler emits no `RAL_T` fallback on the exact Keymgr source list, and its selected `keymgr_smoke_vseq` runs 16 scoreboard operations, exits zero with one checked pass banner, and reports zero UVM warnings/errors/fatals under a 4 GiB/1,800-second guard.
- **Cause and fix:** Foreach selected-path inference found `dv_base_env_cfg.ral` in a specialized inherited class but elaborated its `RAL_T` type in the unrelated coverage method's foreach scope. `elab_type.cc` now carries each property's declaring specialized class scope through property and associative-index type elaboration (IEEE 1800-2017/2023 §§8.13, 8.23, 8.25, 12.7.3). No warning suppression or source overlay was used.
- **Evidence:** [Paired reducer, selected replay, independent review, and raw gates](../../evidence/opentitan-keymgr-foreach-owner-20260929/README.md). JSON/VVP 4,149/4,149, legacy 6,903 total/zero failures, VPI 140/140, negatives 154/154, real-DPI UVM 362/362, and `make check` pass.
- **Boundary:** The selected pass does not change the frozen **23 PASS / 49** OpenTitan corpus. Full class-type or foreach qualification is not claimed.

### OT-TRIAL1-CORE-FILE-LAYOUT — out-of-core FuseSoC file paths

- **State:** DONE on a disposable copy of pinned OpenTitan. The frozen Trial1 row was DEBT solely from two actionable FuseSoC warnings for `../rtl` files outside `hw/ip/trial1/dv`, where `trial1_sim.core` lived. An unpatched one-core setup reproduces both warnings. The [exact-hash overlay](release_overlays/opentitan/trial1_core_layout_overlay.py) moves the core file to the IP root and adjusts five relative HDL paths. With `PYTHONHASHSEED=2` to reproduce the frozen `primgen.py` enum order, the selected one-core result is **PASS**: zero actionable setup warnings, compile hard/semantic debt zero, VVP exit zero, one checked banner, 665 checked messages matching the frozen run, and zero runtime debt under 4 GiB/120 seconds. All 187 staged HDL contents match the frozen row in order. See [raw evidence](../../evidence/opentitan-trial1-core-layout-20260929/README.md).
- **Boundary:** Pinned source and immutable historical **23 PASS / 49** corpus are unchanged. The unrelated DVSIM UVM metadata notice remains a description of the directed bench; it is not an actionable setup warning.

### OT-CSRNG-PACKED-CLASS-PROPERTY-INDEX — packed element becomes property slot
- **IEEE issue:** [#495](https://github.com/dsellerbrock/iverilog-uvm/issues/495) tracks the verified generic partial-overlap clipping gap (DD-103).


- **State:** DONE at local commit `c0abdfa48`; implementation and exact-image validation are complete. The old compiler used a packed element index as a class-property slot and asserted in `property_logic::get_vec4`; paired 2017/2023 reducers reproduce the read and write failure. Final installed `ivl` SHA-256 `7427219cfcf964d35119fb738f237596083f41aa3214219bf6a24071c37c5013` passes 28/28 focused JSON, 16/16 focused official legacy, full JSON 4,147/0, real-DPI UVM 362/362, full legacy 6,898 passed/0 failed (6,903 total; 2 not implemented, 3 expected failures), VPI 140/140, negatives 154/154, and `make check`. The selected pinned-copy CSRNG smoke **passes** in 92.528 seconds with zero hard errors, semantic notices, or runtime errors/debt; peak physical footprint was 4,076,064,032 bytes under a 6 GiB guard. The first final-image replay hit its 4 GiB guard, and earlier candidate gate failures remain archived. See [evidence](../../evidence/opentitan-csrng-packed-property-20260929/README.md). The frozen 23 PASS / 49 corpus row is historical and unchanged.
- **Boundary:** Fully in-range bounded dynamic inner packed ranges are supported; unproven crossing ranges fail closed. IEEE partial-overlap clipping for an arbitrary dynamic range remains [DD-103](DISCOVERED_DEBT.md#dd-103--exact-clipping-for-a-dynamic-inner-packed-class-property-range), a separate implementation ticket.

### OT-I2C-QUEUE-LAST-ELABORATION — class queue `[$]` access

- **State:** DONE at `c4199e5cb` for the three queue-last elaboration errors, with paired edition controls and integrated regression gates green. Selected I2C hard errors fall from 18 to 15; coverage bins, `std::randomize` dynamic-array constraints, and random-dependent constraint functions still block compilation. I2C DV remains **FAIL**. See [focused evidence](../../evidence/opentitan-i2c-queue-last-20260929/README.md).

### OT-IBEX-ICACHE-ORDERED-DIST-RANDOMIZE — time-zero config solve

- **State:** DONE at `78eff3fc4`. The solver now applies complete-range requirements only to components that actually have ordering; paired 2017/2023 red/green controls and integrated regression gates pass. The official `ibex_icache_smoke` advances through `cfg.randomize()` and starts the base test, but times out at 1,800 seconds without a DV pass banner. Ibex DV remains **RUNTIME_TIMEOUT** pending a separate runtime diagnosis. See [focused evidence](../../evidence/opentitan-ibex-ordered-dist-20260929/README.md).
- **Boundary:** The solver fix does not qualify the long smoke sequence. Keep its official transaction count and UVM checks intact; Caliptra remains paused.

### OT-IBEX-ICACHE-BUS-PARAMS-PROVIDER — one provider for `bus_params_pkg`

- **State:** DONE for package-provider setup. The raw Ibex I-cache compile failed after 0.207 seconds on a duplicate `bus_params_pkg`; a hash-guarded one-line `.core` patch leaves exactly the OpenTitan provider already required by `dv_lib`. Selected compile exits 0 with no hard errors or semantic notices. The later solver correction advances the official smoke beyond config randomization, but it times out after 1,800 seconds. See the [provider evidence](../../evidence/opentitan-ibex-provider-20260929/README.md) and [current runtime result](../../evidence/opentitan-ibex-ordered-dist-20260929/README.md).
- **Boundary:** The pinned source and raw 49-target census are unchanged. The solver failure is a separate blocker; no unsafe flag or suppressed package diagnostic is involved.

### OT-MATRIX-SMOKE-REGRESSION-TEST-SELECTION — honor the named smoke regression

- **State:** DONE for smoke selection. A direct pre-fix discovery check failed for both targets. The corrected discovery chooses `rv_timer_random` and `spi_device_flash_mode` from their pinned smoke regressions; the other 47 census target selections are unchanged, and the matrix self-test passes. Selected RV Timer is **PASS**; selected SPI Device prints `TEST PASSED CHECKS` but remains **DEBT** from five separate compile-time semantic notices. See the [focused evidence](../../evidence/opentitan-matrix-smoke-selection-20260929/README.md).
- **Cause and correction:** `scripts/opentitan_matrix.py` selected by a `smoke` substring in test names and ignored the smoke regression's `tests` list, although it already read that regression's run options. It now chooses the most local regression-named test with a concrete `uvm_test_seq` before the existing fallback.
- **Boundary:** The immutable raw 49 rows and pinned source are unchanged. The corrected selected replays are revision-scoped; SPI Device's compile notices are DD-098, not waived by this harness fix. No full-suite qualification follows from these two replays.

### OT-OTBN-DPI-IMPORT-SCOPE — context import exposes its declaration instance

- **State:** DONE for the DPI scope semantics. A paired strict IEEE 1800-2017/2023 two-instance reducer passes for imported functions and tasks; neighboring export and disable controls pass. Exact-image gates pass: JSON 4,129/0 across four shards, legacy 6,880 passed/0 failed (6,885 total), real-DPI UVM 362/362, VPI 131/131, and negatives 154/154. The selected OTBN smoke with real libelf DPI and its ELF reaches `TEST PASSED CHECKS` with zero UVM warnings/errors/fatals; the harness reports DEBT for one native trace-checker teardown warning.
- **Cause and correction:** VVP published the imported function/task scope instead of its declaration instance and returned a leaf name from `svGetNameFromScope`, contrary to IEEE 1800-2017/2023 Annex H.9. The synchronous and coroutine import paths now publish the instance, and the name API returns its full hierarchical name. Multi-instance export dispatch accepts an enclosing parent only for legacy function/task handles.
- **Boundary:** The [original selected abort and raw 49-target census](../../evidence/opentitan-49-parallel-census-20260929/README.md) remain historical. The corrected selected OTBN result is a UVM-checks pass with trace-checker debt (DD-097), not a clean DV PASS or full-suite qualification. Independent source review found no scope-fix defect.

### OT-OTBN-TRACE-DECL-ORDER — source assignment precedes its packed-struct declaration

- **State:** DONE for the selected compile blocker. After DD-095, the prior guarded OTBN compile had two bind/r-value errors at `otbn_trace_if.sv:375`; the declaration is at line 382. [Strict paired Icarus/Slang controls](session_logs/2026-09-28_ot_otbn_trace_decl_order.json) reject that order and accept the [named patch](release_overlays/opentitan/otbn_trace_forward_ref_order.patch).
- **Cause and correction:** IEEE 1800-2017/2023 §6.5 requires this explicit packed-struct variable to be declared before use. Move its unchanged assignment after the declaration in a disposable pinned-source copy.
- **Boundary:** Both exact-hash named patches on a disposable source copy make the [guarded selected OTBN compile](../../evidence/opentitan-otbn-trace-declaration-order-20260929/focus.json) exit zero with no hard or semantic notices, producing a VVP image. No compiler/unsafe waiver was added, and no OTBN DV pass or refreshed 49-target count is claimed.

### OT-OTBN-SAMPLE-FORMAL-UNPACKED-ARRAY — preserve sample array shape and values

- **State:** DD-095 DONE for its bounded compiler fix. Paired strict 2017/2023 focused JSON and legacy tests pass 10/10 each; exact-image JSON 4,129/0, legacy 6,880 passed/0 failed, real-DPI UVM 361/361, VPI 131/131, and negatives 154/154 pass. The [guarded OTBN compile](../../evidence/opentitan-otbn-dynamic-sample-formal-20260929/focus.json) reduces 30 hard errors to two original tracer declaration-order errors, with no new diagnostic line.
- **Cause and correction:** Covergroup sample formals lost unpacked dimensions when parsing retained only the element type. The compiler now carries the declared array shape into covergroup placeholders, copies fixed-array actuals by value, and checks explicit and defaulted actual shape. Defaults are evaluated on every omitted call.
- **Boundary:** No OTBN VVP/DV pass or refreshed 49-target census. Four-state X/Z bin matching is separate DD-096 debt; the two remaining tracer errors require the named pinned-source declaration-order patch.

### OT-UNSAFE-INTERFACE-DRIVER-ALIAS-GUARD — distinguish guarded VIF writes from static conflicts

- **State:** Focused candidate on `525642475`, awaiting exact-head broad gates. The [revision-scoped evidence](session_logs/2026-09-29_ot_unsafe_interface_driver_alias_guard.json) records paired 2017/2023 controls, the selected copied-source SPI Host compile, and the compiler/VVP fingerprints. No selected SPI DV runtime ran.
- **Cause and correction:** A full-width continuous drive made `elaborate.cc` waive every interface-property writer in `-gcommercial-unsafe`. The correction preserves that opt-in waiver only for an unresolved ordinary VIF property whose name maps directly to the physical member and whose actual alias is checked by VVP. A resolved module-port write, a named modport alias, and a generated virtual clocking-output write remain compile errors because their conflicts are definite or their current VVP slot does not guard the raw member. Ref writers and unreachable-task rules retain their existing checks.
- **Boundary:** Strict 2017/2023 modes reject all possible same-member continuous/procedural overlaps under §6.5. Unsafe runtime-selected ordinary and simple-modport VIF writes compile; an actual alias fails with the exact VVP driver error, while a disjoint receiver preserves both interfaces' values. The named modport and virtual clocking-output forms remain conservative compile errors even if a particular runtime binding could be disjoint. This compatibility behavior is not an IEEE qualification claim. The historical `4097/32` full JSON result remains unchanged until an exact-head rerun.

### OT-FLASH-CONSTRAINT-NESTED-QUEUE-CONTENT — randomize queue elements below fixed property ranks
- **IEEE issue:** [#419](https://github.com/dsellerbrock/iverilog-uvm/issues/419) includes the verified nested-container randomization evidence (DD-047, DD-068).


- **State:** The prerequisite passes on the current compiler image. Three already-registered controls pass in strict 2017 and 2023 (**6/6 invocations**), including nonempty queue contents, nested `foreach`, packed fields, per-element `dist`, external 2-D state weights, rand-mode state, rollback, and invalid/X/Z reads. Exact commands, image hashes, and separate output-channel gold checks are in [the paired evidence](../../evidence/opentitan-census-20261002/flash-queue-content-current-image/README.md).
- **Expected behavior and cause:** A selected queue element below fixed unpacked property ranks is represented distinctly by its property, fixed-array leaf, queue index, and packed value; constraints, state reads, size/bounds, `rand_mode`, rollback, and writeback use that same identity. The current-image controls now establish this behavior for the exercised shapes.
- **Boundary:** This closes the nested queue-content prerequisite only; it is not a Flash DV pass and does not qualify the whole-array solve-before clauses. Census11 Flash still has separate ordering diagnostics and a runtime timeout. Keep the pinned OpenTitan tree read-only and advance only to the named solve-before blocker.

### OT-FLASH-SOLVE-BEFORE-MULTIDIM-ARRAY — preserve solve ordering for Flash regions and pages

- **State:** Active. Census11's copied-source Flash compile succeeds with zero hard errors but records ten unique semantic-debt entries; its runtime row timed out at 3000 seconds. A new hash-guarded disposable-source compile expands the two nested queue aggregates and removes the entries at `flash_ctrl_otf_base_vseq.sv:49` and `flash_ctrl_mp_regions_vseq.sv:43`. Eight packed-struct-member ordering entries remain, and no runtime was run on this overlay. The pinned sources remain unchanged.
- **Cause and proof so far:** The whole `rand_regions` and `mp_regions` operands are one-dimensional fixed arrays and remain whole-array operands, covered by `sv_constraint_solve_before_fixed_array` in both language editions. Census11's Flash package has two banks and info-queue lengths 10, 1, and 2. The queue operands were expanded to all 26 statically selected leaves per variable, retaining solve direction. `sv_constraint_fixed_queue_leaf_order` passes strict 2017/2023 legacy and JSON harnesses (**4/4 runs**) and exercises the selected nested queue-leaf path. The disposable compile succeeds with explicit `-gcommercial-unsafe`; its exact two-file patch, source hashes, compile log, and warning delta are in the [selected-leaf evidence](../../evidence/opentitan-census-20261002/flash-solve-before-nested-queue-leaf/).
- **Boundary and next proof:** The remaining entries are packed `flash_op_t` member orderings in the OTF and legacy sequence classes. The strict paired fixture identifies these as an unsafe compatibility extension; the nested queue replay does not establish their behavior. Keep those entries visible, do not remove ordering or order only queue sizes, and do not patch the pinned OpenTitan tree. Resolve the packed-member debt before a Flash runtime or 49-row census replay; all OpenTitan compiles/runtimes must retain explicit `-gcommercial-unsafe`.

### OT-FLASH-ASSOC-FIXED-CHILD-SHUFFLE — order a selected associative fixed array

- **State:** Focused strict 2017/2023 JSON and legacy tests pass **4/4 each**, 18 adjacent associative fixed-array checks pass in each runner, and independent review found no scoped blocker. One hash-guarded patched-copy Flash compile removes exactly `cfg.tgt_pre[partition].shuffle()` at `flash_ctrl_otf_base_vseq.sv:208`: **3 → 2 hard errors**, **135 → 135 warnings**, with no additions. See [the focused session](session_logs/2026-09-28_ot_flash_assoc_fixed_child_shuffle_focus.json) and projectless `outputs/flash-assoc-fixed-child-shuffle-evidence-20260928.md`.
- **Cause and correction:** The frontend rejected a one-dimensional integral fixed child after an enum-keyed associative class-property index, and the fixed-array target emitter handled only direct signal receivers. The selected path now vivifies the stored child, including a private copy of a missing key's explicit default, and uses the existing object `reverse`/`shuffle` operations. Runtime tests cover exact reverse, shuffle permutation and observed change, one-time key evaluation, missing-key insertion, and sibling isolation; scalar and two-dimensional unsupported receivers fail loudly.
- **Boundary:** Direct fixed class-property ordering is a separate silent-copyback defect [DD-084](DISCOVERED_DEBT.md#dd-084--fixed-class-property-ordering-method-silently-skips-its-receiver). Two whole-array `solve before` hard errors and ten nested queue-element warnings that say `randomize()` will fail remain separate. The compile exits 2 without a VVP image. Pinned sources, unsafe flags, broad suites, installation, and Flash DV runtime are unchanged.

### OT-FLASH-CONSTRAINT-INDEXED-QUEUE-SIZE — indexed queue leaf in a class constraint
- **IEEE issue:** [#494](https://github.com/dsellerbrock/iverilog-uvm/issues/494) tracks the fixed queue-size leaf captured by a constraint function (DD-092).


- **State:** Focused compiler repair passes strict 2017/2023 JSON and legacy tests 8/8 each, six adjacent JSON tests and one direct queue legacy control; independent review found no scoped blocker. One hash-guarded patched-copy Flash compile removes all ten indexed `rand_info[i][j].size()` and `mp_info_pages[i][j].size()` hard errors, **13 → 3**, with no new hard errors. Warnings rise **125 → 135** because ten separate nested queue-element constraint items now report that `randomize()` will fail. The compiler image SHA-256 is `923a9b4fd62760a8de1a4a977f92983da72bce64fedc5044b33b2c7bb9e3f308`; see the [focused session](session_logs/2026-09-28_ot_flash_indexed_queue_size_focus.json) and projectless `outputs/flash-indexed-queue-size-evidence-20260928.md`.
- **Cause and correction:** Constraint capture rejected indexed fixed-array-to-queue size calls; direct size IR and VVP variables keyed only the class property, so a parser-only acceptance would alias every leaf to word zero. The repair carries a canonical flat leaf through size IR, solver identity, activity/state pinning, function priority, and queue writeback. Strict runtime tests distinguish 1D/2D lengths, bounds, packed elements, rand modes, non-rand state, function dependencies, contradiction rollback, and loud invalid/unsupported forms.
- **Boundary:** Nested queue-element `foreach` remains unrepresentable and fails at randomization; the ten warnings are not a Flash DV pass. At this checkpoint, the indexed child `.shuffle()` call and two whole-array `solve before` errors remain hard and separate; a read-only review found no qualified distribution-preserving source patch for `solve before` yet. The compile exits 3 without a VVP image. Pinned sources, unsafe flags, broad suites, installation, and Flash DV runtime remain unchanged.

### OT-FLASH-NESTED-COVERPOINT-GET-COVERAGE — method lookup through class and covergroup

- **State:** Focused compiler checkpoint on base `ae698ea3d`: strict IEEE 1800-2017/2023 JSON and legacy tests each pass 6/6, four adjacent JSON checks pass, and independent review found no scoped blocker. One hash-guarded patched-copy Flash compile removes exactly the line-389 missing-method error, **14 → 13 hard diagnostics**, with warnings **125 → 125** and no new diagnostics. See the [focused session](session_logs/2026-09-28_ot_flash_nested_item_coverage_focus.json) and projectless `outputs/flash-nested-coverage-item-evidence-20260928.md`.
- **Cause and correction:** Named coverpoints and crosses are covergroup item metadata, while nested method elaboration searched class properties. The repair retains the selected covergroup receiver, resolves the named item index, and scores that item's static, dynamic, or transition bins. `get_coverage()` returns item type coverage; `get_inst_coverage()` follows the existing instance-option gate. Focused tests distinguish item, group, type, and instance results, including unequal weights and retired instances; missing or unsupported paths diagnose explicitly.
- **Boundary:** Two-ref-argument coverage methods remain explicit unsupported forms; static type-scope and task-statement calls were outside this nested-expression ticket. Thirteen other Flash hard errors prevent a VVP image or DV runtime. Queue `.size()`, child `.shuffle()`, and whole-array `solve before` remain separate; no integrated gates, installation, current-image census, or broad qualification is claimed.

### OT-FLASH-CONSTRAINT-FOREACH-FUNCTION-ARGUMENT — retain iterator in a function argument

- **State:** The compiler repair passes paired strict IEEE 1800-2017/2023 JSON and legacy focus 10/10 each on build-tree `ivl` SHA-256 `8181490bae115633e56b18166158a35d222e10159a6f8b0babc66e3d4dd96886`; independent review found no selected-ticket blocker. One hash-guarded patched-copy Flash compile removes exactly five `en_mp_regions[i]` hard errors, with no new hard errors: 19 → 14. Five paired unbound-`i` warnings disappear, while five `mp_regions_c` randomize()-will-fail warnings become visible, leaving 134 total warnings. See the [focused checkpoint](session_logs/2026-09-28_ot_flash_foreach_function_argument_focus.json) and projectless `outputs/flash-foreach-function-argument-evidence-20260928.md`.
- **Cause and correction:** Fixed-array constraint `foreach` unrolled with a known iterator, but the pure user-function argument was elaborated in a generated wrapper without that binding. The repair installs each iterator as a signed constant parameter before call elaboration and avoids wrapper-name collisions with source methods and iterator names. Runtime tests check distinct selected bits, a 4-bit mapped result, lexical shadowing, signed and nonzero indices, and an unsatisfiable contradiction; impure calls still hard-error.
- **Boundary:** The five new solver warnings belong to the separate fixed-array packed-struct member projection gap below: even `regions[0].en == 4'h6` fails without a function or foreach. This ticket does not repair those randomize calls. Fourteen other hard diagnostics still prevent Flash compilation; no VVP image, DV pass, integrated gate, installation, or fresh 49-core census is claimed. Pinned sources and unsafe flags are unchanged.

### OT-FLASH-CONSTRAINT-FIXED-ARRAY-PACKED-STRUCT-MEMBER — constrain a packed member of a fixed-array element

- **State:** The focused compiler repair passes paired strict 2017/2023 JSON and legacy focus 10/10 each on build-tree `ivl` SHA-256 `8a0e27e0e8881f7b1db4b8ef4201ef820748b4673ca05009d773836113f0bdba` and VVP SHA-256 `0187b7f3078511e914c346d75c630bddee9cebe08a35232933a7c2fb5dd2b0c3`. One hash-guarded patched-copy Flash source-list compile removes exactly nine `rand_regions_c`/`mp_regions_c` solver warnings, 134 → 125, with no new diagnostics; all 14 hard errors remain and no VVP image exists. See the [focused checkpoint](session_logs/2026-09-28_ot_flash_fixed_array_packed_member_focus.json) and projectless `outputs/flash-fixed-array-packed-member-evidence-20260928.md`.
- **Cause and correction:** The class-constraint IR handled direct packed-struct members and whole fixed-array elements, but did not project a member from a selected fixed-array element. The repair slices the existing `e:` rand element at its declared packed bit offset. A guard-aware runtime check rejects an unknown inactive element when its member is read, avoiding a fabricated-zero solve while allowing a guard-off branch. Strict tests cover the Flash 92-bit field layout, distinct indices, contradiction, `dist`, and nested overlap controls.
- **Boundary:** Only defined constant or foreach-folded indices and direct unsigned integral members of one-dimensional rand fixed arrays are supported; other forms fail explicitly. DD-082 records a separate `.v:` unsupported-marker diagnostic bug, and DD-083 records a preexisting X/Z RHS literal alias that also affects plain scalar constraints. The compile is not Flash DV qualification; integrated gates, installation, and a current-image 49-core census remain pending. Pinned sources and unsafe flags are unchanged.

### OT-FLASH-CONSTRAINT-CONSTANT-INDEXED-PART-SELECT — exact +: and -: constraint slices

- **State:** The compiler repair passes paired strict IEEE 1800-2017/2023 legacy and JSON focus 6/6 each on build-tree `ivl` SHA-256 `07b0df527ff7cbea1ba2ef1a7a63b79b6708017fe8a1096e65d076f0c093633c`; independent review found no scoped blocker. One hash-guarded patched-copy Flash compile removes exactly the `flash_ctrl_erase_suspend_vseq.sv:300` inline `-:` hard error and 12 named `+:` constraint warnings: 20 → 19 hard errors and 146 → 134 warnings, with no additions. No VVP image exists. Pinned sources are unchanged. See the [focused checkpoint](session_logs/2026-09-28_ot_flash_indexed_constraint_part_select_focus.json).
- **Cause and correction:** Shared class and inline constraint select IR handled a bit select and fixed `[msb:lsb]` range but returned no IR for `+:` or `-:`. For a constant base and positive width of at most 64 bits on a one-dimensional zero-based 2-state packed `bit` vector, including a packed-struct field receiver, the repair evaluates both bounds, checks the declared direction and exact in-range slice, and emits the existing fixed `(part ...)` solver IR. Runtime tests prove selected bits remain constrained in both strict editions.
- **Boundary:** Wider bounds, four-state vectors, legal partial out-of-range, symbolic, unknown-index, and multirank forms stay explicit unsupported boundaries. DD-081 records a separate preexisting ascending class-property indexed readback defect. The other 19 hard diagnostics and 25 `randomize()`-will-fail warnings remain separate; no Flash DV, integrated gate, installation, or fresh 49-core census is claimed.

### OT-FLASH-FOREACH-OMITTED-ASSOC-KEY — skip an associative rank, iterate its fixed child

- **State:** The compiler repair passes paired strict IEEE 1800-2017/2023 JSON and legacy focus 6/6 each on build-tree `ivl` SHA-256 `e561d97a5a92f6f760421b5e9f35164c8161c6ebbce287e1fa164832b1c9e604`; independent review found no scoped blocker. One controlled patched-copy Flash compile falls from 21 to 20 hard diagnostics by removing only `flash_ctrl_env.sv:43`. No new hard diagnostics appear, all 146 warnings remain unchanged, and no VVP image exists. The pinned source is unchanged. See the [focused checkpoint](session_logs/2026-09-28_ot_flash_omitted_assoc_foreach_focus.json).
- **Cause and correction:** `PForeach::elaborate_assoc_array_` rejected an omitted associative key before examining the fixed bank rank. IEEE 1800-2017 §12.7.3 omits iteration over that outer rank. The repair reuses fixed-array loop lowering with an index offset, visiting each bank once per enclosing `part` without inventing or traversing associative keys. Populated and empty maps, class properties and plain signals, both fixed-bound directions, and all-omitted zero visits are checked in strict paired runtime tests.
- **Boundary:** A true excess rank hard-errors. Legal packed tails and indexed earlier target prefixes receive explicit unsupported diagnostics rather than silently misexecuting; they are recorded as separate debt. The other 20 hard diagnostics and 37 explicit `randomize()`-will-fail warnings remain separate; no Flash DV, integrated gate, install, or fresh 49-core census is claimed.

### OT-FLASH-VIF-PACKED-STRUCT-FIELD — packed struct fields through a virtual interface

- **State:** The compiler repair passes paired strict IEEE 1800-2017/2023 JSON and legacy focus 14/14 each on build-tree `ivl` SHA-256 `9e9695f87b70325cf8582c22ba122d3775b50523ecd40cd332c14cf752f068ac`. One controlled patched-source Flash compile falls from 29 to 21 hard diagnostics: all six targeted scoreboard line-108/110 errors clear, two line-124 diagnostics disappear downstream, no new hard errors appear, and all 146 warnings remain unchanged. The compile exits 21 without a VVP image. The pinned source is unchanged. See the [focused checkpoint](session_logs/2026-09-28_ot_flash_vif_packed_struct_field_focus.json).
- **Cause and correction:** `rd_buf` is a two-dimensional packed array of packed structs. Virtual-interface property elaboration treated the first packed rank as a whole struct element, then sent the second rank to a queue/associative-array helper. The repair reads the whole property and selects each packed rank separately. The intermediate row remains typed as a packed array, and the final element remains typed as the declared struct before `.addr`, `.part`, or `.info_sel` lookup. Integral index validation prevents string/real indices from reaching invalid runtime or target operations.
- **Boundary:** Valid slots and fields match the direct physical-interface reads; invalid/unknown VIF indices do not alias another slot. Missing fields, partial/range member forms, and nonintegral indices hard-error. An enum method on a selected enum field is explicitly unsupported rather than compiling to a failing VVP call. The two line-124 disappearances are cascade evidence only, not independent proof of their packed-vector/coverage semantics. The separate physical-interface inner-index alias is [DD-078](DISCOVERED_DEBT.md#dd-078--physical-interface-packed-inner-index-aliases-a-neighbor). The remaining 21 hard diagnostics and 37 explicit `randomize()`-will-fail warnings preclude a Flash compile or DV pass; broad gates, installation, and a fresh 49-core census are pending.

### OT-FLASH-FOREACH-MIXED-RANK — fixed ranks followed by runtime array ranks

- **State:** The focused compiler repair passes paired strict 2017/2023 JSON and legacy tests 4/4 each. One disposable patched-source Flash compile falls from 47 to 29 hard diagnostics: all 16 standard whole-target mixed-rank `foreach` errors clear through this repair; two nonstandard `info_mem` errors clear through a separate source correction. No new hard errors appear, and all 146 warnings remain unchanged. The pinned checkout is unchanged; broad gates, installation, Flash DV runtime, and a fresh 49-core census remain pending. See the [focused record](session_logs/2026-09-28_ot_flash_mixed_foreach_focus.json).
- **Cause and correction:** Class-property elaboration counted only grouped outer fixed dimensions, while the plain-signal path could compile a populated fixed-plus-queue loop that visited zero elements. The repair selects the complete fixed slot, iterates its queue, dynamic, or associative child through the existing runtime walker, then wraps the child loop in declared-order fixed loops. The positive test checks ragged lengths, string keys, selected values, and outer order; a true excess rank remains a hard error.
- **Boundary:** Final-component bracketed `foreach` targets are a separate accepted extension and are outside the standard whole-target compiler change. A packed dimension after a runtime child receives an explicit unsupported diagnostic; standalone queue packed-tail zero-visit behavior is [DD-077](DISCOVERED_DEBT.md#dd-077--queue-foreach-silently-skips-a-packed-element-dimension). The remaining 29 Flash hard diagnostics and 37 explicit `randomize()`-will-fail warnings preclude an application or DV pass.

### OT-RSTMGR-DERIVED-ARRAY-OPEN-FORMAL — released CSR array helper type mismatch

- **State:** The named [source patch](release_overlays/opentitan/rstmgr_csr_array_selector.patch) is reviewed and compiles on a disposable pinned OpenTitan copy. One `rstmgr_sim` core compile exits zero with 21 port/assertion warnings. The pinned checkout is unchanged; DV runtime, integrated gates, install, and a fresh 49-core census remain pending.
- **Cause:** Eleven calls pass fixed arrays of distinct derived RAL register classes to an `input uvm_object ptr[]` helper. IEEE 1800-2017/2023 §7.6 requires equivalent array element types. Slang and Icarus reject a minimal strict 2017/2023 array call; an explicit per-element handle selector compiles and runs in both Icarus editions.
- **Correction and boundary:** The patch selects each scalar handle from `sw_rst_ctrl_n[8]` or `sw_rst_regwen[8]`, preserving index order, value bits, reset exits, and each CSR operation. It updates both generated Earlgrey sequences and template mirrors. This is source correction, not compiler or unsafe-dialect support, and the compile alone does not qualify RSTMGR DV.

### OT-AES-IMPLICATION-DIST-GRAMMAR — unbraced guarded distribution

- **State:** Committed at `8a35c584b`; the [paired self-checking fixture](../../ivtest/ivltests/sv_constraint_implication_dist.v) covers direct and nested hard and soft distributions, and a paired compile-error fixture rejects `dist {}`. The seven-case build-tree JSON focus passes 7/7. The released AES testbench has a separate `logic [255:0] init_key[2]` to `bit [7:0][31:0] key[2]` type mismatch. A one-line correction on a disposable source copy lets the core compile; this is patched-source compile evidence, not a pristine or DV pass. Broad gates and installation remain pending.
- **Cause and scope:** The generic expression rule had parsed `guard -> subject` before the constraint rule saw `dist`, leaving `dist` applied to the Boolean implication. A recursive consequent rule puts `PEInside` on the distribution subject, retains `PESoft` for soft consequents, and wraps each unbraced guard in `PEConstraintIf`; a precedence declaration chooses that rule on `dist` while ordinary `guard -> expression;` keeps its existing expression representation. All four distribution productions require at least one item, so `dist {}` fails during parsing instead of dropping the constraint. The parser conflict signature is unchanged (`conflict_diff.sh HEAD`: zero changed states). No solver or pinned application source changed.
- **Boundary:** Focused tests establish guard-off freedom, guard-on hard exclusion, `:=` and `:/` item forms, failed-solve rollback, right-associated nested hard guards, nested soft override and preference, and ordinary/grouped/soft implication neighbors. Scratch probes reject empty plain, direct, nested, direct-soft, and nested-soft distributions in both editions. Parenthesized implication expressions used as a `dist` subject retain their existing top-down diagnostic. These tests do not establish full clause-18 or released DV qualification.

### OT-AES-CONSTRAINT-STATE-PACKED-SELECT — selected class state in constraints

- **State:** The two saved AES reducers for `config_error_type_c` and `alert_reset_trigger_c` now compile and randomize without diagnostics in strict 2017 and 2023. Paired self-checking [positive](../../ivtest/ivltests/sv_constraint_state_packed_select.sv) and [invalid-state](../../ivtest/ivltests/sv_constraint_state_packed_select_invalid.sv) fixtures pass the registered JSON focus 4/4 on build-tree `ivl` SHA-256 `17599d13ebfba7e418ff8dcf38eadced91594100cc50ac10950975461ba45d15`. A single disposable key-type-patched AES core compile exits zero with five warnings; the two earlier constraint representability warnings are gone. The function copy-out warning is tracked separately below.
- **Cause and boundary:** The nonrandom-property gate classified packed selects as unpacked-array elements before the existing typed packed-select lowering could run. The repair admits selected packed vector/enum state and two-state packed structs of 1–64 bits, and uses the declared width for whole packed structs. State changes between `randomize()` calls and `rand_mode(0)` remain pinned to current values. Four-state or wider packed structs fail explicitly; invalid four-state vector reads and X/Z guards remain failures. This is focused compile/randomization evidence only; no AES DV runtime, installed image, broad gate, or new 49-core census is claimed.

### OT-AES-FUNCTION-COPY-OUT-SELECTED-PACKED — output into a packed word of a fixed-array property

- **State:** The saved 24-line AES reducer and paired self-checking fixture pass in strict 2017 and 2023. Registered JSON and legacy focus each pass 2/2, and six neighboring fixed-property output JSON tests pass 6/6. A single disposable key-type-patched AES core compile exits zero with four warnings; the lost copy-out warning is gone. The target image SHA-256 is `cbbf7b676deaedcac0b2179241f6001be621aecfdea4337b82b5f105512251dd`.
- **Cause and boundary:** The target received `SELECT(PROPERTY(key[slot]), packed offset)` but handled only simpler output actuals, so it returned success without storing the result. The focused path uses the existing indexed property bit-store opcode and preserves other packed words and array slots. It handles 2- and 4-state scalar output formals, truncation and casting, one evaluation of each address expression, invalid slot/offset no-ops, and null receivers. This is compile and focused runtime evidence only; no AES DV runtime, installed image, broad gate, or new 49-core census is claimed.

### OT-KEYMGR-CONSTRAINT-UNBASED-FILL — fill literal width in constraints

- **State:** The saved direct equality and 256-bit plain `inside` Keymgr reducers now compile and run in strict 2017 and 2023. Paired self-checking and compile-error fixtures pass registered JSON 4/4 and legacy 4/4; direct reducers and neighboring packed-element, cast, and `dist` controls also pass in both editions. Slang accepts the positive fixture in both editions. No Keymgr application replay, broad gate, installed image, or new 49-core census is claimed.
- **Cause and boundary:** The constraint IR serialized unbased `'1` as a one-bit numeric constant before the comparison supplied its width, then the solver zero-extended it. Direct equality and each plain `inside` item now materialize the fill at the proven comparison width, including 256-bit values; explicit `1'b1` remains numeric one. The fixture covers reversed equality, signed and 2-/4-state values, class and scope constraints, an unsatisfiable rollback, and a mixed-width per-item comparison. Fill-bearing composite expressions and plain `inside` range endpoints without proven context fail with diagnostics. Relational fill comparisons are outside this focused repair. Dynamic packed-element indexing in the released Keymgr constraint remains a separate blocker.

### OT-SRAM-INDEXED-DARRAY-SLICE — runtime-indexed dynamic-array slice values

- **State:** The reviewed private compiler passes paired IEEE 1800-2017/2023 read, write, overlap, mismatch, invalid-form, control, and resource-boundary tests (16/16). Full legacy has 6,556 ordinary passes of 6,561 total, zero failures, two not implemented, and three expected failures; full JSON passes 3,548/3,548; negatives 155/155; VPI 131/131; and real-DPI UVM 358/358 with zero failed/skipped. The exact pinned `otp_ctrl_sim` and `chip_sim` replays clear all four former `sram_scrambler_pkg.sv:278/280/332/334` errors, then fail on 22 and 60 classified hard diagnostics, respectively; chip also aborts on a separate `entropy_src_core.sv:3324` elaboration assertion. Neither enters DV runtime. The installed compiler remains unchanged during Caliptra's live sweep. See the [reviewed candidate evidence](../../evidence/opentitan-sram-indexed-darray-slice-20260924/README.md).
- **Requirement:** IEEE 1800-2017 §§7.4.6, 7.6 and 2023 §§7.4.5, 7.6 require a fixed-count unpacked slice at a variable base, equivalent element types, left-to-right assignment, invalid-index defaults/no-op writes, and no target mutation on a mismatched dynamic source size.
- **Boundary:** The candidate handles direct one-dimensional blocking reads/writes, integral bases up to 127 bits, and a complete RHS snapshot. Legal bases wider than 127 bits, slices wider than 65,536 elements, and nonblocking or timed indexed-slice assignments remain explicit unsupported cases. Property/nested and multidimensional forms are not claimed.

### OT-SPI-CLASS-EVENT-TRIGGERED — per-instance event state in expressions

- **IEEE issue:** The explicit function-call forms remain tracked in [#439](https://github.com/dsellerbrock/iverilog-uvm/issues/439); this blocker’s parenthesis-free property-read fix is merged in PR #340.

- **State:** Merged in [PR340](https://github.com/dsellerbrock/iverilog-uvm/pull/340) at `909e3f314` after exact-head Ubuntu 22.04 success. The [candidate evidence](session_logs/2026-09-23_opentitan_class_event_triggered_focus.json) shows all three class-event errors removed from the pinned SPI compile. No SPI Device DV qualification is claimed.
- **Requirement:** IEEE 1800-2017/2023 §15.5.3 keeps an event's triggered state true for the firing time step and lets `wait (obj.ev.triggered)` handle either same-time trigger order. Different class instances must remain independent.
- **Cause and boundary:** Class-event reads fell into ordinary class-property lookup before per-object event lowering; `wait` also entered an unrelated direct-event fast path. The candidate reuses per-object VVP event opcodes and passes paired positive, negative, boundary, and instance-isolation checks. Explicit `triggered()` calls remain separate debt; the pinned SPI compile still fails on other mechanisms.

### OT-AON-EVENT-TRIGGERED-SENSITIVITY — named-event property changes

- **State:** Integrated at `0a902ee9f`; the [revision-scoped replay](session_logs/2026-09-23_inside_array_named_event_integration.json) records paired static and automatic checks and a zero-error released AON compile. Its bounded smoke produced no UVM verdict; the later [mixed-VIF repair checkpoint](session_logs/2026-09-23_opentitan_spi_aon_postfix.json) records one passing unchanged AON smoke.
- **Requirement:** IEEE 1800-2017/2023 §15.5.3 keeps `e.triggered` true through the firing time step. `@(e.triggered)` observes its value changes, including the reset at the next real time advance, with independent state per automatic activation.
- **Boundary:** The earlier timeout is superseded for the observed smoke sequence by the mixed-VIF event-wait repair below. Full AON DV remains unqualified.

### OT-AON-MIXED-VIF-EVENT-WAIT — edge-qualified virtual-interface event list

- **State:** Integrated at `07d8ba6df`; [paired focus and neighboring tests plus the unchanged AON smoke](session_logs/2026-09-23_opentitan_spi_aon_postfix.json) pass. This covers the observed smoke only.
- **Requirement:** IEEE 1800-2017/2023 §§9.4.2 and 25.9 wake an event-OR control on the first selected virtual-interface member edge, respecting each leaf's edge qualifier and cancelling sibling waits.
- **Cause and boundary:** The target lowered mixed negedge/anyedge VIF lists to static events even though single-VIF waits were dynamic. A new per-leaf edge-mode wait handles the tested reset and pin branches, same-slot wake, rearm, rebinding, cancellation, and null-VIF rejection. Full event-control and AON DV qualification remain open.

### OT-SPI-ASSOC-FIND-INDEX — keyed associative locator

- **State:** Merged in [PR341](https://github.com/dsellerbrock/iverilog-uvm/pull/341) at `7943dffd1` after exact-head Ubuntu 24.04 success. The [candidate evidence](session_logs/2026-09-23_opentitan_assoc_find_index_multi_object_focus.json) records that the released SPI Device compile advanced to a separate queue-randomize error, which is now resolved; the UCRT64 checkout failed certificate trust before compiler execution.
- **Requirement:** IEEE 1800-2017/2023 §7.12.1 `find_index()` returns matching associative keys with their declared type, rather than ordinal positions.
- **Boundary:** Integral and string keys are tested; wildcard/object keys and other associative locators remain loud unsupported cases. The separate queue `std::randomize` rejection is cleared; the pinned SPI Device compile still reports later vector-context diagnostics.

### OT-CLASS-EVENT-MULTI-OBJECT-LIST — event controls lose object identity
- **IEEE issue:** [#440](https://github.com/dsellerbrock/iverilog-uvm/issues/440) tracks the multi-object class-event identity gap (DD-051).


- **State:** Merged in [PR341](https://github.com/dsellerbrock/iverilog-uvm/pull/341) at `7943dffd1` after exact-head Ubuntu 24.04 success. The [paired RED reducer](../../evidence/ot-class-event-multi-object-list-triage-20260923/README.md) now passes at runtime in both editions; see the shared [candidate evidence](session_logs/2026-09-23_opentitan_assoc_find_index_multi_object_focus.json).
- **Requirement:** IEEE 1800-2017/2023 §15.5 `@(a.ev or b.ev)` wakes on either selected class object's event. The candidate gives each leaf its existing per-object waiter and joins them for a one-shot event control.
- **Boundary:** Explicit `triggered()` call syntax remains DD-052; no full named-event or OpenTitan DV qualification is claimed.

### OT-SPI-STD-RANDOMIZE-QUEUE — constrained scope queue argument

- **State:** Focused implementation integrated at `512d53539` following compiler commit `c44dc1dd4`; the paired scope tests pass. The former [RED reducer](../../evidence/ot-spi-std-randomize-queue-20260923/README.md) now passes with `-g2017`. The pinned SPI Device compile no longer reports this queue-randomize rejection but has eight later vector-context diagnostics; no application compile or DV pass is claimed.
- **Requirement:** IEEE 1800-2017/2023 §18.12 scope `std::randomize` accepts its queue argument with an inline size constraint and preserves the queue on an unsatisfiable solve.
- **Boundary:** Support is limited to one-dimensional local integral queues whose length is exactly constrained, through 65536 elements. A declared queue maximum is honored; nonexact or over-limit requests are diagnosed and rolled back. Other argument forms and arbitrary queue sizing are not supported. This bounded implementation does not qualify the full §18.12 clause.
- **Evidence:** [Revision-scoped focus](session_logs/2026-09-23_scope_queue_randomize_focus.json).

### OT-SPI-INSIDE-CONST-ARRAY — unpacked parameter array in an `inside` set

- **State:** The ordinary-expression path was implemented at `88f0e9044`; [earlier paired evidence](session_logs/2026-09-23_inside_array_named_event_integration.json) preserves that scope. The separate constraint-context path is integrated at `b7551af50`; the [postfix record](session_logs/2026-09-23_opentitan_spi_aon_postfix.json) shows the pinned SPI Device fileset now compiles without the kind-26 error. The later [solver replay](session_logs/2026-09-23_opentitan_spi_csrng_next.json) advances past the JEDEC sampling cap but still fails at a separate large-range exact-`dist` call.
- **Requirement:** IEEE 1800-2017/2023 §11.4.13 recursively traverses an unpacked array in an `inside` set to its singular elements and applies asymmetric wildcard equality to integral comparisons. The independent queue-concatenation form remains tracked under [OT-SPI-QUEUE-ARRAY-CONCAT](#ot-spi-queue-array-concat).

### OT-SPI-QUEUE-ARRAY-CONCAT — unpacked array concatenation assigned to a queue

- **State:** Integrated at `2e648c7ec`; the [paired focus, neighbor, and pinned compile record](session_logs/2026-09-23_opentitan_spi_aon_postfix.json) shows both released SPI Device queue-concatenation sites clear. The [original two-form reducer and diagnosis](../../evidence/opentitan-spi-device-array-pattern-vector-20260923/README.md) remains historical.
- **Requirement:** IEEE 1800-2017/2023 §10.10 permits an unpacked array concatenation in an assignment-like context; queue conversion must preserve element order and length. The pinned fileset compiles, but DV does not pass.

### OT-SPI-JEDEC-SAMPLING-LIMIT — configured flash-mode smoke solver ceiling

- **State:** The previous `ral.jedec_id.randomize()` 1024-tuple enumeration-limit failure is cleared by the locally committed, unpublished isolated full power-of-two nested-domain sampler at `df9f167f4`. The unchanged configured SPI smoke now reaches a later, separate exact-`dist` failure at `spi_device_pass_base_vseq.sv:146`; see [OT-SPI-LARGE-EXACT-DIST-SAMPLING](#ot-spi-large-exact-dist-sampling).
- **Evidence:** The [paired revision-scoped record](session_logs/2026-09-23_opentitan_spi_csrng_next.json) preserves the reducer and application replay. Neither the former focused pass nor reaching a later smoke failure qualifies SPI Device DV.
- **Selected JEDEC check:** A separate pinned pre-DV JEDEC case with three named patches on a copied source tree compiled under `-gcommercial-unsafe` with exit 0, zero errors and zero warnings. Its guarded runtime exited 0 with exactly five continuous-code bytes (`num_cc=5`), JEDEC ID `BEA55A`, one checked completion marker, and no bad diagnostics. This scoped copied-source pass leaves the full SPI Device DV blocker and historical 49-case census unchanged; see [checked JEDEC evidence](../../evidence/opentitan-spid-jedec-checked-20260929/README.md).

### OT-SPI-LARGE-EXACT-DIST-SAMPLING — large-range exact `dist` in flash-mode sequence

- **State:** The local coupled-range candidate passes its paired focus, but the unchanged released flash smoke still stalls after UVM `PRE_START`. A bounded profile now finds wide-scalar feasible-domain enumeration before the distribution call; that is the next performance blocker, and SPI DV remains open.
- **Requirement:** IEEE 1800-2017 §18.5.10 and 1800-2023 §18.5.9 require uniform distribution over legal value combinations; exact `dist` weights must be respected.
- **Evidence:** [Original RED and replay](session_logs/2026-09-23_opentitan_spi_csrng_next.json), [current focused candidate and released replay](../../evidence/opentitan-spi-lazy-item-20260923/result.json), and [solver profile](../../evidence/opentitan-spi-pass-large-dist-profile-20260923/followup.md). Do not infer a pass from compiler tests or a running UVM sequence.

### OT-CSRNG-BLKLEN-CONSTANT-PART-SELECT — instance-hierarchical width in CSRNG

- **State:** The same-name interface-array parser error at pinned `tb.sv:85` is cleared by locally committed, unpublished `6410b956c`; compilation now stops with 12 elaboration errors, including hierarchical `BlkLen` used as a constant indexed part-select width at `tb.sv:152/162`.
- **Requirement:** IEEE 1800-2017/2023 §11.5.1 requires a positive constant indexed width; the released module-instance path is outside Annex A's constant-primary grammar. Keep Icarus strict. A revision-bound [two-width overlay](release_overlays/opentitan/csrng_blklen_width.patch) substitutes the pinned 128-bit value without disabling the assertions.
- **Evidence:** [Paired legality triage](../../evidence/opentitan-csrng-blklen-triage-20260923/FINDING.md), [pristine failure](session_logs/2026-09-23_opentitan_spi_csrng_next.json), and [selected overlay](release_overlays/README.md). The configured smoke now reaches UVM after the local loader and scheduler fixes, then fails on a separate constraint-solver restriction. DV is unqualified.

### OT-CSRNG-ARRAY-WORD-SIZE-CRASH — forward net-array driver metadata

- **State:** Locally fixed at `6e1af2425`: VVP now resolves forward concat-driven packed net-array metadata after driver attachment. Paired 2017/2023 positive and invalid-driver controls pass. This is unpublished; later CSRNG blockers remain.
- **Evidence:** [Pre-fix crash and reducer](../../evidence/opentitan-csrng-array-crash-triage-20260923/README.md) and [current released replay](../../evidence/opentitan-csrng-timezero-scheduler-20260923/result.json).

### OT-CSRNG-TIMEZERO-INIT-SCHEDULER — startup propagation starves procedural mode assignment

- **State:** Local scheduler candidate moves generated initialization fanout into the time-zero active slot. The faithful packed-tri reducer and startup boundaries pass in both editions; the released CSRNG smoke now reaches UVM but fails at a separate solver restriction. Broad gates and publication remain pending.
- **Requirement:** IEEE 1800-2017/2023 §§4.5 and 4.9.1 schedule initialization and continuous-assignment events in the time-zero slot with procedural startup; an unbounded pre-start drain must not starve time-zero processes.
- **Evidence:** [Reducer, invalidated false green, and trace](../../evidence/opentitan-csrng-post-load-triage-20260923/README.md) and [current paired/release result](../../evidence/opentitan-csrng-timezero-scheduler-20260923/result.json).

### OT-CSRNG-CFG-JOINT-DIST — published ordered conditional-fiber sampler

- **State:** Private source-tree Icarus implements bounded exact ordered conditional-fiber sampling in vvp/vvp_z3.cc. It proves guards and due weights across every feasible earlier-stage prefix before RNG, samples inactive subjects by the ordinary exact path, and rejects unproved coupled/randc/UNKNOWN/cap cases loudly. Existing guard focus passes 22/22, initial new paired cases 6/6, added independent-weight/randc/prefix-cap cases 6/6, registered legacy focus 34/34, and registered JSON focus 34/34. The final expanded broad legacy gate passed 6581 total with 6576 ordinary passes, zero failures, two not implemented, three expected failures, bundled VPI 131/131, negatives 155/155, and runtime invariants 15/15; private real-DPI UVM passed 358/358. Full JSON passed 3616/3616 with zero failures. Pinned CSRNG and OTP advance beyond cfg.randomize() but remain **0/1 DV each** at time zero on separate nested-VIF handoff and class-specialization identity blockers, with no pass marker or meaningful traffic. The solver patch is published in [PR #358](https://github.com/dsellerbrock/iverilog-uvm/pull/358); private binaries are not installed.
- **Requirement:** Conditional hard `dist` constraints are legal under §§18.5.4/18.5.7 (2017) and §§18.5.3/18.5.6 (2023). When an earlier `solve ... before` stage resolves a guard, prove activation for every feasible prefix before any RNG draw; retain exact active weights, ordinary exact inactive-subject sampling, and rollback. Same-stage or unproved guards, UNKNOWN, unsupported weights/caps, and randc interactions must remain loud rather than being treated as inactive or sampled with bias.
- **Scope:** The published implementation changes only `vvp/vvp_z3.cc` and dedicated paired 2017/2023 constraint tests/manifests. The coordinator owns private build, broad gates, pinned CSRNG/OTP replays using named disposable overlays, evidence, review, and PR. Installed Caliptra tools and pinned source checkouts remain unchanged.
- **Evidence:** [Existing candidate and pinned CSRNG replay](../../evidence/opentitan-csrng-proven-guard-replay-20260923/result.json), [paired CSRNG reducer/trace](../../evidence/opentitan-csrng-cfg-joint-dist-20260923/README.md), [focused proven-guard tests](session_logs/2026-09-23_joint_proven_guard_focus.json), [pinned OTP overlay replay with nested cfg reducers](../../evidence/opentitan-otp-backdoor-path-overlay-20260924/README.md), and [paired coupled-child RED](../../evidence/opentitan-joint-ordered-guard-red-20260924/README.md). The OTP compile also has 46 nonfatal `sorry` diagnostics and an ignored constraint item; those remain separate DV qualification gaps. [Private focus and released replays](../../evidence/opentitan-joint-ordered-guard-candidate-20260924/README.md). [Registered paired review-branch cases](../../ivtest/regress-joint-proven-guard-legacy.list).

### OT-ROM-CTRL-STARTUP-RSS — selected smoke exhausts bounded VVP memory

- **State:** The selected copied-source smoke clears `cfg.randomize()` with native PRINCE DPI, but its 4 GiB/10 s replay completes the 8,192-word ROM init and hits the RSS cap at 4,135.9 MiB after 6.166 s. There is no selected DV pass or pass marker; the 49-target census is unchanged. An earlier replay omitted `-d`, emitted 40,960 missing-PRINCE-symbol errors, and is excluded from this conclusion.
- **Narrowing:** Replacing only per-word `std::randomize` with `$urandom` still hits the cap (4,141.2 MiB). Omitting the entire encrypted-write call lowers peak RSS to 2,768.8 MiB and exits, but reports `KmacDataODataKnown_A` and `TEST FAILED CHECKS`. Keeping the encryption path while omitting only its final `write39integ` still hits the cap (4,115.5 MiB). This points to work before the final deposit in `rom_encrypt_write32_integ`; the integrated residual growth is unresolved. Both write variants are functionally invalid diagnostics.
- **Reducer/allocator diagnosis:** A guarded package-only pre-deposit reducer reaches 203.9 MiB at 1,024 words; address S&P alone reaches 139.0 MiB. At one versus 256 words, live VVP objects and malloc block counts stay flat in both modes, while macOS `DefaultMallocZone` allocated space rises from 20.9 to 54.5 MiB (address) or 71.3 MiB (full path). The evidence points to allocator high-water growth under temporary array-copy churn, without a demonstrated VVP ownership leak. Disabling `MallocNanoZone` did not reliably reduce the full-path peak. No VVP patch or selected ROM DV pass is claimed.
- **Evidence:** [Bounded corrected-DPI replay and copied-source A/B](session_logs/2026-09-29_ot_rom_ctrl_bounded_memory_triage.json). No full ROM Control DV or new 49-target census is claimed.

### OT-CSRNG-NESTED-VIF-HANDOFF — released genbits VIF value lost

- **State:** The scoped `elab_expr.cc` and `tgt-vvp/eval_object.c` fix selects the named child of the class-held parent VIF at runtime and preserves that physical child's instance identity. Paired strict 2017/2023 legal, missing, wrong-type, hidden-modport, null, rebind, and parameterized-layout focus passes 14/14 in both harnesses; neighboring VIF cases pass 184/184 each. A declared child with no physical parent now compiles and produces a null-receiver runtime fatal. The final private `ivl` is `a2470636e85fced3aacc6df62f790e32615e339f8dca012f18191d60eaa708bd`. Final broad legacy passes 6,601 total with zero failures, full JSON 3,640/3,640, and real-DPI UVM 358/358.
- **Released DV:** Pinned CSRNG with its named disposable BlkLen overlay and explicit `-gcommercial-unsafe` compiles with the final private tool, but remains **0/1 nonstandard compatibility DV**. It advances past the former 0 ps null nested-VIF failure to 1,000 ps, then fails an unknown CSR backdoor field check, reports `TEST FAILED CHECKS`, a TL-UL assertion, and exit 1. No meaningful CSRNG command traffic or scoreboard comparison occurs. The exact unknown-field cause is unresolved. The compiler still skips a `mon_cb` monitor event, assumes a monitor condition false, and ignores an `int_state_read_enable_c` constraint item, so full DV checks are not qualified.
- **Boundary:** Zero-concrete-instance parameterized or array nested children remain explicitly unsupported because their specialization cannot be inferred safely from the available parsed instance metadata. Keep them out of IEEE pass claims; preserve pinned source and all released checks. The unknown CSR field and monitor warnings need separate work after this one-blocker PR.
- **Evidence:** [PR #363](https://github.com/dsellerbrock/iverilog-uvm/pull/363), [original bytecode and RED](../../evidence/opentitan-csrng-nested-vif-handoff-20260924/README.md), and [final focused and pinned replay](../../evidence/opentitan-csrng-nested-vif-fix-20260925/README.md).

### OT-CSRNG-INLINE-RECEIVER-PROPERTY-CONSTRAINT — direct owner-held randomize receiver

- **State:** [PR #366](https://github.com/dsellerbrock/iverilog-uvm/pull/366) recognizes an unindexed owner-held receiver such as `req.randomize() with { req.clen == 12; }` and resolves the direct qualified member against the randomized object. The paired strict 2017/2023 reducer was 0/4 in each legacy/JSON runner on PR #365 and is 4/4 each after the fix. Neighboring tests pass 11/11 each, full legacy 6,617 total with zero unexpected failures, full JSON 3,656/3,656, and `-g2012` real-DPI UVM 358/358.
- **Requirement:** IEEE 1800-2017/2023 §§18.7 and 18.7.1 govern inline target and explicit caller lookup; §§18.6.1 and 18.6.3 govern randomizing the selected object and rollback. The tested direct receiver path preserves target-class name shadowing, distinct caller handles as fixed state, `local::` qualification, and failed-solve rollback; an absent receiver member is rejected.
- **Released DV:** The pinned CSRNG smoke uses explicit nonstandard `-gcommercial-unsafe` and native AES DPI. The previous first-item randomization fatal is absent, and its scoreboard observes one SW-app instantiate command. It remains **0/1 released compatibility DV** at `AesSecCmDataRegKeySca` at 16,454,635 ps with one UVM_ERROR, `TEST FAILED CHECKS`, no completed generate/genbits check, and no pass marker despite VVP exit zero.
- **Boundary and evidence:** Same-object aliases and explicit-`this` caller fallback remain separate strict-language gaps DD-059/60; this fix does not qualify general inline receiver identity or full clause 18. The [revision-scoped commands, focused tests, broad gates, and release replay](../../evidence/opentitan-csrng-inline-receiver-20260925/README.md) preserve the pinned source and checks. The later AES assertion has its own blocker below.

### OT-CSRNG-AES-FINAL-ROUND-STATE-ASSERTION — whole-array assertion reads a late net word

- **State:** [PR #367](https://github.com/dsellerbrock/iverilog-uvm/pull/367) publishes the scoped VVP fix. A paired strict 2017/2023 reducer was RED in both editions: the positive state update and scalar assertion pass, but the equivalent whole-array assertion fails after a net-array input changes later in the antecedent's clock slot. A deliberate bad update fails both assertions. The fix passes the registered 1/1 legacy and 2/2 JSON focus, including second-word, held-force, and strength-resolved net-array controls. Full legacy passes 6,618 total with zero unexpected failures, JSON 3,658/3,658, negatives 155/155, SVA dual-engine 62/62, VPI with PLI1 140/140, and real-DPI UVM 358/358.
- **Requirement and cause:** IEEE 1800-2017 §7.4.3 and 2023 §7.4.6 allow fixed unpacked-array equality; both editions §§16.5.1, 16.9.3, and 16.12.7 require the prior Preponed values in the nonoverlapped consequent. `%hist/on/av` enabled array-owned history, but net-backed words change through their underlying wires and bypass the array's snapshot-before-write path. `%load/preponed/av` then read live words. VVP now enables and reads the existing per-wire first-write history for integral net-array words, while retaining a held force's visible bits and leaving other array storage on its old path.
- **Released DV:** With the pinned OpenTitan source, hash-checked disposable BlkLen overlay, unchanged AES assertion, native AES DPI, and explicit nonstandard `-g2017 -gcommercial-unsafe`, the final private VVP completes the released `csrng_smoke_test` sequence at 77,830,086 ps. The scoreboard observes SW-app instantiate, generate, and uninstantiate; the UVM summary reports zero errors/fatals and `TEST PASSED CHECKS`. This is **1/1 released nonstandard compatibility CSRNG DV**, separate from strict IEEE and UVM regression results.
- **Boundary and evidence:** The compile still warns that `int_state_read_enable_c` is ignored by the constraint solver. That warning and broader CSRNG coverage remain separate; this smoke result does not qualify all OpenTitan DV or the full assertion clause. Same-slot changes to a force overlay need their own history assessment. [Paired RED, exact source/overlay hashes, focused checks, and native-DPI replay](../../evidence/opentitan-csrng-aes-final-round-20260925/README.md) preserve the checks and distinguish the nonstandard release profile.

### OT-OTP-CLASS-SPECIALIZATION-IDENTITY — factory sequencer type identity fixed in PR #360

- **State:** The scoped `elab_scope.cc` change at bb92498ad keys supported concrete multi-value class actuals by effective value. The original factory cast now accepts equal positional/named/default forms and rejects unequal forms in paired 2017/2023 runs. Registered focused legacy and JSON tests pass 6/6 each; the final-image full legacy gate passes 6,587 total with zero failures, VPI 131/131, negatives 155/155, and runtime invariants 15/15. Full JSON passes 3,622/3,622 with zero failures, and real-DPI UVM passes 358/358. Private `ivl` is `57eec3fc…ca423f3`, and the installed Caliptra compiler remains unchanged.
- **Released DV:** Pinned OTP with the unchanged named RAM-path overlay and native DPI clears `cfg.randomize()` and DCLPSQ, then fails `GrantKnown_A` in `prim_arbiter_tree.sv:206` at 1,559,061 ps. One UVM_ERROR, `TEST FAILED CHECKS`, no pass marker, and no meaningful checked traffic make this **0/1 released DV** despite VVP exit zero. The responsible arbiter instance is not yet identified. Its assertion stays enabled; this is a separate blocker for a later PR. CSRNG also remains 0/1 after its nested-VIF handoff clears, on an unknown CSR backdoor field and incomplete monitor elaboration.
- **Boundary and evidence:** The fix changes only the central concrete specialization key and paired tests. A legal dependent-width value formal is still rejected before keying and is recorded as a separate support limit, not an IEEE pass. The pinned OpenTitan source remains clean. The fix is published in [PR #360](https://github.com/dsellerbrock/iverilog-uvm/pull/360). See the [pre-fix factory reducer](../../evidence/opentitan-otp-dd056-factory-registry-20260924/README.md) and [final pinned replay, focus, and gate records](../../evidence/opentitan-otp-class-identity-20260924/README.md).

### CALIPTRA-UNSAFE-VIRTUAL-DISPATCH-REACHABILITY — called task falsely waived (selected P1)

- **State:** Independent paired baseline review found a called interface task reached through a concrete base handle to a virtual `Derived.go` override. The earlier explicit `-gcommercial-unsafe` compiler accepted its overlap with a continuous value-0 drive; VVP drove value 1. This violates the campaign rule that called or uncertain task writes reject. A private elaborate.cc candidate passed [28/28 dedicated and 34/34 neighboring controls](../../evidence/caliptra-unsafe-virtual-dispatch-20260924/README.md), including called virtual rejection and proven-unused allowance. The installed ivl SHA-256 `6ec92c4825dc51e3810d1cb22405071f033015626d39cf3db92c319aeb9d3b10` passes [shared paired P1 focus 28/28](../../evidence/caliptra-unsafe-virtual-dispatch-20260924/shared_focus.json). Its [strict full-top guard](../../evidence/caliptra-icarus-l0-strict-p1-20260924/README.md) still rejects exactly 46 mixed-driver overlaps with zero other errors or Preponed warnings, and launches no runtime. The [P1-install broad legacy gate](../../evidence/caliptra-virtual-final-ivtest-gate-20260924.log) exits zero: 6,555 total, 6,550 passed, zero failed, two not implemented, three expected failures; bundled VPI 131/131, negatives 155/155, and VVP invariants 15/15 also pass. The [final REAL DPI UVM umbrella](../../evidence/caliptra-virtual-final-real-dpi-uvm-20260924.log) passes 358/358 with both VIF smokes. The [full JSON compiler/VVP suite](../../evidence/caliptra-virtual-final-json-gate-20260924.log) passes 3,536/3,536 with zero failures; pristine compatibility review remains; PR #350 merged at c5679aa31.
- **Scope:** The selected implementation may change only `elaborate.cc` and dedicated paired 2017/2023 tests/evidence. Prove reachable overrides are live for the concrete interface instance; retain rejection of uncertain dispatch and genuine overlaps, while preserving the exception for proven-unused task writes. Coordinator owns shared builds, full gates, pinned replay, and review. The [16-case paired 2017/2023 RED](../../evidence/caliptra-interface-driver-reducer-20260923/virtual_override_reachability_result.json) includes called virtual, unused virtual, direct called, and nonvirtual called controls.

### CALIPTRA-L0-INTERFACE-MIXED-DRIVERS — released full top violates variable driver rule

- **Campaign profile:** The selected 52 Caliptra L0 cases use explicit `-gcommercial-unsafe` as the main nonstandard compatibility lane, with the original testbench checks and zero-error gate intact. Strict mode is the focused IEEE guard for genuine mixed-driver overlaps; the full-top strict compile is historical baseline evidence. Named test-selected Caliptra/OpenTitan patches are applied only to disposable copies under the [release overlay guide](release_overlays/README.md), preserving pinned checkouts.
- **State:** Latest P1-installed strict Icarus compilation of the pinned v2.1.2 `caliptra_top_tb` exits 46 on 46 continuous/procedural driver overlaps across two local `axi_if` instances, including with the released internal-TRNG define; it emits zero Preponed sampling warnings and launches 0/52 L0 runtimes. Before PIC integration, an opt-in `-gcommercial-unsafe` candidate compiled the same top after proving that each overlapping task write is unreachable for its concrete interface instance; the existing direct called, unknown, exported, and live-writer controls reject, but the later P1 virtual-dispatch called-task RED exposed an unsafe false waiver in that pre-P1 image. The pre-PIC exact native-vector first compatibility runtime was 0/1 with 51 unrun, 621 instruction-trace entries, simulation exit 1, zero pass/fail markers, and 17,467 bad diagnostics; original TLU, SOC IFC, and LSU assertions act at 43.865 us. Its reported retired-instruction and cycle counters are zero because no final CSR dump was reached. A separate hash-guarded copied-reset diagnostic case was also 0/1. The integrated PIC candidate passes paired focus 4/4. Its initial exact unsafe compile crashed exit 139 on a null `Nexus::first_nlink()` in the new cprop traversal, but a cprop null guard now lets the exact top compile to VVP. The [exact null-guard first-case replay](../../evidence/caliptra-icarus-l0-unsafe-pic-nullguard-first-20260924/smoke_test_veer/result.json) completes with firmware/simulation exits 0, one pass marker, zero fail markers, 633 retired instructions, 4,348 cycles, and 634 trace commits, but 17,863 bad diagnostics fail the unchanged zero-error gate. It is nonstandard compatibility 0/1 with 51 unrun; the former 43.865 us terminal SOC/TLU/LSU fatal is absent. The selected VIF repair now passes the full real-DPI UVM gate 358/358; PIC source work remains suspended while remaining error-root review continues after P1 broad legacy, full JSON 3,536/3,536, and REAL DPI UVM gates passed. The [fresh VIF-install exact unsafe first case](../../evidence/caliptra-icarus-l0-unsafe-vif-first-20260924/README.md) also fails nonstandard compatibility 0/1 with 51 unrun and 17,863 diagnostics despite 633 retired instructions and a pass marker. No strict or pristine compatibility L0 pass is established; the separate combined disposable-copy diagnostic passes one case.
- **Latest profile checkpoints:** The [installed P1 strict summary](../../evidence/caliptra-icarus-l0-strict-p1-20260924/summary.json) has compile exit 46, 46 genuine overlaps, zero other errors or Preponed warnings, and 0/52 runtimes attempted. The [bundled-BFM reset-copy summary](../../evidence/caliptra-icarus-l0-diagnostic-reset-vif-20260924/summary.json) is `diagnostic_reset_overlay` 0/1 with 51 unrun, 633 retired instructions, one pass marker, zero startup errors, exactly 17,844 checker prints, and clean pinned sources/fingerprints. The [combined reset/checker disposable-copy summary](../../evidence/caliptra-icarus-l0-diagnostic-combined-p1-20260924/summary.json) passes `diagnostic_reset_checker_source_overlay` 1/1 with 51 unrun, zero bad diagnostics, one pass marker, 633 retired instructions, 4,348 cycles, and 634 trace commits; this is separate from pristine unsafe 0/1 and IEEE conformance. The runner now uses per-case firmware source roots, and a focused check across all 52 selected names and frozen patch hashes checks each named patch target, keeps the other 50 on the pinned source root, and rejects cross-target patch-target tampering. Existing one-case results are unaffected. The preliminary sequential `--all` diagnostic run was intentionally stopped during `smoke_test_mbox` after `smoke_test_veer` printed PASS; preserved partial output at `evidence/caliptra-icarus-l0-diagnostic-combined-all-p1-20260924/` has no aggregate result and is unqualified. [During/after provenance](../../evidence/caliptra-l0-active-sweep-provenance-20260924/README.md) confirms both 5,139-entry copied firmware trees differ from pinned source only by their respective named patch and xPack GCC 15.2 toolchain hashes remained unchanged. A new ephemeral-JTAG-port profile passes focused copy and bind-error checks but has no runtime; a bounded-parallel wrapper is pending.
- **Requirement:** IEEE 1800-2017/2023 §§6.5 and 10.3.2 prohibit a procedural assignment to a variable also driven continuously. The 23 assignments per instance in `caliptra_top_tb_axi_complex.sv` overlap task-body assignments declared by `axi_if`. The existing paired legal forwarding, direct-overlap, direct-called-task, and uncalled-task controls agree between Icarus and Slang in both editions; they did not cover the virtual-dispatch called path now selected as a P1 soundness breach. No unmodified release configuration avoids this conflict: globally excluding those tasks leaves active `m_axi_bfm_if.rst_mgr`, read, and write calls unresolved. A release-side separation of the task-bearing BFM interface from the continuously forwarded internal interfaces, or otherwise a single legal driver per member, is needed. No standards-correct elaborator fix is established for the released source shape.
- **Evidence:** [Latest integrated PIC strict replay](../../evidence/caliptra-icarus-l0-strict-pic-nullguard-20260924/summary.json), [pre-PIC unsafe first-case result](../../evidence/caliptra-icarus-l0-unsafe-final-first-20260924/smoke_test_veer/result.json), [paired driver reducers](../../evidence/caliptra-interface-driver-reducer-20260923/README.md), [copied-reset post-AES runtime](../../evidence/caliptra-icarus-l0-diagnostic-aesfix-first-20260923/summary.json), [port-binding reducer](../../evidence/caliptra-ahb-vif-anyedge-20260923/README.md), [reset-race reducer](../../evidence/caliptra-l0-timezero-reset-overlay-20260923/README.md), and [AES sensitivity fix](../../evidence/caliptra-aes-sensitivity-fix-20260923/README.md). Pre-PIC shared installation passes driver 34/34 and interface-port/ref 28/28 paired cases in each legacy and JSON harness. The pre-PIC full legacy gate passes 6,551 total with zero failures, plus VPI 131/131, negatives 155/155, and VVP invariants 15/15; pre-PIC JSON gate passes 3480/3480. The pre-PIC real-DPI UVM umbrella loaded DPI but failed 356/358 with `vif_smoke` and `vif_smoke_v2` compile diagnostics on `count`; the narrow elaborate.cc VIF repair now passes the [shared real-DPI UVM gate](../../evidence/caliptra-vif-final-real-dpi-uvm-20260924.log) 358/358 with zero failures/skips and both smokes passing. The first VIF-install legacy gate failed one `sv_packed_mixed_driver_compound` expected-warning gold mismatch (6,555 total; 6,549 pass, two not implemented, three expected failures), while VPI 131/131, negatives 155/155, and invariants 15/15 pass. Its corrected gold passes focused legacy 1/1 and JSON 2/2, but the broad rerun was intentionally stopped after the P1 unsafe-dispatch RED; the [P1-install full JSON gate](../../evidence/caliptra-virtual-final-json-gate-20260924.log) passes 3,536/3,536 with zero failures, while PR qualification remains open. The UVM result does not establish a Caliptra L0 pass. Preserve the strict diagnostic and every L0 checker; keep compile-blocked cases separate from runtime failures and the separate `csrng_tb` unit run outside the 52-test numerator. Pristine explicit unsafe results are nonstandard compatibility evidence, while copied-testbench or checker-patched runs carry distinct diagnostic qualifications; none is IEEE conformance.

### CALIPTRA-VIF-DISJOINT-PROPERTY-WRITER — legal VIF reset write falsely overlaps count output

- **State:** Selected after the pre-PIC real-DPI UVM umbrella loaded real DPI but failed 356/358. Before the repair, both `vif_smoke.sv:96` and `vif_smoke_v2.sv:96` failed strict and explicit unsafe compilation with a continuous/procedural-driver error on `count`, although the VIF procedural write targets `reset` and the DUT output drives disjoint ordinary `PWire` member `count`. Temporary paired 2017/2023 REDs reproduce the false overlap. The shared installed elaborate.cc candidate passes [paired focus 20/20](../../evidence/caliptra-vif-disjoint-property-writer-20260924/shared_new_focus.log) and [neighbor controls 16/16](../../evidence/caliptra-vif-disjoint-property-writer-20260924/shared_neighbor_focus.log). Both real-DPI VIF smokes previously compiled/ran privately with `PASS counter_test` and zero UVM error/fatal. Installed iverilog/ivl/vvp SHA-256 prefixes are 1590b064/ba1dda3d/e9b7a64a. The [full shared real-DPI UVM gate](../../evidence/caliptra-vif-final-real-dpi-uvm-20260924.log) now passes 358/358 with zero failures/skips and both `vif_smoke` variants passing. The [fresh VIF-install first case](../../evidence/caliptra-icarus-l0-unsafe-vif-first-20260924/README.md) fails nonstandard compatibility 0/1 with 51 unrun and 17,863 diagnostics. The first broad legacy gate had one expected-warning gold mismatch; focused retest passes, but its rerun was intentionally stopped after the separate P1 unsafe-dispatch discovery. P1-install broad legacy, full JSON 3,536/3,536, and REAL DPI UVM gates now pass; pristine compatibility review remains pending. This earlier VIF UVM result is separate from Caliptra L0.
- **Requirement and hypothesis:** Distinct ordinary interface members are distinct variables. Exact same-member overlap, uncertain VIF receiver, modport alias, and same-member or uncertain port/ref aliases must still reject in strict and unsafe modes. A known-disjoint `ref` actual is a separate legal case that the current tool still falsely rejects. The installed direct-property repair resolves the concrete receiver/member false overlap. The known-disjoint `ref` actual remains separate false-rejection debt; the P1 virtual-dispatch repair now passes installed paired focus 28/28 and broad legacy, JSON, and REAL DPI UVM gates without widening `-gcommercial-unsafe` waivers.
- **Scope and evidence:** The implementation agent owns `elaborate.cc` plus dedicated paired 2017/2023 ivtest fixtures/golds/evidence only; coordinator owns shared build/install, manifests, the full real-DPI UVM rerun, and broader qualification. The [pre-VIF-fix failing real-DPI UVM gate](../../evidence/caliptra-final-real-dpi-uvm-20260924.log) is the application baseline; the [current shared gate](../../evidence/caliptra-vif-final-real-dpi-uvm-20260924.log) passes 358/358. PIC source work remains suspended after its earlier completed first case failed 0/1 on 17,863 diagnostics. The fresh VIF-install case also fails 0/1; P1-install broad legacy, full JSON 3,536/3,536, and REAL DPI UVM gates pass; pristine compatibility review remains pending, while error-root triage stays open. Pinned sources and all L0 checks stay intact.

### CALIPTRA-VIF-DISJOINT-REF-ACTUAL-FALSE-REJECT — known-disjoint ref member remains rejected

- **State:** Independent paired 2017/2023 review shows `write_ref(vif.reset)` with a continuous `bus.count` drive is rejected in strict and unsafe modes. Direct `vif.reset` compiles, and a same-member `ref` actual correctly rejects. The disjoint `ref` error predates the selected VIF member-name repair and does not block the released Caliptra L0 path.
- **Boundary:** Unresolved `ref` actuals lose `property_idx` before driver analysis. Treat this as separate follow-on debt; no source fix is selected in the current lane. Preserve same-member and uncertain-alias rejection, the narrow unsafe waiver, pinned sources, and all L0 checks. The [paired strict/unsafe reducer](../../evidence/caliptra-vif-disjoint-property-writer-20260924/ref_member_identity_result.json) records legal direct disjoint, false-rejected disjoint `ref`, and correctly rejected same-member `ref` controls in both editions.

### CALIPTRA-AES-FUNCTION-LOCAL-SENSITIVITY — automatic function locals trigger other `always_comb` callers

- **State:** The narrow interval-aware sensitivity subtraction passes 8/8 paired 2017/2023 focused cases, plus 10/10 legacy and 8/8 JSON synthesis neighbors. The pre-fix two-caller automatic-function reducer spun at time zero; the pre-PIC corrected full top advances through 621 instruction-trace entries before separate pinned TLU, SOC IFC, and Veer assertions fail. The sensitivity defect is locally fixed, but no L0 pass is established.
- **Root cause and requirement:** `NetBlock::nex_input` precisely records constant bit writes but `NexusSet::rem` subtracts only exactly matching ranges, leaving a whole-vector read of the fully written local in sensitivity. IEEE 1800-2017/2023 §9.2.2.2.1 excludes written expressions from `always_comb` implicit sensitivity while retaining reads of unwritten bits. A dedicated interval-aware subtraction is selected; exact event-expression matching must remain unchanged.
- **Evidence:** [Paired reducer and VVP comparison](../../evidence/caliptra-aes-timezero-20260923/README.md), [focused fix](../../evidence/caliptra-aes-sensitivity-fix-20260923/README.md), and [post-fix diagnostic runtime](../../evidence/caliptra-icarus-l0-diagnostic-aesfix-first-20260923/summary.json). Preserve the pinned sources and every L0 check. A checked first-case pass is required before expanding to 52.

### CALIPTRA-NESTED-PACKED-PREPONED-SAMPLING — constant packed selects sampled live

- **State:** The local nested constant packed-select fix passes paired 2017/2023 focus 2/2 in each legacy and JSON harness. The final installed strict full-top compile emits zero Preponed sampling warnings where its predecessor emitted 32; the top still fails on 46 mixed drivers, so this establishes no L0 runtime pass. The pre-VIF-fix full legacy gate passes; JSON passes 3480/3480 and pre-VIF-fix real-DPI UVM failed 356/358 on separate VIF smoke compile diagnostics. The current shared VIF installation passes real-DPI UVM 358/358; the installed P1 repair passes paired focus 28/28, while fresh P1-install broad legacy, full JSON 3,536/3,536, and REAL DPI UVM gates pass.
- **Requirement and boundary:** Concurrent assertion operands must use their Preponed values. The previous elaboration left nested constant packed selections on a live-value path, which could produce false assertion failures. The fix reconstructs the nested constant selection and retains its typed select metadata. Dynamic nested-index sampling remains unqualified.
- **Evidence:** [Paired RED, candidate and boundary](../../evidence/caliptra-packed-struct-preponed-20260924/README.md) and [latest strict compile](../../evidence/caliptra-icarus-l0-strict-pic-nullguard-20260924/summary.json). The L0 runner treats a remaining sampling warning as disqualifying.

### CALIPTRA-POST-AES-INTERRUPT-ASSERTIONS — first firmware case fails after interrupt enable

- **State:** The pre-PIC exact native-vector `-gcommercial-unsafe` first case was 0/1 at 43.865 us after 621 instruction-trace entries. The Veer TLU fast-interrupt flush assertion reports first; SOC IFC `ERR_HWIF_IN` calls `$fatal`, and the Veer store-buffer assertion reports in the same terminal interval. The separate copied-reset diagnostic case has the same 0/1 outcome. None is a pass. A third hash-guarded copied-source probe observes unknown PIC interrupt input before that interval; a tiny paired 2017/2023 reducer copied from the pinned PIC priority tree gives `selected_priority=zzzz` from 32 known-zero leaves, proving an isolated simulator defect. The full runtime causal relation remains open. The initial integrated PIC exact unsafe compile crash was repaired by a cprop null guard. The first case now completes without the 43.865 us terminal SOC/TLU/LSU fatal, but its 17,863 diagnostics disqualify the pass banner and simulation exit 0; nonstandard compatibility remains 0/1.
- **Boundary:** The preceding MLDSA/KV `SVA ERROR` details arise from eager checker-function evaluation under false property antecedents in a paired reducer, without an observed outer assertion action. IEEE 1800-2017/2023 §16.6 disallows side effects in assertion-expression functions; the pinned KV/MLDSA checker functions print internally. A [read-only paired assessment](../../evidence/caliptra-sva-eager-assessment-20260924/README.md) shows pure-property truth and exactly one true consequent failure in the direct and legal pure controls, while the impure function is called five times. §16.12.7 conditions consequent evaluation on antecedent match, but this illegal source shape does not prove an assertion-verdict defect or authorize an implementation. Every printed error still violates the L0 zero-error rule. A paired 2017/2023 test of the actual 2,422-bit SOC IFC packed input type shows `$isunknown` agrees with a per-bit check for all-known and one-X controls, ruling out that isolated false-positive mechanism.
- **Evidence:** [Exact first-case result](../../evidence/caliptra-icarus-l0-unsafe-final-first-20260924/smoke_test_veer/result.json), [assertion/action triage, copied-source probes, and PIC priority reducer](../../evidence/caliptra-post-aes-runtime-fatal-triage-20260923/README.md), [checker side-effect reducer](../../evidence/caliptra-post-aes-sva-triage-20260923/README.md), [source-legality assessment](../../evidence/caliptra-sva-eager-assessment-20260924/README.md), and [packed-type `$isunknown` control](../../evidence/caliptra-post-aes-hwif-unknown-20260923/results.json). Preserve the pinned sources and every L0 checker. The separately selected PIC fix below has a narrow cprop.cc scope.

### CALIPTRA-TIMEZERO-ASSERTION-READ-ONLY-DEBT — early reset-dependent assertion diagnostics

- **State:** The unchanged-BFM first case has 19 startup actions: 14 Veer time-zero deferred-immediate failures, two Adams Bridge first-edge immediate errors, and three DOE cold-reset SVA failures. A [six-nanosecond passive VPI trace](../../evidence/caliptra-l0-timezero-passive-vpi-20260924/README.md) records unknown reset-dependent checker inputs before the first clock; it does not prove whether Icarus scheduling or released testbench ordering caused them. A hash-guarded copy of the **bundled Caliptra BFM** shifts its initial power-good drive by `#0` and removes all 19 startup actions. The completed [reset-copy first case](../../evidence/caliptra-icarus-l0-diagnostic-reset-vif-20260924/README.md) is still `diagnostic_reset_overlay` **0/1** with 51 unrun, one pass marker, 633 retired instructions, and exactly 17,844 vacuous KV/MLDSA checker messages as its only bad diagnostics.
- **Boundary:** Read-only causal assessment and copied-BFM diagnostic; no selected compiler fix, assertion suppression, pristine L0 pass, or IEEE qualification follows. Pinned sources, fingerprints, and released checkers remain intact. Keep the reset-copy denominator separate from pristine `-gcommercial-unsafe` nonstandard compatibility.

### CALIPTRA-EAGER-CONSEQUENT-CHECKER-DIAGNOSTICS — read-only compiler-source triage

- **Observation:** In the [PIC-install first-case simulation](../../evidence/caliptra-icarus-l0-unsafe-pic-nullguard-first-20260924/smoke_test_veer/result.json), 4,461 KV and 13,383 MLDSA checker-function `SVA ERROR` lines account for 17,844 of 17,863 bad diagnostics. The other 19 are 16 early plain errors and three reset-SVA errors before or at the first 5 ns edge; no later other errors were recorded. All 17,863 disqualify the case under the unchanged zero-error rule. The [fresh VIF-install replay](../../evidence/caliptra-icarus-l0-unsafe-vif-first-20260924/README.md) independently fails 0/1 with the same 16 + 3 + 17,844 decomposition.
- **Boundary:** [Paired 2017/2023 pure/impure controls](../../evidence/caliptra-sva-eager-assessment-20260924/README.md) trace the eager calls to `pform.cc` consequent-expression capture before the observed wait. The pinned checker functions print internally and violate the assertion-expression side-effect restriction in §16.6, so these messages alone do not prove a legal assertion-verdict defect. No compiler-source implementation is selected. The separate four-helper disposable source overlay below has paired controls and keeps the remaining real assertion diagnostics and L0 zero-error gate intact.

### CALIPTRA-L0-CHECKER-SOURCE-OVERLAY — four impure helpers on a disposable copy

- **State:** A [frozen four-helper patch and paired controls](../../evidence/caliptra-l0-checker-source-overlay-20260924/README.md) remove nine internal detail `$display` calls from the KV and MLDSA secret-key, public-key, and signature helpers on a disposable copy of pinned `caliptra_top_sva.sv`. All comparisons, returns, property expressions, disable guards, and outer failure actions remain byte-for-byte. Paired 2017/2023 pure/impure vacuous, true-pass, true-fail, reset-disable, and same-slot NBA controls pass [4/4](../../evidence/caliptra-l0-checker-source-overlay-20260924/results.json) with identical outer actions and zero versus 18 eager inner prints. The opt-in full-top compile exits zero with zero sampling warnings; the [combined reset/checker first case](../../evidence/caliptra-icarus-l0-diagnostic-combined-p1-20260924/README.md) passes diagnostic qualification 1/1 with 51 unrun, zero bad diagnostics, one pass marker, and 633 retired instructions.
- **Boundary:** This is a selected coordinator-owned **diagnostic source-copy overlay**, disjoint from the P1 `elaborate.cc` compiler repair. The runner records patch/pre/post hashes and separate `diagnostic_checker_source_overlay` or `diagnostic_reset_checker_source_overlay` qualification. The reset-only diagnostic is 0/1 with 51 unrun and exactly 17,844 checker prints; neither it nor the completed combined diagnostic 1/1 enters the pristine nonstandard compatibility numerator. First-mismatch internal detail is lost, while unchanged outer actions and all other L0 checks remain. The combined one-case pass is a diagnostic source-copy result only. The preliminary sequential `--all` output was stopped and has no aggregate result; no pristine or 52-case L0 pass is claimed.

### CALIPTRA-L0-EPHEMERAL-JTAG-PORT-DIAGNOSTIC — isolated listener for bounded replays

- **State:** The runner's explicit `--ephemeral-jtag-port` uses a hash-guarded disposable copy of only the pinned top testbench, changing its sole JTAG `ListenPort` from `63224` to `0`. A [focused copy and bind-error gate](../../evidence/caliptra-icarus-l0-runner-20260923/check_ephemeral_jtag_port.py) passes. The runner rejects JTAG server/bind diagnostics even with a pass marker. With unsafe, the copied bundled Caliptra BFM reset overlay, and the four-helper checker source overlay, the separate label is `diagnostic_reset_checker_source_ephemeral_jtag_port_overlay`. The [same-profile first case](../../evidence/caliptra-icarus-l0-ephemeral-jtag-first-20260924/README.md) passes diagnostic qualification **1/1** with 51 unrun, firmware/VVP exits zero, one pass marker, zero bad/DPI/JTAG diagnostics, 633 retired instructions, 4,348 cycles, and 634 trace commits; source/tool integrity matches. The [bounded four-job exact 52-case wrapper](../../evidence/caliptra-icarus-l0-parallel-runner-20260924/README.md) was deliberately SIGTERM-stopped after one completed `smoke_test_veer` PASS. Longer first-cohort cases were still in released CRT `.data` copy loops; static map/disassembly shows about 17,700-17,900 instructions to `main` versus about 2,400 after 22 minutes, so the 1,800-second limit cannot reach `main`. Its partial output at `evidence/caliptra-icarus-l0-patched-52-20260924/` is unqualified, with no aggregate result or orphan VVP. A same-profile `smoke_test_mbox` pilot with `--timeout 14400` is active at `evidence/caliptra-icarus-l0-mbox-long-pilot-20260924/`.
- **Boundary:** Pinned sources and every L0 check remain unchanged. The stopped sequential partial output at `evidence/caliptra-icarus-l0-diagnostic-combined-all-p1-20260924/` belongs to the prior `diagnostic_reset_checker_source_overlay` profile and has no aggregate verdict. [During/after source-copy and xPack toolchain attestation](../../evidence/caliptra-l0-active-sweep-provenance-20260924/README.md) applies to that stopped run; it does not qualify the new-profile 1/1 result or IEEE conformance. The new-profile first case is also separate from the pristine unsafe denominator; no 52-case pass is claimed.

### CALIPTRA-PIC-PACKED-PARTIAL-DRIVER-CYCLE — dependent packed partial drivers form a self-cycle

- **State:** Selected for one narrow cprop.cc implementation lane after paired 2017/2023 PIC RED and passing independent disjoint-driver and whole-array controls. The installed RED yields `selected_priority=zzzz` from 32 known-zero leaves. A private bounded-reachability cprop candidate passes the paired PIC tree and dependent-slice cases; a partially uncovered 3-bit whole-vector feedback RED changes baseline `zzz` to candidate `z11` in both editions, with a nonfatal target `uwire` multi-driver warning. Integrated paired PIC focus passes 4/4. Its first exact unsafe compile crashed exit 139 from a null `Nexus::first_nlink()` in the new cprop reachability traversal; an integrated null guard now compiles the exact top to VVP. The [exact null-guard first-case replay](../../evidence/caliptra-icarus-l0-unsafe-pic-nullguard-first-20260924/smoke_test_veer/result.json) completes with firmware/simulation exits 0, one pass marker, zero fail markers, 633 retired instructions, 4,348 cycles, and 634 trace commits. It is still nonstandard compatibility 0/1 with 51 unrun because 17,863 bad diagnostics violate the zero-error gate. Removal of the prior terminal 43.865 us SOC/TLU/LSU fatal is a material runtime advance, not an L0 pass; the pre-PIC unsafe 0/1 remains historical and separate. The latest strict top still exits 46 with 46 mixed-driver errors and zero Preponed warnings, so strict L0 remains 0/52 runtimes attempted. The prerequisite real-DPI UVM gate now passes 358/358; PIC source work remains suspended while error-root triage continues after P1 broad legacy, full JSON 3,536/3,536, and REAL DPI UVM passes.
- **Requirement and cause:** Disjoint nested packed continuous assignments must drive their selected bits without feeding the destination into itself. `PGAssign::elaborate` to `PEIdent::elaborate_lnet_common_` creates `NetPartSelect::PV`; `cprop_functor::lpm_part_select` in `cprop.cc:207-347` blends PV drivers into `NetConcat` despite a combinational path from destination structural inputs back to a candidate PV driver input. Direct VP and whole-vector reduction paths show why a VP-only guard is insufficient. The selected cprop guard checks bounded combinational reachability and stops at flip-flops; independent disjoint drivers, two-state, registered, and unrelated-reader controls must retain their behavior.
- **Boundary and evidence:** A separate fully covered 2-bit whole-vector feedback RED remains `zz` instead of `11` because `elab_net.cc`/`netmisc.cc:3170` `collapse_partselect_pv_to_concat` forms the cycle during elaboration. That path is recorded debt, outside this selected cprop.cc source scope; no full packed-driver qualification is claimed. The coordinator owns shared builds, installation, manifests, integration and pinned replay. [PIC RED and controls](../../evidence/caliptra-post-aes-runtime-fatal-triage-20260923/pic_priority_tree_reducer.sv), [source-shape reducer](../../evidence/caliptra-post-aes-runtime-fatal-triage-20260923/pic_packed_slice_reducer.sv), and [paired partial whole-read RED](../../evidence/caliptra-post-aes-runtime-fatal-triage-20260923/packed_whole_read_cycle_min.sv) establish the scoped mechanism; all original L0 assertions remain active. [Integrated paired focus](../../evidence/caliptra-pic-integrated-focus-20260924.log), [intermediate strict compile](../../evidence/caliptra-icarus-l0-strict-pic-20260924/summary.json), and [intermediate unsafe compile crash](../../evidence/caliptra-icarus-l0-unsafe-pic-first-20260924/summary.json) record the caught candidate issue. The [final strict compile](../../evidence/caliptra-icarus-l0-strict-pic-nullguard-20260924/summary.json) and [completed unsafe compatibility replay](../../evidence/caliptra-icarus-l0-unsafe-pic-nullguard-first-20260924/summary.json) record the installed null-guard checkpoint.

### CALIPTRA-L0-DOE-STATUS-SVA — Verilator retains a pre-reset DOE assertion attempt

- **State:** The full selected pinned Caliptra v2.1.2 / Adams Bridge v2.0.3 Verilator L0 replay is 51/52, zero timeouts; `smoke_test_doe_scan` alone emits one SVA error despite exit 0 and a pass banner. The released DOE property is unchanged.
- **Cause and evidence:** The [passive released timing trace](../../evidence/caliptra-doe-root-cause-20260923/assessment.md) shows `clear_obf_secrets=1` sampled on RDC edges before reset, DOE reset pulsing low before the consequent, and `clear_obf_secrets=0` at the first resumed RDC edge. IEEE 1800-2017/2023 §16.12 requires the pending attempt to be aborted by `disable iff`; Verilator checks the stale direct-`|=>` obligation anyway. The [reducer and restored v5.052 source diagnosis](../../evidence/caliptra-doe-verilator-midwindow-20260923/assessment.md) isolate that simulator behavior. Paired Icarus causal controls abort the pre-reset attempt and detect a deliberately fresh post-reset failure.
- **Boundary:** This is a Verilator L0 diagnostic, not an Icarus DOE DV pass or a full Caliptra qualification. No assertion suppression or pinned-source change is justified. A corrected simulator must rerun the unchanged DOE test with zero SVA errors; Verilator implementation is outside this campaign's selected scope.

### OT-SPI-DEVICE-PACKAGE-PARAM-FOREACH — lexical package array bounds

- **State:** Merged in [PR339](https://github.com/dsellerbrock/iverilog-uvm/pull/339) after Ubuntu 24.04 exact-head CI passed; the [follow-on record](session_logs/2026-09-23_spi_adc_pr339_repair_focus.json) covers paired focused tests and the pinned compile. Full SPI Device DV remains open.
- **Requirement:** IEEE 1800-2017 §18.5.8.1 and the paired 2023 `foreach` mode use the actual constant package array when it is referenced from a class method.
- **Cause and boundary:** The bound resolver skipped lexical package parameters. It now finds the array before reporting a missing target; missing and scalar targets still fail. No general package-parameter or coverage qualification is claimed.

### OT-SPI-DEVICE-STRUCT-QUEUE-PARENLESS-SIZE — packed-struct queue method lookup

- **State:** Merged in [PR339](https://github.com/dsellerbrock/iverilog-uvm/pull/339) after Ubuntu 24.04 exact-head CI passed; [paired regression evidence](session_logs/2026-09-23_spi_adc_pr339_repair_focus.json) and the pinned SPI Device compile show the `.size` errors removed. Full DV remains open.
- **Requirement:** IEEE 1800-2017/2023 §7.10.2.1 permits `q.size` as well as `q.size()` for an ordinary queue, including a queue of packed structs.
- **Cause and boundary:** The parenthesis-free path treated `size` as a packed-struct element member before queue dispatch. It now selects the queue method; a missing member on a genuine packed struct still fails.

### OT-ADC-DIRECT-CAST-WIDTH — unbased fill loses cast width in constraints

- **State:** Merged in [PR339](https://github.com/dsellerbrock/iverilog-uvm/pull/339) after Ubuntu 24.04 exact-head CI passed; the [paired runtime and negative evidence](session_logs/2026-09-23_spi_adc_pr339_repair_focus.json) passes. Indexed ADC inner array sizing still blocks the pinned smoke.
- **Requirement:** IEEE 1800-2017/2023 §§5.7.1 and 6.24.1 fill the destination width of a direct typed cast before its value participates in a constraint.
- **Cause and boundary:** Constraint IR encoded `'1` as a one-bit constant before knowing the cast width. The direct fill now has the cast width; sized `1'b1` and two-state X/Z conversion remain distinct. Four-state X/Z constraint casts and fills wider than the current 64-bit IR are explicit unsupported boundaries, not silently solved values.

### OT-PWRMGR-CASE-EXIT-STACK-BALANCE — case body exits bypassed selector cleanup

- **State:** Merged in [PR336](https://github.com/dsellerbrock/iverilog-uvm/pull/336) at `6ee647ca7` after a completed exact-head Ubuntu 24.04 CI success. Full release DV qualification remains open.
- **Requirement:** IEEE 1800-2017/2023 §§9.4, 12.5, and 12.8 preserve procedural `case` and loop exit behavior without leaving a VM selector operand behind.
- **Cause and closure:** Plain, unique, and real-selector codegen popped only at the common case exit; `break`, `continue`, `return`, and `disable` bypassed it. The selector now pops after dispatch and before each body. [Paired-edition and pinned pwrmgr evidence](session_logs/2026-09-23_pwrmgr_case_exit_stack_balance.json) records the focused checks and application replay. Other pwrmgr compile warnings and full OpenTitan DV qualification remain open.

### SV-MACRO-MATCHED-BRACKET-ACTUALS — square-bracket macro actuals split at comma

- **State:** Merged in [PR335](https://github.com/dsellerbrock/iverilog-uvm/pull/335); Ubuntu 24.04 exact-head CI passed after merge.
- **Requirement:** IEEE 1800-2017/2023 §22.5.1 protects separators inside matched `()`, `[]`, and `{}` pairs. Mismatched pairs must not close another delimiter's nesting.
- **Cause and closure:** The scanner counted only `()` and `{}` with one depth integer. A typed delimiter stack now handles matched `[]` and rejects mismatches while preserving strings, comments, and PR334's casted-literal handling. The [paired baseline](../../evidence/macro-bracket-assessment-20260923/README.md) and [integrated checks](session_logs/2026-09-23_vpi_macro_integrated_focus.json) bound this correction; 2023 triple quotes remain separate.

### VPI-LEGACY-VARIABLE-BIT-FORCE-CB-REGISTRATION — bit-select callbacks registered illegally

- **State:** Merged in [PR335](https://github.com/dsellerbrock/iverilog-uvm/pull/335); Ubuntu 24.04 exact-head CI passed after merge.
- **Requirement:** IEEE 1800-2017/2023 §38.36.1 disallows `cbForce` and `cbRelease` registration on variable bit-selects while allowing the supported whole-variable and net-bit forms.
- **Cause and closure:** The legacy `vpiRegBit` and `vpiNetBit` handles shared one registration path. Removing `vpiRegBit` from that path yields a diagnostic and null registration; [paired baseline and integrated VPI checks](session_logs/2026-09-23_vpi_macro_integrated_focus.json) cover the boundary. Callback statement-object identity is a separate open defect.

### CALIPTRA-SVA-LONG-SEQUENCE-REGISTER-COLLISION — generated SVA names collide at step 1000

- **State:** Merged in [PR335](https://github.com/dsellerbrock/iverilog-uvm/pull/335); the focused executable checks and integrated pinned-filelist compile passed locally. Ubuntu 24.04 exact-head CI passed after merge.
- **Requirement:** IEEE 1800-2017/2023 §16.7 permits finite sequence concatenation without a 999-step naming limit. Each sampled check and action must remain observable; compilation alone is insufficient.
- **Cause:** `pform_make_assertion` reserved `b999` for antecedent capture and reused `b999` for consequent step index 999. The [paired baseline and pinned Caliptra PM failure](../../evidence/caliptra-pm-formal-elab-triage-20260923/result.json) reproduce the collision.
- **Evidence:** The [focused record](session_logs/2026-09-23_caliptra_long_sequence_register_focus.json) links executable 999/1000/1001-step 2017/2023 tests and local gates. On the [locally integrated PR334 tree](session_logs/2026-09-23_caliptra_pm_integrated_compile.json), the clean pinned PM formal filelist compiles without diagnostics in both editions. This is compile-only evidence; full Caliptra DV and formal proof remain open.

### OT-ADC-CASTED-UNBASED-INLINE-MACRO-ARG — cast splits a constraint macro actual

- **State:** Merged in [PR334](https://github.com/dsellerbrock/iverilog-uvm/pull/334) after local checks and Ubuntu 24.04 exact-head CI passed; based on the clean pinned Earlgrey-PROD-M6 `adc_ctrl_sim` release target.
- **Requirement:** IEEE 1800-2017/2023 §§22.5.1, 6.24.1, and 5.7.1 require cast delimiters and unbased unsized literals inside a macro actual to retain their nesting so an inner comma or right parenthesis does not end the actual.
- **Cause and evidence:** The first ADC smoke compile diagnostic follows `adc_value_t'('1)` inside `DV_CHECK_RANDOMIZE_WITH_FATAL`; `ivlpp/lexor.lex` consumes the three-character `'('` sequence as one quoted-item token, leaving the inner `)` to end the macro argument. [Pinned target and reducer record](session_logs/2026-09-23_opentitan_adc_macro_arg_baseline.json) distinguishes the failing casted macro from ordinary-literal macro and procedural-cast controls.
- **Closure:** The [candidate and local tests](session_logs/2026-09-23_opentitan_adc_macro_arg_focus.json) preserve cast parentheses and assignment-pattern braces and pass the selected regression gates. The pinned ADC target now compiles but ignores a filter-size constraint, so this is semantic DEBT, not ADC DV success. The separate direct nonmacro cast-width runtime mismatch also remains.

### OT-ADC-NESTED-DYNAMIC-ARRAY-RESIZE — ADC `filter_cfg[][]` randomization

- **State:** The typed outer-resize slice is locally integrated at `0bf19490c`; indexed inner `.size` lowering remains open, so pinned ADC smoke still fails at time 0. See the [focused candidate record](session_logs/2026-09-23_parallel_compiler_followon_focus.json).
- **Evidence:** The [paired reducer and pinned-source assessment](../../evidence/opentitan-adc-class-resize-triage-20260923/assessment.md) shows that `filter_cfg` is a nested dynamic array of packed structs, not class handles. VVP's `class-handle collection` error applies an overbroad guard to this type. The outer size reaches solver IR, but typed resize/write-back is missing; the indexed inner `.size` constraint is separately dropped during elaboration ([DD-047](DISCOVERED_DEBT.md)).
- **Closure:** Finish indexed inner resize and nested size/element constraints with correct retention and rollback in both IEEE editions; keep actual class-handle growth semantics distinct. Rerun pinned ADC DV only after these semantics pass focused positive, negative, and boundary tests. No ADC DV pass is established.

### OT-ADC-FIXED-2D-PACKED-STRUCT-MEMBER-CONSTRAINT — selected fields in fixed arrays

- **State:** Integrated at `8cffebe38` and `d5c7366c3`. Strict paired affected JSON and legacy focus passes 8/8 each; `make check` passes. Full JSON ran 4,097 tests with 32 failures in unrelated families, while both new fixed-2D tests pass. Broad legacy and application corpora remain deferred until the saved error corpus is addressed.
- **Requirement:** IEEE 1800-2017 §§7.4.1, 18.3, 18.5.8.1 and 2023 §§7.4.1, 18.3, 18.5.7.1 require constraint `foreach` over each declared fixed-array dimension to bind the selected packed-struct field of the corresponding rand element. Signed fields retain signed comparisons, and failed randomization preserves old values.
- **Cause and evidence:** `pexpr_to_constraint_ir` restricted the selected packed-struct member branch to one fixed dimension and manually flattened one index. Reusing the existing checked fixed-array leaf helper supports multidimensional fixed arrays, while a signed cast preserves member type. The [paired focused record](session_logs/2026-09-29_ot_adc_fixed_2d_struct_member.json) includes baseline failure, candidate success, and 8/8 in each focused regression harness.
- **Boundary:** This repair covers fixed arrays. The pinned ADC configuration uses nested dynamic arrays, whose indexed inner `.size` and whole-array ordering remain separate gaps. Its copied-source selected compile and queued DV replay are unchanged; no ADC DV pass is established.

### OT-PARTINFO-CONSTRAINT-DIAGNOSTIC-FALLBACK — stop after the specific error

- **State:** All four saved 2017/2023 compile-negative cases now emit their original one specific error instead of two. Focused PartInfo JSON and legacy each pass 18/18, including legal rand-index values and invalid symbolic members; `make check` passes. No test gold changed. See [focused evidence](session_logs/2026-09-29_ot_partinfo_diagnostic_fallback_focus.json).
- **Cause and expected behavior:** Three constant-then-parameter-selector branches in `elaborate.cc` continue after `constraint_constant_ir_` has already increased `Design::errors`. Stop that fallback only after an actual diagnostic; an empty error-free constant attempt must still reach symbolic rand-index selection. Keep value-slot capture behavior unchanged.
- **Boundary:** Verify both invalid constants, valid member-range/rand-index controls, and symbolic invalid-member rejection before any full gate. This repairs diagnostic identity/count, not a new language feature or OpenTitan DV target.

### OT-CONSTRAINT-FIXED-QUEUE-SIZE-FUNCTION-ARGUMENT — preserve the selected size leaf

- **State:** A SIZE-only guard narrowing in `vvp/vvp_z3.cc` passes the strict paired 2017/2023 fixed-queue function-argument positives, fixed-element function-argument negatives, and contradictory size controls: 6/6 exact gold. The build-tree VVP, `make check`, and independent review pass. See [focused evidence](session_logs/2026-09-29_ot_fixed_queue_size_function_argument_focus.json).
- **Cause and behavior:** The compiler emits `SIZE/property 0/leaf 1` for the `q[1].size()` argument and a wrapper that reads that leaf. VVP rejected every fixed-queue function dependency before stage planning. Allowing SIZE alone lets the existing stage solver write back `q[1]` first, capture `plus_one(1)`, then solve `q[0].size()==2`; a fixed queue element argument remains unsupported.
- **Boundary:** The saved full JSON gate remains 4,097/32 at `d5c7366c3`; no broad gate or application DV run followed this focused change. Dynamic queue-size function arguments have a separate staging gap and are outside this ticket.

### OT-SDF-INTERCONNECT-PORT-BOUNDARY — annotate variable-driven input ports

- **State:** The VPI boundary fix passes strict 2017/2023 one-edge reg, `always_comb`, and wire controls with the exact 20 ps delay; focused SDF JSON passes 15/15, including the three saved failures, singleton guard, and selected-resolver neighbors. `make check` passes. The original 4,097/32 gate remains historical. See [the focused evidence](session_logs/2026-09-29_ot_sdf_interconnect_port_boundary_focus.json).
- **Cause and expected behavior:** `vvp/vpi_priv.cc` recognizes only `vvp_fun_buft` as a delayable interconnect port; `d696b6934d` correctly introduced BUFZ and `.sample` to preserve settled variable-port semantics. Extend recognition only for the same physical port-boundary connectivity, preserving its existing checks.
- **Boundary:** Prove exact 20 ps in strict paired tiny controls and run only the SDF interconnect and singleton-guard neighbors before another broad JSON gate. No application DV pass follows from SDF regression repair.

### OT-PORT-BOUNDARY-SIGNEDNESS-VCD-GOLD — retain input actual signedness

- **State:** DONE at compiler commit `0db31d850` and test-only commit `ebbb14df9`. The [revision-scoped gate record](session_logs/2026-09-29_ot_port_boundary_broad_gate.json) has JSON 4107/0, legacy 6875 total/0 failed, VPI 140/140, real-DPI UVM 361/361, negatives 154/154, and SVA dual-run 62/62.
- **Cause and correction:** The variable-input BUFZ temporary defaulted unsigned, so signed actuals zero-extended. It now carries source signedness. The refreshed `vcd-dup` gold retains all 23 named ordered value streams and duplicate warnings; only identifier aliases changed.
- **Boundary:** These gates belong to the cited commits. The 49-case OpenTitan corpus and OTP DV runtime have no new verdict; clauses 11 and 23 remain partial/provisional.

### OT-JSON-STALE-EXPECTATIONS-11 — correct obsolete JSON gate fixtures

- **State:** Focused 11/11 corrected JSON entries pass together on the unchanged installed compiler. Family JSON lists pass 5/5, 7/7, and 11/11; corresponding legacy lists pass 5/5, 7/7, and 10/10 with legal and fail-closed neighbors. The original exact 4,097/32 gate remains historical. See [the focused session](session_logs/2026-09-29_ot_json_stale_expectations_focus.json).
- **Expected behavior:** Keep nonempty supported queue/associative checks positive; preserve compile-negative checks for illegal reference actuals and unsupported wide covergroup bins; verify true-guard null/X state failure and rollback while a false guard succeeds; compare object RNG against an object-RNG oracle. The clocking drive remains fail-closed with its current specific diagnostic.
- **Boundary:** This is test maintenance, not a compiler capability claim. Only the affected ivtest sources/configs/golds/manifests may change. The other 21 saved JSON failures require separate fixes before a new broad gate, and the 49-target OpenTitan count is unchanged.

### OT-OTP-NESTED-TYPE-ARGUMENT-METHOD-ELABORATION — concrete environment override bodies

- **State:** Integrated `b27957d8d` passes strict paired 2017/2023 UVM direct/explicit-typedef controls, ten adjacent specialization controls, focused real-DPI UVM 1/1, and `make check`. The exact 282-source selected OTP compile exits zero with no errors/sorry and 56 warnings; its image contains concrete `build_phase` and `connect_phase` bodies. The no-workaround DD-089 image subsequently passed one guarded selected OTP smoke. See [focused evidence](session_logs/2026-09-29_ot_otp_nested_type_method_integration.json) and the [runtime record](session_logs/2026-09-29_ot_otp_typedef_only_static_init.json).
- **Requirement:** A concrete default-parameterized environment used as a type actual of a concrete parameterized UVM test must have its overriding `build_phase` and `connect_phase` bodies emitted; generic masters and false generate branches remain lazy. Confirm exact IEEE 1800-2017/2023 clause references before qualification.
- **Cause and evidence:** `NetScope::evaluate_type_parameter_` resolves bare `ENV=env` through a type-only class reference, so the concrete environment carrier lacks its methods. The explicit typedef control requests ordinary elaboration and works. The integrated fix requests that elaboration for a non-deferred bare type actual in a concrete specialization. The selected original parameterized OTP environment now emits its concrete `build_phase` and `connect_phase` bodies; the pre-fix image does not. DD-089 is now fixed for the selected compile: its concrete registry initializer is emitted without the named source workaround; that image also passed one guarded selected OTP runtime.
- **Boundary:** The selected copied-source -gcommercial-unsafe/native-DPI OTP smoke passes with one TEST PASSED CHECKS marker, UVM warnings/errors/fatals 0/0/0, and 457 matched scoreboard TL A/D items. This is a scoped compatibility result; the older historical 49-case count is unchanged.

### DD-089 — typedef-only concrete class static initialization

- **State:** DONE at `56f4bc756`. Paired 2017/2023 reducers pass for explicit, bare-default, class-scoped, nested, package-qualified and later-used aliases; generic masters and false-generate branches stay lazy. Exact-image gates pass JSON 4117/0, legacy 6875 total/0 failed, VPI 140/140, negative 154/154 and real-DPI UVM 361/361. See the [revision-scoped record](session_logs/2026-09-29_ot_otp_typedef_only_static_init.json).
- **Requirement:** IEEE 1800-2017/2023 §§8.25, 8.9, 6.8 and 10.5 require a concrete parameterized specialization to have distinct static members and initialize its static properties once before procedural execution, even when a typedef is its only use.
- **Cause and fix:** `NetScope::add_typedefs` indexed typedefs without reaching their concrete class types. The post-root sweep now elaborates concrete explicit, default and class-scoped aliases, revisits newly created specializations before releasing static initializers, and retains caller identity for package-qualified overrides in distinct module instances. Late class-property repair preserves UVM method return types; the `randc` cap warning stays once per declaration and effective width.
- **Boundary:** The 282-source selected OTP compile emits one concrete `otp_ctrl_base_test` registry initializer without the explicit-registration overlay (0 errors/sorry, 56 warnings). Its SHA-256 82821822c92ed1f40562dfcdbe06eb6f400933dc839a2b65d03e4bef37564a82 image passes one guarded copied-source -gcommercial-unsafe/native-DPI smoke: VVP exit 0, no timeout or 6 GiB cap hit (peak 6158439080 bytes), one TEST PASSED CHECKS, UVM warnings/errors/fatals 0/0/0, and 457 matched scoreboard TL A/D items. The 20 prim access error responses are expected negative accesses, distinct from the 437 core A/D items. This is a selected compatibility DV pass, with no fresh 49-case census or broader OTP DV claim; chapter 8 remains PARTIAL.

### OT-SPI-DEVICE-CONSTRAINT-FOREACH-PATH — sparse caller-owned command keys

- **State:** Locally integrated at `c64b1791f`; [paired focused evidence](session_logs/2026-09-23_parallel_compiler_followon_focus.json) covers the released SPI shape. Full SPI Device DV and broad compiler qualification remain open.
- **Requirement:** IEEE 1800-2017 §18.5.8.1 and 2023 §18.5.7.1 iterate actual associative-array keys in a constraint `foreach` over a caller-owned hierarchical source.
- **Boundary:** The tested implementation supports unsigned integral keys up to 64 bits; invalid nonarray sources fail compilation. This does not establish general associative-array constraint coverage.

### VPI-FORCE-RELEASE-CALLBACK-STMT-OBJECT — callback origin identity

- **State:** The HDL statement-object slice and VPI API-origin callback repair merged in [PR339](https://github.com/dsellerbrock/iverilog-uvm/pull/339) after Ubuntu 24.04 exact-head CI passed. The [follow-on local gates](session_logs/2026-09-23_spi_adc_pr339_repair_focus.json) pass; broad VPI qualification remains open.
- **Requirement:** IEEE 1800-2017/2023 §38.36.1 callback `obj` identifies the force or release statement, including a shared identity for concatenated LHS targets; registration still uses the affected signal.
- **Boundary:** Compiled HDL statements expose type and source location. A VPI `put_value` force/release has no HDL source statement; its callback retains the registered target handle as the established API extension behavior. Other statement-handle relationships remain unqualified.

### CALIPTRA-LATE-DEFAULT-CLOCKING — assertions before their module default clock

- **State:** Merged in [PR334](https://github.com/dsellerbrock/iverilog-uvm/pull/334) after local checks and Ubuntu 24.04 exact-head CI passed; source/test commit `342226068` was based on `origin/main` `42f324c90`.
- **Requirement:** IEEE 1800-2017/2023 §§14.12 and 16.14.6 scope a default clocking to its containing module and permit it to supply an otherwise unclocked concurrent assertion. The declaration's later textual position must not turn earlier module assertions into missing-clock errors.
- **Cause and evidence:** The pinned clean Caliptra v2.1.2 `fv_ecc_dsa_sequencer.sv` has five assertions at lines 91–95 before its default clocking at line 97. [The revision-scoped baseline and candidate record](session_logs/2026-09-23_caliptra_late_default_clocking_focus.json) captures the five false missing-clock errors and their removal. `pform_make_assertion` parked the earlier assertions, then `pform_endmodule` popped their module before the pending-procedural flush rejected them.
- **Closure:** The fix retries parked assertions while the validated module default clock and generate scope remain in place; paired execution and rejection boundaries are tested. The pristine pinned formal file still fails on an upstream `DSA_NOP` name mismatch; a [test-specific disposable-copy overlay](session_logs/2026-09-23_caliptra_ecc_nop_overlay.json) compiles it without that mismatch. No formal proof or Caliptra DV qualification follows.

### CALIPTRA-NAMED-SEQUENCE-PARAM-CONSEQUENT — named antecedent captured as a function

- **State:** Merged in [PR333](https://github.com/dsellerbrock/iverilog-uvm/pull/333) at `bdf461a87` after local gates and completed exact-head Ubuntu 24.04 CI success. Full Caliptra DV/formal qualification remains open.
- **Requirement:** IEEE 1800-2017/2023 §§16.8 and 16.12.7 permit a named sequence in an implication antecedent and require the instance's symbolic consequent repetition to execute.
- **Evidence:** The [revision-scoped record](session_logs/2026-09-23_caliptra_named_sequence_antecedent.json) preserves the paired baseline failure, executable tests, and clean pinned ECC formal bind compile. The helper in `pform.cc` ran before named-sequence splicing; declared references now defer to its post-splice offer.
- **Closure:** Resolve the declared sequence before Boolean lowering, verify pass/fail/vacuity/disable and W=0/positive bounds at runtime in both modes, preserve an unknown-sequence diagnostic, and recompile the pinned full ECC formal bind without dropped properties. Full Caliptra DV/formal qualification stays separate.

### SVA-LITERAL-OVERLAP-FAILURE-COUNT — fixed-linear same-edge verdicts

- **State:** The fixed non-negated linear-checker subset merged in [PR332](https://github.com/dsellerbrock/iverilog-uvm/pull/332) at `5dacd0dec` after local gates and completed exact-head Ubuntu 24.04 CI success. See the [revision-scoped baseline and qualification record](session_logs/2026-09-23_sva_literal_overlap_attempt_identity.json).
- **Requirement:** IEEE 1800-2017/2023 §§16.12.7 and 16.14.1 require a separate verdict and failure action for each distinct antecedent match; §39.4.2 requires callback metadata to retain the actual attempt start.
- **Cause and correction:** A one-bit failure flag collapsed simultaneous fixed-offset failures, and X/Z checks did not become definite nonmatches. The legacy linear checker now counts distinct failed tokens and carries each start time through the VPI report. The first NFA-only attempt was ineffective and reverted.
- **Remaining boundary:** Window, unbounded, negated, and other checker families retain their earlier VPI metadata path. Full SVA and formal qualification remain open.

### CALIPTRA-PARAM-CONSEQUENT-REPEAT — symbolic repetition in an SVA consequent

- **State:** Merged in [PR330](https://github.com/dsellerbrock/iverilog-uvm/pull/330) after exact-head CI success. The [local candidate](session_logs/2026-09-23_caliptra_param_consequent_repeat_focus.json) executes the focused shape in both editions, removes the two dropped-property diagnostics from the clean Caliptra v2.1.2 formal file, and passed its required local gates. Full Caliptra DV/formal qualification remains separate.
- **Requirement:** IEEE 1800-2017/2023 §§16.9.2 and 16.12.7 require the consecutive repetition and implication to use each instance's bound with correct match, failure, vacuity, and disable behavior. Confirm exact edition wording before patching.
- **Cause and evidence:** `pform.cc` retains the bound as `rep_kind 4`, but `sva_parameter_repeat_try_assertion_` accepts only an antecedent repetition and the NFA refuses this sentinel. The [paired pinned-source and minimal-reducer baseline](session_logs/2026-09-23_caliptra_param_consequent_repeat_baseline.json) shows the property drop; a literal-bound control compiles. A separate standalone bind-target error is not the SVA defect.
- **Closure:** Reuse instance-sized bound and assertion dispatch machinery, prove executable W=2/W=3 timing, failure, overlap, vacuity, disable, and zero/invalid-bound behavior in both editions, then recompile the pinned source and run required gates. Never substitute the declaration default or count compilation alone as implementation.

### CALIPTRA-REJ-BOUNDED-RUNTIME — scoreboard/zeroize testbench race

- **State:** A minimal downstream testbench patch is focused-tested in an isolated copy. The pristine Caliptra v2.1.2 / Adams Bridge v2.0.3 release remains unmodified and fails this unit test.
- **Cause:** Independent `posedge clk_tb` processes update and inspect the same blocking counter. IEEE 1800-2017/2023 §4.7 does not order their Active-region execution; the checker can schedule zeroize a cycle late.
- **Evidence:** [Race-fix record](session_logs/2026-09-23_caliptra_rej_bounded_race_fix.json) and [patch/reducer](repros/caliptra_rej_bounded/README.md). The correction keeps queue underflow and output checks active.
- **Open work:** [Upstream PR 303](https://github.com/chipsalliance/adams-bridge/pull/303) is open. Use an explicit overlay in application replays until an adopted release contains the correction; keep pristine and patched results separate. Full Caliptra DV has not passed.

### COMMERCIAL-SIM-UNSAFE-FLAG — opt-in packed bit/logic container conversion

- **State:** The compatibility flag is implemented at `9111127532c71fc4eeaf1bab68685ade3c61296f` in [PR326](https://github.com/dsellerbrock/iverilog-uvm/pull/326); strict IEEE type checking remains the default. Focused checks and [post-merge local gates](session_logs/2026-09-23_pr326_postmerge_qualification.json) pass on the documented equivalent compiler/test tree; GitHub CI was pending at observation.
- **Requirement:** IEEE 1800-2017/2023 §7.6 array element type equivalence remains strict by default. `-gcommercial-unsafe` is an explicitly nonstandard compatibility extension limited to equal-width, equal-signedness packed `bit`/`logic` value conversion in whole queue/dynamic-array assignment and native task/function value copies.
- **Evidence:** [Revision-scoped record](session_logs/2026-09-23_commercial_unsafe_flag.json) records the focused tests and exact OpenTitan SPI compile. Enabling the flag clears its strict type errors but leaves nonblocking property assignment codegen errors. OpenTitan DV has not passed.
- **Open work:** Resolve the remaining nonblocking property assignment lowering errors before claiming SPI compile or DV success. Do not count flag acceptance as IEEE qualification or VCS equivalence.

### TASK-CODEGEN-ERROR-DROPPED — task-body target errors do not fail compilation

- **State:** CLOSED in [PR328](https://github.com/dsellerbrock/iverilog-uvm/pull/328) at `4f66ed666` after local gates and one completed current-head CI job passed. Later CI jobs remain separately observable. On base `3be18e4b6`, a class task with an unsupported target form reported a `vvp.tgt error` but returned compile status 0 and emitted an invalid image.
- **Cause:** `draw_task_definition` returns the `show_statement` error count, but `draw_scope` discards it in `tgt-vvp/vvp_scope.c`; the adjacent function path adds its count to `vvp_errors`.
- **Evidence:** Local reducer and base compile logs in `evidence/opentitan-codegen-assessment-20260923/`; [candidate local gates](session_logs/2026-09-23_opentitan_nba_codegen_focus.json) pass. The current SPI compile has zero target errors, though separate semantic degradation remains.
- **Closure:** Propagate task-body errors without suppressing diagnostics; permanently test a still-unsupported task-body form with nonzero compile status and a valid neighboring task. This does not implement the selected-bit NBA.

### VIF-NBA-SELECTED-BIT — dynamic property bit-select NBA is unsupported

- **State:** CLOSED in [PR328](https://github.com/dsellerbrock/iverilog-uvm/pull/328) at `4f66ed666` after local gates and one completed current-head CI job passed. Later CI jobs remain separately observable. On base `3be18e4b6`, five SPI Host driver assignments to `vif.sio[i]` emitted unsupported-form errors.
- **Requirement:** IEEE 1800-2017 and 1800-2023 §10.4.2 evaluate variable LHS components (including index and virtual-interface reference) and RHS when the NBA executes, with the update deferred to the NBA region.
- **Evidence:** Reduced base source and compile log in `evidence/opentitan-codegen-assessment-20260923/`; [candidate record](session_logs/2026-09-23_opentitan_nba_codegen_focus.json) includes paired-edition tests and all required local gates. Four inline-constraint index warnings and a dropped queue-pop expression still prevent an SPI semantic compile pass.
- **Closure:** Capture receiver, selector, and four-state RHS at enqueue; update only the selected packed bit in the NBA region; prove old value before NBA and captured value afterward in both editions, plus boundaries and focused neighboring regressions. Do not claim SPI DV success from codegen alone.

### OT-SPI-QUEUE-POP-DROPPED — parenthesis-free class-property queue pop is dropped

- **State:** IN_PROGRESS, locally focus-tested through `3b6d1986f` on a branch stacked after PR328. The pinned OpenTitan SPI Host source calls `cmd_check(item.data.pop_front)`; the previous compiler warned that the expression was dropped, returned success, and lost the queue mutation and byte value.
- **Requirement:** IEEE 1800-2017/2023 §§5.13 and 7.10.2.4 permit omitting empty parentheses on a direct zero-argument built-in method call; `pop_front` removes and returns the first element. The 2023 §13.4.1 parentheses rule for dereferencing a function return does not apply to this direct value use.
- **Evidence:** [Paired focused and pinned SPI compile record](session_logs/2026-09-23_opentitan_queue_pop_focus.json). The prior `evidence/opentitan-queue-pop-20260923/repro.sv` fails in both editions without parentheses; its `-DPARENS_CONTROL` form passes. The root cause is `PEIdent::elaborate_expr_class_field_` in `elab_expr.cc`.
- **Closure:** The typed `pop_front`/`pop_back` result, single queue mutation, empty-queue boundary, invalid arity, and neighboring checks pass locally. [Boundary follow-up](session_logs/2026-09-23_queue_pop_assoc_boundary.json) rejects these methods on associative arrays in expression context while preserving an associative-array element whose type is a queue. The [statement-method candidate](session_logs/2026-09-23_assoc_queue_statement_methods_focus.json) now rejects five queue-only methods on associative receivers in the shared dispatch; broad gates and CI remain open. Full SPI DV is separate.

This file is a **backlog**, not an authorization to implement. Per
`AGENTS.md`, only `.ai/ACTIVE_WORK.yaml` (status: `in_progress`, naming a
blocker ID from this file) authorizes implementation work. Reading a row
here as "next" and starting to code is exactly the failure mode this file
exists to prevent.

This is a **seed set**, not a migrated copy of `iverilog_uvm_blocker_audit.md`
/ `blocker_inventory.json` (134 grouped entries). Those documents remain the
fuller inventory; entries here were promoted because they have concrete
source/recorded evidence and a plausible closure test. Promote additional
rows from the audit into this format as they are picked up — do not bulk
import.

## Status vocabulary

| Status | Meaning |
|---|---|
| `OPEN` | Identified, not yet reproduced on current HEAD. |
| `REPRODUCED` | A current-HEAD failing reducer exists. |
| `IN_PROGRESS` | An `.ai/ACTIVE_WORK.yaml` ticket currently targets this ID. |
| `BLOCKED` | Requires architecture change or a decision beyond scope lock; see its entry for what's blocking. |
| `CLOSED` | Fixed, tested, and documented per the manifesto's Definition of Done. Record the closing PR. |
| `WONTFIX` | Deliberately out of scope (e.g. illegal-source rejection working as intended); record why. |

## Confidence vocabulary (carried from the audit)

`SOURCE` (inspected implementation path), `RECORDED` (a repo record/PR
states it — re-verify before implementing, some are stale), `QUALIFICATION`
(missing evidence for a claimed scope, not a proven wrong result),
`UNRESOLVED` (record explicitly leaves it tentative), `ARCHITECTURE`
(requirement for a future declared capability, not a reproduced defect).

## Entry format

```markdown
### <ID> — <title>

- **Area / edition:** <e.g. Randomization / edition-agnostic>
- **State:** OPEN | REPRODUCED | IN_PROGRESS | BLOCKED | CLOSED | WONTFIX
- **Confidence:** SOURCE | RECORDED | QUALIFICATION | UNRESOLVED | ARCHITECTURE
- **Evidence / reproducer:** <file:line, PR #, or session log pointer; a
  reducer path once one exists>
- **What it blocks:** <application workload / qualification claim / clause>
- **Closure requirements:** <what a CLOSED verdict must demonstrate>
- **Last verified revision:** <commit sha, or "not re-verified since audit">
```

---

### U01 — Xbar runtime/scoreboard/outstanding-request failures

- **Area / edition:** UVM and applications / edition-agnostic
- **State:** OPEN (checked traffic completes; pinned workload/UVM teardown qualification remains)
- **Confidence:** REPRODUCED
- **Evidence / reproducer:** `docs/conformance/session_logs/2026-09-04_global_constraint_solver.md`
  (5 xbar runtime logs show scoreboard mismatches; all 8 report outstanding
  requests on termination); PR #258; PR #261 (enum fix is explicitly not
  evidence these are fixed). No reducer exists yet — the session log notes
  the targeted probe hit the 300s CPU guard before completing.
- **What it blocks:** Real xbar application-level DV evidence; any claim of
  "OpenTitan xbar works."
- **Closure requirements:** Reproduce the first divergence with a bounded
  probe, reduce the simulator mechanism it exposes, and demonstrate at least
  one xbar smoke reaching normal completion with matched, checked
  request/response traffic and zero outstanding transactions at end of test.
- **Last verified revision:** `53b58890c` (P04): fresh smoke plus2repeats all complete115requests/230checked scoreboard items,4SEQPRTZMBwarnings,0errors/fatals and TEST FAILED CHECKS. All360exported source files match the prior replay. P04 fixes its independent live-parent kill reducer; it does not qualify U01. Pinned workload settings select UVM1.2, campaign library2020.3.1; no library edit or warning suppression. Evidence: `campaign-20260908/u01-after-p04`.

### Z01 — Joint solve-before stages partly supported

- **Area / edition:** Randomization / edition-agnostic
- **State:** PARTIAL. The earlier stale claim of full rejection is superseded
  by the bounded result below; the selected nested scalar-property case now
  has statistical evidence.
- **Confidence:** REPRODUCED.
- **Evidence / reproducer:** `solve child.a before b;` in
  `sv_constraint_cross_object_solve_before.v`. With `b` allowed two values
  when `child.a==0` and four when it is 1, the standard staged distribution
  gives about 500 observations per first group tuple and 250 per second-group
  tuple over 2,000 draws. The paired strict 2017/2023 test enforces those
  bounds and checks that an unsatisfiable call leaves both random values
  unchanged. It passes through both registered harnesses.
- **Root cause / fix:** The frontend already lowered `child.a` to an `r:`
  object-property path, and the VVP solver can resolve an active random leaf
  to its canonical object-graph variable. The solve-before operand allowlist
  rejected `r:` paths, so the ordering directive was dropped and class
  constraint capture failed. The frontend now accepts this path and applies
  the existing random-property and randc legality checks.
- **What it blocks:** Distribution-sensitive parent/child randomization in
  this bounded scalar form was previously unusable. Other legal nested
  ordering shapes, ordered `dist`, randc, aggregate stages, and domains beyond
  existing exact-work limits remain open.
- **Closure requirements:** Qualify more nested scalar forms and exact
  marginals/conditional probabilities, retain rollback, and keep unsupported
  shapes loud rather than silently dropping an ordering directive.
- **Last verified revision:** Fix 28 candidate on
  `agent/ieee-cross-object-solve-before-20261007`; focused evidence is in
  [`cross-object-solve-before-20261007.md`](../../evidence/solve-before-array/cross-object-solve-before-20261007.md).

### RANDOMIZE-NESTED-UNPACKED-STRUCT-MEMBER — constrain nested random struct leaves

- **Area / edition:** Randomization / IEEE 1800-2017 and 1800-2023 §18.4, §18.5.
- **State:** DONE locally; strict paired 2017/2023 and adjacent focused gates pass.
- **Requirement:** A `rand` unpacked structure randomizes its declared random members concurrently, including members reached through a nested unpacked-structure path. A class constraint on `record.nested.scalar` must constrain that leaf, not reject the outer member or lose its solver identity.
- **Evidence / reproducer:** `ivtest/ivltests/sv_constraint_nested_unpacked_struct.sv` checks `root.nested.leaf.value`, enum membership, nested `randc`, state reads, rollback, and successful resumption. The baseline at `04093c40e` emitted the prior unsupported-path diagnostic in both editions. Final evidence and source-built image hashes are in [the qualification record](../../evidence/nested-unpacked-struct-constraint-20261007/README.md).
- **Root cause:** Frontend constraint IR lowering accepted a direct struct leaf and selected elements of one-dimensional member arrays, but did not lower nested unpacked-struct paths. The runtime already traversed class properties and unpacked-struct members; the fix routes this case through that existing path representation.
- **Closure:** Finite nested paths to scalar integral/enum leaves now preserve active `rand`/`randc` qualification, canonical solver-variable identity, state reads, writeback, and transactional failure rollback. The fixed indexed outer-struct scalar-leaf slice is tracked separately below; symbolic outer indices, array/container-valued leaves, other class-handle member shapes, and unrelated ordering/distribution semantics remain separate gaps. The verified handle-in-rand-struct slice is tracked below.
- **Last verified revision:** Source-built ARM64 image recorded in the [qualification record](../../evidence/nested-unpacked-struct-constraint-20261007/README.md); strict new-case legacy and JSON/VVP lists pass 2/2 each, adjacent class/struct lists pass 15/15 and 14/14.

### RANDOMIZE-STRUCT-CLASS-HANDLE-MEMBER — randomize a handle reached through a rand struct

- **Area / edition:** Randomization / IEEE 1800-2017 and 1800-2023 §18.4 and §18.6.2.
- **State:** Bounded subset implemented and locally verified; issue #419 remains open for other container/member shapes. No CI qualification is claimed.
- **Requirement:** An enabled class handle reached through a random unpacked-struct member participates in the containing object's randomization. Aliases preserve object identity, enabled child hooks run once, and a failed solve rolls back child values and `randc` history.
- **Evidence / reproducer:** `ivtest/ivltests/sv_randomize_struct_class_handle_member.v` and its `-g2023` pair constrain the aliased child through its own constraint function and the parent, then check callback counts, rollback, and retry. The paired local build and runner results are in [the evidence record](../../evidence/ieee-rand-struct-class-handle-20261009/README.md).
- **Root cause and fix:** `randomize_struct_members_` rejected the nested class handle before the joint object-graph solve. Once that guard was narrowed, callback and constraint-state discovery still stopped at struct values. The runtime now permits handles on the joint path and traverses struct values to discover child objects without treating structs as callback receivers.
- **Boundary:** Only active class handles in `rand` unpacked structs are covered. Dynamic-array members remain fail-closed; queue, associative-array, and other aggregate member shapes are not claimed. This does not close issue #419 or clause 18.
- **Validation:** New paired cases pass 2/2 in legacy and 2/2 in JSON/VVP. The nested-struct neighbor passes 2/2 in both harnesses; the class declaration/member focus passes 15/15 legacy and 14/14 JSON/VVP after correcting the stale compile-error classification for the existing positive `sv_struct_member_constraint_fail` case.

### RANDOMIZE-INDEXED-OUTER-UNPACKED-STRUCT-MEMBER — constrain indexed struct-array leaves

- **Area / edition:** Randomization / IEEE 1800-2017 and 1800-2023 §§18.4, 18.5.
- **State:** DONE locally for constant, foreach-unrolled, and tested symbolic selectors into fixed arrays; broader IEEE support remains active.
- **Requirement:** A constraint must retain the identity of a scalar integral or enum leaf selected through a fixed array of unpacked structures, including nested unpacked-struct members and a randomized selector.
- **Evidence / reproducer:** `ivtest/ivltests/sv_constraint_indexed_outer_struct.sv` checks a descending one-dimensional array, a two-dimensional array, nested struct leaves, non-random state reads, failed-solve rollback, a symbolic selector, and an unselected X state leaf. Constant-selector history is in the [Fix 36 qualification record](../../evidence/indexed-outer-struct-constraint-20261007/README.md); Fix 37 commands and hashes are in the [symbolic-selector record](../../evidence/symbolic-indexed-outer-struct-constraint-20261007/README.md).
- **Root cause and fix:** Frontend lowering rejected indexed outer unpacked-struct paths. Constant and foreach-unrolled indices resolve to storage-order words. Symbolic selectors over fixed arrays of at most 65,536 words lower to guarded choices over each scalar leaf, with signed mathematical-index comparisons; VVP resolves each guarded state read through the existing randomization graph. X/Z checks remain conditional on the selected branch.
- **What this unblocks:** Common constrained-random record arrays whose scalar fields depend on state or other randomized fields.
- **Boundary:** Dynamic/queue/associative containers, aggregate leaves, class-handle members, arrays beyond the 65,536-word expansion bound, and wide coupled-domain sampling remain unqualified. This increment does not close clause 18 or the full IEEE 1800 objective.
- **Validation:** Both strict editions pass 2/2 in legacy and JSON/VVP focus lists, including an active 2-bit randomized selector and a selected state leaf beside an unselected X leaf. The adjacent nested-struct regression passes 2/2 in both harnesses and editions. Build and install succeed; no broad suite or OpenTitan corpus was run.
- **Last verified revision:** Fix 37 on `agent/ieee-cross-object-solve-before-20261007`; image hashes are in the [Fix 37 qualification record](../../evidence/symbolic-indexed-outer-struct-constraint-20261007/README.md).

### C01 — Untranslated inline constraints are discarded (semantic degradation)

- **Area / edition:** Frontend/randomization / edition-agnostic
- **State:** CLOSED (silent-discard defect only; local implementation unmerged)
- **Confidence:** REPRODUCED
- **Evidence / reproducer:** `make_randomize_with_expr()` in `elab_expr.cc`
  warns and continues when an inline constraint cannot be lowered, instead
  of hard-erroring — the call can be built without the requested constraint.
- **What it blocks:** Trustworthiness of any `randomize() with { ... }` call
  whose constraint shape isn't recognized; a silent-degradation risk, not
  merely a missing feature.
- **Closure requirements:** Reduce a live unsupported inline-constraint
  shape; require either correct constraint execution or an explicit failure
  — never a successful solve that silently dropped the constraint.
- **Last verified revision:** 8f298eefe accepts and discards a selected foreach item in both editions; runtime returns success with 412736472 instead of required 123. Candidate passes all required local gates and review; remote CI required before merge. Unsupported expressions remain unimplemented.

### S01 — Cross-clock overlapping implication (SVA boundary)

- **Area / edition:** Assertions/SVA / IEEE 1800-2017 and 1800-2023 16.13.3.
- **State:** SUPERSEDED (bounded fixed-chain boundary already implemented).
- **Confidence:** VERIFIED
- **Evidence / reproducer:** Commit `0ff77277c` implements the fixed-chain
  overlapping boundary. Fresh `../evidence/campaign-20260908/s01/` runs cover
  coincident edges in both source orders, strictly later consequent ticks,
  positive/negative outcomes, preponed sampling and nested clock flow.
  Three reducers pass in both editions with default and legacy SVA modes
  (12 runs); independent review confirms this bounded classification.
- **Residual scope:** Variable-length antecedents and broader multiclock
  properties remain separate obligations; this is not complete SVA qualification.
- **Last verified revision:** `2be79b2c0`; existing clock-flow/nested-flow
  regressions also pass the required integrated suite. No implementation change.

### V01 — Exact merged type-coverage bin universe (coverage correctness)

- **Area / edition:** Functional coverage / edition-agnostic
- **State:** **Re-verified CLOSED 2026-09-16** (was stale-OPEN; V01A's fix
  is merged on `main` and covers this row's own stated closure
  requirements — see below). Originally: OPEN (V01A resolves bounded
  dynamic value-bin union locally).
- **Confidence:** REPRODUCED (original defect), then RE-VERIFIED FIXED
  against a fresh build of current `main` (not just re-read from an old
  evidence file).
- **Original evidence / reproducer:** `vvp/class_type.cc`'s `type_coverage`
  used a maximum registered dynamic-family size raised to the hit count —
  not an exact union for arbitrary disjoint instance bin sets.
- **2026-09-16 re-verification:** built the LRM's own §19.11.3 worked
  example fresh (`covergroup gt(int l,h); type_option.merge_instances=1;
  option.get_inst_coverage=1; coverpoint a { bins b[] = {[l:h]}; }
  endgroup`, `gv1=new(0,1)`, `gv2=new(1,2)`, sample `a==0` on `gv1` and
  `a==1` on both) against a fresh `main`-tip build (not a stale note):
  `gv1.get_coverage()` and `gv2.get_coverage()` both return exactly
  `66.6667`, `gv1.get_inst_coverage()` returns exactly `100.0`,
  `gv2.get_inst_coverage()` returns exactly `50.0` — all four values
  match the LRM's own stated answers exactly. (Two option-scoping
  mistakes were made and corrected while building this reducer —
  `merge_instances` is a `type_option`, not `option`, and
  `get_inst_coverage()`'s return value equals `get_coverage()` unless
  `option.get_inst_coverage` is explicitly set, both confirmed against
  LRM text before concluding anything — Icarus's behavior at each
  intermediate wrong-option step was itself correct per spec.)
- **This row's own closure requirements, checked against the existing,
  passing `ivtest/ivltests/sv_covergroup_merged_value_union.v` (registered
  for both `-g2017` and `-g2023`, part of every ivtest sweep this session
  with 0 failures):** disjoint instance domains (`unsampled disjoint`,
  `partial disjoint`), a retired instance still counted
  (`retired universe`), a non-100% partial-coverage result checked
  against a hand-computed oracle (`merged hit threshold` = 100/3), signed
  range crossing, fixed-size and scalar bins, and a 64-bit wide value bin
  with no enumeration — all present and passing. This is not "coverage
  reaches 100%" trivia; it is exactly the disjoint/overlapping/partial
  oracle-checked scope this row asked for.
- **LRM's second §19.11.3 worked example checked too** (`ga(abm)` with
  differing constructor-arg `auto_bin_max` per instance, giving 96
  cumulative auto-bins): this hits a DIFFERENT, already-diagnosed
  limitation, not a silent-wrong-answer regression of V01/V01A —
  `option.auto_bin_max = abm;` (`abm` a constructor argument, not a true
  elaboration-time constant) produces a loud `sorry: covergroup option
  'auto_bin_max' is not a constant; using default 64.` `auto_bin_max`
  itself apparently isn't constructor-arg-drivable at all yet (unlike
  `bins b[] = {[l:h]}` range bounds, which V01A's fix does handle
  per-instance); not a V01/V01A regression, and already meets the
  "unsupported behavior must produce a focused diagnostic" bar as-is.
  Not filed as its own row — genuinely minor (auto-bin-max is rarely
  made constructor-dependent in practice; the common case, a fixed
  `auto_bin_max` with constructor-dependent VALUE RANGES, is exactly
  what V01A already covers) — revisit only if a real corpus (OpenTitan/
  Caliptra) reducer needs it.
- **What remains genuinely unverified (not claimed closed):** transition-bin
  / cross-bin unions specifically under `merge_instances` (as opposed to
  the value-bin unions checked above). Re-open (or file a fresh,
  separately-scoped row) only if a reducer for that specific shape is
  found to fail — do not reopen this row generically without a concrete
  new reproducer.

### F00 — Hardware formal proof backend (PROGRAM item, not a bug)

- **Area / edition:** Formal verification / N/A
- **State:** OPEN
- **Confidence:** ARCHITECTURE
- **Evidence / reproducer:** `docs/conformance/iverilog_ieee1800_uvm_manifesto.md`
  places a proof engine in a later program; the audit's F01–F09 rows (sound
  transition-system lowering, property roles, bounded/unbounded search,
  counterexample replay, vacuity checks, backend soundness validation) are
  facets of this one program, not nine independent reproduced defects.
- **What it blocks:** Any claim of formal/model-checking capability beyond
  constrained-random Z3 solving for randomization (which is explicitly not a
  hardware model checker).
- **Closure requirements:** A published supported profile (finite state,
  legal constructs, reset/clock/X-Z treatment) plus a sound lowering,
  bounded-safety/cover search, and soundness qualification against known
  passing/failing designs — this is a multi-increment program; do not close
  it as one PR. Track F01–F09 as its sub-items when work actually starts.
- **Last verified revision:** N/A (architecture item).

---

## Excluded / already reconciled (do not re-open without new evidence)

These were checked during the audit that seeded this file and found to be
stale or already addressed — listed so they aren't accidentally re-promoted
from `blocker_inventory.json` as if still open:

- One-bit enum VPI-format assertion — fixed by merged PR #261.
- "Joint parent/child constraints entirely missing" — PR #258 implements a
  bounded joint route; only its residual contract (Z01 above, and the
  other Z02–Z14 rows in the fuller audit) remains open.
- "Solver UNKNOWN accepted as a successful model" — the class route rejects
  UNKNOWN, but the scope route still accepts unconstrained targets. The
  September 21 source finding in [discovered debt](DISCOVERED_DEBT.md) corrects
  the earlier blanket exclusion; scope runtime reproduction remains pending.

See `blocker_inventory.json` / `iverilog_uvm_blocker_audit.md` (as supplied
to the governance-bootstrap session) for the full 134-row inventory this
seed set was drawn from, and for the complete excluded/reconciled list.

## Campaign-resumed process work

### P01 — Null and empty parallel children are discarded

- **Area / edition:** Process execution / IEEE 1800-2017 and 2023 §9.3.2.
- **State:** CLOSED (bounded local implementation; not merged)
- **Prerequisite:** P03 resolved and locally validated at b9ffa4994. Reducers resumed from preserved Git stash.
- **Confidence:** SOURCE
- **Evidence / reproducer:** Existing fork-process-preservation patch; `ivtest/ivltests/sv_fork_null_child.v` and `sv_fork_empty_child.v` (current baseline verification pending).
- **What it blocks:** Correct join_any termination and process creation for empty children.
- **Closure requirements:** Correct join/join_any/join_none behavior; preserve sequential/assertion null actions; focused and integrated gates.
- **Last verified revision:** Campaign P01 checkpoint on b9ffa4994; all required local gates passed. See 2026-09-08 campaign evidence; closing PR/remote CI pending before merge.

### P02 — Singleton forks lose process identity

- **Area / edition:** Process execution / IEEE 1800-2017 and 2023.
- **State:** CLOSED (bounded local implementation; not merged)
- **Confidence:** SOURCE
- **Evidence / reproducer:** Preserved original worktree `sv_fork_singleton_process.v`; `dll_target::proc_block` flattens singleton joins.
- **What it blocks:** Process identity/control and per-child random stability.
- **Closure requirements:** Process identity, RNG ownership, suspend/resume/kill and task/sequential controls with required gates.
- **Last verified revision:** Campaign P02 checkpoint on a5788c259; all required local gates passed. See 2026-09-08 campaign evidence; closing PR/remote CI pending before merge.

### P03 — Function-spawned fork children execute synchronously

- **Area / edition:** Process execution / IEEE 1800-2017 and 2023.
- **State:** CLOSED (bounded local implementation; not merged)
- **Confidence:** SOURCE
- **Evidence / reproducer:** Preserved original worktree `sv_fork_function_children.v`; `do_fork_` function path can synchronously execute non-final children.
- **What it blocks:** Background process scheduling in functions.
- **Closure requirements:** Child execution starts after parent suspension/termination, including multiple children; required gates.
- **Last verified revision:** Campaign P03 checkpoint based on 49505f514; see 2026-09-08 campaign evidence. All required local gates passed; closing PR/remote CI pending before merge.

### Z01A — Bounded canonical integral joint ordering stages

- **Area / edition:** Randomization / IEEE 1800-2017 18.5.10, 2023 18.5.9.
- **State:** CLOSED (bounded local implementation; unmerged)
- **Parent:** Z01 (remains open beyond this bounded subcase).
- **Confidence:** REPRODUCED
- **Evidence / reproducer:** exact_joint rejects all order_pairs at current b9de0be7f; root-local ordering in existing sv_randomize_global_sampling_fail is legal but unsupported.
- **What it blocks:** Ordered small-domain parent/member-object sampling.
- **Closure requirements:** Exact stage projections, latest partial ordering, rollback, replay, callbacks/activation and required gates; keep ordered dist and non-scalar stages explicit unsupported.
- **Last verified revision:** b9de0be7f red reducer in both editions; candidate patch passes all required local gates and independent review; remote CI/merge pending.


### L01 — Procedural member foreach replaces a selected prefix with a new loop

- **Area / edition:** Procedural iteration / IEEE 1800-2017 and 2023 12.7.3.
- **State:** CLOSED (bounded local scope; remote CI required before merge)
- **Confidence:** REPRODUCED
- **Parent:** U01, preserved under evidence/campaign-20260908/u01.
- **Evidence / reproducer:** lookup.sv fails both editions at c57fbe3c5; inner foreach visits all device ranges despite an enclosing selected-device filter. Slang accepts both editions; Verilator runtime produces correct membership.
- **What it blocks:** Correct selected member iteration and unmodified xbar scoreboard address routing.
- **Closure requirements:** Correct terminal-only loop declarations/iteration, constant/variable/nested controls, Bison/focused/integrated gates and independent review; then replay U01.
- **Last verified revision:** b0ac00f47 passes paired/focused/integrated/full JSON/UVM and review. Unmodified U01 replay confirms corrected routing with four request checks and three matched responses; application remains open for its pre-existing fourth-response stall.

### L02 — Automatic block locals retain values across loop entries

- **Area / edition:** Lifetime / IEEE 1800-2017 and 2023 6.21, 6.8.
- **State:** CLOSED (bounded local scope; remote CI before merge)
- **Confidence:** REPRODUCED and ROOT_CAUSED
- **Parent:** U01; preserved contract and two-edition reducer in evidence/campaign-20260908/u01-loop.
- **Evidence:** Class-task for-loop bit local returns 1 on entry 2 instead of default 0. Emitted autobegin.shared stores it in the task frame. Same driver structure leaves rsp_done set after the first response.
- **Closure requirements:** Fresh per-entry storage/defaults with static and capture controls; required local gates, review and U01 replay.
- **Last verified revision:** e0dab7221 red in both editions. Candidate now passes 93 legacy / 50 JSON focus and make check, including automatic_events2, ancestor history 2,3, and recursive event ownership (prior UVM deadlock repaired). Independent review has no actionable finding. All local semantic gates pass: integrated4666/4661/0/2/3, VPI103, negative149, runtime15, JSON1558/0, UVM355/0/0 real DPI. Unchanged U01 replay on9218751e2 completes115 requests/230 checked items; zero errors/fatals. Four sequence-parent warnings still prevent application qualification.

### V01A — Exact constructor-dependent value-bin union

- **Area / edition:** Coverage / IEEE1800-2017 and2023 19.11.3.
- **State:** CLOSED (bounded local scope; remote CI before merge)
- **Parent:** V01; no complete type-option or arbitrary cross/transition universe claim.
- **Confidence:** REPRODUCED and ROOT_CAUSED
- **Evidence:** Paired sv_covergroup_merged_value_union; original LRM example returned100 instead of66.666667.
- **Implementation:** Register and merge resolved intervals for unsized value bins; preserve name/index identity for scalar/fixed bins. Unsampled and retired instances remain represented.
- **Validation:** Focus53/43, integrated4668/4663/0/2/3, VPI103, negative149, runtime15, JSON1560/0, real-DPI UVM355/0/0, make check and independent review passed.
- **Limits:** Default merge_instances weighted averaging and downstream huge-total saturation remain unqualified.

### V02 — Default type coverage silently merges instances

- **Area / edition:** Coverage / IEEE1800-2017 and2023 19.11.3, table19-3.
- **State:** CLOSED (bounded local scope; remote CI before merge)
- **Confidence:** REPRODUCED
- **Evidence:** evidence/campaign-20260908/v02/average.sv, both editions on6eee0480c return100 rather than50 for two equal-weight half-covered instances.
- **What it blocks:** Trustworthy default type coverage; current result falsely reports complete coverage.
- **Closure requirements:** Respect default/explicit merge mode and instance weighting with paired controls, complete required gates and independent review.
- **Last verified revision:** ac60732f3 implements default weighted instance averaging and explicit merged/public-instance dispatch with native typed option initialization. Focus65/55, integrated4680/4675/0/2/3, VPI103, negative149, runtime15, full JSON1572/0, real-DPI UVM355/0/0, make check and independent review pass.
- **Limits:** Parent V01 remains open. General type_option weighting, procedural static type-option assignment, goals/strobe and arbitrary cross/transition universes are not qualified by this increment.

### V03 — Overall coverage ignores covergroup type weights

- **Area / edition:** Coverage / IEEE1800-2017 and2023 19.7.1 table19-3,19.9,19.11.
- **State:** CLOSED (bounded local scope; remote CI before merge)
- **Confidence:** REPRODUCED and ROOT_CAUSED
- **Evidence:** evidence/campaign-20260908/v03/type-weight.sv; both editions onac60732f3 return75 instead of87.5 for scores50/100 with type weights1/3.
- **What it blocks:** Correct overall coverage; declared type priority is silently ignored.
- **Causal trace:** of_COVGRP_GET_ALL computes an unweighted arithmetic mean; group type-weight metadata is absent.
- **Closure requirements:** Exact group-level type weights, default/zero/eligibility controls, valid constant conversion, all required local gates and independent review.
- **Limits:** Coverpoint/cross type weights and procedural static option access remain separate obligations.
- **Last verified revision:** 2be79b2c0 implements group-level declared type weights in overall coverage. Focus75/65, integrated4690/4685/0/2/3, VPI103, negative149, runtime15, full JSON1582/0, real-DPI UVM355/0/0, make check and independent review pass. Separate type-weight tag preserves old bytecode/property ordering.

### S02 — Bounded variable-length multiclock antecedents

- **Area / edition:** SVA / IEEE 1800-2017 and 1800-2023 16.12.7, 16.13.3.
- **State:** SUSPENDED — attempt-identity design boundary; reducer retained.
- **Confidence:** REPRODUCED compile rejection at `2be79b2c0` in both editions.
- **Evidence:** `../evidence/campaign-20260908/s02/antecedent.sv` and paired
  compile logs; legal `a[*1:2] |=> @(posedge c2) b` is rejected.
- **Mechanism:** Two-domain and N-domain callers of `sva_mc_expand_chain_`
  require fixed antecedents. Mere request-count expansion does not establish
  the per-start implication verdict required when several endpoints match.
- **Closure:** Preserve each endpoint evaluation, aggregate truth and required
  action semantics, clock timing, sampling and cancellation for the exact
  claimed bounded subset. Corrected expectation is two failures for two starts,
  rather than three failures for three endpoints.

S02 coordination boundary: scalar cross-clock request counts erase the parent
identity needed for one verdict per starting attempt. A local count-only fix is
incorrect. Reusing NFA endpoint bookkeeping first requires correcting its
existing per-consequence verdict dispatch; S03 is selected independently on a
fresh wrong-result reducer. A future S02 design must preserve attempt identity,
open antecedent status and outstanding consequences across clock domains;
architecture expansion is not authorized by this suspension.

**2026-09-16 evidence check (compile-rejection claim only, not the
architectural question):** the row's own cited symptom ("legal
`a[*1:2] |=> @(posedge c2) b` is rejected") is stale — the identical
construct compiles clean (exit 0, no diagnostic) against a current
`main`-tip build, and a basic runtime smoke (100 time units, no
triggering `a`/`b` activity) neither crashes nor hangs. This does
**not** touch or resolve the actual open question (per-start vs.
per-endpoint verdict counting under overlapping multi-endpoint matches)
— that needs a carefully constructed multi-start/multi-endpoint
triggering scenario to verify, which requires real expertise in how
this specific construct unrolls into the NFA and was not attempted this
pass; the "architecture expansion not authorized" boundary and
SUSPENDED status both stand unchanged. Only the stale compile-rejection
framing is corrected here so a future pass doesn't waste time trying to
reproduce a rejection that no longer happens before it can even get to
the real (runtime verdict-counting) question.

### S03 — NFA implication verdicts are emitted per endpoint

- **Area / edition:** SVA / IEEE 1800-2017 and 1800-2023 16.12.7.
- **State:** LOCALLY VALIDATED — remote CI required before merge.
- **Evidence:** `../evidence/campaign-20260908/s03/attempt-verdict.sv` fails
  both editions at `2be79b2c0`: one start with two failing consequences emits
  two failure actions instead of one. Independent semantic review confirms.
- **Mechanism:** `pform_sva_nfa_try_assertion` dispatches each consequence
  verdict directly and releases antecedent slots without retaining parent
  verdict identity. Existing endpoint-fanout golds encode this defect.
- **Closure:** Aggregate consequence outcomes per attempt, including early
  failure, delayed success, vacuity, cancellation and end-of-simulation;
  retain independent endpoints and local snapshots. Correct affected golds
  only from reviewed semantics and run required gates.

S03 result: existing NFA endpoint fanout retains parent identity through all
consequences; one child failure terminates the parent once, and success waits
for antecedent closure and all child successes. Vacuous user actions, distinct
nonvacuous callbacks, local snapshots, same-tick slot reuse, disable/kill,
cover counts and parent-counted strong EOS are covered. All required local
gates/review pass: NFA58, focus55/20, integrated4692/4687/0/2/3,VPI103,
negative149,runtime15,JSON1584,real-DPI UVM355,make check. Finite cyclic-pool
limits, DD005 nonfanout vacuity, S02 multiclock identity and broader SVA/formal
qualification remain open. Evidence: campaign-20260908/s03.

### S04 — Missing vacuous user pass actions in single-clock implications

- **Area / edition:** SVA / IEEE1800-2017 and1800-2023 16.12.7,16.14.1.
- **State:** LOCALLY VALIDATED — required local gates and independent review pass; remote CI remains required before merge.
- **Evidence:** At locally validated61ca5f336, false antecedent `a |-> b`
  produces0pass/0fail instead of1pass/0fail in2017/2023, default/legacy modes.
  Four compile/runtime logs and reducer in campaign-20260908/s04.
- **Mechanism:** Nonfanout NFA dead-before-obligation path suppresses pass
  dispatch; legacy match-only injection loses vacuous attempts. Specialized
  callers use the same pass dispatcher; fixed/OR/AND progress and symbolic
  pre-match ages preserve first-loss vacuity. Unsampled and asynchronous
  cancellation includes nonunit integral true values.
- **Validated so far:** Four paired reducers, VPI callback distinction,
  focused legacy17/17, JSON8/8, NFA58/58, affected real-DPI UVM9/9, make check
  and independent code review. Full integrated4700/4695/0/2/3, VPI104/104,
  negative149/149, runtime15/15, JSON1592/0 and real-DPI UVM355/0/0 pass.
- **Limits:** DD-007 symbolic nonvacuous per-endpoint verdict behavior remains
  separate and unqualified; no complete parent-feature claim.
- **Closure:** Correct vacuous user actions per attempt while preserving sampling,
  cancellation, multiplicity, callback distinctions and S03 parent semantics;
  all required local gates and independent review, then remote CI before merge.


### S05 — Symbolic repetition implication parent verdicts

- **Area / edition:** SVA / IEEE1800-2017 and1800-2023 16.9.2,16.12.7,16.14.1.
- **State:** LOCALLY VALIDATED — reviewed S05 parent correction; remote CI required before merge.
- **Evidence:** One enabled start of a[*LO:HI] with overridden LO2/HI3 produces
  good1/0 and bad0/1 at length2, then good2/0 and bad0/2 at length3 in both
  editions. Correct parent results are early good0/0,bad0/1 and final
  good1/0,bad0/1. Reducer/logs: campaign-20260908/s05.
- **Mechanism:** Symbolic r_end/r_fire counts publish consequent endpoint
  actions directly, rather than retiring failed parents and waiting for
  antecedent closure before success. Current packed ages/mature counts must
  retain the necessary ownership without an arbitrary new cap.
- **Selection:** Standards correctness and parameterized application assertion
  relevance; this is a distinct symbolic engine from S03's qualified NFA path.
- **Scope:** Accepted symbolic consecutive-repetition implication paths,
  existing cancellation/sampling/Reactive behavior, empty/nonempty timing and
  repetition-bound overrides. DD-006, symbolic consequent-delay overrides DD-008,
  and S02 remain separate.
- **Closure:** Reviewed parent-verdict semantics with permanent regressions and
  all required local gates; remote CI remains required before merge.

- **S05 current validation:** Paired focus14/14 legacy+JSON in both engines;
  neighbor17/17+8/8, callback1/1, NFA58/58, make check0 and independent review
  pass. Full integrated4714/4709/0/2/3, VPI105, negative149, runtime15,
  JSON1606/0 and real-DPI UVM355/0/0 pass. This qualifies accepted symbolic
  consecutive repetitions with fixed ##0/##1 Boolean consequences and tested
  exact-window empty timing, not all SVA or symbolic consequent-delay overrides.


### S06 — Overridden symbolic SVA cycle delay is frozen to its default

- **Area / edition:** SVA and parameter elaboration / IEEE1800-2017 and1800-2023.
- **State:** LOCALLY VALIDATED — reviewed S06 delay correction; remote CI required before merge.
- **Evidence:** On validated a76c9f67a, LO1/HI2/D0 defaults with D1 override
  pass at tick2 and ignore a false final child at tick3 in both editions.
  Literal ##1 controls pass. Reducer and paired logs: campaign-20260908/s06.
- **Hypothesis:** Single-delay grammar folds a parameter default through
  pform_sva_const_long and deletes its expression; range-delay syntax already
  retains overridable expressions for ordinary instance elaboration.
- **Selection:** Silent timing miscompilation, ordinary parameter override
  correctness and parameterized application assertion relevance.
- **Scope:** Shared single-delay normalization and necessary instance-sized
  lowering; exact parent, cancellation, sampling and empty timing preserved.
  No new arbitrary delay cap or broader multiclock architecture.
- **Closure:** Paired semantic regressions, override/boundary controls,
  required full gates and independent review. Remote CI before merge.

- **S06 repaired scope:** Single named parameter/localparam cycle delays retain
  per-instance values. Delayed sampled histories align symbolic repetition
  endpoints with the current consequent; unmatched real-time ages retain
  vacuity. Direct/prefixed overlap/nonoverlap, bounded/unbounded parents,
  empty timing, cancellation and cover endpoint counts have paired controls.
  Shared self-sizing preserves substituted operand width/sign; invalid
  original negative grouped delays and unknown bounds reject per instance.
- **S06 remaining scope:** Arbitrary delay-expression parsing, broader formal
  lookup, unsupported composed/multiclock shapes and maximal-width arithmetic
  remain unqualified. A rejection control does not implement a legal shape.
- **S06 current validation:** Focus18/18 legacy+JSON in both engines;
  S05neighbors14/14+14/14,S04neighbors17/17+8/8; NFA58/58;
  integrated4732total4727pass0fail2NI3EF,VPI105,negative149,runtime15;
  JSON1624/0,real-DPIUVM355/0/0,makecheck and final source/test review pass.

### S07 — Nested parameterized sequence aliases fail expansion

- **Area / edition:** Sequence composition / IEEE1800-2017 and1800-2023.
- **State:** LOCALLY VALIDATED — reviewed nested-alias increment; remote CI required before merge.
- **Evidence:** campaign-20260908/s04/window-nested-alias.sv; Left/Right
  wrapping Pair(actuals) reports No function named Pair, while direct use
  works. Previously reproduced on61ca5f336; current-source check pending.
- **Scope:** Shared nested sequence expansion and actual binding; preserve
  lexical identity, recursion safeguards, temporal truth and ownership.
- **Closure:** Paired reducer/direct controls, permanent timing/binding tests,
  all required local gates and review; remote CI before merge.

- **S07 exact qualification:** Bare alias bodies recursively expand nested
  sequence calls in their declaration generate scope. Caller-supplied
  sequence actuals retain caller lookup. Active-path cycles reject before
  expansion; repeated legal uses retain independent cloned bodies.
- **S07 validation:** Paired focus12/12 legacy+JSON in both engines;
  S06neighbors18/18+18/18,S04neighbors17/17+8/8,NFA58/58;
  integrated4744total4739pass0fail2NI3EF,VPI105,negative149,runtime15;
  JSON1636/0,real-DPIUVM355/0/0,makecheck and final review pass.
- **S07 residuals:** Full dependency-graph validation across independent
  instances and pre-existing parameterized declaration-owned lookup remain
  unqualified; no general sequence-composition completion claim.

### L03 — Automatic Boolean event expressions share activation state

- **Area / edition:** Lifetime/events / IEEE1800-2017 and1800-2023 6.21,9.4.2.
- **State:** LOCALLY VALIDATED — reviewed Boolean activation state and supported input chains; remote CI before merge.
- **Evidence:** u01-loop/history-expression-preexisting.sv; two automatic
  invocations of posedge(value[2] | 1'b0) both trigger at2 instead of2,3.
  Freshly reproduced after validated L04 in both editions; mixed parent/local
  OR also wakes2,2 instead2,3 (evidence/l03/after-l04-* and mixed-*).
- **Scope:** Shared Boolean driver activation state/context and directly
  necessary selection, preserving existing runtime lifetime mechanisms.
- **Closure:** Paired reducer and lifetime/static controls, all required
  local gates and review; remote CI before merge.

- **L03 validation:** Paired focus12/12legacy+JSON,L02neighbors93/50,
  L04neighbors4/4,PART_PV ancestor history/reuse,NFA58/58,integrated4760total
  4755pass0fail2NI3EF,VPI105/105,negative149/149,runtime invariants,
  JSON1652/0,real-DPIUVM355/0/0,makecheck and final review pass.
- **L03 residuals:** BUF,NOT,mux and other expression families remain
  unchanged/unqualified; no general expression or application closure.

### L04 — Automatic integral defaults do not seed event history

- **Area / edition:** Lifetime/events / IEEE1800-2017 and1800-2023 6.8,6.21,9.4.2.
- **State:** LOCALLY VALIDATED — reviewed integral initialization prerequisite; remote CI before merge.
- **Evidence:** Paired current4a879babc default-negedge reducer fires at1 on
  unchanged partial zero write instead of actual negedge at3; evidence/l04.
- **Mechanism:** Integral slot reset sets storage without initial publication;
  current hooks precede context stack/live linkage.
- **Scope:** Post-link hook using existing activation infrastructure and
  automatic integral initial-value propagation, all allocation callers audited.
- **Closure:** Paired default/lifetime controls and all required gates/review;
  resume L03 only after validated baseline. Remote CI before merge.

- **L04 validation:** Paired focus4/4 legacy+JSON,L02neighbors93/93+50/50,
  mixedlifetime7/7+7/7,eventcontrols14/14+14/14,NFA58/58;
  integrated4748total4743pass0fail2NI3EF,VPI105,negative149,runtime15;
  JSON1640/0,real-DPIUVM355/0/0,makecheck and final review pass.
- **L04 residuals:** Qualification covers integral signal default publication;
  derived Boolean contexts (L03),other value types and broader initialization
  obligations remain separate.


### L05 — Selected associative class-member foreach loses index type

- **Area / edition:** Foreach/arrays / IEEE1800-2017 and1800-2023 12.7.3.
- **State:** LOCALLY VALIDATED — reviewed selected-member index typing; remote CI before merge.
- **Evidence:** campaign-20260908/l01/typed.sv: values[string] member loop
  index becomes int and visits zero entries, also seen before L01.
- **Scope:** Exact implicit-index type resolution and necessary selected-member
  elaboration, preserving prefix selection and existing iteration behavior.
- **Closure:** Paired reducer, key/selection/lifetime controls, all required
  local gates and review; remote CI before merge.

- **L05 mechanism:** Preserve selected target paths through parser declarations
  and foreach index typing; reuse existing type-only lookup to reach the
  terminal array key type without evaluating selectors.
- **L05 validation:** Focus10/10 legacy+JSON, foreach neighbors53/34,
  makecheck/review, NFA58/58, integrated4765/4770 with zero unexpected failures,
  VPI105, negative149, runtime checks, fullJSON1662/0 and real-DPI UVM355/0/0 pass.
- **L05 residuals:** Invalid same-name header selectors (DD-009), selected-array
  non-member typing and broader container obligations are not qualified here.

### V04 — Merged type coverage saturates wide bin totals before division

- **Area / edition:** Coverage / IEEE1800-2017 and1800-2023 19.11.3.
- **State:** FIXED on clean current `main` (`af89cfc50be1084cc86c48865f3f6ba78d4512fa`); the registered reducer passes in both strict editions in the 2026-10-08 local recheck. This is not a CI result.
- **Evidence:** class_type::type_coverage narrows exact dynamic cardinality
  to UINT64_MAX and saturates per-item sums; instance coverage already uses
  unsaturated real aggregation. Multiple named wide families can exceed64 bits.
- **Scope:** Preserve supported merged totals through percentage calculation,
  retaining bin identity, thresholds, weights and mode dispatch.
- **Closure:** Paired relative-error reducer/controls and independent review; the clean-main recheck confirms the V04 registered reducer in `-g2017` and `-g2023`. Parent V01 and cross-bin universe obligations remain separate; merged transition-family cardinality is a validation question in [#513](https://github.com/dsellerbrock/iverilog-uvm/issues/513).
- **Residuals:** Parent V01 and cross-bin universe obligations remain separate.
  Merged transition-family cardinality is validation-only under [#513](https://github.com/dsellerbrock/iverilog-uvm/issues/513).
  No per-blocker PR under updated cadence.

- **V04 candidate:** Local128-bit merged total/hit accumulation; individual
  The reducer does not change individual transition-family cardinality. Focus2/2+2/2, coverage neighbors75/65,
  makecheck and independent review pass. Integrated4772total4767pass0fail2NI3EF,VPI105,negative149,runtime checks,
  fullJSON1664/0,UVM355/0/0,NFA58/58 all pass.

### V05 — Constructed cross bins are omitted or misidentified in merged type coverage

- **Area / edition:** Coverage / IEEE1800-2017 and1800-2023 19.6,19.11.3.
- **State:** FIXED on clean current `main` (`af89cfc50be1084cc86c48865f3f6ba78d4512fa`); the registered reducer passes in both strict editions in the 2026-10-08 local recheck. This is not a CI result.
- **Evidence:** campaign-20260908/v05/cross.sv: two dynamic cross instances,
  six-bin union and two hits; type coverage0 instead33.333333, instance25 correct.
- **Scope:** Register supported automatic cross-bin names/counts for merged
  type coverage and union already-resolved active named properties, preserving
  per-instance topology and full product identity.
- **Closure:** Paired canonical identity/union controls and independent review; the clean-main recheck confirms the V05 registered reducer in `-g2017` and `-g2023`. Parent V01 and unsupported topologies remain separate.

- **V05 candidate evidence:** Ordered component-name tuples registered only
  after successful topology validation; local counts map to canonical type
  counters, with active named-property union. Focus13/13 legacy+JSON,
  coverage neighbors75/65,V04 neighbors2/2,NFA58/58 and independent review pass.
  Includes named/arrayed transition identities and malformed-plan denominator
  assertions. Integrated4785total4780pass0fail2NI3EF,VPI105,negative149,
  runtime checks,fullJSON1677/0,real-DPIUVM355/0/0 and makecheck all pass.
  Parent V01 remains open; unsupported topologies and unqualified options are not closed. Merged transition-family cardinality is tracked as a validation question in [#513](https://github.com/dsellerbrock/iverilog-uvm/issues/513); no incorrect result has been reproduced. The clean-main census separately confirmed the CrossQueueType rejection in [#511](https://github.com/dsellerbrock/iverilog-uvm/issues/511) and the oversized-cross silent drop in [#512](https://github.com/dsellerbrock/iverilog-uvm/issues/512). No immediate PR under milestone cadence.


### V06 — Merged item coverage uses instance weights instead of type weights

- **Area / edition:** Coverage / IEEE1800-2017 and1800-2023 19.7.1,19.11.3.
- **State:** FIXED on clean current `main` (`af89cfc50be1084cc86c48865f3f6ba78d4512fa`); the registered reducer passes in both strict editions in the 2026-10-08 local recheck. This is not a CI result.
- **Evidence:** v06/type-weight.sv has coverpoint scores50/0,type weights3/1,
  instance weights1/3. Type returns12.5 rather than37.5; instance12.5 is correct.
- **Scope:** Declared coverpoint/cross type-weight validation, metadata and merged
  aggregation. Preserve independent defaults, instance modes and old bytecode.
- **Closure:** Paired semantic/invalid-value controls, scoped regression oracle
  corrections for item isolation and independent review; the clean-main recheck
  confirms the V06 registered reducer in `-g2017` and `-g2023`. Procedural
  static assignment and other type-option obligations remain separate.

- **V06 evidence:** Typed constant validator handles independent defaults,
  zero weights, group noninheritance, static/dynamic/implicit crosses and
  merge0/instance isolation. Temporary typed aliases preserve constructor and
  sample scope, including legal type queries and outer constant functions.
  Old bytecode fallback and new tagged metadata bounds are controlled.
  Focus22/22+22/22,coverage75/65,V04 2/2,V05 13/13,integrated4807total4802pass
  zero unexpected2NI3EF,VPI105,negative149,runtime,JSON1699/0,UVM355/0/0,
  NFA58/58,makecheck and independent final review all pass. DD-010 is resolved
  by V07's population guard; current-main recheck passes both strict editions.


### V07 — Never-instantiated covergroup types lower cumulative coverage

- **Area / edition:** Coverage / IEEE1800-2017 and1800-2023 19.9,19.11,19.11.3.
- **State:** FIXED on clean current `main` (`af89cfc50be1084cc86c48865f3f6ba78d4512fa`); the registered reducer passes in both strict editions in the 2026-10-08 local recheck. This is not a CI result.
- **Evidence:** v07/uninstantiated-type.sv reports0 before any instance and50
  after constructing one fully covered type; expected100 in both situations.
- **Root:** Compilation registers types whose static metadata merge1 scores
  without checking whether an instance ever existed. Existing live registry
  and retired-options marker already preserve the required population state.
- **Scope:** Shared type-coverage eligibility, preserving constructed/retired
  populations and independent type/instance weights; no new metadata or registry.
- **Closure:** Paired lifecycle controls and review; the clean-main recheck
  confirms the V07 registered reducer in `-g2017` and `-g2023`. Broader parent
  V01 and other coverage obligations remain open.

- **V07 validation:** Six permanent lifecycle entries pass both harnesses,
  with paired baseline failures and zero-weight/retirement controls. V04/V05/V06
  and coverage neighbors pass; integrated4813total4808pass0fail2NI3EF,VPI105,
  negative149,runtime,JSON1705/0,NFA58/58,UVM355/0/0 realDPI actual-g2012,
  makecheck and independent review pass. Existing live/retired state suffices;
  no metadata, ABI or scheduler changes. Broader qualification remains open.


### U02 — Published UVM revision compatibility matrix

- **Area:** UVM release compatibility / qualification tooling.
- **State:** LOCALLY VALIDATED — requested acquisition/probe tooling complete; release compatibility remains partial.
- **Evidence:** Accellera official downloads lists 1.0/1.1/1.2,2017 and2020 families; current U01 encounters a UVM-version boundary.
- **Scope:** Pin official sources, keep releases available locally, run isolated unmodified-library compile/smoke probes and record exact failures.
- **Closure:** Reproducible acquisition and honest per-release evidence. Does not require all versions to pass or establish IEEE1800.2/application qualification; discovered compiler gaps are record-only during U02.

- **U02 result:** 15 releases available;2020.2.0/2020.3.0/2020.3.1 compile and
  execute factory/copy/phase/regex/HDL smoke with zero warnings/errors/fatals.
  Twelve versions fail compilation; see `uvm_release_matrix.md`. Official Git
  releases use pinned submodules, others verified archive downloads. Six offline
  evidence-integrity/source-preservation controls pass. No compiler fix or
  broad UVM/application/ABI qualification is included in this tooling closure.


### L06 — Empty queues of structs with member defaults are rejected

- **Area / edition:** Data types / IEEE1800-2017 and1800-2023 7.10,7.2.2.
- **State:** CLOSED for empty queue-container initialization at `4965219df`; broader structure defaults remain open.
- **Evidence:** OfficialUVM2020.3.2 uvm_reg_map.svh2058 declares
  uvm_reg_bus_op accesses[$]; the element has data=0. Compiler emits an
  unsupported-default diagnostic for the queue declaration.
- **Expected:** An uninitialized queue is empty; no nonexistent element gets
  member initialization. Preserve valid scalar defaults and invalid-type errors.
- **Validation:** Fourteen paired legacy/JSON regressions, 27/26 neighbors,
  integrated 4827 total / 4822 pass / 0 unexpected failures / 2 NI / 3 EF,
  VPI 105, negative 149, runtime invariants, JSON 1719/0, NFA 58/58,
  real-DPI UVM 355/0/0, make check and independent review passed.
- **Release replay:** Unmodified UVM2020.3.2 passes the former declaration
  failure, then reaches the independently preexisting DD013 queue-last lvalue
  assertion. This is not a release/application pass. Unsupported array shapes
  and invalid member-default diagnostics remain explicitly covered.
- **Publication:** Local semantic qualification is complete. Separate B01
  Windows export correction and required remote merge gates remain pending.


### B01 — Windows coverage API import-library exports missing

- **Area:** Build/API ABI export map, no language-semantic change.
- **State:** CLOSED — old/new export invariant and review passed; required Windows CI now passed on PR273 head abcfdf7fb84b36b030ea8d28b05fca73ca06be16.
- **Evidence:** job102955775883 link of vvp.tgt reports seven missing coverage
  API symbols; all are declared in ivl_target.h and implemented in t-dll-api.cc.
- **Root:** Missing ivl.def entries prevent Windows import-library linkage.
- **Closure:** Old/new invariant proof, exact exports, independent review and
  required Windows CI. Update existing PR273; no new PR or agent merge.


- **Windows evidence:** UCRT64 job102981118128 completed success at2026-09-10T18:56:21Z, including build/link, regression, UVM and installed frontend. MINGW64 and CLANG64 also passed. Export map unchanged from reviewed7c779ff28; macOS remains queued for overall PR, no merge performed.


### U03 — Select a pinned UVM release from the iverilog command line

- **Area:** User-requested driver and release acquisition integration.
- **State:** CLOSED at `c35d2ef36` — focused, registration, selected real-DPI smoke, installed frontend, review, integrated and full JSON gates passed.
- **Authorization:** User requests a UVM version picker in iverilog similar to VCS.
- **Gap:** The driver accepts --uvm-home but has no release-ID selector or
  available-release listing. Existing --uvm-version reports the bundled version.
- **Contract:** Add --uvm=<release> and --uvm-list, using acquired pinned sources;
  preserve -uvm, --uvm-home and reporting-only --uvm-version behavior. Connect
  the downloader to discovery without downloading during a compiler invocation.
  Diagnose unknown/missing versions and conflicting path/version options clearly.
- **Validation:** Driver parsing/resolution tests for valid, missing, invalid and
  conflicting selectors; listing; path with spaces; existing-option controls;
  real-DPI compile/run smoke using a known passing pinned release. Required
  repository gates and independent review remain in force. Selecting a release
  does not qualify its language support or turn current compile failures into passes.
- **Boundary:** B01 is safely suspended awaiting external Windows CI; U03 is
  independent of the export-map correction. L06 passed all local gates before
  installing the candidate driver. U03 is the sole active implementation task.

- **Final validation:** Integrated 4827 total / 4822 pass / 0 unexpected
  failures / 2 NI / 3 EF; VPI105, negative149, runtime15/15; JSON1719/0.
  Availability is separate from compatibility and IEEE1800.2 qualification.

### L07 — Queue-last element assignment aborts elaboration

- **Area / editions:** Queue lvalues, IEEE1800-2017 and IEEE1800-2023 7.10/7.10.1.
- **State:** CLOSED at `9a1b6beb3` for direct queue-variable element lvalues; class-member and other parent forms remain unqualified.
- **Evidence:** Unmodified UVM2020.3.2 uvm_field_op.svh112 assigns msg_queue[$].
  Minimal string queue assignment aborts both saved baseline and L06 candidate.
- **Root candidate:** Plain queue lvalue dispatch handles SEL_BIT but omits
  SEL_BIT_LAST and reaches the SEL_NONE assertion. Trace all related consumers
  before correcting the shared lowering path.
- **Scope:** Runtime last-element selection for direct queue variables and
  affected ordinary element assignment paths; retain empty/bounded queue,
  element-type, index evaluation and existing member-selection semantics.
  Any unsupported parent shapes remain explicitly scoped and recorded.
- **Closure:** Standards evidence, baseline red, permanent paired regressions,
  smallest causal patch, required integrated validation and official release
  replay. Removing the assertion alone is not implementation.

- **Final evidence:** Baseline aborts in both editions. Ten paired legacy/JSON
  tests, neighbors21/13, make check, independent review, integrated4837 total
  with zero unexpected failures, VPI105, negative149, runtime15/15, JSON1729/0,
  NFA58/58 and real-DPI UVM355/0/0 pass. Full 15-release replay is complete and
  baseline-valid: four smoke passes, eleven compile failures. No broad queue,
  UVM, application or formal-program completion claim is made.

### P04 — Process kill misses descendants in synchronous task frames

- **Area / edition:** Process runtime / IEEE1800-2017 and2023 9.7.
- **State:** CLOSED for live-parent descendant traversal; locally validated at `53b58890c63a48aa1943c7ef065db59f19cebef3`.
- **Evidence:** `u01-after-l07/kill_task_children.sv`; both edition runs report
  parent KILLED, child WAITING, counter continuing4to9 after parent.kill.
- **Cause:** Descendant kill traversal skips joined synchronous task frames;
  their live detached children are later reparented during frame cleanup.
- **Scope:** Live-parent kill through synchronous frames only. Terminal-parent
  kill DD-014 and application teardown qualification remain separate.
- **Closure:** Permanent task/frame/deep-descendant and sibling controls;
  focused and required integrated gates, independent review, then U01 replay.

- **P04 validation:** Six paired regressions and all required focused/integrated gates passed: legacy4843total0unexpected failures,JSON1735/0,real-DPIUVM355/0/0,NFA58/58,VPI105,negative149,runtime15/15,makecheck and independent review. U01 replay remains separate.

### L08 — UVM2020.1 resource-queue typing frontier

- **Area / edition:** Class-scoped type actuals, IEEE1800-2017/2023 6.20.3 and8.23.
- **State:** CLOSED for class-scoped type actual resolution and specialization identity; release-wide qualification remains open.
- **Evidence:** DD-011; original2020.1.0/1.1 compile logs in the pinned release
  matrix stop at nested resource-queue type/assignment errors.
- **Closure:** First causal reducer, applicable IEEE semantics and minimal
  implementation scope before any patch; permanent regression, required gates
  and review. No release-wide or application qualification by implication.

- **L08 candidate evidence:** Scoped resource-queue actual fails in both editions on the validated baseline; explicit equivalent type passes. Type-only class-member lookup and resolved specialization keys now pass ten permanent paired regressions in legacy and JSON runners, related17/15 controls and make check. Independent review clear after preserving dotted-path provenance through SVA cloning. Integrated legacy/VPI/negative/runtime, full JSON, real-DPI UVM and NFA remain required; no closure yet.

- **L08 closure:** Implementation47e6c87b3 passed all required local gates: legacy4853total4848pass0fail2NI3EF,VPI105,negative149,runtime15/15,JSON1745/0,NFA58/58,real-DPIUVM355/0/0,focused10/10each,neighbors17/15,makecheck and independent review. Original2020.1.0/1.1 compile but fail runtime as separately recorded in DD-011.

### U04 — Original UVM2020.1 DPI regex loading

- **State:** CLOSED at aa172f5f9 for legacy regex C ABI and real error propagation; original release phase qualification remains DD-017.
- **Evidence:** DD-011, results-gizcr5j0; both original releases compile but miss uvm_re_match/uvm_glob_to_re symbols at runtime, followed by BUILDERR.
- **Scope:** Establish declarations, loaded exports and causal reducer before authorizing a bounded patch. No library edits or release-wide qualification.

### U05 — Standalone DPI reporting callback

- **State:** CLOSED at a5eb76ebb after all required local validation; resume U04.
- **Evidence:** u04/report_bridge.sv compiles but callback count remains0; standalone umbrella defines exported report callback as no-op.
- **Scope:** Existing runtime export dispatcher adapter, preserved merged builds, argument/count and real-UVM reporting tests. U04 legacy regex reducers preserved; resume after validation.

- **U05 closure evidence:** Four paired baseline failures become four passes in relocated frontend S10; S1-S10,review,makecheck,NFA58/58,integrated4853total0unexpected,VPI105,negative149,runtime15/15,JSON1745/0,real-DPIUVM355/0/0 passed. No legacy regex compatibility claim from this reporting fix.

- **U04 closure:** All required local gates passed: paired ABI/error controls,original2020.1.0/1.1 ABI4/4,relocated frontendS1-S10,review,makecheck,NFA58/58,legacy4853total0unexpected,VPI105,negative149,runtime15/15,JSON1745/0,real-DPIUVM355/0/0. Full15release matrix remains4SMOKE_PASS,9COMPILE_FAIL,2RUNTIME_FAIL; no release-wide qualification inferred.

### U06 — Original UVM2020.1 phase execution

- **State:** CLOSED at aad6fe22b (semantic patch fe4e949b8), after all required gates.
- **Evidence:** Both original releases finish at time0 without the smoke marker or expected missing-traffic fatal, despite successful direct ABI checks.
- **Resolved scope:** Preserve recursive caller input context across nested argument calls; IEEE2017/2023 8.6 and13.5.1. Original sources unchanged; both2020.1 releases now execute intended smoke checks through time1.
- **Validation:** legacy4855/0,VPI105,negative149,runtime15/15,JSON1747/0,real-DPIUVM355/0/0,NFA58/58,makecheck,independent review,relocated frontendS1-S10. Paired reducer fails baseline/passes candidate in both editions. Full15release matrix6SMOKE_PASS9COMPILE_FAIL; original2020.1 smoke4/4 in2017/2023. DD018 output-copying scope was subsequently resolved by L09.

### L09 — Nested argument output copy-out loses caller automatic destination

- **State:** CLOSED at 3c44fd13b after all required local gates.
- **Evidence:** Preserved nested output control fails identically before/after U06; caller local remains unchanged.
- **Scope:** Explicit automatic copy-out phases select callee formal loads and caller destination reads/writes, preserving frame ownership and existing typed copying. IEEE2017/2023 8.6 and13.5.
- **Evidence at candidate:** Three permanent regression families fail baseline and pass both editions; focused JSON38/0, malformed bytecode6/6, NFA58/58, makecheck and independent review pass. Full legacy4861/0,JSON1753/0,real-DPIUVM355/0/0,VPI105,negative149,runtime15/15 and frontendS1-S10 passed; restored tools match frozen fingerprints. Class fixed-array property scalar output (DD019) was resolved separately by L10.


### L10 — Fixed-array class-property element output copy-out

- **State:** CLOSED at 051aeee8e after validated prerequisite L11 and all required local gates.
- **Evidence:** Legal scalar output actual holder.slots[index] emits a skipping warning and remains unchanged.
- **Scope:** Existing fixed property slot checks and typed property stores; preserve receiver/index context and invalid-index semantics. No unrelated container expansion.

- **L10 validation:** legacy4873total0unexpected,VPI105,negative149,runtime15/15,copyout6/6,JSON1765/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON50/0,focusedlegacy8/0,independent review,frontendS1-S10; restored root and unchanged frozen fingerprints. Fixed property elements only; broader output/array support remains separately scoped.

### L11 — Scalar output actuals must not be copied in

- **State:** CLOSED at b32df9a29 after all required local gates.
- **Scope:** Native output argument setup must skip caller reads, initialize automatic formals to defaults, retain static formals and preserve DPI open-array handling.

- **L11 validation:** legacy4865total0unexpected,VPI105,negative149,runtime15/15,copyout6/6,JSON1757/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focused42/0,independent review,frontendS1-S10; root restored and frozen hashes unchanged.


### U07 — Legacy UVM member delay compatibility

- **State:** CLOSED at a83731194 after all required local gates.
- **Evidence:** Original1.2 #setting.offset fails parsing; same first frontier in older releases.
- **Classification:** Nonstandard unparenthesized member delay; both IEEE editions require parentheses. Use existing miscellaneous extension switch, preserving strict rejection and normal delay semantics; no library patches.

- **U07 validation:** legacy4881total4876pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,JSON1773/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON8/0,legacy8/0,delayneighbors40/0,independent review,frontendS1-S10; installed root restored and frozen hashes unchanged. Eight release smoke passes; six compile gaps and one runtime timeout remain. This closes only compatibility syntax under the existing miscellaneous-extension mode, not IEEE/UVM parent qualification.

### L12 — String character reads through unpacked struct members

- **State:** CLOSED at a85a256b1 after all required gates.
- **Evidence:** DD021 original UVM1.2 printer row.val[0] receives explicit unsupported struct-member index diagnostic.
- **Scope:** Correct bounded rvalue string indexing, preserving byte type, bounds and index evaluation. Static-local references and constraints remain separate blockers.

### L13 — Signed byte semantics of string character reads

- **State:** CLOSED at849a779ea after corrected index conversion and all required gates.
- **Evidence:** Ordinary s[0] with octal377 yields255 when widened, while getc and byte cast yield-1. Both editions6.16/6.16.3/6.11.3 specify signed byte semantics.
- **Scope:** Shared character-select typing and expression sizing, preserving unsigned packed bit/part selects.

- **L13 validation:** legacy4887total4882pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,JSON1779/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON6/0,legacy6/0,stringneighbors42/0,independent review,frontendS1-S10; installed root restored and frozen hashes unchanged. Fullrelease results-6pvdp6vh retain8smokepasses,6compilegaps,1timeout; normalized diagnostics and source hashes match U07. General class-property dispatch and constant-function string evaluation remain open.

- **L13 corrected validation:** 849a779ea; legacy4887total4882pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,JSON1779/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON6/0,legacy6/0,neighbors42/0,independent review,frontendS1-S10; root restored and frozen hashes unchanged. Release results-m_3ysaa5 retains8passes6compilefail1timeout with matching row sources and normalized diagnostics.

- **L12 validation:** a85a256b1;legacy4893total4888pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,JSON1785/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON6/0,legacy6/0,neighbors71/0,independent review,frontendS1-S10; root restored and frozen hashes unchanged. Original release sweep results-qb7873zh:8SMOKE_PASS5COMPILE_FAIL1RUNTIME_FAIL1RUNTIME_TIMEOUT. Full UVM release and application qualification remain open.

### L14 — Static local hierarchical references inside automatic scopes

- **State:** CLOSED at69ff60cc6 after all required gates.
- **Evidence:** Original1.2 visit.compiled_regex read/write rejected as automatic despite explicit static chandle declaration.
- **Semantics:** Both IEEE editions6.21 explicitly permit static-variable hierarchical references inside automatic tasks/functions, except unnamed blocks. Preserve automatic-variable rejection.

- **L14 validation:** 69ff60cc6;legacy4905total4900pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,JSON1797/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON12/0,legacy12/0,neighbors18/0,independent review,frontendS1-S10; root restored and frozen hashes unchanged. Release results-f9qr050b:8SMOKE_PASS4COMPILE_FAIL1RUNTIME_FAIL2RUNTIME_TIMEOUT; all15 source hashes unchanged, other14 normalized compile logs identical. UVM1.2 runtime timeout remains DD028.

### U08 — Inherited-method lookup causes UVM1.2 root recursion

- **State:** CLOSED at c9626a449 after all required local gates.
- **Evidence:** DD028, original1.2 compiles then times out300s with no runtime output.
- **Resolved scope:** Inherited unqualified method precedence over enclosing homonyms; receiver/task/virtual binding, local visibility and static-caller diagnostics covered under both editions. General access control remains DD029; original1.2 still fails legacy regex DPI (DD030).

- **U08 validation:** c9626a449;legacy4911total4906pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,JSON1803/0,real-DPIUVM355/0/0,NFA58/58,makecheck,focusedJSON6/0,legacy6/0,neighbors32/0,independent review and external-review reconciliation,frontendS1-S10; root restored and frozen hashes unchanged. Release results-eb3ghca7:9SMOKE_PASS4COMPILE_FAIL2RUNTIME_FAIL; no source changes.2017.0.9 now passes;1.2 reaches regex DPI errors.

### U09 — Legacy UVM regex DPI entry points

- **State:** CLOSED at19e7f5592 after all required local gates.
- **Evidence:** DD030/DD027, original1.2 and1.1d import uvm_dpi_regcomp/regexec/regfree; installed modern umbrella exports none of those names. Pinned legacy sources already contain the implementation.
- **Scope:** Provide the legacy C ABI on the Icarus backend with strict regex semantics, error reporting and handle lifetime; permanent coverage and original-release replay. No library-source edits or full application claim.


- **U09 validation:** Focused10/10 under2017/2023; legacy4911total4906pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,JSON1803/0,real-DPIUVM355/0/0,NFA58/58,makecheck,independent review and frontendS1–S10. Installed root restored and frozen hashes unchanged. Original15release sweep results-n2m35ki0:11SMOKE_PASS4COMPILE_FAIL; all source hashes unchanged. Exact cached-regex gap closed, full release/application qualification remains open.

### U10 — OpenTitan UVM1.2 selection and provenance

- **State:** CLOSED at aaf8df44c for source selection/provenance; application qualification remains open.
- **Gap:** Replay harness selects and fingerprints bundled UVM despite pinned OpenTitan commercial configurations selecting1.2.
- **Scope:** Forward an explicit acquired source root, record its actual fingerprint and replay the pinned debug crossbar with original1.2. Keep all application checking and failure criteria.

- **U10 validation:** aaf8df44c harness only, compiler19e7f5592 unchanged. Permanent self-test PASS, invalid path exit2, explicit root/src/environment/override normalization4/4, independent review clear, diff/YAML checks pass. Pinned OpenTitan7a3ad34 original1.2 replay records correct source hash885ba9f74652494aa132aaaa26c43e9f210f94cdf5a8d3a87064993ec9b35dc0 and fails compile74 at legacy macro expansion; zero application traffic, no pass claim. DD031 preserves next frontier.

### L15 — Pasted function-like macro names with numeric suffix

- **State:** CLOSED at aa356ab4d after required local validation and original1.2 replay.
- **Evidence:** DD031 original1.2 OpenTitan field macro pastes uvm_print_aa_string_int3 but reports a missing argument list for its shorter prefix.
- **Scope:** Prove text-substitution semantics, correct the causal preprocessor boundary and preserve permanent paired-edition regression. No upstream source modifications.

- **L15 validation:** aa356ab4d; macrofocuslegacy24/0,JSON6/0,independent review,makecheck,legacy4913total4908pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1805/0,real-DPIUVM355/0/0,NFA58/58,frontendS1-S10; installed root restored and frozen hashes unchanged. Full15release11SMOKE_PASS4COMPILE_FAIL; all statuses/source hashes unchanged. OpenTitan macro errors/cascades removed; next failure is three const-handle member assignment diagnostics, DD032. No application pass.

### L16 — Mutable property through a const class-handle variable

- **State:** CLOSED at5ba60567f after required local validation and original1.2 replay.
- **Evidence:** DD032, original1.2 OpenTitan rejects uvm_top.enable_print_topology assignment.
- **Scope:** Both-edition6.20.6 direct const-handle variable member writes, retaining handle/const-property/value-aggregate protection. No complete const qualification claim.

- **L16 validation:** 5ba60567f; focusedlegacy8/0,JSON8/0,neighborslegacy18/0,JSON32/0,independent reviews,makecheck,legacy4921total4916pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1813/0,real-DPIUVM355/0/0,NFA58/58,frontendS1-S10; root restored and frozen hashes unchanged. Full15release11SMOKE_PASS4COMPILE_FAIL; all statuses/source hashes unchanged. Original1.2 OpenTitan replay42522: compiler0/runtime0,9.964s,152requests/288scoreboard items,0UVMwarnings/errors/fatals,TEST PASSED CHECKS and normal finish17625626ps. OverallDEBT from five compile-time null-fallback diagnostics on compound array-member operations; no application qualification. No waived checks/source edits.

### L17 — Integral compound updates of dynamic-array properties

- **State:** CLOSED at d8e974913 after all required local gates and original1.2 application replay.
- **Evidence:** DD035, five original1.2 register-item array updates emit null fallbacks.
- **Scope:** Typed integral element compound updates with single index evaluation, receiver/width preservation and invalid-index no-write behavior. No full compound/container qualification claim.

### L18 — Resolved property signedness in compound assignment

- **Status:** CLOSED at9791e6411; signedness prerequisite for suspended L17.
- **Evidence:** Signed scalar class property -64 /= 2 produces2147483616, expected-32. NetAssign_ signed_ is default-false for property shapes.
- **Scope:** Use resolved integral selected type in compressed-assignment elaboration. Paired signed/unsigned/part-select regressions and all required gates. No dynamic-array compound qualification before L17 resumes.

L17 coordination boundary: suspended with full partial patch/tests at
`evidence/campaign-20260908/l17/partial.patch`. Focus exposed prerequisite
operand width/state loss and signedness loss before target lowering. L18
handles signedness; DD036 preserves width/state debt. No L17 closure.

L18 closure: focused paired-edition/neighbor tests, independent review and all
required local gates pass; original15release statuses unchanged. Only direct
integral property signedness is resolved. DD036 width/state preservation and
L17 dynamic-array lowering remain open.

### L19 — Preserve four-state compound operands

- **Status:** CLOSED at72a97c038; state-conversion prerequisite for suspended L17.
- **Evidence:** On validated9791e6411, bit[7:0] value=1;value+=logic X yields1 in both editions; expected0 after unknown arithmetic result is assigned to bit.
- **Scope:** Delay destination two-state conversion until after the integral compound operator. Width preservation remains separate DD036 work. All required gates apply.

L19 closure: paired four-state operand and two-state result checks, signedness/
concatenation neighbors, independent review and all required local gates pass.
DD036 operand width and L17 target lowering remain open.

### L20 — Integral compound operation widths

- **Status:** CLOSED atfe12166bd; compressed-vector width prerequisite for suspended L17.
- **Evidence:** On validated72a97c038, logic8bit128 /=32'd256 producesX instead0 in both editions. L17 also demonstrates wide shift count truncation.
- **Scope:** Natural/context RHS width through compressed elaboration and shared vector operation sizing before final result truncation. Preserve existing receiver/index lowering; no new runtime instructions. All required gates apply.

L20 closure: paired constant/runtime widths, signedness/context, self-determined
shift counts, property parts and array/queue cases pass with all required
local gates. Associative front-end expansion remains residual DD036 debt; no
complete associative or parent compound qualification. L17 can now resume.

L17 resumes after validated L18/L19/L20 onfe12166bd. Original red/partial patch
are preserved; adapt append-only manifests and reuse the validated width helper.
All L17 gates/application replay remain required before exact-scope closure.

### L21 — Captured class-root notification preserves rebound handles

- **Status:** CLOSED at1146d2187; captured class-root runtime prerequisite for resuspended L17.
- **Evidence:** Standalone scalar h.value+=rebind() mutates original but restores old h during notification. Captured root delivery overwrites RHS reassignment.
- **Scope:** Guard captured class-root delivery with live binding identity while preserving alias/property events and contexts. All required gates apply. L17 resumed patch is preserved as partial-after-l20.patch.

L21 closure: replacement/null rebind, retained-alias/property events, unchanged
root and automatic-context controls pass with all required local gates. Guard
is limited to captured non-struct class roots; value aggregates/VIF remain
unchanged. L17 can resume on the validated runtime.

L17 closure after validated L18/L19/L20/L21 prerequisites: d8e974913;focuslegacy2/0,JSON2/0,neighborslegacy24/0,JSON23/0,original red passes both editions,makecheck,independent source review;legacy4931total4926pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1823/0,realDPIUVM355/0/0,NFA58/58,frontend97109exit0 all scenarios;install restored and five frozen hashes match. Complete15release results-3d_bbaiu11SMOKE_PASS4COMPILE_FAIL;all15 statuses/source/archive hashes match L21.

Original1.2 OpenTitan debug-crossbar replay6645: PASS,compiler0/runtime0,10.177s,152hostrequests/288scoreboarditems,0UVMwarnings/errors/fatals,compile semantic debt0/runtime debt0,TEST PASSED CHECKS and normal finish17625626ps. Original corpus7a3ad34 clean;UVMsrcSHA885ba9f74652494aa132aaaa26c43e9f210f94cdf5a8d3a87064993ec9b35dc0 unchanged. Actual -g2012,one default-seed smoke invocation;no paired-edition/multi-seed/full OpenTitan qualification. Two existing benign runtime lines report discarded $system return value.

### L22 — Built-in process::state nominal enum type

- **State:** CLOSED at4a102ee47 after all required gates.
- **Evidence:** Original UVM1.0p1 uvm_phases.svh2824 function return type fails visible-class lookup on d8e974913.
- **Scope:** 2017/2023 9.7 declared state enum and typed status/constants, preserving 6.19 nominal enum semantics. No scheduling redesign or full UVM1.0p1 qualification.

L22 validation: 4a102ee47;focuslegacy6/0,JSON6/0,neighborslegacy16/0,JSON10/0,makecheck and final independent review;Bison563SR1122RR,parse.output identical;legacy4937total4932pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1829/0,realDPIUVM355/0/0,NFA58/58,frontend18561exit0 all scenarios;install restored and five frozen hashes match. Complete15release results-p7axbpcu11SMOKE_PASS4COMPILE_FAIL;all15 source/archive hashes and statuses match L17,1.0p1 process::state error removed.

Bare class-scoped module declarations remain DD039; no full process or UVM1.0p1 qualification. Next exposed nested-background fork error is DD040.

### L23 — Nested joins in function-spawned background processes

- **State:** CLOSED at58edf8034 after required validation.
- **Evidence:** DD040 and both-edition reducer reject join_any within outer function fork/join_none.
- **Scope:** 13.4.4 task-legal background children using existing isolated elaboration context; retain direct function blocking-join errors. No scheduling/lifetime redesign or full UVM qualification.

L23 validation: 58edf8034;originalred both editions PASSED/no diagnostics,focuslegacy4/0,JSON4/0,existingfunctionfork2/0 both,neighborslegacy43/0,JSON33/0,makecheck and final independent review;legacy4941total4936pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1833/0,realDPIUVM355/0/0,NFA58/58,frontend38601exit0 all scenarios;install restored and five frozen hashes match. Complete15release results-2hbuhcyt11SMOKE_PASS4COMPILE_FAIL;all15 statuses/source/archive hashes match L22. Nested-fork diagnostic removed from1.0p1/1.1a;each retains three void-cast-of-void errors.

### L24 — Void function calls in void-cast statements

- **State:** CLOSED at795d9f360 with test reconciliation8afc61443 after required validation.
- **Evidence:** DD041, both-edition calls with argument/output effects rejected; original1.0p1/1.1a each fail three such calls.
- **Scope:** Dedicated13.5/A.6.9 function-call statement grammar, preserving actual effects and task/void-expression/deferred-action restrictions. The grammar/prose reading is explicitly recorded as inference; no compatibility bypass or upstream source edits.

L24 validation reconciliation: the initial integrated run found the legacy-only
`sv_void_cast_fail1` expected the dedicated statement to be rejected. That obsolete
expectation is replaced by direct void-function expression rejection; the new
paired tests own legal-statement coverage. Independent review agrees. This does
not qualify historical2005 acceptance. Required rerun remains pending.

L24 final validation: 795d9f360 with test reconciliation8afc61443;originalred both editions PASSED,no diagnostics;focuslegacy7/0,JSON4/0,neighbors23/0 both,makecheck,independent review;legacy4945total4940pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1837/0,realDPIUVM355/0/0,NFA58/58,frontend93910exit0 all scenarios;install restored and five frozen hashes match. Complete15release results-6_pvcxya11SMOKE_PASS2COMPILE_FAIL2RUNTIME_FAIL;all15 source/archive hashes match L23. 1.0p1/1.1a now compile/start but missing older DPI prevents pass;1.0p1 also unresolved-functor/cast diagnostics.

### U11 — Original UVM1.0p1/1.1a DPI entry points

- **State:** CLOSED at e18128369 after required validation.
- **Evidence:** DD042 missing old command-line/regex symbols in unmodified sources.
- **Scope:** Real argv iteration/restart and metadata, strict cached regex adapters;
  no original-source edits or unrelated legacy runtime/recording fixes.

U11 final validation: e18128369;both-edition red failed missing old DPI entrypoint;focused8/0,makecheck,independent code/evidence review;legacy4945total4940pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1837/0,realDPIUVM355/0/0,NFA58/58,frontend41504exit0 all scenarios including oldABI both editions;install restored and five frozen hashes match. Release results-zyhh1jv9 complete/baseline_valid,all15source/archive hashes unchanged. Reviewed12clean smoke passes,1disqualified1.0p1 runtime,2compilefails;raw1.0p1SMOKE_PASS rejected due existing3placeholder and2cast diagnostics. 1.1a clean new smoke pass through time1.

### U12 — Simulator diagnostics cannot be clean release smoke passes

- **State:** CLOSED at1654dc4c9 after required harness validation.
- **Evidence:** DD043 original1.0p1 false-positive runtime row.
- **Scope:** Existing shared classifier/offline tests and fresh release evidence;
  no compiler changes or repair of underlying runtime diagnostics.

U12 final validation: 1654dc4c9;newdiagnosticnegative failed8subcases beforefix,all8offline matrix tests pass;all13historical runtime logs correct12accept/1reject;independent review caught/fixed quoted-UVM_INFO falsepositive with permanent control. Fresh15release results-fm8uvyiv complete/baseline_valid,12SMOKE_PASS1RUNTIME_FAIL2COMPILE_FAIL;all15source/archive and alltoolhashes unchanged vsU11. Only1.0p1 rawstatus corrected;no compiler/DPI or IEEE semantic gain. Frozen U11 fivehashes match.

### L25 — Integral function-name variable passed by reference

- **State:** CLOSED atc58035f49 after requiredvalidation.
- **Evidence:** Both-edition7-to12 ref-update reducer fails; three original1.0p1
  build_coverage functions bind a ref formal to an omitted return signal.
- **Scope:** True reference storage under13.4.1/13.5.2, retaining return and
  lifetime semantics. Address-taken return variables use existing signal/context storage.
  Callback cast/typeidentity diagnostics remain separate.

L25 final validation: c58035f49;originalred/interactions both editions PASSED,no diagnostics;focuslegacy2/0,JSON2/0,neighborslegacy58/0,JSON46/0,makecheck and independent design/code review;legacy4947total4942pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1839/0,realDPIUVM355/0/0,NFA58/58,frontend88452exit0 allscenarios;installrestored and fivefrozenhashesmatch. Complete15release results-3v03d7qs12SMOKE_PASS1RUNTIME_FAIL2COMPILE_FAIL;all15statuses/source/archivehashes unchanged vsU12. Original1.0p1 threeplaceholder diagnostics gone;two callbackcast errors remain.

### L26 — Matching class parameters with independent defaults

- **State:** CLOSED at e3666fd07 after required validation.
- **Semantics:** Both IEEE editions 8.25 require matching effective class-type
  parameters of the same generic declaration to select one type.
- **Cause:** Existing canonical key path requires a dependent default, so
  independent omitted/explicit defaults incorrectly retain source identity.
- **Scope:** Concrete multi-class-type parameters with bare nominal class defaults; preserve unresolved
  forwarding and owner identity. Generic-template initialization remains separate.
- **Evidence:** `evidence/campaign-20260908/l26/default-pair.sv` and `.json`;
  larger original-callback reducer and passing controls retained.

L26 final validation: e3666fd07; both-edition15line reducer PASSED; focuslegacy2/0,JSON2/0,paramneighbors23legacy/16JSON,identity/dependent/seedneighbors6/0each,makecheck and independent design/code review; legacy4949total4944pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1841/0,realDPIUVM355/0/0,NFA58/58,frontend29502exit0 allscenarios; installation restored and five sha256-final hashes match. Complete15release results-8054igtp12SMOKE_PASS1RUNTIME_FAIL2COMPILE_FAIL; all15statuses/source/archivehashes matchL25, original1.0p1 stilltwo callbackcasts.

### L27 — Generic master static initialization

- **State:** CLOSED at8f2252dd3 after required validation.
- **Semantics:** Both8.25 assign static storage to concrete specializations;
  the generic class itself is not a type.
- **Cause:** `netclass_t::elaborate` emits a static initializer process even
  for the unspecialized generic master. One requested specialization causes
  two registration side effects.
- **Scope:** Generic masters only; preserve actual concrete/default and ordinary
  class initialization. Seed-derived forwarding lifecycle remains DD044.
- **Evidence:** `evidence/campaign-20260908/l27/seed-init.sv` and `.json`.

L27 final validation: 8f2252dd3; both-edition red PASSED; focuslegacy2/0,JSON2/0,static/identityneighbors37legacy/25JSON,makecheck and independent design/code review; legacy4951total4946pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1843/0,realDPIUVM355/0/0,NFA58/58,frontend78203exit0 allscenarios; installation restored and five frozen hashes match. Complete15release results-ni3wgjii12SMOKE_PASS1RUNTIME_FAIL2COMPILE_FAIL;all15statuses/source/archivehashes matchL26;original1.0p1 stilltwo callbackcasts.

### U13 — Literal legacy DPI arguments versus GNU runtime options

- **State:** CLOSED, exact harness scope on9006baa15. Prior published2785
  Linux CI failed before simulation with `vvp: invalid option -- f`.
- **Cause:** The fixture invocation lacks `--` before the program/argv.
  `vvp/main.cc` deliberately allows GNU getopt permutation.
- **Scope:** Invocation separator only; retain literal `-f` iteration assertions,
  metadata/regex behavior, and all diagnostics. Local frontend and fresh Linux
  CI are required; no compiler/DPI semantic change.

U13 validation complete: local isolated frontend35171exit0 with all original
argv/regex checks retained and installed hashes restored. Fresh published
9006baa15 jobs103200770181 (Ubuntu22.04) and103200770250 (Ubuntu24.04)
both succeeded; logs confirm legacy_10_dpi IEEE2017 and2023 PASS on both.
Evidence: `evidence/campaign-20260908/l29/ubuntu2204.plain.log` and
`ubuntu2404.plain.log`. Independent review clear. Other PR275 platform
checks remain pending; this closure is not PR readiness or merge permission.

### L28 — Unresolved forwarded type initializer side effects

- **State:** CLOSED at77cce610b after required local validation.
- **Cause:** Symbolic forwarding requests have specialized-instance metadata
  while their actual retains generic source lineage; static init ignores this.
- **Scope:** Existing deferred-type predicate at process registration; preserve
  concrete cache reuse, initialization analysis and ordering. DD044 evidence.
- **Coordination:** U13 remains awaiting fresh Linux CI on9006baa15; it only
  changes a fixture command. L28 has no dependency on that pending harness gate.

L28 final validation: 77cce610b; counter and callback reds both editions PASSED/no diagnostics; focuslegacy4/0,JSON4/0,static/identityneighbors37legacy/25JSON,L27neighbors2/0each,makecheck and independent design/code/evidence review; legacy4955total4950pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1847/0,realDPIUVM355/0/0,NFA58/58,frontend91254exit0 allscenarios;installation restored/five frozen hashes match. Complete15release results-edrgslxb13SMOKE_PASS2COMPILE_FAIL;only1.0p1 statusimproves,all15source/archivehashes unchanged. Original1.0p1 cleanruntime/time1 with zeroUVMwarnings/errors/fatals;existingcompileconstraint/castlimitations remain,notfullUVMqualification.

### L29 — Abandoned procedural block scope during parser recovery

- **Status:** CLOSED at9229c24e7, bounded procedural-block recovery; robustness only.
- **Evidence:** `evidence/campaign-20260908/l29/one-loop.sv`, both editions
  abort134 on validated77cce610b; legal replacement compiles0. Existing parser
  trace shows a discarded begin midrule leaves lexical scope active, then
  normal enclosing for reduction reaches a scope assertion.
- **Scope:** Release discarded procedural block scopes at their ownership
  boundary; retain syntax rejection and valid nested/named/loop behavior.
- **Not claimed:** Recording support, another UVM release pass, or all parser
  recovery. Foreach carrier recovery remains DD045. U13 Linux CI has passed.

L29 final validation: 9229c24e7; original malformed reducer and all five procedural block forms reject normally in both editions; paired runtime lifetime/label/foreach/fork controls PASS. Focus12legacy/12JSON,neighbors68legacy/57JSON,makecheck and independent design/code/test reviews clear. Bison563SR1122RR unchanged. Legacy4967total4962pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1859/0,realDPIUVM355/0/0,NFA58/58,frontend74117exit0 allscenarios;installation restored/five frozen hashes match. Complete15release results-bwek89ja13SMOKE_PASS2COMPILE_FAIL;all status/source/archivehashes unchanged vsL28. 1.1b/c now normalcompile32 without assertion,not new UVM passes.

### L30 — Direct class-scoped type declarations at module scope

- **Status:** CLOSED at34787868e; bounded DD039 direct complete-class type route.
- **Reducer:** Complete class holder with typedef int state; module declares
  holder::state s. Both editions reject as invalid module instantiation.
- **Scope:** Reuse class type resolution at the module declaration frontier;
  preserve type identity, variable shapes and illegal-prefix/access rejection.
- **Authority:** Both editions6.18/8.23; unresolved prefix restrictions remain.
- **Evidence:** `evidence/campaign-20260908/l30/`; no fullclass/UVM claim.

L30 final validation: 34787868e; originalredcompile0/no diagnostics both editions; permanentfocus12legacy/12JSON,neighbors43legacy/32JSON,makecheck and independentdesign/code/ownershipreviewclear. Bison563SR1122RRunchanged. Legacy4979total4974pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66,fullJSON1871/0,realDPIUVM355/0/0,NFA58/58,frontend21313exit0 allscenarios;installation restored/fivefrozenhashes match. Complete15release results-jz6zk_cb13SMOKE_PASS2COMPILE_FAIL;allstatuses/source/archivehashes unchanged vsL29. No fullclass/UVM qualification claim.

### L31 — Associative compound expression typing

- **Status:** CLOSED at0a4e7d639; bounded DD036 associative expression typing.
- **Reducer:** Signed byte associative element -64/=2 gives96 instead of-32
  in both editions. Expansion emits unsigned division.
- **Scope:** Resolved element signedness and binary operand width/state through
  final store; mixed unsigned and self-determined shift controls required.
- **Authority:** Both editions11.4.1/11.6/11.8; evidence l31.

### Campaign priority — Eliminate remaining behavior-changing compile-progress paths

User-directed follow-on after the UVM smoke campaign: implement and qualify
correct semantics for every remaining compile-progress stub or fallback that
emits incorrect behavior. This includes silent degradation, not only diagnostics.
An unsupported error, removed warning, or smoke pass does not close a legal
feature. Select one concrete blocker at a time using reducers and applicable
IEEE semantics; existing registries are not an exhaustive inventory.

Confirmed initial evidence is original1.0p1 `results-jz6zk_cb/compile.log`
(per-release `1.0p1/compile.log`): ignored `pick_sequence` constraint at
uvm_sequence_base.svh949, and class-cast bits reinterpretation at
uvm_phases.svh1951. Reproduce exact semantic effects before selecting each
implementation contract. A constant-loop warning alone is not a stub.
L31 remains active; this priority does not authorize unrelated edits in its patch.


User follow-up explicitly authorizes a sweep of **all fallbacks**, including
silent paths and qualification-harness substitutions. DD046 records the first
tracked-source inventory, source-confirmed categories, false-positive rules,
and remaining semantic triage. This is discovery work, not another governance
bootstrap. Fix behavior-changing cases after UVM smoke, with one active blocker.

L31 final validation: 0a4e7d639; both-edition signed/mixed/shift/wide/four-state and local/property reducers PASS; permanentfocus2legacy/2JSON,neighbors125legacy/92JSON,makecheck and independentdesign/code/ownershipreviewclear. Integrated92982exit0:legacy4981total4976pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66. JSON7147exit0:1873/0. UVM32316exit0:REAL DPI355/0/0. NFA58/58. Frontend49875exit0 allscenarios;installation restored andfivefrozenhashes match. Complete15release results-322hzu4s13SMOKE_PASS2COMPILE_FAIL,allstatuses/source/archivehashes unchanged vsL30. No full associative/UVM qualification claim.


### U14 — Native legacy recording ownership and lifecycle

- **Status:** CLOSED for bounded lifecycle scope on native ARM64; semantic `729edce3c`, test/CI coverage `79885f484`. DD038 remains OPEN.
- **Original gap:** Native owner/lifecycle API absent; both-edition DPI owner reducer
  compiled but failed at runtime. Original1.1b/c recording macro gaps preserved.
- **Scope:** Explicit legacy recorder, real lifecycle journal, owner/kind/state
  validation and cross-owner links using original1.1d API. No automatic install
  or fake attribute macro. Full typed capture/bootstrap remain required.
- **Evidence:** `evidence/campaign-20260908/u14/`; ACTIVE_WORK owns exact contract.

U14 final validation: U14 semantic729edce3c; test/Windows-CI coverage79885f484. Installed native lifecycle/exclusive-text checks both editions and POSIXIOfailure pass; original1.1d realchild/component,wrongowner,stream/transaction rollback,recorder switch,exclusive/replacedfiles and journal-failure tests pass. makecheck and independent design/code/failure-path reviews clear. Integrated20014 exit0:4981total4976pass0fail2NI3EF,VPI105/0,negative149/0,runtime15/15,copyout6/6,exports66. JSON82380 exit0:1873/0. UVM57598 exit0:REAL DPI355/0/0. NFA45081 exit0:58/58. Releases32494 results-y5czc48y complete/baseline_valid13SMOKE_PASS2COMPILE_FAIL,all15status/source/archivehashes unchanged vsL31; separate1.1d lifecycle gate passes2017/2023. Frontend97996 exit0 allS1-S11;installation restored/six frozen hashes match. Bounded ARM64 local lifecycle validation only; typed capture/default installation/1.1b/c and fullUVM qualification remain open. Windows CI wired,execution not claimed.


### U15 — Lossless native recording value capture

- **Status:** CLOSED 2026-09-11 for the packed/real/string attribute-capture
  scope. Semantic `7db0431ff` (registration) + `da8d8c58c` (encoder) +
  `c0a8592eb` (string-dispatch fix). A new systf, `$ivl_uvm_record_attribute`
  (uvm_dpi/uvm_recording.cc), dispatches on `vpi_get_value(vpiObjTypeVal)`:
  packed captures every aval/bval word with declared size/sign; real captures
  exact IEEE754 bits (not decimal text); string reads `vpiStringVal` first
  and retries with `vpiVectorVal` only on a length mismatch against `vpiSize`
  under either unit convention the two backing VPI classes use, which is
  reachable in practice only for a literal whose value contains an embedded
  NUL (38.15 licenses that retry for `vpiStringConst`; L32 is the prerequisite
  that makes it correct). Unknown, wrong-kind, already-ended and
  already-freed transaction handles are all rejected before any journal
  write, with a nonzero simulation exit status since the task has no other
  return channel. All six required gates pass with durable exit files:
  integrated exit0 (unaffected by this change, reused from `c0a8592eb`'s run:
  4981/4976/0/2NI/3EF, VPI107, negative149, runtime15), JSON exit0 (unaffected,
  reused: 1873/0), UVM exit0 355/0/0 REAL DPI, NFA exit0 58/58, releases
  exit0 15/15 SMOKE_PASS (see U16), frontend exit0 all scenarios including
  new S12. Install restored; five of six frozen hashes unchanged, the sixth
  (`uvm_dpi.vpi`) changed as expected and is reframed as U15's new baseline
  (`evidence/campaign-20260908/u15/installed-frozen-sha256.json`).
- **Scope actually closed:** Native packed width/sign/four-state bits, exact
  real values, `string`-variable and string-literal values (including an
  embedded zero byte), valid transaction routing, and single evaluation of
  the value argument (verified: `single-eval-20260911.log`).
- **Bug found and fixed before closure:** the first committed encoder used
  `vpiType`/`vpiConstType` to decide when to retry with `vpiVectorVal`, which
  cannot distinguish a literal from a `.name()`/function-call/concatenation
  result -- all report the identical signature as a systf argument, yet only
  a literal supports `vpiVectorVal` (DD048). `.name()` is the single most
  common string field in real UVM `do_record` bodies, so the bug was on the
  primary path, not an edge case; corrected before any gate ran on it.
- **Remaining parent scope (DD038, still OPEN):** Complete declared schema,
  aggregates, object identity/cycles and deterministic default installation.
  No default-recorder installation in this increment; see U16 for the
  narrower, harness-scoped 1.1b/1.1c macro fix, which is deliberately kept
  separate from this native-capture scope.
- **Discovered, record-only:** DD048 (`__vpiVThrStrStack` has no
  `vpiVectorVal` path and reports `vpiSize` in a different unit than
  `__vpiStringConst`).
- **Evidence:** `evidence/campaign-20260908/u15/`.


### U16 — Legacy UVM release smoke compatibility (1.1b/1.1c)

- **Status:** CLOSED 2026-09-11. Semantic `90e95c339`.
- **Scope:** uvm-1.1b and uvm-1.1c guard `uvm_record_attribute` with
  `ifdef QUESTA/VCS/INCA` and no unguarded fallback branch (1.1d added one;
  these two omit it), so the macro is undefined on any simulator that is none
  of those three and `uvm_tlm2_generic_payload.svh` fails to parse -- a real
  omission in the archives, not a disagreement with them. `docs/uvm_frontend.md`
  states the normal `-uvm`/`--uvm-home` path defines no compatibility macros,
  and `-D` cannot express a function-like macro from the CLI at all, so the
  fix is a harness-only compat file
  (`scripts/uvm-release-compat/legacy_record_attribute.svh`) that
  `scripts/uvm_release_matrix.py` compiles ahead of a release's own
  `uvm_pkg.sv`, only for the two release ids a new `record_attribute_compat`
  manifest field names. It routes to U15's real, tested
  `$ivl_uvm_record_attribute`, not a no-op stub. No pinned archive edited, no
  vendor impersonated, no change to the normal path.
- **Result:** `scripts/uvm_release_matrix.py` reaches 15/15 SMOKE_PASS,
  `complete=true`/`baseline_valid=true`, including 1.1d's separate
  recording-lifecycle qualification
  (`evidence/campaign-20260908/u15/releases-full.log`, exit0). All 13
  previously passing releases are unaffected (gated on the manifest field).
- **Evidence:** `evidence/campaign-20260908/u15/releases-full.log`;
  `third_party/uvm-releases/results-xz9vnb6n/results.json`.


### L32 — VPI string literal vector extraction

- **Status:** CLOSED 2026-09-11 for the literal/parameter vpiVectorVal scope.
  Semantic `ab54351c3`; test oracle correction `fc90f1fa2`. The `swrite` endian
  probe relied on the old reversed literal order. `%u` of a literal now equals
  `%u` of the equivalent vector, as 5.9 and the format specifications clause
  (2017 21.2.1.2, 2023 21.2.1.1) require, so only the probe expectation changed.
  Gates, all with durable exit files: integrated exit0 4981/4976/0/2NI/3EF,
  VPI107, negative149, runtime15; JSON exit0 1873/0 with rows identical to U14;
  UVM exit0 REAL DPI 355/0/0 with rows identical; frontend exit0 all scenarios,
  install restored and six hashes match; NFA 58/58; releases unchanged 13
  SMOKE_PASS/2 COMPILE_FAIL. The string-parameter sibling path is verified in both
  editions. The TEMP subclass is reachable only from interactive `$stop`
  commands and is untested; the vlog95 swrite variant is not run. DD047 found.
- **Reducer:** Both editions return `"ABCD"` as0x44434241 instead of0x41424344;
  `"ABCDE"` also has reversed word placement. Shared loop additionally shifts
  signed bytes and initializes a word beyond the required allocation.
- **Scope:** Repair shared literal vector packing; preserve metadata and other
  conversions. IEEE5.9 and38.15; full typed recording remains open.
- **Evidence:** `evidence/campaign-20260908/u15/literal-vector-red.json` and
  `evidence/campaign-20260908/l32/`. Resume U15 after fullvalidation.

### L33 — Nested class-property VPI lvalue silently drops writes

- **Status:** CLOSED 2026-09-11. Selected from the DD046 fallback-inventory
  triage (`evidence/campaign-20260908/dd046/triage-20260911.md`, "Candidate 2,
  revised"). All required gates pass, durable exit files in
  `evidence/campaign-20260908/l33/`: integrated (legacy ivtest) exit0
  4981/4976/0/2NI/3EF, VPI107, negative149, runtime15/15 (a first run showed
  822 false failures from a stray orphaned `vvp_reg.pl` process racing the
  tracked run on the shared `ivtest/vsim` output file, confirmed by process
  inspection and a clean rerun -- not a real regression); JSON exit0 1873/0;
  UVM exit0 356/0/0 (baseline355 +1, the new permanent regression, both
  `plusargs_class_string_nested_test` and the existing direct-case
  `plusargs_class_string_test` PASS); NFA 58/58; releases unchanged 15/15
  SMOKE_PASS; frontend exit0 all S1-S12 scenarios including the new
  attribute-capture and recording scenarios from U15/U16. Install restored:
  `iverilog`/`ivl`/`uvm_dpi.vpi`/`uvm_legacy_recorder.svh` hashes unchanged
  from the U15 baseline; `vvp`/`vvp.tgt` changed, matching the four files this
  fix actually touched (`evidence/campaign-20260908/l33/installed-frozen-sha256.json`).
- **Symptom:** A `$value$plusargs`/similar VPI-lvalue write to a class string
  property reachable only through another class-typed property (e.g.
  `obj.inner.s`, IEEE1800 clause38.15 vpiStringVal/vpiVectorVal write path)
  silently discarded the value. `tgt-vvp/draw_vpi.c`'s `get_vpi_taskfunc_signal_arg`
  already emitted a working `&CPS<vSIG,pidx>` property-aware VPI handle for a
  DIRECT class-string-property base (`obj.s`, Phase51/U15), but its own comment
  said "Only handle the simple case (direct signal base, not nested)" -- a
  nested chain fell back to `draw_eval_string`, an rvalue-only stack temporary
  whose `vpi_put_value` result is discarded once the systf call returns. No
  error was printed; the plusarg's own matched/not-matched status was
  unaffected, so this was a genuinely silent data-loss path.
- **Root cause:** `ivl_expr_signal()` on an `IVL_EX_PROPERTY` node is a
  shortcut elaboration takes only for a single, non-chained property access.
  Once a property access is itself used as the BASE of a further property
  access, elaboration builds the intermediate node through the generic
  base-expression path (`ivl_expr_oper2()`) instead, even when that base is
  in fact a plain signal -- so `expr_signal_base_()`, and the old fast-path's
  `!ivl_expr_signal(expr)` guard, saw a null signal and bailed to the
  rvalue-only fallback for any chain longer than one hop.
- **Fix:** `tgt-vvp/draw_vpi.c` gained `collect_property_chain_()`, which walks
  an arbitrary-depth string-property chain down to its root signal (stopping
  at either the direct-signal shortcut or a plain-signal base), rejecting any
  hop that is array-indexed (`ivl_expr_oper1()` set) as out of scope. The
  matched chain now emits a variable-arity `&CPS<vSIG_0,idx0,idx1,...>` (was
  fixed two-field). `vvp/parse.y`'s `K_CPS` production now takes the existing
  `numbers` list nonterminal instead of one `T_NUMBER` (zero new grammar
  conflicts -- bison table diffed against the unmodified baseline, only the
  touched production and its own states differ). `vvp/vpi_cobject.cc`'s
  `__vpiClassPropertyStringVar` now holds a property-index PATH rather than a
  single index: every hop but the last is walked via `vvp_cobject::get_object()`
  at each access (the intermediate class handle can change at runtime), and a
  null handle mid-chain on a WRITE reports loudly (`vvp error: class property
  write through a null intermediate class handle...`, matching the existing
  virtual-interface-write-rejection convention) rather than dropping silently
  -- the exact failure mode this blocker exists to remove, not reintroduced
  one level up. Reads through a null intermediate stay silently empty,
  matching this class's pre-existing convention for "no object at all".
- **Scope (deliberately bounded, per AGENTS.md "do not claim a parent feature
  complete after fixing one subcase"):** STRING class properties only.
  Integral (vec4/`CPV`) nested class properties have the identical gap
  (`get_vpi_taskfunc_signal_arg`'s CPV branch still requires a direct signal
  base) and are explicitly NOT fixed here -- recorded as follow-on work, not
  silently left ambiguous. Array-indexed hops anywhere in a chain (`arr[i].s`,
  `obj.arr[i].s`) and virtual/polymorphic dispatch are out of scope and still
  fall back to the rvalue-only path (unchanged pre-existing behavior, not a
  regression). Verified: 1-level (`obj.inner.s`), 2-level/3-hop
  (`obj.mid.leaf.s`), and the null-intermediate-handle write all behave as
  designed; array-indexed hop falls back without crashing.
- **Reducers:** `evidence/campaign-20260908/dd046/c2.sv` (direct case, must
  keep working), `c3.sv` (the original 1-level nested repro), `c4_deep.sv`
  (3-level nesting, confirms the recursion generalizes beyond 1 hop),
  `c5_null.sv` (write through a null intermediate handle -- must error
  loudly, not drop silently), `c6_arrhop.sv` (array-indexed hop -- must fall
  back to the rvalue-only path without crashing, confirmed out of scope).
- **Permanent regression:** `tests/plusargs_class_string_nested_test.sv`
  (new), registered in `.github/uvm_test.sh`'s `plusargs_for()`. Sibling of
  the existing Phase51 `tests/plusargs_class_string_test.sv`, which covers the
  direct (non-nested) case and must keep passing unchanged.
- **Validation:** full required sequence passed (integrated/JSON/UVM/NFA/
  releases/frontend-last); see the Status line above for exact counts and
  `evidence/campaign-20260908/l33/` for durable exit files.
- **Evidence:** `evidence/campaign-20260908/l33/`,
  `evidence/campaign-20260908/dd046/triage-20260911.md`.
- **Addendum (found during L34):** `collect_property_chain_()` (shared by
  this entry's string path and L34's integral path) had a latent gap this
  entry's own gates never exercised: a property access whose base is a
  WORD-INDEXED array of class handles (`arr[1].s`, not merely a chain of
  named properties) carries its index via `ivl_expr_oper1()` on the
  `IVL_EX_SIGNAL`/`IVL_EX_ARRAY` base node, which the helper ignored,
  emitting a label for the wrong (nonexistent) functor. No ivtest test
  exercised "array-of-objects then `.string_property`" at L33's close, so
  this passed unnoticed at the time; L34's gate sweep caught the identical
  gap via an integer-property test and the fix (reject an array-indexed
  base, same as an array-indexed property hop) is in the shared helper, so
  it closes this gap for the string path too. Reverified:
  `evidence/campaign-20260908/dd046/c13_arr_of_obj_str.sv`.

### L34 — Nested class-property VPI lvalue silently drops writes (integral sibling of L33)

- **Status:** CLOSED 2026-09-11. The integral (vec4/CPV) counterpart of
  L33, explicitly named as an un-fixed follow-on in that entry rather than
  left ambiguous. All required gates pass, durable exit files in
  `evidence/campaign-20260908/l34/`: integrated exit0 4981/4976/0/2NI/3EF,
  VPI107, negative149, runtime15/15; JSON exit0 1873/0; UVM exit0 357/0/0
  (356 baseline +1, all four plusargs class-property tests -- direct and
  nested, string and integral -- PASS); NFA 58/58; releases unchanged
  15/15 SMOKE_PASS; frontend exit0 all S1-S12. Install restored:
  `iverilog`/`ivl`/`uvm_dpi.vpi`/`uvm_legacy_recorder.svh` hashes unchanged
  from the L33 baseline; `vvp`/`vvp.tgt` changed, matching the four files
  this fix touched (same four files as L33) --
  `evidence/campaign-20260908/l34/installed-frozen-sha256.json`. A real
  regression (not a race-condition false positive) was found and fixed by
  the ivtest gate mid-pass -- see the dedicated bullet below.
- **Symptom:** Identical to L33 but for `int`/`bit`/`logic`-typed class
  properties: `$value$plusargs("N=%d", obj.inner.n)` silently dropped the
  write when `n` is reached through another class-typed property
  (`obj.inner.n`). The direct case (`obj.n`) already worked via
  `&CPV<vSIG,pidx,width,signed>` (M14/prior session); a nested chain fell
  back to a discarded vec4 stack temporary, same failure shape as L33
  before its fix.
- **Root cause:** Identical mechanism to L33 -- `get_vpi_taskfunc_signal_arg`'s
  old direct-only CPV check required `ivl_expr_signal(expr)` non-null on the
  property node itself, which is null for any nested property chain (see
  L33's root-cause writeup); any chain longer than one hop fell through to
  the rvalue-only path with no error.
- **Fix:** Reused L33's `collect_property_chain_()` unchanged (it is
  already type-agnostic about the leaf property's value type) from a new
  integral-specific call site placed at the same point in
  `get_vpi_taskfunc_signal_arg` as L33's string call site -- before the
  `expr_signal_base_()`-based `if (!sig) return 0` bailout that ate the
  chain for the same reason L33 hit it. The old direct-only CPV block
  became fully dead code once the chain-based check subsumed it (the
  chain collector's base case handles the direct/non-nested case
  identically to the old check) and was deleted rather than left stale.
  `vvp/parse.y`'s `K_CPV` production now takes `numbers` for the chain, but
  -- unlike `K_CPS` -- the chain had to move to the END of the production
  (`&CPV<vSIG_0,width,signed,idx0,idx1,...>`, was
  `&CPV<vSIG_0,pidx,width,signed>`) because CPV has two trailing fixed
  fields (width, signedness) after the property index; putting `numbers`
  before them would be genuinely LALR(1) ambiguous (the parser cannot
  decide, on the next `T_NUMBER`, whether it continues the chain or starts
  the fixed fields). `numbers` followed only by `'>'` is unambiguous, same
  as `K_CPS`. Verified zero new grammar conflicts the same way as L33:
  bison's full verbose table diffed against the (already-verified-clean)
  L33 baseline shows only the `K_CPV` production's own states differing.
  `vvp/vpi_cobject.cc`'s `__vpiClassPropertyVecVar` now holds a
  property-index path exactly like `__vpiClassPropertyStringVar`; a null
  intermediate handle on a write reports loudly via the same
  `report_null_property_container_write_()` L33 added, not a new message.
- **Scope (same boundary as L33):** Integral (`bit`/`logic`/`int`, i.e.
  `IVL_VT_LOGIC`/`IVL_VT_BOOL`) class properties only. `real`-typed nested
  properties, array-indexed hops in a chain, and virtual/polymorphic
  dispatch remain out of scope and fall back to the pre-existing
  rvalue-only path (unchanged, not a regression). Verified: 1-level
  (`obj.inner.n`), 3-level/3-hop (`obj.mid.leaf.n`), and the
  null-intermediate-handle write all behave as designed; array-indexed hop
  falls back without crashing.
- **A second, genuine regression was found and fixed by the ivtest gate
  before this closed** (not the L33 race-condition false positive): the
  first committed L34 change made `collect_property_chain_()`'s
  `IVL_EX_SIGNAL`/`IVL_EX_ARRAY` base-case branch accept the base
  unconditionally, but a word-indexed array-of-class-handles base (e.g.
  `arr[1].id`, `fixed[0].id` -- an array element, not a chain of named
  properties) carries its index via `ivl_expr_oper1()` on that base node.
  Ignoring it and hardcoding the emitted label's word suffix to the
  scalar case produced a label matching no real functor: vvp printed
  "unresolved functor stub" and the read came back `X` instead of the real
  value. Caught by two vendored ivtest tests
  (`sv_array_port_object_event`, `sv_cast_container_task_failure`),
  reduced to `evidence/campaign-20260908/dd046/c12_arr_of_obj.sv`, and
  fixed by rejecting an array-indexed base the same way an array-indexed
  *property* hop was already rejected -- fall back to the safe rvalue-only
  path, which resolves the word correctly. This bug lived in the shared
  helper, so it equally affected L33's string path (never caught there,
  since no ivtest test combines an object array with a string property);
  see the addendum on L33 above. Both ivtest regressions reverified
  passing against gold after the fix.
- **Reducers:** `evidence/campaign-20260908/dd046/c7_int_nested.sv` (direct
  bug reproduction), `c8_direct.sv` (direct case, must keep working),
  `c9_deep_int.sv` (3-level nesting), `c10_null_int.sv` (null-intermediate
  write), `c11_arrhop_int.sv` (array-indexed property hop, out of scope),
  `c12_arr_of_obj.sv` (array-indexed SIGNAL base, the second regression
  above), `c13_arr_of_obj_str.sv` (string analog of c12, confirming the
  shared-helper fix also closes L33's latent gap).
- **Permanent regression:** `tests/plusargs_class_integral_nested_test.sv`
  (new), registered in `.github/uvm_test.sh`'s `plusargs_for()`. Sibling of
  the existing `tests/plusargs_class_integral_test.sv` (direct case), which
  must keep passing unchanged. The array-of-objects regression itself is
  already covered by two existing vendored ivtest tests
  (`sv_array_port_object_event`, `sv_cast_container_task_failure`); no new
  permanent test needed beyond keeping them in the required ivtest gate.
- **Validation:** full required sequence passed (integrated/JSON/UVM/NFA/
  releases/frontend-last); see the Status line above for exact counts and
  `evidence/campaign-20260908/l34/` for durable exit files.
- **Evidence:** `evidence/campaign-20260908/l34/`.

### L35 — Assigning a string value to a real target silently substituted 0.0

- **Status:** CLOSED 2026-09-11. Found via DD046's curated-table re-triage
  (the "Lost expression typing" row), which had been closed the same day
  as "empirically unreached across ~5300 tests" -- but per an advisor
  review, a probe that never fires and a probe that's never reached look
  identical, so a hand-written sanity reducer was built to confirm the
  instrumentation actually could fire before trusting that negative
  result. It fired immediately on the most ordinary possible construct
  (`real r; string s; ...; r = s;`), which is what DD046's table entry
  had missed: this branch is reachable by completely mainstream code, not
  only by exotic unresolved-parameterized-method paths. All six required
  gates pass at the exact pre-existing baseline plus the one new
  permanent test: integrated exit0 4982/4977/0/2NI/3EF (4981/4976 baseline
  +1 new CE test), JSON exit0 1873/0 (unaffected -- new test lives only in
  the legacy ivtest list), UVM exit0 357/0/0, NFA 58/58, releases 15/15
  SMOKE_PASS, frontend exit0 all S1-S12. Install restored: only
  `local-install/lib/ivl/ivl` (the frontend binary) changed vs the L34
  baseline -- `iverilog`/`vvp`/`vvp.tgt`/`uvm_dpi.vpi`/
  `uvm_legacy_recorder.svh` hashes unchanged, exactly as expected for a
  pure elaboration-time fix touching no codegen/runtime path --
  `evidence/campaign-20260908/l35/installed-frozen-sha256.json`.
- **Symptom:** `real r; string s; s = "3.5"; r = s;` compiled clean with
  no diagnostic and always read `r == 0.0` at runtime, silently
  discarding the string value (and any side effects already evaluated
  computing it).
- **Root cause:** `netmisc.cc`'s `elab_and_eval` (both overloads -- the
  `PExpr*`/`ivl_variable_type_t cast_type` form and the `ivl_type_t
  lv_net_type` form) has a compile-progress fallback, added to handle
  genuinely unresolved/generic parameterized-method-argument typing,
  that stubs ANY expression whose elaborated type doesn't match a
  STRING or REAL `cast_type` to an empty string / `0.0` / `null` rather
  than erroring. The sibling BOOL/LOGIC/vectorable branch right next to
  it already excludes a well-typed STRING source (`&&
  tmp->expr_type() != IVL_VT_STRING`) specifically because R30 found
  this exact defect shape for vector targets (`reg [127:0] b; b = str;`
  silently storing zero) and fixed it by letting a well-typed string
  fall through to the real cast machinery instead of being stubbed. The
  REAL-target branch a few lines above never got the same exclusion --
  a well-typed `IVL_VT_STRING` source unconditionally became `0.0`,
  reproducing R30's exact defect class one branch over, missed because
  R30's fix and the comment explaining it are physically adjacent to
  but not covering this branch.
- **Why a stub AND a fallthrough are both wrong here, so this is a hard
  error and not a repeat of R30's fix:** unlike the vector-target case
  (where falling through to `cast_to_int4`/`cast_to_int2` correctly
  packs the string per IEEE 1800-2017/2023 6.16's defined
  string-to-integral conversion), there is no defined string-to-real
  conversion in the LRM at all -- 6.16 enumerates only string<->integral
  and string<->string implicit conversions. Tracing what falling through
  to the existing `cast_to_real()`/`NetECast('r',...)` path would
  actually do confirmed it is not a safe alternative either:
  `tgt-vvp/eval_real.c`'s `draw_unary_real()` handles opcode `'r'` by
  evaluating the sub-expression as a vec4 bit pattern
  (`draw_eval_vec4`) and converting that pattern to a real via
  `%cvt/rv` -- correct for an integral source, but for a string source
  it would reinterpret the string's packed ASCII bytes as a (typically
  huge) unsigned integer and convert that number to a real, which is
  not a sensible "value of the string" under any defined semantics
  either. Neither existing behavior (silent 0.0) nor the naive
  alternative (silent garbage bit-pattern reinterpretation) is
  spec-correct, so per the precedent already set for a class handle
  into a non-class target (R32 finding A, 8.4) and a well-typed
  aggregate into a scalar (R32 finding B, 7.2.2/7.10), this is a hard
  compile error, not a stub of any kind.
- **Fix:** In both `elab_and_eval` overloads, the `cast_type ==
  IVL_VT_REAL` branch now checks `tmp->expr_type() == IVL_VT_STRING`
  first and, if true, reports `error: A string value has no implicit
  conversion to real (IEEE 1800-2017/2023 6.16); an explicit conversion
  such as string::atoreal() is required.` and fails elaboration instead
  of stubbing. A genuinely unresolved/generic (non-STRING) `tmp` type
  still gets the pre-existing `0.0` compile-progress placeholder --
  this fix narrows the branch to stop swallowing a WELL-TYPED string,
  it does not touch the still-open generic/parameterized-method case
  the branch was originally written for.
- **Scope:** Implicit real-target assignment (`real r; r = <string
  expr>;`, and equivalently through a task/function real-typed formal or
  a class real-typed property target reached via the `ivl_type_t`
  overload) only. `string::atoreal()` (explicit method call), integral-
  to-real, and real-to-real all continue to work exactly as before --
  verified with dedicated reducers. Not investigated: the second
  overload's sibling BOOL/LOGIC/vectorable branch
  (`netmisc.cc:2352-2358`) has no `tmp->expr_type() != IVL_VT_STRING`
  exclusion either (unlike the first overload's equivalent branch,
  which does) -- this may be the same R30-class gap recurring a third
  time in a different context, but was not reproduced or fixed this
  pass; flagged for a future increment rather than fixed speculatively.
- **Reducers:** `evidence/campaign-20260908/dd046/c22_real_string.sv`
  (the defect, confirms the hard error), `c22b_atoreal_ok.sv`
  (`string::atoreal()` still works), `c22c_int_to_real_ok.sv`
  (int-to-real still works), `c22d_real_to_real_ok.sv` (real-to-real
  still works).
- **Permanent regression:** `ivtest/ivltests/sv_real_string_assign_fail.v`
  (new, `CE` type), registered in `ivtest/regress-sv.list` alongside the
  existing `sv_class_new_fail1` (the same "illegal implicit conversion
  now hard-errors" pattern, for class handles rather than strings).
- **Validation:** full required sequence passed (integrated/JSON/UVM/NFA/
  releases/frontend-last); see the Status line above for exact counts and
  `evidence/campaign-20260908/l35/` for durable exit files.
- **Evidence:** `evidence/campaign-20260908/l35/`.

### L36 — Fixed-array locator methods rejected legal non-integral/non-zero-base arrays

- **Status:** CLOSED 2026-09-11. Found by directly re-auditing every DD046
  "loud diagnostic" disposition against a stricter bar per user challenge:
  does the diagnostic fire ONLY on illegal SystemVerilog? The Array-locator
  row's rejection did not -- it fired on legal code.
- **Symptom:** `find`/`find_index`/`find_first`/etc. on a fixed-size
  (non-dynamic, non-queue) unpacked array rejected with `sorry: ... on a
  fixed-size array of this element type is not yet implemented` whenever
  the element type was not BOOL/LOGIC, or whenever the array's declared
  range was not zero-based/ascending -- e.g. `string values[1:0];
  values.find_last with (...)` or `int values[5:3]; ...find_last_index...`.
  IEEE 1800-2017/2023 7.12.1: "Array locator methods operate on any
  unpacked array" -- no restriction to integral elements or declared base.
- **Root cause:** `elab_expr.cc`'s array-locator dispatch had two
  independent, artificially narrow gates that `make_array_unique_expr_`
  (the sibling helper used elsewhere for the same materialize-into-a-
  `netdarray_t`-temp pattern) does not have: (1) `make_queue_locator_with_expr_`'s
  `fixed_property` computation excluded any *direct signal* source
  (`!dynamic_cast<NetESignal*>(queue_expr)`), and (2) a separate check
  rejected any element type other than BOOL/LOGIC and any non-zero-based
  declared dimension outright.
- **Fix:** Removed the `NetESignal` carve-out so `fixed_property` is simply
  `fixed_type` (matching `make_array_unique_expr_`'s unconditional
  materialization), and replaced the element-type/base-range gate with a
  single check on `base_type()` allowing BOOL, LOGIC, REAL, STRING, and
  CLASS (the materialize-to-`netdarray_t` path already supports every one
  of these; only genuinely unsupported element categories still `sorry`).
  The declared-base restriction is gone entirely -- the loop already
  carries a separate declared index for `item.index`/`*_index` results,
  computed generically for any base, so nothing else needed to change.
- **Scope:** Fixed-array (direct-signal and class-property) locator
  methods only. At L36 closure, multidimensional fixed arrays still produced
  a genuine, loud `sorry` because subarray iteration was unimplemented. The
  October 8 candidate for issues #422-#426 adds that support and related
  aggregate-copy/result-typing cases; local focused tests pass, with exact-head
  CI pending. Also repaired two stale ivtest negative tests whose own
  comments already admitted the rejected forms were legal SV.
- **Reducers:** `evidence/campaign-20260908/l36/` (nonzero/descending base,
  string/real elements, paren-less syntax, multidim-still-rejected).
- **Permanent regression:** `ivtest/ivltests/sv_locator_fixed_nonintegral.v`
  (new, positive), `sv_array_find_last_fixed_base.v` (renamed/rewritten
  from the former `..._fail.v` negative test, now a positive test),
  `sv_array_find_last_fixed_shape_fail.v` (rewritten to drop the now-fixed
  case, keeping only the still-correct multidim rejection).
- **Validation:** see the combined L36-L40 validation note at the end of
  this run of entries.
- **Evidence:** `evidence/campaign-20260908/l36/`.

### L37 — Bit-stream cast to an unpacked struct crashed the compiler

- **Status:** CLOSED 2026-09-11. Found while auditing the "Casts" DD046
  row for the same "loud diagnostic on legal input" question that
  produced L36 -- this one turned out worse: not a wrong rejection, an
  outright crash.
- **Symptom:** `s_t'(v)` (an explicit bit-stream cast of a packed vector to
  an unpacked-struct type, legal per IEEE 1800-2017/2023 6.24.3) printed a
  warning and then crashed: `Assertion failed: (net), function
  ivl_expr_value, file t-dll-api.cc, line 1059`.
- **Root cause:** `PECastType::elaborate_expr`'s final fallback for a
  non-packed cast target unconditionally did `return sub;`, handing back a
  vector-shaped expression where downstream codegen (`t-dll-api.cc`'s
  `ivl_expr_value`) expects a struct-shaped one; the mismatch produced a
  null child expression that the codegen's `assert(net)` caught as a
  crash rather than a clean diagnostic.
- **Fix:** Per advisor review, full bit-stream-casting support (general
  packed<->unpacked/struct/class conversion per 6.24.3) is a feature, not
  a fallback fix, and was explicitly scoped out. Instead, the crash-prone
  `return sub;` for a non-packed target now reports `sorry: bit-stream
  cast to '<type>' is not yet implemented (IEEE 1800-2017/2023 6.24.3)`
  and fails elaboration cleanly -- converting an unbounded crash into a
  bounded, honest "not yet implemented" the same way every other
  feature-sized gap in this codebase is represented.
- **Scope:** Non-packed-target bit-stream casts only. Packed-target casts
  (the already-correct, already-common case -- e.g. casting a struct or
  array to a packed vector) are untouched and verified unaffected.
- **Permanent regression:** `ivtest/ivltests/sv_bitstream_cast_unpacked_struct_fail.v`
  (new, `CE`, the crash -> clean-sorry conversion) and
  `sv_bitstream_cast_packed_struct.v` (new, positive, confirms the
  packed-target path is unaffected).
- **Evidence:** `evidence/campaign-20260908/l37/`.

### L38 — `inside {}` silently forced membership to 0 for a queue-valued (non-property, non-plain-signal) expression

- **Status:** CLOSED 2026-09-11.
- **Symptom:** `x inside {f()}` where `f()` returns a QUEUE (not a plain
  signal or class property) silently evaluated to `0` regardless of the
  actual contents, with no diagnostic at all.
- **Root cause:** `tgt-vvp/eval_vec4.c`'s inside-operator object-stack
  dispatch arm named both "Queue/darray" in its own comment but its `if`
  condition only tested `ivl_expr_value(arr_arg) == IVL_VT_DARRAY`, never
  `IVL_VT_QUEUE` -- a straightforward missing-enum-value oversight, not a
  design gap (the plain-signal and class-property paths, and the DARRAY
  case of this exact arm, already worked correctly).
- **Fix:** Added the missing `|| ivl_expr_value(arr_arg) == IVL_VT_QUEUE`
  to the existing condition.
- **Permanent regression:** `ivtest/ivltests/sv_inside_queue_expr.v` (new,
  positive: function-returning-queue and function-returning-darray in
  `inside{}`).
- **Evidence:** `evidence/campaign-20260908/l38/`.

### L39 — Chained container-index then string byte-select on a class property rejected as unsupported

- **Status:** CLOSED 2026-09-11.
- **Symptom:** `obj.q[0][1]` where `obj.q` is a class-property `string
  q[$]` (a queue-element select followed by a byte/char select) hit
  `sorry: this index does not select a queue or associative-array
  class-property value`, even though both a bare `string_var[1]` and a
  class-property queue-of-queues `obj.q[0][0]` already worked
  independently via the identical `NetESelect` shape.
- **Root cause:** `apply_trailing_container_indices_` (the shared loop
  walking chained bracket-indices on a class-property container
  expression) dispatched only on `netvector_t` (packed select) and
  `netarray_t` (container element select) for `cur_type`; a `netstring_t`
  intermediate type (the queue's element, after the first index) fell
  through to the generic "sorry" reject with no string-select branch.
- **Fix:** Added a `netstring_t` branch performing a plain string
  byte-select via `NetESelect(cur_expr, index_expr, 8)`, reusing the
  existing `elab_assoc_index` helper for index elaboration -- mirroring
  the plain-string-select code path already used elsewhere.
- **Permanent regression:** `ivtest/ivltests/sv_property_queue_string_charsel.v`
  (new, positive).
- **Evidence:** `evidence/campaign-20260908/l39/`.

### L40 — A class-handle value read through a specialized parameterized class's own type parameter silently degraded to an empty string with zero diagnostic

- **Status:** CLOSED 2026-09-11. First attempt REVERTED the same session
  when the UVM gate caught a real regression; root-caused and re-fixed,
  correctly this time, per explicit user direction to fix it completely
  rather than leave it open. Found while auditing the STRING/CLASS
  `netmisc.cc` stub candidates (part of the user-directed "fix the other
  8" sweep) for a genuine unresolved-generic reproducer.
- **Symptom:** `container #(type T=int)` specialized as `container#(obj_c)`
  (a real class type), whose own method does `T val; string s; s = val;`,
  silently produces `s == ""` at runtime with **no diagnostic whatsoever**
  -- worse than the plain module-scope case (already a hard error per an
  earlier fix in this same function), since ordinary UVM/OOP code lives
  almost entirely inside class methods.
- **Root cause (confirmed):** `netmisc.cc`'s class-handle-rvalue guard
  computes `class_rval_degrade_ok = in_class_scope || cast_type==IVL_VT_LOGIC
  || <PENull>`, where `in_class_scope` is a COARSE check -- true for any
  code textually inside ANY class body. The guard's own comment documents
  exactly two intended exemptions: (a) a genuinely dead
  generic-template-seed elaboration pass (IEEE 1800-2017/2023 8.25: "a
  generic class is not a type"), for which the sibling `is_class_new`
  exemption already uses the PRECISE `in_unspecialized_param_class` check;
  and (b) a forward-referenced class name that collapses to implicit
  4-state LOGIC (`cast_type==IVL_VT_LOGIC`, the "UVM printer globals"
  case). `class_rval_degrade_ok` uses the coarse `in_class_scope` where it
  could use the precise (a) check, so a real specialization's
  class-handle-to-string assignment silently degrades instead of
  hard-erroring.
- **First attempt, REVERTED:** narrowed `class_rval_degrade_ok` (and the
  paired warning-suppression condition) to use `in_unspecialized_param_class`
  instead of `in_class_scope` wholesale, mirroring `is_class_new`. This
  correctly hard-errored the real-specialization reducer AND correctly
  stayed silent for a class whose own declared default type parameter is
  itself a class (`container #(type T = base_c)`, specialized everywhere
  in the design only with `int`) -- both directions of the predicate this
  fix targets were verified. **But the six-gate sweep's UVM/ivtest run
  caught a THIRD, undocumented scenario the coarse `in_class_scope` was
  also covering**: `uvm_vreg::allocate()`'s `this.mem = mam.get_memory();`
  -- an ordinary, ZERO-generics, class-to-class (`uvm_mem`-to-`uvm_mem`)
  property assignment inside a plain (non-parameterized) class method --
  newly hard-errored with "class handle cannot be assigned to a non-class
  target" after the wholesale narrowing.
- **Tracing the third scenario:** temporary `IVL_L40_DEBUG`-gated
  instrumentation at the guard printed `cast_type` and the enclosing scope
  for every entry; against `sv_package_lazy_subroutine_scope.v -uvm` (an
  existing permanent ivtest case that happens to compile enough of the UVM
  register model to reach `uvm_vreg.svh:736`), it showed `cast_type=3`
  (`IVL_VT_BOOL`) for that exact assignment -- NOT `IVL_VT_LOGIC`. Reading
  `uvm_vreg.svh`/`uvm_mem_mam.svh` confirmed why: they forward-declare each
  other (`typedef class uvm_mem_mam;` / `typedef class uvm_mem;`), and that
  circular forward reference collapses `this.mem`'s target to a 2-state
  placeholder -- the SAME "forward-referenced class collapses to an
  implicit type" mechanism case (b) already documents for LOGIC, just
  landing on the 2-state atom instead of the 4-state one this time.
  `cast_type == IVL_VT_LOGIC` doesn't match `IVL_VT_BOOL`, so only the
  broad `in_class_scope` was covering this variant.
- **Fix (correct, landed):** rather than widen the `cast_type` checks
  (which would touch every class-scope degrade, not just the one L40
  targets) or reintroduce the wholesale `in_unspecialized_param_class`
  swap, added a narrow, additional carve-out: `in_real_specialized_param_class`
  (true exactly when the enclosing scope is a parameterized class AND a
  REAL, non-seed-derived specialization -- the logical complement of the
  existing `in_unspecialized_param_class` within a parameterized class's
  body). `class_rval_degrade_ok` becomes `(in_class_scope &&
  !in_real_specialized_param_class) || cast_type==IVL_VT_LOGIC ||
  <PENull>` -- `in_class_scope`'s broad permissiveness is otherwise
  completely untouched (including the BOOL forward-ref collapse case),
  and only the one case L40 targets (a real specialization) is carved out
  to hard-error. Verified all three: the real-specialization reducer now
  hard-errors, the dead-template-seed reducer still compiles silently, and
  `uvm_vreg.svh:736` (via `sv_package_lazy_subroutine_scope.v -uvm`)
  compiles clean again.
- **A separate, pre-existing, unrelated defect surfaced while building the
  "must stay silent" reducer, not part of this fix:** reading an ordinary
  INTEGRAL class property (no generics involved at all) back as a string
  from inside its own class method -- `class c; int val; function string
  f(); string s; s = val; return s; endfunction endclass` -- warns
  `class_property_t::get_string on unsupported property type ...
  returning empty string` and produces `""`, on a plain non-parameterized
  class with no relation to L40's guard (confirmed: this path is
  `IVL_VT_LOGIC`, never enters the `IVL_VT_CLASS` guard at all). Recorded
  in `DISCOVERED_DEBT.md` as a fresh, unfixed, out-of-scope finding
  (anchor `vvp/class_type.cc:536`).
- **Permanent regression:** `ivtest/ivltests/sv_class_handle_string_specialized_fail.v`
  (new, `CE`, the real-specialization hard error) and
  `sv_class_handle_string_seed_ok.v` (new, positive, the dead-seed
  exemption). The forward-ref-collapse (BOOL) case is guarded by the
  pre-existing `sv_package_lazy_subroutine_scope.v -uvm` (already in
  `regress-sv.list`) rather than a new dedicated reducer -- two attempts
  at a minimal, non-UVM standalone reproduction of the circular
  forward-declaration collapse did not reproduce it (kept as negative
  evidence in `evidence/campaign-20260908/l40/l40_uvmvreg_min.sv` and
  `l40_forward_ref_min.sv`); the real UVM register-model source is the
  only confirmed trigger found.
- **Evidence:** `evidence/campaign-20260908/l40/`.

### L36-L40 combined validation

- **Validation:** all six required gates run together over the combined
  L36+L37+L38+L39+L40 changeset (elab_expr.cc, tgt-vvp/eval_vec4.c,
  netmisc.cc, plus 9 new permanent ivtest cases): integrated ivtest,
  JSON/VVP, UVM, NFA dual-run, UVM release matrix, frontend (alone/last).
  Final counts: integrated ivtest 4989/4984/0F/2NI/3EF, JSON/VVP 1873/0,
  UVM 357/0/0, NFA dual-run 58/58, UVM release matrix 15/15 SMOKE_PASS
  (all 15, including 1.0p1 -- restored by L37's follow-up class-cast
  fix), frontend all S1-S12. Merged as PR #277 (2026-09-12), all 6 CI
  platforms green (macOS, Ubuntu 22.04/24.04, MINGW64, UCRT64, CLANG64).
  See `evidence/campaign-20260908/l36/`...`l40/` for reducers and
  `installed-frozen-sha256.json` for the post-install binary hash diff.

### L41 — Class-body `import` statement misdiagnosed on error recovery

- **Status:** CLOSED 2026-09-13. Found while rebaselining OpenTitan after
  PR #277 -- re-verifying the original goal file's "parameterized-class
  inheritance blocking `ac_range_check_env_cov`" priority item against
  fresh census data.
- **Symptom:** an `import pkg::*;` statement written directly inside a
  class body (illegal per IEEE 1800-2017/2023 A.1.8/A.2.1.3, footnote:
  "It shall be illegal to have an import statement directly within a
  class scope" -- confirmed independently by Slang, `error: package
  import not allowed in class declaration`) was already correctly
  rejected by Icarus, but only via bison's generic syntax-error recovery
  on the bare `import` keyword: a bare `syntax error` + `Invalid class
  item.`, after which recovery resynchronizes mid-declaration and emits
  several misleading follow-on errors (e.g. `<pkg> doesn't name a type`)
  that blame later, unrelated lines instead of naming the actual illegal
  construct. This produced a real misdiagnosis in the field: the original
  2026-08-26 OpenTitan baseline session mischaracterized this exact
  construct in `ac_range_check_env_cov.sv` as "parameterized-class
  inheritance" being unimplemented -- a defect that never existed. (This
  specific misdiagnosis was already caught and corrected by an earlier
  session, recorded as memory `class-body-import-is-illegal`; L41 is the
  follow-through fix for the diagnostic-quality half of that finding.)
- **Root cause:** `parse.y`'s `class_item` production has no
  `package_import_declaration` alternative, so a bare `K_import` directly
  in a class body cannot be matched by any `class_item` alternative and
  falls straight to the generic `error ';'` / `error ';'` (with an
  `IDENTIFIER error ';'` variant that produces the misleading "doesn't
  name a type" text) recovery rules at the bottom of that production.
- **Fix:** Added `package_import_declaration` as a `class_item`
  alternative (parse.y) so the construct parses successfully and reaches
  `pform_package_import()` (pform_package.cc) instead of derailing.
  `pform_package_import()` now checks `dynamic_cast<const PClass*>(pform_peek_scope())`
  and, when the immediate enclosing scope IS the class body itself (not a
  method's own function/task scope nested inside it -- `PClass` is a
  `LexicalScope` via `PScopeExtra`/`PScope`; a method's scope is a
  different, non-`PClass` `LexicalScope` even though its parent is one),
  reports one focused, citation-bearing error and refuses the import
  (does not add its symbols to the scope) instead of proceeding. Verified
  zero new bison grammar conflicts (563 shift/reduce, 1122 reduce/reduce,
  identical totals before and after this change).
- **Verified against real OpenTitan source:** `ac_range_check_env_cov.sv:12`
  hard-error-count dropped from 72 to 69 (line 12 is now the single clean
  diagnostic; the line-19 cascade was already present in the ORIGINAL,
  unfixed trace too -- confirmed separate and pre-existing, not something
  this fix left unaddressed). `pwrmgr_base_vseq.sv:21` (3 tops) dropped
  from 4 to 3 hard errors each (now one clean diagnostic; the remaining 2
  errors are a wholly unrelated duplicate-module-declaration issue in a
  different file, `pwrmgr_csr_assert_fpv.sv`).
- **An unverified claim caught and corrected in-flight:** the first draft
  of this fix's comments asserted "an import inside a method body is
  unaffected, still legal" without testing it. It doesn't hold: `import
  pkg::*;` written ANYWHERE inside an ordinary (non-class) function or
  task body already fails with a plain syntax error in Icarus today,
  completely independent of this fix or of classes at all. Corrected the
  comments before closing; recorded as `DISCOVERED_DEBT.md` DD-018, a
  separate, unfixed, untriaged finding -- not investigated further here.
- **Permanent regression:** `ivtest/ivltests/sv_class_body_import_fail.v`
  (new, `CE`).
- **Validation:** integrated ivtest 4990/4985/0F/2NI/3EF, JSON/VVP 1873/0,
  UVM 357/0/0, NFA dual-run 58/58, UVM release matrix 15/15 SMOKE_PASS,
  frontend all S1-S12.
- **Evidence:** `evidence/campaign-20260908/l41/`.

### L42 — Integral class-property read/written as a string used the wrong conversion (or none)

- **Status:** CLOSED 2026-09-13. Found incidentally while building an
  L40 "must stay silent" reducer, deferred as feature-sized at the time;
  picked up as the next Phase-B implementation-campaign item.
- **Symptom:** reading an ordinary integral class property (`int`, `byte`,
  `shortint`, `longint`, `bit [N:0]`, `logic [N:0]`) back as a `string`
  from inside its own class method -- `class c; int val; function string
  f(); string s; s = val; return s; endfunction endclass` -- warned
  `class_property_t::get_string on unsupported property type ...
  returning empty string` and produced `""`, instead of the correct IEEE
  1800-2017/2023 6.16 packed-byte value (`42` -> `"*"`, the same
  conversion a plain, non-property `int` variable already got correctly:
  confirmed `int x; string s; x=42; s=x;` already produced `"*"` before
  this fix, len 1, leading zero bytes dropped). Writing a string INTO
  such a property (`obj.val = "*";`) had the identical gap in reverse.
- **Root cause:** `property_atom<T>` (the class handling `int`/`byte`/
  `shortint`/`longint` properties) and `property_logic` (4-state vector
  properties) never overrode `class_property_t::get_string`/
  `set_string`; every call fell to the base class's generic "unsupported"
  stub (warn once, return `""` / ignore the write). This was NOT a
  decimal/itoa-formatting gap as first hypothesized while triaging --
  confirmed against the LRM directly (6.16: "values of integral type can
  be assigned to a string variable... if the size of the integral value
  is not a multiple of 8 bits, [it] shall be zero-filled on the left") --
  it is a missing BYTE-PACKING conversion, identical in shape to the one
  a plain (non-property) vec4-typed variable's existing `%pushv/str` vvp
  opcode (`of_PUSHV_STR`, vthread.cc) already performs correctly.
- **Fix:** Extracted `of_PUSHV_STR`'s conversion (8-bit big-endian bytes,
  any all-zero byte dropped -- not just leading ones, per 6.16's "assigning
  the value 0 to a string character shall be ignored") into a shared
  `vector4_to_packed_string()` (`vvp/vvp_net.h`/`vvp_net.cc`), and
  refactored `of_PUSHV_STR` itself to call it (dedup, zero behavior
  change for the existing plain-variable path). Added `get_string`/
  `set_string` overrides to `property_atom<T>` and `property_logic`
  (`vvp/class_type.cc`) built on this shared helper for reads, and a new
  shared `pack_string_into_vec4_()` helper (right-justify, zero-fill or
  truncate on the left, mirroring `%cast/vec4/str`'s `of_CAST_VEC4_STR`
  semantics) for writes.
- **Scope:** `property_bit` (2-state `bit [N:0]` vectors) needed no
  change -- confirmed already correct before this fix (`obj.bit_prop`
  read as a string already worked), apparently materializing through the
  same path as `property_atom<T>` for common widths. `property_string`
  (actual `string`-typed properties) was already correct and untouched.
  X/Z bits in a `logic`-typed property contribute 0 to a packed byte,
  matching how the pre-existing plain-variable path already treats them
  (verified, no crash, no special-casing needed).
- **Permanent regression:**
  `ivtest/ivltests/sv_class_property_string_conversion.v` (new,
  `normal`) -- covers `int`/`byte`/`bit`/`logic` reads (including the
  zero-value-collapses-to-empty-string and X-bit cases) and `int`/
  `shortint` writes (including left-truncation for an over-length
  string).
- **Validation:** integrated ivtest 4991/4986/0F/2NI/3EF, JSON/VVP
  1873/0, UVM 357/0/0, NFA dual-run 58/58, UVM release matrix 15/15
  SMOKE_PASS, frontend all S1-S12.
- **Evidence:** `evidence/campaign-20260908/l42/`.


### L43 — Package imports after local declarations

- **State:** IMPLEMENTED; focused validation passes. Full regression
  qualification is deferred to the approximately ten-feature batch boundary
  under the user's 2026-09-14 validation cadence.
- **Origin:** DD-018, corrected after inspecting its invalid return-type reducer.
- **Expected:** legal imports in procedural declaration prefixes resolve local
  types and values without generating an executable operation. Imports after
  statements and direct conditional/loop imports remain rejected.
- **Root cause:** an existing import-as-statement production created `PNoop`,
  which fell into `Statement::elaborate`'s internal-error path.
- **Scope:** parser routing to declaration-capable lists, attribute handling,
  preserving explicit null statements for placement checks, focused tests.
- **Authority:** IEEE 1800-2017 and 1800-2023 A.2.1.3, A.2.6-A.2.8, 26.3.
- **Evidence:** `evidence/dd018-assessment/`; permanent
  `sv_procedural_package_import` tests. Both editions failed with six internal
  errors before the patch. See the current ACTIVE_WORK record for final gates.

### L44 — Compound stores to disjoint mixed-driver packed elements

- **State:** IMPLEMENTED; focused validation passes, batch regression pending.
- **Origin:** DD-019, unmodified OpenTitan PRINCE concat width assertion.
- **Fix:** compound partial stores use the existing unresolved-net partial-force
  route shared with ordinary assignments. No runtime assertion is relaxed.
- **Authority:** IEEE 1800-2017 and 1800-2023 6.5 and 11.4.1.
- **Validation:** original N=2/4/5/6 reducer passes in both editions; permanent
  tests verify two successive input values, preservation of continuously driven
  elements, ordinary dynamic index single evaluation and unknown-index no-write.
  Explicit wire procedural assignment remains rejected. Legacy 2/2, JSON 4/4.
- **Limit:** dynamic subparts of mixed-driver elements remain DD-021; full
  application qualification and batch-wide regression are not claimed.

### L45 — Reject unresolved bare task enables

- **State:** IMPLEMENTED; focused legacy 2/2, JSON 4/4 and real UVM smoke pass.
- **Origin:** DD-020: `missing_task()` compiled and execution continued after
  a warning. It now reaches the existing unknown-task elaboration error.
- **Authority:** IEEE 1800-2017/2023 13.3 and 23.8.1.
- **Scope:** bare unresolved calls after normal lookup. Qualified/class fallback
  gaps remain open. Forward, upward, compilation-unit and implicit class task
  calls must continue to work. Broad regression follows the batch cadence.

### L46 — Preserve packed-element bounds for indexed reads

- **State:** IMPLEMENTED; legacy 1/1, JSON 2/2, null/synthesis and negative
  checks pass both editions. DD-022 writes remain open.
- **Authority:** IEEE 1800-2017/2023 11.5.1.
- **Scope:** final indexed `+:`/`-:` reads after valid fixed packed prefixes
  retain a bounded carrier through nested select expressions. Out-of-range bits
  must read X without exposing neighboring packed elements. Shared runtime
  part-select conversion must preserve wide index magnitude and signedness;
  clipping must avoid overflow and retain in-range bits with X padding.
- **Limits:** writes, invalid earlier prefixes and dynamic-prefix elaboration
  remain open. DD-021 mixed-driver restrictions are unchanged.

### L47 — Wide part-select values through VPI arguments

- **State:** IMPLEMENTED; focused legacy 3/3, JSON 6/6, direct VPI checks
  in both editions, and null/synthesis checks pass.
- **Origin:** DD-023: formatting a wide out-of-range select returned aliased
  bits. The corresponding monitor case also crashed.
- **Fix:** preserve constant normalization and descriptor width; use the shared
  wide-index conversion for dynamic VPI bases. Out-of-range reads return X and
  writes have no effect; callbacks compare the actual selected value.
- **Scope:** value semantics and callbacks triggered by parent value changes.
  Full VPI metadata and index-only callback triggers are not qualified here.
- **Authority:** IEEE 1800-2017/2023 11.5.1 and VPI value/callback semantics.
  Range tags are handle relations; the existing integer range-query extension
  is not claimed as implementation of those standard relations.

### L64 — Function-valued constraint evaluation and argument ordering

- **State:** QUALIFIED for the evidenced subset; integrated locally in4bc02c51b /0c6d5994a.
- **Active ID:** CONSTRAINT-FUNCTION-PRESOLVE.
- **Root cause:** legal function-valued constraints were ignored or lacked typed
  per-object result transport and staged active-argument dependencies.
- **Authority:** IEEE 1800-2017 and 1800-2023 18.5.11, with array-method,
  constraint-guard, soft-constraint and null-handle rules for affected operands.
- **Scope:** pure legal input/const-ref calls, typed result capture, qualified
  and virtual dispatch, active scalar/member/element/size argument stages, one
  rollback transaction, static overlays, selected fixed-array operands, and
  conditional-member validity. No-argument body reads do not invent priority.
- **Validation:** 250 paired focused outcomes; 206 permanent cases in each
  harness; legacy5253 total/5248 pass/0 fail/2 NI/3 EF; JSON2189/0; real-DPI
  UVM357/0/0; NFA58/0; release15 smoke passes; frontend12 scenarios; make check.
  All seven gates used identical frozen artifacts and749 source/test/docs files.
- **Limits:** dynamic-foreach per-iteration function capture, broader inline
  wide-value transport, active returned-member aliases, selected indexed
  conditional handles and multi-prefix reductions remain gaps. This does not
  qualify all Clause18, IEEE1800.2, or whole unmodified OpenTitan/Caliptra DV.
- **Evidence:** session_logs/2026-09-14_constraint_function_presolve.md and
  its companion _qualification.json; failed earlier batches remain preserved.

### L65 — Multiple prefix indices on constrained fixed-array reductions

- **State:** IMPLEMENTED; focused tests pass; local batch qualified (see L65–L74 record).
- **Active ID:** CONSTRAINT-MULTIPREFIX-REDUCTION.
- **Authority:** IEEE1800-2017 7.12.3/18.5.8.2; IEEE1800-2023 7.12.3/18.5.7.2.
- **Reproducer:** evidence/constraint-multidim-reductions-l65/selected-row.sv
  is rejected in both editions on qualified localmain9ad50ce52.
- **Root cause:** reduction admission permits at most one selected prefix,
  and canonicalization only processes that first dimension.
- **Scope:** multiple constant prefix indices leaving one fixed integral
  unpacked dimension, all five reductions, normal with-expression semantics,
  exact active/state element identity, bounds and transactional rollback.
  Runtime-selected prefixes are a separate solver-expression capability.

L65 validation: root2/2, independent4/4 positive and2 paired negative cases, permanent8/8 each harness, neighbors6/6 each. Stable artifacts. All five reductions preserve exact selected row, width/sign, index(), modes and rollback. User cadence defers full suite to about ten features.

### L66 — Typed array return element storage

- **State:** IMPLEMENTED, focused validation; local batch qualified (see L65–L74 record).
- **Origin:** DD-031, scalar return paths intercepted real/string array elements.
- **Authority:** IEEE1800-2017/2023 13.4.1.
- **Scope:** real/string element reads/writes and real compound updates reuse emitted return-array storage, including automatic recursion, exact index evaluation and result copies.
- **Validation:** Focused checks pass; results and revision scope are owned by the evidence record below.
- **Evidence:** session_logs/2026-09-14_typed_array_return_elements.md.

### L67 — Packed-select expression increment/decrement

- **State:** IMPLEMENTED for the evidenced subset; local batch qualified (see L65–L74 record).
- **Origin:** DD-030 selected-width runtime aborts and context-width rejection.
- **Scope:** scalar packed-signal selections and scalar function-return storage; fixed-array receivers are addressed by L68; scalar property receivers are addressed by L69; fixed-array property receivers are addressed by L70; scalar nested packed carriers are addressed by L71; nested array/property carriers remain open.
- **Evidence:** [L67 session](session_logs/2026-09-14_packed_select_increment.md).
- **Standards disposition:** [Clause11 refinement](matrices/ieee1800_2017_clause_matrix.md#l67--packed-select-incrementdecrement-expressions-1136-1142).

### L68 — Packed-select expression updates within fixed-array words

- **State:** IMPLEMENTED for the focused subset; local batch qualified (see L65–L74 record).
- **Origin:** L67 retained a focused rejection for selected fixed-array words.
- **Scope:** fixed-array word and packed-index capture, bounds, result widths, automatic/return storage. Scalar class-property receivers are addressed by L69; fixed-array property receivers are addressed by L70; bounded inner-carrier work remains open.
- **Evidence:** [L68 session](session_logs/2026-09-14_array_packed_increment.md).

### L69 — Scalar class-property packed-select increment/decrement

- **State:** IMPLEMENTED for the focused subset; local batch qualified (see L65–L74 record).
- **Scope:** scalar integral property bit/part pre/post updates, captured receiver,
  bounds, contexts, inheritance/nesting, and readonly diagnostics.
- **Follow-up:** selected fixed unpacked-array properties are addressed by L70; dynamic container and inner-carrier work remains separate.
- **Evidence:** [L69 session](session_logs/2026-09-14_class_packed_increment.md).

### L70 — Fixed-array class-property word packed-select updates

- **State:** IMPLEMENTED for the focused subset; local batch qualified (see L65–L74 record).
- **Scope:** integral fixed-array property words, atomic selected update,
  multidimensional indices, bounds, contexts, and const diagnostics.
- **Evidence:** [L70 session](session_logs/2026-09-14_class_array_packed_increment.md).

### L72 — Constant-function string character evaluation

- **State:** IMPLEMENTED for the focused subset; local batch qualified (see L65–L74 record).
- **Origin:** DD026 re-assessed on L70; string arguments collapsed to one bit.
- **Scope:** preserve argument/local string values and evaluate typed character reads.
- **Evidence:** [L72 session](session_logs/2026-09-14_constant_string_character.md).

### L71 — Nested scalar packed increment/decrement

- **State:** IMPLEMENTED for the focused scalar packed-signal and function-return scope; local batch qualified (see L65–L74 record).
- **Remaining:** Nested array/property roots and the earlier-aborting intermediate-part-select probe require independent assessment.
- **Evidence:** [L71 session](session_logs/2026-09-14_nested_packed_increment.md).

### L73 — Constant-function string character writes

- **State:** IMPLEMENTED for focused local character writes and constant-function locality diagnostics; local batch qualified (see L65–L74 record).
- **Remaining:** Explicit package qualification in character lvalues is separate; runtime compound lowering is L74.
- **Evidence:** [L73 session](session_logs/2026-09-14_constant_string_character_write.md).

### L74 — Runtime scalar string character compound assignments

- **State:** IMPLEMENTED for focused scalar/local/ref character updates; local batch qualified (see L65–L74 record).
- **Remaining:** Whole-string compound operations, array receivers and function-return character storage are separate gaps.
- **Evidence:** [L74 session](session_logs/2026-09-14_runtime_string_character_compound.md).

### L65–L74 local qualification checkpoint

The [joint qualification record](session_logs/2026-09-14_compiler_batch_l65_l74_qualification.json) supersedes pending broad-test notes for the recorded candidate. The individual scope boundaries remain in force.

### L75 — String-function-return character stores

- **State:** IMPLEMENTED for scalar return characters; focused checks pass, broad batch pending.
- **Area / edition:** Runtime return storage; IEEE 1800-2017/2023 6.16, 11.4.1, 13.4.1.
- **Evidence:** `evidence/parallel-batch-l71-l72/l75-assessment/`: both editions leave ABC unchanged for plain/compound character writes to a function return. Plain selectors execute once; compound selectors are skipped.
- **Closure:** Plain and compound byte stores, signed arithmetic, index/RHS capture, bounds/defaults/zero-byte behavior and automatic/recursive return-slot isolation.
- **Last verified revision:** `e25971651` frozen candidate.

- **Focused implementation evidence:** [L75 session](session_logs/2026-09-14_string_return_character.md).

### L76 — Constant-function string case conversion

- **State:** LOCALLY QUALIFIED for the recorded toupper/tolower scope; see joint qualification below.
- **Area / edition:** Constant evaluator; IEEE 1800-2017/2023 6.16.4, 6.16.5, 13.4.3.
- **Evidence:** `evidence/next-constant-assessment/ASSESSMENT.md`: both editions reject the internal method during constant evaluation and then assert; runtime control passes.
- **Closure:** Correct byte conversion without receiver mutation, empty/high-byte/local/argument cases, runtime parity and focused invalid-call diagnostics.
- **Last verified revision:** `e25971651` frozen candidate.

- **Focused implementation evidence:** [L76 session](session_logs/2026-09-14_constant_string_case_conversion.md).

### L77 — Runtime string-character increment/decrement expressions

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l77-baseline.json`: both editions abort loading string storage through the vector loader.
- **Scope:** Scalar string variables and scalar string returns, pre/post byte update/result semantics, bounds and index capture.
- **Standards:** IEEE 1800-2017/2023 6.16, 11.4.2.

- **Focused implementation evidence:** [L77 session](session_logs/2026-09-14_string_character_increment.md).

### L78 — Constant-function string comparisons

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l78-baseline.json`: both editions reject constant compare/icompare evaluation.
- **Scope:** Case-sensitive and insensitive comparison signs, byte ordering, operand preservation and diagnostics.
- **Standards:** IEEE 1800-2017/2023 6.16.6, 6.16.7, 13.4.3.

- **Focused implementation evidence:** [L78 session](session_logs/2026-09-14_constant_string_comparison.md).

### L79 — Fixed-array string-character stores

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l79-array-character-baseline.json`: both editions abort in target assignment lowering.
- **Scope:** Plain blocking byte writes to fixed unpacked-array string words; selector capture and bounds.
- **Standards:** IEEE 1800-2017/2023 6.16, 6.16.2, 7.4, 10.4.1.

- **Focused implementation evidence:** [L79 session](session_logs/2026-09-14_array_string_character_store.md).

### L80 — Constant-function substr

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l80-constant-substr-baseline.json`: both editions reject method evaluation then assert.
- **Scope:** Inclusive substr evaluation with int indices, invalid-range empty results and receiver preservation.
- **Standards:** IEEE 1800-2017/2023 6.16.8, 13.4.3.

- **Focused implementation evidence:** [L80 session](session_logs/2026-09-14_constant_string_substr.md).

### L81 — Fixed-array string-character compound stores

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l81-array-character-compound-baseline.json`: both editions skip the byte assignment and its side effects.
- **Scope:** Legal integral character compound operations on fixed string-array words; whole-string arithmetic is not legal scope.
- **Standards:** IEEE 1800-2017/2023 6.16, 11.4.1.

- **Focused implementation evidence:** [L81 session](session_logs/2026-09-14_array_string_character_compound.md).

### L82 — Constant string-to-integer conversion family

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l82-constant-string-integer-baseline.json`: both editions reject all four conversion methods in constant functions.
- **Scope:** atoi/atohex/atooct/atobin with radix digits, underscore scanning, termination and 32-bit integer results.
- **Standards:** IEEE 1800-2017/2023 6.16.9, 13.4.3.

- **Focused implementation evidence:** [L82 session](session_logs/2026-09-14_constant_string_integer.md).

### L83 — Fixed-array string-character increment/decrement

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l83-array-character-incdec-baseline.json`: both editions route string storage through the vector-array loader and fail runtime semantics.
- **Scope:** Pre/post signed character update/results on fixed string arrays, excluding array returns.
- **Standards:** IEEE 1800-2017/2023 6.16, 11.4.2.

- **Focused implementation evidence:** [L83 session](session_logs/2026-09-14_array_string_character_increment.md).

### L84 — Constant-function string-character increment/decrement

- **State:** LOCALLY QUALIFIED for the recorded subset; see joint qualification below.
- **Evidence:** `evidence/batch-20260914-after-l74/l84-constant-character-incdec-baseline.json`: both editions fail selected-character unary evaluation and assert downstream.
- **Scope:** Scalar local/argument/return string character pre/post byte updates and results in constant functions.
- **Standards:** IEEE 1800-2017/2023 6.16, 11.4.2, 13.4.3.

- **Focused implementation evidence:** [L84 session](session_logs/2026-09-14_constant_string_character_increment.md).

### L75–L84 local qualification checkpoint

The [joint qualification record](session_logs/2026-09-14_compiler_batch_l75_l84_qualification.json) supersedes pending broad-gate notes for these bounded subsets. Remote CI and complete application/edition support remain separate obligations.

### L85 — Ordered distributions in joint canonical scalar solves

- **Parent:** Z01.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/next-batch-after-l84/baseline.json`; both editions reject a legal ordered weighted joint graph at runtime.
- **Scope:** Existing supported hard distribution family combined with bounded canonical scalar solve-before stages; correct stage marginals and conditional fibers.
- **Standards:** 2017 18.5.4/18.5.9/18.5.10; 2023 18.5.3/18.5.8/18.5.9.

- **Implementation evidence:** [L85 session](session_logs/2026-09-14_joint_ordered_distribution.md).

### L86 — Bounded delay-range antecedents in multiclock implications

- **Parent:** S01 residual scope.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/next-batch-after-l84/baseline.json`; both editions reject the finite two-endpoint antecedent.
- **Scope:** Finite constant delay windows with all matching endpoints, correct clock handoff and preserved attempt/action semantics.
- **Standards:** IEEE 1800-2017/2023 16.6/16.7, 16.12.7, 16.13 and 16.14.1/.3.

L86 architecture refinement: scalar cross-clock request counts cannot retain the
parent of multiple antecedent matches. The coordinator authorized dynamic
parent-tagged transport and per-attempt verdict aggregation in ACTIVE_WORK.
The paired action-count reducer is preserved at
`evidence/next-batch-after-l84/parent-actions-baseline.json`; no candidate
qualification is established by this scope refinement.

L86 [implementation and validation](session_logs/2026-09-15_multiclock_bounded_antecedents.md) now provide the bounded delay-window foundation. S02 repetition remains separate.

### L87 — Joint selected integral array-element ordering

- **Parent:** Z01.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-selection/baseline.json` at L85; both editions reject selected-element ordering.
- **Scope:** Statically selected fixed-array integral elements with exact ordered stage identity/projection; dynamic ordering and other unsupported families remain separate.
- **Standards:** 2017 18.5.9/18.5.10; 2023 18.5.8/18.5.9.

- **L87 implementation evidence:** [Focused session](session_logs/2026-09-14_joint_element_ordering.md).

### L88 — Joint dynamic-array selected-element ordering

- **Parent:** Z01.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-dynamic-assessment/baseline.json`; both editions drop the ordering and produce685 first-element ones in1024 calls, violating the uniform first-stage oracle.
- **Scope:** Constant selected integral dynamic-array elements with one proved size before element solving; preserve resize, exact ordering, bounds and transaction invariants. Other container/order families remain separate.

- **L88 implementation evidence:** [Focused session](session_logs/2026-09-15_joint_dynamic_element_ordering.md).

### L89 — Joint queue selected-element ordering

- **Parent:** Z01.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-queue-assessment/after-l88-baseline.json`; paired queue ordering is dropped and violates the first-stage probability oracle.
- **Scope:** Constant selected integral queue elements with one proved size, bounded queue limits, retained-element modes and exact joint ordering. Other queue/order families remain separate.

- **L89 evidence:** [Focused session](session_logs/2026-09-15_joint_queue_element_ordering.md).

### L90 — Packed selects on class-container enum elements

- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-packed-assessment/typed-baseline.json`; paired enum element reads reject, while equivalent bit/signed/logic controls pass.
- **Scope:** Existing read and lvalue packed-select paths for class dynamic-array/queue enum elements, preserving nominal whole-enum typing and existing partial-write semantics.

- **L90 evidence:** [Focused session](session_logs/2026-09-15_enum_container_packed_selects.md).

### L91 — Finite Boolean consecutive repetition in multiclock antecedents

- **Parent:** S02.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-repeat-assessment/baseline.json`; paired rejection of `a[*1:2]` despite the L86 delay-window foundation.
- **Scope:** Finite Boolean repetition with legal empty-match composition, endpoint/parent semantics, existing clock handoff and cancellation. Grouped and unbounded repetition remain distinct obligations.

- **L91 evidence:** [Focused session](session_logs/2026-09-15_multiclock_boolean_repetition.md).

### L92 — Fixed multiclock assertion control

- **Parent:** DD-032.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/l92-baseline/baseline.json`.
- **Scope:** Gate fresh fixed multiclock attempts under Off/Kill while preserving pending completion, restart and selected-instance behavior; reuse existing control helpers.

- **L92 evidence:** [Focused session](session_logs/2026-09-15_fixed_multiclock_assertion_control.md).

### L93 — Constant-function string formatting silently leaves the receiver unchanged

- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-string-format/baseline.json`; runtime paired control succeeds, constant paired invocation returns the empty string after clean compilation.
- **Scope:** Constant evaluation of the five string numeric-formatting methods; internal task lowering must retain the required function mutation. IEEE 1800-2017/2023 6.16.11–6.16.15 and 13.4.3.

- **L93 evidence:** [Focused session](session_logs/2026-09-15_constant_string_formatting.md).

### L94 — Finite grouped consecutive repetition in multiclock antecedents

- **Parent:** S02.
- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-group-repeat/baseline.json`.
- **Scope:** Preserve and repeat the entire finite grouped Boolean/delay fragment, including legal empty alternatives and parent-level verdicts. Unbounded and general match-action groups remain separate.

- **L94 evidence:** [Focused session](session_logs/2026-09-15_multiclock_grouped_repetition.md).

### L95 — Constant-function putc silently skips mutation and arguments

- **State:** LOCALLY QUALIFIED for the recorded subset; see L85–L95 checkpoint below.
- **Evidence:** `evidence/batch-20260914-after-l84/next-putc-assessment/baseline.json`.
- **Scope:** Scalar local string and function-result character updates, IEEE1800-2017/2023 6.16.2 and13.4.3. Other receiver families remain separate.

- **L95 evidence:** [Focused session](session_logs/2026-09-15_constant_string_putc.md).

### L85–L95 local qualification checkpoint

The [batch record](session_logs/2026-09-15_compiler_batch_l85_l95_qualification.json) qualifies the eleven recorded subsets at `d45ee87ab`, including the [regression corrections](session_logs/2026-09-15_batch_l85_l95_regression_repair.md). Broader clause and application scope remains open.

### L96 — Constant-function non-input formals accepted

- **Area / edition:** Function elaboration / IEEE1800-2017 and2023 13.4.3.
- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Confidence:** REPRODUCED.
- **Evidence:** `evidence/batch-20260914-after-l84/next-const-formals-assessment/baseline.json`; both editions accept prohibited output/inout/ref constant calls.
- **Closure:** Reject prohibited formals in constant evaluation, including nested calls, while preserving input-only constant functions and ordinary runtime writable-formal calls. Paired diagnostics and behavioral controls required.
- **Last verified revision:** `e43ecd536` installed candidate, qualified at `d45ee87ab`.

- **Implementation evidence:** [L96 session](session_logs/2026-09-15_constant_function_formal_legality.md).

### L97 — Nested finite whole-sequence repetition rejected

- **Area / edition:** SVA / IEEE1800-2017 and2023 16.9.2,16.9.2.1,16.12.22,16.13.
- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Confidence:** REPRODUCED.
- **Evidence:** `evidence/batch-20260914-after-l84/next-nested-group-assessment/baseline.json`; both editions reject the nested exact-count endpoint witness.
- **Closure:** Preserve inner/outer copies and endpoints, nested empty composition and parent verdicts within the existing finite construction scope. Keep fixed pipeline and same-clock behavior correct; preserve loud unsupported boundaries.
- **Last verified revision:** `e43ecd536` installed candidate, qualified at `d45ee87ab`.

- **Implementation evidence:** [L97 session](session_logs/2026-09-15_nested_finite_grouped_repetition.md).

### L98 — Generated function accepted in constant evaluation

- **Area / edition:** Function elaboration / IEEE1800-2017 and2023 13.4.3.
- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Confidence:** REPRODUCED.
- **Evidence:** `evidence/batch-20260915-after-l95/next-constant-defaults-assessment/generate-baseline.json` at the L96/L97 focused install.
- **Closure:** Reject constant calls to functions declared in generate blocks, including nested/cached paths; preserve ordinary runtime generated functions and module/package constant functions. Paired edition tests required.
- **Implementation evidence:** [L98 session](session_logs/2026-09-15_generated_constant_function_legality.md).

### L99 — String methods lose fixed-array word mutations

- **Area / edition:** Constant evaluation and VPI array words / IEEE1800-2017 and2023 6.16,7.4,13.4.3.
- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Confidence:** REPRODUCED.
- **Evidence:** `evidence/batch-20260915-after-l95/next-string-array-method-assessment/baseline.json`; constant putc/itoa abort, runtime controls leave words unchanged in both editions.
- **Closure:** Correct selected fixed-array string mutation for all six mutating methods in constant and runtime paths, including locality, bounds, once-only evaluation and neighboring word preservation.

- **Implementation evidence:** [L99 session](session_logs/2026-09-15_fixed_string_array_methods.md).

### L100 — Finite multiclock consequence alternatives rejected

- **Area / edition:** SVA / IEEE1800-2017 and2023 16.9.2,16.12.7,16.12.22,16.13.2.
- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Confidence:** REPRODUCED.
- **Evidence:** `evidence/batch-20260915-after-l95/next-ranged-consequence-assessment/assessment.md`; internal one-copy consequence fails at50 while two-copy branch should succeed at90, but both editions reject the source.
- **Closure:** Distinct finite consequence NFA per child; one existential child result feeds universal parent aggregation. Preserve synchronization, controls, pending backlogs and unsupported construction boundaries with paired behavioral tests.

- **Implementation evidence:** [L100 session](session_logs/2026-09-15_finite_multiclock_consequences.md).

### L101 — Constant fixed-array string-character increment

- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Standards:** IEEE1800-2017 and2023 6.16,11.4.2,13.4.3.
- **Evidence:** `evidence/batch-20260915-after-l95/next-const-array-character-assessment/isolated-baseline.json`.
- **Closure:** Correct pre/post byte updates through the selected local fixed-array word, with runtime parity, once-only selectors, bounds and locality controls.

- **Implementation evidence:** [L101 session](session_logs/2026-09-15_constant_array_character_increment.md).

### L102 — Plain finite multiclock consequence alternatives

- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Standards:** IEEE1800-2017 and2023 16.9.2,16.13.1,16.13.2.
- **Evidence:** `evidence/batch-20260915-after-l95/next-plain-consequence-nfa-assessment/ASSESSMENT.md`.
- **Closure:** Fixed first-clock sequence prefix followed by finite second-clock alternatives yields a correctly timed single verdict per attempt, preserving clock boundaries, controls and pending backlogs.

- **Implementation evidence:** [L102 session](session_logs/2026-09-15_plain_multiclock_consequences.md).

### L103 — Plain multiclock ranged first-clock prefix

- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Standards:** IEEE1800-2017 and2023 16.9.2,16.13.1,16.13.2.
- **Evidence:** `evidence/batch-20260915-after-l95/next-plain-ranged-prefix-assessment/assessment.md`; both editions reject the legal finite ranged prefix.
- **Closure:** Existential complete-path aggregation for each plain sequence attempt, with exact times, all-fail/early-success behavior, controls, backlogs and preserved implication universality.

- **Implementation evidence:** [L103 session](session_logs/2026-09-15_plain_multiclock_ranged_prefix.md).

### L104 — Constant mixed integral/literal equality

- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Standards:** IEEE1800-2017 and2023 5.9, Table11-21,11.8.2.
- **Evidence:** `evidence/batch-20260915-after-l95/next-mixed-constant-equality-assessment/assessment.md`.
- **Closure:** Common integral operand sizing, signedness and four-state equality with constant/runtime parity.

- **Implementation evidence:** [L104 session](session_logs/2026-09-15_constant_mixed_equality.md).

### L105 — Fabricated nonlocal constant-function values

- **State:** REGRESSION_TESTED; local seven-gate batch passed, publication CI pending.
- **Standards:** IEEE1800-2017 and2023 13.4.3.
- **Evidence:** `evidence/batch-20260915-after-l95/next-static-constant-fallback-assessment/assessment.md`.
- **Closure:** Reject nonlocal mutable state during constant evaluation; retain actual runtime state and legal constant inputs.

- **Implementation evidence:** [L105 session](session_logs/2026-09-15_nonlocal_constant_function_values.md).

L96–L105 share the [local qualification checkpoint](session_logs/2026-09-15_compiler_batch_l96_l105_qualification.json).

### L118 — Queue/darray operand silently mistreated as vector bits in a concatenation select

- **Status:** CLOSED 2026-09-15. Found while investigating a `tasks/todo.md`
  Phase-B backlog item (`eval_string.c:249`'s silent select-on-unsupported-
  base-type fallback) — the reducer built to test it never reached that
  fallback at all, but surfaced this different, upstream bug instead.
- **Symptom:** `s = {qa, qb}[1];` where `qa`/`qb` are `string queue`s
  compiled with ZERO diagnostics and printed the wrong result (`s=""`,
  should be a real element) at runtime. Disassembly showed Icarus lowering
  `{qa, qb}` as a packed bit-vector concatenation (`%concat/vec4`) and then
  bit-selecting into it, rather than recognizing the queue operands.
- **Investigation correction (recorded so it isn't repeated):** initially
  read this as a MISSING FEATURE (IEEE 1800-2017/2023 10.10 unpacked-array
  concatenation, then an element select — primary grammar A.8.4 allows
  `concatenation [ [ range_expression ] ]`) and began implementing a
  `sorry:` diagnostic for it. Before finishing that, cross-checked with
  slang: `slang --std 1800-2017` REJECTS the identical construct outright
  (`error: invalid operand type 'string$[$]' in concatenation`), and the
  same for a non-string (`int`) queue. Re-reading 10.10: unpacked array
  concatenation requires an enclosing ARRAY-TYPED context (an assignment,
  argument, or pattern target) to be recognized as such; `{...}[...]` used
  as a bare sub-expression (the only way `PEPostSelect`'s base_ reaches a
  `PEConcat`) offers no such context, so a queue/darray operand there is
  simply illegal, not merely unimplemented. Reworded the diagnostic from
  `sorry:` (implies valid-but-unsupported) to `error:` (illegal) to match.
  This is the same discipline as [[discovered-debt-hypothesis-is-not-
  diagnosis]] (memory) — verify a hypothesis against a primary source
  before writing the fix, not just before closing the ticket.
- **Root cause:** `PEPostSelect::elaborate_expr` (elab_expr.cc) unconditionally
  elaborates its `base_` through `PEConcat`'s self-determined-width overload
  (a plain packed-vector concatenation), with no check on operand types —
  a queue/darray operand there was silently treated as vector bits instead
  of being rejected.
- **Fix:** added `postselect_concat_base_has_illegal_container_operand_()`
  (elab_expr.cc), checked right after `base_->test_width()` populates
  operand types: if any `PEConcat` operand covered by the select is itself
  queue/darray-typed (by `expr_type()`, or via `PEIdent::test_type_of_ident`
  for identifier operands), emit a focused `error:` citing IEEE
  1800-2017/2023 10.10 and reject, instead of silently mis-elaborating.
- **Scoped narrowly:** a concatenation of scalar queue/darray *elements*
  (e.g. `{q[0], q[1]}[3:0]`, the operands are scalars, not the container)
  is unaffected — verified with a permanent regression
  (`sv_concat_postfix_select_queue_element.v`) alongside the negative one.
  Plain packed-vector postfix-select (the pre-existing
  `sv_concat_postfix_select.v` coverage) is unaffected.
- **Permanent regression:** `ivtest/ivltests/sv_concat_postfix_select_queue_operand_fail.v`
  (CE, new `error:` diagnostic) and
  `ivtest/ivltests/sv_concat_postfix_select_queue_element.v` (normal,
  guards against a future false-positive on the scalar-element case), both
  registered in `ivtest/regress-sv.list` next to the existing postfix-
  select entries.
- **Validation:** focused 4/4 pass. Full `.github/ivtest_gate.sh` legacy
  sweep: `Total=5810, Passed=5805, Failed=0`, 0 unexplained vs. the
  `main`-tip (L96-L105) baseline. UVM regression: 357 passed, 0 failed, 0
  skipped. (json/nfa/releases/frontend/makecheck gates not re-run for this
  narrow, single-function fix — neither touched by the change.)
- **Not fixed here, deliberately:** actually IMPLEMENTING unpacked-array
  concatenation-then-element-select for the cases where it *is* legal
  (inside an array-typed context, e.g. `bigq = {qa, qb}; s = bigq[1];`,
  already two separate statements that already work today) is a real,
  separate feature, not touched by this fix. Nothing in this fix's scope
  claims that feature exists.

### L119 — `local::` outside an inline constraint block silently resolved as an ordinary property

- **Status:** CLOSED 2026-09-15. Found while probing `local::` (IEEE
  1800-2017/2023 18.7.1) for a hypothesized "snapshot the caller's value"
  defect. **The hypothesized defect did not exist** — `local::` works
  correctly for its real semantics (confirmed against the LRM's own
  worked example, §18.7.1: `function int F(C obj, integer x); F =
  obj.randomize() with { x < local::x; }; endfunction` — `local::x`
  binds to `F`'s own local argument, not a snapshot of `obj`'s property;
  reproduced exactly, 20/20 iterations correct). The investigation is
  recorded here anyway because it surfaced a real, different, narrower
  defect along the way.
- **Symptom:** `local::` used directly inside an ordinary CLASS-BODY
  `constraint` declaration (not an inline `randomize() with {...}`
  block) — e.g. `class c; rand integer x; constraint c1 { x <
  local::x; } endclass` — compiled with ZERO diagnostics and silently
  resolved `local::x` to the class's own (live, jointly-solved) property
  `x`, making the constraint an always-true tautology (`x < x` is never
  satisfiable, so in practice the constraint was effectively dropped/
  ignored by whatever fallback made the call still succeed).
- **LRM citation:** footnote 43 on the `constraint_block_item` production
  (A.2.11 in both editions): "The `local::` qualifier shall only appear
  within the scope of an inline constraint block." Confirmed independently:
  slang rejects the identical class-body construct with `'local'
  qualifier not allowed here`.
- **Root cause:** `pexpr_to_constraint_ir` (elaborate.cc) already had a
  correct, working handler for `local::` identifiers
  (`if (local_qualified && value_slots) return
  scope_randomize_value_slot_(...)`), gated on `value_slots` being
  non-null — `value_slots` is only ever non-null for an inline
  constraint's IR build (it's the argument-capture list an inline
  `with{}` clause needs; a plain class-body constraint has no
  randomize()-call-site scope to capture from, so it's built with
  `value_slots == nullptr`). When `local_qualified` was true but
  `value_slots` was null, there was no corresponding rejection — control
  fell through to the ordinary property-lookup path a few lines below,
  silently treating `local::x` as plain `x`.
- **Fix:** added the missing `if (local_qualified && !value_slots)` branch
  immediately after the existing (correct) inline-capture branch, emitting
  a focused `error:` citing 18.7.1 footnote 43 and returning `""` (which
  the existing dropped-constraint hard-error convention in this file
  already turns into a compile failure, not a silently weakened solve).
- **Scope:** the correct inline-`local::` path (already working, four
  pre-existing `ivtest` files cover it:
  `sv_constraint_function_argument_inline.v`,
  `sv_constraint_handle_inline.v`, `sv_struct_member_constraint_paths.v`,
  `sv_constraint_darray_size_local_scope.v`) is completely untouched —
  verified all four still pass.
- **Permanent regression:**
  `ivtest/ivltests/sv_constraint_local_outside_inline_fail.v` (CE, the
  class-body-`local::` rejection), registered in `ivtest/regress-sv.list`.
- **Validation:** focused 5/5 pass (new test plus the four existing
  inline-`local::` tests). Full `.github/ivtest_gate.sh` legacy sweep:
  `Total=5812, Passed=5807, Failed=0`, 0 unexplained. UVM regression: 357
  passed, 0 failed, 0 skipped.
- **Process note:** this is a repeat of the same discipline as L118 in
  this same session — an initial hypothesis (here: "`local::` doesn't
  snapshot correctly") was WRONG, caught by checking the LRM's own worked
  example and slang before writing any fix, which also reframed what the
  real, narrower, genuinely-broken case actually was. See
  [[discovered-debt-hypothesis-is-not-diagnosis]] (memory).

### L120 — Action-less `assert/assume property` on a liveness operator wrongly refused

- **Status:** CLOSED 2026-09-16. Found compiling real, unmodified
  Caliptra/Adams-Bridge formal-verification source
  (`submodules/adams-bridge/formal/fv_ntt_ctrl/fv_ntt_ctrl_constraints.sv`)
  directly — objective 5 grounding, not a synthetic reducer.
- **Symptom:** a completely action-less `assert property (s_eventually(x));`
  or `assume property (s_eventually(x));` — a bare `;` after the closing
  paren, no `else`, no statement of any kind — was rejected with `sorry:
  a pass action on this property operator is not supported (IEEE
  1800-2017 16.14.6)`, even though the source contains no pass action at
  all to refuse. Reproduced in complete isolation (a 7-line standalone
  reducer, no Caliptra dependency needed). Confirmed NOT specific to
  `assume`, or to any particular liveness shape: bare `assert`/`assume`
  on plain `s_eventually(x)` and on `1'b1 |-> s_eventually(x)` (a
  structurally different op_type reaching the same lowering) all hit it;
  `cover property (s_eventually(x));` was correctly unaffected (see root
  cause).
- **Root cause:** IEEE 1800-2017 A.2.10's "pass action only"
  `concurrent_assertion_statement` production
  (`assert_or_assume K_property '(' property_spec ')' statement_or_null`)
  represents a bare `;` trailing statement as a `PNoop` sentinel object,
  not a null pointer — the same sentinel shape `cover property (p);` and
  `... else ;` use. `pform_make_assertion()` (pform.cc) already consumed
  and cleared this sentinel for the fail-action case (any `kind`) and for
  `cover`'s pass-action case (`kind==2` only) — but never for
  assert/assume's pass-action case (`kind` 0/1). The uncleared `PNoop*`
  then reached `pform_make_temporal_assertion_()`'s
  `if (pass_stmt && !pass_supported)` check as a plain non-null pointer,
  indistinguishable from a genuine user-written pass action, for any
  property routed through that lowering (`op_type >= 4`: `within`,
  liveness, abort, and until-family operators) — which is exactly why
  none of this session's earlier, simpler SVA reducers (plain `|->`/`|=>`,
  `disable iff`+`$past`) had hit it: those operators don't reach this
  lowering at all.
- **Fix:** removed the `kind == 2 &&` restriction on the sentinel-clearing
  check in `pform_make_assertion()` (one line), making the "a null pass
  action has no executable behavior" consumption unconditional — matching
  what the pre-existing comment already said it should do. `cover
  property`'s own behavior is provably unchanged: it already hit this
  same clearing path before the fix (`kind==2` was already true for it),
  so removing the guard doesn't alter its control flow, only extends the
  same clearing to `kind` 0/1.
- **Scope verified narrow:** a REAL, non-empty pass action on a liveness
  operator (`assert property (s_eventually(x)) hits++;`) is still
  correctly refused with the identical diagnostic — confirmed directly,
  not assumed. `else`-only and combined pass+fail forms on liveness
  operators are unaffected (they never passed through the buggy
  sentinel path in the first place — only the pass-action-only grammar
  branch does). `cover property`'s already-correct behavior (own
  separate "not supported" message for unsupported operators) is
  unaffected, confirmed by direct comparison of its message before and
  after the fix.
- **Permanent regression:**
  `ivtest/ivltests/sv_assert_liveness_no_action.v` (normal — the fixed
  case, both `assert`/`assume` and both operator shapes) and
  `sv_assert_liveness_real_action_fail.v` (CE — confirms a genuine pass
  action is still refused), both registered in `ivtest/regress-sv.list`.
- **Validation:** focused 6/6 pass (both new tests plus four pre-existing
  liveness/assertion tests, confirming no regression to already-working
  shapes). Full `.github/ivtest_gate.sh` legacy sweep:
  `Total=5814, Passed=5809, Failed=0`, 0 unexplained. UVM regression:
  357 passed, 0 failed, 0 skipped.
- **Real-world confirmation:** the exact originally-failing real Caliptra
  file (`fv_ntt_ctrl_constraints.sv`, tested standalone with its package
  dependencies) now compiles with the two `sorry:` errors completely
  gone; remaining warnings on that file are pre-existing and unrelated
  (unresolved `bind`-target hierarchy references, from testing the file
  outside its full multi-file `bind` context — not a regression from
  this fix).

### L121 — Named property forward reference resolved as an undefined signal

- **Status:** CLOSED 2026-09-16. Found compiling real, unmodified
  Caliptra source directly (`src/sha512/formal/properties/
  fv_constraints.sv`), immediately after L120 — same session, same
  grounding approach.
- **Symptom:** `assert/assume property (name);` where `name` is a
  no-argument property declared LATER in the same module — legal per
  IEEE 1800-2017/2023 (no textual-order requirement between a
  `concurrent_assertion_statement` and the `property_declaration` it
  names; confirmed independently: slang accepts the identical construct,
  0 errors, 0 warnings) — was rejected with `error: Unable to bind
  wire/reg/memory 'name'`, exactly as if the name were genuinely
  undefined. Reproduced in a 15-line standalone isolated reducer. Two
  separate real, unmodified Caliptra files rely on this exact
  forward-reference shape (`src/sha512/formal/properties/
  fv_constraints.sv`, `src/sha512_masked/formal/properties/
  fv_constraints.sv`).
- **Root cause:** `sva_module_properties` (the map `pform_make_assertion`
  consults to resolve a bare `assert/assume/cover property (name);` to
  its declaration) is populated in single-pass textual parse order. A
  property declared after its first reference is not yet registered when
  that reference is reached, so resolution fell straight through to
  ordinary plain-identifier (signal) lookup and failed.
- **Fix:** mirrors the pre-existing, exactly-analogous deferred-clock-
  inference mechanism (`sva_pending_proc_` /
  `pform_sva_flush_pending_procedural`, called at end-of-module). Added a
  parallel `sva_pending_named_property_` list: when a bare single-
  identifier property reference is not found in `sva_module_properties`,
  park the full original call (loc/prop/fail_stmt/pass_stmt/kind/label)
  and retry once at end-of-module (`pform_sva_flush_pending_named_
  properties`, called before `pform_cur_module.pop_front()` so default-
  clocking lookup still resolves correctly on retry) by re-entering
  `pform_make_assertion` itself with the original arguments — by then
  every property declaration in the module has been parsed and
  registered. A name still unresolved at that point falls through to the
  original, unchanged plain-identifier error path — not a new message,
  no change for a genuinely undefined name (confirmed directly with a
  dedicated negative reducer).
- **Regression caught and fixed before landing (important process note):**
  the first version of this fix deferred on ANY unresolved single
  identifier, which also matches an ordinary already-declared signal used
  directly as a property body (`assert property (a);` where `a` is a
  plain `bit`/`wire` — indistinguishable from a forward-referenced
  property name at the point of first resolution). Deferring those too
  reordered their processing relative to other module items, which two
  VPI assertion-attempt-callback tests depend on for their attempt/
  instance numbering — caught immediately by the full ivtest gate's
  bundled VPI suite (`vpi/m12_assert_attempt.v`, `vpi/m12br_assert_cb2.v`
  went from 108/108 to 106/108, a real regression, not flakiness).
  Root-caused precisely (diffed the VPI gold output, found the `_0`/`_1`
  instance-index suffixes swapped) and fixed by narrowing the deferral
  condition with `pform_get_wire_in_scope()`: only defer when the name
  is not ALREADY resolvable as a known signal in scope, since such a
  name is never going to resolve as a property later instead. Re-ran the
  full VPI suite after the narrowing fix: back to 108/108.
- **Permanent regression:**
  `ivtest/ivltests/sv_assert_named_property_forward_ref.v` (normal — the
  fixed case, plus an ordinary-order property asserted alongside it to
  confirm the deferral machinery doesn't disturb already-working cases)
  and `sv_assert_named_property_undefined_fail.v` (CE — confirms a
  genuinely undefined name is still rejected identically), both
  registered in `ivtest/regress-sv.list`.
- **Validation:** focused 4/4 pass (both new tests plus L120's two).
  Full `.github/ivtest_gate.sh` legacy sweep: `Total=5816, Passed=5811,
  Failed=0`, 0 unexplained. Bundled VPI suite: 108/108 (the regression
  this fix's own first draft introduced, caught, root-caused, and fixed
  within the same investigation before ever being committed). UVM
  regression: 357 passed, 0 failed, 0 skipped.
- **Real-world confirmation:** the exact originally-failing
  `src/sha512/formal/properties/fv_constraints.sv` (with its real DUT,
  `sha512_core.v`) now compiles clean, exit 0.

### L122 — Comma-separated multi-identifier assertion-local variable declaration rejected as a syntax error

- **Status:** CLOSED 2026-09-16. Found compiling real, unmodified
  Caliptra source directly (`src/ecc/formal/properties/
  fv_ecc_pm_ctrl_abstract.sv`), while batch-scanning the `ecc` IP
  block's 24-file formal corpus — same real-corpus grounding approach as
  L120/L121.
- **Symptom:** `logic [5:0] addra, addrb;` — a comma-separated
  multi-identifier declaration inside a `property ... endproperty`
  block's local-variable section — was rejected with a plain `syntax
  error` pointing at the declaration line, followed by the expected
  cascade (`Unable to bind wire/reg/memory` for the property name). The
  single-identifier form (`logic [5:0] addra;`) already worked; only the
  comma continuation was rejected. Confirmed independently: slang
  (`--std 1800-2017`) accepts the identical construct, 0 errors, 0
  warnings — this is IEEE 1800-2017/2023 A.2.10's ordinary
  `assertion_variable_declaration ::= data_type
  list_of_variable_decl_assignments ';'`, ordinary comma-list variable
  declaration syntax used everywhere else in the language, not a
  special local-declaration-only restriction. Three genuine hits in the
  originally-scanned real file (all on `logic[5:0] addra,addrb;` lines,
  three separate properties), plus independently reproduced for the
  `int` form (`int a, b;`).
- **Root cause:** `parse.y`'s `sva_int_local_declarations` nonterminal
  had six alternatives (base and `sva_int_local_declarations`-chained
  forms, each for `K_int` and `K_sva_logic_local` with/without
  `dimensions`), and every one of them terminated in exactly one
  `IDENTIFIER ';'` — there was no comma continuation *within* a single
  declaration statement, only the (different, already-working) ability
  to chain multiple separate `;'-terminated declarations one after
  another (`logic [5:0] addra; logic [5:0] addrb;` always worked).
- **Fix:** added a new `sva_local_ident_list` nonterminal (returns
  `std::list<perm_string>*`), structurally identical to the pre-existing
  `sva_formal_list` comma-list pattern already used for parameterized-
  property formal argument lists — reused the same, already-proven-safe
  shape rather than inventing a new one. Replaced the bare `IDENTIFIER`
  in all six `sva_int_local_declarations` alternatives with
  `sva_local_ident_list`, and changed each action to loop over the
  returned list, calling `pform_sva_declare_int_local`/
  `pform_sva_declare_logic_local` once per name.
  `pform_sva_declare_logic_local(loc, name, dimensions)` previously
  always freed its `dimensions` argument (both the range-expression
  contents and the list container itself) unconditionally — calling it
  more than once with the same shared `dimensions` pointer (one call per
  comma-separated name) would double-free. Added an `owns_dimensions`
  parameter (default `true`, preserving every existing call site
  unchanged) so the grammar action passes `false` for every identifier
  in the list except the last, which alone releases the shared
  dimensions list once all clones have been made.
  `sva_local_dimension_width_()` was already safe to call once per
  identifier sharing the same `dimensions` list: it clones the range
  bounds (`sva_clone_expr_`) rather than consuming the originals, so
  each identifier still gets its own independent width expression tree
  — required since `pform_sva_end_local_declarations()` later deletes
  each map entry's `width` individually, and two entries sharing one
  `width` pointer would double-free there instead.
- **Verified in scope, not conflated with a separate pre-existing
  defect (important process note):** while building the permanent
  regression, mixing `int`-kind and `logic`-kind local declarations
  within one property (e.g. `int a; logic [3:0] z;`) was found to break
  binding of the `int`-typed name(s) at elaboration
  (`Unable to bind wire/reg/memory 'a'`) — but this reproduces with
  **zero commas involved**, using only the pre-existing single-
  identifier chain grammar this fix left untouched, so it is a separate,
  pre-existing defect, not a regression from this fix and not required
  for L122's closure. Recorded separately as DD-034 in
  `DISCOVERED_DEBT.md`; the L122 regression test deliberately declares
  only same-kind identifiers per property to stay in scope. See
  [[discovered-debt-hypothesis-is-not-diagnosis]] — verified the
  boundary of what this fix does and does not touch before claiming
  either construct implemented.
- **Bison grammar-safety check:** shift/reduce and reduce/reduce
  conflict totals compared before/after (`bison -y -d --report=state`):
  562/1122 identical in both, and the new rules are additive
  (`sva_local_ident_list` mirrors `sva_formal_list`'s already-safe
  shape) rather than modifying any existing production's alternatives.
- **Permanent regression:**
  `ivtest/ivltests/sv_assert_property_local_multi_ident_decl.v` (normal
  — functionally verifies both the `logic [N:0] a, b;` base form and an
  `int a, b; int c;` chain, matching values through the sequence rather
  than only checking compile success), registered in
  `ivtest/regress-sv.list`.
- **Validation:** focused 5/5 pass (this test plus L120's and L121's
  four). Full `.github/ivtest_gate.sh` sweep: `Total=5819, Passed=5814,
  Failed=0, Not Implemented=2, Expected Fail=3`, name-diff gate clean (0
  unexplained). Bundled VPI suite: 108/108. Negative suite: 148/148.
  UVM regression: 357 passed, 0 failed, 0 skipped.
- **Real-world confirmation:** the exact originally-failing
  `src/ecc/formal/properties/fv_ecc_pm_ctrl_abstract.sv` no longer
  produces the `syntax error` on any of its three `logic[5:0]
  addra,addrb;` declarations (grep-confirmed absent from the diagnostic
  output; one unrelated pre-existing `syntax error` at line 40, a
  standalone-file port-list type-resolution artifact from compiling
  this file outside its package context, is untouched by and out of
  scope for this fix).

### L123 — Parenthesized cycle-delay expression (`##(expr)`) rejected as a syntax error

- **Status:** CLOSED 2026-09-16. Found compiling real, unmodified
  Caliptra source directly (`src/ecc/formal/properties/
  fv_ecc_hmac_drbg_interface_constraints.sv`, line 67), continuing the
  same real-corpus scan of the `ecc` IP block's formal directory that
  found L122.
- **Symptom:** `##(time_window+1) hmac_drbg_valid;` — a parenthesized
  expression as a cycle-delay operand, where `time_window` is a
  property formal argument — was rejected with a plain `syntax error`.
  Reduced further: the rejection is unconditional on what the parens
  contain, including a pure compile-time-constant expression with no
  formal argument at all (`##(1+1)`) or even a single bare literal
  (`##(3)`) — every parenthesized form failed identically, while the
  unparenthesized bare-identifier form (`##tw`) already correctly
  reached a semantic diagnostic (`sorry: sequence cycle delays must be
  literal constants`) rather than a parse-time syntax error. Confirmed
  independently: slang (`--std 1800-2017`) accepts both `##(3+1)` and
  `##(tw+1)`, 0 errors, 0 warnings — this is IEEE 1800-2017/2023
  A.2.10's `cycle_delay_range ::= '##' constant_primary`, where
  `constant_primary` includes `'(' constant_mintypmax_expression ')'`.
- **Root cause:** `delay_value_simple` — the nonterminal shared by
  every `K_CYCLE_DELAY` (`##`) use site across SVA sequences/
  properties, procedural cycle delay, non-blocking cycle-delay
  assignment, ordinary `#` delay, and specify-path delay — has four
  alternatives (`DEC_NUMBER`, `REALTIME`, `IDENTIFIER`, `TIME_LITERAL`)
  and no parenthesized-expression alternative. The procedural
  cycle-delay statement production already worked around this locally
  by spelling `K_CYCLE_DELAY '(' expression ')' statement_or_null` as
  its own separate alternative (IEEE 1800-2017 14.11) rather than
  extending the shared nonterminal, but the six SVA sequence/property
  cycle-delay productions never got the same treatment.
- **Fix:** added a new `sva_cycle_delay_value` nonterminal
  (`delay_value_simple | '(' expression ')'`) and substituted it for
  `delay_value_simple` at exactly the six SVA-specific `K_CYCLE_DELAY`
  sites (`sva_multiclock_seq`, `sva_mc_tail`, the grouped-composite-
  sequence alternative of `property_expr`, `sva_seq_comb_concat`, and
  the leading/trailing-delay alternatives of `sva_seq_atom`).
  Deliberately scoped to only these six: `delay_value_simple` itself
  was left untouched to avoid any blast radius on the unrelated ordinary
  `#`-delay and specify-path contexts that also use it, and the two
  existing `K_CYCLE_DELAY` sites that don't need this fix (the
  procedural statement production, which already has its own explicit
  paren alternative; and the non-blocking cycle-delay assignment
  production, not evidenced as broken by any real source) were left
  alone.
  The downstream consumers (`pform_sva_single_delay`,
  `pform_sva_tree_concat`) already accepted an arbitrary `PExpr*` and
  fell back to a graceful diagnostic for a non-resolvable value —
  confirmed directly: `pform_sva_single_delay` already had a code
  comment anticipating exactly this shape ("A property formal can later
  substitute arithmetic here"), and the pre-existing bare-identifier
  `##tw` path already exercised that same fallback. No semantic-layer
  change was needed; this was purely a grammar gap.
- **Bison grammar-safety check:** shift/reduce and reduce/reduce
  conflict totals compared before/after (`bison -y -d --report=state`):
  562/1122 identical in both.
- **Permanent regression:**
  `ivtest/ivltests/sv_sva_cycle_delay_paren_expr.v` (normal — exercises
  the parenthesized-arithmetic form at the ordinary leading-delay
  position, plus a parenthesized-literal form through the separate
  multiclock-boundary production, confirming the new alternative is
  wired into more than one of the six touched call sites), registered
  in `ivtest/regress-sv.list`.
- **Validation:** focused pass (this test, compiles and runs correctly
  standalone). Full `.github/ivtest_gate.sh` sweep: `Total=5820,
  Passed=5815, Failed=0, Not Implemented=2, Expected Fail=3`, name-diff
  gate clean (0 unexplained). Bundled VPI suite: 108/108. Negative
  suite: 148/148. UVM regression: 357 passed, 0 failed, 0 skipped.
- **Real-world confirmation:** the exact originally-failing
  `src/ecc/formal/properties/fv_ecc_hmac_drbg_interface_constraints.sv`
  no longer produces the `syntax error` at line 67; the file now
  reaches only its remaining, already-documented `sorry:` limitations
  (parameter-valued consecutive repetition, a separate known gap) plus
  an expected standalone-compile artifact (`bind target module ... is
  not defined in this compilation`, from compiling this file outside
  its full project context).

### L124 — Unpacked-array range select unsupported as a module port-connection actual (closes DD-036)

- **Status:** CLOSED 2026-09-16. Found via a differential Icarus/slang
  static census over Caliptra's full integration filelists (patched
  copy of the pre-existing `run_census.py` census driver — see
  `[[census-driver-paths-rot]]` — pointed at this worktree's build),
  run to look for real defects beyond the `formal/` corpus already
  exhausted this session. Recorded first as DD-036 in
  `DISCOVERED_DEBT.md` with a precise root cause and a promising but
  unverified fix angle; the one open unknown noted there
  (word-vs-pin unit conversion) was resolved by reading
  `normalize_variable_unpacked()`'s and `decode_fixed_uarray_slice()`'s
  implementations directly, then the fix was implemented, built, and
  fully validated — this entry supersedes DD-036, which is now closed.
- **Symptom:** a range select on a single-dimension fixed unpacked
  array (e.g. `arr[hi:lo]`, selecting a contiguous element sub-range of
  the same element type) used as a module port-connection actual was
  rejected with `sorry: Array slices are not yet supported for
  continuous assignment.` Confirmed independently: slang
  (`--std 1800-2017`) accepts the identical construct, 0 errors, 0
  warnings. **This single gap was the only thing blocking Icarus from
  compiling Caliptra's full-chip `caliptra_top` integration target at
  all** — the census's `ICARUS_GAP` category had exactly 5 entries
  (`ntt_masked_mult_reduction_tb`, `ntt_top`, `abr_top`,
  `caliptra_top`, `caliptra_top_ss_mode`), and diffing each target's
  full error set showed all five traced to the exact same two real,
  unmodified source sites
  (`submodules/adams-bridge/src/ntt_top/rtl/ntt_masked_special_adder.sv:102-103`,
  `submodules/adams-bridge/src/abr_libs/rtl/abr_masked_add_sub_mod_Boolean.sv:134-135`
  — both connect a `WIDTH`-element slice out of a `WIDTH+1`-element
  unpacked array straight to a submodule port, e.g.
  `.r0(r0_c0_delayed[WIDTH-1:0])`).
- **Root cause:** `PEIdent::elaborate_unpacked_net()`
  (`elab_net.cc:1607`) already implements a "slice view" mechanism —
  build a `NetNet::IMPLICIT` view net and `connect()`-alias it onto a
  contiguous pin range of the source net — but only for a *sibling*
  index shape: a partial index that supplies fewer indices than the
  source array has dimensions (reducing dimensionality, e.g. `arr2d[i]`
  on a 2-D array yielding a 1-D sub-array). A same-dimension-count
  range select (`SEL_PART`/`SEL_IDX_UP`/`SEL_IDX_DO` in
  `index_component_t`, rather than a plain `SEL_BIT` index) is a
  different shape that `indices_to_expressions()` explicitly rejects
  ("Array cannot be indexed by a range") if fed to it, so the code
  never even attempted the slice-view path for this shape — it fell
  straight through to the `sorry:`.
- **Fix:** rather than reimplementing bound/direction decoding,
  reused `decode_fixed_uarray_slice()` (`netmisc.h`/`netmisc.cc`), a
  general fixed-unpacked-array-slice decoder already relied on by
  three *other* contexts (function/task argument binding, concatenation
  operands, an lvalue path) but never wired into module port
  connections. Added a second branch in
  `PEIdent::elaborate_unpacked_net()`, engaged only when the source has
  exactly one unpacked dimension and the target formal is itself a
  fixed unpacked array: call `decode_fixed_uarray_slice(des, scope,
  *this, this, false, slice)`; on success, build the exact same
  `NetNet::IMPLICIT` + `connect()` view-net pattern the existing
  partial-index branch already uses, but pin-aliased starting at
  `slice.canonical_base` instead of the partial-index branch's
  `normalize_variable_unpacked()`-derived base. Confirmed by reading
  both functions directly (not assumed) that `canonical_base` and the
  existing branch's `base` are in the same word/pin-index space for a
  1-D unpacked array (`normalize_variable_unpacked()`'s stride-based
  canonical address and `decode_fixed_uarray_slice_select_()`'s
  `low - declared_low` compute identically for a single dimension), so
  no unit conversion was needed. On decode failure (`rc < 0`,
  recognized-but-invalid shape, e.g. a direction mismatch),
  `decode_fixed_uarray_slice()` has already reported its own precise
  diagnostic, so the new branch returns immediately without also
  emitting the generic `sorry:` (avoiding a confusing double message).
  On `rc == 0` (not this shape at all) or a shape/type mismatch against
  the target formal, control falls through unchanged to the existing
  `sorry:` — every other case this function already handled is
  untouched.
- **Verified for simulation correctness, not just compile success:**
  a functional reducer (see permanent regression below) confirms the
  view net is wired to the *correct* pins — element-by-element value
  matching, the out-of-range element (outside the slice) correctly
  excluded and its later changes not leaking into the slice, and a
  post-elaboration change to an in-range element correctly propagating
  live through the connection (it is a real net alias, not a one-shot
  copy). Also confirmed the ascending-declared-array direction (not
  just descending) and the negative direction-mismatch case (properly
  rejected with `decode_fixed_uarray_slice()`'s own diagnostic,
  unchanged).
- **Permanent regression:**
  `ivtest/ivltests/sv_unpacked_array_slice_port_conn.v` (normal —
  functional value/exclusion/live-propagation checks, not just compile
  success) and `sv_unpacked_array_slice_port_conn_dir_fail.v` (CE — the
  direction-mismatch negative case), both registered in
  `ivtest/regress-sv.list`.
- **Validation:** focused 2/2 pass. Full `.github/ivtest_gate.sh`
  sweep: `Total=5822, Passed=5817, Failed=0, Not Implemented=2,
  Expected Fail=3`, name-diff gate clean (0 unexplained). Bundled VPI
  suite: 108/108. Negative suite: 148/148. UVM regression: 357 passed,
  0 failed, 0 skipped.
- **Real-world confirmation:** re-ran the exact census commands for all
  5 previously-`ICARUS_GAP` targets directly — `ntt_top` and
  `caliptra_top` both now compile with `-tnull` at exit 0, zero
  diagnostic lines. Re-ran the full 106-target census:
  `ICARUS_GAP: 0` (was 5), all five previously-failing targets now
  report zero Icarus errors/warnings
  (`evidence/caliptra-census-20260916/caliptra-static-census.json`).
  **This closes the single defect that was blocking Icarus from
  compiling Caliptra's full-chip `caliptra_top` target at all** —
  directly serving mission objective 5.

### L125 — Confirmed regression: object method call on a class member misresolved as a bare parameterized-class reference

- **Status:** CLOSED 2026-09-16. Found via a full-corpus differential
  OpenTitan census (`scripts/opentitan_matrix.py`, 530 jobs, unmodified
  `opentitan-upstream` @ `7a3ad34b6`), run after the Caliptra `formal/`
  corpus and the Caliptra full-integration census were both already
  exhausted this session. **This is the first genuine regression found
  this session** (L118-L124 were all pre-existing gaps in previously-
  untested real corpus, not regressions) — root-caused with a proper
  same-script, per-job diff against a freshly rebuilt pre-session
  baseline before any fix was attempted, per
  `[[verify-against-freshly-built-main-baseline]]`.
- **Symptom:** `receiver.method()`, where `receiver` is an ordinary
  class-member (or local) variable whose *declared type's name* happens
  to coincide with an unrelated class's name declared elsewhere in the
  design, was rejected with `error: Parameterized class 'name' requires
  an explicit #(...) specialization before ::.` — even though the
  actual source uses ordinary `.` member/method access, never `::`, and
  `receiver` unambiguously names a variable, not a type. Reduced to a
  20-line standalone case; confirmed independently: slang
  (`--std 1800-2017`) accepts the identical construct, 0 errors, 0
  warnings.
  Real, unmodified OpenTitan DV source hits this directly:
  `hw/dv/sv/dv_base_reg/dv_base_reg_field.sv` declares `dv_base_mubi_cov
  mubi_cov;` (a member variable) and calls `mubi_cov.create_cov(width)`;
  `dv_base_mubi_cov.sv` (a sibling file in the same package) separately
  declares an unrelated `class mubi_cov #(parameter int Width = 4, ...)`
  — the name collision is between the *variable* and the *unrelated
  class*, not a self-reference. `dv_base_reg_field.sv` is common DV
  infrastructure; this broke compilation of `lowrisc:dv:tl_agent_sim`
  and all eight `top_*_xbar_{main,peri}_sim` cores across all three
  OpenTitan tops (earlgrey, darjeeling, englishbreakfast).
- **Confirmed as a real regression, not a pre-existing gap newly
  surfaced:** built the compiler at `631bba6e8` (PR #277, the last
  reliably-documented clean baseline: "OpenTitan census ... PASS 203 |
  FAIL 84 | ... RUNTIME_FAIL 23" exactly reproduced with today's
  `scripts/opentitan_matrix.py`, confirming that script version is the
  right comparison point) and ran the 20-line reducer directly: exit 0,
  clean. The same reducer on current `main` (before this fix): rejected.
  Bisected by building at each intervening squash-merge PR
  (`d9bfbaeee`, `8346955a6`, `5c0f5588e`, `9c8f716b1`, `874e00680`,
  `c45760199`, `34cd45c6b`, `5e0df21fd`) and re-testing the reducer at
  each: first broken at `5c0f5588e` (PR #280, "L43-L64"), the squash
  commit immediately after the clean `631bba6e8` baseline.
- **Root cause:** `PCallTask::elaborate_usr()`'s dotted-call resolution
  (`elaborate.cc`) added new machinery in PR #280 to support calling an
  inherited static class method via a bare class-scoped name with
  implicit `this` (`resolve_scoped_class_method_task_`, extended with
  `deferred_type_parameter`/`illegal_nonstatic`/`use_implicit_this`
  outputs). For a two-component dotted call (`receiver.method()`), this
  new resolution path is tried and its "receiver is a bare, unspecialized
  parameterized class name" diagnostic is acted on *before* checking
  whether `receiver` already resolves as an ordinary variable in scope
  — so a variable whose type happens to share a name with any
  parameterized class anywhere in the design gets misidentified as a
  reference to that unrelated class. The sibling call site for the
  *expression-call* context (`PCallTask::elaborate_method_`, further
  down in the same file) already had the correct guard
  (`if (net == 0) { ... resolve_scoped_class_method_task_(...) ... }`
  — only attempted when ordinary symbol resolution already failed to
  find a net); only the statement-call site (`elaborate_usr`) was
  missing it.
- **Fix:** added the same "does the receiver already resolve as an
  ordinary variable?" guard to the statement-call site: before invoking
  `resolve_scoped_class_method_task_` for a two-component call, resolve
  the single-component receiver via `symbol_search()`; if it finds an
  ordinary net (`sr.net != nullptr`), skip the scoped-class-name
  resolution entirely (`static_method` stays null) and fall through to
  the existing, unchanged ordinary object-method dispatch
  (`elaborate_method_`) below. Confirmed the already-correct sibling
  call site needed no change.
- **Verified the fix doesn't disturb what PR #280 added:** direct
  reducers confirm (1) an inherited static task called via a bare name
  with implicit `this` still resolves and runs correctly, (2) a
  genuinely bare, unspecialized parameterized class reference (`gc::
  hello();` with no shadowing variable) still correctly errors
  unchanged, and (3) an explicit specialized scoped-static call
  (`gc#(8)::hello();`) still works correctly.
- **Permanent regression:**
  `ivtest/ivltests/sv_class_member_shadows_unrelated_class_name.v`
  (normal — reproduces the exact real-world shape: an unrelated
  parameterized class sharing a name with a plain class-member
  variable, and a functional check that the method call actually ran,
  not just that it compiled), registered in `ivtest/regress-sv.list`.
- **Validation:** focused pass (this test, plus the three PR #280
  behavior-preservation reducers above). Full `.github/ivtest_gate.sh`
  sweep: `Total=5821, Passed=5816, Failed=0, Not Implemented=2, Expected
  Fail=3`, name-diff gate clean (0 unexplained). Bundled VPI suite:
  108/108. Negative suite: 148/148. UVM regression: 357 passed, 0
  failed, 0 skipped.
- **Real-world confirmation:** re-ran the full 530-job OpenTitan census
  with the fixed compiler. `lowrisc:dv:tl_agent_sim:0.1` (`uvm` lane):
  `FAIL -> PASS`. The `mubi_cov` error is confirmed completely gone from
  every previously-affected `top_*_xbar_*_sim` core's `hard_errors` list
  (checked directly, not inferred) — those cores do not flip all the way
  to `PASS` because the compile now progresses further and reaches a
  separate, deeper, pre-existing issue in `tlul_assert.sv` (`bind`-scope
  signal binding inside a generated instance path, `tb.dut.
  tlul_assert_host_rv_core_ibex__corei`), unrelated to this fix and out
  of its scope — exactly the documented "a frontier fix usually ADVANCES
  a core's first diagnostic rather than clearing it" pattern. Not
  claimed as closing those cores; only the `mubi_cov` misresolution
  itself is closed.

### L126 — Regression: named sequence solo-referenced inside a generate block loses its scope on deferred retry (fixes the L125-uncovered `tlul_assert` frontier)

- **Status:** CLOSED 2026-09-16. Found by chasing the exact deeper
  frontier L125 uncovered (see L125's "real-world confirmation" —
  `top_*_xbar_*_sim` advanced past `mubi_cov` to a `tlul_assert.sv`
  "Unable to bind wire/reg/memory" error on a sequence name). **This is
  a regression in this session's own L121 fix** (named-property
  forward-reference deferral, merged in PR #289) — the second
  self-introduced regression found and fixed this session, again via
  same-script/same-corpus verification before and after, not assumed.
- **Symptom:** a named sequence declared inside a conditional generate
  block, referenced as the *entire* property expression of an
  assert/cover statement in the *same* block (no forward reference —
  the declaration is textually first), was rejected with `error:
  Unable to bind wire/reg/memory 'name'` — as if the sequence name were
  undefined, even though it is declared right above its use. Reduced to
  a 10-line case; a named-sequence reference *inside a longer chain*
  (`x ##1 seq_name ##1 y`) in the same generate block already worked
  correctly — only the *solo* reference (the sequence IS the whole
  property expression) was affected. Confirmed independently: slang
  (`--std 1800-2017`) accepts the identical construct, 0 errors.
  Real, unmodified OpenTitan RTL (`hw/ip/tlul/rtl/tlul_assert.sv`)
  relies on exactly this shape: the `TLUL_D_CHAN_CONTENT_CHANGED_WO_
  ACCEPTED`/`TLUL_COVER` macros declare a `sequence ..._S; ...
  endsequence` inside `if (EndpointType == "Host") begin :
  gen_host_cov`, referenced solo by a `cover property (...)` in the
  same block — used by essentially every TL-UL-connected DV testbench.
- **Root cause:** L121's deferral guard (`pform.cc`,
  `pform_make_assertion`'s "named property instantiation" handling)
  parks an unresolved bare single-identifier reference as a possible
  forward-referenced *property*, retried at end-of-module — guarded to
  skip deferral when the name is already resolvable as a known signal
  (added when L121's first draft broke VPI attempt-callback ordering,
  see L121's entry above). It did **not** also skip deferral when the
  name was already resolvable as a known *sequence*
  (`sva_module_sequences`) — and a solo sequence reference is never
  going to appear in the *properties* map at all, so it unconditionally
  looked exactly like an unresolved-property shape and always got
  deferred. The deferred retry re-enters `pform_make_assertion` at
  end-of-module, using `pform_cur_generate` (whatever generate block is
  lexically active *at retry time*) to resolve the name — but by
  end-of-module every generate block has already closed, so
  `pform_cur_generate` no longer matches the `PGenerate*` the sequence
  was actually declared under (`sva_scoped_name_t`'s key includes the
  declaring generate block). This "worked" by pure accident at plain
  module scope (both a module-scope declaration's key and the deferred
  retry's implicit scope are `nullptr`) and failed only inside any
  generate block — which is exactly why this was not caught by L121's
  own validation (its reducers were all module-scope) and only surfaced
  now via real corpus with generate-scoped sequences.
- **Fix:** added a third deferral guard alongside the existing
  not-already-a-signal check: also skip deferral when the name is
  already resolvable as a known sequence in the *current* (still
  correct) scope, via `sva_in_scope_(sva_module_sequences, name)`. Such
  a reference falls straight through to the existing, unchanged ordinary
  sequence-splicing path (`sva_splice_sequences_`, already scope-correct
  since it runs immediately, not deferred) instead of being parked.
- **Verified independently as a regression, not a pre-existing gap:**
  built the compiler at `34cd45c6b` (L118, immediately before L119-
  L123/L121 landed) and confirmed the reducer compiles clean there
  (exit 0); the identical reducer on `main` before this fix (with L121
  but not this fix) fails. Also confirmed the failing regression test
  added for this fix genuinely fails when only L125's `elaborate.cc`
  change is cherry-picked without this `pform.cc` change (isolating the
  two fixes from each other).
- **Permanent regression:**
  `ivtest/ivltests/sv_sequence_solo_ref_in_generate_block.v` (normal —
  exercises both the exact real-world shape, a `cover property` solo
  reference, and a functional `assert property` implication using the
  same solo reference, checked against a driven waveform, not just
  compile success), registered in `ivtest/regress-sv.list`.
- **Validation:** focused pass (this test, plus the chain-in-generate-
  block reducer confirming no regression to the already-working case).
  Full `.github/ivtest_gate.sh` sweep: `Total=5822, Passed=5817,
  Failed=0, Not Implemented=2, Expected Fail=3`, name-diff gate clean (0
  unexplained). Bundled VPI suite: 108/108 (re-confirms L121's own
  attempt-callback-ordering regression stays fixed — this change adds a
  guard to the same function). Negative suite: 148/148. UVM regression:
  357 passed, 0 failed, 0 skipped.
- **Real-world confirmation:** re-ran the full 530-job OpenTitan census
  with the fixed compiler (on top of L125). `uvm`-lane result: **all
  eight `top_*_xbar_{main,peri,mbx,dbg}_sim` cores across all three
  OpenTitan tops (earlgrey, darjeeling, englishbreakfast) flip `FAIL ->
  PASS`** — the full crossbar DV family now compiles clean. A further
  ~13 `uvm`-lane cores (`adc_ctrl_sim`, `dma_sim`, `hmac_sim`,
  `mbx_sim`, `pattgen_sim`, `rv_timer_sim`, `soc_dbg_ctrl_sim`,
  `uart_sim`, `gpio_sim` across multiple tops, `rstmgr_sim`) advance
  from a genuine Icarus compile `FAIL` to `DEBT`/`UPSTREAM_INVALID`
  (i.e. Icarus itself no longer errors on them; whatever those
  categories track is a separate, non-Icarus concern). `uvm`-lane PASS:
  190 → 198.

### L127 — Crash: elaboration-time `$fatal()`/`$error()`/`$warning()`/`$info()` segfaults on an unelaboratable argument

- **Status:** CLOSED 2026-09-16. Found in the same OpenTitan `sva`-lane
  census scan that led to L125/L126 — `lowrisc:{earlgrey,darjeeling}_dv:
  otp_ctrl_sva:0.1` both showed a raw process crash (`Segmentation
  fault: 11`, `hard_errors` truncated mid-message) rather than any
  ordinary diagnostic. **A crash is categorically worse than a
  diagnostic gap** — it produces no error message at all, violating the
  project's bar that unsupported/invalid input must produce a focused
  diagnostic, not silently (or violently) fail.
- **Symptom:** an elaboration-time system-task call
  (`$fatal`/`$error`/`$warning`/`$info`, IEEE 1800-2017/2023 clause
  20.11) whose argument fails to elaborate as an expression (e.g. a
  bare identifier that is not declared anywhere) crashed the compiler
  with SIGSEGV instead of reporting a clean error. Real, unmodified
  OpenTitan RTL (`hw/{top_earlgrey,top_darjeeling}/ip_autogen/otp_ctrl/
  rtl/otp_ctrl.sv`) hits this directly via `hw/ip/prim/rtl/
  prim_assert_standard_macros.svh`'s `` `ASSERT_INIT `` macro: under
  `` `ifdef FPV_ON ``, it expands to `if (!(__prop)) $fatal(2, "...%s...
  %s...", (__name), (__prop));` where `__name` is the assertion's own
  bare label token (e.g. `ScrmblKeyNotAllZero_A2`) substituted
  unquoted — an undefined identifier in this expression context, not a
  string literal. Confirmed independently: slang (`--std 1800-2017`)
  also rejects the reduced construct ("use of undeclared identifier"),
  confirming a clean compile error is the correct response here, not a
  crash — this is arguably an upstream macro issue for the `FPV_ON`
  path, but that changes nothing about Icarus's obligation to fail
  safely rather than crash on it.
- **Root cause:** `PCallTask::elaborate_elab()` (`elaborate.cc`,
  ~line 17789) calls `elab_sys_task_arg()` for each argument and, if the returned
  `NetExpr*` fails `check_parm_is_const()`, prints a diagnostic
  including the argument's current value (`*eparms[idx]`) — but never
  checked whether `elab_sys_task_arg()` had returned `nullptr` (which
  it does when an argument fails to elaborate at all, e.g. an
  undefined identifier — already reported as a `warning: Unable to
  bind wire/reg/memory` compile-progress message by that point).
  `check_parm_is_const(nullptr)` itself is safe (a `dynamic_cast` on a
  null pointer is well-defined and just returns false), but the
  subsequent `cerr << ... << *eparms[idx] << ...` dereferences the null
  pointer directly, crashing mid-print — explaining the exact
  truncated error text captured in the census (`"Elaboration task
  $fatal() parameter [3] '"` then nothing, then the shell's own
  SIGSEGV report merged into the same output stream).
- **Fix:** added an explicit null check on `eparms[idx]` before the
  `check_parm_is_const()`/print step: when `elab_sys_task_arg()`
  returns `nullptr`, count it as a non-constant parameter (advancing
  `des->errors` and clearing `const_parms`, exactly as the existing
  non-constant case does) without dereferencing anything, relying on
  the earlier compile-progress warning already emitted by
  `elab_sys_task_arg()` itself to explain why. No other behavior
  changed — a fully-elaborable-but-non-constant argument still gets
  the original, unchanged "is not constant" message with its value
  printed.
- **Verified the existing working cases are unaffected:** a single
  fully-elaborable string-literal `$fatal` argument still prints its
  message and fails elaboration exactly as before; a multi-argument
  `$fatal` where every argument elaborates fine (just more than the
  currently-supported single string) still hits the existing,
  unrelated `sorry: Elaboration tasks currently only support a single
  string argument` limitation, unchanged; a generate-`if` branch where
  the `$fatal` guard condition is false (so the argument is never even
  evaluated) still compiles clean, unchanged.
- **Permanent regression:**
  `ivtest/ivltests/sv_elab_task_fatal_undef_arg_fail.v` (CE — the exact
  crash-triggering shape, confirmed the harness's captured stderr
  matches on the first attempt, no crash), registered in
  `ivtest/regress-sv.list`.
- **Validation:** focused 1/1 pass. Full `.github/ivtest_gate.sh`
  sweep: `Total=5823, Passed=5818, Failed=0, Not Implemented=2, Expected
  Fail=3`, name-diff gate clean (0 unexplained). Bundled VPI suite:
  108/108. Negative suite: 148/148. UVM regression: 357 passed, 0
  failed, 0 skipped.
- **Real-world confirmation:** the exact originally-crashing
  `lowrisc:{earlgrey,darjeeling}_dv:otp_ctrl_sva:0.1` `sva`-lane targets
  no longer crash — both now exit with a normal nonzero status and a
  clean list of 11 `warning: Unable to bind wire/reg/memory` compile-
  progress diagnostics (one per affected `` `ASSERT_INIT `` use), not a
  signal-based abnormal termination. Not claimed as closing those two
  targets to `PASS` — the underlying macro issue (an undefined
  identifier used as a format argument under `FPV_ON`) is a separate,
  likely-upstream concern outside this fix's scope; only the crash
  itself is closed.

### L128 — Crash: `static`/`automatic` qualifier before `task`/`function` at module scope entered unrecoverable parser panic-mode, eventually corrupting generate-scheme state and aborting (closes DD-038)

- **Status:** CLOSED 2026-09-16. Closes **DD-038**
  (`lowrisc:dv:spid_upload_sim:0.1`, SIGABRT via an `ivl_assert`/
  `assert()` failure in `pform_endgenerate`). Root-caused precisely
  after DD-038's own follow-up investigations (same session) had
  already identified the first syntax error's construct and the
  grammar-level reason it produces a raw `syntax error` at all; this
  entry implements and validates the fix.
- **Symptom:** `static task host();` (a `static`/`automatic` qualifier
  used as a *prefix* before `task`/`function`, the class-method-only
  form) declared directly in a module body — not inside a class —
  produced a raw, unhandled bison `syntax error` at the qualifier
  token itself. On real files with several such declarations followed
  by substantial unrelated content (e.g. a large procedural
  `case (cmd) inside ... endcase` block), the resulting panic-mode
  error recovery corrupted parser-internal generate-scheme bookkeeping
  badly enough that a later, syntactically-unrelated construct crashed
  the compiler outright (`Assertion failed:
  (pform_cur_generate->scheme_type == PGenerate::GS_CASE_ITEM ||
  parent_generate->scheme_type != PGenerate::GS_CASE), function
  pform_endgenerate`). Confirmed independently: slang also rejects the
  construct (`error: qualifiers are not allowed on out-of-block method
  definitions`), confirming Icarus's *rejection* was already correct —
  only the diagnostic's quality (opaque `syntax error`) and the crash
  were real problems. Real, unmodified OpenTitan RTL
  (`hw/ip/spi_device/pre_dv/tb/spid_upload_tb.sv`) hits this directly:
  four `static task` declarations at module scope
  (`host()`/`sw()`/`read_sram()`/`read_sram_wrap()`, lines 186/293/624/
  663).
- **Empirically validated before implementing:** patched a local
  scratch copy of the real file (never the tracked OpenTitan source),
  removing just the word `static` from all four declarations, and
  confirmed the crash disappeared entirely (clean, ordinary
  diagnostics only) — direct evidence the `static`-triggered syntax
  error, not something else in the file, was the true trigger, before
  investing in a grammar change.
- **Root cause:** `parse.y`'s qualifier-prefixed task/function forms
  (`K_pure`/`K_extern`/`K_virtual`/`K_static`/`K_local`/`K_protected`
  combinations) are reachable *only* from `class_item` — there is no
  `module_item` alternative anywhere that accepts a qualifier keyword
  before `K_task`/`K_function`. The ordinary module-scope form
  (`K_task lifetime_opt IDENTIFIER ...`) puts the optional lifetime
  keyword *after* `K_task` (`task automatic foo();`), not before. A
  bare `K_static`/`K_automatic` token in `module_item` context
  therefore matches no rule at all, forcing bison into genuine
  panic-mode recovery from the very first token — a fundamentally
  different (and far more disruptive) failure mode than an ordinary
  semantic rejection.
- **Fix:** added four new `module_item` alternatives —
  `K_static task_declaration`, `K_static function_declaration`,
  `K_automatic task_declaration`, `K_automatic function_declaration` —
  that accept the illegal qualifier *syntactically* (reusing the
  existing `task_declaration`/`function_declaration` nonterminals
  wholesale, exactly as the already-working, already-correct
  `class_item_qualifier_opt task_declaration` class-method form does)
  and then report a specific, focused error in the trailing action
  (`error_count += 1`). The construct is still rejected — not accepted
  as valid — but through Icarus's ordinary error-reporting path
  instead of bison's unmatched-token panic-mode recovery, so no
  parser-state corruption occurs.
- **Bison grammar-safety check:** shift/reduce conflicts rose from the
  `main` baseline of 562 to 572 (+10, one pair of new alternatives per
  qualifier/declaration-kind combination); reduce/reduce unchanged at
  1122. Confirmed the three pre-existing "rule useless in parser due to
  conflicts" warnings are identical before and after (same three
  locations, unrelated to this change) — no new dead rule was
  introduced. Validated the conflict increase is benign empirically
  (per `[[parse-y-conflict-totals-are-insufficient]]`, totals alone are
  not proof): the full six-gate suite is clean, and targeted reducers
  confirm every legitimate qualifier form still works — class-scope
  `static`/`virtual`/`local static` methods, and module-scope `task
  automatic`/`function automatic` (lifetime *after* the keyword).
- **Permanent regression:**
  `ivtest/ivltests/sv_static_qualifier_module_task_fail.v` (CE — the
  minimal illegal-construct case), registered in
  `ivtest/regress-sv.list`.
- **Validation:** focused 1/1 pass, plus the class/module legitimate-
  usage reducers above (no dedicated ivtest entries needed — existing
  suite coverage of ordinary class methods and `task automatic` already
  exercises these paths, confirmed unaffected by the full sweep). Full
  `.github/ivtest_gate.sh` sweep: `Total=5826, Passed=5821, Failed=0,
  Not Implemented=2, Expected Fail=3`, name-diff gate clean (0
  unexplained). Bundled VPI suite: 108/108. Negative suite: 148/148.
  UVM regression: 357 passed, 0 failed, 0 skipped.
- **Real-world confirmation:** the exact originally-crashing
  `lowrisc:dv:spid_upload_sim:0.1` (`runtime` lane, via the full
  fusesoc/census pipeline, not just a standalone compile) no longer
  crashes — exits with a normal nonzero status and exactly 4 clean,
  specific diagnostics (one per `static task` declaration in the real
  file), matching the number of real illegal constructs present. Not
  claimed as closing this target to `PASS`; the file's own use of the
  illegal construct is a genuine (if minor) upstream issue outside this
  fix's scope — only the crash is closed.


## September 20 review baseline and next compiler batch

DD-040, DD-042 and DD-043 were reopened after their positive-only PR tests
missed selector evaluation, coverage value-tuple, and selector-resolution
failures. Selected local repairs and regression fixtures are described in
the [revision-scoped review record](session_logs/2026-09-20_pr_review_repairs.md).
The operational phases, pending gates and publication state remain in
[ACTIVE_WORK](../../.ai/ACTIVE_WORK.yaml) and [CAMPAIGN](../../.ai/CAMPAIGN.yaml).
The [restored baseline qualification](session_logs/2026-09-20_restored_baseline_qualification.json) records completed local gates.
The positive recursive cross-`with` reducer in the [implementation record](session_logs/2026-09-20_recursive_cross_with.md) passes in both strict editions on clean current `main`. Remaining verified cases are tracked separately: cross-bin `matches` thresholds [#508](https://github.com/dsellerbrock/iverilog-uvm/issues/508) and wildcard-bin `with` value selection [#509](https://github.com/dsellerbrock/iverilog-uvm/issues/509). The 2026-10-08 checks are local, not CI. DD-044 separately records constraint-body translation that drops a requested constraint and is not closed by selector validation.

### IEEE 1800 clause-19 census crosswalk — 2026-10-08

- [#469](https://github.com/dsellerbrock/iverilog-uvm/issues/469) remains the existing issue for DD-087 and PR #464's DD-112 two-state packed bit-select behavior; the clean-main reproducer returns X in both strict editions.
- [#507](https://github.com/dsellerbrock/iverilog-uvm/issues/507) tracks the §19.3 rule that covergroup constructor `output`/`inout` formals are illegal; paired clean-main probes accept both forms.
- [#508](https://github.com/dsellerbrock/iverilog-uvm/issues/508) tracks unsupported cross-bin `matches` thresholds; [#509](https://github.com/dsellerbrock/iverilog-uvm/issues/509) tracks wildcard-bin values in cross `with` predicates. Each has an ordinary-bin passing control and a paired strict-edition failure.
- [#510](https://github.com/dsellerbrock/iverilog-uvm/issues/510) tracks 2023 real-valued coverpoint bins and `type_option.real_interval`; the clean-main paired reducer drops the bin and reports the wrong denominator. Clause-11 tolerance range operators remain [#462](https://github.com/dsellerbrock/iverilog-uvm/issues/462).

IBEX-ROW-ASYNC-RESET-SYNTHESIS has [focused and neighboring runtime evidence](session_logs/2026-09-21_row_async_reset.json); required batch gates remain pending. Ordinary blocking-index dataflow is separate recorded debt.

The [synthesis and wide-index focused checkpoint](session_logs/2026-09-21_synthesis_and_wide_index_focus.json) records paired-edition runtime and neighboring-test evidence. Required broad batch gates remain pending.

The [September 21 local batch qualification](session_logs/2026-09-21_compiler_batch_qualification.json) records the completed regression gates for the documented batch subsets at `8ab943352`. Earlier pending-gate notes describe their dated checkpoints. Overall language and UVM support remain PARTIAL; publication CI is pending.

CONSTRAINT-OBJECT-METHOD-RECEIVER is implemented and focused-tested;
required broad batch gates remain pending. Scope, indexed-receiver limits and
application failures are recorded in the [receiver evidence](session_logs/2026-09-21_constraint_object_method_receiver.json).

ENUM-NAME-BARE-CONCAT-TYPE has [focused paired evidence](session_logs/2026-09-21_enum_bare_name_type.json), with required broad batch gates pending.

SELF-PACKAGE-TYPE-CAST and SIGNED-COVER-BINS-CROSS-ZERO are focused-tested, with required batch gates pending. The [self-package cast repair](session_logs/2026-09-21_self_package_type_cast.json) and [signed coverage range repair](session_logs/2026-09-21_signed_cover_range_resolution.json) have paired focused evidence. Required broad batch gates remain pending.

The [pwrmgr follow-up reducers](session_logs/2026-09-21_pwrmgr_followup_blockers.json) confirm missing indexed packed VPI handles and skipped compound virtual-interface edge waits. These remain open; current selection and ownership are in ACTIVE_WORK.

VARIABLE-OUTPUT-PORT-DIRECTION is reproduced in both editions: external net resolution feeds back into an output variable across a collapsed port. See the [runtime reducer and net/variable controls](session_logs/2026-09-21_variable_output_port_direction.json). The directional port fix is now integrated and focused-tested; see the [installed six-fix evidence](session_logs/2026-09-21_shared_six_focus.json). Broad gates and fresh pwrmgr replay remain pending.

VPI-PACKED-ELEMENT-ACCESS is focused-tested with permanent paired-edition regressions and the affected VPI suite. See [integration evidence and remaining boundaries](session_logs/2026-09-21_packed_vpi_integration.json). Required batch gates remain pending; this is not whole-VPI or application qualification.

CONTINUOUS-STRING-ASSIGN is reproduced in both editions from the unchanged stable Caliptra/Adams Bridge rejection-sampling testbench. The [paired runtime failure](session_logs/2026-09-21_caliptra_continuous_string.json) now has an integrated, focused-tested fix; see [installed evidence](session_logs/2026-09-21_shared_six_focus.json). Broad gates remain pending. Caliptra rejection sampling still has a separately recorded testbench race; fixing string semantics does not establish application success.

### September21 constraint division/remainder by zero

CONSTRAINT-DIVMOD-ZERO is implemented and focused-tested, awaiting required batch gates. Active zero divisors produce constraint evaluation errors; guarded inactive branches remain legal. See [paired evidence and rollback tests](session_logs/2026-09-21_constraint_divmod_zero.json).

### September21 joint ordering with active cyclic variables

JOINT-ORDERED-ACTIVE-RANDC is implemented and focused-tested, pending batch gates. DD-001/Z01 no longer blanket-rejects ordinary ordering alongside cyclic variables. Multiple coupled ordinary distributions in a cyclic component remain open. See [evidence and limits](session_logs/2026-09-21_joint_ordered_randc.json).

The [packed-VPI synthesis regression repair](session_logs/2026-09-21_packed_vpi_synthesis_regression.json) passes paired runtime controls and focused synthesis/VPI suites; required broad rerun remains pending. This repairs VPI-PACKED-ELEMENT-ACCESS and adds no feature count.

The [nine-fix batch qualification](session_logs/2026-09-21_nine_fix_batch_qualification.json) completes required local gates for the integrated September21 fixes through `c1635efe9`. Broader clause/application blockers and private candidates remain open; CI/publication tracked in CAMPAIGN.

### September 21 application foundation batch

COMPOUND-VIF-EDGE-EVENTS, JOINT-ORDERED-RANDC-MULTIDIST, DV-RUNTIME-ROOT-SEED, UVM-STRICT-REGEX-GLOB-FALLBACK, CONTINUOUS-STRING-ASSIGN, and VARIABLE-OUTPUT-PORT-DIRECTION are integrated and FOCUSED_TESTED. The [installed evidence](session_logs/2026-09-21_shared_six_focus.json) owns current results and scope. Required broad gates and fresh pinned application replay are pending; these items are not yet DONE.

The [six-fix broad gate](session_logs/2026-09-21_shared_six_gate_failure.json) found regressions in automatic events and port/synthesis behavior; these are active repair obligations before qualification. The [fresh release replay](session_logs/2026-09-21_shared_six_release_retest.json) advances pwrmgr past its old HDL-path fatal to legacy regex/build errors. OpenTitan crossbar and Caliptra power2round pass their bounded checks; GPIO, pwrmgr and rejection sampling remain failing.

At `1d7e38ce5`, [runtime and startup repairs](session_logs/2026-09-21_event_runtime_regression_repair.json) have focused evidence. COMPOUND-VIF-EDGE-EVENTS remains open for synthesis boundary repairs and complete regression requalification. These repairs add no feature count.

The [private regex attribution](session_logs/2026-09-21_opentitan_regex_attribution.json) identifies the remaining GPIO/pwrmgr startup failure as a pinned application/API usage compatibility blocker. Keep application sources untouched and strict matching intact; no additional compiler implementation is selected from this observation.

PR309 required local requalification now passes on `09316da3d`; see the [revision-scoped gate record](session_logs/2026-09-21_pr309_local_qualification.json). The six-fix batch and its regression repairs await exact-head CI. OpenTitan/Caliptra residual failures remain open; local regression completion does not close those application objectives.

### September 21 descendant VIF event context

OT-PWRMGR-DESCENDANT-VIF-CONTEXT is LOCALLY_REGRESSION_TESTED, with permanent paired regressions and preserved genuine-null rejection. [Evidence](session_logs/2026-09-21_pwrmgr_descendant_vif_focus.json) records removal of the unmodified power-manager time-zero false-null failure; its configured phase timeout and distribution debt remain open. The subsequent [distribution batch](session_logs/2026-09-21_exact_large_dist_focus.json) passed the required broad local gates with this runtime fix included.

### OT-GPIO-EXACT-LARGE-DIST-RANGES — local regression validated

Exact interval sampling replaces the large ground-range weighted-soft fallback for isolated integral subjects and provably singleton expressions. Unsupported coupled/non-singleton cases fail explicitly. [Revision-scoped evidence](session_logs/2026-09-21_exact_large_dist_focus.json) records boundaries, compatibility validation, and GPIO traffic with matched responses. All required local gates passed. GPIO warnings were assessed as valid upstream NBA diagnostics and standards-permitted input coercion; they remain visible. This is not full DV-suite qualification.

### OT-PWRMGR-LOCAL-VECTOR-CLASS-INDEX-EVENT — locally regression-tested, publication pending

IEEE 1800-2017/2023 §9.4.2: `@(local_vector[cfg.index])` missed local-vector changes because class-mutation lowering omitted the ordinary dependency. Synchronous combined registration fixed arming, but a deferred value filter still lost same-slot pulses. The current patch evaluates the complete expression at occurrence time using the existing VVP evaluator, captures selectors/owners once in their original evaluation order, refreshes precise subscriptions on equal values, and schedules the original process only on a value change. Cancellation, context isolation and Reactive arming have focused regressions. [Current revision-scoped evidence](session_logs/2026-09-21_occurrence_event_focus.json) owns results and remaining gates; [candidate1 evidence](session_logs/2026-09-21_mixed_event_focus.json) preserves the earlier failure. All required local gates pass; publication is pending. The unmodified pwrmgr seed3 assertion remains separately recorded debt; no application workaround is selected.

### OT-PWRMGR-SEED3-ESC-TIMEOUT — valid seed; upstream checker defect confirmed

- **State:** Selected current-image copied-source **PASS** with the [edge-counter patch](release_overlays/opentitan/pwrmgr_clock_edge_count.patch). The 138-sample checker contract remains: the focused active and faster-clock controls pass, while a stopped clock still triggers at the expected sample. The one-core matrix run has zero actionable setup warnings, zero hard or semantic compile debt, one checked runtime banner, 43 scoreboard reads, zero UVM/assertion errors or runtime debt, and 666,011,232-byte peak under 4 GiB/120 seconds. An explicit seed-3 replay of the same image also passes with 28 scoreboard reads. Eleven pre-existing benign compiler warnings remain visible; the earlier timestamp overlay adds one mixed-timescale semantic notice and is retained only for historical evidence.
- **Evidence:** [Current selected replay and reducer](../../evidence/opentitan-pwrmgr-clock-edge-count-20260929/README.md); [prior seed-3 revalidation](session_logs/2026-09-21_pwrmgr_seed3_upstream_revalidation.json); [original signal trace](session_logs/2026-09-21_pwrmgr_seed3_phase_assessment.json).
- **Upstream confirmation:** [OpenTitan PR28474](https://github.com/lowRISC/opentitan/pull/28474) fixes this exact sampled-clock failure. Its subsequent port-connection correction is required when evaluating that backport. No VCS differential or VCS-specific defect is established.
- **Boundary:** Pinned OpenTitan and the frozen 23 PASS / 49 corpus remain unchanged; report this checker-overlay run separately. The stronger official heartbeat/`until` backport exposes a separate continuation negative-test failure and is not selected here.

### OT-WHOLE-FUNCTION-CLASS-EVENT — class-method event dependencies

- **State:** REGRESSION_TESTED; required local gates pass for the documented integral-expression subset. [PR #317](https://github.com/dsellerbrock/iverilog-uvm/pull/317) merged after Ubuntu 24.04 CI passed; remaining platform CI was pending at merge.
- **Semantics:** IEEE 1800-2017/2023 §9.4.2 integral event expressions and class method receivers.
- **Evidence:** [Revision-scoped implementation and focused results](session_logs/2026-09-21_whole_function_event_focus.json), including retained baseline failures. Virtual-interface reads inside methods remain explicitly unsupported.
- **Closure:** Correct value-change behavior, ordinary dependency tracking, receiver lifetime/rebinding, unchanged-value suppression and required regression gates. Reuse the existing expression observer; no source workaround.

### OT-SPI-COMPOUND-EVENT-LIST — atomic class-property event lists

- **State:** REGRESSION_TESTED local checkpoint; permanent and mapped UVM gates pass. Broad suites remain at the authorized batch checkpoint; no full qualification claim.
- **Semantics:** IEEE 1800-2017/2023 §9.4.2, pure integral event lists containing class-property reads.
- **Evidence:** [Scoped implementation and validation](session_logs/2026-09-21_spi_class_event_list_focus.json).
- **Application boundary:** Pristine M6 SPI Host advances past this event-list diagnostic but still fails compilation; queue type diagnostics and a selected-event synthesis crash remain.

### OT-SPI-SELECTED-VIF-EDGE — selected virtual-interface edge expressions

- **Status:** REGRESSION_TESTED; all required local gates pass; publication/CI pending.
- **Requirement:** IEEE 1800-2017/2023 9.4.2 and 25.9. Evaluate the complete selected expression with live receiver/index dependencies and the four-state edge table; cancel all registrations on wake/kill.
- **Root cause:** Structural synthesis received a class-property selector without a signal net. The candidate routes selected edge expressions through the synchronous observer and subscribes to actual VIF signal reads.
- **Evidence and qualification:** [Revision-scoped record](session_logs/2026-09-21_selected_vif_edge_focus.json). Pristine stable SPI compilation advances to explicit queue/constraint diagnostics; no SPI DV pass.

### CI-WIN-UVM-REGEX-NOOUTPUT — strict-regex test crashes under MSYS2 TRE regex

- **Status:** DONE. Merged in PR321 (`3ccd5d73`) after all six CI jobs passed; MINGW64/UCRT64/CLANG64 report `uvm_regex_strict_exec_test PASS` and UVM 358/358.
- **Observation:** Every MSYS2 job since merged PR317 fails `uvm_regex_strict_exec_test` with no captured output; Linux and macOS pass.
- **Root cause:** Vendored `uvm_re_comp` calls `regfree` on a `regex_t` whose `regcomp` failed. POSIX leaves that undefined; TRE (libsystre) segfaults on the test's first invalid pattern. TRE also rejects legal 2048-character patterns with REG_ESPACE when submatch tracking is on.
- **Fix:** The fork-owned wrapper skips `regfree` for exactly the buffer that failed to compile. It adds `REG_NOSUB`, which leaves every match result unchanged because the vendored `regexec` passes `nmatch=0`. The UVM runner now reports the vvp exit status for no-output failures. Pinned UVM sources are unchanged.
- **Evidence:** [Revision-scoped record](session_logs/2026-09-22_win_regex_tre_fix.json); Linux TRE reproducer `evidence/win-regex-tre/`.

### SVA-IMPLICATION-UNTIL-CONTINUATION — locally regression-tested; merged in PR319 (`288132f2`)

The upstream OpenTitan checker backport exposed missed late `until` violations. The compiler correction covers property truth, empty/nonempty repetition concatenation and independent consequent timing. [Revision-scoped evidence](session_logs/2026-09-21_until_continuation_focus.json) owns the exact subset, tests and pending gates. This does not qualify the pristine application or the complete assertion language.

### OT-SPI-INLINE-CALLER-QUEUE-FOREACH — locally regression-tested

Direct caller-owned integral queue/dynamic-array iteration now has paired focused evidence, including target-first lookup, signed values, invalid-state rejection and rollback. The pristine SPI compile no longer rejects this foreach; independent errors remain. [Revision-scoped evidence](session_logs/2026-09-22_caller_queue_foreach_focus.json) owns results and passing required local gates. Merged in PR320 (`1af223c8`); Linux/macOS CI jobs passed on the preceding main run, and the MSYS2 failure is CI-WIN-UVM-REGEX-NOOUTPUT. No full application qualification is claimed.

### OT-SPI-INLINE-STATE-FUNCTION-CALL — merged state-only scope

- **Status:** State-only scope merged in PR323; staged random-variable arguments remain open.
- **Requirement:** IEEE 1800-2017 §18.5.12 / 2023 §18.5.11 function calls in inline randomize constraints, with §18.7 call semantics.
- **Evidence:** [Revision-scoped focused record](session_logs/2026-09-23_inline_state_function_focus.json). The bounded state-only caller/target/self path preserves post-`pre_randomize` state, four-state rejection, virtual dispatch, and retained target identity. The record lists remaining argument and width limits; no complete clause or SPI DV qualification is claimed.

### OT-SPI-INLINE-CALLER-OBJECT-METHOD — caller-scope object methods in inline constraints

- **Status:** RECONCILED during direct-main integration after PR323. PR322 closed without merging. Its earlier implementation (`ce2635bd`) captured the call before OT-SPI-INLINE-STATE-FUNCTION-CALL's guarded caller capture and bypassed null-receiver, X/Z, purity/direction and width checks, so it was omitted. Retained caller-method tests pass against PR323's guarded source; the extra collision and boundary regressions merged in PR324 (`ea0be16d5`). The record below is PR322's historical state (REGRESSION_TESTED locally at `ce2635bd`).
- **Requirement:** IEEE 1800-2017 18.5.12/18.7 and 1800-2023 18.5.11/18.7. Inline names resolve target-first, then in the caller. A function in a constraint is called before solving, and its result is a state value.
- **Reproducer:** pristine Earlgrey-PROD-M6 `spi_device_cmd_rsp_seq.sv:117` (`num_lanes == cfg.get_sio_size()`) and `evidence/inline-caller-method/caller_method.sv`. Both editions reported "could not be translated".
- **Root cause:** Object-method state capture existed only for declared class constraints (`constraint_ir_state_calls_ctx_`). Inline caller-scope method calls had no lowering.
- **Historical PR322 fix:** Captured a caller call as a value slot before the guarded lowering; this code was removed. The current guarded state-function path also handles target-member receivers and rejects invalid null/X/Z captures. Indexed receiver calls remain unsupported.
- **Evidence:** [PR322's revision-scoped record](session_logs/2026-09-22_inline_caller_object_method.json) is historical; the [local qualification](session_logs/2026-09-23_pr322_reconciliation.json) and [branch reconciliation](session_logs/2026-09-23_pr322_branch_reconciliation.json) own the current limits. No DV claim.

### VVP-EXTENDED-ARGS-GLIBC-PERMUTE — vvp extended arguments parsed as options on glibc

- **Status:** Committed directly to `main` as `3505e15a6`; CI pending on that main revision.
- **Authority:** `Documentation/usage/vvp_flags.rst` (Extended Arguments) and `vvp.man`: options precede the design file; everything after it is an extended argument.
- **Root cause:** `vvp/main.cc` dropped upstream's leading `+` from the getopt string, so glibc permutation parsed post-file arguments such as `-vcd`/`-none` as vvp options. JSON tests `br_gh710a/b/c`, `dumpfile` and `sdf_header` failed on Linux; macOS getopt hides this.
- **Fix:** Parse options in order and set aside `+plusargs` that precede the options (dvsim ordering) until the input file. The simulation then sees the file, all plusargs in command-line order, then the extended arguments.
- **Evidence:** [Revision-scoped record](session_logs/2026-09-22_vvp_extended_args.json); new permanent JSON test `vvp_plusarg_order`.

### CONSTRAINT-UNIFORM-LEGAL-COMBINATIONS — unordered solutions are not uniform

- **2026-10-16 #416 follow-up:** Direct-scalar coupled components with a member wider than 64 bits now reservoir-sample complete legal tuples after 64 rejected proposals when at most 1,024 tuples exist. Wider-cardinality projections and unsupported soft, array, or member shapes retain the existing fallback; the 1,025-tuple 65-bit control checks legality only, not uniformity. The 257-tuple positive and unsatisfiable rollback regressions are registered in both editions and both harnesses. See [focused evidence](../../evidence/solve-before-array/sparse-wide-coupled-20261016.md).

- **Status:** Historical CI snapshot recorded on main HEAD `fc9d8b86`: PR #409 run #1538 and main push run #1539 each had six jobs queued; PR #404 was green on all six platforms (run #37557795249). This is historical local/CI evidence only; current CI was not checked. Broader clause 18 remains PARTIAL. Paired 2017/2023 evidence covers coupled direct scalars, connected scalar properties wider than 64 bits, isolated wide scalars constrained to one interval or unions of feasible intervals, one-dimensional fixed unpacked bit arrays including a 129-element declaration, 2×2 and 2×2×2 fixed arrays, and variable-size direct integral/enum arrays, including a 1,025-size singleton-enum domain. Arrays with constrained elements use a joint solver model capped at 512 aggregate elements. Arrays with no constrained element leaves use SAT-derived feasible size endpoints and exact cardinality-weighted proposals up to the existing per-container 65,536 allocation cap; sparse holes may need many solver rejections. Small wide unary domains are enumerated through 256 values; larger connected domains use full-width proposals with hard-solver rejection capped at 4,096 attempts per coupled component; an exhausted component falls back to the existing non-uniform solver path. Isolated direct scalar properties wider than 32 bits and at most 4,096 bits first try 64 uniform full-domain proposals, then use exact interval sampling with a total budget of 131,072 SAT boundary queries per randomization. If interval search becomes indeterminate, the sampler tries up to 65,536 more uniform proposals and fails explicitly if it still cannot decide. The registered dense periodic 33-bit regression now gives bins `100,89,111/300`, versus `73,74,153` on the old fallback; the registered 33-run oracle remains within its 1–22/bin threshold. The full registered uniformity suites and adjacent failure-rollback and fixed-array solve-before controls pass under strict 2017 and 2023 on the fix-12 image. The 257-bit [1:1024] oracle produces bins 40,54,53,53/200 after the old fallback produced 26,14,26,134. Fixed-array sampling has no declared-size cap when constraints reference supported leaves. Sparse wide domains above 256 and sparse array-size domains can take impractically many retries; fixed-array ranks above three, other shapes and container types, direct scalar randc domains with more than 1,024 exact values, static/unconstrained wide randc properties and graph-coupled wide randc forms beyond the tested local or reachable object-path scalar cases, sparse randc proposal-budget exhaustion, and dynamic-array randc leaves wider than 20 bits remain open except for bounded one-dimensional integral leaves 21–64 bits whose full feasible set is exactly enumerable within 1,024 values. Non-static single-owner direct scalar leaves 21–64 bits are also covered only under that exact-domain bound. Parent constraints may reference those dynamic-array leaves through constant indices; nested, queue, associative, multidimensional, and struct/member randc forms remain open, as do ordering, soft-preference coupling beyond the tested bounded shapes, and weighted `dist`. A paired direct 11-bit randc regression constrained to `[0:127]` completes two duplicate-free 128-value cycles, with an unsatisfiable call between them to check rollback.
- **Issue #416 selection (2026-10-09):** #416 remains OPEN on refreshed `origin/main` `c339b9f2287a743aeb7ab6de6528e8d34a4dd602`. Draft [PR #526](https://github.com/dsellerbrock/iverilog-uvm/pull/526) contains the local change. The three-tuple reducer produces `64,26,30/120` on the refreshed baseline in both editions. The local branch now traverses the full projected tuple set and reservoir-samples eligible connected direct-scalar components without a cardinality cap; traversal is bounded by the finite bit-vector product, while solver blocking state grows with tuple count. A pre-patch 2017 probe of the 4,097-tuple boundary selected its singleton 3/4 times. Paired sparse positive, UNSAT rollback, and 4,097-tuple boundary controls pass 2/2 in legacy and JSON/VVP; adjacent sampling-failure controls pass 2/2 in each runner. Widths above 64 bits and pending-soft, array, and member components remain unsupported. See [local evidence](../../evidence/solve-before-array/sparse-coupled-uniform-sampling-20261009.md). No CI status was checked.
- **Sampling boundary:** After 64 rejected proposals, eligible connected direct-scalar components with widths up to 64 bits and no pending soft constraints are enumerated up to 4,096 complete tuples, then sampled uniformly using an existing property-owned RNG stream. Dense components retain rejection sampling. Solution sets above 4,096 tuples and unsupported soft, wide, array, or member components retain the existing solver fallback; only over-cap legality is tested, not uniformity. The broader uniformity requirement remains PARTIAL.
- **Requirement:** IEEE 1800-2017 18.5.10 / 1800-2023 18.5.9: "The solver shall assure that the random values are selected to give a uniform value distribution over legal value combinations."
- **Reproducer:** `evidence/solve-before-array/ieee_table_18_2_uniformity.sv`, the standard's class B (`s -> d == 0`, 32-bit `d`). Before this fix, the current engine gave `s == 1` in 251 of 1000 unordered draws; with `solve s before d` it gave 489 of 1000. The paired regression previously failed at 61 unordered `s == 1` results in 256 draws and now passes under both `-g2017` and `-g2023`. The two-element fixed-array fallback sampled its constrained mode 161/500 times; before this fix the 129-element case sampled mode one 155/500 times. Both one-dimensional histograms meet the 70–130/500 threshold in each edition. The 2×2 fixed-array oracle previously sampled its mode-one tuple 267/1000 times; all 17 tuple bins now fall between 30 and 90/1000 in both editions. A 129-tuple wide-scalar case previously selected its 128-value mode 520/1000 times and 101/200 times with the registered seed; the new paired result is 196/200. A dense 65-bit component with `mode -> value != 0` previously chose mode one 150/200 times; full-width rejection now chooses it 200/200 times in both editions. The new 65-bit isolated `[1:1024]` oracle failed before interval sampling at 23/200 in its first 256-value bucket; it now yields `57, 54, 37, 52` across four equal buckets in both editions. A pre-union probe with two equal 512-value ranges failed at 22/200 in its first bucket; the registered unequal-range oracle now keeps all four equal-cardinality bins within 30–70/200. The 33-bit dense periodic reproducer had three equal legal residue classes but gave counts `73,74,153/300` on the old Optimize fallback; the paired exact rejection sampler now gives `100,89,111/300`. The 128/129-element dynamic-array probe previously sampled mode-one 139/300 times; after the cap fix it samples 91/300, within the 70–130/300 bound, and the larger-size count is 209/300. The 256/257-element probe previously sampled its size-256 mode 166/300; with a 512-element cap it samples 44/120, while the larger-size mode appears 76/120. A 2×2×2 fixed-array oracle samples its nine complete legal tuples within 12–55/300 in both editions. A variable-size enum array with three declared values and sizes one or two failed at 67/53 out of 120 before fix 6; the exact sampler produces 29/91 against an expected 30/90. The dynamic-array reproducer's historical 103/400 result predates the complete-tuple array sampling slices.
- **Root cause:** the single-owner path could keep a satisfying prefill or fall back to per-property sampling/Optimize diversity after a coupled tuple failed. An isolated scalar wider than the finite enumeration cap also fell directly to Optimize diversity, which biased large contiguous ranges and fragmented sets. Variable-size arrays also had their size and elements solved in separate passes; domains exceeding the bounded exact-sampling cap fell back to diversity optimization and biased size marginals. The fixed-array sampler additionally capped declared extent at 128 and materialized unreferenced leaves just to include them in the joint tuple; connected wide properties fell out of exact tuple sampling when a unary domain exceeded 128 values. The variable-size array eligibility gate excluded enum-element arrays, and synthesized elements did not inherit their declared literal domains.
- **Scoped implementation:** The current branch rejection-samples whole coupled tuples for active direct scalar class properties, directly referenced fixed-array leaves, and active direct integral or enum elements of bounded one-dimensional dynamic arrays, applying declared enum domains to synthesized active slots. The fixed-array solver path uses flat class storage and element IDs across unpacked ranks; paired statistical coverage includes one-dimensional arrays and 2×2 and 2×2×2 arrays. Connected scalar components use enumerated feasible unary domains for >64-bit variables when those domains contain at most 256 values; larger domains use full-width uniform proposals and reject tuples against the hard solver, which is exact but can be slow for sparse sets. An isolated direct scalar wider than 32 bits and at most 4,096 bits, with no solve-before, `dist`, soft, `randc`, state-check, or queue-element side path first receives up to 64 exact uniform proposals over its full bit-vector domain; sparse domains then use exact interval-boundary searches under a total budget of 131,072 SAT checks per randomization. If a boundary search is indeterminate, up to 65,536 additional uniform proposals are tried; if exact sampling still cannot decide, randomize fails instead of silently using a biased fallback. For variable-size arrays, constrained element leaves are modeled with canonical inactive padding and a 512-element aggregate ceiling. Unconstrained direct integral/enum array leaves are omitted from the solver model; feasible sizes are weighted by element cardinality and sampled jointly with connected properties. SAT binary searches find size endpoints within the existing 65,536 per-container cap; holes and connected constraints are rejected by the shared solver, so sparse accepted sizes may take many retries. Fixed integral/enum arrays likewise add only element variables already referenced by supported constraints; unreferenced leaves remain independently randomized. Non-enumerable ordinary components outside this exact path may use an explicit warned solver-checked fallback, which is not uniformity evidence. Direct scalar randc first uses the existing small-set enumerators. If they cannot finish, fields within the existing 20-bit history limit use uniform bit-vector proposals checked against the hard solver and committed cycle history. A SAT query over the unseen complement proves whether the current legal cycle is exhausted; any reset is staged with the successful value. The scalar path is paired-tested through two constrained 128-value cycles. Direct one-dimensional dynamic-array leaves use the same rejection sampler and are paired-tested through a graph-coupled 1,025-value cycle with rollback and reset. Both paths fail explicitly on unknown solver results or after 65,536 proposals. A separate sparse-history path handles non-static single-owner direct scalar randc leaves 21–64 bits only when the entire feasible domain is exactly enumerable and at most 1,024 values; static, unconstrained and larger scalar forms, plus graph-coupled forms not referenced by an enabled local constraint or reachable direct object path, plus nested, queue, associative, multidimensional, or struct/member randc forms, remain outside this slice. Ordering, weighted `dist`, soft-preference shapes outside the tested direct-scalar and bounded dynamic-array paths, member variables, symbolic state reads, absent dynamic-array elements, cases beyond both exact-work budgets or wider-than-4,096-bit unconnected wide scalars, fixed-array ranks above three, and unsupported shapes remain outside the exact slice. Proven independent factors are sampled separately; otherwise the active tuple is sampled as one unit. See [paired focused evidence](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md). This does not close the broader requirement.
- **Closure bar:** keep sparse large-domain and non-contiguous size sampling practical while preserving exact uniformity, and cover wide scalar interval searches beyond the current query budget, widths above 4,096 bits, fixed-array ranks above three, other array shapes, container members, graph-coupled wide scalar randc outside the supported local or reachable object-path direct scalar cases, static wide scalar randc, unconstrained wide randc, domains above the 1,024-value sparse-history enumeration cap, sparse legal domains that exceed the 65,536-proposal work budget, and aggregate/container randc forms, plus ordering, soft-preference coupling beyond the tested direct-scalar and bounded fixed-size dynamic-array cases, and weighted-`dist` semantics. Keep paired statistical oracles, deterministic seeds, object RNG ownership, and failure rollback; unsupported paths must not silently return a biased sample.

- **Fix 14 update:** Active explicit soft expressions now connect eligible direct-scalar and bounded dynamic-array variables before uniform component sampling. The scalar soft-only reducer reports `945,1012,1043/3000` in both editions, versus `948,916,1136/3000` before the fix. A fixed-size two-element dynamic-array reducer reports `1004,1009,987/3000`, versus `718,751,1531/3000` before its eligibility repair. The registered paired checks bound the scalar bins to 900–1,100/3,000 and array bins to 300–500/1,200; inherited-soft, alias-soft, and source-priority controls pass 3/3 per edition. Broader container/member soft forms and full clause-18 qualification remain open. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#satisfiable-soft-constraints-join-uniform-tuple-factors-fix-14).

- **Fix 15 update:** A fixed-array `foreach` soft preference over `mode` and two payload bits has five equally preferred complete tuples. The paired reducer yields `594,590,592,612,612/3000` in each edition; the pre-fix runtime yielded `476,513,543,508,960`, over-weighting one tuple. The three tuples violating a soft clause remain absent. This adds one common fixed-array soft shape; broader member, ordered, and weighted-`dist` combinations remain open. Both registered suite sources compile; the full suites are deferred to the 10-fix checkpoint. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#soft-foreach-over-fixed-array-elements-fix-15).

- **Fix 16 qualification:** 2017 §18.5.8.1 and 2023 §18.5.7.1 require dynamic-array size constraints to be solved before iterative `foreach` constraints. A paired soft-`foreach` reducer verifies this two-stage distribution at `380,393,390,371,1466/3000`: two `(mode,size)` outcomes are equiprobable first, then payload values are uniform within the selected size and satisfy the soft preference. This protects the implicit ordering from being flattened into five equally likely final tuples. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#soft-foreach-with-variable-dynamic-array-size-preserves-implicit-ordering-fix-16).

- **Fixes 18–19:** The exact hard-solver rejection sampler now handles a graph-coupled scalar `randc` field and a non-nested fixed-array `randc` leaf when their feasible domains exceed the 1,024-value enumeration cap. The paired fixed-array reducer completes the full 1,025-value constrained cycle and starts the next cycle under strict 2017 and 2023. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#graph-coupled-fixed-array-randc-leaves-beyond-full-domain-enumeration-fix-19).

- **Fix 20:** Removed the blanket rejection of active soft constraints on cyclic object graphs. A paired two-object cycle verifies that both objects honor `soft value == 2`, that a hard-unsatisfiable retry preserves prior values, and that randomization recovers after feasibility is restored. This is one bounded graph shape; broader cyclic soft combinations and the full registered suites remain open. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#soft-priority-on-cyclic-object-graphs-fix-20).

- **Fix 21:** Graph-coupled randc elements in one-dimensional direct dynamic arrays now use exact hard-solver rejection when their domain exceeds the 1,024-value enumeration cap. The transaction stages a mark before array writeback and resolves it after resize, so the initially empty array's first selected value is retained. The paired strict 2017/2023 regression completes the 1,025-value cycle, checks an unsatisfiable rollback, and verifies reset after exhaustion. This covers integral elements up to the existing 20-bit history and 65,536-proposal limits; nested, queue, associative, multidimensional, and struct/member aggregates remain open. Full registered suites remain deferred to the ten-fix checkpoint. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#graph-coupled-dynamic-array-randc-first-draw-and-cycle-fix-21).

- **Fix 22:** Non-static single-owner scalar randc properties from 21 through 64 bits now cycle when the hard solver exactly enumerates their complete feasible set, capped at 1,024 values. Sparse history is transactionally committed, resets only after all currently feasible values have been used, and caps at 65,536 stored values per property. The paired `randc int unsigned` regression completes 12 three-value cycles, including an unsatisfiable call during each cycle; the existing graph-coupled/container-wide history controls still fail closed. Static, unconstrained, graph-coupled, larger, and aggregate wide randc forms remain open. The full registered suites remain deferred to the ten-fix checkpoint. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#bounded-sparse-history-for-constrained-wide-randc-fix-22).

- **Fix 23:** Eligible graph-coupled direct scalar randc properties from 21 through 64 bits now use the same sparse-history path when an enabled owner constraint references the property and the entire feasible domain is exactly enumerable at no more than 1,024 values. The paired regression traverses all 101 values, checks an unsatisfiable retry rolls back both graph objects, and verifies cycle reset. Graph domains above the enumeration cap, aggregate properties, and unconstrained properties remain explicit fail-closed controls. Focused strict 2017/2023 JSON and legacy harnesses each pass 4/4; full registered uniformity suites remain deferred to the ten-fix checkpoint. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#owner-referenced-graph-coupled-wide-randc-fix-23).

- **Fix 24:** A non-static scalar wide `randc` child is now admitted when a parent or other reachable enabled constraint references it through an object path. The solver still proves the complete feasible set under the 1,024-value cap before committing history; unreferenced, oversized, and aggregate forms continue to fail closed. The paired regression completes a 65-value parent-constrained cycle, verifies parent/child rollback on an unsatisfiable attempt, and checks reset. Focused strict JSON and legacy harnesses pass 4/4 each. Full registered uniformity suites remain deferred to the ten-fix checkpoint. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#parent-referenced-graph-randc-property-paths-fix-24).

- **Fix 26:** Parent constraints can now reference constant-index elements of a child's one-dimensional dynamic-array `randc` property, with the same exact 1,024-value domain cap and transactional sparse history. The paired 21-bit `[0:64]` regression completes all 65 values, checks rollback/reset, and keeps a 1,025-value fail-closed control. Focused strict 2017/2023 JSON and legacy harnesses each pass 2/2. Other aggregate shapes remain open; full registered uniformity suites are deferred to the ten-fix checkpoint. Evidence: [focused record](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#parent-referenced-wide-dynamic-array-randc-elements-fix-26).

- **Fix-26 checkpoint:** the full paired registered uniformity suites pass on VVP `e852bd40e42b279bd44e9fcb2665063b6106000112025cfd25e2e7da7a8a4787`; 2017 is 229.09 s / 49,905,664-byte maximum RSS and 2023 is 198.16 s / 50,987,008-byte maximum RSS. The adjacent failure-rollback and fixed-array `solve-before` positive/negative gates pass 6/6 in both legacy and JSON/VVP harnesses. This qualifies the registered suite checkpoint, not residual aggregate `randc` forms or clause 18. See [full checkpoint evidence](../../evidence/solve-before-array/uniform-legal-combinations-20261006.md#full-uniformity-checkpoint-on-the-fix-26-image-2026-10-06).

### CONSTRAINT-UNIFORM-DYNAMIC-ARRAY-LEGAL-COMBINATIONS — dynamic-array tuples are biased

- **Status:** PARTIAL. Variable-size arrays whose constrained elements are modeled pass paired regressions up to a combined 512-element solver model. Direct integral/enum arrays with no constrained element leaves use SAT-derived size endpoints and exact cardinality-weighted proposals, up to the existing 65,536 per-container allocation cap. The registered 512/513 size-ratio case passes in both editions with its first unconstrained element also randomized. SAT endpoint searches cover large size intervals up to the existing allocation cap; sparse holes remain a performance limit, and other shapes remain open.
- **Requirement:** IEEE 1800-2017 §18.5.10 / IEEE 1800-2023 §18.5.9 require uniform distribution over legal value combinations. Array size is exactly two in this reproducer.
- **Reproducer:** `evidence/solve-before-array/dynamic_array_order.sv`. The historical report records unordered `m == 1` in 103/400 draws. The registered paired regression now checks the same legal-tuple imbalance plus a `solve m before q` control: unordered `m == 1` must be at most 3/128; ordered `m == 1` must be 40–88/128.
- **Expected:** With `rand bit m`, `rand bit [7:0] q[]`, `q.size() == 2`, and `foreach (q[i]) m -> q[i] == 5`, there are 65,536 legal tuples with `m == 0` and one with `m == 1`; unordered `P(m == 1) = 1/65,537`. With `solve m before q`, the marginal for `m` is approximately uniform.
- **Root cause:** the former direct-scalar eligibility gate rejected `builder.elem_vars` and `builder.size_vars`, so the dynamic-array case fell through to per-element diversity sampling instead of sampling complete legal tuples.
- **Scope:** One class owner; active direct scalar properties and direct integral or enum elements of one-dimensional dynamic arrays. Constrained element leaves are modeled, use declared enum domains, and are capped at 512 aggregate elements. When an array has no constrained element leaves, size values are weighted by the number of element tuples; feasible size endpoints use SAT binary searches up to the existing 65,536 per-container allocation cap. Sparse or highly coupled size domains can require many solver rejections. Queues, associative/nested/member arrays, `randc`, ordering, `dist`, broader soft-preference coupling, absent elements, and symbolic state checks remain open.
- **Acceptance:** The permanent paired-edition regression checks scalar controls, fixed-size unordered/ordered cases, five tuples for the 1/2-size array, eleven tuples across empty/1/2-size arrays, twelve tuples across two correlated arrays, the complete-tuple 64/65-element size ratio, a 65-tuple 65-bit scalar split with a 64:1 mode ratio, 128/129- and 256/257-element arrays with 2:1 size-multiplicity ratios, plus a 3:9 enum-array size ratio and a 1,025-size singleton-enum array with four equal-size bins, under strict `-g2017` and `-g2023`. The wide-domain oracle requires mode one at least 90/100 times; with the prior 64-value cap it was 49/100. Larger or unsupported cases do not count as covered.
- **Sparse-size follow-up (2026-10-16):** A dedicated paired-edition reducer covers legal sizes `{1,3}` with six equal complete tuples, a contradictory size-2 request with state rollback, and the existing 512/513 boundary. The six-tuple interpretation is scoped to non-iterative constraints without `solve...before`; the explicit size-first rules apply when size constraints combine with foreach or array-reduction constraints (§18.5.8.1/.2, 2017; §18.5.7.1/.2, 2023). Clause 18.4's resize-then-randomize wording describes operation sequence; no general probability ordering is stated. The embedded precursor passed T0/T1 on Slurm job 1783; standalone test and mutation verification are pending. See the [revision-scoped record](session_logs/2026-10-16_dynamic_array_sparse_size_uniformity.md). The broader requirement remains PARTIAL.

### SOLVE-BEFORE-FIXED-ARRAY — whole fixed rand arrays in solve...before

- **Status:** Core expansion committed directly to `main` as `bea0a4db3`; the non-integral element guard is locally qualified on the follow-up branch, with CI pending.
- **Fix:** A whole 1-D fixed array (class property or unpacked-struct member) expands to its elements. Non-rand arrays are diagnosed and multidimensional whole arrays are a loud sorry on main. The follow-up diagnoses non-integral elements, including class handles, instead of fabricating order tokens. The original [PR322 record](session_logs/2026-09-22_solve_before_fixed_array.json) is superseded for that guard by the [local qualification](session_logs/2026-09-23_pr322_reconciliation.json) and [branch reconciliation](session_logs/2026-09-23_pr322_branch_reconciliation.json). IEEE 1800-2023 real ordering remains separate debt.

### DPI-EXPORT-DROPPED-EXIT-STATUS — unsupported DPI export dropped with exit 0

- **Status:** Committed directly to `main` as `c7b2a8267`; local regressions pass and main CI is separate.
- **Root cause:** `tgt-vvp/vvp_scope.c` reports `sorry: ... The export is dropped` but did not count an error, so code generation succeeded. The negative tests passed in CI only because a non-root user cannot create `/dev/null.dpiexport.c`.
- **Fix:** Count the dropped export in `vvp_errors`. The existing negative tests `m10_dpi_export_class_handle_argument` and `m10_dpi_export_open_array_argument` now pass independently of the environment.

### OT-OTP-STREAM-FIXED-UARRAY-SLICE — focused fix, release compile still blocked

- **Scope:** A direct constant slice of a one-dimensional fixed unpacked array now streams its selected words in declared direction. Class-property offsets use the declared array origin. An unlisted virtual-interface modport member is rejected for both sliced and whole-array streaming, matching ordinary reads (IEEE 1800-2017/2023 §§11.4.14, 25.5).
- **Evidence:** [Paired reducers and pinned replay](../../evidence/opentitan-otp-stream-fixed-slice-20260924/README.md). The seven `otp_ctrl_scoreboard.sv:168/175/198/200/201/227/238` errors disappear; pinned `otp_ctrl_sim` still exits 17 with 16 explicit errors. `chip_sim` retains its existing entropy-source assertion abort. Neither has DV runtime evidence from this compile.
- **Boundary:** Fixed class-property slice-to-queue assignments at scoreboard lines 1373–1377, virtual-interface array marshalling, and strict mixed-driver overlaps remain separate blockers; packed-parameter `foreach` is addressed below. Multiple ordinary stream operands containing a slice and a pre-sliced operand followed by `with` remain outside this increment.

### OT-OTP-PACKED-PARAM-FOREACH — focused fix, release compile still blocked

- **Scope:** A resolved packed parameter now iterates over its declared indices using the existing static `foreach` loop builder. Sign-only and untyped integral parameters use their inferred logic-vector range; explicit scalar and built-in atom targets still reject (IEEE 1800-2017/2023 §§6.20.2, 12.7.3).
- **Evidence:** [Paired reducers, focused checks, and pinned replay](../../evidence/opentitan-otp-packed-param-foreach-20260924/README.md). Pinned `otp_ctrl_sim` loses its `FATAL_EXP_STATUS` line-294 error but still exits 16 with 15 explicit errors. `chip_sim` retains 48 explicit errors and its existing sensitivity assertion abort. Neither has DV runtime from these compiles.
- **Boundary:** Fixed class-property slice-to-queue assignments are addressed below; virtual-interface array marshalling and strict mixed drivers remain separate OTP blockers.

### OT-OTP-FIXED-SLICE-TO-QUEUE — focused fix, release compile still blocked

- **Scope:** A one-dimensional fixed unpacked-array slice assigned to a plain queue now copies selected packed-integral elements in declared order. Direct arrays and simple class properties are supported; bounds, direction, element type, local/protected declaring-class visibility, and modport access are checked. A packed scalar part-select no longer silently converts to a queue (IEEE 1800-2017/2023 §§7.4.6, 7.6, 8.18).
- **Evidence:** [Paired reducers and pinned replay](../../evidence/opentitan-otp-fixed-slice-queue-20260924/README.md). Pinned `otp_ctrl_sim` loses all five `otp_ctrl_scoreboard.sv:1373-1377` errors but still exits 11 with 10 explicit mixed-driver errors. `chip_sim` retains 48 explicit errors and its existing sensitivity assertion abort. Neither has DV runtime from these compiles.
- **Boundary:** Simple blocking queue targets only; object-backed elements and selections above 65,536 elements reject loudly. Independent review found pre-existing external protected/inherited local visibility false acceptance in scalar and whole-array property reads; this fix rejects those cases on its new slice path only. Remaining OTP strict mixed drivers and chip sensitivity assertion require separate root-cause work.

### OT-ALERT-ESC-CLOCKING-OUTPUT-ALIAS — focused fix, release compile still blocked

- **Scope:** A virtual clocking-output write to a declared, disjoint raw member no longer falsely conflicts with a continuous assignment to another member. Output aliases use their declared raw target; unresolved mappings stay conservative. Successful static and same-scope output writes to the continuously driven member now reject, while an unwritten clocking-output declaration stays legal. The same-member rejection also holds with `-gcommercial-unsafe` (IEEE 1800-2017/2023 §§10.4.2, 14.4, 14.16).
- **Evidence:** [Paired reducers and pinned replay](../../evidence/opentitan-alert-clock-output-driver-20260924/README.md). The pinned `otp_ctrl_sim` loses ten `alert_esc_if.sv` mixed-driver errors and reaches one unsupported fixed unpacked-array virtual-interface task argument at `otp_ctrl_base_vseq.sv:411` (compile exit 1, no explicit errors). `chip_sim` retains 48 explicit errors and its existing `entropy_src_core.sv:3324` sensitivity assertion abort. Neither has DV runtime.
- **Boundary:** Only proven clocking-output identity is treated as disjoint; unknown or colliding generated-property names remain conservative. Virtual-interface fixed-array task marshalling and the chip sensitivity assertion are separate blockers. Caliptra's selected 52 still use explicit `-gcommercial-unsafe` as a nonstandard compatibility profile, with their original checks intact.

### OT-OTP-VIF-FIXED-INPUT — focused fix, OTP compiles but DV fails at time zero

- **Scope:** A class-held virtual interface can copy a compatible, whole one-dimensional packed-integral fixed unpacked array into the selected input task. Automatic and static task runtime tests check selected instance, declared order, four-state values, and caller isolation. Incompatible size/type/scalar actuals reject; omitted/default arrays, output/inout/ref arrays, multidimensional arrays, and fixed-array functions remain loud limitations (IEEE 1800-2017/2023 §§7.6, 13.5.1, 25.9).
- **Evidence:** [Paired reducers and pinned replay](../../evidence/opentitan-otp-vif-fixed-input-20260924/README.md). Private ivl `302d7094` passes paired 22/22, registered JSON 13/13, legacy 4/4, neighboring VIF JSON 44/44, negatives 155/155, and real-DPI UVM 358/358. Pinned `otp_ctrl_sim` compile exits zero with no hard errors or assertions, but 46 nonfatal `sorry` diagnostics remain (six dropped covergroup bins and 40 procedural-continuous-assignment warnings). Its released smoke still fails DV at time zero: `mem_bkdr_util.sv:76` rejects an OTP RAM path string with 18 leading spaces; there is no meaningful traffic or pass marker. `chip_sim` remains a compile failure with 48 explicit errors and one sensitivity assertion.
- **Boundary:** The pinned memory-path macro formatting and chip sensitivity are separate blockers. No OpenTitan application pass or full §§7.6/13.5.1/25.9 qualification is claimed.

### OT-OTP-BACKDOOR-PATH-COMPAT — RAM path repaired; next cfg blocker exposed

- **Failure:** The first released OTP smoke fails at time zero in `mem_bkdr_util.sv:76`: `uvm_hdl_check_path` receives 18 leading spaces before an otherwise existing OTP RAM hierarchy. VVP exits zero after a UVM fatal and 512 follow-on assertions, without meaningful DV traffic or a pass marker. [Exact compile, runtime, and path provenance](../../evidence/opentitan-otp-vif-fixed-input-20260924/README.md).
- **Fix and evidence:** The [hash-checked disposable overlay](release_overlays/opentitan/otp_mem_path_overlay.py) flattens only those two macro bodies. [Paired 2017/2023 controls and the exact pinned replay](../../evidence/opentitan-otp-backdoor-path-overlay-20260924/README.md) confirm the emitted path loses the 18 spaces and the RAM backdoor fatal clears, while hierarchy, `$size`, `$bits`, ECC, and the fatal check remain. Compile exits zero with no hard errors but still emits 46 nonfatal `sorry` diagnostics, including dropped coverage bins, and warns that a constraint item is ignored. These remain separate qualification gaps.
- **Remaining failure:** The released `otp_ctrl_smoke_vseq` is 0/1 DV at time zero: `otp_ctrl_env_cfg.randomize()` hits the existing unresolved joint-distribution random-guard restriction, followed by one UVM_FATAL and 512 end-of-simulation assertion errors. There is no pass marker or meaningful traffic despite VVP exit zero. Paired nested-object reducers reproduce that distinct solver failure in both editions; next work belongs to `OT-CSRNG-CFG-JOINT-DIST`.
- **Boundary:** This is a release-compatibility path, not an IEEE macro-conformance result or an OpenTitan DV pass. The pinned checkout and shared installed tools remain unchanged while Caliptra runs.

### OT-OTP-PACKED-DRIVER-CHAIN — arbiter grant no longer starts unknown

- **Failure:** Legal disjoint packed-bit continuous drivers can read earlier bits of the same vector. The eager `elab_net.cc` collapse turns them into a self-referential transparent concat before their right-hand sides exist; VVP then never receives all concat inputs, leaving even a constant root at Z. Paired 2017/2023 three-bit reducers fail before the fix, and pinned `otp_ctrl_smoke_vseq` fails `GrantKnown_A` with known requests and ready.
- **Fix:** Keep the part drivers until `cprop.cc` can see their dependencies. Its existing feedback guard retains dependent drivers; fully covered independent drivers still use a strength-preserving transparent concat where the target supports it. The SDF interconnect lookup follows a retained scalar part driver only when deferred links prove it is the sole structural driver of that bit; invalid indexed ports are rejected before annotation. Paired legal chains now propagate at startup and after input changes; paired overlapping-variable negatives still reject. [Reproducer, commands, and release replay](../../evidence/opentitan-otp-packed-driver-chain-20260925/README.md).
- **Released DV boundary:** The unchanged OTP smoke reaches its pass marker with balanced checked TL traffic and no UVM errors, but remains **0/1 qualified DV**. Icarus drops the smoke's partition-specific DAI legal-address constraint; a verbose replay shows two out-of-range DAI addresses. Six covergroup bins are also dropped, and the legal packed-variable reducer still emits a “treated as wire” warning. These are separate conformance and DV blockers, not a qualification of this run.

### OT-OTP-DAI-ADDRESS-CONSTRAINT-CONSTANT-MEMBER — fixed ranges retained

- **Failure:** The pinned OTP smoke's eleven conditional `dai_addr inside` ranges use selected members of a package `localparam` array of packed structs. Class-constraint lowering discarded every range before solver translation, leaving only `solve part_idx before dai_addr`. Paired 2017/2023 reductions accepted out-of-range addresses and silently ignored a nonexistent struct member.
- **Fix:** After proving a lexical parameter root and a constant index under constraint lookup, `elaborate.cc` reuses ordinary parameter-member elaboration. It resolves the full path before any same-named terminal class property and diagnoses selected members with meaningful bits above bit 63 rather than truncating them. Paired endpoint, adjacent-invalid, rollback, shadow, explicit-package, invalid-member, and wide-value controls pass. [Commands and pinned replay](../../evidence/opentitan-otp-dai-param-member-20260925/README.md) record the private image and separate gate results.
- **Released DV boundary:** The pinned native-DPI smoke completes with `TEST PASSED CHECKS`, zero UVM/assertion errors, 1343 checked TL A/D pairs, and one DAI address `0x658` inside partition 4. It remains **0/1 qualified released DV** because the distinct rand-indexed `PartInfo[part_idx].secret` condition in `dai_wr_blank_addr_c` is still ignored, as are six covergroup bins. The pinned application checkout and all original checks remain unchanged; unsupported checks are recorded rather than credited as passing.

### OT-OTP-COVER-BIN-METHOD-ENDPOINT — six OTP bins retained

- **Failure:** The pinned OTP `csr_rd_after_alert_cg` lost six bins whose 36 range endpoints call `ral.<register>.get_offset()` through a covergroup constructor handle. Paired 2017/2023 direct and signed reducers compiled with a dropped-bin diagnostic and failed at runtime.
- **Fix:** Capture supported method endpoints once per covergroup instance before VVP resolves dynamic bins. Strict mode proves direct non-ref, constant-state methods and their effective defaults; unsupported nested, ref, mutable, unknown, or unfixed forms reject loudly. The pinned nested RAL path requires an explicit `-gcommercial-unsafe` warning and is nonstandard because method purity is unproved. Side-effecting getters remain possible under that opt-in flag. [Paired reducers and pinned replay](../../evidence/opentitan-otp-cover-bin-method-20260925/README.md) record the exact scope.
- **Released DV boundary:** The named `otp_ctrl_smoke_vseq` passes **1/1 nonstandard compatibility DV** on the final private image: six bin groups and all 36 endpoints are retained, no constraint item is ignored, runtime completes with zero UVM/assertion failures and 1343 checked TL A/D pairs. This seed does not prove after-alert bin hits or the 40 preexisting fault-injection `force` RHS warnings; all ten injection selectors were zero. Strict pinned compilation rejects 36 unproven nested endpoints and has no DV runtime. Full OpenTitan DV and broader §19.5 conformance remain open.

### OT-SYSTEM-FUNCTION-RETURN — `$system` result reaches SystemVerilog

- **Failure:** The pinned released `prim_prince_sim` checked for `dv.stop` through `$system("test -f dv.stop")`; with the file absent, Icarus returned zero to the SV expression and took a false UVM fatal before vector traffic. Paired 2017/2023 reducers confirmed that a nonzero shell status was reported as zero. VVP also warned on the explicitly legal task form.
- **Root cause and fix:** `vpi/sys_icarus.c` set VVP's process exit status instead of the VPI function result. It now returns the C `system()` status through the existing integer-result helper, including `system(NULL)` without an argument. The `$system`-only warning exception in `vvp/vpi_tasks.cc` permits task calls without weakening other system-function diagnostics.
- **Authority and evidence:** IEEE 1800-2017 §20.18.1 and 2023 §20.17.1; [paired RED/GREEN and pinned replay](../../evidence/opentitan-system-return-20260925/README.md). Strict chapter-20 support remains PARTIAL; invalid extra-argument acceptance is DD-062.
- **Released DV boundary:** The unchanged pinned PRINCE smoke with `-gcommercial-unsafe` and native DPI completes five golden plus one random vector and their encryption/decryption comparisons, with one intended pass marker, zero runtime errors/assertions, and normal finish. This is **1/1 named nonstandard compatibility replay**. FuseSoC's three runner-tracked setup warnings (plus a raw backend-deprecation warning) keep the matrix row `DEBT`; the separate merged baseline remains **0/49 clean runtime matrix passes**.

### OT-LC-PACKED-COVERPOINT-SHAPE — bitwise packed coverpoint bin domain

- **State:** [PR #376](https://github.com/dsellerbrock/iverilog-uvm/pull/376) is published as a draft with final private-image local qualification: paired focus 10/10 in both runners, full legacy 6,704 total with zero failures, JSON/VVP 3,753/3,753, VPI 140/140, real-DPI UVM 358/358, negative 155/155, SVA dual-run 62/62, and `make check`.
- **Failure:** Paired 2017/2023 coverpoints over `cfg.err_inj & ~ErrInjMask` dropped both literal zero and open-ended nonzero bins because declaration-time `test_width()` returned zero for nested class properties. The zero sample then reported 1.5625% instead of 50%.
- **Fix:** `elaborate.cc` recovers integral packed operand shapes recursively for unary and binary bitwise expressions, using the standard result width and signedness. It retains both bins and their sampled denominator. Invalid `[$:$]` rejects; unsupported 65-bit bins stay loud.
- **Evidence:** [Paired reducers and exact pinned unsafe replay](../../evidence/opentitan-lc-packed-coverpoint-20260925/README.md). The pinned `lc_ctrl_sim` compile no longer drops either bin, but four hard error sites and 18 debt diagnostics remain. **LC_CTRL is 0/1 released DV**, and the prior selected OpenTitan compatibility baseline remains 11/49; no full current-image matrix was run for this change.
- **Boundary:** X/Z bitwise coverpoint samples can incorrectly hit an ordinary bin (DD-063), a separate runtime issue outside this declaration-time scope. Neither a passing language reducer nor a reduced compile-error count is an OpenTitan DV pass.

### OT-STRING-CASE-EXACT-MATCH — full string values in case comparisons

- **State:** Implemented at `51c424cf2678240bf90fe320e471cb277f4931ee`; the combined local gate checkpoint is at `1838970aae17e2d091a573184d424bd6fd096f68`. Real-DPI UVM passed 358/358 on the combined image; full clause and application DV qualification remain open.
- **Failure and fix:** A string selector longer than a matching-prefix case label lost its high byte and selected that label. Homogeneous string `case` and `unique case` now compare complete string values at run time, and constant-function `case` uses the same normalized string-value comparison (IEEE 1800-2017/2023 §§6.16, 12.5). The paired regression checks equal, longer, empty, and zero-byte-normalized strings. Explicit narrowing casts retain their integral semantics; mixed-type and wildcard case paths keep their prior behavior.
- **Evidence and boundary:** [Revision-scoped checkpoint](session_logs/2026-09-27_string_case_and_ranged_size_focus.md) and the paired `sv_string_cast_width_and_case` tests. This does not qualify every string conversion or case form, and no OpenTitan or Caliptra DV result is inferred.

### OT-STD-RANDOMIZE-RANGED-SIZE-EXACT — feasible local queue sizes

- **State:** Implemented at `1838970aae17e2d091a573184d424bd6fd096f68`. Paired focused checks and all combined local gates pass; application replay remains pending.
- **Failure and fix:** The preliminary local-queue size solver omitted `foreach` bodies, so it could reject a valid empty queue or sample a size whose element constraints were infeasible. Each candidate now checks the fully expanded hard constraints before feasible-size sampling. A guarded out-of-range read is admitted only when the constraint is provably independent of that absent element at the selected size. Declared queue maxima bound the candidate search; exact oversize errors and failure rollback remain intact (IEEE 1800-2017/2023 §§7.10.1, 18.5, 18.12). The paired fixture also retains its earlier dynamic-array range control; this commit did not change that path.
- **Boundary:** The ordinary size window is 0–1024. A complete sparse domain of at most 64 larger candidates can be checked if their combined expansion is at most 16,384 elements; these are solver limits, not IEEE limits. Allocation remains capped at 65,536 elements. Direct out-of-range reads whose type-specific default value could affect the constraint, and larger ranges whose feasibility cannot be proved, fail explicitly without narrowing the successful distribution.
- **Validation:** On the combined `1838970aa` image, full legacy ivtest ran 6,704 with zero failures, JSON/VVP ran 3,851 with zero failures, bundled VPI passed 131/131, negatives 155/155, runtime invariants 15/15, and dual SVA 62/62. The paired `sv_std_randomize_darray_size_range` test and exact unsupported-neighbor gold pass. [Revision-scoped checkpoint](session_logs/2026-09-27_string_case_and_ranged_size_focus.md). Real-DPI UVM passed 358/358 with zero failures or skips.

### OT-PACKED-CONSTRAINT-INDEX-EXACT — exact packed selects in constraints

- **State:** Focused exact-select repair and the bounded #421 packed-array-of-struct field slice pass locally. Broad gates, exact-head CI, and application replay remain pending; issue #421 remains open.
- **Failure and fix:** Constant packed indices were converted to signed host integers, so unsigned `64'hffffffffffffffff` could alias declared index -1 and silently constrain the wrong element. Narrow signed negative indices instead failed as unsupported. The packed-select helper now reuses the fixed-array index conversion, preserves ascending/descending bit offsets, and rejects reversed part-select endpoints. Direct packed properties, typed `std::randomize` locals, enum, packed-struct, and packed-array bases, array-method iterators, and both forms of foreach index now reach that helper. Associative foreach preserves its declared key type. The generic VVP `(part)` evaluator records a state error for invalid bounds instead of treating the result as a free solver bit. A typed `bit4` IR form guards symbolic four-state bit reads against out-of-range indices, while two-state reads retain zero; constant four-state out-of-range items are diagnosed as unsupported so randomize fails. The VVP validity comparison now keeps a signed upper bound positive at narrow widths (IEEE 1800-2017 §§7.4.1, 7.4.6, 18.3, 18.5; 2023 §§7.4.1, 7.4.5, 18.3, 18.5).
- **Focused evidence:** A 29-case scratch corpus passes 29/29 in each strict edition on the build-tree compiler, covering signed/unsigned boundaries, bit and part selects, both range directions, and nested packed shapes. Paired `sv_constraint_packed_element_select` checks exact negative-index values, symbolic simple-vector bit selection, and a valid packed array-method iterator part. Paired `sv_constraint_packed_invalid_select` checks six unsigned-high and reversed-range cases; all six now emit source-line unsupported diagnostics. A paired compile-error fixture pins a reversed packed select on an array-method iterator. Paired `sv_constraint_packed_bit_valid` and `_invalid` check narrow signed positive/negative indices, logic constant/symbolic/enum OOB failure, bit constant/symbolic OOB zero (including `==1` rejection), failure rollback, and an inactive guarded read. Paired `sv_constraint_packed_typed_bit_callers` checks valid and OOB unrolled/dynamic foreach indices, two-state and four-state associative keys, and logic/bit packed-struct iterator and local selections. Paired `sv_constraint_packed_parray_select` retains exact constant packed-array elements and its OOB symbolic selection now reports the four-state invalid-index runtime error. The new paired `sv_constraint_packed_struct_array_symbolic_select` covers an in-range symbolic index and selected packed-record member plus the OOB boundary: legacy passes 2/2 and JSON/VVP 4/4 in ordinary and strict-expression-width modes. See the [#421 evidence](../../evidence/ieee-packed-symbolic-nested-select-20261009/README.md). The earlier focused JSON run passes 20/20 with fixed-array bounds, fixed-index cast, and negative-bound part-info neighbors. Scratch caller-state selection also rejects a symbolic OOB logic bit read.
- **Boundary:** The negative fixtures are diagnostic controls; Slang independently rejects the invalid constant source forms. Class constraints now support this one-dimensional packed-array-of-packed-struct selection followed by unindexed packed member reads. Other symbolic nested packed selections, multidimensional packed arrays, and additional indexed tails remain explicitly unsupported; constant elements are exact. Full IEEE clauses, current-image broad gates, OpenTitan, and Caliptra application behavior remain unqualified.

### ARRAY-MAP-2023 — standard array map method

- **State:** Implemented and locally qualified in current main; merged in [PR #407](https://github.com/dsellerbrock/iverilog-uvm/pull/407). The registered fixed, dynamic, queue, and associative cases, including tested unpacked-array-valued results, pass; strict `-g2017` rejects the method. Broader clause qualification remains partial.
- **Standard:** IEEE 1800-2023 §§7.12.4–7.12.5. The `with` expression is required, mapped elements use its self-determined type, and the returned array preserves the source range or associative index set. The optional custom index-method name is supported. Strict 2017 behavior must remain rejecting.
- **Verified scope:** Paired map lists pass 4/4 in JSON and legacy harnesses. Cases cover default/custom iterator names, custom index alias, empty and populated inputs, descending fixed ranges, 2D row reduction, preserved associative keys, integral, bit, string, real, and unpacked-struct results, plus fixed-array-valued results for fixed, dynamic, queue, and associative receivers. The result tests check contents, ranges/keys, empty outputs, and nested maps over containers of rows. Adjacent min/max/reduction, unique/find-last, and OpenTitan array-of-containers checks pass; exact commands and image hashes are in the [qualification record](../../evidence/array-map-2023-20261007/README.md).
- **Remaining boundary:** Further legal result types and interactions need broader qualification. The focused ticket closes the tested implementation gap; it does not claim full §7.12.5 or complete array-method-clause conformance.
- **Original root cause:** `elab_expr.cc` omitted `map` from receiver dispatch and result type inference; the iterator context lacked the 2023 custom index-method name; `tgt-vvp/eval_object.c` lacked map lowering. The current implementation reuses the existing iterator and VVP container paths.
- **Source:** The local IEEE 1800-2023 §7.12.4–7.12.5 and 2017 §7.12 text were reviewed directly. The original paired RED is preserved in the qualification record as baseline history.
- **Scope:** `elab_expr.cc`, the required VVP lowering/runtime path, focused paired regression entries, `.ai/ACTIVE_WORK.yaml`, and bounded evidence. No OpenTitan or Caliptra source changes and no broad corpus run.

### IEEE-DPI-ARRAY-RESIDUALS — open issue crosswalk

- **State:** Two distinct actionable legal-argument gaps remain open: [#505](https://github.com/dsellerbrock/iverilog-uvm/issues/505) tracks imported fixed/open `shortreal` arrays; [#506](https://github.com/dsellerbrock/iverilog-uvm/issues/506) tracks fixed-size unpacked export formals.
- **Standard:** IEEE 1800-2017/2023 §35.5.6 and Annex H §§H.7.4/H.7.8 define imported aggregate formals and `shortreal`→C `float`; H.7.8/H.8.2 permit fixed-size unpacked export formals while prohibiting exported open arrays.
- **Evidence:** The retained reducers `tests/negative/m10_dpi_fixed_shortreal_array_argument.sv`, `tests/negative/m10_dpi_open_shortreal_array_argument.sv`, and `tests/negative/m10_dpi_export_fixed_array_argument.sv` each reproduce the current-main unsupported diagnostic. Issue bodies include self-contained examples and acceptance criteria.
- **Boundary:** Scalar shortreal, scalar and packed-vector exports, and the recorded other DPI subsets are supported. The broader signature/runtime cross-product remains M14B-9 qualification work and is not a separate runtime-gap ticket.

### SV23-DIST-DEFAULT-WEIGHT — 2023 `dist default :/` item

- **State:** Implemented and locally qualified as Fix 29; merged in [PR #407](https://github.com/dsellerbrock/iverilog-uvm/pull/407). The larger IEEE 1800-2017/2023 objective remains active.
- **Standard:** IEEE 1800-2023 §18.5.3 adds `default :/ expression`. The item is a single aggregate-weight bucket for the complement of all explicit bins. IEEE 1800-2017 §18.5.4 does not include this syntax.
- **Implementation:** The parser tags the default item, elaboration edition-gates it and rejects duplicate defaults, and VVP computes the complement after collecting every explicit membership predicate. Explicit bins remain weighted items, including overlaps; zero-weight explicit bins still exclude their values from the default bucket. The default bucket uses the existing exact weighted sampler.
- **Validation:** Strict JSON/VVP and legacy focused lists pass 5/5 each, including strict 2017 rejection, required `:/`, malformed and duplicate forms, weighted sampling, overlap, zero-weight exclusion, and hard-constraint failure. Existing large exact-dist neighbor lists pass 14/14 each. No broad corpus or OpenTitan run was needed. See [qualification evidence](../../evidence/dist-default-2023-20261007/README.md).
- **Boundary:** This qualifies the tested 2023 addition only. Other endpoint/weight expressions and interactions remain unqualified; clause 18 remains partial.

### ASSOC-FIND-FIRST-INDEX — associative `find_first_index()`

- **State:** Implemented and locally qualified as Fix 30; merged in [PR #407](https://github.com/dsellerbrock/iverilog-uvm/pull/407). This is a bounded §7.12.1 implementation increment, not full clause-7 closure.
- **Standard:** IEEE 1800-2017/2023 §7.12.1 applies locator methods to unpacked arrays. Index locators return the associative array's declared key type, and first/last on an associative array follow its key type's ordering. Wildcard-index associative arrays are excluded.
- **Failure and fix:** The valid `find_first_index() with (...)` call on a non-wildcard associative array emitted a compile-time “not yet implemented” diagnostic in both editions. The frontend now routes it through the existing keyed locator payload; VVP appends the actual matching key and exits at the first match.
- **Validation:** Strict JSON/VVP and legacy focused lists each pass 6/6. Coverage includes signed integer and string keys, multiple matches, empty/no-match results, existing `find_index` checks, and wildcard-index rejection. No broad suite or OpenTitan corpus was run. See [qualification evidence](../../evidence/assoc-find-first-index-20261007/README.md).
- **Boundary:** This supports integral and string key types accepted by the existing associative `find_index` path. Other associative locator methods and unsupported index-key types remain open.

### ASSOC-FIND-LAST-INDEX — associative `find_last_index()`

- **State:** Implemented and locally qualified as Fix 31; merged in [PR #407](https://github.com/dsellerbrock/iverilog-uvm/pull/407). This is a bounded §7.12.1 increment, not full clause-7 closure.
- **Standard:** IEEE 1800-2017/2023 §7.12.1 requires the last matching associative key in the array's key ordering, with the declared index type in the result queue. Wildcard-index associative arrays are excluded.
- **Failure and fix:** Before the change, valid calls were rejected in both editions. The frontend now uses the existing typed keyed-locator path; VVP begins at the last key, walks predecessors, and stops at the first predicate match in reverse order.
- **Validation:** Strict JSON/VVP and legacy focused lists each pass 8/8. Coverage includes multiple matches, signed integer and string keys, empty/no-match results, existing associative `find_index`/`find_first_index` controls, and wildcard-index rejection. No broad suite or OpenTitan corpus was run. See [qualification evidence](../../evidence/assoc-find-last-index-20261007/README.md).
- **Boundary:** Integral and string associative key types supported by the existing keyed path are covered. Other associative locator methods and unsupported key types remain open.

### SV23-RAND-REAL — IEEE 1800-2023 scalar real randomization

- **State:** Implemented and locally qualified as Fix 34; merged in [PR #407](https://github.com/dsellerbrock/iverilog-uvm/pull/407). The broader IEEE 1800 goal remains active.
- **Standard:** IEEE 1800-2023 §18.4 permits scalar class `rand real`; §18.5.9 permits real solve-before operands and requires uniform real selection. IEEE 1800-2017 retains the strict rejection.
- **Implementation:** The frontend edition-gates scalar real properties. Constraint lowering preserves binary64 literals and property values; the Z3 path handles real arithmetic/comparisons and finite interval membership, samples feasible binary64 candidates against the full hard solver, stages real solve-before values, and writes back only successful solves.
- **Validation:** Strict JSON/VVP and legacy focused lists each pass 3/3: 2023 positive, 2017 negative, and 2023 `randc real` negative. The positive test checks bounds, a relational bit, solve-before, 2,048-draw equal-half frequency (1,004 lower-half draws), and failed-call rollback. Image hashes and commands are in [qualification evidence](../../evidence/rand-real-scalar-20261007/README.md).
- **Boundary:** Only the finite scalar path is qualified. `randc real` is correctly rejected because `randc` is restricted to integral values; it is not a missing feature. `shortreal`, real arrays/aggregates, real `dist`, unbounded intervals, and joint class-graph real solving are outside this increment. Clause 18 remains partial.

### SV23-ARRAY-INDEX-ARGUMENT — IEEE 1800-2023 array-method index argument

- **State:** Implemented and locally qualified as Fix 35; merged in [PR #407](https://github.com/dsellerbrock/iverilog-uvm/pull/407). The broader IEEE 1800 goal remains active.
- **Standard:** IEEE 1800-2023 §7.12 adds the optional `index_argument` name to array-method calls. It names the iterator's index-query alias; strict `-g2017` must reject it.
- **Failure and fix:** The frontend accepted only the iterator argument for locator, reduction, min/max, and unique methods. The shared validator now accepts and edition-gates the second identifier, and iterator binding resolves it for ordinary and associative arrays. Class-element lookup preserves a real property such as `item.index` while resolving a distinct custom alias such as `item.position` to the array index.
- **Validation:** Paired JSON/VVP and legacy focused lists pass 2/2, including class-member collision, associative string-key lookup, `sum`, `min`, `max`, and `unique_index`. Adjacent 2023 `map()` lists pass 4/4 in each harness. Build and install succeed. Exact commands and executable hashes are in [qualification evidence](../../evidence/array-index-argument-20261007/README.md); no broad suite or OpenTitan corpus was run.
- **Boundary:** This qualifies the tested optional-name binding across the listed method families. Other array-method forms and full §7.12 qualification remain separate.

### SV23-CLASS-FINAL — IEEE 1800-2023 class `:final`

- **State:** Patched and focused-tested locally; CI is pending. Do not mark qualified until the PR's required platform checks pass.
- **Standard:** IEEE 1800-2023 §8.3 permits `class :final Name`; a final class may itself extend a non-final parent but cannot be extended. Strict `-g2017` rejects the 2023 specifier.
- **Failure and fix:** The parser rejected the legal declaration as a syntax error and class metadata did not prevent a derived class. Parsing now edition-gates `:final`, carries the flag into elaborated class types, and checks every superclass assignment path.
- **Validation:** Focused legacy and JSON/VVP lists each pass 4/4: a final child extending a regular parent runs and prints `PASSED`, direct and parameterized subclassing of final bases produce the class-specific error, and `-g2017` rejects the specifier. The source frontend built on macOS. The positive bytecode ran on the existing capped Linux runtime; no Linux source build was run for this small change. Evidence: [focused record](../../evidence/class-final-2023-20261007/README.md).
- **Boundary:** Class-level `:final` only; method-level final semantics and broader clause-8 qualification are not included.

### CI-REGRESSION-GATE-410 — repair for merged PR #410 failures

- **State:** The repair is locally verified on a branch based on `origin/main` (`e487a59f`). A follow-up PR's platform checks remain pending; local results do not qualify the gate.
- **Observed failure:** Merged PR #410 run `37634997943` reported failures on Ubuntu 22.04 and 24.04: 33 legacy name-diff entries and one negative test, `sva_multiclock_chain_disable`, which now compiles as a supported three-clock `disable iff` property.
- **Repair:** Current registrations and golds now reflect implemented behavior; array-pattern lowering and object-value copies cover the reported unpacked/packed pattern failures, the solver no longer treats an X/Z distribution weight as a positive dynamic weight, and solve-before expects the standards-required compile error for a non-random target. The obsolete associative `find_last_index` rejection fixture was removed; existing positive paired tests cover that feature. The stale three-clock negative case was removed; paired positive fixed-control tests cover the supported path.
- **Validation:** Source build and focused tests pass on macOS and Ubuntu 24.04 ARM64 (Docker memory cap 4 GB, two build jobs). The current CI-failure subset passes legacy 32/32 and JSON 29/29; the full negative suite passes 153/153. The three-clock SVA fixed-control focus passes 22/22 in each runner.
- **Boundary:** The historical PR #410 run remains failed for its merged head. Do not describe this follow-up as CI-green until the required jobs pass for the follow-up PR head; no full ivtest corpus or OpenTitan qualification was run here.
