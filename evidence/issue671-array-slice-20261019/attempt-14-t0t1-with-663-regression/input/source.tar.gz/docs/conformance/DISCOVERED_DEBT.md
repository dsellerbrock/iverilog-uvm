# Discovered debt (parking lot)

The canonical open-issue inventory, selection rules, and census dispositions are in the [IEEE conformance index](INDEX.md).

This file exists so that finding a defect while working a different
`.ai/ACTIVE_WORK.yaml` ticket never becomes an excuse to widen that ticket.

**Recording an unrelated discovery completes the active agent's
responsibility for it during the current ticket.** Do not fix it, do not
investigate it further, do not expand scope to cover it. Record it below and
return to the active work item.

Triage (promoting an entry here into `docs/conformance/BLOCKERS.md`, or
opening a new `.ai/ACTIVE_WORK.yaml` ticket for it) is a separate activity
done outside any single targeted-fix run.

## Entry format

```markdown
### DD-<NNN> — <short observation>

- **Discovered while working:** <active blocker ID, or "governance
  bootstrap" / other non-blocker task>
- **Observation:** <what was seen>
- **File/function:** <path:line or symbol, if known>
- **Possible clause:** <IEEE clause if applicable, else N/A>
- **Evidence:** <how it was noticed — log excerpt, source read, etc.>
- **Reproducer status:** none / sketched / confirmed
- **Triage status:** untriaged / promoted to BLOCKERS.md as <ID> / declined (why)
```

---

Previously recorded debt follows. The delivery-audit items below are
record-only; they were not implemented in this ticket.

### 2026-10-08 IEEE census — escaped conditional macro identifier

- **Issue status:** [OPEN #468](https://github.com/dsellerbrock/iverilog-uvm/issues/468).
- **Gap/evidence:** A self-authored `` `ifdef \foo `` reducer fails on clean `origin/main` with “without a macro name.” IEEE 1800-2017 and 1800-2023 §22.5 use `text_macro_identifier`; §5.6 includes escaped identifiers. See the issue for the exact reducer and clean-main `ivlpp` evidence. This is separate from #460’s parenthesized conditional-expression gap.



## 2026-10-07 delivery-audit debt

- **Per-test timeout:** Add a timeout to ivtest/vvp_reg.pl so one hung test fails without stalling a full sweep for hours. Not implemented here.
- **Bulky evidence storage:** Move checked-in evidence logs (about 125 MB in the current checkout) to CI artifacts or Git LFS; the packed Git history is about 87 MB. Not implemented here.
- **Exact sparse uniform sampling:** Draft PR #526 now traverses every projected tuple for eligible connected direct-scalar components (widths up to 64 bits, no pending soft constraints) after 64 rejected proposals, with reservoir selection and no tuple-count cap. Traversal is finite over the bit-vector product, but solver blocking state and work grow with the legal tuple count. Widths above 64 bits, soft constraints, arrays, and member components remain outside this exact path; see [#416 local evidence](../../evidence/solve-before-array/sparse-coupled-uniform-sampling-20261009.md).

### DD-001 — joint active-randc prepass and enumeration-cap interaction

- **Discovered while working:** Z01A
- **Observation:** Source review found a randc draw before complete component enumeration. A draw-dependent over-cap failure could condition successful calls on the selected value; not reproduced or claimed as a confirmed defect.
- **File/function:** vvp/vvp_z3.cc, z3_solve_pass_ randc prepass and exact_joint component enumeration.
- **Possible clause:** IEEE 1800-2017 18.4.2 / global constraint distributions; exact applicability needs triage.
- **Evidence:** Independent Z01A source review; ordered active-randc is explicitly excluded/rejected by Z01A.
- **Reproducer status:** sketched
- **Triage status:** untriaged


### DD-002 — associative member foreach loses string key type

- **Discovered while working:** L01
- **Observation:** foreach(boxes[selector].values[key]) with class member values[string] declares key as int and iterates zero entries. Same output and int key declaration with retained pre-L01 compiler and campaign runtime; not caused by the selected-prefix fix.
- **File/function:** pform_make_foreach_declarations / foreach_index_type_t unindexed member type resolution.
- **Possible clause:** IEEE 1800-2017/2023 12.7.3 implicit index type.
- **Evidence:** evidence/campaign-20260908/l01/typed*.sv, .vvp and logs; old compiler from preserved string-array-param-after253 worktree, a diagnostic comparison rather than a campaign qualification gate.
- **Reproducer status:** confirmed
- **Triage status:** resolved within the reviewed, locally validated L05 selected-member index-type scope; no repair included in L01. Broader container/header validation remains separate.

### DD-003 — Boolean event-expression driver discards automatic activation context

- Active blocker: L02. Record-only; not a regression from L02.
- **Historical observation (S03):** simultaneous task activations using posedge (value[2] | 1'b0)
  both report transition time 2 instead of 2,3.
- **Historical mechanism (S03):** vvp/logic.cc vvp_fun_boolean_ receives no retained context and
  vvp_fun_or::run_run sends its result with context 0; input storage is shared.
- Authority: IEEE 1800-2017/2023 6.21 and 9.4.2; expression event transition
  must use the invocation's value.
- Evidence: u01-loop/history-expression-preexisting.sv, history-baseline.log,
  history-baseline.vvp; fresh e0dab7221 compiler rebuilt into baseline-tools
  with original frame selection. Identical 2,2 failure on baseline and L02.
- Reproducer status: resolved within reviewed locally validated L03 Boolean
  functor family and supported input chains. Other expression families remain
  unqualified; no general expression-correctness claim.

### DD-004 — Unchanged partial write can manufacture a default-bit negedge

- Active blocker: L02; record-only, not introduced by frame selection.
- **Historical observation (S03):** default bit vector 0, unchanged value[2:1]=0 at t1 wakes
  negedge value[0], although the intended first negedge is at t3.
- **Historical mechanism (S03):** vvp_fun_signal4_aa::reset_instance emits no initial sample;
  recv_vec4_pv sends even an unchanged vector, exposing probe history X.
- Authority: IEEE 1800-2017/2023 6.8 and 9.4.2.
- Evidence: u01-loop/default-negedge.sv and baseline/candidate logs, both
  fail at t1. Original e0dab7221 compiler frame layout also fails with the
  candidate runtime; native probe path has no ancestor history to seed.
- Reproducer status: resolved within L04 reviewed locally validated automatic integral default publication. Broader types and derived Boolean contexts remain unqualified.

### DD-005 — Non-fanout assertion paths omit vacuous user pass actions

- **Issue status:** [CLOSED #470](https://github.com/dsellerbrock/iverilog-uvm/issues/470); no current-main failure reproduced.

- **Current disposition:** Historical S03 finding; no active blocker after current-main recheck.
- **Historical observation (S03):** `tests/sva_recursive_consequent_test.sv` executes17 enabled
  starts; the fixed negated consequence has one nonvacuous success and one
  failure, but reports only1pass rather than16 including vacuity. Existing
  until/eventual controls similarly count only nonvacuous successes.
- **Historical mechanism (S03):** unchanged non-endpoint NFA/legacy implication handling suppresses
  vacuous pass dispatch. S03 repairs only the split endpoint parent path.
- Authority: IEEE1800-2017/2023 16.12.7; a no-match antecedent succeeds.
- Evidence: campaign-20260908/s03/recursive-red-2017.log and2023.log;
  old baseline test already expects1pass, and the unaffected source path
  omits its vacuous action. Nested/throughout parent paths now report17.
- **Reproducer status:** Historical paired S03 red logs remain valid for that revision. On clean origin/main af89cfc50be1084cc86c48865f3f6ba78d4512fa, the reducer passes in both strict editions; the registered legacy focus passes 17/17, JSON focus 8/8, and endpoint fan-out VPI 1/1. Closeout details: https://github.com/dsellerbrock/iverilog-uvm/issues/470#issuecomment-6066898539.


### DD-006 — nested parameterized sequence alias does not expand

- **Discovered while working:** S04.
- **Observation:** Pair(x,y) defined as x ##2 y works when reused directly with distinct actuals in OR/AND antecedents. Wrapping Pair(a,b) and Pair(c,d) in named Left/Right aliases instead reports No function named Pair during elaboration.
- **File/function:** pform.cc sequence splicing / parameter-window antecedent normalization; causal triage pending.
- **Possible clause:** IEEE 1800-2017/2023 sequence declarations and argument binding; exact clause pending triage.
- **Evidence:** evidence/campaign-20260908/s04/window-nested-alias.sv and window-nested-alias.log. Same four errors with compiler rebuilt from validated61ca5f336: window-nested-baseline.log. Current source/build restored afterwards; installed candidate tools unchanged during running gates.
- **Reproducer status:** confirmed before S04; direct parameterized reuse is a passing control.
- **Triage status:** resolved within S07 reviewed locally validated bare-alias recursive expansion scope; full dependency-graph validation and broader parameterized declaration lookup remain unqualified.

### DD-007 — symbolic repetition still reports consequent endpoint verdicts

- **Discovered while working:** S04 oracle review.
- **Observation:** Symbolic ranged/unbounded antecedent lowering retains per-endpoint consequent pass/fail actions, rather than aggregating one parent assertion verdict. S03 repaired the NFA parent model, not this separate symbolic engine. S04 only repairs previously missing vacuity for ages that never matched.
- **File/function:** pform.cc sva_parameter_repeat_try_assertion_ r_pass_req/r_fail_req and endpoint counts.
- **Possible clause:** IEEE 1800-2017/2023 16.12.7 and 16.14.1.
- **Evidence:** Existing validated sv_assert_repeat_parameter_override and sv_assert_repeat_parameter_smoke tests explicitly expected multiple endpoint actions before S04. Independent S04 review derived their new totals by adding vacuity; these remain compatibility checks, not per-attempt standards qualification. No new regression inferred from those totals.
- **Reproducer status:** existing regression stimuli retained; parent-verdict reducer needs a deliberate selection boundary.
- **Triage status:** resolved within S05 locally validated fixed ##0/##1 symbolic repetition scope. Broader symbolic consequent-delay overrides remain DD-008 and are not covered by this qualification.

### DD-008 — symbolic consequent delay override uses the default

- **Discovered while working:** S05 boundary reducer construction.
- **Observation:** `a[*LO:HI] |-> ##D q` with defaults LO1/HI2/D0 and instance D1 passes at the second tick instead of awaiting the final child at tick3; making q false at tick3 produces no failure. Explicit literal ##1 is a passing control in the S05 paired reducers.
- **File/function:** pform.cc cycle-delay normalization and symbolic repetition probe; causal triage pending.
- **Possible clause:** IEEE1800-2017/2023 6.20.2,16.9,16.12.7; exact delay-normalization cause unverified.
- **Evidence:** campaign-20260908/s05/parameter-delay-override.sv and .log; current candidate produces EARLY1/0 then1/0. First observed before the S05 parent edit; no retained pre-S05 isolated reducer result, so baseline comparison remains required.
- **Reproducer status:** reduced current failure; literal-delay control passes.
- **Triage status:** resolved within the reviewed, locally validated S06 single named parameter/localparam delay scope. Broader delay-expression syntax, composed/multiclock shapes, formal lookup and maximal-width arithmetic remain unqualified.


### DD-009 — Invalid foreach header selector accepts an implicit string key

- **Discovered while working:** L05
- **Observation:** foreach(boxes[key].values[key]) where boxes is fixed-size
  and values is string-keyed compiles despite the implicit key being string.
  The attempted outer-key positive interpretation was withdrawn after IEEE
  12.7.1/12.7.3 review; both Slang editions reject the string selector.
- **File/function:** Selected target expression/index type validation; not
  isolated to a specific lower-level check yet.
- **Possible clause:** IEEE1800-2017/2023 7.4.2,12.7.1,12.7.3.
- **Evidence:** campaign-20260908/l05/shadow-invalid-positive.sv and design
  review. Existing runtime target binding was preserved, not changed to
  make this invalid positive case pass.
- **Reproducer status:** Candidate acceptance observed; exact diagnostic
  reducer and pre-existing validation mechanism remain to be isolated.
- **Triage status:** record-only; no repair or invalid-header qualification
  is included in L05's legal selected-member index-type increment.

### DD-010 — Uninstantiated merged covergroup type enters overall denominator

- **Current disposition (2026-10-08):** Fixed by the V07 population guard. The clean `origin/main` build at `af89cfc50be1084cc86c48865f3f6ba78d4512fa` passes the registered V07 reducer in both strict editions. This is local evidence, not CI; the earlier failure below is historical.

- **Discovered while working:** V06 final scope-control review.
- **Observation:** One fully covered instantiated type plus a declared but
  uninstantiated merged type produces overall50 rather than100 percent.
- **File/function:** vvp/class_type.cc type_coverage/registry eligibility and
  vvp/vthread.cc of_COVGRP_GET_ALL; at discovery the exact correction had not
  yet been selected.
- **Possible clause:** IEEE1800-2017/2023 19.9,19.11,19.11.3; complete eligibility
  semantics require review at selection.
- **Evidence:** campaign-20260908/v06/uninstantiated-type.sv and candidate/v05
  logs. Both candidate and saved validated V05 runtime reproduce50 vs100.
  For V05 compatibility only the new item-type-weight tags were removed from
  emitted bytecode; every item/type weight in this reducer is1.
- **Historical reproducer status:** Pre-existing runtime failure established on
  V05; the V07 correction and paired lifecycle controls supersede this status.
- **Historical triage status:** record-only during V06. V06 function-scope test
  instantiated all intended groups; V07 subsequently corrected the population
  guard. Broad application qualification remains separate.

- **DD-010 resolution:** V07 validates the shared population guard with paired
  lifecycle controls and required local gates. Never-instantiated types are
  excluded; zero-weight retired merged instances remain represented. The clean
  current-main recheck passes the registered reducer in both strict editions;
  broader coverage qualification remains separate.


### DD-011 — UVM release-matrix compile frontiers

- **Discovered while working:** U02 user-requested release acquisition/probes.
- **Evidence:** `docs/conformance/uvm_release_matrix.md` and local
  `third_party/uvm-releases/results-pv87b5yu/results.json`; unmodified releases,
  compiler/runtime implementation03caa64c8, actual-g2012.
- **Observed:** Legacy1.x/2017 libraries encounter member-delay syntax (1.0p1
  also reports process class lookup);2020.1.0/1.1 encounter nested resource
  queue type/assignment errors;2020.3.2 rejects default-initialized unpacked
  struct queue `accesses` in uvm_reg_map.svh2058. Later diagnostics may cascade.
- **Classification:** Reproduced compile gaps, not yet reduced/standards-classified.
  Do not label nonstandard library syntax a mandatory IEEE compiler defect.
- **Triage:** Record-only during U02; select and ground one causal mechanism
  before any semantic fix. No archived library or application source patched.


- **L08 candidate follow-up:** Original2020.1.0/1.1 now compile at47e6c87b3, but both are RUNTIME_FAIL in results-gizcr5j0 (complete=true,baseline_valid=true). Runtime logs report unresolved uvm_re_match/uvm_glob_to_re DPI symbols followed by command-line UVM errors and BUILDERR. Record-only pending L08 validation; release-specific DPI loading/ABI and runtime semantics are not qualified. No library edits.


### DD-012 — L06 mixed-array and class-qualified declaration boundaries

- **Discovered while working:** L06 expanded initialization controls.
- **Evidence:** evidence/campaign-20260908/l06/class-qualified-module-declaration.sv
  and queue-of-fixed-array.sv plus compile logs; no fixes included.
- **Observed:** Module-level class-qualified declarations hit parser errors;
  the supported procedural class-qualified form is covered positively. Queues
  of fixed-array elements hit the existing netuarray_t unsupported boundary.
- **Triage:** Record-only. Permanent array boundary tests guard against wrong
  dimension classification but do not qualify those legal unimplemented shapes.

### DD-013 — Last-element queue lvalue crashes elaboration

- **Discovered while working:** L06 officialUVM2020.3.2 replay after queue-default fix.
- **Evidence:** UVM uvm_field_op.svh112 assigns msg_queue[$]; minimal
  evidence/campaign-20260908/l06/queue-last-lvalue.sv creates stringq, pushes
  one element and assigns q[$]. Expected replacement of the last element.
- **Observed:** Saved validated03caa64c8 compiler and L06 candidate both abort
  at elab_lval.cc1335 use_sel==SEL_NONE in2017/2023. Four logs preserve proof.
- **Triage:** Proven preexisting next-blocker candidate; not caused by L06,
  not repaired in its patch. UVM2020.3.2 is still COMPILE_FAIL/unqualified.

- **L07 follow-up:** Direct queue-variable element assignment fixed and locally validated at `9a1b6beb3`. Unmodified2020.3.2 now passes the release smoke. Class-property/root-member last-index forms remain outside the resolved scope.

### DD-014 — Terminal process kill loses descendant reachability

- **Discovered while working:** U01 teardown source tracing; record-only.
- **Observation:** `of_PROCESS_KILL` returns immediately when the process has no
  owner or already reports FINISHED/KILLED. Thread reaping reparents detached
  children. This appears unable to kill live descendants through a retained
  handle to a terminated parent.
- **File/function:** `vvp/vthread.cc`, `of_PROCESS_KILL`, `vthread_reap`.
- **Possible clause:** IEEE 1800-2023 9.7 explicitly requires killing live
  descendants even when the target is FINISHED/KILLED. The 2017 wording differs
  and needs separate qualification; do not infer identical edition requirements.
- **Evidence:** Current source at validated semantic revision `9a1b6beb3` and
  local primary LRM text; no attribution to U01's intermittent warnings.
- **Reproducer status:** none.
- **Triage status:** untriaged; no implementation authorized by this entry.

### DD-015 — Function-valued UVM core-state wait diagnostic woke early

- **Discovered while working:** U01 post-report observer construction.
- **Observation:** An added diagnostic top using
  `wait (get_core_state() == UVM_CORE_FINISHED)` continued at time zero and
  stopped the application at 1 ns. This invalidated the observer attempt; it
  is not application qualification or proof of a compiler defect.
- **File/function:** `uvm-core/src/base/uvm_globals.svh`, `get_core_state`;
  evidence `u01-after-l07/teardown_observer_wait_attempt.sv` and
  `teardown-observer.log` preserve the attempt.
- **Possible clause:** Wait expression evaluation and function dependencies;
  exact applicable semantics and cause remain to be established.
- **Reproducer status:** diagnostic observation only; not minimized.
- **Triage status:** untriaged, record-only. U01 observer now uses a bounded
  explicit time after the known smoke completion and verifies log ordering.

### DD-016 — Regex edge cases during legacy ABI comparison

- **Discovered during:** U04 read-only legacy/modern regex comparison, before U05 prerequisite selection.
- **Evidence:** Modern uvm-core/src/dpi/uvm_regex.cc uvm_re_comp strips slash brackets without the legacy len>1 guard; the single-slash input appears to underflow re_len-2. Source-only, not yet reduced; do not claim a runtime defect without evidence. Legacy2020.1 glob_to_re bracketed-input branch also falls through into the tail rather than preserving input, unlike modern conversion.
- **Disposition:** Record-only; original vendor code unchanged. U04 must define explicit regex/empty/slash/bracket/error expectations before any ABI delegation; upstream behavior is not automatically normative.

### DD-017 — Original UVM2020.1 smoke exits before intended phase checks

- **Discovered during:** U04 original-release replay.
- **Evidence:** results-9mvpk_8f complete=true,baseline_valid=true; both original2020.1 releases compile0/runtime0, no unresolved DPI symbols or command-line UVM errors, but finish at time0 without required smoke completion marker. Direct legacy ABI tests pass4/4 across both releases/editions.
- **Disposition:** Record-only during U04; still RUNTIME_FAIL. Establish whether the intended run-phase traffic/checking executes and reduce the causal mechanism after the current semantic baseline is validated. No warning waivers or application edits.

U06 closes the recursive-input cause after full validation at aad6fe22b.
Original2020.1.0/1.1 now pass their unchanged smoke; full qualification remains separate.

### DD018 — Nested argument output copy-out selects staged caller scope

Discovered under U06. Evidence-only copyout_control.sv and
copyout-baseline.log/copyout-candidate.log in evidence/campaign-20260908/u06
show identical failures on validated aa172f5 runtime and U06 candidate.
A recursive method passes get_child(output seen) as an argument; seen is
an automatic caller local. Generated copy-out stores through the staged
outer callee frame instead of the caller frame. Both runs fail the output
assertion when input assertions are removed to isolate this behavior.
IEEE 1800-2017/2023 13.5 argument passing is the applicable cluster; exact
copy-out correction remains untriaged. Symbols: draw_copy_out_function_argument,
scoped write-context selection. Original smoke has no such output actual.
Record-only, not a U06 regression or a qualified subcase; preserve reducer
for deliberate selection after validating the input-context increment.

DD018 resolved by L09 at 3c44fd13b after required local validation.
Caller actual context and formal source context are now selected separately.

### DD019 — Scalar output into fixed-array class property element

L09 probe fixed_property_output.sv (evidence/campaign-20260908/l09) produces
"Skipping indexed property copy-out" on both validated U06 target and L09
candidate. Existing emitter supports certain container-valued property
elements but not this scalar fixed-array slot. Compile baseline diagnostic
is preserved in fixed-property-baseline-compile.log. Legal output lvalue
classification belongs to IEEE2017/2023 13.5 and class array properties;
implementation remains open. Record-only during L09; no warning waiver or
claim of fixed-array property-element output support.


### DD020 — Scalar output actuals evaluated before call and on return

L10 index-side-effect control fails on candidate because scalar output actuals
are copied in before function execution. Existing function_port_is_container_output_
only suppresses container/fixed-array output input evaluation. The same issue
applies to plain fixed-array scalar actuals on validated L09, independent of
L10 property stores. IEEE2017/2023 13.5 return copying; must preserve automatic
formal defaults and static output persistence. Selected prerequisite L11; L10
patch and reducers preserved under evidence/campaign-20260908/l10.

L10 receiver().slots[...] syntax probe was rejected by parser; preserved in
receiver_syntax_probe.sv. Not required for nested env.box receiver coverage;
record-only syntax frontier, no parser changes under L10.

DD020 resolved by L11 at b32df9a29 after all required local gates.


L10 conversion probes found ordinary string/integral assignments are permissively
accepted by the existing frontend despite6.16 requiring explicit casts. Preserved
`evidence/campaign-20260908/l10/string_assignment_control.sv`; broader assignment
diagnostic debt is record-only. L10 now rejects the fixed-property output
mismatch so its new typed stores cannot execute a mismatched load opcode.

DD019 resolved by L10 at051aeee8e after validatedL11 prerequisite and all required local gates.


### DD021 — UVM1.2 frontiers after member-delay parsing

U07 candidate original1.2 probe `third_party/uvm-releases/results-sv_woyjp`
gets past #setting.offset but fails elaboration: uvm_printer.svh1172 reports
an unsupported index on struct member val, and uvm_traversal.svh284-285 reports
hierarchical references to automatically allocated compiled_regex in visit.
The upstream declaration is explicitly `static chandle compiled_regex`;
reduce lifetime handling and hierarchical lookup rather than assuming the diagnostic is correct.
A uvm_sequence_base.svh1255 pick_sequence constraint item is also reported
unrepresentable and ignored. These remain separate semantic/diagnostic
frontiers; no UVM pass or waiver. Source trees unchanged; record-only during
U07, reduce/classify at a later coordinator boundary.

### DD022 — Original UVM 2017.0.9 smoke runtime timeout

U07 full release sweep `third_party/uvm-releases/results-4r1diuop`
compiles unchanged 2017.0.9 successfully, then its runtime times out after
300.059 seconds with an empty log. The earlier baseline rejected member-delay
syntax before runtime. Source hash and exact commands are preserved in results.json.
No causal runtime diagnosis yet; timeout is not proof of a scheduler defect.
2017.1.0 and 2017.1.1 now pass all smoke checks. Record-only during U07;
reduce and classify at a later coordination boundary. Full release remains open.

### DD023 — Unknown ordinary string index behavior

During L12 control testing, an ordinary string `s="@abc"` read at integer
X or Z index returns character64 for both `s[i]` and `s.getc(i)`. Negative
and length indices return0. The runtime string select reads an integer word
without its unknown flag. Evidence `evidence/campaign-20260908/l12/bounds_control.sv`.
Needs standards classification; not claimed qualified and record-only for L12.

### DD024 — String character selection loses signed byte type

L12 high-bit control shows ordinary and proposed member indexing widen0xff to255, while getc/byte cast yield-1. Both-edition6.16 and6.11.3 require signed byte. Selected as prerequisite L13; L12 partial work preserved and source restored before new baseline. Prior9baa5a9c3 gates passed, but reopened after narrow two-state parameter index2 returned0 instead of the third byte. Corrected by849a779ea with source-signed resize and separate signed int cast; all required gates pass. L12 may resume.

### DD025 — Class string-property character index uses property slot

L13 control `c.s[1]` with `c.s="abc"` aborts in class_type.cc get_string
array_size assertion on both saved L10 compiler and L13 candidate. Index0
returns whole string instead of character. Exact reducer `evidence/l13/class_control.sv`
and L12 byte_type probe retained. Distinct property dispatch defect, not
introduced by signed-byte typing; record-only, no class-property character
qualification claimed by L13.

### DD026 — Constant function string argument character result unknown

L13 `constant_probe.sv` contains automatic int function get_value(input string s)
returning s[0], evaluated for a localparam. Both saved L10 and L13 candidates
produce X for that constant-function result; direct typed parameter selection
is a distinct L13 width issue now in scope. Evidence/l13/constant_probe_results.json.
Record-only for constant-function argument/evaluation classification; no
constant-function string qualification claim.

DD023 follow-up during resumed L12: with "abcde" and a four-state integer
index ending in1x, ordinary s[idx] and initial L12 member path returned'a',
while getc(idx) returned'c'. Both editions6.16/getc(int) and6.11.2 require
per-bit two-state conversion. L12 now uses the existing int2/32 cast for its
new member path; ordinary string index lowering remains a separate proven
gap. Evidence/l12/index_conversion.sv. No ordinary-selector fix included.

### DD027 — Original UVM1.1d compiles but does not pass smoke

L12 candidatea85a256b1 removes the member-string elaboration frontier. Original1.1d now compiles with ignored-constraint and object-expression null-fallback warnings, then runtime exits0 but fails the smoke qualification checks. Evidence third_party/uvm-releases/results-qb7873zh/1.1d/{compile,runtime}.log. Runtime reports missing DPI symbol uvm_dpi_regcomp, four command-line regex UVM_ERRORs and one BUILDERR UVM_FATAL, then exits0 before smoke completion. Exit0 is not a smoke pass. Record-only during L12 required validation.

DD021 follow-up: L12 candidate removes original1.2 printer string-index errors. Four remaining compilation errors at uvm_traversal.svh284-285 concern compiled_regex in visit, plus the existing ignored pick_sequence constraint warning. Original1.1a now reaches fork/join_any-in-function and void-cast-of-void diagnostics; standards legality must be verified before selecting changes. No library edits or qualification claims.

### DD028 — Original UVM1.2 smoke runtime produces no output before timeout

L14 candidate69ff60cc6 removes all four visit.compiled_regex reference errors. Original1.2 compiles0 in0.635s, then runtime times out after300.061s with empty runtime.log (return-9). Evidence third_party/uvm-releases/results-f9qr050b/1.2 and results.json. Ignored pick_sequence constraint and newly reached object-codegen null-fallback warnings remain visible. No relationship to the already known2017.0.9 timeout is proven. Select and reduce after L14 required gates; do not infer startup, scheduler, DPI or initialization cause from an empty log alone.

### DD029 — General class method visibility fallback gaps

U08 review observed local base methods still accessible when no enclosing homonym exists, and through explicit class qualification. Existing method_from_name and later call fallbacks do not enforce complete method access control. U08 is bounded to inherited lexical precedence over enclosing homonyms; it retains qualifier metadata and prevents a package-selected statement call being re-resolved to a local base method. General no-homonym/explicit-qualified access checks remain separate qualification debt, not a completed8.18 feature.

### DD030 — Original UVM1.2 reaches missing legacy regex DPI

U08 development replay results-pqt3anxi removes the root-construction recursion and starts release_test, then reports missing uvm_dpi_regcomp, five command-line regex UVM_ERRORs and one BUILDERR UVM_FATAL. Result RUNTIME_FAIL, not smoke/application pass. Original source tree unchanged. Pinned1.2 src/dpi/uvm_svcmd_dpi.c already defines uvm_dpi_regcomp/regexec/regfree using POSIX REG_NOSUB|REG_EXTENDED; current fork umbrella includes the modern source, which lacks those exported entry points. User requested investigation. Preserve legacy strict regex semantics, allocation/free behavior and error reporting when selecting DPI work after U08 validation; do not simply alias to the modern glob-retry wrapper.


DD027/DD030 resolution (U09,19e7f5592): cached-regex exports and callback-aware
error reporting now pass focused original1.1d/1.2 checks in both editions.
Full required local gates pass. Both original releases pass smoke in
results-n2m35ki0 with unchanged source fingerprints. Other compile-time
constraint/codegen warnings and full application qualification remain open.

### DD031 — OpenTitan original1.2 macro expansion frontier

U10 replay uses explicit original1.2 root and records src hash
885ba9f74652494aa132aaaa26c43e9f210f94cdf5a8d3a87064993ec9b35dc0.
Pinned7a3ad34 debug crossbar compile exits74; first diagnostics are missing
argument list for uvm_print_aa_string_int at dv_base_env_cfg.sv112/114,
followed by parser cascades. No simulation or traffic ran.
Evidence evidence/campaign-20260908/u10/result.json and matrix-compile.log.
Record-only during U10 harness qualification; macro source/expansion and both
LRM editions require investigation before selecting any compiler change.

DD031 resolution (L15,aa356ab4d): complete pasted function-like names now expand
correctly under both editions and all required local gates pass. Fresh original1.2
OpenTitan replay removes the macro errors and cascades with unchanged UVM source
hash; compilation now exits3 at the distinct const-handle assignment frontier.

### DD032 — Mutable member assignment through a const class handle rejected

After validated L15, original1.2 OpenTitan debug crossbar compile fails three
times at dv_base_test.sv92: uvm_top.enable_print_topology = print_topology.
The diagnostic says assignment to const signal uvm_top is not allowed, although
the target is a mutable member of its referenced object. Evidence
evidence/campaign-20260908/l15/opentitan/result.json and matrix-compile.log;
source hash885ba9f74652494aa132aaaa26c43e9f210f94cdf5a8d3a87064993ec9b35dc0.
No simulation ran. Record-only during L15 closure; verify both editions and
reduce before selecting a const-handle elaboration fix.

### DD033 — Explicit package-qualified member compound assignment parser gap

L16 development positive fixture used const_handle_pkg::shared.value += 2 and
both editions rejected its statement syntax before elaboration. Imported
shared.value += 2 works and is the selected const-handle test. Preserved
evidence/l16/development.json; explicit qualified compound assignment is
record-only and not part of L16's bounded direct handle const check.

### DD034 — Existing class-member lookup/const-chain limitations

L16 independent source review confirmed the existing class-member walker can
warn and discard an unknown property write, and rejects traversal through an
intermediate const class-handle property even when the leaf is mutable.
L16 enables only direct scalar const-handle variables with existing writable
members; it does not qualify unknown-member diagnostics or const property
chains. These source-inspection findings need dedicated reducers before
implementation; no correctness claim for those paths.

DD032 resolution (L16,5ba60567f): mutable member writes through scalar const
class-handle variables pass both editions and full required gates. Original1.2
OpenTitan const-handle errors are removed. Replay runs normally with
152requests/288scoreboard items and zero UVM warnings/errors/fatals, but overall
DEBT remains because five compile-time null-substitution diagnostics persist.

### DD035 — Integral compound updates of UVM register item array members emit null

Validated L16 original1.2 OpenTitan replay reports five draw_eval_object
null-fallback warnings: uvm_reg.svh2501 (rw.value[0] &= ~wo_mask),2173
(rw.value[0] &= ((1 << m_n_bits)-1)), uvm_reg_field.svh1483,
uvm_reg_map.svh2109 (rw.value[val_idx] |= shifted data), and
uvm_reg_predictor.svh192 (reg_item.value[0] |= shifted data).
These integral selected-element operations should not take object-RHS
evaluation. Evidence evidence/campaign-20260908/l16/opentitan/{result.json,
matrix/runtime/lowrisc_dv_top_darjeeling_xbar_dbg_sim_0.1/matrix-compile.log}.
Runtime0/pass banner/zero UVM severities does not waive compile-time semantic
debt. Reduce and trace a concrete selected-element compound assignment before
selecting an implementation change; full UVM/application qualification open.

DD035 resolution: L17 d8e974913 implements integral whole-element dynamic-array
property compound updates after validated operand/receiver prerequisites. All
required gates pass; fresh original1.2 debug-crossbar smoke reports PASS with
all five substitution warnings absent. Full container/UVM qualification remains open.

### DD036 — Compound operands prematurely converted to destination width/state

During L17 focused review, byte property >>=32'd256 reaches VVP as an8bit
zero shift count; /=32'd256 also reaches division with zero divisor, whose
unknown result was masked by the two-state destination. netmisc.cc
elab_and_eval destination casting loses width/state before target lowering.
Four-state RHS into two-state compound target must retain X until the final
result conversion. Preserve l17/focus.vvp,focus.log,partial.patch. Separate
prerequisite selection required after L18; not repaired by target width logic.

L18 review note: associative compound expansion in elaborate.cc independently
reads the old get_signed flag. Existing source-inspection limitation, no
new reducer or qualification claim; outside scalar-property L18 scope.

DD036 L20 review boundary: existing associative front-end expansion builds
its binary expression at destination width before the compressed target
helper. Migrating the target's associative callers does not qualify that
separate expansion; preserve as residual width debt requiring its own reducer.
L20 claims the ordinary compressed vector paths and permanent tested shapes.

DD036 associative expression width/sign/state scope resolved by L31 at0a4e7d639
after allrequiredlocalgates. Declared element signedness and binary context now
precede extension, with final assignment conversion at store. Mixed unsigned,
wide arithmetic, self-determined shifts, state and local/property controls pass.
This does not qualify all associative compound semantics: preexisting key/receiver
reevaluation in the expansion remains a separate unqualified scope.

### DD037 — Captured class mutation notification undoes handle rebinding

L17 resumed receiver test and standalone scalar-property reducer show
notify_mutated_object_root_ sending captured root_obj back to root_net after
RHS rebinds it. Original object updates correctly but h reverts to old handle.
Evidence l17/receiver-debug and l21/red; vvp/vthread.cc19414. Selected as
L21 prerequisite at deliberate suspension boundary; no value-aggregate or
static-overlay correctness claim beyond tested contexts.

### DD038 — Legacy 1.1b/c vendor-only recording macro

At L17/L22 selection, unchanged1.1b/c macros/uvm_object_defines.svh defines
uvm_record_attribute only for QUESTA/VCS/INCA, but generic payload calls it
unconditionally. Current compiler warns undefined macro then parser recovery
asserts. Do not define a commercial-vendor macro or empty recording operation
to claim support. Recording compatibility and parser robustness require separate
assessment; original sources unchanged. Evidence results-3d_bbaiu compile logs.

DD038 design review at30b803071: parser recovery is now normal rejection
(L29), while the missing recording API remains. Independent source review rejects
an adapter that concatenates $typename with %p and calls m_set_attribute:
%p uses decimal/%g/string formatting rather than a lossless typed encoding;
the direct attribute macro has no lexical recorder argument; base uvm_recorder
bypasses the attribute macro and may record literal description text. These are
reasons not to use formatting as typed serialization, not a claim that every
%p formatting choice violates its own IEEE contract.

The original typed-value/no-artificial-width-limit recording objective remains
mandatory. Proposed native backend decomposition, to select only after L31
validation: (1) real handle ownership/lifecycle and inspectable stream/begin/
link/end/free events; (2) typed value capture preserving schema, widths, four-state
bits, real precision, strings and object identity/cycles; (3) deterministic
legacy-recorder installation and original1.1b/c integration. No macro no-op or
text-only substitute. Parent recording support stays incomplete until its full
contract is implemented and qualified.

First prerequisite should use an explicitly instantiated native-compatible
recorder before any global installation. Preserve upstream sources and actual
handle allocation. Upstream handles/m_handles are static, but file descriptors
and filenames are per recorder; native ownership must add owner/kind/lifecycle,
not reuse check_handle_kind as an ownership oracle. Avoid shared-default-filename
collisions. Failed superclass allocations return0 or-1 and must not register.
Ended-but-unfreed handles stay linkable; cross-owner links are legal. Component
begin/end can select different current recorders, unlike transaction.m_recorder;
route by original ownership. Arbitrary custom recorder integer namespaces can
collide, so native compatibility needs an explicit registration contract, never
silent adoption. A later initial block is not a deterministic default installer;
user static initializers and explicit custom recorder selection must be preserved.
Use an already-compilable original legacy release for initial lifecycle coverage;
keep1.1b/c compile reducers intact until the actual attribute API is available.
Evidence: independent recording_design_review, source anchors
uvm_recorder.svh40-41/247-365,uvm_object_globals.svh666,
uvm_component.svh2597-2760,uvm_transaction.svh667-671/776-784,
uvm_object.svh1294-1313 in original1.1b. Read-only review; no implementation
selected or changed while L31 is awaiting validation. Cross-model review skipped
in this automated continuation.

U14 concrete API review: use native lifecycle operations through the existing
context-DPI umbrella. Preserve explicit begin/end time as unsigned64, separate
from event occurrence time. Transaction-kind queries must see globally registered
transactions (including ended/unfreed) because component2649 uses that query
before linking its handle to the transaction's separately owned handle. Fiber
queries must require owner identity to invalidate stale component stream caches.
Mutation ownership stays separate. Child links are parent-to-child; caller may
own the right endpoint (transaction743/component2645), so a source-owner-only
link rule is incorrect. Preserve direction and both owners plus issuing recorder.

Native state/journal is authoritative; do not claim atomic commits across native
and superclass text logs. Validate before existing-handle mutations, reject
re-registration of retained ended handles, retain ended handles for links, and
specify live-transaction free behavior (upstream allows it). Journal write/flush
failure poisons the owner; later operations cannot report successful continuation.
If superclass allocation precedes failed native registration, explicitly undo
its membership when possible and fail the operation. New journal creation must
be exclusive, not exists-then-open, and must not collide with superclass text
output before its first open. Per-simulation cleanup must clear registry/callback
state as well as close native-owned streams. Full test must exercise actual
cross-owner begin_child_tr and component/transaction dual recording; manual links
alone would miss both API traps. These findings refine U14 before implementation;
no native source has been changed yet.

### DD039 — Bare class-scoped module variable declarations

During L22 negative-test construction, bare process::state s at module scope
parses as invalid instantiation. Independent ordinary class reducer
`class holder; typedef int state; endclass` followed by module holder::state s
fails the same way, outside the new builtin-specific lookup branch. Local
procedural declarations and typedef aliases work. Record-only general parser
gap; no grammar expansion under L22. Evidence l22/direct-module-state.sv and
ordinary-class-scoped-module.{sv,json}; bare module scope remains unqualified.

DD039 direct complete-class module declaration scope resolved by L30 at34787868e
after all required local gates. Enum identity, packed/unpacked shapes, initializers,
inherited typedefs, concrete aliases and process::state controls pass both editions.
Missing/non-type/incomplete/typeparameter prefixes remain rejected. Arbitrary
nested or parameterized class grammar and complete class qualification remain open.

### DD040 — Nested fork in a function-spawned background process

L22 release sweep now reaches UVM1.0p1 uvm_objection.svh m_forked_drop:
a function contains outer fork/join_none with nested fork/join_any in its
child begin/end. Existing diagnostic rejects inner join_any as function code.
IEEE1800-2023 13.4.4 allows task-legal statements inside function fork/join_none;
2017 wording and actual elaboration context need reducer/trace before selection.
UVM1.1a reports the same frontier. Record-only under L22; no dependent patch
on the unvalidated baseline. Evidence results-p7axbpcu/1.0p1/compile.log.

DD040 resolution: L23 58edf8034 permits blocking joins inside function-spawned
background children, retains direct-function rejection, and passes all required
gates. Original1.0p1/1.1a nested-fork errors removed; no full release pass.

### DD041 — Void function call in dedicated void-cast statement form

L23 original1.0p1/1.1a replay reaches three void'(void_function()) errors
(find_all/get_args). Independent standards review: both editions13.5 Syntax13-3
and AnnexA.6.9 allow void'(function_subroutine_call); A.8.2 does not restrict
return type. 13.4.1 forbids void functions as expressions but does not explicitly
forbid this dedicated statement form; ordinary6.24.1 cast grammar excludes void.
Candidate overly restrictive diagnostic, not established upstream-invalid source.
Permitted-statement reading is an inference needing a scoped ticket/reducer;
no relaxation or implementation during L23. Preserve calls/arguments/restrictions,
never fabricate a value or generalize to task/arbitrary-expression casts.
Evidence results-2hbuhcyt1.0p1/1.1a compile logs and original source.

### DD042 — Pre-1.1d command-line and regex DPI entry points

L24 makes original1.0p1/1.1a compile and start. Both then fail unresolved
DPI symbols dpi_get_next_arg_c/dpi_regcomp, producing four UVM command-line
regex errors (1.1a terminates BUILDERR at time0). 1.0p1 reaches smoke banner but
has errors and unresolved-functor/$cast diagnostics, so remains RUNTIME_FAIL.
Old native ABI must be inspected before reusing newer U09 cached-regex helpers;
no fabricated empty argv/regex match or DPI-disabled bypass. Record-only under
L24. Evidence results-6_pvcxya/{1.0p1,1.1a}/runtime.log.

### DD043 — Release smoke harness misses simulator runtime errors

During U11, original1.0p1 has no missing DPI and reaches its marker with zero
UVM summary counts, but still prints three unresolved-functor placeholder-net
and two failed-$cast runtime error lines already present under L24. The unchanged
smoke_passed helper checks exit/marker/UVM summaries only and incorrectly emits
SMOKE_PASS in results-zyhh1jv9. That raw row is explicitly disqualified; no clean
pass or full implementation claim. Original1.1a is a clean new smoke pass.
Record-only during U11; select a bounded harness-classification ticket at next
coordination boundary, retaining offending logs as negative regression evidence.
No compiler workaround or filtering of errors. 1.0p1 actual semantic gaps remain
separate from fixing the false-positive classifier.

DD043 resolved by U12 at1654dc4c9: fresh results-fm8uvyiv classifies1.0p1
RUNTIME_FAIL;quoted UVM_INFO remains informational. Underlying1.0p1 runtime
errors remain open. No original source or compiler changes.

### DD044 — Generic-seed callback initialization remains after L26 reducer fix

The larger `l26/forward-registry.sv` reducer has two failed casts before L26
and one after the concrete default-identity fix. The remaining failing method
belongs to a specialization keyed with unresolved forwarding from a generic
master, yet a static initialization thread calls it. Original UVM1.0p1 still
has two callback cast diagnostics in results-8054igtp and remains RUNTIME_FAIL.
This is evidence for the next bounded investigation, not yet a complete causal
explanation of both original errors. Keep unresolved generic type identities
distinct; do not equate runtime class names or suppress the cast diagnostics.
The standards say a generic class is not itself a type (both editions8.25).
Record-only during L26; preserve the original trace and failing/passing controls
before deciding the next implementation contract.

DD044 bounded direct/multilevel type-formal forwarding scope resolved by L28
at77cce610b after all required local gates. Both-edition counter/callback
reducers pass; original1.0p1 callback diagnostics are gone and its runtime
smoke passes. No runtime type-name equivalence or error suppression. Nested
type-expression/value-parameter lineage and complete class/UVM qualification
remain open; existing compile constraint/cast limitations are not resolved.

### DD045 — Foreach parser scope carrier recovery remains unqualified

L29 review found that foreach has its own untyped parser scope carriers. L29
repairs procedural begin/fork ownership; it does not redesign foreach recovery.
The nested malformed begin inside foreach rejects normally in both editions
after L29, but discarding the foreach carrier itself is a separate unqualified
robustness case. No independent failing reducer yet; record-only during L29.
Source: parse.y foreach productions; standards scope context12.7.3; do not claim
all parser recovery qualified.


### DD046 — User-requested sweep of all fallback and compile-progress paths

- **Active blocker:** DD046-TRIAGE-1 (see `.ai/ACTIVE_WORK.yaml`) as of
  2026-09-11, after the UVM smoke campaign closed (U15/U16, 15/15
  SMOKE_PASS). First triage pass:
  `evidence/campaign-20260908/dd046/triage-20260911.md`. Two candidates
  examined in `vvp/vpi_cobject.cc`. One (`vpiLineNo`) proved
  architecture-wide and was split out as DD049, not forced into a bounded
  fix. The other (a class string property's VPI write silently dropping
  when reached through a NESTED class-typed property, e.g. `obj.inner.s`)
  was root-caused, reduced (`evidence/campaign-20260908/dd046/c3.sv`), and
  resolved as **L33** (see `docs/conformance/BLOCKERS.md`). Its named
  integral follow-on was resolved as **L34** in the same pass, which also
  found and fixed a second, independent real regression (an array-indexed
  signal base silently mis-resolving) in the shared helper both L33 and
  L34 depend on -- see BLOCKERS.md L33's addendum and L34's own entry.
- **2026-09-11 comprehensive re-triage of the curated table below:** all
  twelve rows were checked against current source (nine with a concrete
  reducer, three by tracing callers/overrides where that settled the
  question without one). Eleven are now dispositioned RESOLVED or
  ALREADY-LOUD -- either fixed by earlier sessions since the table was
  written, already print a diagnostic before falling back (not DD046's
  silent-path concern), already correctly implemented for every legal
  construct tried, or (for `test_value_callback_ready`) a legitimate
  virtual-method default properly overridden wherever real filtering is
  needed. **Caveat, learned the hard way in this same session (L34's
  regression was silent at its actual source and loud only three layers
  downstream, in a generic safety net):** a nearby `cerr`/`fprintf(stderr`
  does not by itself prove a fallback is harmless, and "N reducers all
  came back correct" is *absence of a found defect*, not *proof of
  absence* -- three of the eleven rows (string/object lowering, casts,
  iteration) rest on a handful of reducers each, not exhaustive coverage,
  and are recorded here as such rather than as closed proofs. The table
  cells below record exactly what was tried for each; treat the "RESOLVED"
  label as "no defect found under this session's search," not "cannot
  contain one."
  **Lost expression typing** (`netmisc.cc`'s `elab_and_eval`, the silent
  empty-string/0.0-real/null substitution for "unresolved parameterized
  helper/container method paths that lose argument typing") was the
  twelfth row and the only one with zero loud diagnostics anywhere on its
  path. It was NOT closed by tracing a caller or a hand-written reducer --
  instead, temporary `getenv`-gated probes were added at all 7 silent
  stub sites (both `elab_and_eval` overloads), the compiler rebuilt, and
  the probe armed across two full corpora: the 357-test UVM smoke/
  regression suite (357/357 passed, 0 probe hits) and the complete
  ~5000-test legacy ivtest suite (4981/4976/0F/2NI/3EF -- the exact clean
  baseline, confirming the instrumented build introduced zero
  regressions; 0 probe hits). The instrumentation was then fully reverted
  (`git diff` on `netmisc.cc` shows no residual change) and the clean
  binary rebuilt/reinstalled. Per this pass's own calibration: an empirical
  sweep of ~5300 tests finding zero hits is stronger evidence than any
  other row's hand-picked reducers, but is still not proof the branch is
  unreachable by SOME construct neither corpus exercises -- recorded as
  such, not as a closed proof.
  **That caution proved warranted within the hour:** before moving on, a
  hand-built sanity construct (`real r; string s; r = s;`) was compiled
  with the same probe armed specifically to confirm the instrumentation
  COULD fire at all -- and it fired immediately, on the single most
  ordinary construct imaginable, not an exotic parameterized-method edge
  case. The REAL-target stub silently substitutes `0.0` for a well-typed
  STRING source with no exclusion, unlike its BOOL/LOGIC/vectorable
  sibling branch (which already excludes STRING, per R30's identical
  fix for a vector target). Root-caused against IEEE 1800-2017/2023
  6.16 (no string-to-real conversion is defined; the naive alternative
  of falling through to the existing real-cast codegen was traced and
  confirmed to also be wrong -- it would bit-reinterpret the string's
  packed bytes as an integer) and fixed as a hard error, closed as
  **L35** in `docs/conformance/BLOCKERS.md`. The lesson generalizes: an
  empirical sweep finding zero hits is only as trustworthy as the last
  time anyone confirmed the probe can fire at all -- always fire-test
  the instrumentation on a hand-built positive case before trusting its
  silence on a corpus. The `elab_expr.cc:8297` stub-callers thread
  (left open in the prior pass) was also traced to completion: 6 of 7
  callers already warn; the 7th is a deliberate silent placeholder for
  dead generic-template-body elaboration, tagged and consumed downstream
  exactly like the `in_unspecialized_param_class` case above -- correctly
  designed, not a defect. All twelve curated-table rows are now fully
  dispositioned; DD046-TRIAGE-2 is closed. Incidentally found along the
  way (both passes): `find()` on a plain (non-class-property) fixed-size
  array of non-integral elements is loudly rejected at elaboration
  (`elab_expr.cc:16554-16562`, "sorry: ... not yet implemented") -- a
  real, known feature gap, but loud, not silent, so not itself a DD046
  target; recorded here for completeness. `.ai/ACTIVE_WORK.yaml` carries
  the next-selection detail for DD046 beyond the curated table (mining
  the raw ~12,850-line fallback inventory, or shifting to the user's
  third priority phase).
- **Scope:** User explicitly expanded the request to sweep ALL fallbacks.
  Include parser/name/type resolution, elaboration, code generation, simulator,
  DPI/VPI, other compiler targets and qualification harnesses. Include silent
  constant/no-op substitutions, even without a fallback warning.
- **Evidence revision:** 3d60cb54a (compiler candidate0a4e7d639).
- **Inventory:** `evidence/campaign-20260908/fallback-tracked-candidates.tsv`
  and `.json` outside the checkout retain the file/line candidates and scanned
  file manifest. 608 tracked C/C++/header/grammar/Python/shell files scanned;
  12849 matching lines, with overlapping tags: fallback494, stub609,
  degradation2245, constant-return9652. These are search hits, NOT defect counts.
  Tests, third_party/vendor, skills, graph artifacts and untracked generated
  sources are excluded from this implementation inventory. Pinned UVM diagnostics
  remain independent application evidence.
- **Search vocabulary:** fallback/fall-back; stub/placeholder/compile-progress;
  ignored/silently/approximation/unsupported/not-enforced/noop/dummy/fabricated/
  dropped/forced-to/substitute; and literal zero/one/true/false/null/empty returns.
  Repeat against the selected revision and trace unnamed equivalent paths.

Source-confirmed candidates (reachability by legal source and exact semantic
loss still require reducers; comments and diagnostic wording are not an oracle):

| Area | Source anchors at evidence revision | Observed implementation | Qualification needed |
| --- | --- | --- | --- |
| Lost expression typing | netmisc.cc:1899 (STRING stub), 1905-1928 (REAL stub, FIXED as L35), 1845/2334/2400 (CLASS/NULL stubs), 2365 (STRING stub, 2nd overload) | **Re-triaged (2026-09-11), one real defect found and fixed as L35 after the initial "empirically unreached" disposition was challenged.** (Line numbers here are post-L35-fix current; the REAL-stub sites shifted by the fix itself, so this cell is re-anchored rather than left pointing at pre-fix locations.) These sites are the ONLY genuinely silent branches found in this whole DD046 sweep (no `cerr` anywhere on the path, unlike every sibling row). Temporary `getenv`-gated probes at all 7 stub sites (both `elab_and_eval` overloads) found zero hits across the 357-test UVM suite and the ~5000-test ivtest suite -- but per an advisor review, a probe that never fires and one that's never reached look identical, so a hand-written sanity reducer (`real r; string s; r = s;`) was built to confirm the instrumentation actually could fire before trusting that negative result. **It fired immediately** -- the REAL-target branch silently substituted `0.0` for ANY mismatched `tmp` type including a well-typed STRING, with no exclusion for the well-typed case unlike its BOOL/LOGIC/vectorable sibling branch (which already excludes STRING, per R30's fix for the identical defect shape on a vector target). Root-caused, spec-grounded (IEEE 1800-2017/2023 6.16 defines no string-to-real conversion; confirmed the naive fallthrough alternative -- `cast_to_real()`'s vec4-bitpattern-reinterpretation codegen -- is not spec-correct either), and fixed: closed as **L35** in `docs/conformance/BLOCKERS.md` (hard error, not a stub, matching the R32 class-handle/aggregate precedent). The STRING-target stubs (`1899`, `2365`) and the CLASS/NULL-target stubs (`1845`, `2334`, `2400`) were probed but never fired and were NOT touched -- they remain exactly the "empirically unreached across ~5300 tests, not proof of absence" disposition the initial pass gave, now demonstrated to need the same fire-test-first discipline before being trusted again. One further gap noted but not fixed: the second `elab_and_eval` overload's BOOL/LOGIC/vectorable branch (`netmisc.cc:2392-2398`, was `2352-2358` pre-fix) lacks the STRING exclusion its sibling (first overload, `1922-1924`) already has -- checked whether it's actually reachable: `netqueue_t : netdarray_t`, so the well-typed-aggregate hard error a few lines above already catches queue sources the same as fixed arrays, leaving only a genuinely VOID/NO_TYPE (unresolved-generic) `tmp` able to reach it -- the same "requires an actual unresolved-generic scenario" wall every other row in this sweep hit. Not sized as a promising next reducer target for that reason. | L35 (real=string) is closed. The STRING-target and CLASS/NULL-target stub branches remain open -- re-open with a fire-tested probe (confirm it CAN trigger on a hand-built construct before trusting a corpus sweep's silence) or a direct reducer. The second overload's un-excluded vectorable branch is very likely unreachable by the same aggregate-hard-error reasoning that already covers queues; not worth pursuing without new evidence. |
| Unresolved methods/functions | elab_expr.cc:8297; elaborate.cc:14061,14072 | **Re-triaged (2026-09-11), resolved.** Traced all 7 call sites of `elaborate_compile_progress_expr_method_stub_`. 6 of 7 already call `warn_compile_progress_stub_fired_` before returning the stub. The 7th (`elab_expr.cc:16388`, reached only via `should_defer_type_parameter_expr_call_`) is silent by design: it fires exclusively while elaborating a generic/unspecialized parameterized-class method body before real specialization (guarded by `is_deferred_type_parameter_expr_receiver_`, which explicitly excludes real built-ins like `randomize`/mailbox/semaphore/covergroup methods and any class with a resolvable method scope), and the resulting stub is tagged via `mark_deferred_type_parameter_stub()` so downstream consumers (e.g. the enum-assignment path at `elab_expr.cc:3334`, and `inherit_deferred_type_parameter_stub` propagation in `dup_expr.cc`/`pad_to_width.cc`/`netmisc.cc`) can recognize it as a placeholder from dead template-body elaboration that never actually executes -- the same deliberate "shape-check only" pattern already established for the `in_unspecialized_param_class` case in the Lost-expression-typing row above and the `initialize`/`m_initialize` cases in `elaborate.cc:14061`. Correctly designed, not a defect. | None -- deliberate and consistent with the codebase's established generic-body-elaboration pattern. |
| Casts | elab_expr.cc:18184 | **CLOSED as L37 (2026-09-11).** The prior re-triage stopped one branch short: the non-packed "unchanged-passthrough" fallback this row named was not a passthrough at all for a bit-stream cast to an unpacked struct (`s_t'(v)`, legal per IEEE 1800-2017/2023 6.24.3) -- it crashed the compiler (`Assertion failed: (net), function ivl_expr_value, t-dll-api.cc:1059`). Fixed by converting the crash into a clean `sorry: bit-stream cast ... not yet implemented` diagnostic (full bit-stream casting is a feature, not a fallback fix, and was explicitly scoped out per advisor review). Packed-target casts (the case this row's original reducers tested) remain correct and unaffected. See BLOCKERS.md L37. | None -- fixed. |
| Constraints | parse.y:18467; original1.0p1 pick_sequence compile diagnostic | **Re-triaged (2026-09-11).** Already loud (a suppressed-after-first `cerr` warning: "pkg::func(...) with-clause is parsed but not enforced ... constraints are silently dropped"). Scoped deliberately: the grammar comment states other package-function with-clauses "retain their compile-progress diagnostic" -- only `std::randomize(...) with {...}` gets real enforcement via `set_with_constraints`. No legal SystemVerilog construct calls an arbitrary `pkg::func(...)` with a `with` clause outside the randomize family (18.7), so this branch may not be reachable by standard code at all; not attempted with a reducer this pass. | Loud already; only worth a reproducer if a real randomize-family variant (not std::randomize itself) is found routing through this branch. |
| Events and waits | elaborate.cc:19847,20322,20458,20629,20775 | **Re-triaged (2026-09-11).** All five sites already print a `cerr` warning before skipping/no-opping (unresolvable event expr, scope-as-event, class-property event expr, empty event set, unelaborable wait condition, no event sources) -- none is silent. Not attempted with a reducer; the loud diagnostics already satisfy DD046's "not silent" bar for every cited line. | Loud already at every cited site. |
| Unresolved methods/functions | elab_expr.cc:8297; elaborate.cc:14061,14072 | **Re-triaged (2026-09-11).** `elaborate.cc:14061`'s `silent_noop` cases (`rand_mode`, `copy`/`do_copy`/`print`/`record`, `initialize`/`m_initialize`) are deliberate, individually justified by in-code Phase63b/B3-B4 comments citing specific known-safe UVM dead-spec patterns (a verified-safe deferred-init race, not an oversight) -- re-litigating these without new contrary evidence isn't productive. `elaborate.cc:14072`'s general unknown-task case is loud. `elab_expr.cc:8297`'s constant-stub expression method (`elaborate_compile_progress_expr_method_stub_`) was not traced to its call site(s) this pass to confirm whether callers already warn; unexamined. | The `elab_expr.cc:8297` stub's callers are the one open thread here; everything else is either deliberate-and-justified or already loud. |
| Iteration | elaborate.cc:22119 | **Re-triaged again (2026-09-11), $low/$high sub-candidate investigated further and BLOCKED (2026-09-13).** Still no reproducer reaching the original `elaborate.cc:22119` branch (fourth attempt: too-many-index-variables `foreach(assoc[k,j])` over a 1D associative array of structs, `evidence/campaign-20260908/other8-audited/iter2_toomany_idx.sv`). That attempt's own byproduct -- the construct compiles clean and then at runtime prints `function $low()/$high() argument object code is 615; using 0/-1 fallback` with the loop body never executing -- was pursued as a possible compile-time-validation gap: IEEE 1800-2017 12.7.3 states "The number of loop variables shall not be greater than the number of dimensions of the array variable," and `pt_t assoc[string]` is declared with one dimension while the reducer supplies two loop variables (`k, j`), which read as explicitly illegal. **But independent cross-check contradicts this reading**: `slang --std 1800-2017` (oss-cad-suite build) accepts the identical reducer with "Build succeeded: 0 errors, 0 warnings" -- no diagnostic at all. Per campaign policy slang is a comparison signal, not the normative oracle, so its silence doesn't prove the construct is legal -- but it does mean my own single reading of "dimensions" for an associative array whose value type is a struct is not solid enough to justify a NEW rejection in Icarus (adding a compile-time error here risks tightening Icarus stricter than a commercial-grade-target comparison tool, exactly the kind of move the campaign's correctness bar warns against making off one interpretation). Not re-derivable from a second reading of the same clause; would need either a second independent tool's datapoint (e.g. a licensed commercial simulator) or an LRM passage that explicitly addresses associative-array-of-struct dimensionality to break the tie. The runtime `$low()`/`$high()` "object code 615" fallback itself remains unexplained on its own terms (does it happen to coincide with whatever slang does internally for the same construct, i.e. some form of degenerate single-pass handling? untested) and is left as its own unresolved thread, separate from the "is this a missing rejection" question. | Re-open elaborate.cc:22119 if a nested-container shape reaching it is found. The `$low()`/`$high()` "object code 615" candidate is BLOCKED pending a tie-breaking oracle (a second real tool's verdict, or a more precise LRM citation on associative-array-of-struct dimensionality) -- do not add a compile-time rejection based on the 12.7.3 reading alone, it's contradicted by slang's acceptance. |
| Membership | tgt-vvp/eval_vec4.c:1937 | **CLOSED as L38 (2026-09-11).** The prior re-triage checked the plain-signal and class-property cases of the queue/darray arm immediately above the loud fallback, and both were real implementations -- but missed a third case in that SAME arm: a QUEUE-valued expression that is neither a plain signal nor a class property (e.g. a function call returning a queue) silently forced membership to `0` with no diagnostic. Root cause: the arm's own comment named "Queue/darray" but its condition only tested `IVL_VT_DARRAY`, never `IVL_VT_QUEUE` -- a missing-enum-value oversight. Fixed with the one-line addition. See BLOCKERS.md L38. | None -- fixed. |
| Increment/decrement | tgt-vvp/eval_vec4.c:2354 (now ~2351) | **RESOLVED (2026-09-11 re-triage).** `draw_unary_inc_dec`'s switch handles `IVL_EX_SIGNAL`/`IVL_EX_SELECT`/`IVL_EX_PROPERTY` with real codegen; only a genuinely unhandled expr type reaches the `default:` fallback, which itself prints a loud `sorry:` before the read-only fallback. Reducers for the two legal lvalue shapes a table reader would suspect (queue element `q[0]++`, associative-array element `assoc["k"]++`) both compute correctly (`evidence/campaign-20260908/dd046/c14_incdec.sv`) -- neither reaches `draw_unary_inc_dec` at all, so this candidate is not reachable by the constructs it looked like it should cover. | None -- already loud where reachable, and the obvious legal reproducers don't reach it |
| Array locators | tgt-vvp/eval_object.c:2584,2622 (elaboration gate: elab_expr.cc:16554-16562) | **CLOSED as L36 (2026-09-11).** The prior re-triage's own framing was the bug: it treated the plain-signal "loud `sorry:` at elaboration" as evidence the row was resolved, without checking whether that `sorry:` was firing on ILLEGAL input. It was not -- IEEE 1800-2017/2023 7.12.1 places no restriction on element type or declared base for array locator methods, and the rejection fired on both non-BOOL/LOGIC elements and non-zero-based declared ranges for plain fixed-array signals. Fixed by unconditionally materializing any fixed array (direct-signal or property) into a `netdarray_t` temp, matching the sibling `make_array_unique_expr_` pattern, and widening the supported-element-type gate to BOOL/LOGIC/REAL/STRING/CLASS. See BLOCKERS.md L36. | None for the L36 scope. Follow-up candidate (2026-10-08, issues #422-#426): multidimensional fixed locators, aggregate value copying, and wrapper result typing pass the focused local legacy and JSON/VVP suites (16/16 each) under `-g2012`, `-g2017`, and `-g2023`; exact-head CI is pending. Associative locator gaps remain. See the dated Chapter 7 matrix entry. |
| String/object lowering | tgt-vvp/eval_string.c:249; tgt-vvp/eval_object.c:1197,1282 | **Partially re-triaged (2026-09-11); further narrowed with structural evidence (2026-09-15).** `eval_object.c`'s two select/null fallbacks (1197, ~1280) are already loud (`fprintf(stderr, "Warning: ...")` before the `%null`), not silent. `eval_string.c:249`'s "select on an unsupported base type -> empty string" fallback IS silent (no diagnostic) and remains genuinely open in principle, but is now backed by a much stronger unreachability case than "five failed reproducers": (1) five prior attempts (ternary-selected string, string-concat select, bare function-call-result select, string-method-result select, queue-of-strings element select) each hit an earlier parser/elaboration rejection or resolved through an already-working path; (2) two MORE attempts this pass (a queue/darray-of-string concatenation then select -- `{qa,qb}[i]` -- and a mixed real-string-variable-plus-literal concatenation then select -- `{stringvar,"x"}[0]`) both also hit earlier, *different* rejections (the first is now L118's new `error:`, confirmed independently illegal via slang; the second hits `PEPostSelect::test_width`'s own pre-existing `!type_is_vectorable(base_->expr_type())` guard, "A postfix select requires a packed integral expression"); (3) tracing `PEPostSelect::test_width` directly (elab_expr.cc:13096) shows it ALREADY gates every select base to `type_is_vectorable` before elaboration ever runs -- a STRING-typed concat base (real string operand present) is rejected there, and a QUEUE/DARRAY-typed concat base is now rejected by L118's separate operand-type check (added because `PEConcat::test_width_`'s own crude expr-type computation doesn't detect queue/darray operands as non-vectorable, the one gap that let L118's reducer through). The two grammar-legal shapes that can reach `PEPostSelect`/produce an `IVL_EX_SELECT` at all -- `hierarchical_identifier select` (fully covered by the SIGNAL/ARRAY/PROPERTY branches earlier in `string_ex_select`) and `concatenation [ [ range_expression ] ]` (now shown to be gated to vectorable-only at elaboration, and a vectorable result is handled by `string_ex_select`'s own BOOL/LOGIC branch at the top, before ever reaching line 249) -- are both now accounted for. This is not a formal proof, but it is elaboration-level structural coverage, not just failed-reproducer accumulation; treat this branch as very likely dead code reachable only through a shape not yet identified. | Re-open only if a specific reproducer is found for the `eval_string.c:249` branch -- given the structural coverage above, that would most likely mean a shape that reaches `IVL_EX_SELECT` through neither `PEIdent` nor `PEPostSelect` (e.g. a different PExpr subtype's `elaborate_lval`/`elaborate_expr` also constructing a `NetESelect`), not another attempt at a concatenation or identifier select. |
| Missing executable targets | tgt-vvp/vvp_process.c:808 | **Re-triaged (2026-09-11).** `emit_td_stub_definitions()` is a defensive bookkeeping safety net (emit an empty label for any thread-destination referenced but never defined, so a stray forward reference can't produce a dangling jump) rather than a feature-implementation fallback; not traced further this pass to find a legal construct that leaves a genuine reference unresolved. | Unclear this represents user-visible incorrect behavior; would need a concrete case where a legally-reachable TD reference has no definition. |
| Simulator/VPI | vvp/compile.cc:1148; vvp/vpi_callback.cc:217 | **Re-triaged (2026-09-11), both resolved.** `compile.cc:1148`'s placeholder-net path is already loud (`unresolved_warn_once`) and is the generic safety net that ANY malformed functor reference trips -- it is literally the mechanism whose output ("unresolved functor stub"/"created placeholder net") was the observed symptom of the real L34 regression this session found and fixed; it did its job correctly. `vpi_callback.cc:217`'s `test_value_callback_ready()` "stub" is a legitimate virtual-method default (always-ready is correct for a plain full-value-change callback) properly overridden by `value_part_callback`/`array_word_part_callback`/`runtime_array_word_value_callback` wherever real bit/word-range filtering is actually needed -- traced all overrides and call sites; this is correct OOP design, not a defect. | None -- both already resolved (one already loud+working-as-intended, one already correctly designed). |
| Qualification fallback | .github/uvm_test.sh:139 | Already understood at DD046's original writing: this row's own "Qualification needed" column already states the correct handling (keep real-DPI/no-DPI evidence separate). Not re-examined this pass; harness-flavored, not a compiler-semantics candidate. | Low priority; the existing disposition already looks correct. |
| Chained container index + string select | elab_expr.cc: `apply_trailing_container_indices_` (~2499) | **CLOSED as L39 (2026-09-11).** New row -- found (not in the original DD046 table) while auditing container-indexing paths. `obj.q[0][1]` (a class-property queue-of-strings, element-select then byte-select) hit `sorry: this index does not select a queue or associative-array class-property value`, even though both a bare `string_var[1]` and a class-property queue-of-queues `obj.q[0][0]` already worked independently via the identical `NetESelect` shape -- the shared indexing loop dispatched on `netvector_t`/`netarray_t` for the intermediate type but had no `netstring_t` branch. Fixed by adding one, reusing the existing `elab_assoc_index` helper. See BLOCKERS.md L39. | None -- fixed. |
| Class-handle rvalue degrade inside a real specialization | netmisc.cc `class_rval_degrade_ok` (~1644-1750) | **CLOSED as L40 (2026-09-11).** New row -- found while auditing the STRING/CLASS `netmisc.cc` stub candidates for a genuine unresolved-generic reproducer. A specialized parameterized class (`container#(obj_c)`) whose own method assigns a class-handle-typed value (via its type parameter `T`) to a `string` local variable silently produced `""` with ZERO diagnostic, because the guard's `in_class_scope` check is coarse (true for any class body, dead template-seed or real specialization alike). A first wholesale-narrowing attempt (swap `in_class_scope` for `in_unspecialized_param_class` outright) broke `uvm_vreg::allocate()`'s ordinary `this.mem = mam.get_memory();` -- instrumentation traced this to a THIRD scenario: `uvm_vreg.svh`/`uvm_mem_mam.svh`'s circular forward-declaration collapses the target to `cast_type==IVL_VT_BOOL` (the same mechanism as the documented LOGIC forward-ref case, just 2-state). Fixed correctly with a narrow additional carve-out (`in_real_specialized_param_class`, the logical complement of `in_unspecialized_param_class` within a parameterized class body) that hard-errors only a real specialization, leaving `in_class_scope`'s broad permissiveness -- BOOL collapse included -- completely untouched. See BLOCKERS.md L40. | None -- fixed. |
| Integral class-property read as a string | vvp/class_type.cc:536 (`class_property_t::get_string` base-class default) | **CLOSED as L42 (2026-09-13).** Found incidentally while building the L40 "must stay silent" reducer. Reading an ORDINARY integral class property back as a `string` from inside its own class method warned and returned `""` instead of the IEEE 1800-2017/2023 6.16 packed-byte value a plain (non-property) variable already got. Root cause confirmed: `property_atom<T>` (int/byte/shortint/longint properties) and `property_logic` (4-state vector properties) never overrode `get_string`/`set_string`, falling to the base class's "unsupported" stub -- NOT a decimal/itoa formatting gap as first guessed, but a missing byte-packing conversion (confirmed against the LRM: "values of integral type can be assigned to a string variable... zero-filled on the left"). Fixed by extracting the exact conversion the existing `%pushv/str` vvp opcode already used for plain variables into a shared `vector4_to_packed_string()` helper, and adding `get_string`/`set_string` overrides to both classes that reuse it (plus a shared `pack_string_into_vec4_()` for the write direction, mirroring `%cast/vec4/str`'s right-justify/truncate/zero-fill semantics). `property_bit` (2-state `bit` vectors) turned out unaffected -- it already worked, apparently routing through the same materialization as `property_atom<T>` for common widths. See BLOCKERS.md L42. | None -- fixed. |

- **Triage:** OPEN, semantic classification pending. Ordinary allocation
  fallbacks, generated DPI bridge stubs, valid empty-container results and
  error-recovery paths are not automatically defects. Inspect the surrounding
  control flow and terminal diagnostic status. Source-confirmed substitution
  does not yet prove a legal reproducer reaches it.
- **Completion rule:** Every candidate must be classified as valid behavior,
  unreachable/superseded with evidence, explicit unsupported/qualification gap,
  or a reproduced semantic defect. All legal behavior-changing fallbacks need
  standards-grounded implementation and permanent regressions; warning removal,
  an unsupported error, or a smoke pass alone cannot close that obligation.
  Keyword coverage is not semantic exhaustiveness; review default branches,
  early returns, ignored statuses and synthesized values by requirement cluster.


DD046 first reachability check: a fixed-size real array `find with (item > 1.5)`
is rejected with compile exit1 in both2017/2023 before code generation:
"find() on fixed-size arrays of non-integral elements is not yet implemented."
The fallback in eval_object.c is therefore not reached by this reducer. Record
this case as an explicit unsupported legal feature, not observed fabricated
runtime results. Evidence: `evidence/campaign-20260908/fallback-reducers/`
`fixed-real-find.sv` and `fixed-real-find.json`. Other routes remain unqualified.


DD038 prerequisite U14 locally validated at729edce3c with test/CI79885f484:
explicit original1.1d lifecycle recorder, native owner/handle registry, retained
exclusive file descriptors, cross-owner links and allocation rollback are real
and regression-tested. Full local gates pass (BLOCKERS U14). Typed attribute
capture and deterministic default installation remain mandatory and OPEN;
original1.1b/c still fail the missing macro. No parent completion claim.


### DD047 — String literal with a high-bit byte fails to load as a vector operand

- **Active blocker:** L32; record-only.
- **Observation:** `x = "\301B";` into `reg [15:0]` and `y = "\377";` into
  `reg [7:0]` compile with exit 0 in both 2017 and 2023, but vvp refuses to load:
  `numeric operand out of range` (`%pushi/vec4 18446744073709535554, 0, 16`).
  Expected: x=c142, y=ff.
- **File/function:** `tgt-vvp/eval_vec4.c` `draw_string_vec4`:
  `tmp |= (unsigned long)*p` on a plain `char`, which is signed on this ARM64 host,
  so bytes of 0x80 and above sign-extend.
- **Possible clause:** IEEE 1800-2017/2023 5.9 (literal operands are unsigned
  integer constants of 8-bit values).
- **Evidence:** `evidence/campaign-20260908/l32/dd-hibit-assign.v` and `.log`.
  Not introduced by L32 (`ab54351c3` touches only `vvp/vpi_const.cc` among
  implementation files). Upstream master still has the same loop.
- **Triage:** OPEN; reproduced; candidate for the next selection.

L32 note: upstream master `vvp/vpi_const.cc` still has the pre-L32 literal
`vpiVectorVal` loop. Upstream `ivtest/ivltests/swrite.v` still has the endian
probe that depended on it. An upstream report is a separate, unfiled action.


### DD048 — __vpiVThrStrStack has no vpiVectorVal path; vpiSize unit differs from __vpiStringConst

- **Active blocker:** U15; record-only (worked around, not fixed).
- **Observation:** A systf string argument that is not a bare literal --
  a `string` variable, an enum `.name()` result, a function-call result, or a
  runtime concatenation -- is represented by `__vpiVThrStrStack`
  (vvp/vpi_vthr_vector.cc), which rejects `vpiVectorVal`
  (`vvp error: get 9 not supported by vpiConstant (String)`, unconditional
  stderr, format returns `vpiSuppressVal`) even though `vpiType`/`vpiConstType`
  report `vpiConstant`/`vpiStringConst` identically to a real literal (a
  `__vpiStringConst`, vvp/vpi_const.cc, L32-fixed). The two classes also
  report `vpiSize` in different units for the same property code:
  `__vpiStringConst` returns bits (`value_len_*8`); `__vpiVThrStrStack`
  returns characters (`val.size()`). A 5-character enum `.name()` reports
  `vpiSize==5`, not 40.
- **File/function:** `vvp/vpi_vthr_vector.cc` `__vpiVThrStrStack::vpi_get_value`
  (no `vpiVectorVal` case) and `__vpiVThrStrStack::vpi_get` (`vpiSize`).
- **Consequence for U15:** `$ivl_uvm_record_attribute`'s string encoder
  (uvm_dpi/uvm_recording.cc) cannot use `vpiType`/`vpiConstType` to select a
  byte-exact read path, since both classes present identically at that level.
  It instead reads `vpiStringVal` first and compares the result's length
  against `vpiSize` under both possible unit conventions (`*8` and as-is);
  only a mismatch (reachable in practice only via a true literal whose value
  contains an embedded NUL, which `__vpiStringConst`'s own `vpiStringVal`
  branch alters rather than truncates) triggers a `vpiVectorVal` retry. This
  keeps the common non-literal path silent and correct and confines the
  byte-exact/embedded-NUL path to where it is actually reachable, but it does
  not give `__vpiVThrStrStack` a lossless path: a genuinely NUL-containing
  runtime string expression (e.g. a literal fragment concatenated into a
  variable at runtime) cannot be captured exactly and is reported as a loud
  failure rather than silently truncated.
- **Evidence:** `evidence/campaign-20260908/u15/se2.sv`/`se2.c` (direct
  probe), `expression-string-args-20260911.log` (pre-fix failure),
  `expression-string-args-fixed-20260911.log` (post-fix). Permanent
  regression: `tests/uvm_releases/recording_attribute.sv` `string_enum_name`/
  `string_func_result`/`string_concat` cases plus the harness's
  `"vvp error: get" not in output` assertion.
- **Triage:** OPEN; reproduced; candidate for a future selection. Giving
  `__vpiVThrStrStack` a `vpiVectorVal` path (and reconciling the `vpiSize`
  unit inconsistency generally, not only for this one caller) is a separate,
  non-trivial VPI runtime change, out of U15's scope.


### DD049 — vpiLineNo/vpiFile never captured for signals, part-selects or class variables

- **Issue status:** [OPEN #501](https://github.com/dsellerbrock/iverilog-uvm/issues/501).

- **Active blocker:** DD046 triage; record-only.
- **Observation:** `vpi_get(vpiLineNo, handle)` returns a hardcoded `0` for
  every ordinary signal/net/reg (`__vpiSignal`, `vvp/vpi_signal.cc:552`),
  every part/bit select (`__vpiPV`, `vvp/vpi_signal.cc:1415`), and every
  class variable (`__vpiCobjectVar`, `vvp/vpi_cobject.cc:201`) -- all three
  sites carry the identical `// Not implemented for now!` comment. `struct
  __vpiSignal` (vvp/vpi_priv.h) has no file/line storage field at all: the
  value was never captured, not merely left unwired to an existing field.
- **Possible clause:** IEEE1800-2017 37.3.3: "Most objects have... vpiLineNo
  [and] vpiFile... applicable to every object that corresponds to some
  object within the source code," with an explicit exception list that does
  not include signals, part-selects, or class variables -- so this is
  normatively required for these kinds, not optional.
- **Reachability:** trivial; any `vpi_get(vpiLineNo, ...)` on an affected
  handle observes it.
- **Scope:** architecture-wide, not a bounded single-function fix. A correct
  fix needs new file/line plumbing from elaboration through netlist
  compilation into vvp bytecode/VPI object creation, for every affected
  object kind (not fully enumerated -- these three classes were the ones
  examined; other classes were not checked for the same pattern).
- **Evidence:** `evidence/campaign-20260908/dd046/triage-20260911.md`
  (Candidate 1).
- **Triage:** OPEN; reproduced; too large for one bounded DD046 increment.
  A future selection should scope it explicitly as its own multi-part
  feature (which object kinds, what elaboration-to-vvp plumbing) rather than
  a single reducer-sized fix.

### DD-018 — Procedural package import after a local declaration (L43)

- **Current status (2026-09-14):** IMPLEMENTED with focused validation; L43 implements
  the legal declaration-prefix case with invalid-placement safeguards.
- **Correction to the L41 assessment:** the archived reducers declared
  `function foo_t get_val()` before importing `foo_t` inside the body. Their
  syntax failure occurred at the return type, before the import. With an `int`
  return type, a leading import already works. An import after `int dummy;`
  instead reaches an existing statement-context production and fails with
  `What kind of statement? 5PNoop` during elaboration.
- **Root cause:** package lookup is already installed by
  `pform_package_import`; the fallback statement production creates an
  unelaboratable `PNoop` for a declaration. A one-line null replacement was
  rejected in review because it also accepts illegal conditional/late imports
  and crashes when an attribute is bound through the null statement.
- **Grammar investigation:** the old +222 reduce/reduce jump is reproduced
  by duplicating the already-present `block_item_decl` import alternative.
  Bison state 1230 contains two identical completed productions and all 222
  extra conflicts. This is not evidence of a DPI-import collision. Scratch
  reports: `evidence/dd018-assessment/{baseline,duplicate}.output`.
- **Normative basis:** both IEEE 1800-2017 and 1800-2023 A.2.1.3,
  A.2.6-A.2.8 and 26.3. Imports belong in declaration prefixes, not arbitrary
  statement positions. The earlier A.6.3 citation was imprecise; the
  `block_item_declaration` production is in A.2.8.
- **Evidence:** corrected reducers and pre-fix six-error regression logs in
  `evidence/dd018-assessment/`. Permanent positive source:
  `ivtest/ivltests/sv_procedural_package_import.v`.

### DD-019 — Packed mixed-driver compound assignment aborts (PRINCE)

- **Discovered during:** L43; independent assessment only, not active implementation.
- **Observation:** freshly compiled unmodified OpenTitan `prim_prince_sim`
  aborts in `vvp_fun_concat::recv_vec4_pv`: port 0 expects 256 bits, receives
  384. Compiler/target/runtime hashes were unchanged during this replay.
- **Reducer:** `evidence/opentitan-runtime-assessment/packed_compound_drivers.sv`.
  A six-word packed array has word 0 assigned in `always_comb`, with `^= 0`
  following the ordinary assignment; other words are continuously driven.
  The plain-assignment control passes. Compound form reproduces the exact abort.
- **Root-cause hypothesis:** ordinary assignments use `%force/vec4/off` for
  a signal lowered to an unresolved net, while `put_vec_to_lval` emits
  `%store/vec4` for the compound form. The runtime store reaches the concat
  network with the full packed width. Investigate target write routing,
  not a width-clamping workaround in the concat runtime.
- **Normative basis to verify at activation:** IEEE 1800-2017/2023 6.5
  (independent packed elements may have different kinds of drivers), 11.4.1
  (compound assignment equivalence and single index evaluation).
- **Status:** L44 implemented with focused validation. Full PRINCE success is unproven;
  missing native DPI dependencies may expose a later independent failure.

### DD-020 — Unresolved task calls compile and continue after a warning

- **Issue status:** [OPEN #500](https://github.com/dsellerbrock/iverilog-uvm/issues/500).

- **Discovered during:** L44, independent next-blocker assessment.
- **Observation:** the OpenTitan synchronizer test calls mode/interval setter
  tasks absent from the pinned `prim_cdc_rand_delay` implementation. The
  compiler ignores all six enables instead of rejecting the unresolved calls.
  That application cannot serve as clean simulator qualification evidence.
- **Reducer:** `evidence/unresolved-task-assessment/missing_task.sv` calls an
  undeclared task and prints a marker afterward. Both 2017 and 2023 compile
  with exit 0 and execute the marker. `results.json` records both runs.
- **Location:** `PCallTask` elaboration in `elaborate.cc`, including the
  SystemVerilog-only bare unknown-task warning/no-op branch near line 14069;
  qualified/class paths contain related fallbacks requiring separate assessment.
- **Expected:** an unresolved enable cannot be treated as a successful call.
  IEEE 1800-2017/2023 13.3 and 23.8.1 govern task calls and lookup.
- **Status:** L45 implements the bare unqualified-call diagnostic. Qualified
  and class fallback paths remain OPEN and must not be mistaken for semantics.
  The synchronizer's reset-time queue mismatch itself remains untriaged; the
  missing setters are not claimed to be its root cause.
- **Post-L48 assessment:** `missing_package_task.sv` calls a missing task in an
  existing package; `missing_hier_task.sv` calls a missing task in an existing
  module instance. Both compile and execute `CONTINUED` in both editions.
  `evidence/unresolved-task-assessment/qualified-results.json` records all four
  runs. Package and hierarchical fallback branches remain distinct next fixes;
  preserve valid forward declarations and class method dispatch when correcting
  them. No implementation or qualification is claimed yet.

DD-020 qualified-call follow-up: `qualified-shadow-function-results.json`
records an explicit missing package call from a class compiling and continuing
in both editions despite a same-named class method. Valid package void/nonvoid
functions and hierarchical void functions retain their side effects in the
positive control. These form the next bounded elaboration checks.

Indexed hierarchy follow-up: `indexed_hier_task_valid.sv` calls a real task in
`child dut[1:0]`. Both editions discard `dut[1].bump()` and leave both counters
zero (`indexed-hier-task-results.json`). This is an execution defect for a
valid call, distinct from missing-call diagnostics. The early indexed-object
fallback bypasses ordinary hierarchical task lookup. Scope/object separation
must preserve valid object-array methods when fixing module/generate calls.

L51 implements downward package-qualified task/function statement lookup,
including valid self-qualified forward tasks and exported subroutines. Missing
members no longer fall back to compilation-unit task/function shadows or
warning/no-op paths. IEEE 23.7.1 requires this downward-only resolution.
Legacy 4/4 and JSON 8/8 pass; hierarchical and class fallback debt remains open.

L52 resolves fixed indexed hierarchy through the ordinary task/function path
and rejects missing members on proven indexed scopes. Module/generate tasks,
copy-out, delays, void functions and object-array controls pass (legacy 5/5,
JSON 10/10). Unknown/out-of-range/over-wide instance selections are diagnosed;
legal negative indices including INT_MIN pass. Unindexed missing hierarchical
tasks and class fallback paths remain OPEN. Full batch qualification is pending.

### DD-021 — Dynamic subpart of a disjoint mixed-driver element is rejected

- **Issue status:** [OPEN #472](https://github.com/dsellerbrock/iverilog-uvm/issues/472).

- **Discovered during:** L44 boundary validation.
- **Observation:** a fixed packed element written procedurally through a dynamic
  subpart, with a different fixed element continuously driven, is rejected as
  also continuously assigned before target emission.
- **Authority:** IEEE 1800-2017/2023 6.5 permits disjoint static prefixes to have
  different driver kinds; dynamic selection inside a fixed element does not
  make the entire containing array the longest static prefix.
- **Status:** OPEN. L44 covers the accepted static mixed-driver route only.
  Do not register this legal source as an expected language-error regression.

### DD-022 — Packed subpart writes escape the selected element

- **Issue status:** [OPEN #471](https://github.com/dsellerbrock/iverilog-uvm/issues/471).

- **Discovered during:** DD-021 prerequisite assessment alongside L45.
- **Reducer:** `evidence/dynamic-mixed-driver-assessment/subpart_bounds.sv`;
  `logic [1:0][7:0] words = 16'ha520` followed by a procedural
  `words[0][pos +: 4] = 4'hf`, with `pos=8`, changes the upper element:
  observed `16'haf20`, expected unchanged `16'ha520`. Both editions fail
  the runtime assertion; `bounds-results.json` records the results.
- **Authority:** IEEE 1800-2017/2023 11.5.1: wholly out-of-range part-select
  writes have no effect; partially out-of-range writes affect in-range bits only.
- **Root-cause evidence:** `normalize_variable_part_base` flattens a subpart
  offset into the full packed signal. `NetAssign_::set_part` retains the flat
  base and width, without the selected element's bounds. The runtime therefore
  treats the adjacent element as in range.
- **Read counterpart:** `subpart_read_bounds.sv` reads `5` from the neighboring
  element instead of `x` in both editions (`read-bounds-results.json`).
- **Status:** OPEN prerequisite to DD-021. Do not merely relax mixed-driver
  rejection while writes can escape the static prefix into continuous drivers.
  Assess ordinary, compound and nonblocking write paths plus read semantics,
  partial overlaps, index single evaluation, ascending/descending declarations
  and unknown indexes before choosing the shared correction.

- **L46 bounded implementation:** read-only indexed `+:`/`-:` selects with a
  fixed packed prefix will retain the selected carrier as nested `NetESelect`
  nodes. Write semantics remain OPEN regardless of read-focused test results.
- **Write design checkpoint:** preserve canonical selected-carrier bounds through
  `NetAssign_`, `dup_lval`, target lvalue transport and synthesis. Consumers include
  VVP blocking/compound/NBA paths, procedural sensitivity/write analysis,
  `synth2.cc`, and VHDL/Verilog source targets. Reuse interval intersection logic;
  do not duplicate index evaluation or silently drop partial in-range writes.
- **Additional boundary:** `prefix-bounds.sv` reads `3` instead of `x` from
  `words[0][3][0+:4]` when the middle declared dimension is `[2:0]`.
  `prefix-results.json` records the 2023 failure. Constant prefix flattening
  also lacks per-dimension bounds checks; L46's valid-prefix read scope does
  not qualify this case.
- **L48 focused read correction:** final-dimension indexed reads preserve every
  packed prefix as a nested selection, including dynamic and unknown prefixes.
  Focused tests cover both editions, unpacked-word suffixes, two-state results,
  wide indices, single evaluation, and unchanged subarray selection. Legacy 2/2,
  JSON 4/4, L46 neighbor 2/2, and null/synthesis checks pass. Packed writes remain
  OPEN and broad qualification remains pending.
- **L49 synthesis baseline:** `write-synthesis-runtime.sv` synthesizes the
  combinational DUT with `-S` and simulates it under a retained testbench.
  Both editions return `a7e0` instead of `a5e0` for a partial write into the
  low packed element. `write-synthesis-red-results.json` records the failures.
  A target compile-only smoke cannot establish correct write semantics.

### DD-023 — Wide constant one-dimensional select aliases in formatting arguments

- **Discovered during:** L46 wide-index review.
- **Reducer:** `evidence/dynamic-mixed-driver-assessment/one-dimensional-wide.sv`.
  Formatting `value[64'h1_0000_0000+:4]` for an eight-bit value produces `0101`
  instead of `xxxx`, while the dynamic-base version produces `xxxx` after L46.
  Both editions fail the string-result assertion. Assignment context does not
  reproduce this case, so do not claim all constant reads are affected.
- **Authority:** IEEE 1800-2017/2023 11.5.1.
- **Evidence:** `one-dimensional-wide-results.json`. The analogous nested packed
  read passes both modes (`nested-wide-format-results.json`).
- **Status:** L47 focused value/callback correction implemented. Constant
  normalization and VPI base transport both required correction; direct VPI
  read/write and parent-value callback checks pass both editions. Full metadata
  and index-only callback triggers remain unqualified.


DD-022 follow-up evidence: `prefix-boundary-results.json` shows both editions
reading neighboring bits for an out-of-range or X middle prefix, while evaluating
the final index function once. `prefix-outside.sv` and `prefix-unknown.sv` are the
next read-side reproducers; neither is qualified by L46/L47.

DD-022 write-side preparation: `write-boundary-results.json` contains six failing
checks across both editions. Blocking and nonblocking writes to `words[0][6+:4]`
change `a520` into `a7e0` instead of `a5e0`; compound XOR produces `a6e0`, also
changing the adjacent element. Sources are `write-blocking.sv`,
`write-compound.sv` and `write-nonblocking.sv` in the same evidence directory.
The read fixes do not qualify these assignment paths.

L49 focused write correction preserves carrier bounds for defined, valid fixed
packed prefixes across blocking, compound, NBA and synthesis. Legacy 4/4,
JSON 8/8 and a root 228-case boundary matrix per edition pass. Constant compound
and unpacked-array routes have permanent review regression assertions. Dynamic
and invalid write prefixes, unsupported source-target translations and broad
qualification remain OPEN; DD-021 is not relaxed by this increment.

### DD-024 — Empty implicit sensitivity crashes synthesis

- **Discovered during:** L49 constant-write validation. A reducer with no RHS
  reads did not isolate packed-carrier synthesis.
- **Reducer:** `evidence/dynamic-mixed-driver-assessment/synthesis-empty-sensitivity.sv`
  contains a one-dimensional output assigned a constant in `always @*`.
  With `-S -tnull`, both editions warn that the block will never trigger, then
  crash with exit 139. `synthesis-empty-sensitivity-results.json` records this.
- **Scope:** independent of packed-carrier metadata; this reducer has no packed
  subpart selection. Whether it predates L49 has not been verified against a
  prior binary. Do not count the crash as a packed-write qualification failure
  after replacing that test with a DUT that actually reads an input.
- **Expected:** preserve the semantics of an event wait with no triggering
  signals, or report an explicit synthesis limitation. Never infer a constant
  driver merely because the unreachable assignment contains a constant.
  IEEE 1800-2017/2023 9.4.2.2 governs implicit event controls; compare the distinct
  time-zero execution rule for `always_comb` in 9.2.2.2.
- **Status:** L50 fixes null-body dereferences in asynchronous classification
  and legacy synthesis tokenization. Focused legacy 2/2 and JSON 4/4 pass,
  preserving dormant X output, time-zero always_comb execution and ordinary
  retriggering. Forced synthesis still rejects explicitly. Broad qualification
  remains pending.


L43–L52 batch qualification checkpoint (`c686a4781`, 2026-09-14): all local
broad gates pass after correcting null AST actions, selector name handling,
sensitivity selection kinds, declared two-state read casts and VPI array-word
signedness. This supersedes the broad-pending notes for L43–L52 above; DD-024
is locally qualified within its stated empty-wait scope. The broader DD-020,
DD-021 and DD-022 obligations remain open.

Next DD-020 evidence: `unindexed-hier-frozen-candidate.json` still observes
`dut.missing()` compiling successfully in both editions. Valid module/package
forward tasks and indexed object methods pass the accompanying controls.

Next DD-022 evidence:
`evidence/dynamic-mixed-driver-assessment/invalid-prefix-writes/results.json`
records constant OOB and X prefixes leaking blocking, compound and NBA writes
in both editions (six cases per edition). Final-index and RHS functions each
execute once. A correction must preserve that evaluation while preventing
invalid stores; classifying dynamic prefixes as constant-invalid is incorrect.

L53 focused follow-up closes the proven non-class/non-package unindexed
hierarchy receiver case: missing tasks are diagnosed after existing resolution
attempts. Legacy13/13 and JSON24/24 pass with forward-call effects and inherited
method controls. Unresolved receivers and broader object-method fallbacks
remain open; full batch qualification is pending.

L54 focused correction suppresses indexed writes through proven-invalid
constant packed prefixes in the common lvalue path. Blocking, compound, NBA
and unpacked-word controls preserve evaluation counts and unchanged storage;
legacy4/4, JSON8/8 and independent ordinary/synthesized runtime checks pass.
A 128-bit prefix probe passes with existing host-width warnings. Dynamic
prefixes remain open. DD-021 still reproduces on the L53 baseline in
`dynamic-after-l53-results.json`: a dynamic subpart of words[0] is rejected
when words[1] has the disjoint continuous driver. The next implementation must
reuse exact static-prefix bounds rather than relax driver conflicts globally.

L55 focused DD-021 correction checks the driven mask of a proven valid fixed
packed carrier before permitting a dynamic final subpart write. The permanent
positive exercises blocking, compound and delayed NBA, partial low/high and
both directions, unknown/OOB bases, continuous neighbor updates and evaluation
counts. Actual same-carrier overlap remains a compile error. Legacy7/7 and
JSON14/14 pass. The earlier unpacked whole-word conflict guard and unproven
prefix cases remain open; this is not full mixed-driver completion.

DD-022 next runtime-prefix evidence:
`evidence/dynamic-mixed-driver-assessment/dynamic-prefix-next/results.json`
records six failures per edition on the L55 focused binary. An invalid middle
index aliases an adjacent element; a valid dynamic prefix with a partial final
select spills into adjacent bits. Blocking, compound and NBA all fail, while
each prefix, final-index and RHS function executes once. Runtime per-dimension
validation and selected-element clipping must preserve those evaluation counts.

L56 baseline expands DD-022 coverage with an independently calculated 378-case
matrix over signed 128-bit prefix/final indices, including huge values, X/Z,
ascending and negative ranges, both selection directions and three assignment
forms. The L55 binary fails 65 checks per edition. A separate clocked NBA DUT
has 36 cases and fails eight in each ordinary/synthesized run, in both editions.
`l56/root-red-results.json` and `l56/root-synth-red-results.json` record stable
compiler hashes before/after. These are failing baseline evidence, not passing
qualification. Expected bit placement is calculated from each declared range,
without using the compiler's flattened-index expressions.

DD-020 next unresolved-receiver matrix on the L55 binary:
`evidence/unresolved-task-assessment/after-l55/results.json` records
`missing_receiver.run()`, `missing_receiver[0].run()`, `dut.missing.run()` and
`obj.missing.run()` compiling and completing with ignored-call warnings in
both editions. `absent[0].clear()` and `absent.copy()` compile and complete
without a diagnostic. Direct missing methods on resolved scalar/indexed class
objects already reject; valid object and forward hierarchy calls retain their
observed counter effects. Binary hashes are stable across this assessment.
The relevant fallback paths are `PCallTask::elaborate_usr`'s indexed-object
fallback and its unresolved dotted-call branches. A correction must preserve
valid deferred type-parameter resolution and built-in methods while preventing
invalid executable calls from becoming empty blocks. IEEE 1800-2017/2023
13.3 and 23.8.1 govern task declarations/calls and name resolution.

L56 sibling-route baseline: `l56/root-bit-element-red-results.json` records
34 failures per edition across 108 dynamic bit/whole-element assignment cases.
These share the flattened-prefix defect with indexed part-select writes.
The independent `root_dynamic_sensitivity.sv` control passes ordinary and
synthesized execution in both editions before L56. Moving prefix expressions
out of the final base must preserve their contribution to `NetAssign_` input
sensitivity; changing only the outer or middle index must retrigger `always @*`.

L56 first executable WIP uses the existing checked-property-index runtime
helper for packed prefixes, with per-dimension orientation and stride. Original
blocking invalid-prefix/spill reproducers pass, but the independent matrix on
`ae60f63f...` finds four blocking failures per edition: descending `-:4` with
base 1 on [7:0], and equivalent negative ranges. Expected partial-low writes
are suppressed. `collapse_packed_member_indices` constructs its width adjustment
as an unsigned PENumber, so the negative relative offset is treated as a wide
unsigned value. Compound and NBA consumers are not yet connected and remain
red (126 cases each per edition). `l56/root-slice1-results.json` records this
partial implementation evidence; it is not a qualification checkpoint.

L56 blocking correction now passes all 126 indexed-write blocking cases per
edition on installed `649fbf7c...` (stable before/after hashes in
`root-blocking-fixed-results.json`). Compound and NBA remain WIP-red.
Consumer review found constant-function assignment evaluation ignoring dynamic
carrier metadata: `root_const_function.sv` gives valid=0xF instead of
0x0F0000000000, with partial and invalid selections also wrong in both editions.
`root-const-function-slice1-results.json` records the evidence. Required
consumers also include precise output/driver analysis: a constant relative
base must not be interpreted as a constant absolute destination when its
carrier is dynamic. These are L56 integration obligations, not waived gaps.

L56 compound review corrected a whole-signal old-value read to nested carrier
and relative selections. `root_compound_old_value.sv` now passes both editions:
partial high/low and descending selects propagate X through four-state +=,
while two-state old-value conversion produces the expected numeric result.
`root-compound-old-value-results.json` records stable compiler/target/runtime
hashes. This arithmetic probe is necessary because bitwise XOR alone cannot
expose an out-of-carrier old-value read. `root_nba_capture.sv` is the pending
independent delay/capture/partial-update oracle; no result is claimed yet.

L56 pure-packed checkpoint: `root-packed-complete-results.json` records all
378 indexed-write cases passing in each edition, with stable compiler, VVP
target and runtime hashes. `root-nba-capture-results.json` additionally proves
captured dynamic indices/RHS values and disjoint delayed partial updates in
both editions. Whole-feature qualification is still pending.

The separate fixed unpacked-word matrix has 504 cases per edition and remains
red before its consumers are connected (`root-array-before-consumer-results.json`,
installed ivl 3f7515fe...). Packed-prefix function counts are zero in those
paths, although the word, final-index and RHS functions execute. The matrix
checks valid, OOB, X and 128-bit overflow word indices, every packed dimension,
and all three assignment forms against independently calculated storage.
The clocking prefix probe still emits its existing focused unsupported
runtime-clockvar diagnostic; no clocking-support claim is made.

L56 fixed-array consumer checkpoint: `root-array-connected-results.json`
records all 504 cases passing in each edition with stable compiler/target/runtime
hashes. Blocking, compound and NBA now consume the checked carrier while
preserving word validity independently. This supersedes the WIP-red array
checkpoint above. Constant-function evaluation, synthesis, precise analysis,
source-target handling and permanent regression packaging remain pending;
L56 is not yet integrated or fully focused-qualified.

L56 constant evaluator checkpoint: independent dynamic-prefix, static-carrier
and compound logic/bit fixtures pass both editions (six runs in
`l56/root-const-review-results.json`, stable compiler hash). Static high/OOB
writes previously corrupted adjacent bits (`root-const-static-before-results.json`)
and are now clipped. Invalid carrier suppression occurs after final-index
evaluation; exact index conversion and partial-offset arithmetic were reviewed.
The postincrement side-effect fixture cannot yet qualify this behavior because
of the separate constant-expression evaluation defect below.

### DD-025 — Postincrement expressions fail constant-function evaluation

- **Current disposition (2026-10-08):** Fixed on `main` by [commit 5c0f5588](https://github.com/dsellerbrock/iverilog-uvm/commit/5c0f5588ee). `NetEAssignExpr::evaluate_function` and `NetEUnary::evaluate_function` now preserve local mutation and old/new results; paired constant-function regressions cover the behavior. The original failure records below are historical.

- **Discovered during:** L56 compile-time index side-effect testing.
- **Reducer:** `evidence/dynamic-mixed-driver-assessment/l56/const-postinc_expression.sv`
  uses only local scalar integers: `i=0; j=i++; return 10*i+j;` in a constant
  function. Both editions reject its localparam invocation with an inability
  to evaluate the parameter. The corresponding statement `i++; return i;`
  compiles and produces the expected result in both editions.
- **Evidence:** `l56/const-postinc-isolation-results.json`. No packed arrays or
  dynamic carrier metadata are involved in these isolated reducers.
- **Expected:** expression postincrement returns the old value and increments
  the local variable once during constant-function evaluation. Track IEEE
  1800-2017 and 2023 compatibility separately.
- **Status:** OPEN. Increment/decrement uses `NetEUnary`, whose constant
  evaluator currently evaluates an operand as a value without updating its
  local l-value. Assignment expressions use `NetEAssignExpr` and separately
  lack a dedicated constant-function evaluator. Do not count
  `root_const_index_effects.sv` as a passing L56 side-effect check while this
  prerequisite remains unsupported.

### L56 pre-integration review checkpoint — 2026-09-14

L56 remains unintegrated. Fourteen fresh ordinary/synthesized sensitivity,
clocked-write, and constant-function controls pass with stable installed hashes
(`l56/root-freeze-consumer-results.json`). Two expanded checks require correction:

- The checked-index synthesis lowering asserts on 128-bit signed and unsigned
  inputs (`expr_synth.cc:164`). Ten synthesized runs fail across descending,
  ascending, and negative packed ranges; all ten ordinary controls pass.
  See `l56/root-wide-synthesis-results.json` and `root_wide_synth_shape*.sv`.
- Fixed unpacked-array word elaboration treats a constant `[7:4]` tail as one
  bit: `words[1][0][7:4]=4'hf` stores `16'h0080` instead of `16'h00f0` in
  both editions. See `l56/root-array-constant-part-results.json` and
  `root_array_constant_part.sv`.

Both are active L56 review findings, assigned to the existing implementation
agent; neither is deferred as accepted behavior. Broad qualification remains
at the previous batch baseline.

A third L56 review control covers a statically invalid unpacked word rather
than the runtime word expressions in the 504-case matrix. Blocking and NBA
preserve both selector calls and the RHS call, while compound assignment
skips both selector calls (`0/0/1` rather than `1/1/1`) in both editions.
`l56/root-invalid-constant-word-results.json` records all six runs. The
static-word compound read path requires the same one-time selector evaluation
as the other L56 routes; correction is assigned to the same worker.

The final part-select can also select packed elements larger than one bit.
`words[oi][mi+:2]` on `[1:0][2:0][7:0]` passes the valid `mi=0` control but
spills into the adjacent outer element at `oi=0, mi=2`: actual
`000012340000`, expected `000000340000`, in both editions. Evidence:
`l56/root-nonleaf-indexed-part-results.json`. This remains an L56 bounds
review finding; the checked carrier must cover the selected packed dimension,
with offsets and widths scaled by its remaining element width.

### L56 corrected review — 2026-09-14

All four pre-integration findings above are corrected in the installed
candidate. `l56/root-corrected-review-results.json` passes 32/32 paired
ordinary/synthesized runs, including the 108-case nonleaf matrix.
`l56/root-corrected-regression-results.json` passes 18/18 runs, including
the original 378 packed, 108 bit/whole-element, and 504 array-word cases
per edition. Installed compiler/target/runtime hashes remain stable.
Neighbor checks pass 11/11 legacy and 19/19 JSON, including negative
mixed-driver tests and checked-property-index controls. These results
supersede the review failures above for this candidate; the historical
failure logs are retained. DD-025 remains separate and open. Full-suite
qualification still belongs to the previous batch until the next broad gate.

### DD-025 expanded baseline — 2026-09-14 after L56

`evidence/constant-assignment-expression-assessment/baseline-results.json`
records 15 forms in both IEEE modes: pre/post increment and decrement,
plain assignment, arithmetic/bitwise compound assignments, and shifts.
All 30 runtime controls pass exact final-local and expression-result checks;
all 30 constant-function invocations fail elaboration. Compiler/target/runtime
hashes are stable across the sweep. The functions use local scalar integers,
with sequenced statements, avoiding unspecified ordering between competing
side effects in one expression. This confirms two missing evaluator routes:
`NetEUnary::evaluate_function` for increment/decrement and `NetEAssignExpr`
(inherited `NetESFunc::evaluate_function`) for assignment expressions.

Authority checked in local IEEE texts: 2017 11.4.1/11.4.2 and 13.4.3,
2023 11.3/11.4.1/11.4.2 and 13.4.3. The assignment-expression result must
reflect the destination type; prefix/postfix forms must return the proper
new/old value while changing the local variable exactly once. Existing
statement assignment evaluation provides a candidate shared implementation,
but no DD-025 compiler change has been made during L57.

### DD-020 L57 receiver review — 2026-09-14

The first installed L57 candidate rejects ordinary missing receiver calls,
but name-based UVM/TLM and constraint-mode fallbacks still accept invalid
receivers or missing methods. The paired root probe accepts 16/24 invalid
calls: `absent.reset`, `absent[0].get_fields`, missing constraint-mode
receivers/constraints, `atomic.put`, and missing `mirror`/`m.write` methods.
The other eight controls reject. Evidence:
`evidence/unresolved-task-assessment/l57-root/named-escape-baseline.json`,
with stable compiler hash `0a7819c74fdaf4022a6ae7d57d41ecc232f07376a9d0bd9649e4a19a476c0b16`.

These are active L57 review findings, not retained exceptions for familiar
method names. Valid direct/indexed/nested methods with those same names and
named constraint-mode updates have independent exact-effect controls ready
for the corrected build. No UVM source changes or broad-suite claims follow
from this focused receiver review.

L57 second-candidate review passes all 28 named-receiver and exact-effect
controls plus the 20-case original paired receiver corpus. A further typed
receiver probe finds the remaining untyped collection-name fallback:
`obj.member.delete/push_back/push_front/insert` accepts an integer member
without diagnostics (eight paired wrong passes), while `pop_back` rejects.
`l57-root/scalar-member-escape-results.json` records this finding. Removal
of `is_multi_hop_collection_task_stub_candidate_` is assigned to the existing
worker; a valid class-owned queue control checks contents and method effects.

L57 final review supersedes the receiver and scalar-member failures above:
`l57-root/final-results.json` passes 40/40 paired outcomes with stable hashes,
and `specialization-neighbor-results.json` passes 12/12, including concrete
specialized task effects and invalid default specialization rejection.
Permanent focus passes 9 legacy and 10 JSON tests. All name-only receiver
stubs identified in L57 are removed; unspecialized type-parameter deferral
remains separate from concrete call execution. Broad/application qualification
remains pending at the feature-batch gate.

### DD-026 — Two-state assignment expression retains unknown bits at runtime

- **Issue status:** [OPEN #473](https://github.com/dsellerbrock/iverilog-uvm/issues/473).

- **Discovered while working:** L58 independent destination-conversion controls.
- **Reducer:** `evidence/constant-assignment-expression-assessment/root-boundaries/bit_assign_x-runtime.sv`.
  Local `bit[3:0] i,j; j=(i=4'bx101);` should produce `{i,j}=8'h55` after
  conversion to the destination type, but yields unknown bits in both modes.
- **Control:** ordinary statements `i=4'bx101; j=i;` pass exact `55` checks
  at runtime and in constant functions, four paired runs recorded in
  `bit-statement-control-results.json`.
- **Evidence:** `root-boundaries/baseline-results.json`, stable compiler hash.
- **Authority:** IEEE 1800-2017/2023 11.3 assignment-expression destination-type
  conversion and 6.11 two-state integral types.
- **Status:** OPEN. This is a runtime expression-conversion defect. L58's
  constant evaluator must implement the correct two-state semantics, not
  copy this runtime behavior. No runtime source edit has been made during
  the independent assessment.

L58 boundary baseline adds 12 forms across runtime/constant evaluation and
both editions: 22/24 runtime checks pass (the two DD-026 failures above),
4/24 constant checks pass (short-circuit controls whose mutation operand is
not evaluated). Narrow wrap, signed arithmetic/shift, 128-bit values,
four-state increment, real inc/dec, and a chosen ternary branch provide
independent exact-result tests. Evidence is under
`evidence/constant-assignment-expression-assessment/root-boundaries/`.

### DD-027 — Runtime increment of a fixed-array element crashes VVP

- **Issue status:** [OPEN #502](https://github.com/dsellerbrock/iverilog-uvm/issues/502).

- **Discovered while working:** L58 indexed-local constant-function controls.
- **Reducer:** `evidence/constant-assignment-expression-assessment/root-boundaries/array_index_post-runtime.sv`.
  A function initializes `a[0]=5`, `a[1]=7`, `idx=0`, then evaluates
  `j=a[idx++]++`. It must leave `idx=1`, `a[0]=6`, `a[1]=7`, and `j=5`.
- **Evidence:** `array-index-baseline-results.json`: both IEEE modes compile
  successfully and VVP terminates with signal 11. The paired constant form
  is an active L58 candidate review case and currently produces an incorrect
  value; that evaluator failure is not the same runtime crash.
- **Possible source:** `tgt-vvp/eval_vec4.c:draw_unary_inc_dec` distinguishes
  signals/selects/properties but requires review of fixed-array word addressing.
- **Authority:** IEEE 1800-2017/2023 11.4.2 and 7.4.6; the index expression
  must retain its single evaluation and postfix must return the old element.
- **Status:** OPEN. Runtime repair is separate from L58 constant evaluation;
  no runtime change was made during this assessment.

L58 current corrected candidate passes 68/68 independent paired constant
runs in `evidence/constant-assignment-expression-assessment/root-current-results.json`,
with stable compiler/target/runtime hashes. This includes typed defaults,
independent invocations, indexed-local postfix effects, and the previously
blocked L56 packed-carrier side-effect oracle. The reversed increment
candidate failure is corrected. Invalid/X/wide array-index no-store behavior
is still under review, including preservation of evaluator failure instead
of silently substituting a default. DD-026 and DD-027 runtime defects remain
separately open; these constant-function passes do not close either.


DD-026 runtime-only confirmation: a delayed module-level expression
`returned=(stored=input_value)` with `bit [3:0] stored` and runtime
`logic [3:0] input_value=4'bx101` produces stored X / returned 0X in both
editions, instead of 5 / 05. This excludes constant-function folding as a
mask. Evidence: `evidence/runtime-assignment-conversion-assessment/baseline-results.json`.

DD-027 expanded runtime baseline: 32 paired runs cover all four pre/post
increment/decrement forms on int, bit, logic, and real fixed arrays. All 24
integral runs crash with signal 11; the eight real runs fail exact effects,
leave the index unchanged, and report an unresolved-functor placeholder.
The real path directly loads/stores a scalar signal label and omits the
array index. Evidence: `evidence/runtime-array-increment-assessment/baseline-results.json`;
all three installed binary hashes remain stable across the baseline.


### DD-025 L58 final review — 2026-09-14

**Focused fix validated; broad batch qualification pending.** Local scalar
assignment expressions and integral/real local increment/decrement now
preserve mutation and expression results during constant evaluation.
Invalid indexed increments return typed signed defaults and suppress stores;
failed index evaluation remains an error. Final independent outcomes are
80/80, permanent legacy 4/4 and JSON 6/6, existing constant-function neighbors
18/18. See `session_logs/2026-09-14_l58_constant_expression_effects.md`.
Eight independent constant-result runtime checks retain DD-027 startup
warnings from uncalled array-function bodies. No clean runtime claim is
made for those forms. DD-026 and DD-027 remain open.


DD-026 L59 independent operator/width baseline: 96 paired cases cover
plain assignment and eleven compound forms on bit[7:0], signed byte,
signed int, and bit[127:0]. Dynamic mixed X/Z input is checked against
manually derived converted storage and 128-bit expression results; 8 pass
and 88 fail on the frozen L58 target. Evidence:
`evidence/runtime-assignment-conversion-assessment/operator-matrix/baseline-results.json`.

M4C-22 is reopened to PARTIAL while the L58 constant-evaluation and L59
runtime-conversion corrections await the next batch qualification. Its
original destination-conversion claim was too broad for the X/Z cases.


### DD-026 L59 final review — 2026-09-14

**Focused fix validated; broad batch qualification pending.** Runtime
assignment-expression code generation now applies the existing two-state
conversion before copying the result for storage and return. This corrects
plain, arithmetic, bitwise, and shift compounds through one common path.
The independent 96-case matrix now passes with exact clean output, compared
with 8/96 before the fix. Eight paired existing expression/negative/constant
neighbors pass; permanent legacy 2/2 and JSON 4/4 pass. See the L59 session
log. DD-027 runtime array increment remains separate and open.


DD-027 L60 boundary baseline adds 108 semantic cases per edition across
bit[7:0], logic[7:0], and real elements; ascending/nonzero/negative ranges;
preincrement and postdecrement; valid, out-of-range, X/Z, and signed
128-bit indices. It pins selector evaluation once and unchanged neighboring
elements. All 24 runs compile, but 16 integral runs crash with signal 11
and eight real runs abort with signal 6 before completing the cases.
Evidence: `evidence/runtime-array-increment-assessment/boundaries/baseline-results.json`.
These are failing baselines, not completed runtime coverage.


### DD-028 — Property increment expressions return without updating storage

- **Current disposition (2026-10-08):** Fixed on `main` by [commit 5c0f5588](https://github.com/dsellerbrock/iverilog-uvm/commit/5c0f5588ee). Runtime pre/post increment/decrement stores scalar and fixed-array class-property results, with paired focused regressions. The original failure records below are historical; packed-select increment is tracked separately by #498.

- **Discovered during:** L60 adjacent property-path review.
- **Reducers:** `evidence/runtime-property-increment-assessment/scalar.sv`
  and `array.sv`. A scalar `c.a++` returns 5 but fails to update 5 to 6.
  A fixed-array property `c.a[index++]++` evaluates the index once and returns
  the old value, but also omits the element update.
- **Evidence:** `baseline-results.json` records four clean compilations and
  four exact-result failures across IEEE 2017 and 2023, with stable installed
  hashes. Emitted scalar bytecode contains property reads but no increment
  or subsequent property store. The same `prop_word` read-only fallback
  exists in `0c85d32a8:tgt-vvp/eval_vec4.c`, before L60 edits.
- **Expected:** IEEE 1800-2017/2023 11.4.2 requires increment/decrement to
  update the operand and return the appropriate old/new value. A read-only
  substitution does not implement this operation.
- **Status:** OPEN. Queued for L61 after the active fixed-array runtime repair.
  This is distinct from local fixed-array signal storage in DD-027.

DD-028 expanded matrix: int/logic/real, scalar/fixed-array properties, and
all four pre/post ++/-- forms produce 48 failing paired runs: 32 integral
wrong-result exits and 16 real runtime aborts after clean compilation.
Stable-hash evidence: `evidence/runtime-property-increment-assessment/matrix/baseline-results.json`.


### DD-029 — Wide fixed string-array reads alias a valid element

- **Census disposition (2026-10-08):** No active gap. [Issue #503](https://github.com/dsellerbrock/iverilog-uvm/issues/503) was opened then closed after current-main review: `of_LOAD_STRA` rejects `thr->flags[4] != BIT4_0` before address use, and the L62 normalized candidate plus paired wide-index matrix pass. The issue close comment includes the exact current-main evidence. Historical baseline failures below are retained.

- **Discovered during:** L60 shared array load/store review.
- **Reducers:** `evidence/runtime-string-array-index-assessment/read-32.sv`
  and `read-100.sv`. A two-element string array indexed by unsigned 128-bit
  values `1<<32` or `1<<100` returns element zero instead of the empty string.
- **Evidence:** `baseline-results.json`: four clean compilations followed by
  four exact runtime failures, stable hashes, both IEEE editions.
- **Source:** `of_LOAD_STRA` narrows the index to unsigned and recognizes only
  the unknown flag value, not the separate overflow flag value. This is the
  string-read counterpart of the integral/real bounds work in L60.
- **Expected:** IEEE 1800-2017/2023 7.4.6 typed invalid-index read behavior;
  the result is the element type's default, without reading a valid element.
- **Status:** OPEN. Queued after DD-028; the active L60 shared store fix does
  not by itself repair string reads.

L60 review remains open: literal out-of-range array-element increments are
folded as rvalue defaults before unary elaboration, then rejected as constant
operands (six paired int/logic/real compile failures). Dynamic invalid-index
checks pass, but do not establish literal-index support. Readonly const-array
increment validation also required correction before integration.


### DD-030 — Matching-width packed-select increment crashes at runtime

- **Issue status:** [OPEN #498](https://github.com/dsellerbrock/iverilog-uvm/issues/498).

- **Discovered during:** L60 operand-reconstruction boundary review.
- **Reducers:** `evidence/runtime-selected-increment-assessment/matching-width/`.
  `logic result; result=a[index++]++;` and a four-bit result assigned from
  `a[3:0]++` compile cleanly, then abort in `vvp_vector4_t::add` on a width
  assertion. Four paired runs fail with signal 6.
- **Correction to earlier assessment:** the eight earlier widened-result
  probes were rejected as unsupported vector slices. That evidence does not
  prove all packed-select increment forms are diagnosed: matching result
  widths reach the backend path, which uses the whole carrier width.
- **Expected:** IEEE 1800-2017/2023 11.4.2 selected-lvalue update with the
  selected width, correct prefix/postfix result, and untouched carrier bits.
- **Status:** OPEN. Separate from L60 whole unpacked-array elements. Queued
  after the silent-result DD-028 and DD-029 defects.


### DD-027 L60 final review — 2026-09-14

**Focused fix validated; broad batch qualification pending.** Whole fixed
unpacked-array element pre/post ++/-- now captures the index once and uses
array storage. Native bounds and all invalid-index flags are checked before
narrowing addresses. Const updates are rejected, while literal-invalid
operands preserve typed defaults and suppress stores. Final independent
94/94 outcomes plus six constant/runtime literal-X checks pass; ten existing
neighbors and permanent legacy 4/4, JSON 8/8 pass. The original index converter
is retained: the defect was in its consumers' treatment of overflow flags.
See `session_logs/2026-09-14_l60_runtime_array_increment.md` for exact scope,
known compile warnings, and hashes. DD-028 is fixed, DD-029 was later fixed and
closed as [#503](https://github.com/dsellerbrock/iverilog-uvm/issues/503), and
DD-030 remains open as [#498](https://github.com/dsellerbrock/iverilog-uvm/issues/498).


DD-028 L61 receiver-form assessment: `handles[select_receiver()].property`
with once-only receiver selection already works for scalar int properties
(two paired passes), while indexed property elements omit updates (two
failures) and real expression receivers abort during compilation (two
failures). Evidence: `evidence/runtime-property-increment-assessment/capture-indexed/baseline-results.json`.
Direct signal receivers and expression receivers must both be covered;
passing one does not qualify the other. Separate function-return/member
syntax probes stopped at parsing and have no established grammar disposition;
they are not counted as proven runtime defects or L61 requirements.

### DD-028 L61 frozen review — 2026-09-14

Scalar and fixed-array whole-property pre/post increment/decrement now use
property storage for integral and real operands. Receiver capture precedes
index evaluation; invalid slots yield typed defaults and suppress only the
store. Unsupported property destination shapes produce a target error.
Root frozen replay passes 114/114 paired outcomes, including the 48 original
failures, 48 boundary runs, six receiver controls, six alias-notification runs,
and six const restrictions/const-handle controls. Evidence:
`evidence/runtime-property-increment-assessment/root-frozen/results.json`.
Permanent legacy 2/2, JSON 4/4, and 21 neighboring checks pass. This is focused
validation pending batch qualification, not closure of packed-select DD-030.

Historical next step at the time: the expanded signed/unsigned 128-bit string-array read matrix
has eight failing paired runs (40 semantic cases per edition), including
nonzero/negative declared ranges and indices above 32, 63, and 100 bits.
Evidence: `evidence/runtime-string-array-index-assessment/matrix/baseline-results.json`.

### DD-029 L62 first-candidate review — 2026-09-14

The runtime consumer now rejects wide native addresses before narrowing and
recognizes all invalid-index flags. Root replay at runtime SHA `65baa472`
passes 16/20 runs, but four module/automatic paired unsigned-128 cases still
alias element -1 in a declared [-1:1] array when the source index is all ones.
The source index is a large positive unsigned value; normalization appears to
wrap it into a valid coordinate before the runtime bounds check. This remains
under investigation, not qualified or waived. Evidence:
`evidence/runtime-string-array-index-assessment/root-candidate/results.json`.

### DD-029 L62 normalized candidate — 2026-09-14

Independent sibling probes establish that unsigned all-ones normalization also
aliased integral and real array reads. The shared normalizer now zero-extends
unsigned source indices before signed canonical arithmetic, following the
existing packed-offset representation. Root replay passes 36/36 paired runs:
original reproducers, module/automatic range matrices, int/logic/real/string
read controls, and invalid-store neighbor preservation. Stable hashes are in
`evidence/runtime-string-array-index-assessment/root-normalized/results.json`.
Permanent regressions, final freeze, and broad batch qualification remain pending.

L62 frozen review:68/68 root cases, permanentlegacy1/1 JSON2/2, fourneighbors.
Direct two-state element comparison also verifies conversion after generic
vector array load, before any assignment can hide X. Source reviewed; batch
qualification remains pending. Evidence `root-final/results.json`.

### DD-031 — Real/string array-return element stores take scalar return path

Status: OPEN, observed during L53–L62 batch repair review.
Legal automatic functions returning typedef unpacked arrays and assigning
individual result elements in a loop abort compilation for real and string
elements: store_real_to_lval at stmt_assign.c2654 and
show_stmt_assign_sig_string at stmt_assign.c2773 assert dimensions==0.
The scalar return-value special case precedes fixed-array element handling.
Integral and logic variants compile but reproduce the separately diagnosed
stale flag4 on the first returned element. Whole-array pattern results in the
existing sv_uarray_func_return test do not cover these element assignments.
Paired2017/2023 evidence: `evidence/batch-20260914-l53-l62/qualification/return-types/baseline-results.json`.
Do not claim full typed array-return support from whole-pattern tests alone.

DD-031 follow-up: real array-return compound assignments also abort in both
editions. Constant and dynamic selectors reach get_real_from_lval assertions
at stmt_assign.c2564 and c2579 respectively. put_real_to_lval also unconditionally
routes return signals through scalar `%ret/real`, so removing the read asserts
alone would not be sufficient. Reuse the existing array load/store paths for
array return storage, retaining the scalar return path only for scalar values.
Evidence: `evidence/batch-20260914-l53-l62/qualification/return-types/compound-baseline.json`.

DD-031 L66: real/string return-array element reads and writes, including real compound updates, are implemented with focused validation. Scalar return handling is now restricted to scalar signals; array paths preserve typed storage. Root28/28 paired outcomes, permanent8/8 per harness, neighbors4/4. See session_logs/2026-09-14_typed_array_return_elements.md. Broad qualification remains at the next batch checkpoint.

DD-030 update: L67 implements the scalar packed-signal and return-slot subset with focused evidence. Broader selected receivers remain open. Current operational scope is in BLOCKERS L67; measured outcomes are in session_logs/2026-09-14_packed_select_increment.md. Earlier reproductions and oracle corrections remain preserved.


### DD-032 — Fixed multiclock assertions start attempts while disabled

- **Discovered during:** L91 consequent compatibility review, 2026-09-15.
- **State:** REPRODUCED; record-only, not part of the active L91 patch.
- **Evidence:** `evidence/batch-20260914-after-l84/l91-review/fixed-control-baseline.json`
  records eight paired runtime failures and the installed compiler hash.
  Both a fixed Boolean consequent and `good[*1:2]` start another attempt
  after `$assertoff(0)` or `$assertkill(0)` at time 11. The source clock ticks
  at 10 and 30; the destination ticks at 15 and 35. Off should allow only
  the pending first attempt to finish; kill should allow neither.
- **Observed:** Off produces two passes, and kill produces one pass at 35,
  in both editions. These failures predate the unbuilt L91 source patch.
- **Authority:** IEEE 1800-2017/2023 assertion control semantics: Off prevents
  new attempts; Kill also discards pending attempts. Verify the appropriate
  control-task and VPI assertion-control clauses when selecting this fix.
- **Source hypothesis:** The fixed multiclock source pipeline starts with an
  unconditional gate; the L86 ranged pipeline has an enabled-state gate.
  A fix must gate new starts while preserving pending attempts for Off,
  and retain kill/restart, coincident clocks, and action scheduling.

DD032 is resolved for the fixed-pipeline control subset by [L92](session_logs/2026-09-15_fixed_multiclock_assertion_control.md); original failing records remain preserved. Broad qualification is pending.

## L99 adjacent VPI output observations — 2026-09-15

During L99 boundary testing, selected real fixed-array `$sscanf` outputs arrived as nonassignable constants, and selected integral outputs with negative/nonzero declared bounds appeared to use an unnormalized word index. These observations are unqualified, require baseline reproduction and IEEE21.3/VPI address review, and are not part of L99 completion. Evidence: `evidence/batch-20260915-after-l95/next-string-array-method-assessment/L99-IMPLEMENTATION.md`. No new implementation is authorized by this record.

### L101 discovery — const local fixed-string-array initializer

During L101, a constant local fixed-string-array aggregate initializer crashed before the character update. This is a separate unqualified initializer defect, not evidence against selected-character reads or the implemented update path. Evidence: `evidence/batch-20260915-after-l95/l101-l102-first-direct.json` and the L101 assessment reducers. Possible scope: declaration/aggregate initialization under clauses6.16 and10.9; standards and minimal root cause require triage. Status: recorded, not selected. L101 readonly regression uses a module const receiver and pins its write rejection.

### DD-033 — Package-scope fixed unpacked-array `parameter` with a keyed assignment-pattern value (2026-09-16)

- **Issue status:** [OPEN #474](https://github.com/dsellerbrock/iverilog-uvm/issues/474).

Found compiling real, unmodified Caliptra formal-verification source
directly (`src/sha256/formal/properties/fv_sha256_core_pkg.sv`, line 26):
```systemverilog
typedef bit unsigned [31:0] a_unsigned_32_64 [63:0];
parameter a_unsigned_32_64 K = '{0:'h428A2F98, 1:'h71374491, ... 63:'hC67178F2};
```
A package-level (or, by the same code path, module-level) `parameter` of
an explicit fixed-unpacked-array typedef, initialized with a fully-keyed
(every index given) assignment pattern, is rejected with `error: Unable
to evaluate parameter K value: '{...}` (`net_design.cc`, the `switch
(expr->expr_type())` in the parameter-elaboration function). Confirmed
independently: slang accepts the identical construct (minimized to a
4-element `t`/`p` reducer), 0 errors. Two real Caliptra `fv_*_pkg.sv`
files use exactly this pattern for round-constant tables (SHA-256's
64-word K table is one; likely more across the corpus given how common
round-constant tables are in hash/cipher RTL).

**Root cause, level 1 (confirmed, minimal fix known):** the `switch`
dispatches on `expr->expr_type()`, and a fixed-array-of-`bit`/`logic`
constant's elaborated value (`NetEArrayPattern`) reports the ELEMENT's
base type (`IVL_VT_LOGIC`/`IVL_VT_BOOL`), landing in the scalar
LOGIC/BOOL case, which requires `dynamic_cast<NetEConst*>` and rejects
anything else — including a `NetEArrayPattern`. This case already has an
exact precedent one arm away: the `IVL_VT_NO_TYPE` case explicitly
accepts a `NetEArrayPattern` for an **unpacked struct** parameter
(`dynamic_cast<const netstruct_t*>(param_type) && !param_type->packed()
&& dynamic_cast<const NetEArrayPattern*>(expr)`), added for the exact
same reason. The direct mirror for an unpacked **array** parameter
(check `dynamic_cast<const netuarray_t*>(param_type)` instead of
`netstruct_t`, in the LOGIC/BOOL case since that's where an array's
value lands, not NO_TYPE) was implemented, built, and confirmed to
resolve this exact symptom.

**Root cause, level 2 (found, NOT fixed, do not re-attempt the naive
level-1 fix alone):** accepting the value is only half the feature.
`K[0]`-style element selection on the now-accepted array parameter
crashes the compiler: `assert: elab_expr.cc:24133: failed assertion
par_ex` in `PEIdent::elaborate_expr_param_bit_`. That function already
has a documented "defensive fallback" dispatcher —
`if (found_in->is_array_parameter(name)) return
elaborate_expr_param_array_(...);` — specifically for array-typed
parameter element selects, but `is_array_parameter()` (`net_scope.cc`)
returned false for `K` even after the level-1 fix, so control fell
through to the scalar-bit path's `dynamic_cast<NetEConst*>(par)` +
`ivl_assert`, which aborts. `is_array_parameter()` checks the given
scope's *own* `parameters` map (`NetScope::is_array_parameter`); the
reducer that exposed this used `import p::*;` (wildcard package import)
to reach `K`, so the scope resolving the identifier and the scope that
actually registered `K` with `is_array_param=true` (set in
`net_scope.cc:505` from the parameter declaration's `udims`) may not be
the same scope in this path — not traced further. **This is a real
compiler crash, strictly worse than the pre-existing clean error it
would replace — the level-1 fix was reverted rather than landed
half-done.** `net_design.cc` is unmodified; `git diff` confirms clean.

**Closure requirements:** both levels together, not level 1 alone —
landing level 1 without level 2 trades a clean, honest `error:` for an
`assert:` abort on the very next thing real code does with such a
parameter (indexing into a round-constant table). Trace why
`is_array_parameter()` disagrees with `net_scope.cc:505`'s registration
for a package-imported array parameter specifically; confirm the fix
against both a direct-scope and wildcard-imported reference, plus a
positional (non-keyed) assignment pattern and a partially-keyed one with
a default (LRM 10.9's `default:` item), which were not tried this pass.
Status: recorded, not selected.

### DD-034 — Mixing `int` and `logic` assertion-local variable declarations in one property breaks binding (2026-09-16)

- **Issue status:** [OPEN #475](https://github.com/dsellerbrock/iverilog-uvm/issues/475); fix in progress.

Found while building a permanent regression for the L122 comma-
separated multi-identifier local-declaration fix. **Not caused by that
fix** — reproduces with zero commas involved, using only the pre-
existing single-identifier `sva_int_local_declarations` chain grammar
that L122 left untouched:

```systemverilog
property p1;
  int a;
  logic [3:0] z;
  (1'b1, a = 1) ##1 (1'b1, z = a[3:0]) ##1 (z == 4'd1);
endproperty
```
Rejected at elaboration with `error: Unable to bind wire/reg/memory
'a[...]'`. The failure is in fixed-delay local-variable lowering: it
substituted earlier locals into each step's Boolean expression, but not
into that step's later local-assignment RHS. Substitution also needs to
rebuild a packed part-select when replacing a single-name local reference.
The Preponed-sampling copier must also preserve the resulting select on an
expression base; otherwise it reports that value as an unsampled live
operand.
In this example, `a[3:0]` in the assignment to `z` was left unresolved and
then carried into the later comparison. This is a lowering/substitution
defect exposed by the mixed declarations, not evidence of a collision in
the local-declaration type map. Confirmed independently: slang accepts the
identical construct, 0 errors, 0 warnings.

Two same-kind declarations chained together (`int a; int b;`, or
`logic [5:0] x; logic [2:0] y;`) with whole-value assignments work. The
permanent regression keeps those controls alongside the mixed-type case.
IEEE 1800-2017/2023 §§16.10 and 16.12 cover sequence local variables and
their declarations.

Regression: `ivtest/ivltests/sv_assert_property_local_mixed_type.v`, run
under `-g2017` and `-g2023`; the T0/T1 gate result is recorded in the
pull request. L122's own regression test
(`ivtest/ivltests/sv_assert_property_local_multi_ident_decl.v`)
deliberately avoids mixing kinds to stay in scope.

### DD-035 — Sequence match-item assignment LHS selected-local subset (2026-09-16; partially implemented 2026-10-13)

**2026-10-13 update (PR #573):** Direct bit-select and constant part-select
assignments to declared assertion-local variables are now lowered as ordered
full-value updates in fixed-delay sequences. The functional regression checks
that successive part and bit writes preserve untouched bits. Paired 2017/2023
tests cover legacy and NFA lowering. Dynamic selects, variable-delay chains,
implications, unpacked or multidimensional locals remain unsupported. The
typed property-formal syntax in the original Caliptra source is a pre-existing
parser gap; the regression uses a module-scope source value and does not claim
to close that separate gap.


- **Issue status:** [OPEN #476](https://github.com/dsellerbrock/iverilog-uvm/issues/476); the selected-local subset is in PR #573, pending T2 and merge.

Found compiling real, unmodified Caliptra source directly
(`src/ecc/formal/properties/fv_montmultiplier_glue.sv`, line 113):
```systemverilog
property compare_p(prime,idx);
logic [REG_SIZE-1:0] fv_result;
logic [FULL_REG_SIZE-1:0] fv_reg;
    ##0 n_i == prime
    ##0 start_i
    ##DLY_CONCAT
    ##0 (1'b1, fv_reg[RADIX-1:0]    = (ecc_montgomerymultiplier.gen_PE[0].box_i.s_out))
    ##1 (1'b1, fv_reg[2*RADIX-1:RADIX]   = (ecc_montgomerymultiplier.gen_PE[0].box_i.s_out))
    ...
```
A sequence match-item assignment (`(bool, lhs = rhs)`) whose LHS is a
part-select or bit-select of an assertion-local variable — building up
a wide local register RADIX bits at a time across successive match
steps — was rejected with a plain `syntax error`. Reduced to a minimal
7-line case (both part-select `fv_reg[3:0] = ...` and bit-select
`fv_reg[3] = ...` reproduce identically); confirmed independently:
slang (`--std 1800-2017`) accepts the part-select form, 0 errors, 0
warnings. This is ordinary `operator_assignment` LHS syntax (IEEE
1800-2017/2023 A.2.10's `sequence_match_item ::= operator_assignment |
...`, whose `variable_lvalue` production includes `[]`/`[:]` selects
like any other assignment target) — not a special restriction on
local-variable match-items specifically.

**Root cause:** `parse.y`'s `sva_seq_atom` match-item-assignment
alternatives (`'(' expression ',' IDENTIFIER '=' expression ')'` and
the `sva_match_call_list`-suffixed variant) hardcode the LHS as a bare
`IDENTIFIER` token — there is no part-/bit-select alternative at all.
`pform_sva_coerce_local_assignment(loc, name, rhs)` likewise only takes
a plain name, with no notion of a selected sub-range.

**Original scope assessment (2026-09-16, historical):** unlike L118-L123 (each a pure grammar gap whose downstream
semantic layer already accepted a general expression), this genuinely
needs new semantics, not just a wider grammar production. The
assertion-local variable model here is "the whole named local holds
one value, replaced wholesale by each match-item assignment we
process" (`sva_local_decl_insert_`, `sva_local_decl_types_`,
`pform_sva_coerce_local_assignment`) — there is no existing concept of
a partial-width write. A grammar-only fix that accepts `fv_reg[3:0] =
rhs` but silently lowers it as a full-width overwrite of `fv_reg`
(dropping the untouched high bits, or worse, misinterpreting `rhs`'s
width against the full local rather than the selected slice) would
satisfy the parser while producing wrong values — exactly the
"manufactured apparent success" the project's correctness bar forbids.
A correct fix needs a real read-modify-write lowering: read the
local's current value, blend the RHS into the selected bit range
(e.g. via a synthesized concatenation/part-replace expression), and
assign that back as the new whole-local value — before the *next*
match-item's read of the local observes it.

**Real corpus impact:** `fv_montmultiplier_glue.sv`'s `compare_p`
property (both instantiations, `compare_concat_prime_p_a` and
`compare_concat_prime_q_a`) is exactly this shape: it assembles
`fv_reg` (a wide accumulator) RADIX bits at a time across 9 match
steps, one part-select write per step, before comparing the fully
assembled value. This is a real, non-contrived formal-verification
pattern (checking a modular multiplier's output against pieces
gathered from ecc_montgomerymultiplier's internal per-PE outputs), not
a synthetic edge case.

**Current implementation and remaining scope:** PR #573 covers direct
bit/constant-part writes to a declared local with one packed dimension and
constant bounds in fixed-delay sequences. It includes functional paired-
edition tests. Typed property formals, dynamic selects, variable delays,
implications, and unpacked or multidimensional locals remain outside this
change. Keep this issue open until the PR merges.

**Follow-up investigation (2026-09-16; historical, still relevant to the
excluded variable-delay and implication cases):** traced how `lv_name`/`lv_rhs` (the
`sva_seq_step_t` fields a match-item assignment populates, per
`parse_misc.h`) are actually consumed downstream. They are not read in
one place; `lv_rhs` alone appears at 40+ sites across `pform.cc`,
spanning the entire NFA/automaton sequence-lowering engine (roughly
lines 16800-25200): dependency analysis for which locals a step reads
vs. assigns (`sva_expr_reads_lv_`, ~16600-16650), `$past`-style
history substitution for repeated locals (~18200-18280), automaton
leaf/prefix collapsing rules that special-case "no local-variable
assignment present" (dozens of `!st.lv_rhs`/`!cs.lv_rhs` checks used
as simplification preconditions throughout), and the actual register
synthesis (`sva_make_reg_`, a general-purpose carrier-register
allocator used far beyond just local variables) with per-local storage
in a `lv_rhs_reg` vector **indexed by variable name, not by variable
name *plus selected range*** (`pform.cc` ~17200-17280,
~17620-17622, ~17797-17799 — multiple distinct code-generation paths
that each build the write action, not one choke point).

This confirms the closure requirement above is not just "add a grammar
production and a blend expression in
`pform_sva_coerce_local_assignment`" — the read-modify-write blend
would need to be correct at *every* one of these existing whole-
variable-identity call sites, several of which assume `lv_rhs` is the
complete new value for the named local (not a masked partial value),
and some of which actively pattern-match on `lv_rhs`'s absence/
presence as a simplification trigger for the wider automaton (changing
what "having an lv_rhs" means at one of those sites without touching
the others risks silently breaking already-working whole-variable
match-item assignments elsewhere in the automaton, not just leaving
the new part-select case incorrect). This is closer in scope to a
sub-feature of the SVA automaton-lowering engine than a contained
elaboration fix (compare to L124, which touched one function reusing
existing infrastructure) — it needs a dedicated session with time to
read the whole lowering pipeline before writing any code, not
something to attempt opportunistically alongside other fixes. Status
unchanged: recorded, not selected.

### DD-036 — Unpacked-array range select ("array slice") unsupported as a port-connection actual / continuous-assignment source (2026-09-16, HIGH VALUE: single blocker for `caliptra_top`)

**CLOSED 2026-09-16, superseded by [L124](BLOCKERS.md).** The one open
unknown below (word-vs-pin unit conversion) was resolved by reading
`normalize_variable_unpacked()` and `decode_fixed_uarray_slice_select_()`
directly rather than assuming, and the recommended reuse angle
(`decode_fixed_uarray_slice()` wired into
`PEIdent::elaborate_unpacked_net()`) worked as anticipated. Full root
cause, fix, and validation (including a re-run of the same 106-target
census confirming `ICARUS_GAP: 0`, and direct re-compiles of
`ntt_top`/`caliptra_top` at exit 0) are in L124's `BLOCKERS.md` entry.
Left below verbatim as the original finding record.

Found via a differential Icarus/slang static census over Caliptra's
integration filelists (`evidence/caliptra-census-20260916/`, a patched
copy of the pre-existing `run_census.py` driver — see
[[census-driver-paths-rot]] — pointed at this session's own
`iverilog-uvm-concat-select-20260915` build; 106 manifest targets, 60
PASS, 5 `ICARUS_GAP`). **All five `ICARUS_GAP` targets
(`ntt_masked_mult_reduction_tb`, `ntt_top`, `abr_top`, `caliptra_top`,
`caliptra_top_ss_mode`) trace to the exact same two source sites** —
confirmed by diffing each target's full error set: identical four
lines in every one. This is the single thing currently standing
between Icarus and a clean compile of `caliptra_top`, the full-chip
integration target — directly relevant to mission objective 5.

**Symptom**, from real, unmodified Caliptra source
(`submodules/adams-bridge/src/ntt_top/rtl/ntt_masked_special_adder.sv:102-103`
and `submodules/adams-bridge/src/abr_libs/rtl/abr_masked_add_sub_mod_Boolean.sv:134-135`):
```systemverilog
logic [1:0] r0_c0_delayed [WIDTH:0];   // unpacked array, WIDTH+1 elements
...
abr_masked_MUX #(.WIDTH(WIDTH)) r0_MUX_r0 (
    ...
    .r0(r0_c0_delayed[WIDTH-1:0]),     // range-select WIDTH elements out of WIDTH+1
    .r1(r1_c1[WIDTH-1:0]),
    ...
);
```
`r0_c0_delayed[WIDTH-1:0]` is a **range select on an unpacked array**
(selecting a contiguous WIDTH-element sub-array out of the WIDTH+1
declared elements, itself an unpacked array of the same `[1:0]`
element type), used as a port-connection actual. Rejected with:
```
sorry: Array slices are not yet supported for continuous assignment.
     : Port 1 (r0) of sub is connected to r0_c0_delayed[(WIDTH)-('sd1):'sd0]
```
Minimal 10-line reducer confirms the same rejection in isolation, and
confirms independently via slang (`--std 1800-2017`, 0 errors, 0
warnings) that this is legal. This is an honest, already-correct
`sorry:` diagnostic (not a crash, not a silently-wrong compile) — it
meets the project's non-negotiable bar for unsupported behavior. This
is a genuine **feature gap**, not a defect in already-claimed behavior.

**Root cause, located precisely:** `elab_net.cc:1636-1689`
(`PEIdent`'s unpacked-array select-to-net elaboration, reached while
binding a port-connection actual). The existing code at this exact
site already implements a **"slice view" mechanism** for a *sibling*
case — a partial index that supplies fewer indices than the array has
dimensions (e.g. `arr2d[i]` on a `arr2d[N][M]` 2-D unpacked array,
yielding a 1-D `[M]` sub-array): it computes a contiguous pin range in
the source net (`base_const->value().as_long()`, `slice_dims`), builds
a new `NetNet` of `NetNet::IMPLICIT` type with those dimensions, and
pin-aliases it onto the corresponding contiguous range of the source
net's pins via `connect(view->pin(pin), sr.net->pin(base + pin))` —
then returns that view net to stand in for the port connection. When
that path's shape/type checks don't line up (`shape_ok`, `type_ok`),
or when `name_tail.index` isn't the "fewer-dims-than-declared, each a
plain index" shape it expects, control falls through unconditionally
to the `sorry:` at line 1685.

A single-dimension **range select** (`r0_c0_delayed[WIDTH-1:0]` — same
number of dimensions as declared, but a contiguous *sub-range of
elements within one dimension* rather than a reduced-dimension index)
is a different `name_tail.index` shape than what `indices_to_expressions`
above is built to consume here (a partial list of *whole-dimension*
indices, not a `[hi:lo]` range within the last dimension) — this
appears to be why it never even reaches the `shape_ok`/`type_ok`
checks, going straight to the `sorry:`. **Not yet confirmed empirically
how `name_tail.index` represents a `[hi:lo]` range vs. a plain index**
(needs a debug trace or a read of whatever `index_component_t`/similar
structure `path_.back().index` uses) — that is the next concrete step,
not a full implementation guess.

**Much stronger lead found: the exact machinery this needs already
exists and is already used for three sibling contexts, just not this
one.** `index_component_t` (`pform_types.h:140`) already distinguishes
`SEL_BIT` (plain index) from `SEL_PART`/`SEL_IDX_UP`/`SEL_IDX_DO`
(range/indexed-part-select forms) — confirming `[WIDTH-1:0]` parses to
a genuinely different index shape than the partial-index case the
existing `elab_net.cc:1636` branch handles (its call to
`indices_to_expressions()` explicitly hard-errors "Array cannot be
indexed by a range" if it ever receives a non-`SEL_BIT` component,
confirming that function is scoped to plain indices only).

A **complete, general, already-battle-tested decoder for exactly this
shape already exists**: `decode_fixed_uarray_slice()`
(`netmisc.h:179`, implemented `netmisc.cc:1080` via the static
`decode_fixed_uarray_slice_select_()` helper at `netmisc.cc:940`,
which explicitly handles `SEL_PART`/`SEL_IDX_UP`/`SEL_IDX_DO` with
direction checks and clear diagnostics). It is already wired into
**three** other contexts that all accept exactly this kind of
unpacked-array slice today: function/task argument binding
(`elab_expr.cc:15703`, `PECallFunction::elaborate_arguments_`),
concatenation operands (`elab_expr.cc:5117/5252`), and an lvalue path
(`elab_lval.cc:1509/3696`). Its signature takes a `PExpr*` directly —
`decode_fixed_uarray_slice(des, scope, loc, expr, allow_whole, out,
quiet)` — and returns a `fixed_uarray_slice_t{signal, canonical_base,
count, selected_range, element_type, whole}` (`netmisc.h:170`) on
success (return value `1`).

**Recommended implementation angle** (not yet attempted — the one
remaining unknown below must be resolved first): in
`PEIdent::elaborate_unpacked_net()` (`elab_net.cc:1607`), where the
existing partial-index branch currently falls through unconditionally
to the `sorry:` for any non-partial-index shape, add a new branch that
calls `decode_fixed_uarray_slice(des, scope, *this, this, false,
slice)` before giving up; on success, build a `NetNet::IMPLICIT` view
net sized to `slice.count` elements of `slice.element_type` and
pin-alias it onto the source net's pins starting at the slice's base —
the exact same `NetNet` + `connect()` pattern the existing partial-index
branch already uses just below (`elab_net.cc:1668-1679`), just fed by
`decode_fixed_uarray_slice`'s output instead of
`indices_to_expressions`/`normalize_variable_unpacked`'s.

**One concrete unknown to resolve empirically before writing this,
not to assume:** `fixed_uarray_slice_t::canonical_base` and `::count`
are documented as *word/element* units ("Lowest canonical word in the
slice"), while the existing branch's `connect()` loop indexes
`sr.net->pin(base + pin)` in raw *pin* units via `base` from
`normalize_variable_unpacked()`. Whether one canonical word always
equals exactly one `NetNet` pin for an unpacked array (making the unit
conversion an identity) or needs an explicit element-to-pin-width
multiplication has not been checked against the actual `NetNet`/
`netuarray_t` pin layout — get this wrong and the fix would compile
and elaborate cleanly while silently wiring the wrong bits, exactly
the "manufactured apparent success" the project's correctness bar
forbids. Verify by reading `normalize_variable_unpacked()` (used by
the existing sibling branch) and one of the three existing
`decode_fixed_uarray_slice()` call sites' downstream pin/word handling
before writing a single line of the new branch — this is real,
security-sensitive-precision elaboration work and deserves a full,
dedicated session (with real simulation-correctness testing, not just
compile-success testing, for its regression) rather than a rushed
attempt.

**LRM clause for unpacked array range-select syntax needs to be pinned
down precisely before implementing** (this reducer's slang run used
`--std=1800-2017` and slang accepted it, but confirm the exact clause
— likely under 1800's "select" grammar for array types — rather than
assuming a specific subclause number without checking; per
[[discovered-debt-hypothesis-is-not-diagnosis]], verify against the
LRM text directly before coding).

**Census infrastructure note:** the patched driver copy lives at
`evidence/caliptra-census-20260916/` (`run_census.py` +
`fileset_top.sv`, `IVERILOG` repointed at
`iverilog-uvm-concat-select-20260915/local-install/bin/iverilog`, `OUT`
repointed at its own directory) — do not edit the original
`caliptra-rtl-build/static-census-bd31614/run_census.py` in place (see
[[census-driver-paths-rot]]); copy again into a fresh evidence
directory and repoint `IVERILOG`/`OUT` for any future run, since the
worktree path baked in here will itself rot once this worktree is
retired. Full JSON/markdown results:
`evidence/caliptra-census-20260916/caliptra-static-census.{json,md}`.

**Closure requirements:** find the emission site and its assumptions;
design and implement correct lowering (per-element loop or array-slice
net view, whichever the existing net/PWire representation supports
more directly); confirm the LRM clause; verify against the minimal
reducer, both real originally-failing files, and re-run the census
(expect all 5 `ICARUS_GAP` targets to flip to `PASS` from this single
fix, since they share one root cause); add a functional permanent
regression; re-run the full six-gate suite. Status: recorded, not
selected — high priority given it single-handedly unblocks
`caliptra_top`.

### DD-037 — Crash: `ivl` segfaults on `top_{earlgrey,darjeeling}_chip_sim` (both `uvm` and `runtime` lanes) after ~60 unrelated pre-existing errors (2026-09-16)

Found in the same OpenTitan census scan that led to L127 while
double-checking whether L127's fix also happened to cover this crash
— **it does not; this remains open.** (An earlier verification pass
this session incorrectly reported this as fixed by L127 based on
checking only the first few `hard_errors` entries rather than the
full list, which ends in the crash; corrected here.)

`lowrisc:dv:top_earlgrey_chip_sim:0.1` and `top_darjeeling_chip_sim`
(both the `uvm` and `runtime` lanes for each) segfault
(`returncode: 139`, no `Assertion failed` message — a pure SIGSEGV,
not a controlled `ivl_assert`/`assert()` abort like DD-038 below)
after accumulating roughly 60 diagnostic lines covering many already-
independently-known, unrelated feature gaps (SPI agent task-output
queue/dynamic-array formal mismatches, `foreach` array-target
resolution failures, container slice/index chains, streaming-
concatenation width mismatches, `std::randomize() with` constraint
forms, etc. — this full-chip integration target aggregates essentially
every currently-open DV frontier item at once). The crash itself has
**not been reduced to a minimal case** — with ~60 candidate error
sites contributing to whatever state the crash depends on, isolating
the actual trigger requires either bisecting by removing/stubbing
error conditions one at a time from the real file set, or a targeted
read of whatever code path runs immediately after the last printed
diagnostic (`chip_scoreboard.sv:49`'s `foreach` target-resolution
error) to look for an unguarded null-pointer use analogous to L127's,
but this was not attempted this pass.

**Closure requirements:** reduce to a minimal reproducer (start from
the last diagnostic printed before the crash and work backward, or
build a small file exercising just a `foreach` target-resolution
failure inside a `chip_scoreboard`-shaped class hierarchy to see if
that alone crashes); once reduced, apply the same discipline as
L127 (check for an unguarded null dereference following a reported
elaboration failure). Given the scale of unrelated pre-existing debt
in the same file, this is likely NOT one afternoon's work — plan a
dedicated session. Status: recorded, not selected.

**Follow-up (2026-09-16, same pass, inconclusive):** the real file's
crash trace shows the identical `foreach` target-resolution error
(`chip_scoreboard.sv:49`) printed twice — once under the properly-
named class scope (`chip_env_pkg.chip_scoreboard.process_alerts_for_
cov.$ivl_foreach884`) and again immediately before the crash under an
ANONYMOUS auto-generated scope name (`chip_env_pkg._ivl_1.process_
alerts_for_cov.$ivl_foreach884`, `_ivl_%d` being the generic anonymous-
scope-naming counter in `net_scope.cc` — not specific to `foreach` or
any retry mechanism by itself). This double appearance, with the named
class scope replaced by an anonymous one on the second occurrence,
*resembles* the same "same construct re-processed under a different/
wrong scope" shape as L121/L126 (both of which really were exactly
that), so it was tried as a lead: built a 3-level reducer (`cfg.
chip_vif.alerts_cb.alerts`, a class member holding a virtual-interface-
handle-to-clocking-block, `foreach`'d from within a class method) —
it did NOT crash (5 ordinary errors, clean exit). The real construct
has a 4th level the reducer didn't reproduce (`cfg.chip_vif.alerts_if.
alerts_cb.alerts` — an extra virtual-interface-to-sub-interface hop
before the clocking block), so this is inconclusive, not a
disproof — the extra nesting level may be exactly what matters.

**Second follow-up (2026-09-16, same pass): built the exact 4-level
construct faithfully** (an `alerts_if` interface with a clocking
block, nested as a named instance inside a `chip_if` interface,
referenced through a class member's `virtual chip_if` handle — this is
structurally identical to the real
`hw/top_earlgrey/dv/env/chip_if.sv`/`alerts_if.sv` pair, not an
approximation). This reproduces the **exact same error message** as
the real file character-for-character (`Unable to resolve foreach
target cfg.chip_vif.alerts_if.alerts_cb.alerts in scope ...`) — so the
4-level nesting depth is confirmed NOT the missing ingredient; the
`foreach`-resolution failure itself is fully, faithfully reproduced.
**But it still does not crash alone** (1 clean error, ordinary exit).
This rules out "nesting depth" as the missing piece and narrows the
remaining candidate explanation to the one already suspected: the
crash requires the *same* construct's failure to be processed a
*second* time under a *different* (anonymous, auto-generated) scope —
matching the real crash trace's duplicate error appearance
(`chip_env_pkg.chip_scoreboard....` then `chip_env_pkg._ivl_1....`)
— which single-instantiation reducers structurally cannot exhibit.
Reproducing that would need two elaborated instances of a class
containing this method (e.g. two UVM components both extending a
common base that declares it, or some other path that elaborates the
same method body twice under different scope identities) — not
attempted this pass; this is a concrete, specific next step for
whoever picks this up, not a vague "reduce further." Not pursued
further this pass.

**Third follow-up (2026-09-17): "two elaborated instances of a
class" ruled out.** Extended the 4-level reducer to two `chip_if`
instances (`u_chip_if0`, `u_chip_if1`) each driving its own
`scoreboard` instance (`sb0`, `sb1`), both calling the same
`process_alerts_for_cov()` method. Still does not crash, and — the
decisive part — the `foreach`-resolution error is printed only
**once**, not twice as in the real trace. A class method body
elaborates once as shared code regardless of how many object
instances call it; per-instance elaboration was never going to
duplicate the error under a second scope, and it didn't. This closes
the specific next step the previous follow-up recorded.

Status of the two concrete leads this entry has recorded so far:
- 4-level nesting depth: ruled out (second follow-up above).
- Two elaborated instances of the same class: ruled out (this
  follow-up).

Remaining candidate explanation, unchanged and still untested:
whatever construct actually causes the *same* method body to be
re-elaborated a *second* time under a *different*, anonymous
`_ivl_%d` scope (`net_scope.cc`'s generic anonymous-scope counter,
not specific to `foreach` or any known retry mechanism). No third
hypothesis has been formed — the candidates (`fork`, an unnamed
`begin`, virtual/derived-class method dispatch, some other deferred-
elaboration retry path) are unconfirmed guesses, not evidence-backed
leads, and testing them blind risks burning a session without
converging. Confirms the earlier assessment: this needs a dedicated
session with a fresh angle (most likely: read the code path that runs
immediately after `chip_scoreboard.sv:49`'s diagnostic in the real
file, or trace what actually creates an `_ivl_%d`-named scope during
class-method elaboration, rather than guessing at reducers). Not
pursued further this pass.

### DD-038 — Crash: `ivl` aborts (`ivl_assert`/`assert()` failure in `pform_endgenerate`) on `spid_upload_sim` after cascading syntax errors (2026-09-16)

**CLOSED 2026-09-16, superseded by [L128](BLOCKERS.md).** The
grammar-level root cause identified in this entry's own follow-up
(qualifier-prefixed task/function forms only reachable from
`class_item`, forcing bison panic-mode recovery for the unmatched
`K_static` token at module scope) was confirmed as the true trigger by
empirically patching a local scratch copy of the real file (removing
just the word `static`, crash disappeared entirely) before
implementing the fix. Full root cause, fix, bison-conflict validation,
and real-corpus confirmation (the exact originally-crashing
`spid_upload_sim` target no longer crashes) are in L128's
`BLOCKERS.md` entry. Left below verbatim as the original finding
record.

Found in the same scan as DD-037, also incorrectly reported fixed by
L127 in an earlier pass of this session before the full `hard_errors`
list was checked; corrected here — **this remains open.**

`lowrisc:dv:spid_upload_sim:0.1` (`runtime` lane) aborts (SIGABRT, not
SIGSEGV — a genuine, deliberate `assert()` firing, not a wild pointer
dereference) with:
```
Assertion failed: (pform_cur_generate->scheme_type == PGenerate::GS_CASE_ITEM
  || parent_generate->scheme_type != PGenerate::GS_CASE),
  function pform_endgenerate, file pform.cc, line 2907.
```
after 82 accumulated diagnostic lines, the great majority genuine
`syntax error`/`Invalid module item`/`Invalid module instantiation`
cascades starting at `src/lowrisc_dv_spid_upload_sim_0.1/tb/
spid_upload_tb.sv:186`.

**Follow-up investigation (2026-09-16, same pass): the crash reproduces
standalone from this one file alone**, no other dependencies needed
(`iverilog -g2012 -t null hw/ip/spi_device/pre_dv/tb/spid_upload_tb.sv`
aborts directly) — a much smaller starting point than the full
`spid_upload_sim` fusesoc target.

**The first syntax error's root construct identified, and it is
already-known-invalid, not a new gap:** line 186 is
`static task host();` — a `static` qualifier on an ordinary task
declared directly in a module body (not a class out-of-block method
definition). Confirmed independently with slang: it also rejects this,
with a far more specific diagnostic than Icarus's generic `syntax
error` — `error: qualifiers are not allowed on out-of-block method
definitions [-Wqualifiers-on-out-of-block]`. So Icarus's *rejection* is
correct (matches
[[top-syntax-family-is-often-upstream-invalid]]'s pattern exactly: a
`static task` at module scope, named in that very memory as a
construct worth disproving before assuming it's a real gap) — only the
diagnostic's *quality* (opaque "syntax error" vs. a clear, specific
message) and the *downstream crash* are real problems. `sw()` (line
293) is a second, identical `static task` at module scope, and is what
actually contains the `case (cmd) inside ... endcase` block
(lines 312-375) whose nested `begin...end` case-item bodies are what
the crash trace's line numbers (338-354) fall inside — i.e. the crash
happens while processing *ordinary procedural case-item bodies*, not
anything resembling a real `generate case`. This means the parser's
error-recovery after the `static task sw();` syntax error somehow
routes subsequent processing of this *procedural* `case (cmd) inside`
construct through code paths that manipulate `pform_cur_generate`'s
generate-scheme bookkeeping — plausibly a bison error-recovery state
overlap between ordinary `case_item` and `generate_case_item`
productions once the parser is off its normal path, but this was not
traced past `pform_endgenerate()`'s consuming end (`pform.cc` ~line
2881-2913) to find where a generate scheme's `GS_CASE`/`GS_CASE_ITEM`
gets spuriously pushed in the first place.

**Deliberately not attempted as a quick "guard the assert" patch:**
`pform_endgenerate()`'s assertion at line 2906-2907 protects a real
structural invariant (a generate-case item's containing generate must
itself be tagged `GS_CASE`, or the current scheme must itself be
`GS_CASE_ITEM`) that later code
(`parent_generate->generate_schemes.push_back(pform_cur_generate)` and
whatever eventually walks `generate_schemes`) may rely on. Silently
disabling or loosely guarding this assertion when `error_count > 0`
would stop *this* crash but risks pushing a genuinely-inconsistent
scheme object that a *different*, unguarded downstream traversal then
dereferences unsafely — trading one diagnosable crash for a harder-to-
trace one, or worse, a silently-wrong internal structure that doesn't
crash at all. That is exactly the kind of "manufactured non-crash"
this project's correctness bar forbids trading for safety without
first understanding the invariant fully.

**Closure requirements:** trace the actual parser actions between the
`static task sw();` syntax error's recovery and the crash to find
where/why a `GS_CASE`/`GS_CASE_ITEM`-tagged `PGenerate` gets created
for what is really just an ordinary procedural `case (cmd) inside`
block — likely by adding targeted instrumentation (print
`pform_cur_generate`'s scheme_type transitions) while re-running the
minimal single-file reducer, or by reading the bison error-recovery
states around the `case_item`/`generate_case_item` productions in
`parse.y` directly. Once the actual mis-route is understood, the
correct fix is almost certainly to prevent that mis-route from
happening at all (so `pform_endgenerate()`'s invariant is never
violated), not to weaken the invariant check itself. Separately (lower
priority, since the underlying rejection is already correct): give
`static`/`automatic` qualifiers on a non-class-scope task/function
declaration their own specific diagnostic (matching slang's
"qualifiers are not allowed on out-of-block method definitions")
instead of a generic `syntax error`, improving diagnostic quality even
though the construct stays correctly rejected either way. Status:
recorded, not selected — the standalone single-file reducer
(`hw/ip/spi_device/pre_dv/tb/spid_upload_tb.sv`, no dependencies)
significantly lowers the bar for a future session to pick this up.

### DD-039 — `syntax error` on a chained, un-parenthesized leading cycle delay (`##N ##M seq`) (2026-09-16, fixed 2026-09-17)

Found while validating a DD-035 partial fix against the real
originally-failing Caliptra file (`src/ecc/formal/properties/
fv_montmultiplier_glue.sv`) — **confirmed unrelated to that fix and to
any other change this session** (reproduces identically with the
part-select grammar addition reverted via a stashed rebuild-and-retest).

The first reproducer found looked tangled up with parameterized
properties, a bare-identifier cycle delay, and a match-item assignment
whose RHS was a function call — but further bisection (removing one
ingredient at a time and re-testing after each removal) showed every
one of those was a red herring. The true minimal reproducer has none
of them:
```systemverilog
module t;
  bit clk = 0, b = 0;
  always #5 clk = ~clk;
  default clocking cb @(posedge clk); endclocking
  property p1;
    ##3 ##0 b;      // syntax error
  endproperty
  ap: assert property (p1);
endmodule
```
The discriminating pair: `##3 ##0 b;` is a `syntax error`, while
`##3 (##0 b);` (same delays, parens added around the second one)
compiles cleanly. slang (`--std 1800-2017`) accepts `##3 ##0 b;` with
0 errors, so this is not an upstream-invalid-syntax false alarm (see
[[top-syntax-family-is-often-upstream-invalid]]) — it is a genuine
Icarus grammar gap. Reproduces identically in every `sequence_expr`
context tried: a bare `property`/`sequence` body, the consequent of
`|=>`, and an inline `assert property (...)`. Not related to match-item
assignments at all — the very first minimal-enough reducer already
showed a bare boolean (`##3 ##0 b`) fails the same way a match-item
form does.

**Root cause:** in `parse.y`, `sva_seq_expr`'s
leading-cycle-delay productions (e.g. `K_CYCLE_DELAY sva_cycle_delay_value
sva_seq_atom` at parse.y:8369, and its bounded/unbounded-window siblings
at 8372/8390/8404) all take a trailing `sva_seq_atom`, not a trailing
`sva_seq_expr`. A second, unparenthesized `K_CYCLE_DELAY ...` only
reduces to `sva_seq_expr` (there is no `sva_seq_atom` alternative that
starts with `K_CYCLE_DELAY`), so it can't fill that trailing slot —
only the explicit `'(' sva_seq_expr ')'` `sva_seq_atom` alternative can
convert it back, which is why adding parens works around the gap.
IEEE 1800-2017/2023's `sequence_expr ::= cycle_delay_range
sequence_expr | ...` is right-recursive through the *full*
`sequence_expr`, not just through a delay-atom subset, so the grammar
needs a real production, not just this narrow write-up.

Runtime semantics of the already-accepted parenthesized form were
checked before recording this (per [[discovered-debt-hypothesis-is-not-diagnosis]]):
`pform.cc`'s `pform_sva_single_delay` accumulates (`step.delay_lo +=
value`), not overwrites, and a real clocked runtime check confirmed
`a |=> ##3 (##0 b)` and `a |=> ##5 b` fire identically — so the fix
only needs to close the parse gap, not touch delay-accumulation
semantics.

**Fix:** added a new `sva_seq_lead_delay` nonterminal in `parse.y`
(type `<sva_seq>`, alongside `sva_seq_expr`/`sva_seq_atom`) with ten
alternatives: each of the five leading-delay shapes (`K_CYCLE_DELAY
sva_cycle_delay_value`, the bounded window `[e:e]`, the unbounded
window `[e:$]`, and the `[*]`/`[+]` shorthands), each with a trailing
operand that is either a plain `sva_seq_atom` (base case, identical to
the previous behavior) or another `sva_seq_lead_delay` (the new
recursive case — right recursion through the delay productions
specifically, not through the full `sva_seq_expr`, so `K_until`/
`K_implies`/`K_iff`/`K_within`/`sva_seq_comb_concat` are not pulled
into a leading delay's decision point and existing `##N a until
b`-shaped bindings are untouched). `sva_seq_expr`'s five original
leading-delay productions were replaced with a single `sva_seq_expr :
sva_seq_lead_delay` pass-through, so there is exactly one derivation
per input (no new reduce/reduce ambiguity). Each alternative's action
is bodily identical to its former `sva_seq_expr` counterpart, applying
the delay to the trailing operand's first step — `pform_sva_single_delay`
and the inline window logic both accumulate into that step's existing
`delay_lo`/`delay_hi` rather than overwrite, so a chain of N delays
folds down correctly regardless of chain length, confirmed by the
runtime check below.

Verified via `bison --report=state`: shift/reduce and reduce/reduce
conflict totals (562/1122) are byte-for-byte identical across
`origin/main`, the DD-035 part-select commit, and this fix — zero new
conflicts. All prior reducers in this entry (and their variants —
literal delays, parameter-valued delays, chained-with-a-preceding-atom,
match-item and plain-boolean trailing forms, every `sequence_expr`
context) now compile cleanly; where a *different*, pre-existing
unsupported-semantics diagnostic legitimately still applies (e.g. the
parameter-valued bounded cycle-delay composition sorry), it is reached
honestly instead of masked by a syntax error. Runtime-verified with a
real clocked stimulus (not just `-tnull`) that `a |=> ##2 ##3 b`
behaves identically to `a |=> ##5 b` — both pass or fail together
against the same stimulus, proving the composed delay is exactly 5,
not silently wrong in either direction. Permanent regression:
`ivtest/ivltests/sv_sva_chained_leading_cycle_delay.v`. Status: fixed.

### DD-040 — `foreach` selected-prefix into an ASSOCIATIVE array silently iterates the wrong keys; the selector is dropped, not applied (2026-09-17, REOPENED by 2026-09-20 review)

Current review: PR integration is unqualified; see [the September 20 repair record](session_logs/2026-09-20_pr_review_repairs.md). Earlier test results below retain their original revision scope.


Found via a fresh OpenTitan census against the corrected release pin
(Earlgrey-PROD-M6): `hw/dv/sv/dv_utils/dv_report_catcher.sv:19`,
`foreach (m_changed_sev[id][msg])` over `uvm_severity
m_changed_sev[string][string]`, where `id` is already a local
variable — a `foreach` **selected prefix** (IEEE 1800-2017/2023
12.7.3: an index-bracket identifier already declared in an enclosing
scope acts as a fixed selector, not a fresh loop variable). This form
had never been supported for the UNDOTTED double-bracket shape
(`arr[id][msg]`, no `.member` between the brackets) — only the
DOTTED form (`obj.key[0].member[i]`) had a grammar production. Fixing
the grammar gap surfaced a far more serious, PRE-EXISTING bug in the
shared elaboration path.

**Grammar fix:** added a new `parse.y` alternative to the `foreach`
statement's production list, mirroring the already-existing dotted
"selected-prefix" rule (`K_foreach '(' foreach_array_identifier '[' loop_variables ']'
'.' foreach_array_identifier '[' loop_variables ']' ')'`), minus the
`.foreach_array_identifier` in between. A bare identifier in the first
bracket reduces through `loop_variables` for the same 1-token-lookahead
reason the existing dotted rule's own comment documents (bison cannot
distinguish a length-1 `loop_variables` list from an `expression` with
one token of lookahead). Verified via `bison --report=state`: shift/
reduce and reduce/reduce conflict totals unchanged from baseline — zero
new conflicts.

**Correctness gate added (parse.y, before treating the identifier as a
selector):** the LRM's "already declared in an enclosing scope" clause
is the dividing line between a legal selector and an accidental fresh
loop variable, so a new `pform_wire_visible_in_enclosing_scope()`
helper (`pform.cc`/`pform.h`, walks `LexicalScope::wires_find()` up the
full parent chain — the existing `pform_get_wire_in_scope()` only
checks one level, insufficient here since the selector can be declared
in any scope enclosing the `foreach`, not just the innermost one) now
checks this at parse time. An undeclared identifier in that position
(`foreach (m[k1][k2])` with fresh `k1`) is a real, focused elaboration
error, not a silent pass — confirmed independently: slang
(`--std 1800-2017`) also rejects it, as "use of undeclared identifier
'k1'". Before this gate, Icarus silently accepted it with only a soft
"Unable to bind" warning and undefined runtime behavior.

**The deeper bug (why this stays a `sorry:`, not a real fix):** with
the grammar and undeclared-selector gate both correct, a real
clocked/discriminating-population runtime test (NOT just a compile
check — see [[discovered-debt-hypothesis-is-not-diagnosis]] and
[[parse-y-conflict-totals-are-insufficient]], the same "verify past
the first coincidental pass" discipline) showed that `foreach
(m[id][msg])` — for EITHER a literal constant selector (`m["a"][msg]`)
or a variable one, and regardless of the associative array's key
type — never actually applies the selector at all. Root cause:
`PForeach::elaborate`'s `hier_sig` fast path (`elaborate.cc`) finds
`m` as a plain signal via `des->find_signal()` (which matches on the
base name alone, ignoring the appended selector index entirely) and
calls `elaborate_signal_array_()`, which wraps the WHOLE outer array
in a bare `NetESignal` and hands it straight to
`elaborate_assoc_array_()` — the selector index is simply never
consulted. Confirmed the identical bug is reachable through the
ALREADY-MERGED, previously-shipped "fixed expression" rule too
(`parse.y`'s `'[' expression ']' '[' loop_variables ']'` production,
landed earlier this session under a different item) — this is not a
defect introduced by the new grammar rule, it is a latent gap the new
rule made reachable from a second angle, exactly like DD-039's
chained-delay discovery. Failure mode varies by shape (a string-keyed
outer array with a variable selector iterates the OUTER array's own
keys into the inner loop variable; other combinations silently
iterate zero times) — all wrong, none diagnosed, until this fix.

**Real fix:** a `foreach_target_has_selector_prefix_()` check
(`elaborate.cc`, unchanged from the earlier `sorry:` version) still
identifies whenever the **final** path component being iterated
carries a non-empty selector index. What changed is the dispatch: a
selector-prefixed target into an ASSOCIATIVE array (`netqueue_t`,
`assoc_compat()`) now routes to `elaborate_foreach_target_expr_`,
which builds a `PEIdent` from the full (selector-included) target path
and calls `PEIdent::elaborate_expr()` — the exact same
`elab_assoc_index()`-based lookup machinery every other indexed
reference to an associative array already uses. That machinery
re-evaluates the selector at RUNTIME on every loop entry (not baked in
once at elaboration time), so it correctly tracks a selector whose
value changes across outer-loop iterations (see the `successors[s].
m_predecessors[pred]` UVM shape below) or across repeated executions
of the same `foreach` statement. `elaborate_signal_array_()`'s own
associative-array branch is now reached ONLY for a genuinely
unselected target (no index on the final component at all), where
wrapping the whole array signal and handing it to
`elaborate_assoc_array_()` is correct as-is.

**A second, pre-existing bug found and fixed in the same pass (loop
variable type):** the runtime fix above only mattered for a VARIABLE
selector (`m[id][msg]`); a real discriminating-population test showed
a LITERAL/constant selector (`m["a"][msg]`) still iterated zero times
regardless. Root cause was upstream of `elaborate.cc` entirely: the
pre-existing `parse.y` grammar rule for this shape
(`K_foreach '(' foreach_array_identifier '[' expression ']' '['
loop_variables ']' ')'`) always passed `nullptr` as the array name to
`pform_make_foreach_declarations`, forcing the loop variable (`msg`)
to be typed plain `int` regardless of the array's real key type. For a
string-keyed associative array this made the vvp code generator emit
the wrong opcode variant (`%aa/first/sv` instead of `%aa/first/str`,
confirmed by direct `.vvp` bytecode inspection via `iverilog -d
elaborate`), which iterates zero elements with no diagnostic at all —
not even a wrong answer, just silence. Fixed by attaching the fixed
selector's index onto the array name BEFORE calling
`pform_make_foreach_declarations` (instead of after, once the body had
already been parsed) and passing that real, indexed name through, so
`foreach_index_type_t::elaborate_type_raw`'s existing "selected" branch
(already used by the undotted-selector grammar rule above) resolves
the loop variable's true declared type instead of falling back to
`int`.

**A third, pre-existing bug found and fixed in the same pass (plain
static arrays):** the loop-variable-type fix above is lazy — it only
changes what type gets attached to the loop variable, so on its own it
should not have touched anything about how the array TARGET itself is
resolved. But re-running the full verification suite after landing it
caught a real regression anyway: `foreach (A[0][j])` over a plain
`int A[2][3]` (no associative array anywhere) started failing with
"Array A['sd0] needs 2 indices, but got only 1." where it had
previously compiled. The actual cause was independent of the loop-var
fix and had been latent since the FIRST version of this session's
routing change (the one gating `elaborate.cc`'s `hier_sig` fast path
on `foreach_target_has_selector_prefix_`): that gate was written to
force ANY selector-prefixed target through the expression route, not
just associative ones. For a plain static array, the expression
route's `PEIdent::elaborate_expr()` refuses a PARTIAL index into a
signal outright (`elaborate_expr_net_word_` demands a complete,
element-addressing index count) — a restriction that exists precisely
because ordinary expression elaboration has no use for a "half
selected" array. Before this session's DD-040 work, this exact shape
went through `elaborate_signal_array_()` via the same fast path as
every other plain array, which DID compile — but a discriminating
runtime check newly written to confirm the fix showed it had ALWAYS
silently iterated the wrong (already-fixed) dimension, ignoring the
selector's value entirely: the same "drop the selector" bug class as
DD-040's headline bug, just for a signal instead of a queue, and never
previously caught because the only check on record for this shape was
`exit==0`, not actual output. Fixed by narrowing the routing gate to
send only a selector-prefixed target into an ASSOCIATIVE signal
through the expression route; a selector-prefixed target into any
other (plain static or dynamic) signal still uses the fast path, and
`elaborate_signal_array_()` now drops the leading N selected
dimensions (N = the selector's index count — only the COUNT matters
here, never the selector's actual value, since the loop bounds for the
remaining dimensions don't depend on which slice was picked) before
computing loop bounds for the remaining ones. Verified with a real
discriminating-population runtime test: two different selector values
(`A[0][j]` and `A[1][k]`) each correctly iterate the same REMAINING
dimension (size 3), never the fixed one (size 2).

**A near-miss worth recording as its own lesson:** the first version
of this gate checked whether ANY component of the target path had a
non-empty index, not just the final one. That misclassified plain,
already-correct dotted class-property `foreach` targets — where an
EARLIER component's index is an ordinary element select (e.g. the
outer foreach's own loop variable indexing into a different, non-target
array along the way) rather than a selector on the array actually
being iterated — as selector-prefixed, and refused them too. UVM's own
`uvm-core/src/base/uvm_phase.svh:1551` uses exactly this shape
(`foreach (successors[s].m_predecessors[pred])` nested inside `foreach
(successors[s])`, where `s` is the outer loop's own variable and
`m_predecessors` — the real target — carries no selector of its own).
The overly-broad gate took UVM regression from 357/0/0 to 0/357/0 in
one local run, since `uvm_phase.svh` is a mandatory dependency of
every UVM test — caught before landing by re-running the full UVM
gate specifically because the mission's local six-gate bar treats any
regression there as disqualifying, not by code review alone. Narrowed
the check to `array_path.back().index` (the component whose type is
actually iterated) before landing; UVM regression is 357/0/0 with the
corrected gate. See `sv_foreach_nested_assoc_no_selector.v` for the
permanent regression protecting this exact shape.

**Resolution:** all three bugs above (the associative-array selector
never being applied, the literal-selector loop variable being
mistyped, and the plain-static-array selector silently iterating the
wrong dimension) are fixed and verified with real discriminating-
population runtime checks, not just compile checks. This unblocks the
OpenTitan UVM/runtime census jobs that hit `dv_report_catcher.sv`
(`m_changed_sev[id][msg]`) — that construct now elaborates and runs
correctly instead of failing with a `sorry:`. Local six-gate suite
(UVM: 357/0/0, ivtest: 5827 passed/0 failed/0 unexplained, VPI: 108/0,
negative: 148/0, runtime invariants: 15/15) and `bison --report=state`
conflict-state comparison against origin/main (572 shift/reduce, 1122
reduce/reduce, identical per-state signatures, zero new conflicts) all
clean. Status: fixed.

Tests: `ivtest/ivltests/sv_foreach_selected_prefix_assoc.v` (renamed
from `..._fail.v` now that the construct passes — both a variable
selector `m[id][msg]` and a literal one `m["a"][msg]`, real runtime
check with a discriminating population of disjoint inner key sets),
`sv_foreach_undotted_selected_prefix_fail.v` (undeclared selector
identifier, still correctly a real elaboration error, gold-verified),
`sv_foreach_nested_assoc_no_selector.v` (the UVM-shaped false-positive
protection, real clocked runtime check with a discriminating population
— two outer keys with disjoint inner key sets — not just a compile
check), `sv_foreach_selected_prefix_static_array.v` (the plain-static-
array sibling bug found while fixing this, real runtime check with two
different selector values each iterating the correct remaining
dimension).

### DD-041 — Crash: `ivl_assert` failure evaluating a class-method `localparam` initialized from a bare-name outer-scope parameter (2026-09-17, FIXED)

Found via the same fresh OpenTitan census (Earlgrey-PROD-M6) that surfaced
DD-040: `hw/dv/sv/entropy_src_xht_agent/seq_lib/entropy_src_xht_base_device_seq.sv:55`,
`localparam int RngWordsPerByte = 8/RNG_BUS_WIDTH;` inside
`test_cnt_hash()`, a method of class `entropy_src_xht_base_device_seq`.
`RNG_BUS_WIDTH` is a plain `parameter int` declared in
`entropy_src_pkg`, reaching this class body's scope via
`entropy_src_xht_agent_pkg`'s package-level `import entropy_src_pkg::*;`
(the class itself does not import anything — the earlier DD-035/DD-039
session already established class-body `import` is correctly illegal,
see [[class-body-import-is-illegal]]; this is a different construct
entirely, an ordinary bare-name reference to an already-visible outer
parameter). Compiling this file aborts:
```
entropy_src_xht_base_device_seq.sv:55: assert: net_design.cc:1518: failed assertion cur->second.ivl_type
Abort trap: 6
```
Both `uvm` and `runtime` lanes of `lowrisc:dv:entropy_src_sim:0.1` hit
this identically (2 census jobs), since the file is compiled into both.

**Minimal standalone reproducer** (no OpenTitan/UVM dependency,
confirmed with `-tnull`):
```systemverilog
package my_agent_pkg;
  parameter int RNG_BUS_WIDTH = 4;
  class C;
    function void f();
      localparam int X = RNG_BUS_WIDTH;
      $display(X);
    endfunction
  endclass
endpackage
module t;
  import my_agent_pkg::*;
  initial begin C c = new; c.f(); end
endmodule
```

**Bisection so far** (each variant isolates one ingredient; all other
ingredients held at the shape above):
- Replacing `RNG_BUS_WIDTH` with the fully qualified
  `my_base_pkg::RNG_BUS_WIDTH` (a separate package, no wildcard
  import) — **does not crash**, prints the correct value. So a bare
  parameter name specifically, not a qualified one, is implicated.
- Moving the exact same `localparam int X = RNG_BUS_WIDTH;` line into
  an ordinary package-scope **function** (not a class method) — **does
  not crash**, prints the correct value. So this is specific to a
  class *method* body, not bare-name outer-parameter resolution in
  general.
- Removing the division (`8/RNG_BUS_WIDTH` → bare `RNG_BUS_WIDTH`) —
  **still crashes**. The division/arithmetic is not required.
- Removing the wildcard import entirely, declaring `RNG_BUS_WIDTH` and
  the class in the *same* package (no cross-package reference at all,
  the name is visible purely through ordinary lexical scoping) — **still
  crashes**. So this is not specific to wildcard-import resolution
  either; it reproduces for any bare-name reference from a class
  method to a parameter declared in an *enclosing* (not class-local)
  scope.
- A bare-name reference to a parameter declared directly at *module*
  scope (not package scope) from that module's own class does not
  reach this crash — it instead hits a pre-existing, unrelated
  "Unable to bind parameter" error (a separate, not-yet-investigated
  gap; class-in-module bare-name outer-parameter visibility may simply
  work differently or not be supported at all — not pursued this pass).

**Root cause, found via direct instrumentation (temporary `cerr` tracing
at both `NetScope::evaluate_parameter_`'s type-elaboration step and
`evaluate_parameter_logic_`'s pre-assert check, removed before landing
the fix):** the trace showed `X`'s `ivl_type` correctly becoming
non-null immediately after `evaluate_parameter_` elaborates its
declared type — then, after recursively resolving `RNG_BUS_WIDTH`'s
own value, reading back as null again for the SAME map entry (same
address) by the time `evaluate_parameter_logic_`'s assert runs. Nothing
in between explicitly clears it except `NetScope::set_parameter()`
(`net_scope.cc:490-512`), which unconditionally resets `ref.ivl_type = 0`
on every call — meaning `X`'s declaration was being RE-REGISTERED a
second time, mid-flight, while its own first registration's value was
still being evaluated.

That re-registration traces to `elaborate_scope_class()`
(`elab_scope.cc`, the ordinary/non-parameterized class-scope
elaboration entry point): it elaborates a class's typedefs, signals,
events, enums and — critically — every task/function method scope
(which is where a method-local `localparam` gets declared via
`set_parameter`) entirely inline, but **never calls
`use_class->set_scope_ready(true)`** afterward, unlike its two siblings
`elaborate_specialized_class_type()` and
`complete_class_scope_in_place_()`, which both do at the end of
equivalent work. Because the class is left permanently looking
"incomplete", `ensure_visible_class_type()`'s "found the class, but it
is not `scope_ready()`" branch (`elab_scope.cc:800-813`) re-triggers
`elaborate_scope_class()` for the SAME class on every subsequent
lookup — including a self-referential one reached while resolving
`RNG_BUS_WIDTH`'s bare-name reference from inside the class's own
method body. That second call finds the class scope already exists
(the `child_byname` guard at `elab_scope.cc:4351`) and, since
`scope_ready()` is still false, calls `complete_class_scope_in_place_()`
— which reuses the SAME, already-elaborated method scope object
(`class_scope->child(use_name)`) and re-runs
`PFunction::elaborate_scope()` on it, re-declaring `X` via
`set_parameter()` and wiping the `ivl_type` the outer, still-in-progress
`evaluate_parameter_()` call had just set.

**Fix:** add `use_class->set_scope_ready(true)` at the true completion
point of `elaborate_scope_class()`, mirroring what its two sibling
completion paths already do. This is the correct, minimal, root-cause
fix — not a defensive guard on `set_parameter()`'s reset, which would
leave the actual bug (silent, wasteful, and potentially unsafe
re-elaboration of an already-complete class scope on every subsequent
reference to it) in place for whatever else it might also corrupt.

**Verified:** the original minimal reproducer, the qualified-name and
plain-function bisection variants (still correctly unaffected), and a
real discriminating-population runtime check (two classes in two
different packages, each referencing a differently-valued same-named
outer parameter, plus two instances of one class, confirming no
cross-instance or cross-package value confusion) — see
`ivtest/ivltests/sv_class_method_localparam_outer_param.v`. Local
six-gate suite clean (UVM 357/0/0, ivtest 5827/0/0 unexplained, VPI
108/0, negative 148/0, runtime invariants 15/15). The separate,
still-open "class-in-module bare-name outer-parameter visibility" gap
noted in the bisection above (a different, pre-existing "Unable to
bind parameter" diagnostic path) was confirmed NOT to be the same
mechanism and remains unpursued — genuinely out of scope for this fix.
Status: fixed.

### DD-042 — Covergroup cross `select_expression with (...)`: the `with` clause only accepts a bare cross/bins name, not a general `binsof`/`&&`/`||` selector (2026-09-17, REOPENED by 2026-09-20 review)

**Census disposition (2026-10-08):** The positive recursive cross-`with` cases pass in both strict editions on clean current `main` (`af89cfc50be1084cc86c48865f3f6ba78d4512fa`). Two distinct remaining failures are open: [#508](https://github.com/dsellerbrock/iverilog-uvm/issues/508) for `matches` thresholds and [#509](https://github.com/dsellerbrock/iverilog-uvm/issues/509) for wildcard-bin value tuples. Both use self-authored paired reducers with ordinary-bin controls. The full census added [#511](https://github.com/dsellerbrock/iverilog-uvm/issues/511) for the confirmed CrossQueueType explicit-set rejection and [#512](https://github.com/dsellerbrock/iverilog-uvm/issues/512) for a legal 83,521-bin cross dropped at the implementation ceiling with compile exit 0. [#513](https://github.com/dsellerbrock/iverilog-uvm/issues/513) is a validation-only question for merged transition-family cardinality; no mismatch is claimed. Paired reducers and a focused clean-main probe found no present defect in transition-name union, source-denominator carving, or trailing-empty-bin exclusion. Report/VPI formatting is outside IEEE 1800 scope. The local checks are not CI evidence. Earlier results below retain their original revision scope.

The census also links [#507](https://github.com/dsellerbrock/iverilog-uvm/issues/507) for prohibited covergroup `output`/`inout` formals and [#510](https://github.com/dsellerbrock/iverilog-uvm/issues/510) for 2023 real-valued coverpoint bins. These are separate from DD-042's `select_expression with` behavior.

Historical status: the [restored baseline](session_logs/2026-09-20_restored_baseline_qualification.json) passed local qualification; the recursive predicate fix originally had its broader batch gate pending.


Found via the fresh OpenTitan census (Earlgrey-PROD-M6): two independent
real corpus files hit a raw `syntax error` on a cross-body `ignore_bins`
whose selector combines `binsof()` with a `with (...)` predicate:

`hw/ip/csrng/dv/cov/csrng_cov_if.sv:78-80`:
```systemverilog
ignore_bins not_full_and_not_ready = !binsof(cp_hw0_cmd_depth) intersect {2}
                                     with (!hw0_cmd_rdy);
ignore_bins full_and_ready = binsof(cp_hw0_cmd_depth) intersect {2} with (hw0_cmd_rdy);
```

`hw/ip/pwm/dv/env/pwm_env_cov.sv:99-101`:
```systemverilog
ignore_bins undefined_state = (binsof(blink_en_cp) && binsof(htbt_en_cp))
                                with ((blink_en_cp == 0) && (htbt_en_cp == 1));
```

**Confirmed via the LRM, not just slang, before touching the grammar**
(per [[top-syntax-family-is-often-upstream-invalid]]): IEEE 1800-2023
A.2.10 (clause 19.6.1) gives
```
select_expression ::=
    select_condition
  | ! select_condition
  | select_expression && select_expression
  | select_expression || select_expression
  | ( select_expression )
  | select_expression with ( with_covergroup_expression ) [ matches ... ]
  | cross_identifier
  | cross_set_expression [ matches ... ]
select_condition ::= binsof ( bins_expression ) [ intersect { covergroup_range_list } ]
```
— `with (...)` is a suffix on the **general, recursive** `select_expression`
production (so it can follow `!`/`&&`/`||`/parens/`binsof(...)
intersect {...}` just as well as a bare name), not something bound
only to `cross_identifier`. 19.6.1.2's prose confirms the semantics:
"the `with` clause specifies that only those bin tuples in the
**subordinate select_expression**... are selected" — `cross_identifier`
is explicitly called out as just ONE alternative select_expression
that happens to select all tuples, not the only thing `with` can
attach to. Confirmed independently: slang (`--std 1800-2017`) accepts
both real-file forms above, 0 errors.

**Root cause:** `parse.y`'s `cross_body_opt` already has a general,
recursive `cross_bins_expr` nonterminal (`binsof(...)`,
`binsof(...) intersect {...}`, `!`, presumably `&&`/`||` — the
IEEE 1800-2017 M11-3 comment above it says so) used for the plain
`ignore_bins X = cross_bins_expr ;` form. But the THREE `K_with`
productions (`illegal_bins`/`ignore_bins`/`bins` at parse.y ~4724-4742)
hardcode a bare `bins_name` (`IDENTIFIER`) as the operand before
`K_with`, not `cross_bins_expr` — so `with` only works after a plain
name, matching just the `cross_identifier` alternative of
`select_expression`, not the `binsof`/`&&`/`||`/paren alternatives the
LRM also allows before `with`.

**Why this wasn't a small parse.y-only fix:** the pform-level struct
these productions populate (`class_type_t::pform_cross_t::cross_bin_t`,
`pform_types.h`) has a `with_cross` field typed as a bare `perm_string`
(a cross/bins *name*), consumed downstream in `elaborate.cc` including
a same-cross-name identity check (`cb.with_cross == cross.label`) that
only makes sense when the pre-`with` operand really is a name.
Generalizing the grammar to accept a full `cross_bins_expr` before
`with` needed the existing `select` field (the SAME select-tree
`cross_bins_expr` already builds for the non-`with` bins forms — no
new field type required) to carry it, and every `elaborate.cc`
consumer of the with-dispatch updated to handle both shapes.

**Fix:** `parse.y` gained three new `cross_body_opt` alternatives
(`illegal_bins`/`ignore_bins`/`bins`, each mirroring its existing
`bins_name K_with (...)` sibling) accepting
`cross_bins_expr K_with '(' expression ')' ';'` and storing the parsed
select tree into `cb.select` (the SAME field the non-`with` forms
already populate) alongside `cb.with_expr`. `cross_bins_expr` never
reduces from a bare IDENTIFIER alone (every alternative requires
`binsof`/`!`/`&&`/`||`/parens), so this cannot collide with the
existing bare-name `bins_name K_with` form — confirmed via
`bison --report=state`: shift/reduce and reduce/reduce conflict
totals AND the full per-state conflict-shape multiset (count+type per
conflicting state, ignoring state numbers that shift when new states
are inserted — see [[parse-y-conflict-totals-are-insufficient]]) are
byte-for-byte identical to the origin/main baseline (572 shift/reduce,
1122 reduce/reduce, 209 conflicting states, same shapes) — zero new
conflicts.

`elaborate.cc`'s with-dispatch (the loop building each cross's product
tuples) now branches on whether `cb.select` is set: when it is (the
new general-expression form), the tuple is first filtered through the
SAME `eval_sel()` tree-evaluator the non-`with` bins forms already
use; only a tuple that survives that filter is then ALSO checked
against the `with` predicate (still requiring every contributing
coverpoint bin in the tuple to be a singleton integral value, per
19.6.1.2, unchanged from before). When `cb.select` is null (the
existing bare-name form), the original `cb.with_cross == cross.label`
self-reference check runs exactly as before — that path is untouched.

**Verified:** both real OpenTitan shapes (csrng's `!binsof(...)
intersect {...} with (...)` / `binsof(...) intersect {...} with
(...)` complementary pair, and pwm's `(binsof(a) && binsof(b)) with
(...)`) now parse AND elaborate correctly — checked against
`cov.get_inst_coverage()`, not just compile success: a general-select
`with`-filtered construct produces IDENTICAL coverage percentages to
a hand-verified, already-working bare-name `with` construct filtering
the logically equivalent tuple (27.7778% and 34.4444% on a matched
3x2 cross, both forms agreeing exactly), and a real
discriminating-population test explicitly samples the tuples the
`with`-predicate SHOULD exclude and confirms they don't move coverage
that would otherwise depend on them — see
`ivtest/ivltests/sv_covergroup_cross_with_select_expr.v`. Local
six-gate suite clean (UVM 357/0/0, ivtest 5828/0/0 unexplained, VPI
108/0, negative 148/0, runtime invariants 15/15). Status: fixed.

### DD-043 — Constraint `foreach`: no undotted selected-prefix form (`foreach (arr[fixed][loop])`), only plain and dotted-member forms exist (2026-09-17, REOPENED by 2026-09-20 review)

Current review: PR integration is unqualified; see [the September 20 repair record](session_logs/2026-09-20_pr_review_repairs.md). Earlier test results below retain their original revision scope.


Found via the fresh OpenTitan census (Earlgrey-PROD-M6):
`hw/ip/adc_ctrl/dv/env/adc_ctrl_env_cfg.sv:118-122`:
```systemverilog
foreach (filter_cfg[channel]) {
  foreach (filter_cfg[channel][filter]) {
    soft filter_cfg[channel][filter] == FILTER_CFG_DEFAULTS[filter];
  }
}
```
`filter_cfg` is `rand int filter_cfg[NumAdcFilters][ADC_CTRL_NUM_CHANNELS]` — a plain 2D unpacked array, no class/struct member involved anywhere. The inner `foreach (filter_cfg[channel][filter])` hit a raw `syntax error`. This is the exact same construct class as DD-040 (a `foreach` selected-prefix, IEEE 1800-2017/2023 12.7.3: `channel` is already declared by the enclosing `foreach`, so it selects a fixed index rather than introducing a second loop variable) — but here inside a `constraint` block's iterative-constraint form (18.5.7.1) rather than an ordinary statement.

**Confirmed independently: slang (`--std 1800-2017`) accepts this exact reducer, 0 errors** (minimal standalone reproducer, no OpenTitan/UVM dependency):
```systemverilog
class C;
  rand int filter_cfg[3][4];
  int FILTER_CFG_DEFAULTS[4];
  constraint c1 {
    foreach (filter_cfg[channel]) {
      foreach (filter_cfg[channel][filter]) {
        filter_cfg[channel][filter] == FILTER_CFG_DEFAULTS[filter];
      }
    }
  }
endclass
module t;
  initial begin C c = new; void'(c.randomize()); end
endmodule
```

**Root cause:** `parse.y`'s `constraint_expression` nonterminal (IEEE 1800-2017/2023 18.5.7.1) had exactly two `K_foreach` alternatives: a plain single-bracket form and a DOTTED selected-prefix form for a hierarchical/member target (`K_foreach '(' IDENTIFIER '[' loop_variables ']' '.' IDENTIFIER '[' loop_variables ']' ')' constraint_set`). There was no UNDOTTED sibling (`IDENTIFIER '[' loop_variables ']' '[' loop_variables ']'`, no `.member` in between) — exactly the gap DD-040 closed for ordinary statement `foreach`, but never added on the constraint side.

**Why this needed more than a grammar rule:** `PEConstraintForeach`'s hierarchical-target code path (`constraint_foreach_source_type_` in `elaborate.cc`, plus the emission dispatcher's `has_hierarchical_target()` branch) assumed a real `.member_name` always followed the prefix — after consuming `prefix_names().size()` array dimensions, it looked up `member_name` as a class property or struct member and, at emission time, routed through the `qforeach` runtime-queue machinery (which requires a DYNAMIC array/queue element type, not a static one). An undotted selected-prefix has no member to look up and is not a queue: it needs to continue iterating the SAME array's own remaining STATIC dimension(s), unrolled at elaboration time like the plain form already does.

**Fix:** the new grammar alternative reuses the EXISTING hierarchical `PEConstraintForeach` constructor, passing a NIL `member_name` to mark "no member, self-referential continuation into the same array" — no new field or third constructor shape needed. Two `elaborate.cc` sites were updated to recognize this marker:
- `constraint_foreach_source_type_`: when `member_name()` is nil, return the array type as already reduced by consuming `prefix_names().size()` dimensions (the remaining-dimension array type) directly, instead of falling into the member-lookup path that assumes the prefix fully consumed every dimension.
- The constraint-IR emission dispatcher: a nil `member_name()` now skips the `qforeach`/dotted-member branch entirely (that branch's own guard was narrowed to `has_hierarchical_target() && !member_name().nil()`) and falls through to the existing plain-static-array unroll loop, which was extended to offset past `prefix_names().size()` LEADING dimensions — those are already fixed by an outer, already-bound variable (present in the incoming `loop_env`, seeded by the enclosing foreach's own unroll), not re-iterated here — so the trailing loop variables unroll the array's REMAINING dimensions instead of restarting at dimension 0.

Unlike DD-040's plain-statement form, this grammar rule does not check the selector identifier against a parse-time symbol table: a constraint foreach's own loop variables are not declared as real wires (they exist only as `PEConstraintForeach::loop_vars_`, resolved through a runtime `loop_env` at elaboration), so there is no parse-time table to check the selector against — matching the already-shipped DOTTED constraint-foreach rule, which accepts its own `prefix_names` the same way, without a declared-check either. An undeclared/misspelled selector fails to resolve at elaboration instead (the array-index reference inside the constraint body can't find it in `loop_env`), consistent with that existing form's own behavior.

**Verified:** `bison --report=state` conflict totals and per-state conflict-shape multiset unchanged from the origin/main baseline (572 shift/reduce, 1122 reduce/reduce, 209 conflicting states, same shapes) — zero new conflicts. A real discriminating-population runtime check (not just "does it compile"): the constraint value depends on BOTH the prefix-selected outer variable and the freshly-iterated inner variable, producing 12 distinct correctly-constrained values across a 3x4 array — see `ivtest/ivltests/sv_constraint_foreach_undotted_selected_prefix.v`. Confirmed the pre-existing plain single-bracket, comma multi-dimensional, and dotted hierarchical-member forms are all unaffected. Local six-gate suite clean (UVM 357/0/0, ivtest 5828/0/0 unexplained, VPI 108/0, negative 148/0, runtime invariants 15/15). Status: fixed.

### DD-044 — Class-state array indices in constraint foreach bodies can drop an entire constraint (2026-09-20)

This remains record-only: the first reducer contained redundant constraints, so no discriminating unsatisfiable failure is established.


Observed while repairing DD-043 selector validation on local integration
`0133287ec` using the unchanged `104541cde` compiler. A declared integral
class-state selector resolves, but the body `a[selected][j] == 10 + j`
in `foreach (a[selected][j])` is warned as unrepresentable and ignored.
The compiler returns success. This is not valid constraint implementation.

Root observation: `netclass_t::elaborate`, the empty-IR declaration-constraint
fallback in `elaborate.cc`, emits a warning without incrementing the error
count. Applicable semantics: IEEE 1800-2017 18.5.8.1 / 2023 18.5.7.1;
state variables retain their values under constraint solving (18.3).
Evidence: `evidence/review-20260920/sv_constraint_foreach_selector_declared-before.log`.
The first reducer had redundant constraints, so its PASSED banner does not
prove the dropped constraint. A discriminating unsatisfiable reducer and a
root-cause fix remain required. Recorded, not selected; do not count the
warning as successful support.

### 2026-09-21 blocking-index memory synthesis control

Discovered while reviewing IBEX-ROW-ASYNC-RESET-SYNTHESIS. The control assigns
an ordinary integer index with blocking assignments before a clocked memory
NBA, including conditional overwrite and self-increment. Ordinary simulation
passes; current synthesized simulation leaves both output words X on the first
clock in both editions. This predates the rejected generic block-cache proposal.
The source and failed evidence are in
`evidence/review-20260920/next-row-async-reset/blocking-overwrite-boundary.sv`
and `blocking-overwrite-baseline.json`; the2023 behavioral/control pair was also
run. Candidate source includes the original context-fold proposal, but no new
blocking-value cache. Possible scope: synthesis of procedural blocking dataflow
into compact memory address ports, IEEE1800-2017/2023 10.4 and9.2.

Status: REPRODUCED, root cause unconfirmed, record-only during the immutable
row-snapshot fix. Do not claim this control passing or suppress its failure.

### 2026-09-21 direct package-state foreach and GPIO regex boundaries

During CONSTRAINT-INTEGRAL-CAST-IR, the package-global queue foreach fails
translation even without a cast. `PEConstraintForeach` takes the plain property
lookup path and cannot capture the caller container; the cast is not the cause.
Paired failing reducers are under
`evidence/review-20260920/next-joint-distributions/foreach-cast/`.
IEEE 1800-2017 18.5.8.1 / 2023 18.5.7.1; reproduced, separate record-only debt.

The GPIO diagnostic DPI trace identifies twenty direct `uvm_re_match` calls
with `*_shadowed`, rejected by native POSIX regex compilation. Pinned UVM1.2
uses the same direct `regcomp(REG_EXTENDED)` path. Attribution and exact
commands live in `evidence/review-20260920/next-uvm-regex/confirmed-attribution.json`.
This is an application/UVM API compatibility boundary, not an established
compiler defect. Other platform behavior remains unverified. Preserve failure;
do not rewrite patterns or suppress diagnostics to obtain a passing test.

### 2026-09-21 wide inside-container value transport

During CONSTRAINT-INTEGRAL-CAST-IR, review found that the class `q:` and
scope `qv:` emitters replaced element widths above 64 with 32. This loses the
declared type required by inside common-type evaluation and can misrepresent
membership. The candidate now rejects those containers explicitly; it does
not implement their wide value transport. Full-width element capture and
comparison remain UNSUPPORTED, separate from scalar integral casts.
IEEE 1800-2017/2023 11.4.13 and 11.8.2; producer and paired diagnostic evidence:
`evidence/review-20260920/next-joint-distributions/patch-type-inside/`.

### 2026-09-21 scope solver UNKNOWN still accepts random targets

During CONSTRAINT-INTEGRAL-CAST-IR review, `vvp_z3_randomize_scope` in
`vvp/vvp_z3.cc` was found to return success with unconstrained targets when
`Z3_optimize_check` returns UNKNOWN. This branch also exists in committed
`93ce7507a`; it is not introduced by the queue-state patch. The BLOCKERS
exclusion for solver UNKNOWN was too broad: class and scope routes differ.
IEEE 1800-2017/2023 clause 18 constraint satisfaction remains required; a
warning cannot establish a legal solution. Source-confirmed, runtime UNKNOWN
reproducer not yet established, record-only pending separate selection.

#### Scope UNKNOWN reproduction update — 2026-09-21

On semantic revision `8ab943352`, a controlled dynamic-library interposer
makes `Z3_optimize_check` return UNKNOWN. In both `-g2017` and `-g2023`,
`std::randomize(x) with { x == 7; }` returns 1 and writes 1652484268,
violating the hard constraint. The identical non-injected control returns
1 and writes 7. This proves the error-path defect, not a naturally occurring
application solver failure. IEEE 1800-2017/2023 18.12 requires success only
when all randomized variables receive valid values. The caller already
restores RNG state when the solver returns false. Source, interposer and
paired logs: `evidence/review-20260920/scope-unknown-assessment/`.
No compiler repair is integrated yet; PR307's qualified source remains frozen.

### 2026-09-21 OpenTitan power-manager 138-cycle antecedent rejection

Current semantic revision `8ab943352` still rejects unmodified
Earlgrey-PROD-M6 `lowrisc:dv:pwrmgr_sim:0.1` at
`pwrmgr_sec_cm_checker_assert.sv:121`: the escalation-clock checker uses
`(!clk_esc_i && io_clk_en)[*(128 + 8 + 2)] |=> ...`.
A fresh replay of the retained runtime-lane compile command exits 1.
A two-line isolated `a[*138] |=> b` assertion reproduces in both2017/2023;
128 and129 repetitions compile, so the diagnostic's stated128-cycle limit
is not itself the exact repetition boundary. These are compile observations,
not runtime qualification. Applicable sequence semantics are clause16.9.2;
implementation selection must preserve every overlapping assertion attempt,
disable behavior and sampled-value timing, rather than just raise a cap.
Commands, logs and paired boundary results are retained under
`evidence/review-20260920/pwrmgr-current-assessment/`.
This is a next-candidate assessment; no compiler edit integrated.

#### Power-manager follow-on diagnostics — 2026-09-21

With the private long-antecedent repair integrated for testing, the exact
unmodified power-manager compile gets past the original assertion rejection
but exits13 during elaboration. Distinct diagnostics concern a package enum
type cast and enum name expressions in `pwrmgr_env_cov.sv:172-174`, constraint
calls to UVM `get_reset` in `pwrmgr_smoke_vseq.sv:21-25`, and an open covergroup
bin requiring more than65536 counters. These are record-only next candidates,
not selected work or proof of root cause. Current log:
`evidence/review-20260920/next-long-antecedent/pwrmgr-compile.log`.

### 2026-09-21 signed cover-bin ranges crossing zero are misinterpreted

**Census disposition (2026-10-08):** No issue filed. A temporary self-authored
reducer on clean `origin/main` at `af89cfc50be1084cc86c48865f3f6ba78d4512fa`
reported 33.333% after three of nine values and 100% after all nine in both
strict editions. The reducer was not retained as a permanent fixture, so this
result only closes the reported zero-crossing range; broader signed range,
intersection and carving combinations remain outside this disposition. It is
local evidence, not CI.

Historical baseline finding:

A fresh standalone reducer of OpenTitan's `bins close[] = {[-4:4]}`
compiles with a diagnostic claiming more than65536 counters, drops the bin,
and returns3.125% after all nine intended values are sampled. This reproduces
in both2017 and2023; `[-1:1]` also fails while `[-4:-1]` and `[0:4]` controls
pass. Thus the application diagnostic does not establish a genuinely large
range. `netclass_t::elaborate`'s `eval_ranges` lambda at elaborate.cc33145
converts endpoints with `as_ulong64()` and swaps by unsigned comparison,
turning a signed zero-crossing interval into its enormous complement.
Selection must account for effective coverpoint width/sign, empty and unknown
ranges, duplicate bins and carving; merely raising a bin cap is incorrect.
IEEE1800-2017/2023 clause19.5 bin semantics apply (exact conversion clauses
must be verified before implementation). Evidence:
`evidence/review-20260920/next-signed-cover-assessment/`.
This also demonstrates unsafe fallback to automatic bins after dropping an
explicit family; implementation must not manufacture coverage when a bin
cannot be represented. At the time of that record no fix was integrated; the
current-main disposition above supersedes that status for the tested range.

### 2026-09-21 power-manager remaining blockers reduced

The enum cast failure reduces to a class inside package `p` using
`p::wakeup_e'(i)` before that package body closes. External-package control
casts pass. Coordinator `-g2017` and worker `-g2023` runs fail with the same
hierarchical-size-cast diagnostic as the application. Earlier worker `-g2012`
runs are not2017 evidence. See
`evidence/review-20260920/next-package-enum-context/coordinator-real-2017.json`.
Parser self-package resolution is selected in ACTIVE_WORK.

The constraint failure reduces to a pure `box.get_value()` call through a
state object handle. Direct and nested receiver cases fail both editions;
current-object calls, including the UVM default-string/associative-array/64bit
return shape, pass and observe state updates. Impure calls remain rejected.
See `evidence/review-20260920/next-constraint-method-assessment/RESULTS.md`.
Receiver resolution before existing state-call capture is selected separately
with exclusive elaborate.cc ownership. Neither repair is integrated yet.

Generated application input files for the two original failures were compared
byte-for-byte with the pinned clean release sources; provenance is retained in
`evidence/review-20260920/next-batch-20260921/pwrmgr-source-provenance.json`.

### 2026-09-21 VPI force callback object fidelity

Review under VPI-PACKED-ELEMENT-ACCESS confirmed IEEE1800-2017/2023 38.36.1 requires statement objects for compiled force/release callbacks and prohibits variable-bit registrations. New packed variable leaves reject registration; inherited legacy variable-bit acceptance and compiled statement-object fidelity remain record-only debt. VPI-origin forces have no SV statement; selected-object callback behavior is an Icarus policy. See [scoped evidence](session_logs/2026-09-21_packed_vpi_integration.json).

## UVM-STRICT-REGEX-GLOB-FALLBACK — 2026-09-21

- Active work: nine-fix batch qualification; read-only GPIO DPI assessment.
- **Historical observation (S03):** the modern Icarus UVM DPI wrapper retries invalid strict regular expressions as globs even when the caller passes deglob=0. A paired 2017/2023 direct-DPI reducer fails because `uvm_re_comp("*_shadowed", 0)` returns a compiled handle. Explicit deglob=1 and valid strict `.*_shadowed` controls succeed.
- Root: `uvm_dpi/uvm_dpi_iverilog.cc::uvm_ivl_regcomp` fallback overrides the explicit mode passed through the unmodified upstream UVM regex API.
- Authority: pinned `uvm-core/src/dpi/uvm_regex.{svh,cc}` explicitly distinguishes strict matching from requested glob conversion; this is a UVM-library semantic issue, not an IEEE1800 language-feature count. Exact IEEE1800.2 clause mapping remains unassessed.
- Evidence: `evidence/review-20260920/next-uvm-regex-assessment/current-results.json` and `strict_regex.sv`; installed binary, real DPI, no corpus edits.
- Triage: reproduced, suitable for a bounded removal of the fallback with strict-invalid, valid regex, explicit glob, bracket and length/error controls. Keep legacy API strict. GPIO's observed legacy errors need independent classification and are not fixed by loosening regex semantics.

### 2026-09-21 current VPI force-callback debt reproduced

Installed `09316da3d` reproduces the earlier callback debt in both 2017 and 2023 modes. Legal whole-variable force/release registrations fire, but their callback `obj` is type `vpiReg`, rather than the statement handle required by 38.36.1. A `cbForce` registration on the legacy `vpiRegBit` handle also succeeds despite the prohibition. The bit-select `cbRelease` rejection was not separately exercised. `make_force_release` already rejects newer packed variable-bit views but accepts legacy `vpiRegBit` in its shared bit-parent branch. Private sources, commands, tool hashes and logs are under `evidence/review-20260920/next-vpi-force-callback-assessment/`. This is reproduced next-batch debt, not an authorized implementation change or evidence of corrected behavior.

### 2026-09-21 vendor-compatibility investigation reminder

User requested investigation of documented VCS quirks/extensions when they may explain OpenTitan or Caliptra blockers. Candidate questions are strict-versus-glob legacy regex handling in OpenTitan and the scheduling-sensitive Caliptra rejection-sampling boundary. Current evidence establishes neither VCS behavior nor a required workaround. Before attributing such incompatibilities solely to application defects, check the pinned workload’s supported simulator/version/options and use documented behavior or a minimal differential run. Keep vendor compatibility separate from IEEE/UVM semantics; do not silently change standard behavior, modify application sources, or count a vendor-specific accommodation as standards qualification. Implementation remains subject to coordinator selection in ACTIVE_WORK.

### 2026-09-21 SPI Host failures after member-array constraint parser repair

Active blocker: OT-SPI-HOST-STRUCT-MEMBER-ARRAY-CONSTRAINT. Installed uncommitted candidate (tool hash and exact command in `evidence/review-20260920/spi-host-build/application-2/result.json`) with pinned UVM1.2 and unmodified Earlgrey-PROD-M6 passes the original `spi_host_base_vseq.sv:52` parser boundary, then exits139. Earlier diagnostics report queue/dynamic-array output element-type equivalence at `spi_host_driver.sv:156,256` and unsupported compound class-property event combination at line48. The crash follows those diagnostics; its root cause is not established. Do not count this as SPI Host compilation or DV success, or attribute the crash to the constraint patch without a reducer. Triage status: recorded, bounded assessment needed; no additional implementation selected. Raw compiler output is preserved in `evidence/review-20260920/spi-host-build/application-2/compile.log`.

### 2026-09-21 correction: OpenTitan regex failure includes a harness configuration gap

The earlier assertion that pinned OpenTitan/UVM regex configuration matched upstream is superseded by `evidence/review-20260920/opentitan-priority-spi-host-next-regex/ASSESSMENT.md`. Earlgrey-PROD-M6 `hw/dv/tools/dvsim/common_sim_cfg.hjson:65` supplies `+define+UVM_REGEX_NO_DPI`; matrix discovery records the option but the compiler command omits it. Pinned UVM1.2 uses this macro to select its SystemVerilog glob matcher. An unchanged direct `*_shadowed` match/nonmatch test fails through strict DPI regex without the define and passes with the upstream define while ordinary `-uvm` and other DPI remain enabled. Earlier runtime trace results remain valid for their recorded command, but do not prove an upstream-invalid pattern or VCS-specific behavior. Selected harness correction: OT-UVM-REGEX-CONFIG-PROPAGATION in ACTIVE_WORK. Full GPIO/pwrmgr DV outcomes remain unproven until rerun.

### 2026-09-21 GPIO exact distribution blocker after configuration correction

The corrected pinned GPIO run reaches normal UVM completion but remains unqualified. `evidence/review-20260920/opentitan-gpio-dist-next/ASSESSMENT.md` traces the runtime weighted-soft warning to inherited `cip_base_vseq.sv:66-73` reset-delay `:/` ranges with thousands to millions of members. A 301-member `:/1` versus 211-member `:/3` reducer selects only the heavier item in64draws; the sub-cap control samples both. This is probability-semantics debt, not a warning that can be waived or cured by increasing the enumeration cap. Exact range sampling must preserve item-versus-per-value weights, overlap, feasible support, solve ordering and RNG ownership. Read-only assessment continues; no new implementation is selected while PR311 qualification is under repair.

### 2026-09-21 power-manager descendant VIF event context

Read-only assessment after the upstream regex configuration repair identifies false null-at-arm errors in `pwrmgr_scoreboard.reset_coverage_collector` descendant forks. The enclosing automatic receiver is nonnull, but its publication precedes child event-context allocation; the child proxy initializes from a null shared default instead of the matching ancestor activation. Paired 2017/2023 reducers cover detached and retained parents, distinct concurrent roots, rebinding, nested descendants and context reuse; direct task waits pass and genuine-null controls retain their fatal diagnostic. Evidence and clause references: `evidence/review-20260920/opentitan-pwrmgr-null-vif-next/LIFETIME_MATRIX.md`. Candidate repair reuses the existing automatic object slot through an explicit-context accessor; no implementation is selected while PR312 qualification remains active.

### 2026-09-21 power-manager phase timeout after VIF context repair

Discovered during OT-PWRMGR-DESCENDANT-VIF-CONTEXT validation: the clean pinned M6 power-manager smoke compiles and reaches its configured1ms UVM PH_TIMEOUT after the false-null event errors are removed. The exact cause is not yet reduced; process exit0 is not a pass. Preserve the existing timeout and application sources. The large-range distribution fallback remains in the same run and must be resolved before any qualification claim. [Scoped evidence](session_logs/2026-09-21_pwrmgr_descendant_vif_focus.json); record-only, no timeout/scheduler workaround selected.

### 2026-09-21 scope-less VVP event fixture crashes

Active blocker: OT-PWRMGR-LOCAL-VECTOR-CLASS-INDEX-EVENT. Three hand-written VVP files declare an event without an enclosing scope and exit with SIGSEGV before the intended operand diagnostic on candidate1. Replacing their surrounding program with a compiler-generated valid program and mutating only the new wait count produces normal rejection for zero, overflow and missing operands. The scope-less input crash is separate internal-bytecode robustness debt; no IEEE source-language defect or regression attribution is established. Candidate bytecode parser/event construction needs bounded triage before selecting a fix. Preserve private inputs/results under `evidence/review-20260920/opentitan-mixed-wait-design/runtime/` and `derived-malformed/`; no scope-less-input implementation change is authorized here.

### 2026-09-21 pwrmgr seed 3 escalation-clock assertion

During OT-PWRMGR-LOCAL-VECTOR-CLASS-INDEX-EVENT candidate1 validation, unchanged Earlgrey-PROD-M6 `pwrmgr_base_test` / `pwrmgr_smoke_vseq` seed 3 reports `EscClkStopEscTimeout_A` at 26,220,918 ps in `pwrmgr_sec_cm_checker_assert.sv:120`. It terminates with one UVM error despite process exit0; seeds1/2 complete without UVM errors. Evidence: `evidence/review-20260920/opentitan-mixed-wait-implementation/pwrmgr-seed3/{run.json,runtime.log}`. The candidate also has independently reproduced transient-event loss, so this assertion is untriaged: no distinct root cause or vendor dependency is inferred, and no timeout/assertion suppression or application edit is authorized.

### 2026-09-21 whole-function class selector event delivery

Active blocker: OT-PWRMGR-LOCAL-VECTOR-CLASS-INDEX-EVENT. The lifetime-test draft `@(data[cfg.selector()])` reaches `vvp_wide_fun_t::recv_object` and aborts; its generated image contains no new `%wait/obj/expr` instruction. The accepted direct-class-property shape `@(cfg.bits[cfg.selector()])` does emit the observer recipe and passes paired self-disable/lifetime assertions. Preserve `evidence/review-20260920/opentitan-mixed-wait-implementation/runtime/bytecode-fixtures/results-build2-selfkill3/` and corrected `results-build2-selfkill4/`. The whole-function dependency/lowering path requires separate IEEE 1800 §9.4.2 assessment; regression attribution is unestablished, and no unrelated compiler fix is selected.

### 2026-09-21 event-recipe null-method diagnostic consistency

Active blocker: OT-WHOLE-FUNCTION-CLASS-EVENT. Build4 paired 2017/2023 private probes show null receiver methods returning object, real, string, or void can execute inside an integral event recipe without a null-call diagnostic when their bodies do not read instance properties. The new receiver guard currently covers integral-return calls; actual null-property reads are separately diagnosed. Relevant symbols: `of_CALLF_OBJ/REAL/STR/VOID` and their virtual variants versus `event_expr_method_receiver_valid_` in `vvp/vthread.cc`. Evidence: `evidence/review-20260920/whole-function-event-next/final-review-null-return/` (eight edition-paired observations).

IEEE1800-2017/2023 §8.4 declares null access to non-static members illegal, its result indeterminate, and an error optional; §8.10 identifies properties and methods as members. These invalid-source probes establish inconsistent diagnostic coverage, not a valid-source conformance failure or a required semantic result. The raw probe labels saying BUG refer to the proposed diagnostic policy, not a normative requirement. Triage: record-only robustness debt, not selected implementation. Current null-access qualification covers only the tested integral-return and actual property-read cases; no all-return-type diagnostic claim.

### 2026-09-21 SPI selected-event synthesis crash localized

On the current SPI event-list candidate, the earlier compound class-property diagnostic is gone, but pristine M6 compilation still exits139 after the two queue element-equivalence diagnostics. LLDB identifies `NetPins::pin` called by `NetPartSelect`, `NetESelect::synthesize`, and `PEventStatement::elaborate_st` in class-task elaboration. This identifies the failing compiler path, not yet the exact source event or the causal role of earlier diagnostics. Private trace: `evidence/review-20260920/spi-event-list-next/crash-assessment/lldb-backtrace.log`. The compound event itself passes standalone; a selected VIF event is under bounded assessment. No crash fix or application success is claimed.

### 2026-09-21 SPI output queue state-type mismatch

Active blocker: OT-SPI-SELECTED-VIF-EDGE. After the selected-event crash is removed, pristine stable M6 SPI Host calls at spi_host_driver.sv:156/256 copy back an `output bit [7:0]` queue into `rsp.data`, a `logic [7:0]` queue. IEEE 1800-2017/2023 6.22.2 and 7.6 require equivalent array element types, including state representation. Private equivalent/mismatched controls confirm the distinction in 2017/2023 modes. Evidence: `evidence/review-20260920/spi-queue-type-next/ASSESSMENT.md`, including `results/2017-confirmation.json`. Classification: application-language incompatibility, not standards-required compiler acceptance. No application edits or type-rule relaxation selected; any documented commercial compatibility extension would require separately specified conversion semantics and evidence.

### 2026-09-21 continuous until consequent misses a late failure

- Active blocker: OT-SPI-SELECTED-VIF-EDGE (frozen during qualification).
- **Historical observation (S03):** The official OpenTitan checker backport uses `$rose(dead_count == 138) |=> timeout until !rst_lc_ni`. With timeout true on the first consequent sample and false later, installed NFA mode reports no assertion failure; a negative reducer requires one. Both 2017 and 2023 reproduce; legacy mode does not provide an alternate passing implementation.
- Evidence: `evidence/review-20260920/pwrmgr-seed3-revalidation/ASSESSMENT.md`, `upstream_counter_repro.sv`, corrected `focused-results/dropped_timeout-*-nfa1.run.log`. Initial parameter-override harness mistake is preserved separately and not counted.
- Status: Reproduced; bounded root-cause assessment of forbidden-until NFA lowering underway. Parser precedence checked. No implementation change or qualification claim yet; do not weaken the upstream check or treat smoke success as proof of continuation semantics.

### 2026-09-22 legacy `uvm_re_match` regex capacity on TRE

- Active blocker: CI-WIN-UVM-REGEX-NOOUTPUT.
- **Historical observation (S03):** the fork-owned legacy `uvm_re_match` in `uvm_dpi/uvm_dpi_iverilog.cc` compiles with `REG_EXTENDED` only and never reads submatches. On TRE (MSYS2 libsystre), literal patterns longer than 1463 characters fail with REG_ESPACE without `REG_NOSUB`; glibc accepts them. The active fix covers `uvm_re_comp` only.
- Evidence: `evidence/win-regex-tre/` harness technique; the capacity limit was measured against Ubuntu TRE 0.8.0. Not reproduced through the legacy SV API, and no Windows run has been made.
- Triage: recorded only. Check the pinned UVM 1.x legacy source flags before any change; there is no correctness defect on glibc/macOS.

### 2026-09-22 inline randomize on function-call receiver syntax

- Discovery ID: INLINE-RANDOMIZE-CALL-RECEIVER-PARSE. Active blocker: OT-SPI-INLINE-STATE-FUNCTION-CALL.
- Installed build3 rejects `get_target().randomize() with { n == value(); }` at parsing, while the paired plain `get_target().randomize()` class-constraint control compiles and executes. This precedes target-function lowering; do not count it as a failure of the new retained-receiver implementation.
- Evidence: `evidence/review-20260920/spi-external-cfg-constraint-next/build3/target-red/receiver_once-2023.compile.log` and `fixtures.json`; paired 2017 observation agrees. Sources are in `target-fixtures/receiver_once.sv` and `receiver_once_control.sv` under that evidence root.
- Alternative lifetime acceptance probe `coordinator/target_index_once.sv` parses an indexed receiver with an observable index-function call count and reaches the selected unsupported target-function diagnostic.
- Possible standard scope: IEEE 1800-2017/2023 18.7 inline constraints and method-call grammar. Status: reproduced, parser root cause and complete grammar disposition unassessed; record only, no parser change authorized.

### 2026-09-22 scalar constraint state reads discard X/Z

- Active blocker: OT-SPI-INLINE-CALLER-OBJECT-METHOD.
- **Historical observation (S03):** IEEE 1800-2017/2023 18.3 makes X/Z values in constraints illegal. Inline caller-state value slots (`vvp/vthread.cc` `%randomize/with` pop loops near lines 6028 and 6181) keep only BIT4_1 bits, so `lanes == x` with `x = 'x` succeeds with `lanes == 0`. The class-state `r:` read (`vvp/vvp_z3.cc` `parse_state_path`) drops X/Z the same way. Class function captures, guards, container elements and associative reads already reject X/Z.
- Evidence: 2017 private reducer with `logic [2:0] x = 'x` in the caller prints `x-slot ret=1 lanes=0`; installed build of main `1af223c8`.
- Triage: reproduced; a cross-path 18.3 blocker candidate. Rejection must stay guard-aware (inactive implication/if branches), like the existing `qbad:` path.

### 2026-09-22 method call and property read through a null handle execute silently

- Active blocker: OT-SPI-INLINE-CALLER-OBJECT-METHOD.
- **Historical observation (S03):** `r = c.get_size();` with `c == null` runs the body and returns a value built from zero-valued properties (prints 2). An inline constraint reading `cfg.mode` through a null caller handle succeeds with 0. IEEE 1800-2017/2023 8.4 makes accessing nonstatic members through null illegal. The class-constraint capture path guards this explicitly; ordinary expressions and inline caller slots do not.
- Evidence: private reducers `nullcall.sv` and `null_slot.sv` (commands in the active session log).
- Triage: reproduced; general runtime/elaboration 8.4 candidate. The inline caller-method subset excludes null receivers until this is fixed.

### 2026-09-22 OpenTitan matrix runner mis-parses edalize v0.4.0 TOPLEVEL

- Active blocker: OT-SPI-INLINE-CALLER-OBJECT-METHOD (application reproduction).
- **Historical observation (S03):** pinned M6 `python-requirements.txt` edalize v0.4.0 writes `TOPLEVEL := tb` and uses `-s$(TOPLEVEL)` in its recipe. `scripts/opentitan_matrix.py::parse_makefile` passes TOPLEVEL tokens through verbatim, so the compile command gets a bare `tb` source argument ("tb: No such file or directory"). The historical Mac environment evidently used an edalize emitting `-s` inside TOPLEVEL.
- Triage: harness defect, not compiler semantics. The manual equivalent compile (`-s tb`, run from `sim-icarus/`) is used meanwhile. Fix in the runner with a recorded ticket.

### 2026-09-22 dropped DPI export `sorry` still exits successfully

- Active blocker: OT-SPI-INLINE-CALLER-OBJECT-METHOD (negative-gate differential).
- **Historical observation (S03):** `tests/negative/m10_dpi_export_class_handle_argument.sv` and `m10_dpi_export_open_array_argument.sv` print `sorry: ... The export is dropped; calls from C will not link.`, then write stubs to `<output>.dpiexport.c` and exit 0. The negative suite passes in CI only because a non-root user cannot create `/dev/null.dpiexport.c`, which fails the run. As root, both tests report "accepted or no diagnostic". This is identical on a baseline `ivl` built from `1af223c8` `elaborate.cc`, so it is independent of the active patch.
- Triage: reproduced. A dropped export is a semantic loss, so the compile should fail. The negative suite's pass is currently environment-dependent. Selected as DPI-EXPORT-DROPPED-EXIT-STATUS (see BLOCKERS).

### 2026-09-22 vvp extended arguments rejected on glibc (compatibility regression)

- Active blocker: OT-SPI-INLINE-CALLER-OBJECT-METHOD (JSON-gate differential).
- **Historical observation (S03):** `vvp/main.cc` uses `getopt(argc, argv, "d:hil:M:m:nNqsvV")` without a leading `+`, deliberately allowing permutation (commit `b6cb9eea`). glibc then parses Icarus extended arguments that follow the input file, such as `vvp x.vvp -vcd -dumpfile=foo`, as vvp options: `vvp: invalid option -- 'c'`. JSON tests `br_gh710a`, `br_gh710b`, `br_gh710c`, `dumpfile` and `sdf_header` fail on Linux. macOS getopt does not permute, so the Mac JSON gate passed. The vvp binary is unchanged by the active patch.
- Evidence: `python3 ./vvp_reg.py` on this Linux container (cloud session log for this checkpoint); the tests fail identically when rerun alone.
- Triage: reproduced upstream-compatibility regression, Linux only. A fix must keep plusarg/option interleaving for dvsim while stopping option parsing at the input file for extended arguments. Selected as VVP-EXTENDED-ARGS-GLIBC-PERMUTE (see BLOCKERS).

### 2026-09-22 Caliptra power2round testbench passes with zero vectors

- Active work: application replay after VVP-EXTENDED-ARGS-GLIBC-PERMUTE.
- **Historical observation (S03):** unmodified Adams Bridge v2.0.3 `power2round_tb.sv` runs `python power2round.py` via `$system`. If the generator fails (for example without numpy), `$fopen` of the vector files fails and the testbench still prints `TESTCASE PASSED`.
- Triage: application-harness hazard, not a compiler defect. Replays must confirm the generated vector files exist (2048 lines each) before counting a pass; `2026-09-22_application_replay_linux.json` records the invalidated first run.

### 2026-09-22 opentitan_matrix self-test timeout-descendant check fails in container

- **Historical observation (S03):** `scripts/opentitan_matrix.py --self-test` asserts "timed-out command left a descendant running" on this Linux container, both before and after the TOPLEVEL normalization change.
- Triage: environment or harness issue; not yet root-caused.

### 2026-09-22 SPI Host remaining compile errors are IEEE-invalid source

- Active blocker: SOLVE-BEFORE-FIXED-ARRAY (application recompile).
- **Historical observation (S03):** after this batch, pristine Earlgrey-PROD-M6 SPI Host fails only at `spi_host_driver.sv:156` and `:256`. `issue_data(req.data, rsp.data, ...)` binds `logic [7:0] data[$]` actuals to `bit [7:0] ...[$]` formals. IEEE 1800-2017/2023 7.6 requires equivalent element types for unpacked array assignment compatibility, and 6.22.2 makes 2-state and 4-state vectors non-equivalent. Slang 11 independently rejects the same shape ("no implicit conversion ... are you missing a cast?"), and Icarus rejects both argument directions consistently.
- Triage: upstream-invalid source relying on apparent commercial-simulator leniency. The user selected a separately labeled, opt-in compatibility extension; documented VCS behavior is still unverified, so it must not be represented as VCS or IEEE conformance. Pristine sources stay unmodified.
- Flag-design assessment: `elaborate.cc` already has a narrow unconditional whole queue/dynamic-array assignment exception for bit/logic element-state mismatch; task and function output copy-back use separate strict checks. The proposed `-gcommercial-unsafe` must gate the existing exception as well as any new copy-back allowance so the default remains strict. No flag implementation is visible at `origin/main` `1520ccee6`.

### 2026-09-23 same-event process resume order is unstable (compatibility question)

- Active item: CALIPTRA-REJ-BOUNDED-RUNTIME (diagnosis only).
- **Historical observation (S03):** `vthread_add_event_wait` in `vvp/vthread.cc` pushes waiters at the list head, so two `initial forever @(posedge clk)` processes resume B,A on one edge and A,B on the next (`evidence/caliptra-rej-bounded/event_resume_order.sv`). IEEE 1800-2017/2023 4.7 permits any order, so this conforms. Unmodified Caliptra `rej_bounded_tb.sv` depends on declaration order between its scoreboard and zeroize checker and fails 8/10 vectors.
- Triage: application race, recorded in `session_logs/2026-09-23_caliptra_rej_bounded_race.json`. Stable declaration-order resume would be a scheduler-wide compatibility change needing a user decision and documented vendor behavior; not selected.

### 2026-09-23 IEEE 1800-2023 random real variables remain unsupported

- Active blocker: SOLVE-BEFORE-FIXED-ARRAY integration boundary.
- **Historical observation (S03):** IEEE 1800-2023 18.4 permits `rand real` and 18.5.9 permits real values in `solve...before`. The current `-g2023` compiler rejects a `rand real` fixed array using an IEEE 1800-2017 18.4 diagnostic before solve-before lowering. The 2017 rejection is expected; the 2023 rejection is an unsupported edition feature, not proof that real ordering is invalid.
- Evidence: `evidence/review-20260920/pr322-reconcile-build2/real_array_order.sv` and paired compile logs. Status: reproduced, not selected; real-valued solver representation and distributions require a separate scope.

### 2026-09-23 known caller-state values wider than 64 bits are truncated

- Discovery ID: CONSTRAINT-CALLER-STATE-WIDE-KNOWN. Active blocker: CONSTRAINT-STATE-XZ-SCALAR.
- **Historical observation (S03):** `vvp/vthread.cc` stores ordinary caller-state slots as `uint64_t`; `vvp/vvp_z3.cc::substitute_slots` changes a `v:N:65` token to width 32 and uses only the low 64 bits. A `logic [64:0]` caller value of `65'h10000000000000000` makes a `rand bit [64:0]` target solve to zero even though the active constraint equates them. Private reducer `evidence/review-20260920/state-xz-port/known-wide-state.sv` prints `FAILED known wide caller state got=00000000000000000 expected=10000000000000000` with the active worktree compiler.
- Possible standard scope: IEEE 1800-2017/2023 18.3 and integral expression width rules. Status: reproduced, not selected. The active X/Z port scans all bits for unknown state but does not expand the solver's known-value slot representation; select a separate full-width implementation ticket.

### OT-SPI-INLINE-FOREACH-INDEX — inline foreach index remains unresolved

- **Discovered while working:** VIF-NBA-SELECTED-BIT application compile.
- **Observation:** The pinned M6 SPI Host compile succeeds after the NBA fix but still warns four times that `i` could not bind in inline constraint `foreach` bodies. An older checkout-ledger claim that these warnings disappeared is not established by this current compile.
- **File/function:** `elaborate.cc` caller-state capture for indexed `local::` expressions; `elab_expr.cc` emits the compile-progress warning.
- **Possible clause:** IEEE 1800-2017/2023 constraint `foreach` and `local::` rules; exact subclauses need confirmation.
- **Evidence:** `evidence/opentitan-codegen-integration-20260923/spi-compile.log`, clean M6 `a78922f14`, current worktree compiler hashes in the integration record.
- **Reproducer status:** sketched: rand queue `foreach (data[i]) data[i] == local::data[i]` with a same-named caller queue; the existing caller-queue regression covers a different shape.
- **Triage status:** untriaged; do not suppress the warning or substitute a fabricated caller value.

### OT-SPI-QUEUE-POP-DROPPED — queue `pop_front` expression is dropped

- **Discovered while working:** VIF-NBA-SELECTED-BIT application compile.
- **Observation:** The pinned M6 SPI Host compile warns that `item.data.pop_front` is dropped inside `spi_device_cmd_rsp_seq`. The smoke sequence starts that response sequence, although entry into its first-byte branch in a specific run remains unverified.
- **File/function:** `elab_expr.cc` class-property queue method expression path; an existing parenthesized path and VVP queue-pop runtime may be reusable.
- **Possible clause:** IEEE 1800-2017/2023 §7.10 queue methods; parenthesis-free expression syntax still needs direct-edition verification.
- **Evidence:** `evidence/opentitan-codegen-integration-20260923/spi-compile.log` and read-only source trace.
- **Reproducer status:** sketched: push one byte, assign `x = c.q.pop_front`, verify both result and queue size.
- **Triage status:** untriaged; no compiler or OpenTitan source change in the NBA ticket.

### ASSOC-QUEUE-POP-STATEMENT — associative array accepts queue-only methods as statements

- **Discovered while working:** OT-SPI-QUEUE-POP-DROPPED expression-path review.
- **Observation:** In both `-g2017` and `-g2023`, `int a[int]; a.pop_front;` and `a.pop_back();` compile with exit 0 and only a function-as-task warning, including a class-property associative array. IEEE 1800-2017/2023 §7.9 associative-array methods do not include the queue-only methods in §7.10.2.4. A true queue statement control compiles and removes its element.
- **File/function:** `elaborate.cc` statement method lowering accepts `netqueue_t::assoc_compat()` as a queue; PR329's `elab_expr.cc` guard covers expressions only.
- **Evidence:** [Paired source and tool output](session_logs/2026-09-23_assoc_queue_pop_statement_debt.json).
- **Triage status:** selected and locally fixed on `d0560368e` after `elaborate.cc` ownership was released. The [focused record](session_logs/2026-09-23_assoc_queue_statement_methods_focus.json) also covers `push_front`, `push_back`, and `insert` through the same faulty dispatch. PR, CI, and broad qualification remain open.

### SVA-LITERAL-OVERLAP-FAILURE-COUNT — same-tick failures collapse

- **Discovered while working:** CALIPTRA-PARAM-CONSEQUENT-REPEAT.
- **Observation:** In `tests/sva_nfa/parameter_consequent_repeat.sv`, a literal `start |=> !ready[*3] ##1 ready` checker reports only one failure when two distinct live consequences fail their `!ready` step at posedge 65. The independently counted symbolic-bound candidate and per-attempt model report two. IEEE 1800-2017 §16.12.7 evaluates a consequent for each successful antecedent match; the fixed literal NFA's `pform.cc` death branch assigns a one-bit failure flag, collapsing same-tick deaths.
- **Evidence:** Paired `-g2017`/`-g2023` executable comparison on the current SVA candidate printed `FAILED W=3: symbolic 4/3 model 4/3 literal 4/2 at 71` in both editions; source at `pform.cc` around the literal NFA death branch. The candidate patch does not intercept literal repetitions.
- **Triage status:** reproduced separate compiler defect, not part of the symbolic-bound blocker. Do not force the new checker to match this undercount; retain an independent per-attempt regression and select a separate ticket to repair literal/NFA verdict multiplicity.

### SVA-BOUND-EDITION-DIAGNOSTIC — 2023 mode cites 2017

- **Discovered while working:** CALIPTRA-PARAM-CONSEQUENT-REPEAT.
- **Observation:** The shared parameter-bound validity guard rejects W=-1 in both language modes, but its `-g2023` diagnostic still says `IEEE 1800-2017 16.9.2`. The wording is hardcoded in `sva_parameter_add_bound_guard_` in `pform.cc`; the rejection behavior itself is correct.
- **Evidence:** Paired direct compiles of `ivtest/ivltests/sv_assert_parameter_consequent_repeat_negative.v` and its 2023 wrapper, both exit 1 with the same 2017 clause text.
- **Triage status:** diagnostic-only follow-up, not part of the consequent engine's semantic fix.

### OT-AON-EVENT-TRIGGERED-SENSITIVITY — `@(e.triggered)` cannot elaborate

- **Discovered while working:** released OpenTitan application replay at compiler head `f46696830c3056889ab42c72dc7475f89dc36204`.
- **Observation:** the pinned Earlgrey-PROD-M6 AON timer smoke compile exits 3 at three `@(sample_coverage.triggered)` uses in `aon_timer_scoreboard.sv`, reporting `$ivl_event_method$triggered not defined in system table` and skipping the event expression. Procedural `.triggered` reads already have a `%evtest` runtime path.
- **File/function:** `elab_expr.cc` produces the internal event-method expression, while `elaborate.cc::PEventStatement::elaborate_event_` sends it to `expr_synth.cc`, which rejects synthesis of that function. A complete fix likely also needs target/runtime wait handling.
- **Possible clause:** IEEE 1800-2017/2023 §15.5.3. `@(e.triggered)` must detect changes of the persistent time-slot value; treating it as `@(e)` would wake a rearmed waiter on a second trigger in the same slot.
- **Evidence:** `evidence/opentitan-aon-current-20260923/result.json` and its pinned-source compile log. A future focused regression should cover first trigger, same-slot rearm, next-slot trigger, and `->>`.
- **Triage status:** root-caused, not selected; `elaborate.cc` and `vvp/vthread.cc` overlap Claude Code's active ownership.

### OT-SPI-DEVICE-CONSTRAINT-FOREACH-PATH — three-component source rejected

- **Discovered while working:** released OpenTitan application replay at the same compiler head.
- **Observation:** the pinned SPI Device compile reports a syntax error at `spi_device_pass_base_vseq.sv:281`, but standalone `find_index() with ('1)` is valid and works. The preceding inline-constraint `foreach (cfg.spi_host_agent_cfg.cmd_infos[j])` reproduces the parser failure; the grammar has productions only for a plain source and a one-member source.
- **File/function:** `parse.y` has only plain-identifier and one-member `constraint_expression` foreach productions. Representing and resolving the full path likely needs `PEConstraintForeach` in `PExpr.h`/`PExpr.cc` and `elaborate.cc`, so a grammar-only acceptance patch would be incomplete.
- **Possible clauses:** IEEE 1800-2017 §18.5.8.1 and IEEE 1800-2023 §18.5.7.1 allow a `ps_or_hierarchical_array_identifier` as the constraint-foreach source; both editions' §7.12.1 allow the separate locator `with` expression.
- **Evidence:** `evidence/opentitan-spi-device-current-20260923/result.json` and its pinned-source compile log; a temporary standalone reducer was run but must be frozen before implementation.
- **Triage status:** reproduced, not selected; `elaborate.cc` overlaps Claude Code's active ownership. Preserve the locator as a positive control and test empty/nonempty collection boundaries when selected.

### DD-045 — Caliptra v2.1.2 ECC formal file references absent `DSA_NOP`

- **Discovered while working:** CALIPTRA-LATE-DEFAULT-CLOCKING.
- **Observation:** After the clocking fix, the clean pinned ECC formal filelist fails only because `fv_ecc_dsa_sequencer.sv:121` uses `DSA_NOP`. Its wildcard-imported `ecc_dsa_uop_pkg` declares `ECC_NOP = 7'd12` and derives `DSA_KG_S` from it; no `DSA_NOP` declaration exists in the pinned `src` tree. The RTL uses `ECC_NOP`.
- **File/function:** Caliptra `src/ecc/formal/properties/fv_ecc_dsa_sequencer.sv:121` and `src/ecc/rtl/ecc_dsa_uop_pkg.sv:113`.
- **Possible clause:** IEEE 1800-2017/2023 §26.3: a wildcard package import cannot expose a name the package never declares.
- **Evidence:** A disposable one-token source copy (`DSA_NOP` to `ECC_NOP`) compiles the same full ECC filelist under both editions; the pristine file remains a loud bind error. [Clocking candidate record](session_logs/2026-09-23_caliptra_late_default_clocking_focus.json) pins the clean-source failure.
- **Reproducer status:** confirmed on Caliptra v2.1.2 `49370266d12c`; this is an upstream formal-source mismatch, not an Icarus defect.
- **Triage status:** test-specific downstream overlay [recorded and paired compile-tested](session_logs/2026-09-23_caliptra_ecc_nop_overlay.json); the pinned release remains unchanged. Formal proof and DV qualification remain open.

### DD-046 — OpenTitan ADC casted inline constraint loses width at runtime

- **Discovered while working:** OT-ADC-CASTED-UNBASED-INLINE-MACRO-ARG.
- **Observation:** Removing only the macro wrapper lets an inline constraint containing `adc_value_t'('1)` compile, but a reduced run returns `ramp_max=1` instead of the 16-bit all-ones value and reports `%ret/vec4 width mismatch (32 != 1), coercing`.
- **File/function:** `vvp/vthread.cc:28070` warning path; full width-loss mechanism needs a separate trace.
- **Possible clause:** IEEE 1800-2017/2023 §§5.7.1, 6.24.1, and 18.5 constraint expressions.
- **Evidence:** [Pinned ADC macro baseline](session_logs/2026-09-23_opentitan_adc_macro_arg_baseline.json) and its direct nonmacro control; no commercial-simulator result.
- **Reproducer status:** confirmed on the installed candidate compiler, separate from macro preprocessing.
- **Triage status:** Direct unbased-fill cast-width subset fixed at `5afbe4c7f` with [paired local gates](session_logs/2026-09-23_spi_adc_pr339_repair_focus.json); PR339 new-head CI remains pending. The primary loss was constraint IR, not the secondary `vvp/vthread.cc` warning. Wider-than-64-bit and four-state constraint casts remain explicit unsupported boundaries.

### DD-047 — OpenTitan ADC filter-size constraint is ignored

**Issue status:** [OPEN existing issue #419](https://github.com/dsellerbrock/iverilog-uvm/issues/419); nested-array randomization is tracked there, not as a duplicate.


- **Discovered while working:** OT-ADC-CASTED-UNBASED-INLINE-MACRO-ARG.
- **Observation:** The pinned ADC target compiles after the macro fix, but ignores `foreach (filter_cfg[channel]) { filter_cfg[channel].size == ADC_CTRL_NUM_FILTERS; }` at line 94. The direct outer `filter_cfg.size` constraint at line 91 is accepted. A nested `struct[][]` reducer returns successful `randomize()` while inner arrays retain size 1 instead of constrained size 3.
- **File/function:** OpenTitan `hw/ip/adc_ctrl/dv/env/adc_ctrl_env_cfg.sv:91-94`; `elaborate.cc` rejects nested dynamic-array foreach and indexed `.size` lowering; `vvp/vvp_z3.cc` rejects resize of an unallocated nested class-handle collection during a global solve.
- **Possible clause:** IEEE 1800-2017 §18.5.8.1, 2023 §18.5.7.1, and both editions' §18.4 require size-before-iterative solving and resizing constrained rand dynamic arrays.
- **Evidence:** `evidence/opentitan-next-independent-20260923/candidate-adc-compile.json` and `evidence/opentitan-adc-filter-debt-20260923/assessment.md` on installed ivlpp SHA-256 `35d983cb76b8df6ad118cfa7add3bb84d384eae38667ea0ffd9d6f54c42ccd21`.
- **Reproducer status:** pinned-target warning and standalone runtime failure confirmed; one-dimensional size control passes.
- **Triage status:** the pinned ADC gap remains unresolved and its compile is not a DV pass. Current-main selection check (2026-10-09) passes a bounded nested dynamic-array reducer that asserts outer size 2 and inner sizes 3 in both strict editions; that size-only case does not reproduce the full ADC constraint interaction or qualify the pinned target.

### DD-048 — Caliptra masking struct member loses packed bit select

- **Issue status:** [OPEN #499](https://github.com/dsellerbrock/iverilog-uvm/issues/499).

- **Discovered while working:** PR339 compiler CI repair and pinned Caliptra unit-census assessment.
- **Observation:** Clean Adams Bridge v2.0.3 `masking_tb` uses `inputs.x_boolean[j][0]`, where the first index selects an unpacked struct-member element and the second its packed bit. Icarus reports two indices where it expects one; a whole-element control passes.
- **File/function:** `elab_expr.cc` struct-member index elaboration; the read and lvalue paths both need assessment.
- **Possible clauses:** IEEE 1800-2017/2023 §§7.4 and 11.5.
- **Evidence:** [Paired RED and control](../../evidence/caliptra-masking-member-index-triage-20260923/README.md) against the clean pinned release. Other whole-array port errors would remain in that census row.
- **Triage status:** reproduced, not selected for implementation; it overlaps the OpenTitan class-event `elab_expr.cc` candidate.

### DD-049 — OpenTitan SPI class-event `.triggered` is rejected

- **Status:** Fixed in merged [PR #340](https://github.com/dsellerbrock/iverilog-uvm/pull/340) at `909e3f314`. This is separate from the still-open explicit `triggered()` call forms in [issue #439](https://github.com/dsellerbrock/iverilog-uvm/issues/439).

- **Discovered while working:** PR339 repaired-head pinned SPI Device compile.
- **Observation:** Three released `spi_item` event properties are rejected when the scoreboard reads `.triggered`. A per-instance class-event trigger/wait control executes; a paired `.triggered` reducer fails before simulation.
- **File/function:** `elab_expr.cc` class-event member lookup and likely `elaborate.cc`/VVP event query and wait handling.
- **Possible clause:** IEEE 1800-2017/2023 §15.5.3.
- **Evidence:** [Exact reducer and neighboring control](../../evidence/opentitan-spi-class-event-triggered-triage-20260923/README.md); the fresh pinned SPI compile remains at nine strict or five commercial-unsafe errors.
- **Triage status:** selected as `OT-SPI-CLASS-EVENT-TRIGGERED` on merged main `6fd804a39`; all three event errors are one semantic mechanism.

### DD-050 — OpenTitan SPI scope randomization rejects a byte queue

- **Discovered while working:** same pinned SPI Device compile.
- **Observation:** `std::randomize(byte_q) with { byte_q.size() == exp_num_bytes; }` is rejected as nonintegral at `spi_device_tpm_base_vseq.sv:150`. The released macro expands directly to this call; it is not a malformed macro argument.
- **File/function:** `elab_expr.cc::make_std_randomize_with_expr` accepts only scalar or packed-vector targets. A complete queue fix also needs target lowering, VVP resize/copyback, and solver modeling.
- **Possible clauses:** IEEE 1800-2017 §§18.4 and 18.12; verify exact 2023 wording before implementation.
- **Evidence:** [Fresh pinned compile](session_logs/2026-09-23_spi_adc_pr339_repair_focus.json). A focused queue-size/rollback reducer is specified but not yet run.
- **Triage status:** standards-grounded source trace, reducer pending; do not apply an elaboration-only acceptance workaround.

### DD-051 — multi-object class-event list waits on a static event

- **Discovered while working:** OT-SPI-CLASS-EVENT-TRIGGERED.
- **Observation:** `@(a.ev or b.ev)` compiles, but `->b.ev` does not wake the waiter even by the next time step. The emitted VVP waits on `Ewait_0 .event/or E_ev,E_ev` while the trigger uses `%evt/obj 0`; the selected class instances are lost.
- **File/function:** `elaborate.cc` explicit `PEventStatement` event-list lowering; VVP emission reflects a static `NetEvent` rather than per-object `NetEvWaitObj` branches.
- **Possible clause:** IEEE 1800-2017/2023 §§15.5.1–15.5.2 and class-instance event identity.
- **Evidence:** [Paired reducer and emitted-VVP diagnosis](../../evidence/ot-class-event-multi-object-list-triage-20260923/README.md) on PR339 source incorporated into main `6fd804a39`.
- **Reproducer status:** confirmed in both editions; one-object event waits remain a passing control.
- **Triage status:** untriaged; separate from `.triggered` expression reads and waits. Do not expand the active ticket to repair explicit `@(...)` event lists.

### DD-052 — explicit named-event `triggered()` call aborts `ivl`

- **Issue status:** [OPEN existing issue #439](https://github.com/dsellerbrock/iverilog-uvm/issues/439); the recorded crash is candidate-only and still needs a clean current-main check.

- **Discovered while working:** OT-SPI-CLASS-EVENT-TRIGGERED.
- **Observation:** `event ev; ev.triggered()` aborts in `ivl` at an assertion, while the parenthesis-free spelling has a separate working path. A class-event `obj.ev.triggered()` call is also rejected as an unknown method.
- **File/function:** `elab_expr.cc` event-method call elaboration; exact root cause and baseline status are pending.
- **Possible clause:** IEEE 1800-2017/2023 §15.5.3 gives the `function bit triggered()` prototype.
- **Evidence:** [Minimal crash reducer](../../evidence/ot-event-triggered-call-crash-20260923/README.md) on the current class-event candidate; compiler exit 134 on macOS.
- **Reproducer status:** confirmed on the candidate, baseline comparison pending.
- **Triage status:** untriaged; separate from the selected parenthesis-free class-event `.triggered` ticket.

### DD-053 — unresolved interface task call lowers to a no-op

- **Discovered while working:** CALIPTRA-UNSAFE-VIRTUAL-DISPATCH-REACHABILITY
- **Observation:** If interface method lookup reaches its unresolved fallback, elaboration warns that the task enable is ignored and returns an empty `NetBlock`. A valid call reaching this path would lose requested behavior; applicability to a legal source case is unproved.
- **File/function:** `elaborate.cc:16976`, `PCallTask::elaborate_method_`.
- **Possible clause:** N/A until the fallback's accepted source cases are classified.
- **Evidence:** Read-only source review during the no-candidate virtual-interface call regression.
- **Reproducer status:** none
- **Triage status:** untriaged

### DD-054 — OTP backdoor memory path is padded before VPI lookup

- **Discovered while working:** OT-OTP-VIF-FIXED-INPUT
- **Observation:** The first released OTP smoke reaches `mem_bkdr_util.sv:76` at time zero and fails `uvm_hdl_check_path` for an existing memory because its generated path string begins with 18 spaces. VVP exits zero after a UVM fatal and end-of-simulation assertions; there is no DV pass.
- **File/function:** pinned generated `otp_ctrl_sim` `tb.sv:182-191` nested `MEM_*` macros and `DV_STRINGIFY`; `uvm_dpi/uvm_dpi_iverilog.cc` `uvm_hdl_check_path`; `ivlpp/lexor.lex` continued-macro expansion.
- **Possible clause:** Macro stringification/whitespace semantics require edition-specific review before labeling this an IEEE compiler defect.
- **Evidence:** [Pinned compile and smoke](../../evidence/opentitan-otp-vif-fixed-input-20260924/README.md); the generated VVP has the padded string and the target `mem` array.
- **Reproducer status:** confirmed in the released OTP runtime; paired 2017/2023 continued, flattened, and literal-space controls are in [the path-overlay evidence](../../evidence/opentitan-otp-backdoor-path-overlay-20260924/README.md).
- **Triage status:** promoted to BLOCKERS.md as OT-OTP-BACKDOOR-PATH-COMPAT; a hash-checked disposable-source overlay clears the path fatal while preserving the backdoor fatal and width/depth checks. The released smoke then fails on the distinct joint-distribution blocker. IEEE macro-whitespace classification remains separate.

### DD-055 — CSRNG nested virtual-interface value omitted at config-db handoff

- **Discovered while working:** OT-CSRNG-CFG-JOINT-DIST
- **Observation:** The private ordered-guard VVP advances the pinned CSRNG smoke past cfg.randomize(), but the same 0 ps replay reports a null %wait/vif/posedge, TL-UL assertion, and TEST FAILED CHECKS. VVP exit 0 is not a DV pass. A hash-verified opcode probe locates the failing wait in the 129-bit genbits push-pull monitor. The parent CSRNG VIF is nonnull and the nested agent receives its config object, but the child VIF is null before monitor assignment. In the original VVP image, the two config-db set calls for cfg.vif.cmd_push_if and cfg.vif.genbits_push_if omit the %store/obj for formal value, so the callee receives default null.
- **File/function:** PCallTask::elaborate_build_call_ in elaborate.cc builds the copy-in assignment; PEIdent::elaborate_expr_class_field_ in elab_expr.cc resolves the class-held nested VIF actual, and tgt-vvp/stmt_assign.c emits a valid object store. Which compiler stage loses the assignment remains to be traced.
- **Possible clause:** N/A until the compiler path is reduced/classified; the released parent-to-child VIF handoff should preserve the interface object value.
- **Evidence:** [Hash-checked released replay, bytecode and paired 2017/2023 RED/controls](../../evidence/opentitan-csrng-nested-vif-handoff-20260924/README.md).
- **Reproducer status:** parent-VIF and direct-nested controls compile/run; class-held nested handoff fails code generation -3 in strict 2017 and 2023. The original released image shows omitted value stores.
- **Triage status:** independent compiler lowering blocker, outside the ordered-guard solver patch. CSRNG remains 0/1 DV, and no compiler fix has been applied.

### DD-056 — OTP smoke reaches an EDN pull-agent sequencer cast fatal

**Census disposition (2026-10-08):** no active ticket. Current-main history includes `bb92498ad` (“Canonicalize concrete multi-value class specializations”), and the clause matrix records the corresponding §8.25 identity fix; no current-main reproducer was established in this census.


- **Discovered while working:** OT-CSRNG-CFG-JOINT-DIST
- **Observation:** The private ordered-guard VVP advances the named-overlay OTP smoke past cfg.randomize(), then dv_base_seq.sv:10 raises DCLPSQ at 0 ps for m_edn_pull_agent[0].sequencer. The compiled factory creates a push_pull_sequencer #(32,33) descriptor different from the same-parameter descriptor required by p_sequencer; both use the same registry get. A bytecode-only diagnostic accepting the factory descriptor clears DCLPSQ but the run still ends in assertion failure, so OTP remains 0/1 DV with no meaningful traffic or pass.
- **File/function:** elab_scope.cc:3533-3540 uses source-sensitive specialization keys for multiple value parameters; elaborate_specialized_class_type in elab_scope.cc:4013-4043 uses the semantic cache only for C-prefixed keys. Named versus positional forms of the same parameter values therefore emit different class descriptors.
- **Possible clause:** IEEE 1800-2017/2023 parameterized class type identity; classify against the exact clauses before a conformance claim.
- **Evidence:** [Paired 2017/2023 RED and bytecode probes](../../evidence/opentitan-otp-dd056-factory-registry-20260924/README.md) and [private pinned OTP replay](../../evidence/opentitan-joint-ordered-guard-candidate-20260924/otp-private-runtime.log).
- **Reproducer status:** paired named/positional equal-value specialization casts fail in both editions; positional-only controls pass and unequal-value casts reject as expected.
- **Triage status:** separate compiler canonicalization blocker, outside the selected vvp/vvp_z3.cc solver patch. No pinned-source or compiler fix has been applied.

### DD-057 — scalar function output to associative class-property element is skipped

- **Issue status:** [OPEN existing issue #429](https://github.com/dsellerbrock/iverilog-uvm/issues/429).

- **Discovered while working:** OT-CSRNG-FUNCTION-OUTPUT-BIT-COPYBACK
- **Observation:** A function output `logic[1023:0]` actual `holder.entries["k"]` where `entries` is a class associative array of `bit[31:0]` compiles with `Skipping indexed property copy-out for data`; the element remains zero. This differs from the selected whole scalar `holder.value` copy-out.
- **File/function:** `tgt-vvp/draw_ufunc.c`, indexed `IVL_EX_PROPERTY` function copy-out branch.
- **Possible clause:** IEEE 1800-2017/2023 §13.5; indexed class-property lvalue typing also needs classification.
- **Evidence:** [Diagnostic source and log](../../evidence/opentitan-csrng-function-output-bit-copyback-20260925/output-shapes-assoc.runtime.log) with separate compile log in the same directory.
- **Reproducer status:** confirmed in a diagnostic copy; not a qualifying released DV run.
- **Triage status:** untriaged, outside this blocker and its bit conversion fix.

### DD-058 — mismatched two-state/four-state ref actual is accepted

- **Issue status:** [OPEN #477](https://github.com/dsellerbrock/iverilog-uvm/issues/477).

- **Discovered while working:** OT-CSRNG-FUNCTION-OUTPUT-BIT-COPYBACK
- **Observation:** Both strict editions accept a `ref logic[31:0]` formal bound to a `bit[31:0]` actual, even though a `ref` argument must have an equivalent type; this is distinct from an `output` argument's assignment conversion.
- **File/function:** function ref-argument validation in elaboration; exact source symbol not traced.
- **Clause:** IEEE 1800-2017/2023 §§13.5.2 and 6.22.2(c) require equivalent `ref` types, including the same two-state or four-state classification.
- **Evidence:** [Paired diagnostic source and compile logs](../../evidence/opentitan-csrng-function-output-bit-copyback-20260925/ref-mismatch.sv).
- **Reproducer status:** confirmed acceptance in both editions; no runtime semantics assessed.
- **Triage status:** untriaged, outside this output copy-back blocker.

### DD-059 — inline constraints capture an aliased active random variable as caller state

- **Issue status:** [OPEN #478](https://github.com/dsellerbrock/iverilog-uvm/issues/478).

- **Discovered while working:** OT-CSRNG-INLINE-RECEIVER-PROPERTY-CONSTRAINT.
- **Observation:** With `owner.alt` and `owner.req` pointing to the same item, `alt.randomize() with { req.clen == 12; }` returns zero and leaves `clen=0` in both strict editions. The direct `req.randomize() with { req.clen == 12; }` now succeeds, while a distinct object reference remains fixed caller state. A spelling-only receiver-root mapping cannot distinguish the two aliases.
- **File/function:** `elaborate.cc` `constraint_inline_alias_field_ir_()` and `pexpr_to_constraint_ir()` compare the caller handle with the randomize receiver before lowering the selected property as an active solver field or caller state.
- **Clause:** IEEE 1800-2017 §18.5.9 and 2023 §18.5.8 select active random variables from the invoked object and treat other references as state; §18.7 governs inline name lookup.
- **Evidence:** [Paired strict alias reducer and logs](../../evidence/opentitan-csrng-inline-receiver-20260925/alias_identity.sv) with `boundary_results.json` in the same directory.
- **Reproducer status:** paired 2017/2023 compile exit zero; runtime exit one at the same-object alias after bare and direct-receiver controls pass.
- **Triage status:** implemented in the active #478 feature branch; T0/T1 covers direct and nested aliases plus a distinct-object control. Keep open until the T2 batch lands.

### DD-060 — explicit `this` inline target lookup accepts a caller-only member

- **Issue status:** [OPEN #479](https://github.com/dsellerbrock/iverilog-uvm/issues/479).

- **Discovered while working:** OT-CSRNG-INLINE-RECEIVER-PROPERTY-CONSTRAINT.
- **Observation:** `this.no_such_member` in a target object's inline constraint is accepted when the caller class declares `no_such_member` but the randomized class does not. Both strict editions compile it without an error, although explicit `this` must bind in the randomized class.
- **File/function:** `elaborate.cc` inline target-path lookup and expression elaboration; exact first fallback remains to be traced.
- **Clause:** IEEE 1800-2017/2023 §18.7 requires `this`-qualified inline names to bind to the randomized object's class and makes an unresolved target name an error.
- **Evidence:** [Paired strict reducer and compile logs](../../evidence/opentitan-csrng-inline-receiver-20260925/explicit_this_caller_shadow_illegal.sv) with `boundary_results.json` in the same directory.
- **Reproducer status:** paired 2017/2023 compile exit zero; runtime not assessed.
- **Triage status:** separate lookup blocker; the current PR's negative check covers only an absent member through the direct receiver spelling.

### DD-061 — constant out-of-range parameter-array read may lose two-state default

- **Discovered while working:** OT-OTP-DAI-RAND-INDEXED-PARTINFO-GUARD.
- **Observation:** Source review found the pre-existing constant-index parameter-array elaboration path constructs an X value for an invalid selection without checking whether the selected integral type is two-state. This PR's solver-dependent selection handles the declared two-state/four-state distinction; the separate constant-folding path remains unqualified.
- **File/function:** `elab_expr.cc` constant unpacked parameter-array selection; exact call chain needs triage.
- **Clause:** IEEE 1800-2017 §7.4.6 and 2023 §7.4.5, Table 7-1 (invalid-index integral read default).
- **Evidence:** Read-only source review during the paired dynamic-index reducer design; no constant-index runtime result is claimed.
- **Reproducer status:** sketched; paired constant-index reducer still needed.
- **Triage status:** untriaged, outside this solver-dependent selection blocker.

### DD-062 — `$system` accepts an extra argument

- **Issue status:** [OPEN #480](https://github.com/dsellerbrock/iverilog-uvm/issues/480).

- **Discovered while working:** OT-SYSTEM-FUNCTION-RETURN.
- **Observation:** Both strict editions compile `$system("exit 0", "exit 7")` without an arity diagnostic. The current ticket only repairs the returned status and legal task use.
- **File/function:** `vpi/sys_icarus.c` `$system` registration has no `compiletf`; `system_calltf` reads only the first argument.
- **Possible clause:** IEEE 1800-2017 §20.18.1 and 2023 §20.17.1 allow one string expression or no argument.
- **Evidence:** [Paired illegal reducer](../../evidence/opentitan-system-return-20260925/system_extra_arg_fail.v) compiles exit zero under both editions before and after the selected function-result fix.
- **Reproducer status:** paired illegal source accepted; runtime behavior was not assessed.
- **Triage status:** untriaged, outside the function-result blocker.

### DD-063 — covergroup sampling loses X/Z before ordinary-bin matching

- **Issue status:** [OPEN #481](https://github.com/dsellerbrock/iverilog-uvm/issues/481).

- **Discovered while working:** OT-LC-PACKED-COVERPOINT-SHAPE.
- **Observation:** In both strict 2017 and 2023 modes, a five-bit X-valued class property and its bitwise expression evaluate as `xxxxx`, but the first `sample()` raises ordinary zero/negative-bin coverage from 0% to 50%. A direct-property coverpoint fails alongside the bitwise expression, so this is independent of the selected declaration-time shape fix. An explicit X/Z-bin diagnostic also remains unsupported; simply skipping all unknown samples would be incomplete.
- **File/function:** `vvp/vthread.cc` `of_COVGRP_SAMPLE` computes `cp_has_xz` but passes only zero-coerced `uint64_t` values to `covgrp_sample_core_` / `covgrp_rec_match_`, which then matches the numeric zero bin.
- **Possible clause:** IEEE 1800-2017/2023 §19.5, including the explicit X/Z-bin rules in §19.5.4; review the exact matching rule before implementation.
- **Evidence:** [Paired X/Z value and direct-property reducer](../../evidence/opentitan-lc-packed-coverpoint-20260925/xz_sample_red.sv), [2017 log](../../evidence/opentitan-lc-packed-coverpoint-20260925/xz_sample_2017.log), [2023 log](../../evidence/opentitan-lc-packed-coverpoint-20260925/xz_sample_2023.log), and [explicit-bin probe](../../evidence/opentitan-lc-packed-coverpoint-20260925/xz_explicit_bin.sv).
- **Reproducer status:** paired compile exit zero, runtime exit one at the first X sample; source and expression both print `xxxxx` before coverage rises to 50%. Z behavior is not yet isolated beyond the same earlier boundary fixture failing at X first.
- **Triage status:** separate VVP four-state coverage representation blocker; no fix, no DV credit, and no implementation scope in the current elaborate.cc ticket.

### DD-064 — string conditions test only the low bit

- **Current disposition (2026-10-08):** Fixed on `main` by [commit 11d4b588](https://github.com/dsellerbrock/iverilog-uvm/commit/11d4b588c). The paired 2017/2023 regression in `ivtest/ivltests/sv_string_condition_truth.v` verifies string truth conversion; the original failure records below are historical.

- **Discovered while working:** OT-STD-RANDOMIZE-RANGED-SIZE-EXACT.
- **Observation:** In strict 2017 and 2023, `s = "AB"; if (s)` takes the false branch although the string's packed value is nonzero (`16'h4142`) and `!s` is false. `while`, `for`, `do while`, and ternary conditions also choose the false path.
- **File/function:** `tgt-vvp/eval_condit.c` `draw_condition_fallback`; `tgt-vvp/eval_string.c` and `eval_real.c` duplicate the nominal-width test for ternary conditions.
- **Possible clause:** IEEE 1800-2017/2023 12.4 (nonzero known `if` predicate); 11.4.7 (logical truth).
- **Evidence:** `/private/tmp/str_truth_conditions_red.sv` passes `slang --quiet`; both strict runs print `failed=5 value=9 chosen=no real=2.500000` and exit at `$fatal`. The generated VVP casts the string at natural width, then tests bit 0 without reduction.
- **Reproducer status:** confirmed in strict 2017 and 2023.
- **Triage status:** untriaged; separate from the active Z3 size solver patch.

### DD-065 — virtual-interface covergroup sampling silently has zero coverpoints

- **Issue status:** [OPEN #482](https://github.com/dsellerbrock/iverilog-uvm/issues/482).

- **Discovered while working:** OT-STD-RANDOMIZE-RANGED-SIZE-EXACT.
- **Observation:** In strict 2017 and 2023, `vif.cg.sample()` compiles without a diagnostic but leaves two bound interface instances at 0% coverage. The same calls through physical `u0.cg` and `u1.cg` reach 50% each. A direct `coverpoint v` fails through `vif` too, so the loss precedes coverpoint expression lookup.
- **File/function:** `elaborate.cc` `PCallTask::elaborate_method_` reads `covgrp_ncoverpoints()` from the virtual receiver's covergroup type; `elab_type.cc` `interface_layout_view_` supplies its interface layout type. The emitted virtual calls use `%covgrp/sample 0, 0`, whereas physical calls evaluate the coverpoint and use `%covgrp/sample 1, 1`.
- **Possible clause:** IEEE 1800-2017/2023 §19.3 (covergroup sampling) and §25.9 (virtual-interface binding); confirm exact subclauses during selection.
- **Evidence:** `/private/tmp/iverilog-vif-covergroup-scope-review.sv` and paired generated VVP files; both strict installed-tool runs print `COVERAGE 0.000000 0.000000` / `FAILED`, while the physical-call control prints `COVERAGE 50.000000 50.000000` / `PASSED`. Slang accepts the virtual source under both editions with zero errors or warnings.
- **Reproducer status:** confirmed paired strict wrong-success; virtual receiver can rebind between two instances.
- **Triage status:** separate elaboration/type-metadata blocker. A fixed concrete-instance lookup cannot cover a rebinding virtual handle; retain the selected receiver while making its covergroup metadata and sample expressions available, or reject unsupported sampling explicitly. No implementation in the active solver ticket.

### DD-066 — const-ref forwarding is rejected as an assignment to const

- **Issue status:** [OPEN #483](https://github.com/dsellerbrock/iverilog-uvm/issues/483).

- **Discovered while working:** OT-PACKED-CONSTRAINT-INDEX-EXACT.
- **Observation:** The released OpenTitan SPID `tlul_rmw` task passes its `const ref` clock and response arguments to `tlul_read` and `tlul_write`, whose corresponding formals are also `const ref`. After a disposable source overlay clears an unrelated missing struct field, Icarus reports four `Assignment to const signal` errors at the two calls. A 16-line standalone reducer produces the same four errors under local Icarus `-g2012`, with or without `-gcommercial-unsafe`. Slang 11.0.448 accepts it with zero errors and warnings under both `--std 1800-2017` and `--std 1800-2023`. A negative control changing one receiving formal to writable `ref` is rejected by Slang in both editions (`cannot bind const variable to 'ref' argument`). Icarus has no 2017/2023 language switch; `-g2012` is its highest available mode.
- **File/function:** `PCallTask::elaborate_ref_bind_` in `elaborate.cc:18056` calls `actual->elaborate_lval` without conveying that the receiving formal is read-only. `PEIdent::elaborate_lval` then rejects `reg->get_const()` at `elab_lval.cc:958` as though reference binding were an assignment. The sole caller of `elaborate_ref_bind_` is `PCallTask::elaborate_build_call_` at `elaborate.cc:18668`. A dedicated read-only-ref lvalue context, enabled only when the receiving `ref` formal is const, would retain the existing lvalue checks while preserving writable-ref rejection; `is_init` and `is_force` are not suitable substitutes.
- **Possible clause:** IEEE 1800-2017/2023 §13.5.2 (passing arguments by reference); confirm the exact edition wording before implementation.
- **Evidence:** `/Users/danielellerbrock/Documents/Codex/2026-09-27/users-danielellerbrock-projects-iverilog-uvm-handoff/outputs/minimal-reproducers/ot-spid-const-ref-forward-min.sv`; disposable SPID compile log `/private/tmp/ot-spid_jedec-focused-w3qzp13u/compile.log`. The three stale SPID ports and four `sd_out` mixed-driver diagnostics in that log are separate.
- **Reproducer status:** Confirmed compile rejection in local Icarus and acceptance in paired Slang editions; the writable-ref negative control rejects as expected in Slang. No compiler patch or application-source edit was made.
- **Triage status:** Reproduced, record-only during OT-PACKED-CONSTRAINT-INDEX-EXACT; no implementation selected.

### DD-067 — associative arrays of fixed arrays lack a sound VVP representation

- **Issue status:** [OPEN #484](https://github.com/dsellerbrock/iverilog-uvm/issues/484).

- **Discovered while working:** OT-RSTMGR-DERIVED-ARRAY-OPEN-FORMAL corpus triage.
- **Observation:** A three-line `bit tgt[enum][2]` declaration fails under Icarus strict 2017/2023 while Slang accepts it. This is the largest family in the saved patched-copy Flash compile (114 diagnostics). Removing the `netuarray_t` type guard alone would lose fixed bounds and default element construction in VVP.
- **File/function:** `elab_type.cc` associative element check; `tgt-vvp/vvp_priv.h` container layout; `vvp/vvp_object.*` layout; `vvp/vthread.cc` associative element construction.
- **Possible clause:** IEEE 1800-2017/2023 §§7.4, 7.8; check exact nested-container behavior when selected.
- **Evidence:** `outputs/minimal-reproducers/ot-flash-assoc-of-fixed-red.sv` and `work/flash-queue-triage-20260928/result.json` in the projectless campaign workspace.
- **Reproducer status:** paired strict compile RED on the frozen compiler; current active patch passes 16/16 focused strict JSON and 16/16 legacy controls for module and class-property storage. One patched-copy Flash compile and wider qualification remain pending.
- **Triage status:** active compiler blocker OT-FLASH-ASSOC-OF-FIXED-ARRAY, separate from the RSTMGR source patch.

### DD-068 — nested queue constraints cannot reach fixed-array queue leaves

- **Issue status:** [OPEN existing issue #419](https://github.com/dsellerbrock/iverilog-uvm/issues/419).

- **Discovered while working:** OT-RSTMGR-DERIVED-ARRAY-OPEN-FORMAL corpus triage.
- **Observation:** `q[i].size()==2` under `rand bit q[2][$]` fails elaboration, and `foreach(q[i,j]) q[i][j]==1` warns that it is unrepresentable before `randomize()` fails. Flat queue controls pass in both editions; Slang accepts the nested sources.
- **File/function:** `elaborate.cc` indexed queue `.size()` constraint lowering and fixed-array/queue `foreach` IR traversal.
- **Possible clause:** IEEE 1800-2017/2023 §18.5; confirm subclauses during selection.
- **Evidence:** `outputs/minimal-reproducers/ot-flash-nested-queue-size-red.sv`, `outputs/minimal-reproducers/ot-flash-nested-queue-element-red.sv`, and `work/flash-queue-triage-20260928/result.json` in the projectless campaign workspace.
- **Reproducer status:** paired strict compile/runtime REDs; no compiler fix.
- **Triage status:** the original simple fixed-array queue-leaf candidate is superseded. Current-main direct probes (2026-10-09) assert queue sizes and constrained values and pass under strict 2017 and 2023. This does not qualify all nested queue/container forms or the Flash core; select only a stronger current reducer if reopening this debt.

### DD-069 — prim_flop_2sync setup omits its generated flop provider

- **Discovered while working:** OT-RSTMGR-DERIVED-ARRAY-OPEN-FORMAL corpus triage.
- **Observation:** The pinned FuseSoC dependency graph contains `prim_generic:flop_2sync -> prim:flop`, but its source list omits both `prim_flop.sv` and `prim_generic_flop.sv`. A one-line direct `prim:flop` dependency in `prim_flop_2sync.core` makes disposable setup generate both. One focused compile removes the two unknown-module errors and exposes separate obsolete CDC-delay task calls.
- **File/function:** `hw/ip/prim/prim_flop_2sync.core` `primgen_dep`; generated `prim_flop_2sync` file list.
- **Possible clause:** setup/provider mapping, not an IEEE compiler-semantic issue.
- **Evidence:** `outputs/patches/ot-prim-flop-provider-dependency.patch` and `work/prim-flop-provider-20260928/compile-result.json` in the projectless campaign workspace.
- **Reproducer status:** disposable setup and one focused compile; no runtime.
- **Triage status:** source metadata correction proposal; the six stale TB task calls remain a separate issue.

### DD-070 — SPI TPM pre-DV testbench targets obsolete parameters and ports

- **Discovered while working:** OT-RSTMGR-DERIVED-ARRAY-OPEN-FORMAL corpus triage.
- **Observation:** Three TB overrides name local or nonexistent `spi_tpm` parameters. A three-line correction clears the exact minimal strict 2017/2023 errors, but static RTL comparison also finds eight obsolete named ports and a TB 8-bit read-FIFO assumption against the RTL's 32-bit read FIFO. The current OpenTitan matrix already compiles this target with `-gcommercial-unsafe`; census11 still reports the three parameter errors under that flag. The flag's documented compatibility cases do not include overriding localparams or dropping unknown ports, so this result is not a reason to treat strict mode as the matrix mode. The separate source-interface drift still requires port/FIFO reconciliation for runtime.
- **File/function:** `hw/ip/spi_device/pre_dv/tb/spi_tpm_tb.sv` instance versus released `hw/ip/spi_device/rtl/spi_tpm.sv`.
- **Possible clause:** released source/interface mismatch, not an IEEE compiler-semantic issue.
- **Evidence:** `outputs/patches/ot-spi-tpm-stale-parameter-overrides.patch` and `work/ot-spi-tpm-param-20260928/result.md` in the projectless campaign workspace.
- **Reproducer status:** paired strict minimal controls and static port contract; no full core compile or runtime.
- **Triage status:** source correction proposal only; requires separate port/FIFO reconciliation before application qualification. Evaluate a narrowly paired unsafe-mode extension only if a supported commercial tool accepts these exact overrides; even that cannot restore the obsolete ports or old byte-FIFO behavior.

### DD-071 — missing associative key read omits the required warning

- **Issue status:** [OPEN #486](https://github.com/dsellerbrock/iverilog-uvm/issues/486).

- **Discovered while working:** OT-FLASH-ASSOC-OF-FIXED-ARRAY.
- **Observation:** Reading a nonexistent scalar associative entry returns its default value without allocating, but emits no runtime warning. This predates fixed-array element support; the active blocker preserves the same read/value behavior and does not claim full missing-key diagnostic conformance.
- **Warning distinction:** The fixed-child runtime currently stores its implicit default through `has_default_`, which also marks a user-specified default. A later warning fix must distinguish those cases so implicit fixed defaults do not suppress the §7.8.6 warning.
- **File/function:** VVP associative-array read handlers in `vvp/vthread.cc`; precise warning path needs separate triage.
- **Possible clause:** IEEE 1800-2017/2023 §7.8.6 (read of a nonexistent entry warns unless a user default is specified).
- **Evidence:** `work/flash-queue-triage-20260928/scalar-missing-key.sv` prints `VALUE=00 EXISTS=0` with no warning under the frozen Icarus runtime.
- **Reproducer status:** confirmed with a minimal scalar control.
- **Triage status:** untriaged; separate from fixed-array value/storage semantics.

### DD-072 — variable-size whole-map pattern items need transactional validation

- **Issue status:** [OPEN #485](https://github.com/dsellerbrock/iverilog-uvm/issues/485).

- **Discovered while working:** OT-FLASH-ASSOC-OF-FIXED-ARRAY.
- **Observation:** A dynamic array or queue can legally supply a fixed-array associative pattern item when its runtime size matches. On a mismatch, the whole-map assignment must report an error and leave the old map unchanged. The current typed pattern builder loses destination layout until after map replacement, so this slice explicitly rejects variable-size items at compile time instead of silently replacing the map.
- **File/function:** `tgt-vvp/stmt_assign.c` `draw_eval_assoc_default`, `draw_assoc_pattern_value_`; `vvp/vthread.cc` `aa_new_default`; `vvp/vvp_assoc.h` map copy/rebind.
- **Possible clause:** IEEE 1800-2017/2023 §7.6 and §7.8.
- **Evidence:** Paired strict expected-fail fixture `ivtest/ivltests/sv_assoc_fixed_pattern_variable_source_fail.v`; transactional module/class reducers under `work/flash-queue-triage-20260928/flash-review-*-dynamic-mismatch-transaction.sv` in the projectless campaign workspace. Slang accepts those legal sources; current Icarus gives an explicit unsupported diagnostic for both default and keyed pattern items.
- **Reproducer status:** strict 2017/2023 CE control passes in the 16-case JSON and legacy focus; transactional runtime implementation remains absent.
- **Triage status:** explicit unsupported boundary for this blocker; select separately before claiming full §7.6 pattern assignment support.

### DD-073 — module associative fixed-array class-handle writes (fixed subset)

- **Issue status:** [OPEN #484](https://github.com/dsellerbrock/iverilog-uvm/issues/484).

- **Discovered while working:** OT-FLASH-ASSOC-OF-FIXED-ARRAY.
- **Observation:** Fixed for module variables whose associative elements are fixed unpacked arrays of class handles. In `entry src[int][8:9]`, reading a missing key returns the fixed-array default without creating the key; assigning `src[4][8] = handle` creates the entry, leaves `src[4][9]` null, and preserves the assigned handle identity. Class-property handling is unchanged.
- **File/function:** `tgt-vvp/stmt_assign.c` module associative-array lvalue lowering; existing `%aa/viv/sig` with `AA_VIV_FIXED` allocates the missing key and the enclosing fixed-slot lvalue retains the child type.
- **Possible clause:** IEEE 1800-2017/2023 §§7.4, 7.8.6, and 7.8.7.
- **Evidence:** Paired tests `ivtest/ivltests/sv_assoc_fixed_module_class_handle.v` and `_2023.v` check absent-read nonallocation, write allocation, the untouched default handle, and handle identity. Local focused legacy/JSON runs passed; exact-head Fast Linux passed. Full T0/T1 remains pending.
- **Reproducer status:** 2017 and 2023 reducers pass. They check absent-read nonallocation, not the §7.8.6 warning. This qualifies only the module-scope class-handle leaf write/read shape.
- **Triage status:** this slice fixes DD-073. Issue #484 remains open for other shapes, including DD-074 packed-bit tails and DD-075 indexed nonblocking writes.

### DD-074 — packed-bit write after an associative fixed slot is unsupported

- **Issue status:** [OPEN #484](https://github.com/dsellerbrock/iverilog-uvm/issues/484).

- **Discovered while working:** OT-FLASH-ASSOC-OF-FIXED-ARRAY.
- **Observation:** `m[key][fixed_slot][packed_bit] = value` is legal and accepted by Slang, but current Icarus gives an explicit `one key and one fixed slot index` elaboration error. The selected Flash sites use whole packed-leaf assignments.
- **File/function:** `elab_lval.cc` nested fixed-child lvalue selection.
- **Possible clause:** IEEE 1800-2017/2023 §§7.4 and 7.8.
- **Evidence:** `work/flash-queue-triage-20260928/flash-assoc-fixed-packed-tail-boundary.sv` in the projectless campaign workspace; strict 2017 compiler exits nonzero, Slang lint accepts it.
- **Reproducer status:** focused explicit compile boundary.
- **Triage status:** separate follow-on; no packed-bit write support claimed by this blocker.

### DD-075 — nonblocking indexed write to an associative fixed child is unsupported

- **Issue status:** [OPEN #484](https://github.com/dsellerbrock/iverilog-uvm/issues/484).

- **Discovered while working:** OT-FLASH-ASSOC-OF-FIXED-ARRAY.
- **Observation:** `m[key][fixed_slot] <= value` is legal, but current target reports that the nonblocking property assignment form is unsupported rather than scheduling the write with NBA semantics. The selected Flash sites do not require this form.
- **File/function:** `tgt-vvp/stmt_assign.c` nested indexed nonblocking assignment lowering.
- **Possible clause:** IEEE 1800-2017/2023 §§7.8 and 10.4.2.
- **Evidence:** `work/flash-queue-triage-20260928/flash-review-nba.sv` in the projectless campaign workspace; strict 2017 compile exits nonzero with an explicit target diagnostic.
- **Reproducer status:** focused explicit compile boundary.
- **Triage status:** separate follow-on; no NBA behavior claimed by this blocker.

### DD-076 — null class method calls can return without a diagnostic

- **Discovered while working:** OT-FLASH-INDEXED-FIXED-HANDLE-METHOD.
- **Observation:** A void function call through a null class handle returns normally without invoking the body or reporting an error. Both a direct scalar receiver and an associative-key/fixed-slot receiver behave alike in strict 2017/2023. An out-of-range fixed-slot read yields null and does not alias a valid neighbor.
- **File/function:** Generated class-method call/body and property dereference paths in `tgt-vvp`/`vvp`; exact diagnostic owner needs separate triage.
- **Possible clause:** IEEE 1800-2017/2023 §§7.4.6/7.4.5, 8.4; null access diagnostic behavior needs separate assessment.
- **Evidence:** `work/flash-direct-null.sv`, `work/flash-indexed-null.sv`, and `work/flash-indexed-oob.sv` in the projectless campaign workspace; paired strict Icarus runs print `FAILED null method returned` for direct and selected null receivers.
- **Reproducer status:** paired strict runtime observation; no change to this global behavior in the indexed receiver fix.
- **Triage status:** record-only diagnostic-policy follow-on; do not count silent null calls as successful method execution.

### DD-077 — queue foreach silently skips a packed element dimension

- **Issue status:** [OPEN #487](https://github.com/dsellerbrock/iverilog-uvm/issues/487).

- **Discovered while working:** OT-FLASH-FOREACH-MIXED-RANK.
- **Observation:** `bit [1:0] q[$]; foreach (q[i,j])` compiles in strict 2017/2023 but executes zero body visits after a two-bit queue element is inserted. Slang accepts the same source. This predates the mixed fixed/runtime repair; that repair gives an explicit unsupported diagnostic when a packed rank follows its selected runtime leaf, rather than silently dropping the loop.
- **File/function:** `elaborate.cc` `PForeach::elaborate_runtime_array_` and `make_foreach_array_element_expr_` currently descend through runtime array ranks only.
- **Possible clause:** IEEE 1800-2017/2023 §12.7.3.
- **Evidence:** `work/flash-foreach-next-20260928/plain-queue-packed-tail.sv` and `work/flash-foreach-next-20260928/mixed-packed-tail-unsupported.sv` in the projectless campaign workspace.
- **Reproducer status:** paired strict Icarus runtime zero-visit control and explicit mixed-tail compile boundary; Slang accepts the legal packed-tail source.
- **Triage status:** separate foreach packed-tail lowering task; no packed-tail runtime support claimed by the mixed-rank repair.

### DD-078 — physical-interface packed inner index aliases a neighbor

- **Issue status:** [OPEN existing issue #414](https://github.com/dsellerbrock/iverilog-uvm/issues/414).

- **Discovered while working:** OT-FLASH-VIF-PACKED-STRUCT-FIELD.
- **Observation:** With distinct packed-struct values in `rd_buf[0][0] = 8'h11`, `[0][1] = 8'h22`, `[1][0] = 8'h33`, and `[1][1] = 8'h44`, direct physical-interface reads `fi.rd_buf[0][2].addr` and `fi.rd_buf[1][-1].addr` return `8'h33` and `8'h22`. The invalid inner index carries into the neighboring outer row. The selected VIF repair returns X for both because it selects each packed rank separately. Valid direct slots still provide the field-value oracle for the active blocker.
- **File/function:** Direct physical-interface packed-select collapse in `elab_expr.cc`/`netmisc.cc`; exact owner needs separate triage.
- **Possible clause:** IEEE 1800-2017/2023 packed-array out-of-range indexing; exact subclause needs separate assessment.
- **Evidence:** Projectless `work/flash-vif-packed-struct-20260928/runtime-print-invalid.sv` on the focused candidate prints `outer=xx inner_high=33 inner_low=22 outer_x=xx inner_x=xx`; paired VIF-focused runtime controls return X for invalid inner indices.
- **Reproducer status:** confirmed with a minimal strict 2017 direct-interface runtime probe; VIF controls pass strict 2017/2023.
- **Triage status:** untriaged; separate from the selected VIF packed-struct field repair.

### DD-079 — packed child rank after an omitted associative foreach key

- **Issue status:** [OPEN #487](https://github.com/dsellerbrock/iverilog-uvm/issues/487).

- **Discovered while working:** OT-FLASH-FOREACH-OMITTED-ASSOC-KEY.
- **Observation:** `foreach (map[, bank, bit_index])` is legal when `map` has an associative rank, one fixed child rank, and a packed vector leaf. Slang accepts the strict 2017/2023 reducer. The selected repair iterates the fixed bank rank but explicitly diagnoses the packed tail as unsupported; no packed-rank execution is claimed.
- **File/function:** `elaborate.cc` `PForeach::elaborate_assoc_array_` and packed-rank descent after fixed child iteration.
- **Possible clause:** IEEE 1800-2017/2023 §12.7.3.
- **Evidence:** Focused candidate reducer and paired diagnostics in projectless `outputs/flash-omitted-assoc-foreach-focused-evidence-20260928.md`.
- **Reproducer status:** strict Slang accepts; focused Icarus gives an explicit `sorry` in both editions.
- **Triage status:** separate packed-tail implementation ticket; no silent execution accepted.

### DD-080 — indexed parent path before an omitted associative foreach key

- **Issue status:** [OPEN #487](https://github.com/dsellerbrock/iverilog-uvm/issues/487).

- **Discovered while working:** OT-FLASH-FOREACH-OMITTED-ASSOC-KEY.
- **Observation:** `foreach (boxes[next_idx()].m[, bank])` is legal and the indexed parent expression must be evaluated. A candidate that deleted the target expression without evaluating it visited banks but called `next_idx()` zero times. The selected repair explicitly diagnoses this form as unsupported, while the unindexed Flash target works.
- **File/function:** `elaborate.cc` `PForeach::elaborate_assoc_array_`; selector evaluation must precede fixed child loop execution.
- **Possible clause:** IEEE 1800-2017/2023 §12.7.3 and ordinary expression side effects.
- **Evidence:** Focused indexed-prefix negative and independent review in projectless `outputs/flash-omitted-assoc-foreach-focused-evidence-20260928.md`.
- **Reproducer status:** Slang accepts strict 2017/2023; Icarus emits an explicit `sorry` in both editions.
- **Triage status:** separate indexed-target evaluation ticket; no dropped side effects accepted.

### DD-081 — ascending packed class-property indexed read selects wrong bits

- **Issue status:** [OPEN #488](https://github.com/dsellerbrock/iverilog-uvm/issues/488).

- **Discovered while working:** OT-FLASH-CONSTRAINT-CONSTANT-INDEXED-PART-SELECT.
- **Observation:** A class property `bit [0:7] value = 8'hA6` reads `value[2+:3] == 3'b101` and `value[5-:3] == 3'b110`; copying it into a local `bit [0:7]` and selecting the same ranges gives the correct `3'b100` and `3'b001`. The whole property remains `8'hA6`. This predates the selected constraint change and occurs without randomization.
- **File/function:** procedural class-property packed-select elaboration/code generation; exact owner needs separate triage.
- **Possible clause:** IEEE 1800-2017/2023 §11.5.1 indexed part-select orientation.
- **Evidence:** Projectless `work/flash-constraint-indexed-impl-20260928/class-ascending-readback-debt.sv` reproduces in strict 2017 and 2023 using frozen installed ivl SHA-256 `56fe5718f2a7db3ea2075a588d1bbe82a49ecde8827536cde35897eebe6dfb6e` and VVP SHA-256 `0bc8c3b3e6a430dd0feec77d987c9ff78350206e8f386695f068131db5bcf862`.
- **Reproducer status:** paired strict runtime observation; the selected solver test checks ascending bits through a copied local.
- **Triage status:** separate procedural class-property selector repair; no claim that this constraint change repairs the read path.

### DD-082 — unsupported constraint marker mistakes a `.v:` filename for a value slot

- **Discovered while working:** OT-FLASH-CONSTRAINT-FIXED-ARRAY-PACKED-STRUCT-MEMBER.
- **Observation:** An unsupported constraint in a source named `*.v` emits the expected compile warning and makes `randomize()` fail, but runtime reports `malformed class constraint function capture` instead of naming the unsupported item. The same source named `*.sv` reports the intended unsupported-item error.
- **File/function:** `substitute_class_slots_` scans the `(unsupported ...file.v:line)` marker as if its `v:` filename suffix were a value-slot token.
- **Possible clause:** Diagnostic fidelity for explicitly unsupported class constraints; no changed IEEE semantic acceptance is claimed.
- **Evidence:** Projectless `work/flash-foreach-function-arg-20260928/unsupported-marker-filename.v`, compiled with strict `-g2017` and run with the current build-tree VVP. The `.v` run printed `ERROR: constraint state read: malformed class constraint function capture.`; the `.sv` variant printed the intended unsupported-item site.
- **Reproducer status:** confirmed with a minimal source; no solver-acceptance change.
- **Triage status:** untriaged; keep the filename parser repair separate from the packed-member fix.

### DD-083 — X/Z numeric literal in a constraint can alias zero

- **Issue status:** [OPEN #489](https://github.com/dsellerbrock/iverilog-uvm/issues/489).

- **Discovered while working:** OT-FLASH-CONSTRAINT-FIXED-ARRAY-PACKED-STRUCT-MEMBER.
- **Observation:** On freshly fetched `origin/main` at `c339b9f`, `rand logic [3:0] en; en == 4'hx` compiles without a diagnostic and `randomize()` wrongly succeeds with value zero in strict 2017 and 2023. Scalar and packed-struct array-member X/Z literal reducers also compile; a named scalar X/Z constant instead fails only at runtime.
- **File/function:** `elaborate.cc`'s `PENumber` arm in `pexpr_to_constraint_ir` calls `constraint_const_bits_ir_`, which serializes only one-bits and loses X/Z information. `constraint_constant_ir_` also returned no diagnostic for scalar named constants containing X/Z.
- **Possible clause:** IEEE 1800-2017/2023 §18.3. The standard says constraints support only two-state values and X/Z values or four-state operators are illegal and shall result in an error.
- **Evidence:** Projectless `work/flash-fixed-packed-member-20260928/{flash-scalar-x-rhs,flash-packed-member-x-rhs}.sv` on build-tree `ivl` SHA-256 `8a0e27e0e8881f7b1db4b8ef4201ef820748b4673ca05009d773836113f0bdba` and VVP SHA-256 `0187b7f3078511e914c346d75c630bddee9cebe08a35232933a7c2fb5dd2b0c3`; both report `WRONG-SUCCESS value=0`. The active repair adds paired source cases under `ivtest/ivltests/sv_constraint_xz_*` and strict manifests `ivtest/regress-constraint-xz-focus-{legacy,vvp}.list`.
- **Reproducer status:** confirmed in both strict editions for scalar, array-member, and named-constant forms.
- **Triage status:** selected as active issue #489 after current-origin/main reproduction on 2026-10-10; the repair is in draft [PR #530](https://github.com/dsellerbrock/iverilog-uvm/pull/530). The local 2017/2023 standards PDFs confirm §18.3; the scalar reducer compiles and wrongly randomizes to zero in both editions. Local focused gates pass; CI qualification remains pending and will be inspected only if a failure is reported. Keep the repair separate from the earlier packed-member fix.

### DD-084 — fixed class-property ordering method silently skips its receiver

- **Issue status:** [OPEN #490](https://github.com/dsellerbrock/iverilog-uvm/issues/490).

- **Discovered while working:** OT-FLASH-ASSOC-FIXED-CHILD-SHUFFLE.
- **Observation:** A direct one-dimensional fixed-array class property accepts `.reverse()` in strict 2017/2023, but target emission warns that `$ivl_uarray_method$order` has an unsupported receiver and skips it. The runtime array remains unchanged. This is distinct from the selected associative child: that child can use typed associative vivify to obtain stored object storage, while a direct fixed property needs explicit copyback.
- **File/function:** `tgt-vvp/vvp_process.c` `$ivl_uarray_method$order` at 6125–6150; fixed class-property array materialization and store path.
- **Possible clause:** IEEE 1800-2017/2023 §7.12.2.
- **Evidence:** Projectless `work/flash-shuffle-c56988df8-20260928/shuffle_min.sv`; Slang accepts the source in both editions, and current build-tree Icarus emits the skip warning and fails the direct-property reverse self-check.
- **Reproducer status:** confirmed.
- **Triage status:** untriaged; explicitly outside the selected associative child shuffle fix.

### DD-085 — whole selected queue masquerades as a scalar solve-order target

- **Issue status:** [OPEN #491](https://github.com/dsellerbrock/iverilog-uvm/issues/491).

- **Discovered while working:** OT-FLASH-SOLVE-BEFORE-MULTIDIM-ARRAY.
- **Observation:** `solve first before values[0][0]` for a fixed-array-of-queue class property compiles without warning and `randomize()` reports success, but the emitted order target is `e:1:1:0`, a scalar fixed-element slot. It is neither the queue size nor its contents. A strict 2017/2023 control with selected queue contents warns and fails instead.
- **File/function:** `elaborate.cc` selected fixed-element constraint reference at 33630–33635; `vvp/vvp_z3.cc` `ElemVar` and scalar element read/writeback.
- **Possible clause:** IEEE 1800-2017/2023 §18.5.10 integral solve-before operands and class constraint representation.
- **Evidence:** Projectless `work/flash-solve-solver-review-20260928/EVIDENCE.md` and `result.json`, build-tree `ivl` SHA-256 `512c79d3f4830012397def1142bf5325fee9004bb0e86e44847497380bcf283c`.
- **Reproducer status:** confirmed in strict 2017 and 2023; no Flash source-list replay followed.
- **Triage status:** reject whole-queue order until a typed nested queue-content representation exists; a simple dimension-guard removal is unsound.

### DD-086 — unpacked-array output port connected to a slice of a 2-D unpacked array reads X

- **Issue status:** [OPEN #492](https://github.com/dsellerbrock/iverilog-uvm/issues/492).

- **Discovered while working:** VVP-HOTPATH-PERF (Caliptra/Adams Bridge single-core performance assessment; no conformance ticket).
- **Observation:** `m u0(.s(s[0]))`, where `s` is `logic [1:0] s [2][3:0]` and the port is `output logic [1:0] s [3:0]` driven by `always_comb`, leaves every `s[0][k]` at X. Connecting a whole one-dimensional array (`.s(s1)`) works. No diagnostic is issued. The first Adams Bridge A2B reducer hit this and reported an all-X output hash.
- **File/function:** Port binding of unpacked-array slices; exact elaboration path not traced.
- **Possible clause:** IEEE 1800-2017/2023 §7.6 (unpacked array assignment compatibility) and §23.3.3 (port connection rules); review exact wording before implementation.
- **Evidence:** [Reducer](../../evidence/vvp-hotpath-perf-20260928/unpacked_slice_output_port.sv) and [log](../../evidence/vvp-hotpath-perf-20260928/discovered_debt_repro.log): `xx xx xx xx | 01 10` in both strict editions, identical on the unmodified 7a04009f baseline.
- **Reproducer status:** confirmed, paired 2017/2023.
- **Triage status:** untriaged. The performance reducer now uses per-instance arrays.

### DD-087 — out-of-range part select of a two-state vector leaves X in a two-state variable

- **Issue status:** [OPEN #469](https://github.com/dsellerbrock/iverilog-uvm/issues/469).
- **Crosswalk:** #469 also covers PR #464's DD-112 two-state packed bit-select OOB limitation. A paired clean-main reducer still prints X for the bit select; this is not a CI result.

- **Discovered while working:** VVP-HOTPATH-PERF.
- **Observation:** Invalid bit-selects from `bit` packed values returned X, and partially or fully out-of-range part-select reads retained X when assigned to `bit` destinations. IEEE 1800-2017/2023 §11.5.1 requires invalid two-state bit-selects to return 0 and partial part-select reads to return X in missing positions; §6.11.2 converts X/Z to zero at a two-state destination.
- **File/function:** `elab_expr.cc`, `PEIdent::elaborate_expr_net_bit_()`, `elaborate_expr_net_part_()`, and indexed part-select elaborators.
- **Evidence:** The original [reducer](../../evidence/vvp-hotpath-perf-20260928/two_state_oob_part_select.sv) and [log](../../evidence/vvp-hotpath-perf-20260928/discovered_debt_repro.log) establish the partial-select failure. The expanded permanent paired regression is `ivtest/ivltests/sv_two_state_packed_select_oob.v`. A clean-main frozen binary failed eight checks in each edition; the candidate passes direct `-g2017`/`-g2023`, focused legacy 3/3, and JSON/VVP 6/6, including `vvp_load_vec4_part_select` neighbors.
- **Reproducer status:** Confirmed before the patch and locally passing after it under both editions.
- **Triage status:** Tracked by [issue #469](https://github.com/dsellerbrock/iverilog-uvm/issues/469). Implemented locally; exact-head CI and merge remain pending. This is not a qualification claim.

### DD-088 — packed-subfield `release` asserts on non-immediate LHS offset

- **Issue status:** [OPEN #493](https://github.com/dsellerbrock/iverilog-uvm/issues/493).

- **Discovered while working:** OT-OTP-FORCE-RHS-BANKED.
- **Observation:** A `release dut.part_access[0].read_lock` on a packed array of packed structs aborts the VVP target with `Assertion failed: (number_is_immediate(part_off_ex, 64, 0)), function show_stmt_release, file vvp_process.c, line 3322.` This occurs after the separately selected packed-force link guard is applied. Whole-array `release dut.part_access` and `release dut.part_access_dai` compile and run; these are the exact release forms used by the selected OTP task.
- **File/function:** `tgt-vvp/vvp_process.c` `show_stmt_release`, packed LHS offset handling.
- **Possible clause:** IEEE 1800-2017/2023 §10.6 procedural continuous assignment `release` semantics; inspect the exact packed-select requirements before implementation.
- **Evidence:** [Reducer](../../evidence/opentitan-otp-force-rhs-20260928/packed_partial_release_repro.sv) and [focused OTP evidence](../../evidence/opentitan-otp-force-rhs-20260928/README.md). Strict `-g2017` and `-g2023`, each with `-gstrict-expr-width`, both exit 134 at the assertion on the private force-corrected VVP target.
- **Reproducer status:** confirmed paired compile-time assertion; no selected OTP runtime implicated.
- **Triage status:** separate targeted ticket; do not broaden the OTP force-RHS correction to partial release.

### DD-089 — type-only parameterized OTP test specialization is not registered

- **Discovered while working:** OT-UVM-PARAMETERIZED-REGISTRY-STATIC-INIT.
- **Pre-fix observation:** The pinned OTP testbench names a concrete parameterized base test only through a typedef in a true generate block. The former compiler emitted its generic master and registry but no concrete registration initializer; UVM reports `INVTST` at time zero. Paired 2017/2023 compiler-only controls with typedefs in package, module, and true-generate scopes all omit the concrete `$init`; false-generate and no-typedef controls also emit none. A concrete handle or explicit `get_type()` emits one named initializer. The pre-b2c3baf39 image emitted a generic-master initializer, not the concrete one, so reverting that commit would restore a false success.
- **File/function:** `NetScope::add_typedefs` only indexes names from package, module, generate, class, task/function, and named-block scopes; no later use reaches `typedef_t::elaborate_type` for a typedef-only specialization. A sound compiler fix needs deferred traversal of typedefs in elaborated scopes before `finalize_pending_specialized_class_elaboration()` and `release_deferred_static_inits()` in `elaborate.cc`, excluding generic masters and false generate branches.
- **Clauses:** IEEE 1800-2017/2023 §§8.25, 8.9, 6.8 and 10.5 govern concrete specializations and static class-property initialization; §6.21 supplies static-lifetime context. Both local editions were checked.
- **Evidence:** [Selected compile and tiny controls](../../evidence/opentitan-otp-factory-registration-20260929/selected_compile.json); the [named OTP source workaround](release_overlays/opentitan/otp_ctrl_explicit_test_registration.patch) calls the intended concrete specialization before `run_test()`.
- **Reproducer status:** confirmed in the small compile gate and selected OTP image; full patched-source OTP runtime pending.
- **Triage status:** CLOSED by `56f4bc756` for the tested compiler subset. Paired concrete typedef-only, false-generate, generic-only and later-use controls pass; the selected OTP compile no longer needs the registration workaround. Application runtime and full chapter-8 qualification remain separate.

### DD-090 — SDF interconnect port buffer emitted as BUFZ

- **Discovered while working:** OT-ADC-FIXED-2D-PACKED-STRUCT-MEMBER-CONSTRAINT integrated JSON gate.
- **Observation:** All three `sdf_interconnect` tests report `Could not find intermodpath` and miss their annotated delay. The smallest existing source, `sdf_interconnect1.v`, emits a `BUFZ` for the top variable-to-module input buffer with the current compiler, where the older compiler emitted `BUFT`. Current VVP runs the older bytecode correctly; older VVP reproduces the failure with current bytecode. This is compiler output, not a VVP runtime regression.
- **File/function:** `elaborate.cc` input-port `NetBUFZ` construction around line 6611 uses `!variable_input_source` even with `gn_interconnect_flag`; `t-dll.cc` maps a nontransparent buffer to `IVL_LO_BUFZ`; `vvp/vpi_priv.cc` `vpi_handle_multi` requires `vvp_fun_buft` for SDF interconnect. The variable-port rule was added in `d696b6934d`.
- **Possible clause:** Module port connection and SDF interconnect delay semantics; confirm precise IEEE 1800-2017/2023 clauses before implementation.
- **Evidence:** `ivtest/ivltests/sdf_interconnect1.v` with `-Ttyp -ginterconnect -gspecify -s top`; projectless `work/sdf-regression-triage-20260929/` has both bytecode images and cross-runtime results. The integrated gate ran 4,097 JSON tests with 32 failures; this family accounts for three.
- **Reproducer status:** confirmed with a minimal existing test and compiler/runtime cross-matrix.
- **Triage status:** separate compiler ticket. Preserve variable-port settled-value behavior while making SDF port buffers annotatable; no shared source change under the fixed-2D ticket.

### DD-091 — unsafe interface-driver guard suppresses live overlapping writes

- **Discovered while working:** OT-ADC-FIXED-2D-PACKED-STRUCT-MEMBER-CONSTRAINT integrated JSON gate.
- **Observation:** Twelve paired unsafe-mode compile negatives unexpectedly succeed with no diagnostic: eight virtual-interface property writers, two module-port procedural writers, and two virtual clocking-output writers. Each strict counterpart reports the expected continuous/procedural overlap error. Legal disjoint-member controls pass.
- **File/function:** `elaborate.cc` `finalize_unsafe_interface_drivers_` around lines 2960–2971. Commit `ed6415e450` suppresses `interface_member_has_property_writer_` whenever `-gcommercial-unsafe` and `completely_driven` are true. A fully driven scalar satisfies that condition even when its procedural writer is live or its VIF receiver is uncertain. The intended waiver is narrower: provably uncalled same-instance interface task writers.
- **Possible clause:** IEEE 1800-2017/2023 variable driver restrictions and virtual-interface aliasing; verify exact subclauses before implementation.
- **Evidence:** Exact-head direct strict/unsafe pairs and analysis in projectless `work/json-unsafe-negative-20260929/triage.md`. The 12 names are in the 4,097/32 full JSON gate.
- **Reproducer status:** confirmed in both editions using existing minimal sources.
- **Triage status:** separate compiler ticket; preserve the SPI compatibility case that motivated the unsafe waiver while keeping live or uncertain writes rejected.

### DD-092 — function argument capture rejects fixed queue size leaves

- **Issue status:** [OPEN #494](https://github.com/dsellerbrock/iverilog-uvm/issues/494).

- **Discovered while working:** OT-ADC-FIXED-2D-PACKED-STRUCT-MEMBER-CONSTRAINT integrated JSON gate.
- **Observation:** Both editions of `sv_constraint_fixed_queue_leaf_size` pass direct size constraints but fail the function-argument leaf-identity check. Emitted `.constraint_dep 3 0 1` denotes the requested fixed queue leaf SIZE; VVP rejects a function dependency on any fixed queue before capturing that value. A dynamic queue-size function argument also fails, so removing this one guard is not a proven fix.
- **File/function:** `vvp/vvp_z3.cc` around lines 11632–11636, fixed queue function-argument dependency guard and stage/capture path.
- **Possible clause:** IEEE 1800-2017/2023 class-constraint function calls and queue size; verify exact subclauses before implementation.
- **Evidence:** Exact-head direct tests and smallest controls in projectless `work/json-eight-direct-20260929/triage.md`.
- **Reproducer status:** confirmed strict 2017/2023 direct cases.
- **Triage status:** separate solver ticket; validate stage value and rollback before relaxing the guard, and retain intentional fixed-element function-argument rejection.

### DD-093 — constraint constant-folding errors trigger duplicate PartInfo diagnostics

- **Discovered while working:** OT-ADC-FIXED-2D-PACKED-STRUCT-MEMBER-CONSTRAINT integrated JSON gate.
- **Observation:** The bad-member and above-bit-63 PartInfo negatives each emit the expected specific error followed by a generic selector error, producing four JSON gold mismatches across 2017/2023. The second diagnostic does not add information.
- **File/function:** `elaborate.cc` constant-then-selector paths around lines 33465, 34093, and 34334 call `constraint_parameter_member_select_ir_` after `constraint_constant_ir_` has already increased `Design::errors`.
- **Possible clause:** Diagnostic quality rather than a new language-semantic claim.
- **Evidence:** Exact-head direct tests and first-error traces in projectless `work/json-eight-direct-20260929/triage.md`.
- **Reproducer status:** confirmed paired 2017/2023 negative tests; positive rand-index controls await a scoped fix.
- **Triage status:** separate diagnostic ticket. Skip selector fallback only when constant folding adds an error; continue symbolic fallback when it returns empty without an error.

### DD-094 — OTBN packed coverage bins use mutable class fields

- **Discovered while working:** OT-ROM-CTRL-STARTUP-RSS.
- **Observation:** The saved 49-target compile log for `lowrisc:dv:otbn_sim:0.1` has 178 errors because packed mnemonic and CSR bin bounds are initialized mutable class fields. Making them `const` removes that error but still fails wide-bin lowering; class `localparam` bounds compile and sample in tiny strict 2017/2023 controls.
- **File/function:** Pinned OpenTitan `hw/ip/otbn/dv/uvm/env/otbn_env_cov.sv`, `DEF_MNEM` and `DEF_CSR` macros at lines 17 and 114.
- **Possible clause:** IEEE 1800-2017/2023 §19.5, covergroup bin value expressions.
- **Evidence:** [DD-094 focused evidence](../../evidence/opentitan-otbn-localparam-bins-20260929/focus.json) records the historical log, exact copied-source/tool hashes, strict 2017/2023 controls, and paired selected compile commands/results. Raw paired logs and their SHA-256 values remain under `/private/tmp/otbn-dd094-20260929/`.
- **Reproducer status:** confirmed with tiny packed-width compile/runtime controls and a paired current-compiler OTBN source-list compile under a sampled 4 GiB process-group RSS watchdog.
- **Triage status:** the two-macro `localparam` overlay is committed. Relative to the unpatched copy, it clears 178 mutable-bin errors, 178 wide-bin errors, and 2,927 dropped-empty-cross notices without changing any other diagnostic line. The selected target still fails with 30 independent errors; no OTBN VVP/DV pass or 49-target census update is claimed.

### DD-095 — OTBN dynamic unpacked flag selection fails in coverpoint expressions

- **Discovered while working:** DD-094 paired selected OTBN compile.
- **Observation:** A non-ref covergroup sample formal containing `flags_t flags[2]` rejects `flags[fg].C`, `flags[fg][0]`, and `flags[fg][idx]` in strict 2017/2023. Scalarized controls compile and sample two distinct group values; Slang accepts the direct forms.
- **File/function:** Icarus `parse.y` covergroup sample-formal capture near line 3795 stores only `PWire::data_type()`, omitting `unpacked_indices()`; `elaborate.cc` then builds scalar formal placeholders/call slots. The `elab_expr.cc` and `netmisc.cc` failures are downstream symptoms.
- **Possible clause:** IEEE 1800-2017 §7.4.6 and IEEE 1800-2023 §7.4.5 for array indexing; both editions §19.5 for coverpoint sample expressions.
- **Evidence:** Projectless `work/otbn-flag-select-20260929/flag_select.sv` and `results.json`; DD-094 patched selected compile retains 25 sample-index and 3 packed-member internal errors.
- **Reproducer status:** the final candidate passes paired strict 2017/2023 direct, class-property, bare-array, opposite-direction and defaulted-array sample controls. Focused JSON and legacy runners pass 10/10 each; the guarded selected OTBN compile clears 25 dynamic-index errors and three packed-member internal errors, leaving two original tracer errors.
- **Triage status:** DONE for the tested compiler scope: exact-image JSON 4129/0, legacy 6880 passed/0 failed, real-DPI UVM 361/361, VPI 131/131, negative 154/154. [DD-095 evidence](../../evidence/opentitan-otbn-dynamic-sample-formal-20260929/focus.json) records exact source/tool hashes and the selected compile. No OTBN VVP/DV pass or 49-target update.

### DD-096 — X/Z coverpoint samples hit known-value bins

- **Issue status:** [OPEN #481](https://github.com/dsellerbrock/iverilog-uvm/issues/481).

- **Discovered while working:** DD-095 focused regression.
- **Observation:** A scalar non-ref covergroup sample formal `logic flag` is sampled as `1'bx` and `1'bz` in `{fg, flag}`; each sample reports 50% coverage of explicit known-value bins `2'b00` and `2'b11`, then the guard fatals. The sample has no dynamic array or packed-struct selection.
- **File/function:** Functional-coverage value sampling/bin matching, exact runtime root cause not yet traced.
- **Possible clause:** IEEE 1800-2017 and 1800-2023 §19.5.4: non-wildcard value bins match four-state values exactly; sampled X/Z cannot match these known-only bins.
- **Evidence:** [DD-096 reducer and paired red logs](../../evidence/opentitan-covergroup-xz-bin-debt-20260929/); the original projectless files remain under `work/dd095-xz-coverage-debt-20260929/`.
- **Reproducer status:** paired strict editions compile and fail the runtime check; first X sample already reports 50% instead of 0%.
- **Triage status:** separate coverage-runtime blocker. Exclude X/Z samples from the DD-095 array-shape success fixture; do not infer four-state bin qualification from known-value passes.

### DD-097 — OTBN trace checker ends with an unfinished operation

- **Discovered while working:** OT-OTBN-DPI-IMPORT-SCOPE.
- **Observation:** Without a final trace check, the selected OTBN smoke printed `TEST PASSED CHECKS` and zero UVM warnings/errors/fatals, then native `OtbnTraceChecker` warned on destruction that an operation remained unfinished. An instrumented replay showed `Finish()` was never called and both pending-entry queues were empty at shutdown. Calling `Finish()` at final model destruction checks any trailing RTL/ISS entries without the premature register comparison.
- **File/function:** Pinned OpenTitan `hw/ip/otbn/dv/model/otbn_trace_checker.cc` destructor at lines 28–34 and `Finish()` at line 213; caller in `otbn_model.cc` at line 463.
- **Possible clause:** N/A; application trace-verification completeness.
- **Evidence:** Earlier run: `evidence/opentitan-otbn-dpi-import-scope-20260929/selected-result.json` and `selected-runtime.log`. Hash-guarded runner overlay and selected PASS: [focused result and copied logs](../../evidence/opentitan-census-20261002/otbn-auto-prerun-focus/).
- **Reproducer status:** confirmed in one selected pinned-source smoke with real libelf DPI and the generated smoke ELF; no minimal reducer yet.
- **Triage status:** RESOLVED for the matrix's exact pinned OTBN source. `scripts/opentitan_matrix.py` stages a one-line hash-guarded overlay to call `Finish()` on final model destruction. The one-target matrix run is PASS with no runtime debt; the pinned source remains unchanged. A broader 49-target census is still pending.

### DD-098 — SPI Device flash-mode selected compile retains semantic notices

- **Discovered while working:** OT-MATRIX-SMOKE-REGRESSION-TEST-SELECTION.
- **Observation:** The official `spi_device_flash_mode_vseq` selected replay compiles and prints `TEST PASSED CHECKS` with zero UVM warnings/errors/fatals, but its compile has five semantic notices: three `spi_agent_pkg` foreach iterator `i` unresolved references, one covergroup `valids` bin clipped to a 1-bit domain, and one `spi_device_pass_base_vseq` indexed `addr` fallback. The runner correctly reports DEBT rather than PASS.
- **File/function:** OpenTitan SPI agent sequence files, `spi_device_env_cov.sv:123`, and `spi_device_pass_base_vseq.sv:548`; compiler diagnostics in the selected result.
- **Possible clause:** IEEE 1800-2017/2023 foreach scoping, covergroup bin typing, and indexed expression semantics; root causes remain to be separated.
- **Evidence:** `evidence/opentitan-matrix-smoke-selection-20260929/selected-result.json` and the selected compile log path recorded there.
- **Reproducer status:** selected pinned-source compile and runtime; no minimal reducer for these five notices yet.
- **Triage status:** record-only under the harness ticket. Preserve the SPI Device DEBT verdict until each semantic notice is resolved or justified.

### DD-099 — Entropy Source UVM real-field macro passes 4096 bits to `$bitstoreal`

- **Discovered while working:** OT-CSRNG-PACKED-CLASS-PROPERTY-INDEX, during the frozen 49-target census.
- **Observation:** The official Entropy Source smoke stops at two `$bitstoreal` calls on a 4096-bit UVM bitstream. A disposable one-line UVM macro patch selects bits `[63:0]` and removes both errors, but does not make the DV target pass.
- **File/function:** Pinned UVM 1.2 `uvm_object_defines.svh:999`, `UVM_SETINT`; Icarus `vpi/sys_convert.c:166` enforces exactly 64 bits.
- **Possible clause:** IEEE 1800-2017/2023 §20.5 defines `$bitstoreal` on a real bit pattern; wider-argument behavior is not explicit in the checked wording.
- **Evidence:** `/private/tmp/ot-entropy-bitstoreal-selected-20260929/HANDOFF.md`, paired reducer and hash-guarded selected replay.
- **Reproducer status:** confirmed; selected patch removes the specific error on the same installed image.
- **Triage status:** untriaged source-compatibility correction; do not count Entropy Source as passing.

### DD-100 — Entropy Source event-sensitive `ref` binding stops selected replay

- **Discovered while working:** OT-CSRNG-PACKED-CLASS-PROPERTY-INDEX, after the isolated DD-099 source correction.
- **Observation:** With the wide `$bitstoreal` arguments corrected, selected runtime reaches `event-sensitive ref binding has an unsupported non-integral whole-variable actual` and fails. Four pre-existing covergroup width warnings also remain.
- **File/function:** Icarus `vvp_net_sig.cc` event-sensitive reference binding; exact OpenTitan call site is in the selected runtime log.
- **Possible clause:** IEEE 1800-2017/2023 `ref` actual binding and lifetime; exact subclause pending.
- **Evidence:** `/private/tmp/ot-entropy-bitstoreal-selected-20260929/HANDOFF.md` and selected result.
- **Reproducer status:** selected application replay; no minimal compiler reducer yet.
- **Triage status:** untriaged. Keep Entropy Source RUNTIME_FAIL.

### DD-101 — OTBN smoke runner omits the required pre-run ELF mode

- **Discovered while working:** OT-CSRNG-PACKED-CLASS-PROPERTY-INDEX, during the frozen 49-target census.
- **Observation:** Census11 showed that the runner recorded OpenTitan's `build_otbn_smoke_binary_mode` but did not execute it or supply `+otbn_elf_dir`, so OTBN failed at time zero. The runner now executes that pre-run mode and supplies the generated ELF directory. A hash-guarded final trace check also clears DD-097 for the selected target.
- **File/function:** `scripts/opentitan_matrix.py` runtime option resolution; pinned `otbn_sim_cfg.hjson` pre-run mode.
- **Possible clause:** N/A; application setup and later TLUL protocol assertion.
- **Evidence:** [focused runner result and copied logs](../../evidence/opentitan-census-20261002/otbn-auto-prerun-focus/); earlier replay: `/private/tmp/otbn-smoke-selected-20260929/HANDOFF.md`.
- **Reproducer status:** confirmed in the corpus and one guarded selected replay.
- **Triage status:** UPDATE 2026-10-02: `scripts/opentitan_matrix.py` now runs the pinned `gen-binaries.py` pre-run for this exact smoke, uses xPack RV32 `as`/`ld` from `RV32_TOOL_AS`/`RV32_TOOL_LD`, supplies the generated directory as `+otbn_elf_dir`, and sets `REPO_TOP`. The generated ELF hash is `e47c6d70669a8b2837e8476b6e3ca1eeaadb98b62bab87321a0ce698348cb827`. A hash-guarded final trace check resolves DD-097. The selected 102.1-second matrix run returns zero and is PASS with zero actionable setup warnings, semantic debt, runtime errors, or runtime debt. The earlier TLUL `noOutstandingReqsAtEndOfSim_A` failure no longer reproduces. This is selected evidence, not a refreshed 49-target census. Never substitute a dummy ELF.

### DD-102 — Pwrmgr parallel runner exception before simulator launch

- **Discovered while working:** OT-CSRNG-PACKED-CLASS-PROPERTY-INDEX, during the frozen 49-target census.
- **Observation:** FuseSoC setup and Icarus compilation complete, then the parallel worker reports `[Errno 1] Operation not permitted` before recording a runtime command or log. The exact failed syscall is unconfirmed; this row is `MATRIX_ERROR`, not a DV verdict.
- **File/function:** `scripts/opentitan_matrix.py` runtime launch after compile; the concurrent worker exception is caught at `future.result()`.
- **Possible clause:** N/A; macOS runner/process-launch reliability.
- **Evidence:** `/private/tmp/ot-corpus-after-fixes-20260929/result-final.json` pwrmgr row and its `work-final/runtime/lowrisc_dv_pwrmgr_sim_0.1/` setup/compile logs. The earlier raw census ran Pwrmgr and failed `EscClkStopEscTimeout_A`.
- **Reproducer status:** one parallel-run exception; a single-core same-image replay is pending after the corpus finishes.
- **Triage status:** untriaged. Do not count Pwrmgr as PASS based on successful compilation or on a prior separate checker-patched DEBT result.

### DD-103 — exact clipping for a dynamic inner packed class-property range

- **Issue status:** [OPEN #495](https://github.com/dsellerbrock/iverilog-uvm/issues/495).

- **Discovered while working:** OT-CSRNG-PACKED-CLASS-PROPERTY-INDEX.
- **Observation:** Flattening `property[outer][base +: width]` into an absolute offset can alias the neighboring outer element when the inner range crosses its declared dimension. Rejecting every dynamic base also rejects valid bounded byte selectors. The validated CSRNG fix admits ranges proven wholly inside the inner dimension, including the existing dynamic UVM nested-slice control; unproven crossing ranges remain explicit compile errors.
- **File/function:** `netmisc.cc::check_packed_property_tail_range`; class-property RMW in `tgt-vvp/stmt_assign.c`. Ordinary signal lvalues already use `NetAssign_::set_dynamic_part_carrier` and `%clip/vec4/d`, but class-property blocking, compound, and nonblocking stores need their own preserved carrier and evaluation order.
- **Possible clause:** IEEE 1800-2017 and 1800-2023 §11.5.1: a partly out-of-bounds read fills only missing bits with X; a write updates only in-range bits. An all-or-nothing runtime guard is insufficient.
- **Evidence/reproducer:** Paired `ivtest/ivltests/sv_class_packed_property_2d_range_invalid.v` and `sv_class_packed_property_dynamic_slice_cross.v` reject aliases; paired `sv_class_packed_property_dynamic_nested_slice.v`, `sv_class_packed_property_dynamic_range_width.v`, `sv_class_packed_property_narrow_cast_cross.v`, and `sv_class_packed_property_ascending_dynamic_slice.v` cover bounded, width, truncation, and direction cases. The existing `tests/class_packed_dynamic_nested_slice_test.sv` passes again. The exact final gates and selected CSRNG result are under `evidence/opentitan-csrng-packed-property-20260929/`.
- **Triage status:** Open, record-only beyond the validated bounded subset. Exact carrier clipping for arbitrary runtime bases needs a separate target/read-lowering ticket with single-evaluation, ascending/descending, partial-overlap, blocking/compound/NBA, and X/Z controls. Do not count the selected CSRNG PASS as qualification of partial-overlap behavior.

### DD-104 — procedural `$past` history captures the Active-region value, not the Preponed value

- **Issue status:** [OPEN #496](https://github.com/dsellerbrock/iverilog-uvm/issues/496).

- **Discovered while working:** OpenTitan hmac same-event wake-order fix (FIFO waiters), via `sv_sampled_value_procedural`.
- **Observation:** The generated sampler process (`pform_make_sampled_history_process_`) shifts `hist <= expr` under NBA, but `expr` is evaluated when the sampler thread runs in the Active region. A writer that shares the sampling edge and runs first is therefore captured; one that runs later is not. With the writer first, `$past(d)` at the 4th negedge answers 3, IEEE 1800-2017 16.5.1 / 16.9.3 (Preponed sampling) says 2.
- **File/function:** `pform.cc` `pform_make_sampled_history_process_`, `sva_rewrite_sampled_`.
- **Evidence/reproducer:** `/tmp`-style probe: `always @(negedge clk) begin k++; d = k; end` declared before `always @(negedge clk) $display($past(d))` prints `d-1` instead of `d-2`. After the FIFO wake-order change the reader-first form of the existing test happens to give the Preponed answer, so the test now expects 2; the writer-first order remains wrong.
- **Triage status:** locally qualified on `agent/ieee-procedural-past-preponed-20261007`. Shared capture/history-enable helpers wrap supported static operands through the existing `$ivl_clocking_sample` path for inferred-edge, explicit-event, and default-clocking routes, enabling signal history before the first edge. A simple direct automatic local stays in the reader and uses its current value; unsupported direct automatic call shapes diagnose, and a compound automatic local fails elaboration rather than escaping into the detached sampler. Clocking-input operands are explicitly diagnosed and covered by paired compile-error tests. The writer-first 2017/2023 regression and related controls pass 5/5 legacy rows and 10/10 strict JSON/VVP checks, including expected compile errors. See [DD-104 evidence](../../evidence/procedural-past-preponed-20261007/README.md). This does not close clause 16 or qualify arbitrary automatic, clocking-input, or expression shapes.

### DD-105 — fixed-array assignment patterns reach the VVP vector evaluator

**Census disposition (2026-10-08):** No issue filed. The five named registered cases compile with exit 0 and without the reported `kind 26` diagnostic on the clean `origin/main` install at `af89cfc50be1084cc86c48865f3f6ba78d4512fa`; the paired `sv_array_packed_select_incdec_scopes` case was compiled under both editions. The PR #411-head failure is not reproducible; runtime/output behavior was not rechecked, so this disposition covers only the reported compile-time failure.


- **Discovered while working:** SV23-CLASS-FINAL, while reviewing PR #411's replayed conformance gate.
- **Observation:** Registered assignment-pattern cases emit `this expression (kind 26) cannot be evaluated in a vector context` during VVP code generation. The affected cases are `sv_default_assign_pattern` (source lines 44 and 102), `sv_uarray_slice_pattern_assign` (67), `sv_byte_array_string` (17), `sv_array_packed_select_incdec_scopes` (17 under both editions), and `sv_assignment_pattern_keys_replication` (26). The fixtures are unchanged by PR #411; this is not a demonstrated class-final regression.
- **File/function:** `tgt-vvp/stmt_assign.c::draw_array_pattern` and `tgt-vvp/eval_vec4.c::draw_eval_vec4_core_`; the exact dispatch that sends these patterns to vector evaluation remains untriaged.
- **Possible clause:** IEEE 1800-2017/2023 §§7.6 and 10.9; verify exact applicable requirements during triage.
- **Historical evidence:** Replay logs at `/tmp/pr409-repro-logs2/` for the five named cases, generated at PR #411 head `32cfc8dcc5c670e5fcd7f7ed7f53838310a26b33`.
- **Current-main recheck:** The reported compile diagnostic is not reproducible; all five case names compile successfully, including the paired `sv_array_packed_select_incdec_scopes` runs. No runtime/output replay was performed.
- **Triage status:** Excluded as a current compile-time gap. Keep separate from the adjacent whole-unpacked-struct-array representation diagnostic; do not widen PR #411.

### DD-106 — package-qualified class call probe cases (a)-(e)

- **Issue status:** [OPEN #497](https://github.com/dsellerbrock/iverilog-uvm/issues/497).

- **Discovered while working:** SV-PACKAGE-CLASS-STATIC-CALL.
- **Observation:** Before the active fix, probes (a) `x = p::c::get()`, (b)
  `void'(p::c::get())`, (c) `p::c#(8)::set(1)`, (d) non-static
  `p::c::m()`, and (e) nonexistent-class `p::missing::set(1)` all failed in
  parsing with `syntax error` / `Malformed statement` under strict 2017 and
  2023. After the statement-call fix, (b) and (c) pass in both editions, (d)
  reports the focused non-static-method diagnostic, and (e) reports an unknown
  task/class diagnostic without crashing. The reducer passes and prints
  `v=5`; (a) still fails in expression position. Extending the raw carrier into
  `expr_primary` increased Bison conflicts, so that grammar change was reverted
  and (a) remains outside this ticket.
- **File/function:** Parser grammar for package-qualified class-scope call
  statements; elaboration diagnostics for the negative forms.
- **Possible clause:** IEEE 1800-2017/2023 §§8.23 and 26.3.
- **Evidence:** Pre/post-patch probes compiled with the active worktree's
  `local-install/bin/iverilog` and executed with its `local-install/bin/vvp`;
  permanent reducer and non-static logs are in `ivtest/log/`.
- **Reproducer status:** Confirmed on the clean baseline.
- **Triage status:** Triage-pending, record-only. Cases (a)-(e) are probes for
  the active fix, not separately authorized blockers; retain the post-fix
  result here and promote none from this entry without coordinator selection.

### DD-107 — unequal-length SVA negative case leaves Linux CI red

- **Discovered while working:** SV-PACKAGE-CLASS-STATIC-CALL; during review of
  merged SVA intersect support and its later package-call CI run.
- **Observation:** PR #412 merged at `7c4aa26e`. Its Ubuntu 22.04 job
  `112981302851` (workflow `37676515427`) failed the hard gate; the job log
  reports the negative suite at 152 passed / 1 failed. PR #413 merged at
  `af89cfc50`, but its Ubuntu 22.04 job `113118218660` and Ubuntu 24.04 job
  `113118218666` in workflow `37717798761` also failed the negative suite at
  152/153. The legacy sweep on those PR #413 jobs reports 7,243 total, 7,238
  passed, 0 failed, 2 not implemented, 3 expected failures, and a clean name
  diff; the bundled VPI suite passes 131/131. The workflow was still running
  on macOS, MINGW64, and CLANG64 when captured, so no all-platform result is
  claimed. PR #467 on issue #460 repeated the failure on Ubuntu 22.04 job
  `113303751524` and Ubuntu 24.04 job `113303751404` (workflow
  `37775071993`): both report 152/153 negative tests, while the legacy
  name-diff gate is clean and bundled VPI passes 131/131. A local replay on
  the #460 worktree identifies the sole case as `m9b_intersect_unequal_len`;
  the CI logs report the count but do not name that case. At the last snapshot,
  macOS was queued and the three Windows jobs were still in progress. PR #466
  (issue #450) repeats the same 152/153 negative-suite failure on Ubuntu 22.04
  and 24.04 in run `37767274293`; the logs show the legacy suite and name-diff
  gate pass, then the negative gate fails. A local replay identifies
  `m9b_intersect_unequal_len` as the sole failure.
- **Local identification:** The available source-built compiler's negative
  runner reports its sole failure as `m9b_intersect_unequal_len`. That fixture
  asserts unequal-length SVA `intersect` operands must be rejected. The PR #412
  log exposes the same suite count but only prints its final five lines, so the
  identity of its earlier failing test is not independently confirmed.
- **Scope:** The failing fixture concerns SVA intersect semantics and predates
  package-call PR #413. PR #413 does not modify the fixture or negative runner;
  it adds a package-qualified class static-call grammar continuation and paired
  tests. Treat this as unrelated to the package-call ticket.
- **Evidence:** [PR #412](https://github.com/dsellerbrock/iverilog-uvm/pull/412),
  workflow `37676515427`; [PR #413](https://github.com/dsellerbrock/iverilog-uvm/pull/413),
  workflow `37717798761`; direct job logs and a local `tests/negative/run_negative.sh`
  replay.
- **Correction:** The fixture now carries `NEG-LEGACY-ONLY` on PR #467. The default NFA
  accepts the legal form; `IVL_SVA_LEGACY=1` preserves the explicit unsupported-
  lowering diagnostic. The full negative suite passes locally, 153/153.
- **Triage status:** The correction is on main-based PR #467. Consult that PR
  for current exact-head CI status; do not claim the hard gate
  qualified until that exact-head run passes. PR #466 remains on its earlier
  failed head and should be reassessed after the shared correction is validated.

### DD-108 — PR #411 Ubuntu 24.04 check failed after merge

- **Discovered while working:** SV-PACKAGE-CLASS-STATIC-CALL.
- **Observation:** GitHub reports PR #411 merged at `32cfc8d` on 2026-10-07.
  Its workflow `37659524348` has an Ubuntu 24.04 failure (job
  `112923171077`, completed 2026-10-08 00:33 UTC); macOS, Ubuntu 22.04,
  MINGW64, UCRT64, and CLANG64 remain queued.
- **Scope:** This is the already-merged IEEE 1800-2023 class `:final` change,
  not the package-qualified class-call patch in this ticket.
- **Evidence:** [PR #411 check rollup](https://github.com/dsellerbrock/iverilog-uvm/pull/411)
  and workflow run `37659524348`, job `112923171077`.
- **Triage status:** Triage-pending. Do not claim PR #411 CI is green. Inspect
  the completed workflow log and select any repair separately.

### DD-109 — wide packed-struct constraint state is silently accepted

- **Issue status:** [OPEN existing issue #421](https://github.com/dsellerbrock/iverilog-uvm/issues/421).

- **Discovered while working:** SV-PACKAGE-CLASS-STATIC-CALL, during the full
  JSON ivtest gate.
- **Observation:** `sv_constraint_state_packed_select_invalid_2017` and its
  2023 counterpart fail. The fixture expects an unsupported wide packed-struct
  state select in a constraint to fail closed, but `wide_state.randomize()`
  returns success and triggers the fatal at source line 37. The same run
  diagnoses the separate four-state `struct_state` case at line 20.
- **File/function:** `ivtest/ivltests/sv_constraint_state_packed_select_invalid.sv:20,25,37`;
  exact solver path not yet isolated.
- **Possible clause:** IEEE 1800-2017/2023 §18.3.
- **Evidence:** Full JSON run on this ticket's branch: 4,499 tests, 4 failed;
  both edition logs show the line-37 fatal and omit the expected wide-state
  diagnostic.
- **Reproducer status:** Confirmed in both editions by the registered fixture.
- **Triage status:** Current-main recheck (2026-10-09) passes the paired JSON/VVP fixtures 2/2. The source intentionally checks a 65-bit selected packed-struct state bit succeeds when true and fails when constrained false; only the four-state invalid reads diagnose. This DD-109 report is stale and is not a current #421 reproducer. The separate in-range symbolic nested packed-array selection still fails and is tracked in the active #421 slice.

### DD-110 — registered global-uniform tests exceed the guarded run budget

**Census disposition (2026-10-08):** no semantic mismatch was measured; this is a host runtime-budget observation, not a confirmed IEEE result defect.


- **Discovered while working:** SV-PACKAGE-CLASS-STATIC-CALL, during the full
  JSON ivtest gate.
- **Observation:** `sv_randomize_global_uniform` and
  `sv_randomize_global_uniform_2023` produced empty VVP output instead of the
  expected `PASSED` gold under the 300-second per-process CPU guard. The
  guarded run reached the resource limit on each statistical test.
- **File/function:** `ivtest/ivltests/sv_randomize_global_uniform.v` and
  `sv_randomize_global_uniform_2023.v`; runtime duration in the global uniform
  sampler.
- **Possible clause:** IEEE 1800-2017 §18.5.10 / IEEE 1800-2023 §18.5.9.
- **Evidence:** Full JSON run on this ticket's branch: 4,499 tests, 4 failed;
  the two uniform tests have empty VVP stdout/stderr and no expected pass
  marker. An earlier unguarded attempt was manually stopped after exceeding
  the same CPU budget.
- **Reproducer status:** Confirmed as a bounded-runtime failure on this host;
  no distribution mismatch was measured in this run.
- **Triage status:** Triage-pending, unrelated to the package-call parser
  change. Do not expand the active ticket to optimize the solver.

### DD-111 — axi-vip constraint calls an impure width helper

- **Discovered while working:** SV-PACKAGE-CLASS-STATIC-CALL, in the required
  read-only axi-vip compile at revision
  `16d0f444299014b2079c941925ea8b43d85a13f7`.
- **Observation:** After the package-qualified static-call parser fix, the
  compile advances beyond `axi_base_test.sv:53`. The next diagnostic is that
  `get_width` is not pure when called from constraints at
  `common/sim/vip_lib/axi_uvc/axi_trans.svh:40-41`.
- **Evidence:** From the external axi-vip checkout root, ran
  `iverilog -uvm -g2012 -s axi_tb_top -o /private/tmp/axi-pkg-class-static-call-20261007.vvp -f axi.f`
  using this worktree's compiler. This entry records only the next diagnostic;
  subsequent output is intentionally not triaged here.
- **Triage status:** Triage-pending, record-only. Do not continue the axi-vip
  compile chain from this observation.

### DD-112 — two-state packed bit-select OOB returns X

- **Discovered while working:** IEEE-PACKED-MULTIDIM-SELECT-OOB (#414), while
  checking the result-type wording of IEEE 1800-2017/2023 §11.5.1.
- **Observation:** `bit [7:0] value; integer index; value = '1; index = 8;`
  followed by `$display("%b", value[index])` prints `x`; §11.5.1 requires an
  invalid select to return 0 for a two-state value. The same one-dimensional
  direct-select path remains unchanged by #414's checked multidimensional
  prefix fix.
- **Reproducer:** `/tmp/sv_one_dim_bit_oob.sv`; current local ARM64 image prints
  `one_dim_oob=x`.
- **Triage status:** Triage-pending, separate from #414's four-state alias
  failure; do not expand the multidimensional fix to change one-dimensional
  result typing.

### DD-113 — selected VIF real-index diagnostic changed in packed-property lowering

- **Discovered while working:** SV23-REF-STATIC-TF-ARGUMENTS (#449), during the
  full legacy ivtest run.
- **Observation:** `sv_selected_vif_edge_invalid_real_index_2017` and its 2023
  counterpart fail only because their gold expects `real expression cannot
  index a property`, while the compiler now reports `index expression must be
  integral`. Both still emit the expected skipped-event warning and one
  elaboration error.
- **File/function:** `ivtest/ivltests/sv_selected_vif_edge_invalid_real_index_2017.v`,
  `..._2023.v`, and their stderr golds.
- **Possible clause:** N/A; diagnostic wording/gold maintenance.
- **Evidence:** Full legacy report at `ivtest/regression_report.txt` lines
  6295–6296 and output diffs in `ivtest/log/`.
- **Reproducer status:** Confirmed in both editions; the full runner reports
  only a gold mismatch.
- **Follow-up:** The packed-property selector now carries property-index
  context to the shared checker, preserving the historical property-specific
  error while direct packed-signal indices retain the integral-type error.
  Both VIF cases pass in legacy (2/2) and JSON/VVP (2/2) on the updated local
  image; their gold files are unchanged.
- **Triage status:** Locally resolved in PR #464; exact-head CI is pending.

### DD-114 — `sv_always_comb_fixed_point` spins in zero time

- **Discovered while working:** SV23-REF-STATIC-TF-ARGUMENTS (#449), during the
  full JSON/VVP ivtest run.
- **Observation:** The test's initial block waits one time unit, prints
  `PASSED`, and calls `$finish`, but VVP remained CPU-active in the test for
  more than five minutes with no output. The run was stopped; the full JSON
  runner did not produce an aggregate result.
- **File/function:** `ivtest/ivltests/sv_always_comb_fixed_point.v`; two
  `always_comb` blocks assign and then restore each other's values.
- **Possible clause:** Verify during triage; this is a zero-time convergence
  failure.
- **Evidence:** Full JSON run on 2026-10-08 reached this registered test at
  `ivtest/regress-vvp.list` line 1607. `vvp work/a.out` stayed CPU-active with
  under 3 MB RSS and an empty VVP output log until explicitly stopped; the
  Python runner exited 143 after termination.
- **Reproducer status:** Confirmed on the local macOS ARM64 image.
- **Triage status:** Triage-pending, unrelated to `ref static`; do not expand
  this ticket to change event scheduling or add runner timeouts.

### DD-115 — obsolete negative expected unequal-length `intersect` rejection (resolved)

- **Discovered while working:** SV23-REF-STATIC-TF-ARGUMENTS (#449), while
  investigating Ubuntu hard-gate failures.
- **Observation:** The old negative expected `(a ##1 b) intersect c` to be
  rejected. IEEE 1800-2017/2023 §16.9.6 defines a match only when both operands
  end on the same tick; unequal fixed-length operands are legal and produce no
  match.
- **Resolution:** Removed the obsolete negative. The same behavior already has
  a positive runtime regression in
  `ivtest/ivltests/sv_assert_intersect_unequal_lengths.v`, registered for strict
  2017 and 2023 runs.
- **Evidence:** PR #515 Ubuntu 22.04/24.04 run 37890533641 and the local negative
  suite exposed the obsolete test. The positive strict-edition regressions cover
  the legal empty-match result.
- **Triage status:** Resolved. Variable or ranged-length mismatches remain
  outside that regression's scope.

### DD-116 — constraint-state packed struct select fails in full JSON sweep

- **Discovered while working:** IEEE-1800-ASSOC-ARRAY-TYPED-PARAMETERS (#450),
  during the full JSON ivtest run.
- **Observation:** `sv_constraint_state_packed_select_invalid_2017` and
  `_2023` both exit with a VVP error. The expected `PASSED` line is replaced by
  a fatal at `wide_state.flags[64]`; the compiler also omits the expected
  warning/error for the line-25 constraint. The associative parameter patch
  does not change the packed-struct constraint path exercised here.
- **Evidence:** Full JSON run: 4,503 tests, 4 failures. A targeted rerun of
  those two cases reproduced both failures after installing the missing
  optional FPGA target; the two FPGA rejection cases then passed. The full-run
  constraint diffs are in `ivtest/log/` and identify the failing `wide_state`
  case.
- **Reproducer status:** Reproduced on the current candidate; baseline status
  has not been checked.
- **Triage status:** Triage-pending and outside #450 scope. No constraint
  solver changes are included.
- **Resolution (2026-10-09, agent/sim-perf-hotspots-20261009):** stale
  expectation, not a runtime defect. The 65-bit two-state struct state is now
  supported: `flags[64] == 1'b1` with `flags[64]` set is satisfiable, so
  `randomize()` must succeed (IEEE 1800-2017 18.3). The test now expects that
  and adds `flags[64] == 1'b0`, which must fail, so a dropped constraint would
  still be caught. Both editions pass in the JSON runner.

### DD-117 — legacy/JSON expectations drift for real-valued coverpoint tests

- **Discovered while working:** IEEE-UNPACKED-ARRAY-OUTPUT-SLICE (#492), while
  reviewing CI failures reported after PR #466 merged.
- **Observation:** The Ubuntu 22.04 and 24.04 jobs in run 37947939833 failed the
  hard ivtest gate on `sv_covergroup_bitwise_real_operand_unsupported` and its
  2023 variant. Focused legacy and JSON/VVP runs each reproduced 2/2 failures.
- **Cause:** The 2017 case was registered as a normal pass although `-g2017`
  rejects real-valued coverpoint bins. The 2023 legacy gold mixed a compiler
  diagnostic with runtime output, and the default JSON invocation expected
  compiler stderr that it does not emit.
- **Repair:** Issue #522 removes the invalid 2017 normal-test registrations,
  retains the existing 2017 compile-error feature-boundary case in the focused
  lists, limits the unsupported-operand case to 2023, and aligns the legacy and
  JSON stream golds with their actual outputs. Focused legacy and JSON/VVP
  lists pass 10/10 each; the strict 2017/2023 pair passes 2/2. The full hard
  gate was stopped with exit 143 after 16 minutes while
  `sv_randomize_global_uniform` was still consuming CPU; it has no aggregate
  result. PR CI has not yet verified the repair.
- **Status:** Repair is pending review in draft PR #523. Do not call it
  CI-qualified until all required checks pass on that exact PR head.
- **Follow-up (2026-10-09, agent/sim-perf-hotspots-20261009):** the 2023
  case's silence was a compiler regression, not a gold drift: the
  compiler at f3f394f3 emitted the `sorry: ... the bin is dropped` line, and the
  test states the real bitwise operand must not make the bin legal. The
  coverpoint now counts as real only for `+ - * / **` (elaborate.cc), which
  restores that diagnostic, and the two golds are restored to their pre-#523
  content. Covergroup tests pass 236/236 legacy and 215/215 JSON.

### DD-118 — `%disable/flow` name fallback compares one shared VPI buffer

- **Discovered while working:** simulation-performance hotspot survey
  (2026-10-09), while checking `vpi_get_str` calls on hot paths.
- **Observation:** `of_DISABLE_FLOW` keeps `target_name`, `thr_name`, and each
  `cur_name` from `vpi_get_str(vpiFullName, ...)`. Those calls return the same
  static `RBUF_STR` buffer (`need_result_buf` in `vvp/vpi_signal.cc`), so the
  later calls overwrite `target_name` and `strcmp(cur_name, target_name)` always
  compares the buffer with itself. When no ancestor matches the target scope
  pointer, the fallback selects the first ancestor that has a scope instead of
  one with a matching name.
- **File/function:** `vvp/vthread.cc`, `of_DISABLE_FLOW`.
- **Possible clause:** IEEE 1800-2017/2023 §9.6.2 (`disable`), only if the
  pointer match can fail for a legal disable target.
- **Evidence:** Source read; `scope_get_str` returns `simple_set_rbuf_str(p)`.
- **Reproducer status:** the shared buffer is confirmed through
  `IVL_FLOW_TRACE=1`, which printed the same name for source, target and
  selected thread; no design was found that reaches the name fallback.
- **Triage status:** fixed on agent/sim-perf-hotspots-20261009. Both
  `%disable/flow` opcodes keep owned name copies (built only when needed),
  so the fallback compares real names and the trace prints distinct names.

### DD-119 — typed mailbox rejects a derived class handle

- **Discovered while working:** simulation-performance hotspot survey
  (2026-10-09), while writing a class/mailbox benchmark.
- **Observation:** `mailbox #(txn) mb; btxn t = new(i); mb.put(t);` with
  `class btxn extends txn` fails elaboration: "Typed mailbox method `put'
  argument must have a type equivalent to the mailbox message type". The
  benchmark was changed to assign the handle to a `txn` variable first.
- **File/function:** `elaborate.cc` typed-mailbox method check
  (`mailbox_message_type_equivalent`).
- **Possible clause:** IEEE 1800-2017/2023 §15.4.9. Verify during triage whether
  the clause requires type equivalence or assignment compatibility for `put`.
- **Evidence:** `benchmarks/sim-hotspots/classq.sv` before the workaround.
- **Reproducer status:** confirmed (three-line reducer above).
- **Triage status:** resolved as a compatibility option (2026-10-09). The
  default mode keeps IEEE behavior: §15.4.9 says the compiler verifies that
  put, try_put, peek, try_peek, get and try_get use argument types
  *equivalent* to the mailbox type, as the registered
  `sv_typed_mailbox_{statement,expression}_type_fail` tests pin. Under
  `-gcommercial-unsafe`, put/try_put accept what commercial simulators accept
  for that input argument: null or a handle of the message class or a
  subclass, and integral/real values converted to an integral/real message
  type. get/peek keep requiring equivalence (ref arguments). Pinned by
  `sv_typed_mailbox_put_assignable_unsafe{,_2023}` and its `_fail` CE pair.
  Re-check the §15.4.9 sentence against the local PDF.

### DD-120 — string variable assigned to an integral target without a cast

- **Discovered while working:** DD-119 investigation (2026-10-09).
- **Observation:** `int i; string s; i = s;` and passing `s` to a function
  `int` input both elaborate without a diagnostic in -g2017.
- **File/function:** `elaborate_rval_expr` (elab_expr.cc) type checking.
- **Possible clause:** IEEE 1800-2017/2023 §6.16 and §6.24 (casting). Verify
  against the PDF whether string-to-integral assignment requires a cast
  before changing behavior.
- **Evidence:** reducer above, compiled with the current `ivl`.
- **Reproducer status:** confirmed.
- **Triage status:** untriaged; clause text not available in this session.

### DD-121 — coupled wide rand variables are sampled by XOR distance, not uniformly

- **Discovered while working:** simulation-performance hotspot survey, Z3 path
  (2026-10-09).
- **Observation:** A rand integral variable whose legal set is too large to
  enumerate gets its value from Z3 `optimize` minimizing `var ^ target` for a
  random target. That favors values bordering large illegal gaps: for
  `x inside {0, [32'h1000:32'h1FFF]}` it chose `x == 0` in 208 of 400 draws
  (uniform: about 0.1). The same branch now uses the exact interval sampler
  when the variable is an isolated factor; variables whose constraints also
  mention another free variable (for example `addr + len <= LIMIT`) still take
  the XOR path.
- **File/function:** `vvp/vvp_z3.cc`, `z3_minimize_diversity_` call sites in
  `z3_solve_pass_`.
- **Possible clause:** IEEE 1800-2017 §18.5.10 / 1800-2023 §18.5.9 (uniform
  distribution over legal value combinations).
- **Evidence:** `ivtest/ivltests/sv_randomize_isolated_wide_uniform.v` fails on
  the pre-fix runtime (`zeros=208`).
- **Reproducer status:** confirmed for the isolated case (fixed); coupled case
  by source read.
- **Triage status:** isolated case fixed on agent/sim-perf-hotspots-20261009;
  coupled case needs exact joint sampling and is open.

### DD-122 — rounded-to-zero time literals have no diagnostic

- **Discovered while working:** M6 issue #545 triage (2026-10-16).
- **Observation:** With no `timescale` or `timeunit`, Icarus's documented
  default is `1s/1s`. A standalone `#5ns` then reports `$time == 0` and
  `$realtime == 0.0` without a rounding warning. In an `always` clock loop,
  the compiler reports that the process has no delay and will loop forever.
- **File/function:** `pform.cc:pform_set_scope_timescale` selects default
  precision; `netmisc.cc:get_scaled_time_from_real` scales and rounds delay
  values without reporting a nonzero value rounded to zero.
- **Possible clause:** IEEE 1800-2017/2023 §§3.14.1, 3.14.2.3, 5.8, and 9.4.5.
- **Evidence:** Main `7f508a8a`; local Mac test matrix and zero-time probe in
  `~/codex-supervisor/evidence/a3-m6-issue545-current-main-20261016/`.
- **Reproducer status:** Confirmed; the same reducer passes with
  `` `timescale 1ns/1ps`` in both editions.
- **Triage status:** Open, diagnostic-quality follow-up. No simulator change
  is included in #545; the source must specify its intended time scale.

### DD-123 — side-effecting covergroup iff guard is treated as enabled

- **Discovered while working:** #448 / PR #594 (2026-10-15).
- **Observation:** Sampling a coverpoint with `iff (value++)` on a covergroup
  `ref` formal emits `coverpoint iff guard cannot be evaluated at this
  sample() site; the guard is treated as enabled.` The guard therefore does
  not control sampling. Whether this expression is permitted by the LRM's
  coverage-expression rules has not been fully checked.
- **File/function:** generated coverpoint `iff` evaluation; source location
  not yet identified.
- **Possible clause:** IEEE 1800-2017/2023 §19.5.
- **Evidence:** `evidence/a3-m5-issue448-followup/job1376/logs/ref2017.log`.
- **Reproducer status:** confirmed for the 2017 mode.
- **Triage status:** untriaged; outside #594.

### DD-124 — caller-scope name can capture a covergroup guard

- **Discovered while working:** #457 embedded covergroup inheritance.
- **Observation:** Sample-site elaboration evaluates a stored covergroup guard
  in the caller's scope before falling back to a property on the covergroup's
  static parent type. An unrelated caller-scope identifier with the same name
  could therefore capture the guard instead of the declaring class property.
- **File/function:** `elaborate.cc`, generated `sample()` argument construction
  for coverpoint, cross, and bin guards.
- **Possible clause:** IEEE 1800-2023 §19.4.1; lexical binding is inferred from
  inheritance semantics and is not stated explicitly in that clause.
- **Evidence:** source review of the generated sample-site evaluation path;
  no isolated runtime reproducer was run.
- **Reproducer status:** sketched; not confirmed.
- **Triage status:** untriaged, recorded as pre-existing for all covergroups;
  outside #457.

### DD-125 — shadowed non-property constants are outside covergroup owner checks

- **Discovered while working:** #457 embedded covergroup inheritance.
- **Observation:** The inherited-expression shadow check enumerates class
  properties. A base parameter or enum constant hidden by a derived
  declaration is not visible through the property table and may still bind by
  name in the derived class scope.
- **File/function:** `elab_sig.cc:bind_covergroup_range_expr_` and inherited
  covergroup expression elaboration.
- **Possible clause:** IEEE 1800-2023 §19.4.1; lexical lookup is inferred from
  the inheritance replacement rule, not explicit in that clause.
- **Evidence:** source review of property-index binding; no reducer was run.
- **Reproducer status:** sketched.
- **Triage status:** untriaged; outside #457.

### DD-126 — class-member covergroup sampling events are skipped

- **Discovered while working:** #457 embedded covergroup inheritance.
- **Observation:** A class-embedded covergroup sampling event that names a
  class property, such as `@(posedge clk)` with `clk` declared in the class,
  warns that `clk` cannot bind in `$unit` and skips the event. The inherited
  group has the same failure. An enclosing-module event binds and samples the
  base and derived group instances correctly.
- **File/function:** `elaborate.cc`, `elaborate_standalone_cg_samplers_`
  elaborates event expressions in the enclosing module scope.
- **Possible clause:** IEEE 1800-2017/2023 §19.3.
- **Evidence:** #457 local probe: class-property event compile warnings plus
  missed second-edge coverage; module-event control reports `edge1 b=0.0
  d=0.0` and `edge2 b=50.0 d=50.0`.
- **Reproducer status:** confirmed.
- **Triage status:** untriaged; pre-existing sampler limitation, outside #457.
