# OpenTitan synthesis, SVA, UVM and runtime matrix

The selected 49-target runtime gate now passes on engine `367e4467…`. Its
[aggregate result](../../evidence/opentitan-census-20261002/candidate-runtime-engine-367e-aggregate-20261005/README.md)
combines 48 rows from a serial full run with a focused I2C replay. The replay
fixed a source-overlay staging rejection; the original run and focused result
are preserved unchanged. The older candidate result also passed 49/49 on
engine `890c5b3c…`; see the [engine 890c result](../../evidence/opentitan-census-20261002/candidate-runtime-recheck-20261005/README.md),
[pre-candidate result](../../evidence/opentitan-census-20261002/census18-xpack-runtime-20261005/README.md),
and [replication guide](opentitan_49of49_reproduction.md).

The 49-target runtime gate is not the full OpenTitan DV suite. The latest
scoped 309-row RTL/SVA/UVM census has four board rows excluded by policy and
305 in-scope rows: 188 PASS and 117 dependency-only, with no in-scope compile
failures or debt. The direct unbased-fill range-endpoint fix is
covered by focused regressions and a 35/35 patched UVM recheck on engine
`367e4467…`. The older discovery totals below come from OpenTitan revision
`7a3ad34b6d483f4d1d69ac670ddb1c45f1172e19` and describe a broader inventory.

`scripts/opentitan_matrix.py` is the canonical census driver for the current
OpenTitan closure campaign.  It replaces one-off source lists with a pinned,
machine-readable result for every selected FuseSoC core.

## Clean-source compile census (2026-10-05, engine 367e)

The latest serial compile-only census completed 309 RTL/SVA/UVM rows against
clean OpenTitan commit `a78922f14a8cc20c7ee569f322a04626f2ac6127`. It records
157 PASS, 120 dependency-only, 6 DEBT, 16 FAIL, 7 setup failures, and 3
upstream-invalid rows. The [full result and remaining-row list](../../evidence/opentitan-census-20261002/candidate-engine-367e-compile-census-20261005/README.md)
includes per-lane counts and reproduction details. The 3 RTL hard failures are
Xilinx board tops that need vendor primitives. Thirteen baseline UVM rows
still fail, while the separate [patched UVM lane passes 35/35](../../evidence/opentitan-census-20261002/candidate-patched-uvm-final-20261005/README.md)
on this engine.

The census excludes runtime. The selected 49/49 runtime gate now passes on
engine `367e…`; it is a selected target set, not the full OpenTitan DV suite.
The earlier engine `890c…` compile snapshot recorded 137 PASS, 120
dependency-only, 19 DEBT, 16 FAIL, 7 setup failures, and 10 upstream-invalid;
see the [historical census](../../evidence/opentitan-census-20261002/candidate-census18-pinned-compile-20261005/README.md).
The earlier 31 UVM failure count was a missing-DPI setup artifact and is
superseded.

## Patched-source scoped compile census (2026-10-06)

The initial 309-row run against the reproducible OpenTitan overlay snapshot
recorded 176 PASS, 120 dependency-only, 1 DEBT, 3 FAIL, 7 setup failures, and
2 upstream-invalid; all 35 UVM rows passed. Its raw result is preserved. The
latest [scoped aggregate](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/result-scoped-aggregate.md)
retains all 309 rows. Per project direction, four Xilinx board tops are
`OUT_OF_SCOPE` because Vivado handles those primitives. Current in-scope counts
are 188 PASS and 117 dependency-only, with no FAIL, DEBT, setup-fail, or
upstream-invalid rows. Of the dependency-only rows, 116 are helper cores
compiled through passing parent top levels; `primgen` is generator-only and
exercised by passing parents. Focused Ibex replays use the exact support
library revision pinned by OpenTitan; both `ibex_riscv_compliance` and
`ibex_simple_system_cosim` pass on their declared `sim` targets. The six
previously uncovered standalone providers also pass direct compile replays.
The EnglishBreakfast helpers are dependency-only; the generated
`top_englishbreakfast` passes after a
hash-recorded overlay guards only its simulation path-printing block; and its
Verilator simulation target passes after the runner mirrors its `VERILATOR`
tool define. This is a compile-only result; its C/C++ simulation harness and
runtime memory-image arguments are not executed by Icarus. See
the [Ibex replay](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/ibex-target-profile-replay-20261006/README.md)
and [EnglishBreakfast replay](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/englishbreakfast-rtl-replay-r3-20261006/result.md),
plus the [Verilator follow-up](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/englishbreakfast-rtl-replay-r5-20261006/result.md).
The [generated top replay](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/englishbreakfast-rtl-replay-r6-20261006/result.md)
records the focused pass.
The [Ibex compliance replay](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/ibex-support-replay-r1-20261006/result.md)
uses OpenTitan's exact pinned support library, and the
[simple-system replay](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/ibex-simple-system-cosim-replay-r2-20261006/result.md)
passes its declared `sim` target. The [chip SVA replay](../../evidence/opentitan-census-20261002/candidate-engine-367e-patched-source-compile-census-20261005/chip-earlgrey-sva-replay-r8-20261006/result.md)
applies the chip simulation config's imported `1ns/1ps` default; the mixed
timescale compiler notice remains recorded as benign.
The public Apache-2.0 Xilinx UNISIM models were fetched and resolve the board
primitive references in a focused compile when `glbl` is included as an
elaboration root. Board rows stay excluded under the current policy. The
selected 49/49 runtime gate is separate and already passes on this engine; it
does not claim full OpenTitan DV-suite coverage.

A focused follow-up on engine `367e…` passes the default-image
`top_earlgrey`, `chip_earlgrey_asic`, and `chip_earlgrey_verilator` synthesis
rows with zero semantic debt. It verifies the ROM/OTP defaults and wrapper
parameters, fixes the Verilator wrapper’s multibit signals and bypass wiring,
and gives the Ibex trace locals automatic lifetime. The RTL results are
included in the refreshed census; its `chip_earlgrey_asic` SVA row also now
passes with the declared simulation timescale. See the [default-image pair](../../evidence/opentitan-census-20261002/candidate-memload-synthesis-default-image-20261005/README.md)
and [Verilator row](../../evidence/opentitan-census-20261002/candidate-chip-earlgrey-verilator-compile-20261005/README.md).

The I2C SVA and UVM compile rows also pass on engine `367e…` with the existing
qualified warning-cleanup patch staged as hash-checked build-local overlays.
Both rows are included as passes in the refreshed census; see the
[I2C result](../../evidence/opentitan-census-20261002/candidate-i2c-qualified-warning-cleanup-20261005/README.md).

Four additional SVA rows previously marked `DEBT` now pass after the setup
classifier confirms that warned non-HDL files are not in Icarus's source lists.
The focused [SVA result](../../evidence/opentitan-census-20261002/candidate-sva-setup-classification-20261005/README.md)
is reflected in the refreshed census.

`lowrisc:dv:spi_host_sva:0.1` also passes after a build-local core overlay
removes its reference to an undefined `files_formal` fileset. The original
`files_dv` content remains selected; see the [focused result](../../evidence/opentitan-census-20261002/candidate-spi-host-sva-fileset-20261005/README.md).

The Keccak 2-share FPV row passes on engine `367e…` with a hash-checked,
build-local control model matching the DOM-based DUT. See the
[focused result](../../evidence/opentitan-census-20261002/candidate-keccak-2share-fpv-dom-controller-20261005/README.md).

The Keccak round FPV row also passes on engine `367e…` after its testbench
clear signal was changed to the DUT's `mubi4_t` encoding. See its
[focused result](../../evidence/opentitan-census-20261002/candidate-keccak-round-fpv-mubi4-clear-20261005/README.md).

The `lowrisc:fpv:prim_lfsr_fpv:0.1` row also passes on engine `367e…` after a
hash-checked build-local overlay assigns disjoint vector indices to its
linear and nonlinear LFSR instances. This focused follow-up does not recompute
the census separately; its `PASS` is included in the refreshed 309-row result.
See the [result and patch](../../evidence/opentitan-census-20261002/candidate-prim-lfsr-fpv-disjoint-slots-20261005/README.md).

The `lowrisc:fpv:prim_packer_fpv:0` row also passes on engine `367e…` after a
hash-checked build-local overlay gives each DUT instance separate outputs.
Its `PASS` is included in the refreshed census; see the
[result and patch](../../evidence/opentitan-census-20261002/candidate-prim-packer-fpv-disjoint-outputs-20261005/README.md).

The `lowrisc:fpv:sha3_fpv:0.1` row passes on engine `367e…` after a
hash-checked build-local overlay updates the FPV wrapper to the current DUT
interface and types. Its `PASS` is included in the refreshed census; see the
[result and patch](../../evidence/opentitan-census-20261002/candidate-sha3-fpv-current-interface-20261005/README.md).

The `lowrisc:ip:aes_wrap:1.0` RTL row passes on engine `367e…` after removing a
redundant data-integrity encoder from the wrapper. This focused follow-up does
not need a separate census run; its `PASS` is in the refreshed result. See the
[result and patch](../../evidence/opentitan-census-20261002/candidate-aes-wrap-single-data-integrity-driver-20261005/README.md).

The `lowrisc:fpv:sha3pad_fpv:0.1` SVA row now passes a focused compile with a
hash-checked overlay for the current DUT ports, MuBi controls, and sampled
digest. The pinned source is unchanged, and the frozen census totals were not
recomputed. See the [result and patch](../../evidence/opentitan-census-20261002/candidate-sha3pad-fpv-sampled-mubi-20261005/README.md).

The candidate now propagates the subject width to a direct unbased fill literal
used as a plain `inside` range endpoint. Its strict 2017/2023 regression passes;
the clean pinned OTP row no longer reports that error but remains `FAIL` on
procedural-force diagnostics and coverage-constructor debt. The focused OTP row
passes with zero debt on the reproduced source overlay; see its
[current candidate result](../../evidence/opentitan-census-20261002/candidate-otp-fill-range-20261005/README.md).

The earlier engine `890c…` candidate 49-target runtime lane completed: 33 rows
passed in the first segment and the remaining 16 in a guarded continuation.
The first segment stopped at a 68% free-memory sample under its 70% floor; no completed
row failed. The aggregate confirms exact coverage of the canonical 49 targets
with no duplicate or missing rows. The full result and guard logs are preserved
in the [candidate runtime evidence](../../evidence/opentitan-census-20261002/candidate-runtime-recheck-20261005/README.md).

## Pass criteria

The runner keeps these outcomes distinct:

| Status | Meaning |
|---|---|
| `PASS` | Setup, compile, and (for the runtime lane) execution completed with no hard diagnostic or semantic-degradation warning. |
| `DEBT` | The process exited successfully, but the compiler reported a warning, ignored construct, approximation, fallback, unresolved operation, or other possible semantic loss. This is **not** a conformance pass. |
| `FAIL` | Compilation returned nonzero or emitted a hard error even if its exit status was zero. |
| `DEPENDENCY_ONLY` | The CAPI core is a package/fileset provider with no standalone top. Its sources are covered through runnable parent top-level jobs. |
| `SETUP_*`, `*_TIMEOUT`, `RUNTIME_FAIL`, `MATRIX_ERROR` | The named build, execution, or census infrastructure stage did not complete. |

An exit status of zero is therefore necessary but insufficient.  In
particular, compile-progress stubs, ignored constraints, dropped loop bodies,
unresolved class/interface calls, covergroup fallbacks, altered scheduling, and
unsupported SVA lowering remain visible debt.

FuseSoC's unsigned-core trust-file notice and its legacy-backend migration
notice are explicitly allowlisted because neither changes the selected HDL or
its meaning.  Every other setup warning is retained.  Ambiguous virtual-core
provider selection is a build-integrity/reproducibility finding; it is not by
itself a compiler semantic result.

## Reproducible inputs

Each job pins both of the provider families that otherwise depend on FuseSoC's
selection order:

- `lowrisc:prim_generic:all:0.1`
- `lowrisc:systems:top_earlgrey:0.1`, or
  `lowrisc:systems:top_darjeeling:0.1` for Darjeeling cores

Six pinned Earlgrey-PROD-M6 core files omit direct dependencies used by their
RTL: `prim_mubi.core` misses `lowrisc:prim:flop_2sync`;
`prim_ram_1p_adv.core` misses `lowrisc:prim:mubi`; the Flash and OTP
register-top cores omit register-check, TL-UL, and subregister providers;
`prim_dom_and_2share.core` misses its XOR and flop providers; and
`tlul_lc_gate.core` misses the error-response and secure-anchor providers. The
runner creates build-local core-root overlays, leaves the input checkout
untouched, and records source and overlay hashes in the result JSON. The
focused seven-core regression and dependency list are documented in the
[dependency overlay evidence](../../evidence/opentitan-matrix-source-dependency-overlays-20261004/README.md).

The `rom_ctrl`, default `top_earlgrey`, and default `chip_earlgrey_asic` RTL
rows can use a build-local include overlay for the simulation-only memory-path
plusarg/display. It is enabled only for hash-checked source and verified empty
image defaults, with no parameter override; the optional `$readmemh` branch
stays intact. The runner records source and generated overlay hashes. See the
[ROM controller overlay evidence](../../evidence/opentitan-romctrl-memload-synth-overlay-20261005/README.md)
and the [Earl Grey follow-up](../../evidence/opentitan-census-20261002/candidate-memload-synthesis-default-image-20261005/README.md).

The `top_englishbreakfast` core intentionally has no virtual-core `mapping`
stanza. For English Breakfast jobs, the runner generates a build-local CAPI
mapping core that pins its RACL, AST, flash-register, flash-package, and random
constant providers, then selects that mapping alongside the generic primitive
mapping. This avoids both the Earl Grey provider conflict and FuseSoC's
nondeterministic-provider fallback without modifying the OpenTitan checkout.

The JSON report also records the OpenTitan commit and dirty state, compiler and
FuseSoC versions, exact setup and compile commands, selected top, diagnostics,
durations, log paths, and a hash of compiler output. The compiler fingerprint
includes the driver, the actual `ivl` compiler engine, the VVP target and
runtime, normal and synthesis configurations, installed UVM DPI module, and
installed UVM source tree when present. Hashing only the `iverilog` driver is
insufficient because that binary can remain unchanged when the compiler engine
is rebuilt. A dirty OpenTitan tree is reported rather than modified.

For UVM and runtime jobs, the runner forwards
`-DUVM_REGEX_NO_DPI` only when discovery retained the exact
`+define+UVM_REGEX_NO_DPI` option from the selected dvsim metadata. Earlgrey-
PROD-M6 defines it in `hw/dv/tools/dvsim/common_sim_cfg.hjson`; pinned UVM 1.2
then uses its documented SystemVerilog glob matcher for `uvm_re_match`.
Normal `-uvm` DPI support remains enabled, and the runner does not translate
arbitrary dvsim or VCS build options. RTL, SVA, and UVM metadata without this
option do not receive the define.

The Python interpreter used for FuseSoC API discovery is equally part of the
fingerprint. The runner records its logical virtual-environment path, real
executable, SHA-256, Python version, imported FuseSoC version, and HJSON version
when simulation metadata is read. It rejects a FuseSoC executable/Python
package version mismatch. By default it checks an adjacent virtual-environment
interpreter and then a conventional Python shebang; `--fusesoc-python` is the
unambiguous choice. The logical venv path is intentionally preserved: resolving
that symlink to its base Homebrew interpreter bypasses `pyvenv.cfg` and loses
the environment's packages.

On Apple Silicon, the supported campaign interpreter is native Python 3.13 at
`/opt/homebrew/opt/python@3.13/bin/python3.13`. Do not use an older environment
whose interpreter points into `/usr/local`: changing only that symlink does not
rebuild its x86_64 extension modules. Create a fresh environment from
OpenTitan's hashed requirements and pass its logical `bin/python` path through
`--fusesoc-python`. The matrix records and validates the selected machine
architecture as well as the Python and FuseSoC versions.

The earlier inventory at OpenTitan revision
`7a3ad34b6d483f4d1d69ac670ddb1c45f1172e19` found 264 RTL/default-target jobs,
128 standalone SVA/formal jobs, 61
UVM compile jobs, and 77 runtime jobs. The runtime total is the 61 configured
UVM targets plus 16 directed simulations; eight Verilator-only and six
elaboration-only targets remain inventoried but are not mislabeled as Icarus
runtime tests. Some RTL candidates are CAPI package/fileset providers without a
toplevel; the runner records those as `DEPENDENCY_ONLY` rather than falsely
reporting a compiler or setup failure. Three top-specific `rv_plic_fpv` cores
live in an `*_ip` VLNV library; their formal sources and target belong only to
the SVA/formal lane, so they are excluded from RTL rather than being compiled
twice under different labels.

## Commands

The runner requires explicit roots so a report cannot silently use a different
checkout or compiler from the one under test. Use the Python and FuseSoC from
one OpenTitan tool environment. A small ADC-control census is:

```sh
OT_PY=/path/to/opentitan-tool-env/bin/python
OT_FUSESOC=/path/to/opentitan-tool-env/bin/fusesoc
"$OT_PY" scripts/opentitan_matrix.py \
  --opentitan-root /path/to/opentitan \
  --build-root /path/to/build/matrix/adc_ctrl \
  --iverilog /path/to/install/bin/iverilog \
  --fusesoc "$OT_FUSESOC" --fusesoc-python "$OT_PY" \
  --lane rtl --lane sva --lane uvm \
  --ip adc_ctrl
```

List the full discovered inventory without building it:

```sh
"$OT_PY" scripts/opentitan_matrix.py \
  --opentitan-root /path/to/opentitan \
  --build-root /path/to/build/matrix \
  --iverilog /path/to/install/bin/iverilog \
  --fusesoc "$OT_FUSESOC" --fusesoc-python "$OT_PY" \
  --lane rtl --lane sva --lane uvm --list
```

Run all four lanes with four independent cores in flight. On macOS, the
default 3814 MiB per-agent VVP runtime budget is divided across these workers;
setup and compiler subprocesses are outside this footprint guard.

```sh
"$OT_PY" scripts/opentitan_matrix.py \
  --opentitan-root /path/to/opentitan \
  --build-root /path/to/build/matrix/full \
  --iverilog /path/to/install/bin/iverilog \
  --fusesoc "$OT_FUSESOC" --fusesoc-python "$OT_PY" \
  --lane all --jobs 4
```

Run register generation through the same interpreter rather than relying on
`util/regtool.py`'s ambient `python3` shebang:

```sh
"$OT_PY" /path/to/opentitan/util/regtool.py -r \
  -t /path/to/evidence/uart-reg-rtl \
  /path/to/opentitan/hw/ip/uart/data/uart.hjson
```

Keep that output outside the OpenTitan checkout, then compare it with the
checked-in generated RTL. This validates the register-generation dependency
closure without altering the compatibility workload.

`--core` selects an exact VLNV; `--ip` is a repeatable case-insensitive name or
description filter.  Runtime plusargs can be repeated with `--runtime-arg`.
Timeouts are independently configurable for setup, compile, and runtime. The
defaults are 600 seconds for setup, 600 seconds for compile, and 300 seconds for
runtime. Each command starts in its own process session; a timeout terminates
the whole session, including compiler/preprocessor descendants, before the next
job starts. Interrupting a census cancels queued jobs, terminates all active
command sessions, and preserves the last atomic JSON/Markdown checkpoint.
This makes bounded termination part of the evidence instead of allowing a hung
lowering pass or an orphan compiler to consume the remainder of the campaign.

The RTL lane uses synthesis mode and defines
`SYNTHESIS_MEMORY_BLACK_BOXING`, matching OpenTitan's GTECH flow for generic
RAM models.

In RTL and UVM compile lanes, FuseSoC C/C++ file-type notices are benign only
when the staged file is absent from the direct and nested Icarus `.scr` source
lists. The runner preserves the raw notices and records the classification
separately. Runtime rows use separate native-DPI build and checked-pass
evidence. The [13-row UVM follow-up](../../evidence/opentitan-uvm-setup-warning-followup-20261004/README.md)
records this distinction.

The default reports are `opentitan-matrix.json` and `opentitan-matrix.md` under
the build root.  `DEBT` and all failure/timeout statuses make the runner return
nonzero, allowing the matrix to become a genuine zero-debt gate.

For OpenTitan compatibility DV, pass `--commercial-unsafe` with the UVM and
runtime lanes. This adds `-gcommercial-unsafe` to those compile commands and
records the profile in JSON and Markdown; RTL and SVA commands are unchanged.
Results using this opt-in flag are nonstandard compatibility results, separate
from IEEE conformance. The [2026-09-25 unsafe baseline](../../evidence/opentitan-icarus-dv-baseline-unsafe-20260925/README.md)
records the exact pinned-source 84-row command and per-row table.

## Per-core simulation setup

FuseSoC literal `sim` targets do not carry every build option that OpenTitan
dvsim configuration files apply.  The UVM/runtime command builder therefore
supplies a small, explicit per-core define table only when a bare target needs
one to represent its documented default RTL configuration.

`lowrisc:dv:spi_device_sim:0.1` receives
`-DSRAM_TYPE=spi_device_pkg::SramType1r1w`. Its core target has no SRAM-mode
parameter, while `spi_device_pkg::DefaultSramType` is `SramType1r1w`. This
selects the documented default DUT configuration for the bare-core row.
OpenTitan also defines a distinct `spi_device_2p_sim_cfg.hjson`
configuration with
`SRAM_TYPE=spi_device_pkg::SramType2p`; that variant is not covered or claimed
by the bare-core matrix row. It requires a future variant-aware matrix entry.

## Historical checkpoints

The following first-run results are retained evidence. For newer compiler and
application results, use [CURRENT_WORK](CURRENT_WORK.md).

### First whole-RTL checkpoint

A pinned pre-G20 run at OpenTitan `7a3ad34b6d483f4d1d69ac670ddb1c45f1172e19`
completed 113 of 267 RTL jobs before deliberate interruption: 4
`COMPILE_TIMEOUT`, 16 `DEBT`, 59 `DEPENDENCY_ONLY`, 30 `FAIL`, and 4
`SETUP_FAIL`. All four timeouts were independent Ibex cores and each spent the
then-configured 1800 seconds in synthesis lowering. A process sample located the
hot path under `NetProcTop::synth_async`, dominated by repeated nexus connects.
This is a partial root-cause census, not a pass-rate claim.

That checkpoint exposed two infrastructure defects now fixed in the runner:
the 1800-second default made iteration needlessly slow, and a timed-out driver
could leave its compiler descendants running. The default is now 600 seconds
and timeout/interrupt cleanup covers the complete command session. The next
whole-RTL run must start from a new build root and compiler fingerprint; results
from the partial checkpoint must not be merged with the post-G20 compiler.

The first exact post-G20 Ibex-core rerun removed the immediate synthesis
segfault exposed by a statically non-overlapping packed write, then reached the
new 600-second limit. It was recorded as `COMPILE_TIMEOUT` after 600.085 seconds
and left no driver, preprocessor or compiler descendant. The bounded cleanup is
therefore verified; the hot synthesis path remains an open G22 compiler gap.

The later `ibex-disjoint-precise-v2` replay reaches the same independent hot
path and times out after 600.078 seconds with no orphan. It no longer reports
the `ibex_alu.sv` partial-field latch error: the lower field is fully assigned
on both `if/else` paths and now composes with its independently driven upper
bit. The sole remaining warning in that exact log is the legal constant-only
`always_comb` in `ibex_cs_registers.sv`; G26 removes that false debt after the
replay. The timeout itself remains an open compiler-performance finding.

The subsequent disjoint-packed-process and precise-select-sensitivity fixes
move the exact Darjeeling RACL target to a clean result at the same pinned
OpenTitan revision: `PASS`, exit 0, no hard errors, no semantic-debt lines, no
timeout, and 0.304 seconds. This is one exact core witness, not a whole-suite
claim; its compiler fingerprint must remain separate from earlier `FAIL` and
`DEBT` reports.

The final ownership-union and retained-behavioral-driver validation was replayed
in `racl-disjoint-precise-v4`: the result remains `PASS` with the same zero-error,
zero-debt disposition and a 0.357-second compile.

After the complete-branch refinement and G26 warning cleanup,
`racl-disjoint-precise-v6` is the final witness: `PASS`, exit 0, zero hard
errors, zero semantic-debt lines, no timeout, and a 0.334-second compile. This
replay includes the adversarial per-bit-state guard added after v5.

### First ADC-control matrix witness

The first three-lane run exposed the intended distinction immediately:

| Lane | Result | Current frontier |
|---|---|---|
| RTL synthesis | `DEBT` | Compile succeeds; one conservative `always_*` sensitivity warning remains recorded. |
| Standalone SVA/formal | `FAIL` | After supplying UVM to the unmodified formal dependency graph, `adc_ctrl_fsm_sva_if.sv` refers to the simulation hierarchy `tb.dut` while the formal target's top is `adc_ctrl`. This is presently an OpenTitan target/topology mismatch, followed by compiler semantic-debt warnings. |
| UVM compile | `DEBT` | Compile and code generation succeed with no hard errors, but 153 unique warning/degradation lines remain. |

The UVM warning count is a triage count, not a defect count: one root language
or lowering bug can fire at many call sites, and one line can contain several
semantic consequences.  Work proceeds by the first causal diagnostic and by
clusters (typing/context, calls, constraints, interfaces, coverage, containers,
scheduling, SVA), with value- and behavior-checking regressions added for every
compiler fix.
