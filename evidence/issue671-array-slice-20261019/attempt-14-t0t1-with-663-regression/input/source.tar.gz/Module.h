#ifndef IVL_Module_H
#define IVL_Module_H
/*
 * Copyright (c) 1998-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */


# include  <list>
# include  <map>
# include  <vector>
# include  <utility>
# include  "StringHeap.h"
# include  "HName.h"
# include  "named.h"
# include  "PScope.h"
# include  "PNamedItem.h"
# include  "netlist.h"
# include  "pform_types.h"
class PExpr;
class PEIdent;
class PGate;
class PGenerate;
class PModport;
class PSpecPath;
class PTimingCheck;
class PLet;
class PTask;
class PFunction;
class PWire;
class PProcess;
class PEventStatement;
class Design;
class NetScope;

/*
 * A module is a named container and scope. A module holds a bunch of
 * semantic quantities such as wires and gates. The module is
 * therefore the handle for grasping the described circuit.
 *
 * SystemVerilog introduces program blocks and interfaces. These have
 * much in common with modules, so the Module class is used to represent
 * these containers as well.
 */

class Module : public PScopeExtra, public PNamedItem {

	/* The module ports are in general a vector of port_t
	   objects. Each port has a name and an ordered list of
	   wires. The name is the means that the outside uses to
	   access the port, the wires are the internal connections to
	   the port. In SystemVerilog, input ports may also have a
	   default value. */
    public:
      struct PClocking : public LineInfo {
	    explicit PClocking(perm_string n, PEventStatement*evt);
	    ~PClocking();

	      /* IEEE 1800-2017 14.3: each clocking signal has a direction.
		 Inputs are sampled, outputs are driven, inouts (and the
		 `input ... output ...` combined form) are both. */
	    bool add_signal(perm_string sig_name, NetNet::PortType dir,
			    const pform_clocking_skew_t*in_skew = nullptr,
			    const pform_clocking_skew_t*out_skew = nullptr);
	    NetNet::PortType signal_direction(perm_string sig_name) const;

	      /* 14.4 skew application. Input skew classification:
		 #1step (or none/edge-only) samples the Preponed value;
		 an explicit numeric delay (including #0) samples a
		 #d-delayed shadow after the NBA region. Output skews
		 delay the drive landing. Item skews win over the
		 block `default input/output` skews. */
	    enum skew_kind_t { SKEW_1STEP, SKEW_DELAY };
	    skew_kind_t input_skew(perm_string sig_name, PExpr*&delay) const;
	    const pform_clocking_skew_t* output_skew(perm_string sig_name) const;
	    PExpr* output_skew_delay(perm_string sig_name) const;
	    void set_default_skews(const pform_clocking_skew_t*in_skew,
				   const pform_clocking_skew_t*out_skew);

	    perm_string name;
	    PEventStatement*event;
	    std::vector<perm_string>signals;
	    std::map<perm_string,NetNet::PortType>directions;
	    std::map<perm_string,pform_clocking_skew_t>in_skews;
	    std::map<perm_string,pform_clocking_skew_t>out_skews;
	      /* clocking_decl_assign (A.6.11): clockvars sampling an
		 arbitrary expression. The signal-path form is
		 supported; other shapes are diagnosed. */
	    std::map<perm_string,PExpr*>decl_assigns;
	    pform_clocking_skew_t default_in, default_out;
	    bool default_in_set = false, default_out_set = false;
      };

      struct port_t {
	    perm_string name;
	    std::vector<PEIdent*> expr;
	    PExpr*default_value;
      };

    public:
	/* The name passed here is the module name, not the instance
	   name. This name must be a permallocated string. */
      explicit Module(LexicalScope*parent, perm_string name);
      ~Module() override;

	/* Initially false. This is set to true if the module has been
	   declared as a library module. This makes the module
	   ineligible for being chosen as an implicit root. It has no
	   other effect. */
      bool library_flag;

      bool is_cell;

	/* This is true if the module represents a program block
	   instead of a module/cell. Program blocks have content
	   restrictions and slightly modify scheduling semantics. */
      bool program_block;

	/* This is true if the module represents a interface
	   instead of a module/cell. Interfaces have different
	   content restrictions and some extra allowed items. */
      bool is_interface;

	/* Checkers are module-like scopes, but IEEE 1800 permits a checker
	 * (unlike an ordinary module) to be bound into an interface. */
      bool is_checker;

      enum UCDriveType { UCD_NONE, UCD_PULL0, UCD_PULL1 };
      UCDriveType uc_drive;

	/* specparams are simpler than other parameters, in that they
	   can have a range, but not an explicit type. The restrictions
	   are enforced by the parser. */
      std::map<perm_string,param_expr_t*>specparams;

	/* The module also has defparam assignments which don't create
	   new parameters within the module, but may be used to set
	   values within this module (when instantiated) or in other
	   instantiated modules. */
      typedef std::pair<pform_name_t,PExpr*> named_expr_t;
      std::list<named_expr_t>defparms;
      static std::list<named_expr_t>user_defparms;

        /* Parameters may be overridden at instantiation time;
           the overrides do not contain explicit parameter names,
           but rather refer to parameters in the order they
           appear in the instantiated module.  Therefore a
           list of names in module-order is needed to pass from
           a parameter-index to its name. */
      std::list<perm_string> param_names;

	/* This is an array of port descriptors, which is in turn a
	   named array of PEident pointers. */
      std::vector<port_t*> ports;

      std::map<perm_string,PExpr*> attributes;

	/* The module has a list of generate schemes that appear in
	   the module definition. These are used at elaboration time. */
      std::list<PGenerate*> generate_schemes;

	/* Nested modules are placed here, and are not elaborated
	   unless they are instantiated, implicitly or explicitly. */
      std::map<perm_string,Module*> nested_modules;

	/* An interface can contain one or more named modport lists.
           The parser will ensure these don't appear in modules or
           program blocks. */
      std::map<perm_string,PModport*> modports;
      std::map<perm_string,PClocking*> clocking_blocks;

	/* IEEE 1800-2017 14.12: at most one default clocking block per
	   module, interface, or program. Nil when no default is declared.
	   Anonymous default clocking blocks are registered in
	   clocking_blocks under an internal name that no source
	   identifier can collide with. */
      perm_string default_clocking;

	/* IEEE 1800-2017 14.14: at most one global clocking block per
	   module/program (design-wide resolution happens at
	   $global_clock elaboration by walking the enclosing scopes).
	   Nil when none is declared. */
      perm_string global_clocking;

	/* List for specify paths and timing checks */
      std::list<PSpecPath*> specify_paths;
      std::list<PTimingCheck*> timing_checks;

	/* let declarations (IEEE 1800-2017 11.13), expanded by
	   substitution at elaboration. */
      std::map<perm_string,PLet*> lets;

	// The mod_name() is the name of the module type.
      perm_string mod_name() const { return pscope_name(); }

      void add_gate(PGate*gate);

      unsigned port_count() const;
      const std::vector<PEIdent*>& get_port(unsigned idx) const;
      unsigned find_port(const char*name) const;

      // Return port name ("" for undeclared port)
      perm_string get_port_name(unsigned idx) const;

      PExpr* get_port_default_value(unsigned idx) const;

      PGate* get_gate(perm_string name);

      const std::list<PGate*>& get_gates() const;

      void dump(std::ostream&out) const;
      bool elaborate(Design*, NetScope*scope) const;

      typedef std::map<perm_string,PExpr*> replace_t;
      bool elaborate_scope(Design*, NetScope*scope, const replace_t&rep);

      bool elaborate_sig(Design*, NetScope*scope) const;

      SymbolType symbol_type() const override;

      bool can_be_toplevel() const;

    private:
      void dump_specparams_(std::ostream&out, unsigned indent) const;
      void dump_timingchecks_(std::ostream&out, unsigned indent) const;
      std::list<PGate*> gates_;

    private: // Not implemented
      Module(const Module&);
      Module& operator= (const Module&);
};

/* Resolve the raw signal a clocking-block item samples or drives:
   the local signal of the same name, or the clocking_decl_assign
   target when the item declared one (signal-path form only;
   other expression shapes return nil). Implemented in netmisc.cc. */
class Design;
extern NetNet* resolve_clocking_raw_signal(Design*des, NetScope*scope,
				    const Module::PClocking*cb,
				    perm_string sig_name);

#endif /* IVL_Module_H */
