module narrow_shape;
  bit [4:3] data;
  bit lane;
  initial data[2'(3'(lane + 3'd3)) -: 1] = 1'b1;
endmodule
