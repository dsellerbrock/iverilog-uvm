module wide_declared_slice;
  class C;
    bit [1:0][64'd2147483655:64'd2147483648] data;
    function bit [3:0] read_slice(bit lane);
      return data[0][(33'd2147483648 + lane*4 + 3) -: 4];
    endfunction
  endclass
  C c;
  initial begin
    c = new;
    c.data = 16'h12a5;
    $display("a=%h b=%h", c.read_slice(1'b0), c.read_slice(1'b1));
  end
endmodule
