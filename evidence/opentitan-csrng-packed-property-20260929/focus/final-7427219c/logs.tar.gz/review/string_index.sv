class C;
  bit [3:0] v;
endclass
module top;
  C c;
  string idx;
  bit b;
  initial begin
    c = new;
    idx = "1";
    b = c.v[idx];
    $display("b=%b", b);
  end
endmodule
