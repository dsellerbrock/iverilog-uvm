module wide_declared_index;
  class C;
    bit [1:0][64'd2147483649:64'd2147483648] data;
    function bit read_bit(bit lane);
      return data[0][(33'd2147483648 + lane) -: 1];
    endfunction
  endclass
  C c;
  initial begin
    c = new;
    c.data = 4'b1011;
    $display("got=%b", c.read_bit(1'b1));
  end
endmodule
