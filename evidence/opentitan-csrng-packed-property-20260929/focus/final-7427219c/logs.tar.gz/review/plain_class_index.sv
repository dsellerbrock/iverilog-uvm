class C;
endclass
module top;
  C c;
  bit [3:0] v;
  bit b;
  initial begin
    c = new;
    b = v[c];
    $display("b=%b", b);
  end
endmodule
