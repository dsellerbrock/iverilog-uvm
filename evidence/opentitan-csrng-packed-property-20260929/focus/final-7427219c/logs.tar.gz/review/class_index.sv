class C;
  bit [3:0] v;
endclass
module top;
  C c;
  bit b;
  initial begin
    c = new;
    b = c.v[c];
    $display("b=%b", b);
  end
endmodule
