module plain_nested;
  bit [31:0] data;
  int i;
  initial data[i[1:0]*8+7 -: 8] = 8'h00;
endmodule
