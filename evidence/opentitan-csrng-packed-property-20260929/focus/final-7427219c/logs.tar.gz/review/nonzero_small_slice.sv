module nonzero_small_slice;
  class C;
    bit [1:0][11:4] data;
    function bit [3:0] read_slice(bit lane);
      return data[0][(33'd4 + lane*4 + 3) -: 4];
    endfunction
  endclass
  C c;
  initial begin
    c = new;
    c.data = 16'h12a5;
    $display("a=%h b=%h", c.read_slice(1'b0), c.read_slice(1'b1));
  end
endmodule
