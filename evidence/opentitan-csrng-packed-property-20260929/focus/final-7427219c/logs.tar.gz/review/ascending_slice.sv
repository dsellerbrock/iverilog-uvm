module ascending_slice;
  class C;
    bit [1:0][0:7] data;
    function bit [3:0] up();
      return data[0][1 +: 4];
    endfunction
    function bit [3:0] down();
      return data[0][6 -: 4];
    endfunction
    function void write_up();
      data[0][1 +: 4] = 4'h9;
    endfunction
    function void write_down();
      data[0][6 -: 4] = 4'h6;
    endfunction
  endclass
  C c;
  bit [1:0][0:7] s;
  initial begin
    c = new;
    s = 16'hA5C3;
    c.data = s;
    $display("up class=%h sig=%h", c.up(), s[0][1 +: 4]);
    $display("down class=%h sig=%h", c.down(), s[0][6 -: 4]);
    c.write_up();
    s[0][1 +: 4] = 4'h9;
    $display("write up class=%h sig=%h", c.data, s);
    c.write_down();
    s[0][6 -: 4] = 4'h6;
    $display("write down class=%h sig=%h", c.data, s);
  end
endmodule
