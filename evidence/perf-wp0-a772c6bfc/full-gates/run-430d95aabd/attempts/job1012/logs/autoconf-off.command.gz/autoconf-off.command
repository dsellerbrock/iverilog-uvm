command=bash -c cd\ \"\$1\"\ \&\&\ sh\ ./autoconf.sh bash /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-full-430d95aabd-20261014-r2/source-off 
