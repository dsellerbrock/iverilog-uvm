command=bash -c cd\ \"\$1/ivtest\"\ \&\&\ python3\ ./vvp_reg.py bash /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-full-430d95aabd-20261014-r2/source-off 
