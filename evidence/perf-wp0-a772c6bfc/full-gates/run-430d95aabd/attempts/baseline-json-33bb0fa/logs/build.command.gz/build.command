command=make -C /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-json-baseline-33bb0fa-20261014/source -j2 
