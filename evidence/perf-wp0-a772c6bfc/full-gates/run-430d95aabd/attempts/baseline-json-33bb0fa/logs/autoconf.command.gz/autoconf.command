command=bash -c cd\ \"\$1\"\ \&\&\ sh\ ./autoconf.sh bash /home/dsell/slurm-runs/iverilog-uvm/a5-perf/wp0-json-baseline-33bb0fa-20261014/source 
