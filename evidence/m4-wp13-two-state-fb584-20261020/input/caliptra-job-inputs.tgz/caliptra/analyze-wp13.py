#!/usr/bin/env python3
import csv
import gzip
import json
import math
import re
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
cases = (
    "smoke_test_dma_aes_gcm_short_1_dword",
    "smoke_test_sha256",
    "cptra_ss_test_rom",
)
variants = ("base", "candidate")
events = list(csv.DictReader((root / "results/events.tsv").open(), delimiter="\t"))
assert len(events) == 18, len(events)
window_re = re.compile(
    r"MCYCLE_WINDOW start=(\d+) end=(\d+) cycles=(\d+) elapsed_ns=(\d+)"
)


def normalized(path):
    with gzip.open(path, "rt", errors="replace") as source:
        return "\n".join(
            line for line in source.read().splitlines()
            if not line.startswith(("MCYCLE_WINDOW ", "CALIPTRA_PROGRESS_HEARTBEAT "))
        )


runs = {}
for event in events:
    case, variant, repeat = event["test"], event["variant"], int(event["repeat"])
    key = (case, variant, repeat)
    assert case in cases and variant in variants and repeat in (1, 2, 3), key
    evidence = root / "runs" / f"{case}-r{repeat}-{variant}"
    match = window_re.fullmatch((evidence / "window.txt").read_text().strip())
    assert match, key
    start, end, cycles, elapsed_ns = map(int, match.groups())
    assert (start, end, cycles) == (100, 2100, 2000), (key, match.groups())
    assert elapsed_ns > 0
    hex_inputs = {}
    for line in (evidence / "generated-hex.tsv").read_text().splitlines():
        digest, name = line.split("\t", 1)
        hex_inputs[name] = digest
    assert len(hex_inputs) == 39, (key, len(hex_inputs))
    runner_exit = int(event["runner_exit"])
    assert runner_exit == 1, (key, runner_exit)
    result = json.loads((evidence / "result.json").read_text())
    assert result.get("passed") is False, (key, result)
    runs[key] = {
        "rate": cycles * 1_000_000_000 / elapsed_ns,
        "elapsed_ns": elapsed_ns,
        "hex": hex_inputs,
        "log": evidence / "sim.log.gz",
    }
assert len(runs) == 18

for case in cases:
    expected_hex = expected_log = None
    for repeat in (1, 2, 3):
        for variant in variants:
            row = runs[(case, variant, repeat)]
            if expected_hex is None:
                expected_hex = row["hex"]
            assert row["hex"] == expected_hex, (case, repeat, variant, "firmware inputs differ")
            log = normalized(row["log"])
            if expected_log is None:
                expected_log = log
            assert log == expected_log, (case, repeat, variant, "normalized simulation logs differ")

summary = {
    "pinned_base": "fb584a251dd4cc91e56a75be662ccd5ee05c64e9",
    "candidate_patch_sha256": (root / "input/wp13-candidate.patch.sha256").read_text().split()[0],
    "window": {"start": 100, "end": 2100, "cycles": 2000},
    "all_inputs_identical": True,
    "all_normalized_logs_identical": True,
    "tests": {},
}
lines = [
    "# WP13 Caliptra A/B: pinned base vs two-state wire-load prototype",
    "",
    "Three interleaved repeats per build and test used the fixed mcycle window 100–2,100 on one CPU.",
    "Spread is (maximum minus minimum) divided by median.",
    "",
    "| Test | Pinned base cycles/s (spread) | Prototype cycles/s (spread) | Speedup |",
    "|---|---:|---:|---:|",
]
ratios = []
for case in cases:
    stats = {}
    for variant in variants:
        rates = [runs[(case, variant, repeat)]["rate"] for repeat in (1, 2, 3)]
        median = statistics.median(rates)
        stats[variant] = {
            "median_cycles_per_second": median,
            "min_cycles_per_second": min(rates),
            "max_cycles_per_second": max(rates),
            "spread_percent": (max(rates) - min(rates)) / median * 100,
            "runs": rates,
        }
    ratio = stats["candidate"]["median_cycles_per_second"] / stats["base"]["median_cycles_per_second"]
    ratios.append(ratio)
    summary["tests"][case] = stats
    lines.append(
        f"| {case} | {stats['base']['median_cycles_per_second']:.3f} "
        f"({stats['base']['spread_percent']:.2f}%) | "
        f"{stats['candidate']['median_cycles_per_second']:.3f} "
        f"({stats['candidate']['spread_percent']:.2f}%) | {(ratio - 1) * 100:+.2f}% |"
    )
geo = math.exp(sum(math.log(value) for value in ratios) / len(ratios))
summary["geometric_mean_speedup_percent"] = (geo - 1) * 100
lines.extend([
    "",
    f"Three-test geometric-mean speedup: {(geo - 1) * 100:+.2f}%.",
    "",
    "All generated firmware inputs and simulator logs matched after removing only the "
    "mcycle marker and progress-heartbeat instrumentation. The VPI marker stops each "
    "incomplete test at mcycle 2,100, so these are bounded throughput samples, not firmware pass results.",
    "",
])
(root / "results/summary.json").write_text(json.dumps(summary, indent=2) + "\n")
(root / "results/summary.md").write_text("\n".join(lines))
