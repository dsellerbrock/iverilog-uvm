#!/bin/sh
set -eu

script_dir=$(CDPATH= cd "$(dirname "$0")" && pwd)
repo_dir=$(CDPATH= cd "$script_dir/../.." && pwd)
iverilog=${IVERILOG:-$repo_dir/local-install/bin/iverilog}
vvp=${VVP:-$repo_dir/local-install/bin/vvp}
work_dir=$(mktemp -d "${TMPDIR:-/tmp}/two-state-vec4-load.XXXXXX")
trap 'rm -rf "$work_dir"' EXIT HUP INT TERM

if [ ! -x "$iverilog" ] || [ ! -x "$vvp" ]; then
    echo "error: missing executable compiler/runtime" >&2
    exit 2
fi

"$iverilog" -g2012 -o "$work_dir/two_state_vec4_load.vvp" \
    "$script_dir/two_state_vec4_load.sv"
"$vvp" "$work_dir/two_state_vec4_load.vvp" \
    > "$work_dir/stdout" 2> "$work_dir/stderr"

if [ -s "$work_dir/stderr" ] \
   || ! grep -F -x -q 'PASS two-state vec4 load and forced X/Z fallback' \
        "$work_dir/stdout"; then
    echo "FAIL two-state vec4 load and forced X/Z fallback" >&2
    cat "$work_dir/stdout" >&2
    cat "$work_dir/stderr" >&2
    exit 1
fi

echo "PASS two-state vec4 load and forced X/Z fallback"
