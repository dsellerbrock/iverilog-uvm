module two_state_vec4_load;
    bit [3:0] source;
    bit [69:0] wide_source;
    wire bit [3:0] state2;
    wire bit [69:0] wide_state2;

    assign state2 = source;
    assign wide_state2 = wide_source;

    initial begin
        source = 4'hA;
        wide_source = 70'h3f_123456789abcdef0;
        #1;
        if (state2 !== 4'hA)
            $fatal(1, "two-state value changed on load: %b", state2);
        if (wide_state2 !== 70'h3f_123456789abcdef0)
            $fatal(1, "wide two-state value changed on load: %b", wide_state2);

        force state2 = 4'bx1z0;
        #1;
        if (state2 !== 4'b0100)
            $fatal(1, "forced X/Z was not applied through the two-state type: %b", state2);

        release state2;
        #1;
        if (state2 !== 4'hA)
            $fatal(1, "released two-state value changed: %b", state2);

        $display("PASS two-state vec4 load and forced X/Z fallback");
        $finish;
    end
endmodule
