# WP13 Caliptra A/B: pinned base vs two-state wire-load prototype

Three interleaved repeats per build and test used the fixed mcycle window 100–2,100 on one CPU.
Spread is (maximum minus minimum) divided by median.

| Test | Pinned base cycles/s (spread) | Prototype cycles/s (spread) | Speedup |
|---|---:|---:|---:|
| smoke_test_dma_aes_gcm_short_1_dword | 10.537 (1.33%) | 10.408 (1.69%) | -1.22% |
| smoke_test_sha256 | 10.566 (1.62%) | 10.511 (2.15%) | -0.52% |
| cptra_ss_test_rom | 10.537 (0.62%) | 10.446 (1.10%) | -0.86% |

Three-test geometric-mean speedup: -0.87%.

All generated firmware inputs and simulator logs matched after removing only the mcycle marker and progress-heartbeat instrumentation. The VPI marker stops each incomplete test at mcycle 2,100, so these are bounded throughput samples, not firmware pass results.
