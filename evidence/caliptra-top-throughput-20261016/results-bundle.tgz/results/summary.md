# End-to-end Caliptra throughput: campaign base, main, and #601

Each sample covers 2,000 mcycles (100–2,100) in the full Caliptra top-level testbench. Three repeats per test and build were interleaved on one Slurm CPU. Spread is (maximum minus minimum) divided by median.

| Test | Campaign base f9f8e0a | Main 631b7a8 before #601 | #601 candidate | Candidate vs base | Candidate vs main |
|---|---:|---:|---:|---:|---:|
| smoke_test_dma_aes_gcm_short_1_dword | 7.269 (1.67%) | 8.396 (2.35%) | 9.530 (0.35%) | +31.10% | +13.51% |
| smoke_test_sha256 | 7.267 (0.66%) | 8.328 (1.13%) | 9.507 (2.34%) | +30.83% | +14.15% |
| cptra_ss_test_rom | 7.262 (7.50%) | 8.290 (2.06%) | 9.499 (4.13%) | +30.81% | +14.57% |

Three-test geometric-mean main vs base: +14.76%.

Three-test geometric-mean candidate vs base: +30.91%.

Three-test geometric-mean candidate vs main: +14.08%.

All 39 generated firmware hex inputs matched across every repeat and build. Normalized simulator logs matched after removing only the mcycle-window marker and progress-heartbeat lines. VPI deliberately stops each incomplete test at mcycle 2,100; the expected runner exit is 1, so these are bounded throughput samples, not firmware pass results.
