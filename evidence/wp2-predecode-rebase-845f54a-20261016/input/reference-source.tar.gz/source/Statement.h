#ifndef IVL_Statement_H
#define IVL_Statement_H
/*
 * Copyright (c) 1998-2026 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  <string>
# include  <vector>
# include  <list>
# include  <map>
# include  <set>
# include  "ivl_target.h"
# include  "StringHeap.h"
# include  "PDelays.h"
# include  "PExpr.h"
# include  "PScope.h"
# include  "HName.h"
# include  "LineInfo.h"
class PExpr;
class PChainConstructor;
class PPackage;
class Statement;
class PEventStatement;
class pform_constructor_order_audit_t;
class Design;
class NetAssign_;
class NetCAssign;
class NetDeassign;
class NetForce;
class NetScope;
struct typedef_t;

/*
 * The PProcess is the root of a behavioral process. Each process gets
 * one of these, which contains its type (initial, always, or final)
 * and a pointer to the single statement that is the process. A module
 * may have several concurrent processes.
 */
class PProcess : public LineInfo {

    public:
      PProcess(ivl_process_type_t t, Statement*st)
      : type_(t), statement_(st), generated_verification_(false) { }

      virtual ~PProcess() override;

      PProcess(const PProcess&) = delete;
      PProcess& operator=(const PProcess&) = delete;

      bool elaborate(Design*des, NetScope*scope) const;

      ivl_process_type_t type() const { return type_; }
      Statement*statement() { return statement_; }

      void generated_verification(bool flag = true)
      { generated_verification_ = flag; }
      bool is_generated_verification() const
      { return generated_verification_; }

      std::map<perm_string,PExpr*> attributes;

      virtual void dump(std::ostream&out, unsigned ind) const;

    private:
      ivl_process_type_t type_;
      Statement*statement_;
      bool generated_verification_;
};

/*
 * The PProcess is a process, the Statement is the actual action. In
 * fact, the Statement class is abstract and represents all the
 * possible kinds of statements that exist in Verilog.
 */
class Statement : virtual public LineInfo {

    public:
      Statement() { }
      virtual ~Statement() override =0;

      virtual void dump(std::ostream&out, unsigned ind) const;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const;
      virtual void elaborate_scope(Design*des, NetScope*scope) const;
      virtual void elaborate_sig(Design*des, NetScope*scope) const;

	// True if this statement (or a sub-statement within the same
	// activation frame) is a detached fork — a fork/join_none or
	// fork/join_any whose spawned branches outlive the statement.
	// Used by elaborate_scope to decide whether an automatic block
	// that declares its own locals may be collapsed into the
	// enclosing task frame: a block whose locals are captured by a
	// detached branch must keep a per-entry frame so each loop
	// iteration produces a distinct copy (IEEE 1800-2017 9.3.2).
      virtual bool contains_detached_fork() const { return false; }

	// Conservative "might this statement refer to `name'?" search.
	// The base answers TRUE: a statement kind that does not override
	// this is assumed to refer to the name, so a kind nobody handled
	// keeps the existing diagnostic rather than silently suppressing
	// it -- a missing override costs precision, never soundness.
      virtual bool refs_name(perm_string name) const;

	// IEEE 1800-2017 9.3.2: "Within a fork-join_any or fork-join_none
	// block, it shall be illegal to refer to formal arguments passed
	// by reference other than in the initialization value expressions
	// of variables declared in a block_item_declaration of the fork."
	// Answers whether this subtree contains a detached fork that
	// refers to `name'. Overridden in exactly the kinds that override
	// contains_detached_fork(), so it is as complete as that walk.
      virtual bool detached_fork_refs_name(perm_string name) const;

      std::map<perm_string,PExpr*> attributes;
};

/*
 * Assignment statements of the various forms are handled by this
 * type. The rvalue is an expression. The lvalue needs to be figured
 * out by the parser as much as possible.
 */
class PAssign_  : public Statement {
    public:
      bool refs_name(perm_string name) const override;
      explicit PAssign_(PExpr*lval, PExpr*ex, bool is_constant,
			bool is_init = false, bool delete_rval = true,
			const typedef_t*rval_typedef = 0);
      explicit PAssign_(PExpr*lval, PExpr*de, PExpr*ex);
      explicit PAssign_(PExpr*lval, PExpr*cnt, PEventStatement*de, PExpr*ex);
      virtual ~PAssign_() override =0;

      PAssign_(const PAssign_&) = delete;
      PAssign_& operator=(const PAssign_&) = delete;

      const PExpr* lval() const  { return lval_; }
      PExpr* rval() const  { return rval_; }
      bool has_timing_control() const
      { return delay_ || event_ || count_; }

      // Phase 63a/A3: in-place rewrite for the `{<<N{x}} = rhs`
      // → `x = {<<N{rhs}}` transformation.  The caller takes
      // ownership of the new lval/rval pointers (formerly inner_ of
      // the LHS PEStreaming and a freshly-built PEStreaming wrapping
      // the original rval, respectively).
      void replace_lval_rval(PExpr*new_lval, PExpr*new_rval) const
            { const_cast<PAssign_*>(this)->lval_ = new_lval;
              const_cast<PAssign_*>(this)->rval_ = new_rval; }

    protected:
      NetAssign_* elaborate_lval(Design*, NetScope*scope) const;
      NetExpr* elaborate_rval_(Design*, NetScope*, ivl_type_t lv_net_type,
			       ivl_variable_type_t lv_type,
			       unsigned lv_width,
			       bool force_unsigned =false) const;
      NetExpr* elaborate_rval_(Design*, NetScope*, ivl_type_t ntype) const;

      NetExpr* elaborate_direct_integral_container_rval_(
	    Design*, NetScope*, ivl_type_t target_type, bool&handled) const;

      NetScope* elaborate_rval_scope_(Design*, NetScope*) const;

      NetExpr* elaborate_rval_obj_(Design*, NetScope*,
				   ivl_variable_type_t type) const;

      PExpr* delay_;
      PEventStatement*event_;
      PExpr* count_;

    private:
      PExpr* lval_;
      PExpr* rval_;
      bool is_constant_;
        // Whether the assignment is a variable initializer expression
      bool is_init_ = false;
        // Most assignments own their rvalue. Parse-time synthesized struct
        // member defaults borrow the expression retained by the type AST.
      bool delete_rval_ = true;
        // A borrowed unpacked-struct member default is written where the
        // variable is declared, but its names are resolved where the
        // defining typedef was declared.
      const typedef_t*rval_typedef_ = 0;
};

class PAssign  : public PAssign_ {

    public:
	// lval  - assignment l-value
	// ex    - assignment r-value
	// op    - compressed assignment operator (i.e. '+', '-', ...)
	// de    - delayed assignment delay expression
      explicit PAssign(PExpr*lval, PExpr*ex);
      explicit PAssign(PExpr*lval, char op, PExpr*ex);
      explicit PAssign(PExpr*lval, PExpr*de, PExpr*ex);
      explicit PAssign(PExpr*lval, PExpr*cnt, PEventStatement*de, PExpr*ex);
      explicit PAssign(PExpr*lval, PExpr*ex, bool is_constant, bool is_init);
      explicit PAssign(PExpr*lval, PExpr*ex, bool is_constant, bool is_init,
		       bool delete_rval,
		       const typedef_t*rval_typedef = 0);
      ~PAssign() override;

	// The compressed-assignment operator ('+' for `x += e'), or 0
	// for a plain assignment. Read by the assertion lowering, which
	// has to reproduce a user action block at two sites.
      char op() const { return op_; }

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;

    private:
      NetProc* elaborate_unwrapped_(Design*des, NetScope*scope) const;
      NetProc* elaborate_compressed_(Design*des, NetScope*scope) const;
      char op_;
};

class PAssignNB  : public PAssign_ {

    public:
      explicit PAssignNB(PExpr*lval, PExpr*ex);
      explicit PAssignNB(PExpr*lval, PExpr*de, PExpr*ex);
      explicit PAssignNB(PExpr*lval, PExpr*cnt, PEventStatement*de, PExpr*ex);
      ~PAssignNB() override;

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;

    private:
      NetProc*assign_to_memory_(class NetMemory*, PExpr*,
				Design*des, NetScope*scope) const;
};

/*
 * A block statement is an ordered list of statements that make up the
 * block. The block can be sequential or parallel, which only affects
 * how the block is interpreted. The parser collects the list of
 * statements before constructing this object, so it knows a priori
 * what is contained.
 */
class PBlock  : public PScope, public Statement, public PNamedItem {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      enum BL_TYPE { BL_SEQ, BL_PAR, BL_JOIN_NONE, BL_JOIN_ANY };

	// If the block has a name, it is a scope and also has a parent.
      explicit PBlock(perm_string n, LexicalScope*parent, BL_TYPE t);
	// If it doesn't have a name, it's not a scope
      explicit PBlock(BL_TYPE t);
      ~PBlock() override;

      BL_TYPE bl_type() const { return bl_type_; }
      void randsequence_block(ivl_randsequence_block_t kind)
      { randsequence_block_ = kind; }
      ivl_randsequence_block_t randsequence_block() const
      { return randsequence_block_; }

      bool var_init_needs_explicit_lifetime() const override;

	// This is only used if this block is the statement list for a
	// constructor. We look for a PChainConstructor as the first
	// statement, and if it is there, extract it.
      PChainConstructor*extract_chain_constructor();

	// If the bl_type() is BL_PAR, it is possible to replace it
	// with JOIN_NONE or JOIN_ANY. This is to help the parser.
      void set_join_type(BL_TYPE);

      void set_statement(const std::vector<Statement*>&st);

	// Read by the assertion lowering, which has to reproduce a user
	// action block at two sites.
      const std::vector<Statement*>& statements() const { return list_; }

	// Copy the statement from that block to the front of this
	// block.
      void push_statement_front(Statement*that);

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      bool contains_detached_fork() const override;

      SymbolType symbol_type() const override;

    private:
      friend class pform_constructor_order_audit_t;
      BL_TYPE bl_type_;
      ivl_randsequence_block_t randsequence_block_ = IVL_RANDSEQ_BLOCK_NONE;
      std::vector<Statement*>list_;
};

class PBreak : public Statement {
    public:
      bool refs_name(perm_string name) const override;
      explicit PBreak(ivl_flow_control_t kind = IVL_FLOW_LOOP_BREAK)
      : kind_(kind) { }
      ivl_flow_control_t flow_control() const { return kind_; }
      void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;

    private:
      ivl_flow_control_t kind_;
};

class PCallTask  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      explicit PCallTask(PPackage *pkg, const pform_name_t &n, const std::list<named_pexpr_t> &parms);
      explicit PCallTask(const pform_name_t &n, const std::list<named_pexpr_t> &parms);
      explicit PCallTask(perm_string n, const std::list<named_pexpr_t> &parms);
	// Method-call statement on an arbitrary receiver expression,
	// e.g. f().method(args); (IEEE 1800-2017 8.10). path_ holds only
	// the method name.
      explicit PCallTask(PExpr*receiver, perm_string method_name,
			 const std::list<named_pexpr_t> &parms);
      ~PCallTask() override;

      const pform_name_t& path() const;
      PPackage* package() const { return package_; }
      PExpr* receiver_expr() const { return receiver_; }
      const std::vector<named_pexpr_t>& parms() const { return parms_; }

      /* Phase 63b/Q-methods: with-clause predicate for sort/rsort/
         unique task-form calls (`q.sort with (item.key);`).  Empty
         vector when no with-clause was attached at parse time. */
      void set_with_constraints(std::vector<PExpr*> c)
            { with_constraints_ = std::move(c); }
      const std::vector<PExpr*>& with_constraints() const
            { return with_constraints_; }
      void set_randomize_with_identifiers(std::vector<perm_string> names)
	    { randomize_with_identifier_list_present_ = true;
	      randomize_with_identifiers_ = std::move(names); }
      const std::vector<perm_string>& randomize_with_identifiers() const
	    { return randomize_with_identifiers_; }
      bool has_randomize_with_identifier_list() const
	    { return randomize_with_identifier_list_present_; }

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;

      bool elaborate_elab(Design*des, NetScope*scope) const;

      void void_cast() { void_cast_ = true; }
      bool is_void_cast() const { return void_cast_; }
      void set_leading_type_args(struct parmvalue_t*type_args)
            { leading_type_args_ = type_args; }
      const struct parmvalue_t* leading_type_args() const
            { return leading_type_args_; }
      void set_scoped_type_prefix() { scoped_type_prefix_ = true; }
      bool has_scoped_type_prefix() const { return scoped_type_prefix_; }

    private:
      NetProc* elaborate_sys(Design*des, NetScope*scope) const;
      NetProc* elaborate_usr(Design*des, NetScope*scope) const;

      NetProc*elaborate_method_(Design*des, NetScope*scope,
                                bool add_this_flag = false) const;
      NetProc*elaborate_receiver_method_(Design*des, NetScope*scope) const;
      NetProc*elaborate_function_(Design*des, NetScope*scope) const;
      NetProc*elaborate_void_function_(Design*des, NetScope*scope,
				       NetFuncDef*def) const;
      NetProc *elaborate_non_void_function_(Design *des, NetScope *scope) const;

      NetProc*elaborate_build_call_(Design*des, NetScope*scope,
				    NetScope*task, NetExpr*use_this,
				    bool super_call = false) const;
	// Bind a `ref' formal to its actual (IEEE 1800-2017 13.5.2).
	// Sets *via to a temporary when the actual could not be named
	// directly, in which case the caller copies through it.
      NetProc*elaborate_ref_bind_(Design*des, NetScope*scope,
				  NetNet*port, PExpr*actual,
				  unsigned argno, NetNet**via) const;
      NetProc*elaborate_sys_task_method_(Design*des, NetScope*scope,
					 NetExpr*obj,
					 ivl_type_t obj_type,
					 perm_string method_name,
					 const char *sys_task_name,
				         const std::vector<perm_string> &parm_names = {}) const;
      NetProc*elaborate_queue_method_(Design*des, NetScope*scope,
				      NetExpr*obj,
				      const netdarray_t*obj_darray,
				      perm_string method_name,
				      const char *sys_task_name,
				      const std::vector<perm_string> &parm_names) const;
      NetProc*elaborate_method_func_(NetScope*scope,
				     NetExpr*obj,
				     ivl_type_t type,
				     perm_string method_name,
				     const char*sys_task_name) const;
      NetProc*elaborate_randomize_with_(Design*des, NetScope*scope,
					NetExpr*obj,
					const netclass_t*class_type) const;
      bool test_task_calls_ok_(Design*des, const NetScope*scope) const;

      PPackage*package_;
      pform_name_t path_;
      std::vector<named_pexpr_t> parms_;
      struct parmvalue_t*leading_type_args_ = 0;
      bool scoped_type_prefix_ = false;
      bool void_cast_ = false;
      std::vector<PExpr*> with_constraints_;
      bool randomize_with_identifier_list_present_ = false;
      std::vector<perm_string> randomize_with_identifiers_;
	// Non-null for method-call statements on arbitrary receiver
	// expressions. In that case path_ holds only the method name.
      PExpr*receiver_ = nullptr;
};

class PCase  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      struct Item {
	    std::list<PExpr*>expr;
	    // M14: for `case (x) inside`, range items [lo:hi] are held
	    // here (single values stay in expr). Empty for ordinary case.
	    std::list<inside_range_t> inside_ranges;
	    Statement*stat;
      };

      PCase(ivl_case_quality_t, NetCase::TYPE, PExpr*ex,
            std::vector<Item*>*, bool quality_if = false);
      ~PCase() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      ivl_case_quality_t quality_;
      NetCase::TYPE type_;
      PExpr*expr_;

      std::vector<Item*>*items_;
      bool quality_if_;

    private: // not implemented
      PCase(const PCase&);
      PCase& operator= (const PCase&);
};

/* randcase (IEEE 1800-2017 18.16): weighted random branch selection.
 * Reuses PCase::Item for the parsed items (each carries one weight
 * expression and a statement). Elaboration lowers it to: evaluate each
 * weight once into a temp, sum them, draw $urandom_range(sum-1), and
 * select the branch by cumulative-threshold compare. A zero total weight
 * executes no branch. */
class PRandCase : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      explicit PRandCase(std::vector<PCase::Item*>*items)
	    : items_(items) {}
      ~PRandCase() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      std::vector<PCase::Item*>*items_;

    private: // not implemented
      PRandCase(const PRandCase&) = delete;
      PRandCase& operator=(const PRandCase&) = delete;
};

/* SystemVerilog `case (X) matches` pattern matching (IEEE 1800-2017
 * 12.6). Each non-default item has a typed pattern and an implicit lexical
 * block containing any pattern variables. */
class PCaseMatches : public Statement {

    public:
      struct Item {
            PMatchPattern*pattern;
            bool is_default;
            Statement *stat;
            Item() : pattern(nullptr), is_default(false), stat(nullptr) {}
            ~Item();
      };

      PCaseMatches(PExpr*expr, std::vector<Item*>*items,
                   NetCase::TYPE case_type)
            : expr_(expr), items_(items), case_type_(case_type) {}
      ~PCaseMatches() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      friend class pform_constructor_order_audit_t;
      PExpr *expr_;
      std::vector<Item*>*items_;
      NetCase::TYPE case_type_;

    private: // not implemented
      PCaseMatches(const PCaseMatches&) = delete;
      PCaseMatches& operator=(const PCaseMatches&) = delete;
};

/* Internal statement prepended to a pattern item's implicit block. It copies
 * one selected member into its already-declared pattern variable after the
 * predicate succeeds and before the user's statement executes. */
class PPatternAssign : public Statement {
    public:
      PPatternAssign(const pform_scoped_name_t&subject,
                     unsigned lexical_pos,
                     const pform_pattern_path_t&path,
                     perm_string destination)
      : subject_(subject), lexical_pos_(lexical_pos), path_(path),
        destination_(destination) { }

      NetProc* elaborate(Design*des, NetScope*scope) const override;
      void dump(std::ostream&out, unsigned ind) const override;

    private:
      pform_scoped_name_t subject_;
      unsigned lexical_pos_;
      pform_pattern_path_t path_;
      perm_string destination_;
};

class PCAssign  : public Statement {

    public:
      explicit PCAssign(PExpr*l, PExpr*r);
      ~PCAssign() override;

      PCAssign(const PCAssign&) = delete;
      PCAssign& operator=(const PCAssign&) = delete;

      virtual NetCAssign* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      PExpr*lval_;
      PExpr*expr_;
};

/*
 * This represents the syntax "super.new(...)". This is not really an
 * executable statement, but the elaborator will handle these
 * specially and will remove them from the statement stream. If any
 */
class PChainConstructor : public Statement {
    public:
      explicit PChainConstructor(const std::list<named_pexpr_t> &parms);
      explicit PChainConstructor(const std::vector<named_pexpr_t> &parms);
      ~PChainConstructor() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

      inline const std::vector<named_pexpr_t>& chain_args(void) const
      { return parms_; }

      void set_synthesized(void) { synthesized_ = true; }
      bool is_synthesized(void) const { return synthesized_; }

    private:
      std::vector<named_pexpr_t> parms_;
      bool synthesized_;
};

class PCondit  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      PCondit(PExpr*ex, Statement*i, Statement*e);
      ~PCondit() override;

	// Read by the assertion lowering, which has to reproduce a user
	// action block at two sites.
      PExpr* cond_expr() const { return expr_; }
      Statement* if_clause() const { return if_; }
      Statement* else_clause() const { return else_; }

      // Transfer a parsed else-if chain into another statement shape.
      PExpr* release_cond_expr();
      Statement* release_if_clause();
      Statement* release_else_clause();
      void set_else_clause(Statement*statement)
      { else_ = statement; }

	/* Some other parsed constructs (notably immediate assertions) use a
	   PCondit internally. Record when this node came from an actual `if`
	   statement so qualified-if lowering only flattens syntactic else-if
	   chains. */
      void parsed_if_statement(bool flag = true)
	{ parsed_if_statement_ = flag; }
      bool is_parsed_if_statement() const
	{ return parsed_if_statement_; }

	/* A simple/deferred immediate assertion is represented by a
	   conditional whose branches are assertion action blocks. Keep that
	   provenance through elaboration: system tasks in an assertion action
	   are verification behavior, not logic to synthesize from the
	   containing always_comb/always_ff process. */
      void immediate_assertion(bool flag = true)
	{ immediate_assertion_ = flag; }
      bool is_immediate_assertion() const
	{ return immediate_assertion_; }

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      PExpr*expr_;
      Statement*if_;
      Statement*else_;
      bool parsed_if_statement_ = false;
      bool immediate_assertion_ = false;

    private: // not implemented
      PCondit(const PCondit&);
      PCondit& operator= (const PCondit&);
};

class PContinue : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
};

class PDeassign  : public Statement {

    public:
      explicit PDeassign(PExpr*l);
      ~PDeassign() override;

      PDeassign(const PDeassign&) = delete;
      PDeassign& operator=(const PDeassign&) = delete;

      virtual NetDeassign* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      PExpr*lval_;
};

class PDelayStatement  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      PDelayStatement(PExpr*d, Statement*st);
      ~PDelayStatement() override;

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      PExpr*delay_;
      Statement*statement_;
};

/*
 * IEEE 1800-2017 14.11: procedural cycle delay `## count [statement]`.
 * Waits `count` events of the default clocking block visible in the
 * enclosing module/interface/program scope, then runs the optional
 * sub-statement. Elaboration lowers this to
 *   repeat (count) @(<default clocking>) ; <statement>
 */
class PCycleDelay : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      PCycleDelay(PExpr*count, Statement*st);
      ~PCycleDelay() override;

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      PExpr*count_;
      Statement*statement_;
};


/*
 * This represents the parsing of a disable <scope> statement.
 */
class PDisable  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      explicit PDisable(const pform_name_t&sc);
      ~PDisable() override;

      virtual void dump(std::ostream&out, unsigned ind) const override;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;

    private:
      pform_name_t scope_;
};

class PDoWhile  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      PDoWhile(PExpr*ex, Statement*st);
      ~PDoWhile() override;

      PDoWhile(const PDoWhile&) = delete;
      PDoWhile& operator=(const PDoWhile&) = delete;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      PExpr*cond_;
      Statement*statement_;
};

/*
 * The event statement represents the event delay in behavioral
 * code. It comes from such things as:
 *
 *      @name <statement>;
 *      @(expr) <statement>;
 *      @* <statement>;
 */
class PEventStatement  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;

      explicit PEventStatement(const std::vector<PEEvent*>&ee);
      explicit PEventStatement(PEEvent*ee);
	// Make an @* statement or make a special @* version with the items
	// from functions added and outputs removed for always_comb/latch.
      explicit PEventStatement(bool always_sens = false);

      ~PEventStatement() override;

      void set_statement(Statement*st);
	// Preserve an explicit, possibly empty, wait_order else clause.
      void set_wait_order() { wait_order_ = true; }
      void set_wait_order_else(Statement*st)
      { wait_order_ = true; wait_order_else_ = true; else_statement_ = st; }
	// The statement the event control guards, so a caller that
	// synthesizes extra work around it (M9-SV sampled value
	// capture) can wrap what is already there.
      Statement* statement() const { return statement_; }

      virtual void dump(std::ostream&out, unsigned ind) const override;
	// Call this with a NULL statement only. It is used to print
	// the event expression for inter-assignment event controls.
      virtual void dump_inline(std::ostream&out) const;
      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;

      bool has_aa_term(Design*des, NetScope*scope);
      const std::vector<PEEvent*>& event_expressions() const { return expr_; }

	// This method is used to elaborate, but attach a previously
	// elaborated statement to the event.
      NetProc* elaborate_st(Design*des, NetScope*scope, NetProc*st) const;

      NetProc* elaborate_wait(Design*des, NetScope*scope, NetProc*st) const;
      NetProc* elaborate_wait_fork(Design*des, const NetScope*scope) const;

      bool contains_detached_fork() const override;

    private:
      NetProc* elaborate_conditional_(Design*des, NetScope*scope,
				      NetProc*st) const;
      NetProc* elaborate_wait_order_(Design*des, NetScope*scope) const;
      bool has_conditional_event_() const;

      std::vector<PEEvent*>expr_;
      Statement*statement_;
      Statement*else_statement_ = nullptr;
      bool wait_order_ = false;
      bool wait_order_else_ = false;
      bool always_sens_;
};

std::ostream& operator << (std::ostream&o, const PEventStatement&obj);

class PForce  : public Statement {

    public:
      explicit PForce(PExpr*l, PExpr*r);
      ~PForce() override;

      PForce(const PForce&) = delete;
      PForce& operator=(const PForce&) = delete;

      virtual NetForce* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      PExpr*lval_;
      PExpr*expr_;
};

class PForeach : public Statement {
    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      explicit PForeach(const pform_name_t&var,
                        const std::list<perm_string>&ix,
                        Statement*stmt,
                        unsigned lexical_pos);
      ~PForeach() override;

      PForeach(const PForeach&) = delete;
      PForeach& operator=(const PForeach&) = delete;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
	// Iterate a target that resolved to a SIGNAL (a net or variable),
	// whatever the path shape was. A hierarchical target -- an array
	// member of an interface INSTANCE, `foreach (sif.arr[i])' -- lands
	// here too, so it takes the same route as a plain local array.
      NetProc* elaborate_signal_array_(Design*des, NetScope*scope,
				       NetNet*array_sig) const;
      NetProc* elaborate_assoc_array_(Design*des, NetScope*scope,
				      NetExpr*array_expr,
				      size_t index_var_start) const;
      NetProc* elaborate_assoc_array_(Design*des, NetScope*scope,
				      NetExpr*array_expr) const;
      NetProc* elaborate_runtime_array_(Design*des, NetScope*scope,
					NetExpr*array_expr) const;
      NetProc* elaborate_runtime_array_(Design*des, NetScope*scope,
					NetExpr*array_expr,
					size_t index_var_start) const;
      NetProc* elaborate_static_array_(Design*des, NetScope*scope,
				       const netranges_t&dims) const;
      NetProc* elaborate_static_array_prefix_(Design*des, NetScope*scope,
				       const netranges_t&dims, size_t count,
				       NetProc*sub,
				       size_t index_var_start = 0) const;
      NetProc* elaborate_mixed_fixed_array_(Design*des, NetScope*scope,
				       const netranges_t&dims) const;

    private:
      pform_name_t array_path_;
      std::vector<perm_string> index_vars_;
      Statement*statement_;
      unsigned lexical_pos_;
};

class PForever : public Statement {
    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      explicit PForever(Statement*s);
      ~PForever() override;

      PForever(const PForever&) = delete;
      PForever& operator=(const PForever&) = delete;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      Statement*statement_;
};

class PForStatement  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      PForStatement(PExpr*n1, PExpr*e1, PExpr*cond,
		    Statement*step, Statement*body);
      ~PForStatement() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
        // The assignment carrier owns NAME1_/EXPR1_. The aliases are retained
        // because the direct NetForLoop signal path needs the original parsed
        // operands for synthesis metadata.
      PAssign*initialization_;
      PExpr* name1_;
      PExpr* expr1_;

      PExpr*cond_;

      Statement*step_;

      Statement*statement_;
};

class PNoop  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      PNoop() { }
      ~PNoop() override { }
      NetProc* elaborate(Design*des, NetScope*scope) const override;
};

class PRepeat : public Statement {
    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      explicit PRepeat(PExpr*expr, Statement*s);
      ~PRepeat() override;

      PRepeat(const PRepeat&) = delete;
      PRepeat& operator=(const PRepeat&) = delete;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;
      PExpr* count_expr() const { return expr_; }
      Statement* body() const { return statement_; }

    private:
      friend class pform_constructor_order_audit_t;
      PExpr*expr_;
      Statement*statement_;
};

class PRelease  : public Statement {

    public:
      explicit PRelease(PExpr*l);
      ~PRelease() override;

      PRelease(const PRelease&) = delete;
      PRelease& operator=(const PRelease&) = delete;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      PExpr*lval_;
};

class PReturn  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      explicit PReturn(PExpr*e);
      ~PReturn() override;

      PReturn(const PReturn&) = delete;
      PReturn& operator=(const PReturn&) = delete;

      NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      PExpr* expr() const { return expr_; }

    private:
      PExpr*expr_;
};

/*
 * The PTrigger statement sends a trigger to a named event. Take the
 * name here.
 */
class PTrigger  : public Statement {

    public:
      explicit PTrigger(PPackage*pkg, const pform_name_t&ev, unsigned lexical_pos);
      ~PTrigger() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      pform_scoped_name_t event_;
      unsigned lexical_pos_;
};

class PNBTrigger  : public Statement {
    public:
      explicit PNBTrigger(const pform_name_t&ev, unsigned lexical_pos, PExpr*dly);
      ~PNBTrigger() override;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;

    private:
      pform_name_t event_;
      unsigned lexical_pos_;
      PExpr*dly_;
};

class PWhile  : public Statement {

    public:
      bool refs_name(perm_string name) const override;
      bool detached_fork_refs_name(perm_string name) const override;
      PWhile(PExpr*ex, Statement*st);
      ~PWhile() override;

      PWhile(const PWhile&) = delete;
      PWhile& operator=(const PWhile&) = delete;

      virtual NetProc* elaborate(Design*des, NetScope*scope) const override;
      virtual void elaborate_scope(Design*des, NetScope*scope) const override;
      virtual void elaborate_sig(Design*des, NetScope*scope) const override;
      virtual void dump(std::ostream&out, unsigned ind) const override;
      bool contains_detached_fork() const override;

    private:
      friend class pform_constructor_order_audit_t;
      PExpr*cond_;
      Statement*statement_;
};

/*
 * IEEE 1800-2017 19.5 gives an embedded covergroup constructor a
 * source-order dependency on every enclosing instance constant used by the
 * covergroup expression.  This interface deliberately separates semantic
 * classification (which needs the elaborated class/property tables) from the
 * pform statement walk (which alone still has the original branch, loop, and
 * fork structure).
 *
 * The classifier is called for each procedural assignment and for the
 * initialization assignment in a for-loop header. PROPERTY_IDX is an opaque,
 * class-relative identity selected by the caller; the walker only compares
 * identities. BLOCK_STACK contains the enclosing pform blocks, outermost
 * first, and is valid only for the duration of the callback.
 */
struct pform_constructor_order_assignment_t {
      const Statement*statement = nullptr;
      const PExpr*lval = nullptr;
      const PExpr*rval = nullptr;
      const std::vector<const PBlock*>*block_stack = nullptr;
      bool plain_blocking = false;
};

struct pform_constructor_order_dependency_t {
      size_t property_idx = 0;
      const LineInfo*reference_site = nullptr;
      const char*covergroup_name = nullptr;
};

class pform_constructor_order_classifier_t {
    public:
      virtual ~pform_constructor_order_classifier_t() = default;

      virtual bool classify_instance_constant_initializer(
            const pform_constructor_order_assignment_t&assignment,
            size_t&property_idx) const = 0;

      virtual bool classify_embedded_covergroup_constructor(
            const pform_constructor_order_assignment_t&assignment,
            std::vector<pform_constructor_order_dependency_t>&dependencies)
            const = 0;

      // Return a concrete repeat count only when the expression folds in the
      // current constructor specialization without expression elaboration.
      // BLOCK_STACK preserves lexical shadowing at the repeat site. A runtime
      // expression is not an error and is reported by returning false. This
      // callback is observational: it must not mutate the design, elaborate
      // an expression, or report a diagnostic.
      virtual bool classify_repeat_count(const PExpr*count,
                                         const std::vector<const PBlock*>*
                                               block_stack,
                                         long&iterations) const
      { (void)count; (void)block_stack; (void)iterations; return false; }
};

enum pform_constructor_order_violation_kind_t {
      PFORM_CTOR_ORDER_NOT_INITIALIZED,
      PFORM_CTOR_ORDER_SHARED_LOOP,
      PFORM_CTOR_ORDER_SHARED_JOIN_NONE,
      PFORM_CTOR_ORDER_REASSIGNMENT
};

struct pform_constructor_order_violation_t {
      pform_constructor_order_violation_kind_t kind =
            PFORM_CTOR_ORDER_NOT_INITIALIZED;
      size_t property_idx = 0;
      const LineInfo*initializer_site = nullptr;
      const LineInfo*constructor_site = nullptr;
      const LineInfo*reference_site = nullptr;
      const char*covergroup_name = nullptr;
      const Statement*region = nullptr;
};

struct pform_constructor_order_result_t {
      std::set<size_t> definitely_initialized_at_exit;
      std::set<const Statement*>authorized_instance_constant_initializers;
      std::set<const Statement*>rejected_instance_constant_initializers;
      std::map<const Statement*,size_t> instance_constant_initializer_properties;
      std::vector<pform_constructor_order_violation_t> violations;
      bool has_reachable_exit = false;
};

/*
 * Analyze one already-blended constructor body. INITIALLY_INITIALIZED is used
 * for inherited instance constants whose declaring-class constructor has
 * already been proved, and is normally empty for locally declared constants.
 */
extern pform_constructor_order_result_t audit_pform_constructor_order(
      const Statement*statement,
      const pform_constructor_order_classifier_t&classifier,
      const std::set<size_t>&initially_initialized = std::set<size_t>());

#endif /* IVL_Statement_H */
