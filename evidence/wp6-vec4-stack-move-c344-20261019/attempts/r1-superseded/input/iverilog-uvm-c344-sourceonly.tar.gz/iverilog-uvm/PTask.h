#ifndef IVL_PTask_H
#define IVL_PTask_H
/*
 * Copyright (c) 1999-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "PScope.h"
# include  "PNamedItem.h"
# include  "StringHeap.h"
# include  <string>
# include  <vector>
# include  <list>
class Design;
class NetExpr;
class NetNet;
class NetScope;
class PChainConstructor;
class PWire;
class Statement;
class PExpr;

enum method_override_specifier_t {
      METHOD_OVERRIDE_INITIAL = 1,
      METHOD_OVERRIDE_EXTENDS = 2,
      METHOD_OVERRIDE_FINAL = 4
};

class PTaskFunc : public PScope, public PNamedItem {

    public:
      PTaskFunc(perm_string name, LexicalScope*parent);
      ~PTaskFunc() override;

      bool var_init_needs_explicit_lifetime() const override;

      void set_ports(std::vector<pform_tf_port_t>*p);
      // Append ports declared through the statement-context direction
      // rule (a non-ANSI direction declaration that arrives after the
      // body has left the tf_item declaration section, e.g.
      // `int x; input x;`). set_ports() later prepends the tf_item
      // ports so declaration order is preserved.
      void append_stmt_port_decls(std::vector<pform_tf_port_t>*p);
      // Public accessor for parse-form port metadata used by early
      // signature and legality checks before every NetBaseDef is available.
      inline const std::vector<pform_tf_port_t>* peek_ports() const { return ports_; }

      void set_this(class_type_t*use_type, PWire*this_wire);
      void set_method_type_only(class_type_t*use_type);

	// If this task is a method of a class, this returns a pointer
	// to the class type.
      inline class_type_t* method_of() const { return this_type_; }

      property_qualifier_t method_qualifiers() const { return method_qualifiers_; }
      void set_method_qualifiers(property_qualifier_t q) { method_qualifiers_ = q; }

      inline bool is_virtual_method() const { return is_virtual_; }
      inline void set_virtual_method(bool v) { is_virtual_ = v; }

      inline unsigned method_override_specifiers() const {
	    return method_override_specifiers_;
      }
      inline void set_method_override_specifiers(unsigned v) {
	    method_override_specifiers_ = v;
      }

      inline bool is_pure_method() const { return is_pure_; }
      inline void set_pure_method(bool v) {
	    is_pure_ = v;
	    if (v) is_virtual_ = true;
      }
      inline bool interface_qualifier_valid() const {
	    return interface_qualifier_valid_;
      }
      inline void set_interface_qualifier_valid(bool v) {
	    interface_qualifier_valid_ = v;
      }

      inline bool is_procedural_body_scope() const {
	    return procedural_body_scope_;
      }
      inline void set_procedural_body_scope(bool v) {
	    procedural_body_scope_ = v;
      }

	// DPI import linkage (35.x): both functions and tasks can be
	// DPI imports; the code generator synthesizes the marshaling
	// body from the C name.
      void set_dpi_import(const char*c_name) {
	    is_dpi_import_ = true;
	    dpi_c_name_ = c_name;
      }
      bool is_dpi_import() const { return is_dpi_import_; }
      const std::string& dpi_c_name() const { return dpi_c_name_; }

	// DPI export linkage (35.5): a normal SV function/task (with a
	// body) that is additionally made callable from C under a C name.
	// Marked by a separate `export "DPI-C"' declaration that names it.
      void set_dpi_export(const char*c_name) {
	    is_dpi_export_ = true;
	    dpi_export_c_name_ = c_name;
      }
      bool is_dpi_export() const { return is_dpi_export_; }
      const std::string& dpi_export_c_name() const { return dpi_export_c_name_; }

      virtual void elaborate_sig(Design*des, NetScope*scope) const =0;
      virtual void elaborate(Design*des, NetScope*scope) const =0;

      virtual void dump(std::ostream&, unsigned) const =0;

    protected:
	// Elaborate the ports list. Write into the ports vector the
	// NetNet pointers for the ports, and write into the pdefs the
	// default value expressions, if any.
      void elaborate_sig_ports_(Design*des, NetScope*scope,
				std::vector<NetNet*>&ports,
				std::vector<NetExpr*> &pdefs,
				std::vector<perm_string> &port_names) const;

      void dump_ports_(std::ostream&out, unsigned ind) const;

    private:
      class_type_t*this_type_;
      property_qualifier_t method_qualifiers_ = property_qualifier_t::make_none();
      bool is_virtual_ = false;
      bool is_pure_ = false;
      unsigned method_override_specifiers_ = 0;
      bool interface_qualifier_valid_ = true;
      bool procedural_body_scope_ = true;
      bool is_dpi_import_ = false;
      std::string dpi_c_name_;
      bool is_dpi_export_ = false;
      std::string dpi_export_c_name_;
      std::vector<pform_tf_port_t>*ports_;
};

/*
 * The PTask holds the parsed definitions of a task.
 */
class PTask  : public PTaskFunc {

    public:
      explicit PTask(perm_string name, LexicalScope*parent, bool is_auto);
      ~PTask() override;

      void set_statement(Statement *s);
      void release_elaboration_memory();
      inline Statement* get_statement() { return statement_; }
      inline const Statement* get_statement() const { return statement_; }

	// Tasks introduce scope, to need to be handled during the
	// scope elaboration pass. The scope passed is my scope,
	// created by the containing scope. I fill it in with stuff if
	// I need to.
      void elaborate_scope(Design*des, NetScope*scope) const;

	// Bind the ports to the regs that are the ports.
      void elaborate_sig(Design*des, NetScope*scope) const override;

	// Elaborate the statement to finish off the task definition.
      void elaborate(Design*des, NetScope*scope) const override;

      bool is_auto() const { return is_auto_; };

      void dump(std::ostream&, unsigned) const override;

      SymbolType symbol_type() const override;

    private:
      Statement*statement_;
      bool is_auto_;

    private: // Not implemented
      PTask(const PTask&);
      PTask& operator=(const PTask&);
};

/*
 * The function is similar to a task (in this context) but there is a
 * single output port and a set of input ports. The output port is the
 * function return value.
 *
 * The output value is not elaborated until elaborate_sig.
 */
class PFunction : public PTaskFunc {

    public:
      explicit PFunction(perm_string name, LexicalScope*parent, bool is_auto);
      ~PFunction() override;

      void set_statement(Statement *s);
      void release_elaboration_memory();
      void set_return(data_type_t*t);
      void set_return_type_scope_local() { return_type_scope_local_ = true; }

      void set_constructor_default(bool value) { constructor_default_ = value; }
      bool has_constructor_default() const { return constructor_default_; }
      void set_constructor_default_lexical_pos(unsigned pos) {
	    constructor_default_lexical_pos_ = pos;
      }
      unsigned constructor_default_lexical_pos() const {
	    return constructor_default_lexical_pos_;
      }
      void add_constructor_default_port(perm_string name) {
	    constructor_default_ports_.push_back(name);
      }
      const std::vector<perm_string>& constructor_default_ports() const {
	    return constructor_default_ports_;
      }

      inline Statement* get_statement() { return statement_; }
      inline const Statement* get_statement() const { return statement_; }

	// Push this statement to the front of the existing
	// definition. If the statement is a simple statement, make a
	// block to contain the statements.
      void push_statement_front(Statement*stmt);

	// This is only used if this function is a constructor. In
	// that case, this method looks for a PChainConstructor in the
	// statement and extracts it if found.
      PChainConstructor*extract_chain_constructor();

      void elaborate_scope(Design*des, NetScope*scope) const;

	/* elaborate the ports and return value. */
      void elaborate_sig(Design *des, NetScope*) const override;

	/* Elaborate the behavioral statement. */
      void elaborate(Design *des, NetScope*) const override;

      bool is_auto() const { return is_auto_; };

      void dump(std::ostream&, unsigned) const override;

      SymbolType symbol_type() const override;

    private:
      data_type_t* return_type_;
      Statement *statement_;
      bool is_auto_;
      bool return_type_scope_local_ = false;
      bool constructor_default_ = false;
      unsigned constructor_default_lexical_pos_ = 0;
      std::vector<perm_string> constructor_default_ports_;
};

// A let is like a simple function that is expanded in the compiler
class PLet : public PTaskFunc {
    public:
      typedef struct let_port {
	    data_type_t*type_;
	    perm_string name_;
	    std::list<pform_range_t>*range_;
	    PExpr*def_;

	    void dump(std::ostream&, unsigned) const;
      } let_port_t;

// FIXME: Should the port list be a vector. Check once implemented completely
      explicit PLet(perm_string name, LexicalScope*parent,
                    std::list<let_port_t*>*ports, PExpr*expr);
      ~PLet() override;

      void elaborate_sig(Design*des, NetScope*scope) const override { (void)des; (void)scope; }
      void elaborate(Design*des, NetScope*scope) const override { (void)des; (void)scope; }

      void dump(std::ostream&, unsigned) const override;

      const std::list<let_port_t*>* let_ports() const { return ports_; }
      PExpr* let_expr() const { return expr_; }

    private:
      std::list<let_port_t*>*ports_;
      PExpr*expr_;
};

#endif /* IVL_PTask_H */
