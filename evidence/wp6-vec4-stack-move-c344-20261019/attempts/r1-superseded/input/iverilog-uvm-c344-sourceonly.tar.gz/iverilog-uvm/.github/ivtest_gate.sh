#!/usr/bin/env bash
# Hard regression gate over the vendored ivtest suite (manifesto Phase 0).
#
# Runs the full vvp_reg.pl sweep and name-diffs the failing set against
# the committed expectation list. The gate FAILS on any difference in
# EITHER direction:
#   - a test failing that is not in the list  -> new, unexplained
#     regression; fix it or (only with a written reason) add it.
#   - a listed test that now passes           -> stale entry; remove it
#     in the same PR so the expectation list always states the truth.
#
# Every name in the expectation list carries a category comment in
# docs/conformance/ (baseline + audit); nothing is allowed to fail
# without a written reason. Also hard-gates the bundled VPI suite,
# the negative suite, and malformed-bytecode runtime invariants.
#
# Usage: ./.github/ivtest_gate.sh   (from the repository root)

set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
EXPECT="$ROOT/docs/conformance/ivtest_expected_fails.list"
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

status=0

# The standalone checks below default to $ROOT/local-install, which CI does
# not have (it installs to the default prefix); test the PATH toolchain, as
# the ivtest sweep does.
IVERILOG=${IVERILOG:-$(command -v iverilog 2>/dev/null)}
VVP=${VVP:-$(command -v vvp 2>/dev/null)}
export IVERILOG VVP

if ! python3 "$ROOT/tests/vvp_runtime/run_covgrp_exports.py"; then
    status=1
fi

if ! python3 "$ROOT/tests/vvp_runtime/run_copyout_context.py"; then
    status=1
fi

if ! python3 "$ROOT/tests/vvp_runtime/run_indexed_darray_slice.py"; then
    status=1
fi

if ! bash "$ROOT/tests/vvp_runtime/run_dpi_shortreal_array.sh"; then
    status=1
fi

if ! bash "$ROOT/tests/vvp_runtime/run_dpi_export_fixed_array.sh"; then
    status=1
fi

if ! bash "$ROOT/tests/vvp_runtime/run_cross_product_limit.sh"; then
    status=1
fi

if ! bash "$ROOT/tests/vvp_runtime/run_merged_transition_cardinality.sh"; then
    status=1
fi

if ! bash "$ROOT/tests/vvp_runtime/run_vpi_source_location.sh"; then
    status=1
fi

echo "=== ivtest sweep (vendored suite) ==="
cd "$ROOT/ivtest"
if ! perl vvp_reg.pl > "$WORK/ivtest.log" 2>&1; then
    echo "GATE FAIL: legacy ivtest harness exited nonzero."
    status=1
fi
tail -3 "$WORK/ivtest.log"

if ! awk -F'[=,]' '
    /Total=/ {
        found = 1
        total = $2 + 0
        passed = $4 + 0
        failed = $6 + 0
        not_impl = $8 + 0
        expected_fail = $10 + 0
        if (failed == 0 && total == passed + not_impl + expected_fail)
            valid = 1
    }
    END { exit !(found && valid) }
' "$WORK/ivtest.log"; then
    echo "GATE FAIL: legacy ivtest summary is missing, inconsistent, or has failures."
    status=1
fi

grep -E "==> Failed|Failed - missing" "$WORK/ivtest.log" \
    | awk -F: '{gsub(/ /,"",$1); print $1}' | sort -u > "$WORK/actual.txt"
grep -vE "^#|^\s*$" "$EXPECT" | awk '{print $1}' | sort -u > "$WORK/expected.txt"

new_fails=$(comm -23 "$WORK/actual.txt" "$WORK/expected.txt")
stale=$(comm -13 "$WORK/actual.txt" "$WORK/expected.txt")

if [ -n "$new_fails" ]; then
    echo ""
    echo "GATE FAIL: unexplained new ivtest failures:"
    echo "$new_fails" | sed 's/^/  /'
    while IFS= read -r test; do
        grep -F "$test:" "$WORK/ivtest.log" | tail -1
        echo "--- log/$test.log (last 80 lines) ---"
        tail -n 80 "log/$test.log"
    done <<< "$new_fails"
    echo "Each must be fixed, or added to $EXPECT with a documented reason."
    status=1
fi
if [ -n "$stale" ]; then
    echo ""
    echo "GATE FAIL: stale expectation entries (these tests now PASS):"
    echo "$stale" | sed 's/^/  /'
    echo "Remove them from $EXPECT in this PR so the list stays truthful."
    status=1
fi
[ $status -eq 0 ] && echo "ivtest name-diff gate: clean ($(wc -l < "$WORK/actual.txt") expected failures, 0 unexplained)"

echo ""
echo "=== stub type parameters ==="
if ! iverilog -g2012 -tstub -s test -o "$WORK/stub.out" \
    "$ROOT/ivtest/ivltests/sv_stub_type_parameter.v"; then
    echo "GATE FAIL: stub type parameter test did not compile."
    status=1
elif ! awk '
    /^scope: test\.(default_type|overridden_type) / { scope = $2 }
    /^end scope test\./ { scope = "" }
    scope && /^   parameter type T;$/ { type[scope]++ }
    scope && /^   parameter Width;$/ { width[scope]++ }
    scope && /parameter=Width>/ { value[scope]++ }
    END {
        exit !(type["test.default_type"] == 1 && type["test.overridden_type"] == 1 &&
               width["test.default_type"] == 1 && width["test.overridden_type"] == 1 &&
               value["test.default_type"] == 1 && value["test.overridden_type"] == 1)
    }
' "$WORK/stub.out"; then
    echo "GATE FAIL: stub output omitted a type or value parameter."
    status=1
fi

echo ""
echo "=== bundled VPI suite ==="
perl vpi_reg.pl > "$WORK/vpi.log" 2>&1
tail -1 "$WORK/vpi.log"
if ! grep -qE "Total=[0-9]+, Passed=[0-9]+, Failed=0, Not Implemented=0" "$WORK/vpi.log" \
   || ! awk -F'[=,]' '/Test results/ { exit !($2 == $4) }' "$WORK/vpi.log"; then
    echo "GATE FAIL: bundled VPI suite has failures (Total must equal Passed, Failed must be 0)."
    status=1
fi

echo ""
echo "=== negative suite ==="
cd "$ROOT"
if ! bash tests/negative/run_negative.sh > "$WORK/neg.log" 2>&1; then
    tail -5 "$WORK/neg.log"
    echo "GATE FAIL: negative suite has failures."
    status=1
else
    tail -1 "$WORK/neg.log"
fi

echo ""
echo "=== associative-array invalid-index warning focus ==="
if ! bash "$ROOT/.github/ivtest_focus_gate.sh" \
    regress-assoc-missing-key-warning-legacy.list \
    regress-assoc-missing-key-warning-vvp.list; then
    status=1
fi

echo ""
echo "=== VVP runtime invariants ==="
runtime_vvp=$(command -v vvp 2>/dev/null || true)
runtime_iverilog=$(command -v iverilog 2>/dev/null || true)
if [ -z "$runtime_vvp" ] || [ -z "$runtime_iverilog" ] \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        python3 ivtest/runtime_root_seed.py \
        > "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_rand_mode_stack_underflow.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_prop_const_init_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_bounded_queue_metadata_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_darray_default_fill_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_array_lifetime_legacy.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_assoc_traversal_key_width.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_assoc_set_default_malformed_width.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_array_slice_marshal_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_return_prefix_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" \
        bash tests/vvp_runtime/run_dpi_narrow_return_metadata.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_prefixless_vec4_compat.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_plain_char_abi.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_export_output_logic_default.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_scalar_inout_logic_actual.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_scope_instance.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_disable_protocol.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_disable_protocol_negatives.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dpi_legacy_task_void_compat.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_process_kill_call_context.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_concat_malformed_arity.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_dist_ir_compat.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_covgrp_metadata.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_covgrp_options_report.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_vif_indexed_wait_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_force_array_runtime.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_container_conversion.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_queue_slice_legacy.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! IVERILOG="$runtime_iverilog" VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_string_repeat_ir_compat.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_static_property_binding.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_stream_target_split_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_ufunc_resolver_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_boolean_automatic_history.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        bash tests/vvp_runtime/run_mixed_wait_malformed.sh \
        >> "$WORK/vvp-runtime.log" 2>&1 \
   || ! VVP="$runtime_vvp" \
        python3 tests/vvp_runtime/run_state_foreach_invariants.py \
        >> "$WORK/vvp-runtime.log" 2>&1; then
    cat "$WORK/vvp-runtime.log" 2>/dev/null || true
    echo "GATE FAIL: VVP bytecode invariant failed."
    status=1
else
    tail -1 "$WORK/vvp-runtime.log"
fi

echo "=== JSON ivtest sweep (vvp_reg.py) ==="
# The default install omits tgt-fpga, but JSON synthesis rejects need fpga.conf.
if ! make -C "$ROOT/tgt-fpga" install && \
   { ! command -v sudo >/dev/null 2>&1 || ! sudo -n make -C "$ROOT/tgt-fpga" install; }; then
    echo "GATE FAIL: could not install the FPGA target needed by JSON ivtest."
    status=1
fi

cd "$ROOT/ivtest"
json_start=$(date +%s)
if ! python3 ./vvp_reg.py > "$WORK/json-ivtest.log" 2>&1; then
    echo "GATE FAIL: JSON ivtest runner exited nonzero."
    awk '/: Failed|^Test results:/ { print }' "$WORK/json-ivtest.log"
    status=1
else
    grep '^Test results:' "$WORK/json-ivtest.log" | tail -1
fi
json_elapsed=$(($(date +%s) - json_start))
echo "JSON ivtest wall time: ${json_elapsed}s"

exit $status
