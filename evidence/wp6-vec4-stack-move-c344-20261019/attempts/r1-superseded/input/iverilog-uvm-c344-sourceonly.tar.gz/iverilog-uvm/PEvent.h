#ifndef IVL_PEvent_H
#define IVL_PEvent_H
/*
 * Copyright (c) 2000-2025 Stephen Williams (steve@icarus.com)
 *
 *    This source code is free software; you can redistribute it
 *    and/or modify it in source code form under the terms of the GNU
 *    General Public License as published by the Free Software
 *    Foundation; either version 2 of the License, or (at your option)
 *    any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

# include  "PNamedItem.h"
# include  "StringHeap.h"
# include  "ivl_target.h"
# include  "pform_types.h"
# include  <string>
# include  <list>

class Design;
class NetScope;

/*
 * The PEvent class represents event objects. These are things that
 * are declared in Verilog as ``event foo;'' The name passed to the
 * constructor is the "foo" part of the declaration.
 */
class PEvent : public PNamedItem {

    public:
	// The name is a perm-allocated string. It is the simple name
	// of the event, without any scope.
      explicit PEvent(perm_string name, unsigned lexical_pos);
      ~PEvent() override;

      perm_string name() const;

      unsigned lexical_pos() const { return lexical_pos_; }

      ivl_lifetime_t lifetime_override() const { return lifetime_override_; }
      void lifetime_override(ivl_lifetime_t val) { lifetime_override_ = val; }

	// An unpacked-array bound (IEEE 1800-2017 6.20, e.g.
	// `event arr[3];`). Takes ownership of the list. Null for an
	// ordinary scalar event.
      void set_array_dims(std::list<pform_range_t>*dims) { array_dims_ = dims; }
      const std::list<pform_range_t>* array_dims() const { return array_dims_; }

      void elaborate_scope(Design*des, NetScope*scope) const;

      SymbolType symbol_type() const override;

    private:
      perm_string name_;
      unsigned lexical_pos_;
      ivl_lifetime_t lifetime_override_;
      std::list<pform_range_t>*array_dims_;

    private: // not implemented
      PEvent(const PEvent&);
      PEvent& operator= (const PEvent&);
};

#endif /* IVL_PEvent_H */
